<?php
/**
 * SMM Panel - Ana Konfigürasyon Dosyası
 */

if (PHP_SAPI !== 'cli' && realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
    http_response_code(404);
    exit;
}

error_reporting(E_ALL);
ini_set('display_errors', 0);

date_default_timezone_set('Europe/Istanbul');

// Security katmanı oturumu güvenli cookie ayarlarıyla başlatır.
require_once __DIR__ . '/security.php';

// Veritabanı Ayarları
define('DB_HOST', 'localhost');
define('DB_NAME', '');
define('DB_USER', '');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

define('SITE_URL', '');
define('CRON_SECRET_KEY', '');
define('SITE_PATH', __DIR__);
define('MONI_VERSION', 'v2');

// Kurulum tamamlanmadıysa web isteklerini installer'a yönlendir.
// Böylece boş config ile ana sayfa açıldığında veritabanı hatası gösterilmez.
if (PHP_SAPI !== 'cli' && !file_exists(__DIR__ . '/install.lock')) {
    $currentScript = basename($_SERVER['SCRIPT_FILENAME'] ?? '');
    if ($currentScript !== 'install.php') {
        $documentRoot = isset($_SERVER['DOCUMENT_ROOT']) ? realpath($_SERVER['DOCUMENT_ROOT']) : false;
        $appRoot = realpath(__DIR__);
        $basePath = '';
        if ($documentRoot && $appRoot && strpos($appRoot, $documentRoot) === 0) {
            $basePath = str_replace(DIRECTORY_SEPARATOR, '/', substr($appRoot, strlen($documentRoot)));
        }
        $basePath = rtrim($basePath, '/');
        header('Location: ' . ($basePath !== '' ? $basePath : '') . '/install.php');
        exit;
    }
}

// Veritabanı Bağlantısı
class Database {
    private static $instance = null;
    private $pdo;
    
    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            $this->pdo = new PDO($dsn, DB_USER, DB_PASS, $options);

            // MySQL oturum saat dilimini TR saati yap
            $this->pdo->exec("SET time_zone = '+03:00'");
        } catch (PDOException $e) {
            error_log('Database connection failed: ' . $e->getMessage());
            if (PHP_SAPI === 'cli') { throw $e; }
            http_response_code(503);
            exit('Veritabanı bağlantısı şu anda kullanılamıyor. Lütfen daha sonra tekrar deneyin.');
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->pdo;
    }
}

$db = Database::getInstance()->getConnection();


// ==================== AYAR FONKSİYONLARI ====================

function getSetting($key, $default = '') {
    global $db;
    try {
        $stmt = $db->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $result = $stmt->fetch();
        return $result ? $result['setting_value'] : $default;
    } catch (PDOException $e) {
        return $default;
    }
}

function updateSetting($key, $value) {
    global $db;
    try {
        $stmt = $db->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) 
                              ON DUPLICATE KEY UPDATE setting_value = ?");
        return $stmt->execute([$key, $value, $value]);
    } catch (PDOException $e) {
        return false;
    }
}

// ==================== DİL FONKSİYONLARI ====================

/**
 * Aktif dili getir
 */
function getCurrentLanguage() {
    global $db;
    
    // Önce session kontrol
    if (isset($_SESSION['language'])) {
        return $_SESSION['language'];
    }
    
    // Sonra cookie kontrol
    if (isset($_COOKIE['language'])) {
        $_SESSION['language'] = $_COOKIE['language'];
        return $_COOKIE['language'];
    }
    
    // Varsayılan dili getir
    try {
        $stmt = $db->query("SELECT code FROM languages WHERE is_default = 1 AND is_active = 1 LIMIT 1");
        $lang = $stmt->fetchColumn();
        $lang = $lang ?: 'tr';
        $_SESSION['language'] = $lang;
        return $lang;
    } catch (Exception $e) {
        return 'tr';
    }
}

/**
 * Dil ayarla
 */
function setLanguage($langCode) {
    global $db;
    
    try {
        $stmt = $db->prepare("SELECT code FROM languages WHERE code = ? AND is_active = 1");
        $stmt->execute([$langCode]);
        if ($stmt->fetch()) {
            $_SESSION['language'] = $langCode;
            setcookie('language', $langCode, time() + (365 * 24 * 60 * 60), '/');
            return true;
        }
    } catch (Exception $e) {}
    
    return false;
}

/**
 * Tüm aktif dilleri getir
 */
function getLanguages() {
    global $db;
    try {
        $stmt = $db->query("SELECT * FROM languages WHERE is_active = 1 ORDER BY sort_order, name");
        return $stmt->fetchAll();
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Tüm dilleri getir (admin için)
 */
function getAllLanguages() {
    global $db;
    try {
        $stmt = $db->query("SELECT * FROM languages ORDER BY sort_order, name");
        return $stmt->fetchAll();
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Çevirileri yükle
 */
function loadTranslations($langCode = null) {
    global $db;
    static $translations = [];
    
    if ($langCode === null) {
        $langCode = getCurrentLanguage();
    }
    
    if (isset($translations[$langCode])) {
        return $translations[$langCode];
    }
    
    $translations[$langCode] = [];
    
    try {
        $stmt = $db->prepare("SELECT translation_key, translation_value FROM translations WHERE lang_code = ?");
        $stmt->execute([$langCode]);
        while ($row = $stmt->fetch()) {
            $translations[$langCode][$row['translation_key']] = $row['translation_value'];
        }
    } catch (Exception $e) {}
    
    return $translations[$langCode];
}

/**
 * Çeviri getir
 */
function __($key, $replacements = []) {
    static $translations = null;
    static $fallbackTranslations = null;
    static $currentLang = null;
    
    if ($translations === null) {
        $currentLang = getCurrentLanguage();
        $translations = loadTranslations($currentLang);
        
        if ($currentLang !== 'tr') {
            $fallbackTranslations = loadTranslations('tr');
        } else {
            $fallbackTranslations = [];
        }
    }
    
    // Çeviriyi bul
    $text = $translations[$key] ?? $fallbackTranslations[$key] ?? $key;
    
    // Değişkenleri değiştir
    if (!empty($replacements)) {
        foreach ($replacements as $placeholder => $value) {
            $text = str_replace(':' . $placeholder, $value, $text);
        }
    }
    
    return $text;
}

/**
 * Çeviri ekle/güncelle
 */
function setTranslation($langCode, $key, $value) {
    global $db;
    try {
        $stmt = $db->prepare("INSERT INTO translations (lang_code, translation_key, translation_value) 
                              VALUES (?, ?, ?) 
                              ON DUPLICATE KEY UPDATE translation_value = ?");
        return $stmt->execute([$langCode, $key, $value, $value]);
    } catch (Exception $e) {
        return false;
    }
}

/**
 * Çeviri sil
 */
function deleteTranslation($langCode, $key) {
    global $db;
    try {
        $stmt = $db->prepare("DELETE FROM translations WHERE lang_code = ? AND translation_key = ?");
        return $stmt->execute([$langCode, $key]);
    } catch (Exception $e) {
        return false;
    }
}

/**
 * Tüm çeviri anahtarlarını getir
 */
function getAllTranslationKeys() {
    global $db;
    try {
        $stmt = $db->query("SELECT DISTINCT translation_key FROM translations ORDER BY translation_key");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Bir dildeki tüm çevirileri getir
 */
function getTranslationsByLanguage($langCode) {
    global $db;
    try {
        $stmt = $db->prepare("SELECT translation_key, translation_value FROM translations WHERE lang_code = ? ORDER BY translation_key");
        $stmt->execute([$langCode]);
        $result = [];
        while ($row = $stmt->fetch()) {
            $result[$row['translation_key']] = $row['translation_value'];
        }
        return $result;
    } catch (Exception $e) {
        return [];
    }
}

// Admin paneli kontrolü
$isAdminPanel = strpos($_SERVER['REQUEST_URI'], '/admin/') !== false;

// Dil değiştirme isteğini işle - Admin panelinde yönlendirme yapma
if (isset($_GET['lang']) && !$isAdminPanel) {
    setLanguage($_GET['lang']);
    $redirectUrl = (string)strtok($_SERVER['REQUEST_URI'] ?? '/', '?');
    // Yalnız aynı site içindeki mutlak path'e yönlendir; //host biçimindeki scheme-relative açık yönlendirmeyi engelle.
    if ($redirectUrl === '' || $redirectUrl[0] !== '/' || str_starts_with($redirectUrl, '//')) {
        $redirectUrl = '/';
    }
    $params = $_GET;
    unset($params['lang']);
    if (!empty($params)) {
        $redirectUrl .= '?' . http_build_query($params);
    }
    header('Location: ' . $redirectUrl);
    exit;
}

// Aktif dil kodu
$currentLang = getCurrentLanguage();

// ==================== TEMA FONKSİYONLARI ====================

function getActiveTheme() {
    global $db;
    try {
        $activeThemeName = getSetting('active_theme', 'dark');
        $stmt = $db->prepare("SELECT * FROM theme_settings WHERE theme_name = ?");
        $stmt->execute([$activeThemeName]);
        $theme = $stmt->fetch();
        
        if (!$theme) {
            $stmt = $db->prepare("SELECT * FROM theme_settings WHERE theme_name = 'dark'");
            $stmt->execute();
            $theme = $stmt->fetch();
        }
        
        return $theme ?: getDefaultThemeColors();
    } catch (PDOException $e) {
        return getDefaultThemeColors();
    }
}

function getAllThemes() {
    global $db;
    try {
        $stmt = $db->query("SELECT * FROM theme_settings ORDER BY theme_name");
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        return [];
    }
}

function resetThemeToDefault($themeName) {
    global $db;
    try {
        $stmt = $db->prepare("SELECT * FROM theme_defaults WHERE theme_name = ?");
        $stmt->execute([$themeName]);
        $defaults = $stmt->fetch();
        
        if ($defaults) {
            $sql = "UPDATE theme_settings SET 
                    primary_color = ?, secondary_color = ?, background_color = ?, 
                    text_color = ?, button_color = ?, button_hover_color = ?, 
                    button_text_color = ?, header_bg_color = ?, footer_bg_color = ?,
                    sidebar_bg_color = ?, card_bg_color = ?, border_color = ?
                    WHERE theme_name = ?";
            
            $stmt = $db->prepare($sql);
            return $stmt->execute([
                $defaults['primary_color'], $defaults['secondary_color'], $defaults['background_color'],
                $defaults['text_color'], $defaults['button_color'], $defaults['button_hover_color'],
                $defaults['button_text_color'], $defaults['header_bg_color'], $defaults['footer_bg_color'],
                $defaults['sidebar_bg_color'], $defaults['card_bg_color'], $defaults['border_color'],
                $themeName
            ]);
        }
        return false;
    } catch (PDOException $e) {
        return false;
    }
}

function setActiveTheme($themeName) {
    return updateSetting('active_theme', $themeName);
}

function getDefaultThemeColors() {
    return [
        'theme_name' => 'dark',
        'primary_color' => '#6c5ce7',
        'secondary_color' => '#a29bfe',
        'background_color' => '#1a1a2e',
        'text_color' => '#ffffff',
        'button_color' => '#6c5ce7',
        'button_hover_color' => '#5b4cdb',
        'button_text_color' => '#ffffff',
        'header_bg_color' => '#16213e',
        'footer_bg_color' => '#0f0f1a',
        'sidebar_bg_color' => '#16213e',
        'card_bg_color' => '#1f1f3d',
        'border_color' => '#2d2d5a',
        'success_color' => '#00b894',
        'danger_color' => '#d63031',
        'warning_color' => '#fdcb6e',
        'info_color' => '#0984e3',
        'font_family' => 'inter',
        'heading_font_family' => 'inter',
        'input_bg_color' => '#17172f',
        'input_border_color' => '#373763',
        'secondary_button_bg_color' => '#2a2a4a',
        'secondary_button_hover_color' => '#34345a',
        'wallet_button_color' => '#117a57',
        'wallet_button_hover_color' => '#0f7654',
        'wallet_button_text_color' => '#ffffff'
    ];
}

function moniNormalizeHexColor($value, $fallback = '#000000') {
    $value = trim((string)$value);
    if (preg_match('/^#([0-9a-fA-F]{3})$/', $value, $m)) {
        return '#' . strtolower($m[1][0] . $m[1][0] . $m[1][1] . $m[1][1] . $m[1][2] . $m[1][2]);
    }
    if (preg_match('/^#([0-9a-fA-F]{6})$/', $value, $m)) {
        return '#' . strtolower($m[1]);
    }
    return $fallback;
}

function moniHexToRgb($hex) {
    $hex = ltrim(moniNormalizeHexColor($hex), '#');
    return [hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2))];
}

function moniRgbToHex($r, $g, $b) {
    return sprintf('#%02x%02x%02x', max(0, min(255, (int)round($r))), max(0, min(255, (int)round($g))), max(0, min(255, (int)round($b))));
}

function moniMixHexColors($first, $second, $secondWeight = 0.5) {
    $a = moniHexToRgb($first);
    $b = moniHexToRgb($second);
    $w = max(0, min(1, (float)$secondWeight));
    return moniRgbToHex(
        $a[0] * (1 - $w) + $b[0] * $w,
        $a[1] * (1 - $w) + $b[1] * $w,
        $a[2] * (1 - $w) + $b[2] * $w
    );
}

function moniRelativeLuminance($hex) {
    $rgb = moniHexToRgb($hex);
    $parts = [];
    foreach ($rgb as $channel) {
        $v = $channel / 255;
        $parts[] = $v <= 0.04045 ? ($v / 12.92) : pow(($v + 0.055) / 1.055, 2.4);
    }
    return 0.2126 * $parts[0] + 0.7152 * $parts[1] + 0.0722 * $parts[2];
}

function moniContrastRatio($foreground, $background) {
    $l1 = moniRelativeLuminance($foreground);
    $l2 = moniRelativeLuminance($background);
    $lighter = max($l1, $l2);
    $darker = min($l1, $l2);
    return ($lighter + 0.05) / ($darker + 0.05);
}

function moniBestContrastText($background, $preferred = null, $minimum = 4.5) {
    $background = moniNormalizeHexColor($background, '#ffffff');
    if ($preferred !== null) {
        $preferred = moniNormalizeHexColor($preferred, '#111827');
        if (moniContrastRatio($preferred, $background) >= $minimum) {
            return $preferred;
        }
    }
    $light = '#ffffff';
    $dark = '#111827';
    return moniContrastRatio($light, $background) >= moniContrastRatio($dark, $background) ? $light : $dark;
}

function moniHexRgba($hex, $alpha) {
    $rgb = moniHexToRgb($hex);
    $alpha = max(0, min(1, (float)$alpha));
    return 'rgba(' . $rgb[0] . ', ' . $rgb[1] . ', ' . $rgb[2] . ', ' . rtrim(rtrim(number_format($alpha, 3, '.', ''), '0'), '.') . ')';
}

/**
 * Bir arka plan rengini, seçili metin rengiyle WCAG kontrastını koruyacak
 * en yakın tona taşır. Tema rengi tamamen değiştirilmez; yalnız okunabilirlik
 * için gerektiği kadar açıklaştırılır/koyulaştırılır.
 */
function moniEnsureBackgroundContrast($background, $text, $minimum = 4.5) {
    $background = moniNormalizeHexColor($background, '#6c5ce7');
    $text = moniNormalizeHexColor($text, '#ffffff');
    if (moniContrastRatio($text, $background) >= $minimum) {
        return $background;
    }

    // Açık metin için zemini koyulaştır, koyu metin için zemini aç.
    $target = moniRelativeLuminance($text) > 0.5 ? '#000000' : '#ffffff';
    for ($i = 1; $i <= 40; $i++) {
        $candidate = moniMixHexColors($background, $target, $i / 40);
        if (moniContrastRatio($text, $candidate) >= $minimum) {
            return $candidate;
        }
    }
    return $target;
}

function moniReadableColorOnSurfaces($foreground, array $surfaces, $minimum = 4.5) {
    $foreground = moniNormalizeHexColor($foreground, '#6c5ce7');
    $surfaces = array_map(function ($surface) { return moniNormalizeHexColor($surface, '#ffffff'); }, $surfaces);
    $passes = function ($candidate) use ($surfaces, $minimum) {
        foreach ($surfaces as $surface) {
            if (moniContrastRatio($candidate, $surface) < $minimum) {
                return false;
            }
        }
        return true;
    };
    if ($passes($foreground)) {
        return $foreground;
    }
    $black = '#111827';
    $white = '#ffffff';
    $blackScore = min(array_map(function ($surface) use ($black) { return moniContrastRatio($black, $surface); }, $surfaces));
    $whiteScore = min(array_map(function ($surface) use ($white) { return moniContrastRatio($white, $surface); }, $surfaces));
    $target = $blackScore >= $whiteScore ? $black : $white;
    for ($i = 1; $i <= 20; $i++) {
        $candidate = moniMixHexColors($foreground, $target, $i / 20);
        if ($passes($candidate)) {
            return $candidate;
        }
    }
    return $blackScore >= $whiteScore ? $black : $white;
}

function moniThemeFontStack($preset = 'inter') {
    $preset = strtolower(trim((string)$preset));
    $fonts = [
        'inter' => "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
        'system' => "-apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif",
        'trebuchet' => "'Trebuchet MS', 'Segoe UI', Arial, sans-serif",
        'georgia' => "Georgia, 'Times New Roman', serif",
        'mono' => "'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace",
    ];
    return $fonts[$preset] ?? $fonts['inter'];
}

function generateCSSVariables($theme = null) {
    if ($theme === null) {
        $theme = getActiveTheme();
    }

    $primary = moniNormalizeHexColor($theme['primary_color'] ?? '#6c5ce7', '#6c5ce7');
    $secondary = moniNormalizeHexColor($theme['secondary_color'] ?? '#a29bfe', '#a29bfe');
    $background = moniNormalizeHexColor($theme['background_color'] ?? '#1a1a2e', '#1a1a2e');
    $configuredText = moniNormalizeHexColor($theme['text_color'] ?? '#ffffff', '#ffffff');
    $button = moniNormalizeHexColor($theme['button_color'] ?? $primary, $primary);
    $buttonHover = moniNormalizeHexColor($theme['button_hover_color'] ?? $primary, $primary);
    $configuredButtonText = moniNormalizeHexColor($theme['button_text_color'] ?? '#ffffff', '#ffffff');
    $header = moniNormalizeHexColor($theme['header_bg_color'] ?? '#16213e', '#16213e');
    $footer = moniNormalizeHexColor($theme['footer_bg_color'] ?? '#0f0f1a', '#0f0f1a');
    $sidebar = moniNormalizeHexColor($theme['sidebar_bg_color'] ?? $header, $header);
    $card = moniNormalizeHexColor($theme['card_bg_color'] ?? '#1f1f3d', '#1f1f3d');
    $border = moniNormalizeHexColor($theme['border_color'] ?? '#2d2d5a', '#2d2d5a');
    $success = moniNormalizeHexColor($theme['success_color'] ?? '#28a745', '#28a745');
    $danger = moniNormalizeHexColor($theme['danger_color'] ?? '#dc3545', '#dc3545');
    $warning = moniNormalizeHexColor($theme['warning_color'] ?? '#ffc107', '#ffc107');
    $info = moniNormalizeHexColor($theme['info_color'] ?? '#17a2b8', '#17a2b8');
    $fontFamily = moniThemeFontStack($theme['font_family'] ?? 'inter');
    $headingFontFamily = moniThemeFontStack($theme['heading_font_family'] ?? ($theme['font_family'] ?? 'inter'));
    $inputBgConfigured = moniNormalizeHexColor($theme['input_bg_color'] ?? moniMixHexColors($card, $background, 0.58), moniMixHexColors($card, $background, 0.58));
    $inputBorder = moniNormalizeHexColor($theme['input_border_color'] ?? $border, $border);
    $secondaryButtonBg = moniNormalizeHexColor($theme['secondary_button_bg_color'] ?? moniMixHexColors($card,$background,0.32), moniMixHexColors($card,$background,0.32));
    $secondaryButtonHover = moniNormalizeHexColor($theme['secondary_button_hover_color'] ?? moniMixHexColors($secondaryButtonBg,$primary,0.16), moniMixHexColors($secondaryButtonBg,$primary,0.16));
    $walletButton = moniNormalizeHexColor($theme['wallet_button_color'] ?? $success, $success);
    $walletButtonHover = moniNormalizeHexColor($theme['wallet_button_hover_color'] ?? moniMixHexColors($walletButton,'#000000',0.14), $walletButton);
    $walletButtonTextConfigured = moniNormalizeHexColor($theme['wallet_button_text_color'] ?? '#ffffff', '#ffffff');
    $walletButtonText = moniBestContrastText($walletButton, $walletButtonTextConfigured, 4.5);

    // Kullanıcı tema renklerini koru; yalnız okunamayacak kombinasyonlarda kontrastı güvenli değere yükselt.
    $bodyText = moniBestContrastText($background, $configuredText, 4.5);
    $cardText = moniBestContrastText($card, $configuredText, 4.5);
    $headerText = moniBestContrastText($header, $configuredText, 4.5);
    $footerText = moniBestContrastText($footer, $configuredText, 4.5);
    $sidebarText = moniBestContrastText($sidebar, $configuredText, 4.5);
    $buttonText = moniBestContrastText($button, $configuredButtonText, 4.5);

    $accentMid = moniMixHexColors($primary, $secondary, 0.5);
    $colorScheme = moniRelativeLuminance($background) < 0.32 ? 'dark' : 'light';

    // Hero metni ve gradienti bütün temalarda okunabilir kalmalı.
    $heroText = moniBestContrastText($accentMid, null, 4.5);
    $heroStart = moniEnsureBackgroundContrast($primary, $heroText, 4.8);
    $heroEnd = moniEnsureBackgroundContrast($secondary, $heroText, 4.8);
    $heroMid = moniMixHexColors($heroStart, $heroEnd, 0.5);
    $heroActionBg = $heroText;
    $heroActionText = moniBestContrastText($heroActionBg, null, 4.5);

    $mutedText = moniMixHexColors($bodyText, $background, 0.34);
    $cardMutedText = moniMixHexColors($cardText, $card, 0.34);
    $headerMutedText = moniMixHexColors($headerText, $header, 0.26);
    $footerMutedText = moniMixHexColors($footerText, $footer, 0.28);
    $sidebarMutedText = moniMixHexColors($sidebarText, $sidebar, 0.34);
    $surfaceAlt = moniMixHexColors($card, $background, 0.42);
    $inputBg = $inputBgConfigured;
    $accentText = moniReadableColorOnSurfaces($primary, [$background, $card], 4.5);
    $secondaryText = moniReadableColorOnSurfaces($secondary, [$background, $card], 4.5);
    $headerAccent = moniReadableColorOnSurfaces($primary, [$header], 3.0);
    $footerAccent = moniReadableColorOnSurfaces($primary, [$footer], 4.5);
    $sidebarAccent = moniReadableColorOnSurfaces($primary, [$sidebar], 4.5);

    $onPrimary = moniBestContrastText($primary);
    $onSecondary = moniBestContrastText($secondary);
    $onAccent = moniBestContrastText($accentMid);
    $onSuccess = moniBestContrastText($success);
    $onDanger = moniBestContrastText($danger);
    $onWarning = moniBestContrastText($warning);
    $onInfo = moniBestContrastText($info);
    $accentActionBg = $onAccent;
    $accentActionText = moniBestContrastText($accentActionBg, null, 4.5);

    return ":root {\n" .
        "    color-scheme: {$colorScheme};\n" .
        "    --theme-font-family: {$fontFamily};\n" .
        "    --theme-heading-font-family: {$headingFontFamily};\n" .
        "    --primary-color: {$primary};\n" .
        "    --secondary-color: {$secondary};\n" .
        "    --background-color: {$background};\n" .
        "    --text-color: {$bodyText};\n" .
        "    --configured-text-color: {$configuredText};\n" .
        "    --accent-text-color: {$accentText};\n" .
        "    --secondary-text-color: {$secondaryText};\n" .
        "    --muted-text-color: {$mutedText};\n" .
        "    --muted-color: {$mutedText};\n" .
        "    --text-dim: {$mutedText};\n" .
        "    --text-strong: {$bodyText};\n" .
        "    --card-text-color: {$cardText};\n" .
        "    --card-muted-text-color: {$cardMutedText};\n" .
        "    --button-color: {$button};\n" .
        "    --button-hover-color: {$buttonHover};\n" .
        "    --button-text-color: {$buttonText};\n" .
        "    --header-bg-color: {$header};\n" .
        "    --header-text-color: {$headerText};\n" .
        "    --header-muted-text-color: {$headerMutedText};\n" .
        "    --header-accent-color: {$headerAccent};\n" .
        "    --header-hover-bg: " . moniHexRgba($headerText, 0.10) . ";\n" .
        "    --header-border-color: " . moniHexRgba($headerText, 0.16) . ";\n" .
        "    --footer-bg-color: {$footer};\n" .
        "    --footer-text-color: {$footerText};\n" .
        "    --footer-muted-text-color: {$footerMutedText};\n" .
        "    --footer-accent-color: {$footerAccent};\n" .
        "    --footer-hover-bg: " . moniHexRgba($footerText, 0.10) . ";\n" .
        "    --footer-border-color: " . moniHexRgba($footerText, 0.14) . ";\n" .
        "    --sidebar-bg-color: {$sidebar};\n" .
        "    --sidebar-text-color: {$sidebarText};\n" .
        "    --sidebar-muted-text-color: {$sidebarMutedText};\n" .
        "    --sidebar-accent-color: {$sidebarAccent};\n" .
        "    --card-bg-color: {$card};\n" .
        "    --surface-alt-color: {$surfaceAlt};\n" .
        "    --input-bg-color: {$inputBg};\n" .
        "    --input-border-color: {$inputBorder};\n" .
        "    --secondary-button-bg-color: {$secondaryButtonBg};\n" .
        "    --secondary-button-hover-color: {$secondaryButtonHover};\n" .
        "    --wallet-button-color: {$walletButton};\n" .
        "    --wallet-button-hover-color: {$walletButtonHover};\n" .
        "    --wallet-button-text-color: {$walletButtonText};\n" .
        "    --border-color: {$border};\n" .
        "    --success-color: {$success};\n" .
        "    --danger-color: {$danger};\n" .
        "    --warning-color: {$warning};\n" .
        "    --info-color: {$info};\n" .
        "    --on-primary-color: {$onPrimary};\n" .
        "    --on-secondary-color: {$onSecondary};\n" .
        "    --on-accent-color: {$onAccent};\n" .
        "    --on-accent-alpha-010: " . moniHexRgba($onAccent, 0.10) . ";\n" .
        "    --on-accent-alpha-015: " . moniHexRgba($onAccent, 0.15) . ";\n" .
        "    --on-accent-alpha-020: " . moniHexRgba($onAccent, 0.20) . ";\n" .
        "    --on-accent-alpha-030: " . moniHexRgba($onAccent, 0.30) . ";\n" .
        "    --on-success-color: {$onSuccess};\n" .
        "    --on-danger-color: {$onDanger};\n" .
        "    --on-warning-color: {$onWarning};\n" .
        "    --on-info-color: {$onInfo};\n" .
        "    --primary-soft-bg: " . moniHexRgba($primary, 0.12) . ";\n" .
        "    --primary-alpha-002: " . moniHexRgba($primary, 0.02) . ";\n" .
        "    --primary-alpha-003: " . moniHexRgba($primary, 0.03) . ";\n" .
        "    --primary-alpha-005: " . moniHexRgba($primary, 0.05) . ";\n" .
        "    --primary-alpha-008: " . moniHexRgba($primary, 0.08) . ";\n" .
        "    --primary-alpha-009: " . moniHexRgba($primary, 0.09) . ";\n" .
        "    --primary-alpha-01: " . moniHexRgba($primary, 0.1) . ";\n" .
        "    --primary-alpha-012: " . moniHexRgba($primary, 0.12) . ";\n" .
        "    --primary-alpha-013: " . moniHexRgba($primary, 0.13) . ";\n" .
        "    --primary-alpha-014: " . moniHexRgba($primary, 0.14) . ";\n" .
        "    --primary-alpha-015: " . moniHexRgba($primary, 0.15) . ";\n" .
        "    --primary-alpha-02: " . moniHexRgba($primary, 0.2) . ";\n" .
        "    --primary-alpha-025: " . moniHexRgba($primary, 0.25) . ";\n" .
        "    --primary-alpha-03: " . moniHexRgba($primary, 0.3) . ";\n" .
        "    --primary-alpha-035: " . moniHexRgba($primary, 0.35) . ";\n" .
        "    --primary-alpha-04: " . moniHexRgba($primary, 0.4) . ";\n" .
        "    --primary-soft-border: " . moniHexRgba($primary, 0.28) . ";\n" .
        "    --accent-action-bg-color: {$accentActionBg};\n" .
        "    --accent-action-text-color: {$accentActionText};\n" .
        "    --hero-bg-start: {$heroStart};\n" .
        "    --hero-bg-end: {$heroEnd};\n" .
        "    --hero-text-color: {$heroText};\n" .
        "    --hero-muted-text-color: {$heroText};\n" .
        "    --hero-action-bg-color: {$heroActionBg};\n" .
        "    --hero-action-text-color: {$heroActionText};\n" .
        "    --shadow-color: rgba(0, 0, 0, 0.18);\n" .
        "}";
}

// ==================== SERVİS FONKSİYONLARI ====================

function getCategories($status = 'active') {
    global $db;
    try {
        if ($status === 'all') {
            $stmt = $db->query("SELECT * FROM categories ORDER BY sort_order, name");
        } else {
            $stmt = $db->prepare("SELECT * FROM categories WHERE status = ? ORDER BY sort_order, name");
            $stmt->execute([$status]);
        }
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        return [];
    }
}

function getServices($status = 'active', $categoryId = null) {
    global $db;
    try {
        $sql = "SELECT s.*, c.name as category_name, c.icon as category_icon, c.icon_color as category_icon_color 
                FROM services s 
                LEFT JOIN categories c ON s.category_id = c.id";
        $params = [];
        $where = [];
        
        if ($status !== 'all') {
            $where[] = "s.status = ?";
            $params[] = $status;
        }
        
        if ($categoryId) {
            $where[] = "s.category_id = ?";
            $params[] = $categoryId;
        }
        
        if (!empty($where)) {
            $sql .= " WHERE " . implode(" AND ", $where);
        }
        
        $sql .= " ORDER BY c.sort_order, s.sort_order, s.name";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        return [];
    }
}

function getService($id) {
    global $db;
    try {
        $stmt = $db->prepare("SELECT s.*, c.name as category_name, c.icon as category_icon 
                              FROM services s 
                              LEFT JOIN categories c ON s.category_id = c.id 
                              WHERE s.id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    } catch (PDOException $e) {
        return null;
    }
}

function getHomepageServices() {
    global $db;
    try {
        $stmt = $db->query("SELECT hs.*, s.name as service_name, s.price_per_1000, s.min_quantity, 
                                   c.icon as category_icon, c.icon_color as category_icon_color,
                                   c.name as category_name
                            FROM homepage_services hs
                            LEFT JOIN services s ON hs.service_id = s.id
                            LEFT JOIN categories c ON s.category_id = c.id
                            WHERE hs.status = 'active' AND s.status = 'active'
                            ORDER BY hs.sort_order ASC");
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        return [];
    }
}

function addHomepageService($serviceId, $data = []) {
    global $db;
    try {
        $check = $db->prepare("SELECT id FROM homepage_services WHERE service_id = ?");
        $check->execute([$serviceId]);
        if ($check->fetch()) {
            return false;
        }
        
        $lastOrder = $db->query("SELECT MAX(sort_order) as max_order FROM homepage_services")->fetch();
        $sortOrder = ($lastOrder['max_order'] ?? 0) + 1;
        
        $stmt = $db->prepare("INSERT INTO homepage_services 
                              (service_id, custom_title, custom_description, custom_icon, custom_icon_style, badge_text, badge_color, sort_order, status) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')");
        
        return $stmt->execute([
            $serviceId,
            $data['custom_title'] ?? null,
            $data['custom_description'] ?? null,
            $data['custom_icon'] ?? null,
            $data['custom_icon_style'] ?? null,
            $data['badge_text'] ?? null,
            $data['badge_color'] ?? '#ff6b6b',
            $sortOrder
        ]);
    } catch (PDOException $e) {
        return false;
    }
}

function updateHomepageService($id, $data) {
    global $db;
    try {
        $stmt = $db->prepare("UPDATE homepage_services SET 
                              custom_title = ?, custom_description = ?, custom_icon = ?, 
                              custom_icon_style = ?, badge_text = ?, badge_color = ?, 
                              sort_order = ?, status = ?
                              WHERE id = ?");
        
        return $stmt->execute([
            $data['custom_title'] ?? null,
            $data['custom_description'] ?? null,
            $data['custom_icon'] ?? null,
            $data['custom_icon_style'] ?? null,
            $data['badge_text'] ?? null,
            $data['badge_color'] ?? '#ff6b6b',
            $data['sort_order'] ?? 0,
            $data['status'] ?? 'active',
            $id
        ]);
    } catch (PDOException $e) {
        return false;
    }
}

function deleteHomepageService($id) {
    global $db;
    try {
        $stmt = $db->prepare("DELETE FROM homepage_services WHERE id = ?");
        return $stmt->execute([$id]);
    } catch (PDOException $e) {
        return false;
    }
}

function getServicesGroupedByCategory($status = 'active') {
    $categories = getCategories($status === 'all' ? 'all' : 'active');
    $grouped = [];
    
    foreach ($categories as $category) {
        $services = getServices($status, $category['id']);
        if (!empty($services) || $status === 'all') {
            $grouped[] = [
                'category' => $category,
                'services' => $services
            ];
        }
    }
    
    return $grouped;
}

// ==================== YARDIMCI FONKSİYONLAR ====================

function clean($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

function generateCSRFToken() {
    // Tek CSRF kaynağı kullan: security.php içindeki merkezi token.
    // Eski sayfalardaki csrf_token alanları ile yeni _token alanları aynı değeri taşır.
    if (function_exists('csrf_token')) {
        return csrf_token();
    }
    if (empty($_SESSION['_csrf_token'])) {
        $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf_token'];
}

function validateCSRFToken($token) {
    // Eski formlar csrf_token, merkezi koruma ise _token kullanıyordu.
    // Parametre boş geldiyse merkezi form/header tokenını da kabul et.
    if ((!is_string($token) || $token === '') && isset($_POST['_token'])) {
        $token = (string)$_POST['_token'];
    }
    if ((!is_string($token) || $token === '') && isset($_SERVER['HTTP_X_CSRF_TOKEN'])) {
        $token = (string)$_SERVER['HTTP_X_CSRF_TOKEN'];
    }
    if (function_exists('csrf_check')) {
        return csrf_check($token);
    }
    return isset($_SESSION['_csrf_token']) && is_string($token) && $token !== '' && hash_equals($_SESSION['_csrf_token'], $token);
}

function setAlert($message, $type = 'success') {
    // Eski sayfalarda setAlert('Mesaj', 'success') şeklinde ters kullanımlar vardı.
    // Her iki imzayı da güvenli biçimde destekle.
    $knownTypes = ['success','danger','warning','info','primary','secondary'];
    if (in_array((string)$message, $knownTypes, true) && !in_array((string)$type, $knownTypes, true)) {
        [$message, $type] = [$type, $message];
    }
    $_SESSION['alert'] = [
        'type' => in_array((string)$type, $knownTypes, true) ? $type : 'info',
        'message' => (string)$message
    ];
}

function showAlert() {
    if (isset($_SESSION['alert'])) {
        $alert = $_SESSION['alert'];
        unset($_SESSION['alert']);
        return '<div class="alert alert-' . $alert['type'] . ' alert-dismissible fade show">
                    ' . $alert['message'] . '
                    <button type="button" class="close-alert">&times;</button>
                </div>';
    }
    return '';
}

function isAdmin() {
    return isset($_SESSION['user_id']) && isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function formatPrice($price) {
    global $siteSettings;
    return ($siteSettings['currency_symbol'] ?? '₺') . number_format($price, 2);
}

// ==================== E-POSTA FONKSİYONLARI ====================

/**
 * E-posta Gönderme Ana Fonksiyonu
 */
function sendEmail($to, $subject, $body) {
    global $db, $siteSettings;
    $subject = preg_replace('/[\r\n]+/', ' ', (string)$subject);
    
    $smtpSettings = [];
    // Child Panel özel SMTP'si yalnız admin izni + aktif panel ayarı varsa kullanılır.
    $childSmtp = function_exists('moni_child_panel_smtp_settings') ? moni_child_panel_smtp_settings($db) : null;
    if (is_array($childSmtp)) {
        $smtpSettings = [
            'smtp_host'=>(string)($childSmtp['smtp_host']??''),'smtp_port'=>(int)($childSmtp['smtp_port']??587),
            'smtp_username'=>(string)($childSmtp['smtp_username']??''),'smtp_password'=>(string)($childSmtp['smtp_password']??''),
            'smtp_encryption'=>(string)($childSmtp['smtp_encryption']??'tls'),'smtp_from_email'=>(string)($childSmtp['from_email']??''),
            'smtp_from_name'=>(string)($childSmtp['from_name']??($siteSettings['name']??'Site'))
        ];
    }
    try {
        if (!$smtpSettings) {
        $stmt = $db->query("SELECT setting_key, setting_value FROM settings WHERE setting_key LIKE 'smtp_%'");
        while ($row = $stmt->fetch()) {
            $smtpSettings[$row['setting_key']] = $row['setting_value'];
        }
        }
    } catch (Exception $e) {
        error_log('SMTP Settings Error: ' . $e->getMessage());
    }
    
    $fromName = preg_replace('/[\r\n]+/', ' ', (string)($smtpSettings['smtp_from_name'] ?? $siteSettings['name'] ?? 'Site'));
    $canonicalMailHost=(function_exists('moni_canonical_site_url')?parse_url(moni_canonical_site_url(),PHP_URL_HOST):null) ?: 'localhost';
    $fromEmail = str_replace(["\r","\n"], '', (string)($smtpSettings['smtp_from_email'] ?? $smtpSettings['smtp_username'] ?? 'noreply@' . $canonicalMailHost));
    
    if (empty($smtpSettings['smtp_host']) || empty($smtpSettings['smtp_username']) || empty($smtpSettings['smtp_password'])) {
        return sendEmailBasic($to, $subject, $body, $fromName, $fromEmail);
    }
    
    return sendEmailViaSMTP(
        $smtpSettings['smtp_host'],
        (int)($smtpSettings['smtp_port'] ?? 587),
        $smtpSettings['smtp_username'],
        str_starts_with((string)$smtpSettings['smtp_password'],'enc:v1:') ? moni_decrypt_secret($smtpSettings['smtp_password']) : (string)$smtpSettings['smtp_password'],
        $fromEmail,
        $fromName,
        $to,
        $subject,
        $body,
        $smtpSettings['smtp_encryption'] ?? 'tls'
    );
}

/**
 * Basit mail() Fonksiyonu ile Gönderim
 */
function sendEmailBasic($to, $subject, $body, $fromName = 'Site', $fromEmail = null) {
    if (!$fromEmail) {
        $mailHost=(function_exists('moni_canonical_site_url')?parse_url(moni_canonical_site_url(),PHP_URL_HOST):null) ?: 'localhost';
        $fromEmail = 'noreply@' . $mailHost;
    }
    
    $headers = [];
    $headers[] = "MIME-Version: 1.0";
    $headers[] = "Content-type: text/html; charset=UTF-8";
    $headers[] = "From: {$fromName} <{$fromEmail}>";
    $headers[] = "Reply-To: {$fromEmail}";
    $headers[] = "X-Mailer: PHP/" . phpversion();
    
    return @mail($to, $subject, $body, implode("\r\n", $headers));
}

/**
 * SMTP Yanıtını Oku
 */
function smtpGetResponse($socket) {
    $response = '';
    while ($line = @fgets($socket, 515)) {
        $response .= $line;
        if (substr($line, 3, 1) == ' ') {
            break;
        }
    }
    return trim($response);
}

/**
 * SMTP Socket ile E-posta Gönderme
 */
function sendEmailViaSMTP($host, $port, $username, $password, $fromEmail, $fromName, $to, $subject, $body, $encryption = 'tls') {
    try {
        $secure = ($encryption === 'ssl') ? 'ssl://' : '';
        
        $socket = @fsockopen($secure . $host, $port, $errno, $errstr, 30);
        
        if (!$socket) {
            error_log("SMTP Connection Error: $errstr ($errno)");
            return false;
        }
        
        stream_set_timeout($socket, 30);
        
        $response = smtpGetResponse($socket);
        if (substr($response, 0, 3) != '220') {
            fclose($socket);
            error_log("SMTP Error: Bad greeting - $response");
            return false;
        }
        
        $hostname=(function_exists('moni_canonical_site_url')?parse_url(moni_canonical_site_url(),PHP_URL_HOST):null) ?: 'localhost';
        fputs($socket, "EHLO {$hostname}\r\n");
        $response = smtpGetResponse($socket);
        
        if ($encryption === 'tls') {
            fputs($socket, "STARTTLS\r\n");
            $response = smtpGetResponse($socket);
            
            if (substr($response, 0, 3) != '220') {
                fclose($socket);
                error_log("SMTP Error: STARTTLS failed - $response");
                return false;
            }
            
            $crypto = @stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT);
            if (!$crypto) {
                $crypto = @stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            }
            
            if (!$crypto) {
                fclose($socket);
                error_log("SMTP Error: TLS negotiation failed");
                return false;
            }
            
            fputs($socket, "EHLO {$hostname}\r\n");
            $response = smtpGetResponse($socket);
        }
        
        fputs($socket, "AUTH LOGIN\r\n");
        $response = smtpGetResponse($socket);
        
        if (substr($response, 0, 3) != '334') {
            fclose($socket);
            error_log("SMTP Error: AUTH not supported - $response");
            return false;
        }
        
        fputs($socket, base64_encode($username) . "\r\n");
        $response = smtpGetResponse($socket);
        
        if (substr($response, 0, 3) != '334') {
            fclose($socket);
            error_log("SMTP Error: Username rejected - $response");
            return false;
        }
        
        fputs($socket, base64_encode($password) . "\r\n");
        $response = smtpGetResponse($socket);
        
        if (substr($response, 0, 3) != '235') {
            fclose($socket);
            error_log("SMTP Error: Auth failed - $response");
            return false;
        }
        
        fputs($socket, "MAIL FROM: <{$fromEmail}>\r\n");
        $response = smtpGetResponse($socket);
        
        if (substr($response, 0, 3) != '250') {
            fclose($socket);
            error_log("SMTP Error: MAIL FROM rejected - $response");
            return false;
        }
        
        fputs($socket, "RCPT TO: <{$to}>\r\n");
        $response = smtpGetResponse($socket);
        
        if (substr($response, 0, 3) != '250' && substr($response, 0, 3) != '251') {
            fclose($socket);
            error_log("SMTP Error: RCPT TO rejected - $response");
            return false;
        }
        
        fputs($socket, "DATA\r\n");
        $response = smtpGetResponse($socket);
        
        if (substr($response, 0, 3) != '354') {
            fclose($socket);
            error_log("SMTP Error: DATA rejected - $response");
            return false;
        }
        
        $message = "Date: " . date('r') . "\r\n";
        $message .= "From: =?UTF-8?B?" . base64_encode($fromName) . "?= <{$fromEmail}>\r\n";
        $message .= "To: {$to}\r\n";
        $message .= "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n";
        $message .= "MIME-Version: 1.0\r\n";
        $message .= "Content-Type: text/html; charset=UTF-8\r\n";
        $message .= "Content-Transfer-Encoding: base64\r\n";
        $message .= "\r\n";
        $message .= chunk_split(base64_encode($body));
        
        fputs($socket, $message . "\r\n.\r\n");
        $response = smtpGetResponse($socket);
        
        fputs($socket, "QUIT\r\n");
        fclose($socket);
        
        if (substr($response, 0, 3) != '250') {
            error_log("SMTP Error: Message rejected - $response");
            return false;
        }
        
        return true;
        
    } catch (Exception $e) {
        error_log("SMTP Exception: " . $e->getMessage());
        if (isset($socket) && is_resource($socket)) {
            fclose($socket);
        }
        return false;
    }
}

// v2 çekirdek + güvenli yükseltme uyumluluk katmanı
require_once __DIR__ . '/includes/MoniV2Compat.php';
if (function_exists('moni_admin_request_guard')) { moni_admin_request_guard($db); }

// ==================== GLOBAL DEĞİŞKENLER ====================

$siteSettings = [
    'name' => getSetting('site_name', 'SMM Panel'),
    'logo' => getSetting('site_logo', ''),
    'favicon' => getSetting('site_favicon', ''),
    'description' => getSetting('site_description', 'En iyi SMM Panel'),
    'email' => getSetting('contact_email', ''),
    'phone' => getSetting('contact_phone', ''),
    'currency' => getSetting('currency', 'TRY'),
    'currency_symbol' => getSetting('currency_symbol', '₺'),
    'homepage_services_title' => getSetting('homepage_services_title', 'Popüler Hizmetlerimiz'),
    'homepage_services_subtitle' => getSetting('homepage_services_subtitle', 'En çok tercih edilen sosyal medya hizmetlerimiz'),
    'maintenance_mode' => getSetting('maintenance_mode', '0'),
    'maintenance_message' => getSetting('maintenance_message', ''),
    'maintenance_end_time' => getSetting('maintenance_end_time', ''),
    'maintenance_allowed_ips' => getSetting('maintenance_allowed_ips', '')
];

if (function_exists('moni_apply_child_panel_branding')) { moni_apply_child_panel_branding($db, $siteSettings); }
if(function_exists('moni_child_panel_context')&&function_exists('moni_partial_maintenance_active')&&moni_child_panel_context($db)&&moni_partial_maintenance_active($db,'child_panels')){moni_partial_maintenance_guard($db,'child_panels',false);}
$activeTheme = getActiveTheme();

// ==================== BAKIM MODU KONTROLÜ ====================

/**
 * Bakım Modu Kontrolü
 */
function checkMaintenanceMode() {
    global $siteSettings;
    
    // Bakım modu kapalıysa çık
    if ($siteSettings['maintenance_mode'] !== '1') {
        return false;
    }
    
    $requestUri = $_SERVER['REQUEST_URI'] ?? '';
    
    // Admin paneli her zaman erişilebilir
    if (strpos($requestUri, '/admin') !== false) {
        return false;
    }
    
    // Bakım sayfası zaten açıksa döngüye girme
    if (strpos($requestUri, 'bakimmodu.php') !== false) {
        return false;
    }
    
    // Login sayfası erişilebilir (admin girişi için)
    if (strpos($requestUri, 'login.php') !== false) {
        return false;
    }
    
    // Logout erişilebilir
    if (strpos($requestUri, 'logout.php') !== false) {
        return false;
    }
    
    // Admin kullanıcıları bakım modundan etkilenmez
    if (isAdmin()) {
        return false;
    }
    
    // IP kontrolü
    $userIp = function_exists('moni_client_ip') ? moni_client_ip() : (string)($_SERVER['REMOTE_ADDR'] ?? '');
    $allowedIps = $siteSettings['maintenance_allowed_ips'] ?? '';
    
    if (!empty($allowedIps)) {
        $ipList = array_map('trim', explode(',', $allowedIps));
        if (in_array($userIp, $ipList)) {
            return false;
        }
    }
    
    // Bakım moduna yönlendir
    return true;
}

// Bakım modu aktifse yönlendir
if (checkMaintenanceMode()) {
    header('Location: /bakimmodu.php');
    exit;
}
?>