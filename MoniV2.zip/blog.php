<?php
/**
 * Blog - Tüm Yazılar
 */

require_once 'config.php';

// Sayfalama
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = 9;
$offset = ($page - 1) * $perPage;

// Toplam yazı sayısı
$totalPosts = $db->query("SELECT COUNT(*) FROM blog_posts WHERE is_active = 1")->fetchColumn();
$totalPages = ceil($totalPosts / $perPage);

// Blog yazılarını getir
$stmt = $db->prepare("SELECT id, title, slug, excerpt, content, featured_image, view_count, created_at FROM blog_posts WHERE is_active = 1 ORDER BY created_at DESC LIMIT ? OFFSET ?");
$stmt->bindValue(1, $perPage, PDO::PARAM_INT);
$stmt->bindValue(2, $offset, PDO::PARAM_INT);
$stmt->execute();
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "Blog";
require_once 'includes/header.php';
?>

<style>
.blog-page {
    padding: 60px 20px;
    background: var(--background-color);
    min-height: 70vh;
}

.blog-container {
    max-width: 1200px;
    margin: 0 auto;
}

.blog-page-header {
    text-align: center;
    margin-bottom: 50px;
}

.blog-page-header h1 {
    font-size: 2.5rem;
    font-weight: 700;
    color: var(--text-color);
    margin-bottom: 15px;
}

.blog-page-header p {
    font-size: 1.1rem;
    color: var(--text-color);
    opacity: 0.7;
    max-width: 600px;
    margin: 0 auto;
}

.blog-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 25px;
    margin-bottom: 50px;
}

.blog-card {
    background: var(--card-bg-color);
    border-radius: 16px;
    overflow: hidden;
    border: 1px solid var(--border-color);
    transition: all 0.3s ease;
    display: flex;
    flex-direction: column;
}

.blog-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
}

.blog-card-image {
    position: relative;
    width: 100%;
    height: 200px;
    overflow: hidden;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    display: block;
    flex-shrink: 0;
}

.blog-card-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.blog-card:hover .blog-card-image img {
    transform: scale(1.05);
}

.blog-card-image-placeholder {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: rgba(255, 255, 255, 0.5);
    font-size: 3rem;
}

.blog-card-body {
    padding: 25px;
    flex: 1;
    display: flex;
    flex-direction: column;
}

.blog-card-meta {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 12px;
    font-size: 0.8rem;
    color: var(--text-color);
    opacity: 0.6;
}

.blog-card-meta span {
    display: flex;
    align-items: center;
    gap: 5px;
}

.blog-card-title {
    font-size: 1.15rem;
    font-weight: 600;
    color: var(--text-color);
    margin-bottom: 12px;
    line-height: 1.4;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.blog-card-title a {
    color: inherit;
    text-decoration: none;
    transition: color 0.3s ease;
}

.blog-card-title a:hover {
    color: var(--accent-text-color);
}

.blog-card-excerpt {
    font-size: 0.9rem;
    color: var(--text-color);
    opacity: 0.7;
    line-height: 1.7;
    margin-bottom: 20px;
    flex: 1;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.blog-card-footer {
    margin-top: auto;
}

.blog-read-more {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    color: var(--accent-text-color);
    text-decoration: none;
    font-weight: 600;
    font-size: 0.9rem;
    transition: all 0.3s ease;
}

.blog-read-more:hover {
    gap: 12px;
}

.blog-read-more i {
    transition: transform 0.3s ease;
}

.blog-read-more:hover i {
    transform: translateX(3px);
}

/* Pagination */
.pagination {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
}

.pagination a,
.pagination span {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 42px;
    height: 42px;
    padding: 0 12px;
    border-radius: 10px;
    font-weight: 500;
    font-size: 0.9rem;
    text-decoration: none;
    transition: all 0.3s ease;
}

.pagination a {
    background: var(--card-bg-color);
    color: var(--text-color);
    border: 1px solid var(--border-color);
}

.pagination a:hover {
    background: var(--primary-color);
    color: var(--on-primary-color);
    border-color: var(--accent-text-color);
}

.pagination .current {
    background: var(--primary-color);
    color: var(--on-primary-color);
}

.pagination .disabled {
    opacity: 0.4;
    pointer-events: none;
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
}

/* Empty State */
.blog-empty {
    text-align: center;
    padding: 80px 20px;
    color: var(--text-color);
}

.blog-empty i {
    font-size: 5rem;
    opacity: 0.2;
    margin-bottom: 25px;
}

.blog-empty h2 {
    font-size: 1.5rem;
    margin-bottom: 10px;
    opacity: 0.8;
}

.blog-empty p {
    opacity: 0.6;
}

/* Responsive */
@media (max-width: 1100px) {
    .blog-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 768px) {
    .blog-page {
        padding: 40px 15px;
    }
    
    .blog-page-header h1 {
        font-size: 2rem;
    }
    
    .blog-page-header {
        margin-bottom: 35px;
    }
}

@media (max-width: 600px) {
    .blog-grid {
        grid-template-columns: 1fr;
        max-width: 450px;
        margin-left: auto;
        margin-right: auto;
    }
    
    .blog-page-header h1 {
        font-size: 1.7rem;
    }
    
    .blog-card-body {
        padding: 20px;
    }
}
</style>

<section class="blog-page">
    <div class="blog-container">
        <div class="blog-page-header">
            <h1><i class="fas fa-blog"></i> Blog</h1>
            <p>En son haberler, ipuçları ve güncellemeler</p>
        </div>
        
        <?php if (!empty($posts)): ?>
            <div class="blog-grid">
                <?php foreach ($posts as $post): ?>
                    <article class="blog-card">
                        <a href="<?php echo SITE_URL; ?>/blog/<?php echo clean($post['slug']); ?>" class="blog-card-image">
                            <?php if ($post['featured_image']): ?>
                                <img src="<?php echo clean($post['featured_image']); ?>" alt="<?php echo clean($post['title']); ?>">
                            <?php else: ?>
                                <div class="blog-card-image-placeholder">
                                    <i class="fas fa-newspaper"></i>
                                </div>
                            <?php endif; ?>
                        </a>
                        <div class="blog-card-body">
                            <div class="blog-card-meta">
                                <span><i class="far fa-calendar-alt"></i> <?php echo date('d M Y', strtotime($post['created_at'])); ?></span>
                                <span><i class="far fa-eye"></i> <?php echo number_format($post['view_count']); ?></span>
                            </div>
                            <h2 class="blog-card-title">
                                <a href="<?php echo SITE_URL; ?>/blog/<?php echo clean($post['slug']); ?>">
                                    <?php echo clean($post['title']); ?>
                                </a>
                            </h2>
                            <p class="blog-card-excerpt">
                                <?php 
                                if (!empty($post['excerpt'])) {
                                    echo clean($post['excerpt']);
                                } else {
                                    echo clean(mb_substr(strip_tags($post['content']), 0, 150, 'UTF-8')) . '...';
                                }
                                ?>
                            </p>
                            <div class="blog-card-footer">
                                <a href="<?php echo SITE_URL; ?>/blog/<?php echo clean($post['slug']); ?>" class="blog-read-more">
                                    Devamını Oku <i class="fas fa-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
            
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="<?php echo SITE_URL; ?>/blog?page=<?php echo $page - 1; ?>"><i class="fas fa-chevron-left"></i></a>
                    <?php else: ?>
                        <span class="disabled"><i class="fas fa-chevron-left"></i></span>
                    <?php endif; ?>
                    
                    <?php
                    $startPage = max(1, $page - 2);
                    $endPage = min($totalPages, $page + 2);
                    
                    if ($startPage > 1): ?>
                        <a href="<?php echo SITE_URL; ?>/blog?page=1">1</a>
                        <?php if ($startPage > 2): ?><span class="disabled">...</span><?php endif; ?>
                    <?php endif;
                    
                    for ($i = $startPage; $i <= $endPage; $i++): ?>
                        <?php if ($i == $page): ?>
                            <span class="current"><?php echo $i; ?></span>
                        <?php else: ?>
                            <a href="<?php echo SITE_URL; ?>/blog?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        <?php endif; ?>
                    <?php endfor;
                    
                    if ($endPage < $totalPages): ?>
                        <?php if ($endPage < $totalPages - 1): ?><span class="disabled">...</span><?php endif; ?>
                        <a href="<?php echo SITE_URL; ?>/blog?page=<?php echo $totalPages; ?>"><?php echo $totalPages; ?></a>
                    <?php endif; ?>
                    
                    <?php if ($page < $totalPages): ?>
                        <a href="<?php echo SITE_URL; ?>/blog?page=<?php echo $page + 1; ?>"><i class="fas fa-chevron-right"></i></a>
                    <?php else: ?>
                        <span class="disabled"><i class="fas fa-chevron-right"></i></span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
        <?php else: ?>
            <div class="blog-empty">
                <i class="fas fa-newspaper"></i>
                <h2>Henüz blog yazısı yok</h2>
                <p>Yakında yeni içerikler eklenecek, takipte kalın!</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>