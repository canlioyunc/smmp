<?php
header('Content-Type: application/manifest+json; charset=utf-8');
require_once __DIR__.'/config.php';
require_once __DIR__.'/includes/MoniV2Compat.php';
$p=moni_pwa_config($db);if(empty($p['enabled'])){http_response_code(404);echo '{}';exit;}
$base=rtrim(SITE_URL,'/');$basePath=rtrim((string)(parse_url(SITE_URL,PHP_URL_PATH)?:''),'/');
$resolve=function(string $path)use($basePath){if($path==='')return $basePath.'/';if(!str_starts_with($path,'/'))$path='/'.$path;if($basePath!==''&&!str_starts_with($path,$basePath.'/')&&$path!==$basePath)return $basePath.$path;return $path;};
$mime=function(string $src){$e=strtolower(pathinfo(parse_url($src,PHP_URL_PATH)?:$src,PATHINFO_EXTENSION));return ['png'=>'image/png','jpg'=>'image/jpeg','jpeg'=>'image/jpeg','webp'=>'image/webp','svg'=>'image/svg+xml'][$e]??'image/png';};
$icons=[];foreach([[192,$p['icon_192']],[512,$p['icon_512']]] as [$size,$src]){$src=(string)$src;if($src!==''){$icons[]=['src'=>$resolve($src),'sizes'=>$size.'x'.$size,'type'=>$mime($src),'purpose'=>'any maskable'];}}
if(!$icons)$icons[]=['src'=>$resolve('/pwa-icon.php'),'sizes'=>'any','type'=>'image/svg+xml','purpose'=>'any maskable'];
$data=['name'=>$p['name'],'short_name'=>$p['short_name'],'description'=>$p['description'],'start_url'=>$resolve((string)$p['start_url']),'scope'=>$resolve((string)$p['scope']),'display'=>in_array($p['display'],['standalone','fullscreen','minimal-ui','browser'],true)?$p['display']:'standalone','background_color'=>$p['background_color'],'theme_color'=>$p['theme_color'],'icons'=>$icons];
echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
