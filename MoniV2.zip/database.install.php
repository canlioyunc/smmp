<?php http_response_code(404); exit; ?>
-- Temiz kurulum veritabanı şeması

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: kurulum sırasında kullanıcı tarafından belirlenir
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `icon` varchar(100) DEFAULT 'fas fa-bullhorn',
  `media_type` enum('none','image','video') DEFAULT 'none',
  `media_url` varchar(500) DEFAULT NULL,
  `link_url` varchar(500) DEFAULT NULL,
  `button_text` varchar(100) DEFAULT NULL,
  `button_color` varchar(50) DEFAULT 'primary',
  `display_order` int(11) DEFAULT 0,
  `expires_at` datetime DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `announcements`
--

-- `announcements` tablosu temiz kurulumda boş başlatılır.

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `api_clients`
--

CREATE TABLE `api_clients` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `api_key` varchar(64) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `allowed_ips` text DEFAULT NULL,
  `rate_limit_per_min` int(11) NOT NULL DEFAULT 300,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `api_providers`
--

CREATE TABLE `api_providers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `api_url` varchar(500) NOT NULL,
  `api_key` varchar(500) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `balance` decimal(12,4) DEFAULT 0.0000,
  `currency` varchar(10) DEFAULT 'USD',
  `last_sync` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `api_providers`
--

-- `api_providers` tablosu temiz kurulumda boş başlatılır.

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `bank_accounts`
--

CREATE TABLE `bank_accounts` (
  `id` int(11) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `account_holder` varchar(255) NOT NULL,
  `iban` varchar(50) NOT NULL,
  `branch_code` varchar(20) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `bank_accounts`
--

-- `bank_accounts` tablosu temiz kurulumda boş başlatılır.

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `blog_posts`
--

CREATE TABLE `blog_posts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `excerpt` text DEFAULT NULL,
  `content` longtext NOT NULL,
  `featured_image` varchar(500) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `view_count` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `blog_posts`
--

-- `blog_posts` tablosu temiz kurulumda boş başlatılır.

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `icon` varchar(50) DEFAULT 'fas fa-folder',
  `icon_color` varchar(20) DEFAULT '#667eea',
  `description` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `icon`, `icon_color`, `description`, `sort_order`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Instagram', 'instagram', 'fab fa-instagram', '#E4405F', 'Instagram hizmetleri', 0, 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(2, 'TikTok', 'tiktok', 'fab fa-tiktok', '#000000', 'TikTok hizmetleri', 1, 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(3, 'YouTube', 'youtube', 'fab fa-youtube', '#FF0000', 'YouTube hizmetleri', 2, 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(4, 'Twitter', 'twitter', 'fab fa-twitter', '#1DA1F2', 'Twitter hizmetleri', 3, 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(5, 'Facebook', 'facebook', 'fab fa-facebook-f', '#1877F2', 'Facebook hizmetleri', 4, 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(6, 'Telegram', 'telegram', 'fab fa-telegram-plane', '#0088CC', 'Telegram hizmetleri', 5, 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(7, 'Spotify', 'spotify', 'fab fa-spotify', '#1DB954', 'Spotify hizmetleri', 6, 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `coupons`
--

CREATE TABLE `coupons` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `type` enum('fixed','percentage') NOT NULL DEFAULT 'fixed',
  `max_amount` decimal(10,2) DEFAULT NULL COMMENT 'Yüzdelik kuponlarda maksimum tutar',
  `usage_limit` int(11) DEFAULT NULL COMMENT 'Toplam kullanım limiti (NULL = sınırsız)',
  `usage_limit_per_user` int(11) DEFAULT 1 COMMENT 'Kişi başı kullanım limiti (NULL = sınırsız)',
  `used_count` int(11) NOT NULL DEFAULT 0 COMMENT 'Toplam kullanım sayısı',
  `min_balance` decimal(10,2) DEFAULT NULL COMMENT 'Minimum bakiye şartı',
  `start_date` datetime DEFAULT NULL COMMENT 'Başlangıç tarihi (NULL = hemen aktif)',
  `end_date` datetime DEFAULT NULL COMMENT 'Bitiş tarihi (NULL = süresiz)',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `coupons`
--

-- `coupons` tablosu temiz kurulumda boş başlatılır.

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `coupon_usages`
--

CREATE TABLE `coupon_usages` (
  `id` int(11) NOT NULL,
  `coupon_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL COMMENT 'Kullanıcıya eklenen tutar',
  `used_at` timestamp NULL DEFAULT current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `credit_packages`
--

CREATE TABLE `credit_packages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL COMMENT 'Paket adı',
  `icon` varchar(50) DEFAULT 'fa-coins' COMMENT 'FontAwesome ikon',
  `icon_color` varchar(20) DEFAULT '#667eea' COMMENT 'İkon rengi',
  `credit_amount` decimal(10,2) NOT NULL COMMENT 'Verilecek bakiye miktarı',
  `price` decimal(10,2) NOT NULL COMMENT 'Ödeme tutarı',
  `bonus_amount` decimal(10,2) DEFAULT 0.00 COMMENT 'Bonus miktar (gösterim için)',
  `discount_percent` decimal(5,2) DEFAULT 0.00 COMMENT 'İndirim yüzdesi (gösterim için)',
  `description` text DEFAULT NULL COMMENT 'Paket açıklaması',
  `is_popular` tinyint(1) DEFAULT 0 COMMENT 'Popüler paket mi?',
  `is_active` tinyint(1) DEFAULT 1 COMMENT 'Aktif mi?',
  `sort_order` int(11) DEFAULT 0 COMMENT 'Sıralama',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `credit_packages`
--

INSERT INTO `credit_packages` (`id`, `name`, `icon`, `icon_color`, `credit_amount`, `price`, `bonus_amount`, `discount_percent`, `description`, `is_popular`, `is_active`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, 'Başlangıç Paketi', 'fa-star', '#17a2b8', 50.00, 50.00, 0.00, 0.00, 'Yeni başlayanlar için ideal', 0, 1, 1, '2026-01-30 18:06:11', '2026-02-07 14:20:40'),
(2, 'Ekonomik Paket', 'fa-bolt', '#28a745', 100.00, 95.00, 5.00, 5.00, '%5 bonus ile avantajlı paket', 0, 1, 2, '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(3, 'Popüler Paket', 'fa-fire', '#fd7e14', 250.00, 225.00, 25.00, 10.00, 'En çok tercih edilen paket', 1, 1, 3, '2026-01-30 18:06:11', '2026-01-30 18:45:32'),
(4, 'Premium Paket', 'fa-crown', '#6f42c1', 500.00, 425.00, 75.00, 15.00, '%15 bonus kazanın', 0, 1, 4, '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(5, 'Business Paket', 'fa-gem', '#e83e8c', 1000.00, 800.00, 200.00, 20.00, 'İş kullanıcıları için ideal', 0, 1, 5, '2026-01-30 18:06:11', '2026-01-30 19:03:48'),
(6, 'Enterprise Paket', 'fa-rocket', '#dc3545', 2500.00, 1875.00, 625.00, 25.00, 'Maksimum tasarruf paketi', 0, 1, 6, '2026-01-30 18:06:11', '2026-01-30 18:06:11');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `cron_logs`
--

CREATE TABLE `cron_logs` (
  `id` int(11) NOT NULL,
  `scheduled_order_id` int(11) DEFAULT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `daily_bonus`
--

CREATE TABLE `daily_bonus` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `streak` int(11) NOT NULL DEFAULT 1,
  `claimed_at` timestamp NULL DEFAULT current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `daily_bonus_logs`
--

CREATE TABLE `daily_bonus_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `streak` int(11) NOT NULL,
  `balance_before` decimal(10,2) DEFAULT NULL,
  `balance_after` decimal(10,2) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `daily_bonus_settings`
--

CREATE TABLE `daily_bonus_settings` (
  `id` int(11) NOT NULL,
  `setting_key` varchar(50) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `daily_bonus_settings`
--

INSERT INTO `daily_bonus_settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES
(1, 'is_active', '1', '2026-01-27 22:54:52', '2026-01-28 23:41:29'),
(2, 'claim_interval_hours', '1', '2026-01-27 22:54:52', '2026-01-28 23:41:29'),
(3, 'bonus_amounts', '[0.1,0.15,1,2,3,4,5]', '2026-01-27 22:54:52', '2026-01-28 23:41:29'),
(4, 'streak_reset_hours', '48', '2026-01-27 22:54:52', '2026-01-28 23:41:29'),
(5, 'min_balance_required', '0', '2026-01-27 22:54:52', '2026-01-28 23:41:29'),
(6, 'max_streak_days', '7', '2026-01-27 22:54:52', '2026-01-28 23:41:29');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `email_verification_tokens`
--

CREATE TABLE `email_verification_tokens` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `token` varchar(128) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `email_verification_tokens`
--

-- `email_verification_tokens` tablosu temiz kurulumda boş başlatılır.

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `footer_links`
--

CREATE TABLE `footer_links` (
  `id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(500) NOT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `target` enum('_self','_blank') DEFAULT '_self',
  `sort_order` int(11) DEFAULT 0,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `footer_links`
--

INSERT INTO `footer_links` (`id`, `section_id`, `title`, `url`, `icon`, `target`, `sort_order`, `status`, `created_at`) VALUES
(1, 1, 'Ana Sayfa', '/', 'fas fa-home', '_self', 1, 'active', '2026-01-25 22:59:04'),
(2, 1, 'Hizmetler', '/services.php', 'fas fa-list', '_self', 2, 'active', '2026-01-25 22:59:04'),
(3, 2, 'Kullanım Şartları', 'pages/kullanim-sartlari.php', 'fas fa-file-contract', '_self', 1, 'active', '2026-01-25 22:59:04'),
(4, 2, 'Gizlilik Politikası', 'pages/gizlilik-politikasi.php', 'fas fa-shield-alt', '_self', 2, 'active', '2026-01-25 22:59:04'),
(5, 2, 'İade Politikası', 'pages/iade-politikasi.php', 'fas fa-undo', '_self', 3, 'active', '2026-01-25 22:59:04');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `footer_sections`
--

CREATE TABLE `footer_sections` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `footer_sections`
--

INSERT INTO `footer_sections` (`id`, `title`, `sort_order`, `status`, `created_at`) VALUES
(1, 'Hızlı Linkler', 1, 'active', CURRENT_TIMESTAMP),
(2, 'Yasal', 2, 'active', CURRENT_TIMESTAMP),
(3, 'İletişim', 3, 'active', CURRENT_TIMESTAMP);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `homepage_services`
--

CREATE TABLE `homepage_services` (
  `id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `custom_title` varchar(255) DEFAULT NULL,
  `custom_description` varchar(500) DEFAULT NULL,
  `custom_icon` varchar(50) DEFAULT NULL,
  `custom_icon_style` varchar(100) DEFAULT NULL,
  `custom_price_text` varchar(100) DEFAULT NULL,
  `badge_text` varchar(50) DEFAULT NULL,
  `badge_color` varchar(20) DEFAULT '#ff6b6b',
  `sort_order` int(11) DEFAULT 0,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `homepage_services`
--

-- `homepage_services` tablosu temiz kurulumda boş başlatılır.

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `languages`
--

CREATE TABLE `languages` (
  `id` int(11) NOT NULL,
  `code` varchar(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `native_name` varchar(50) NOT NULL,
  `flag` varchar(10) DEFAULT '?',
  `is_default` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `languages`
--

INSERT INTO `languages` (`id`, `code`, `name`, `native_name`, `flag`, `is_default`, `is_active`, `sort_order`, `created_at`) VALUES
(1, 'tr', 'Türkçe', 'Türkçe', '🇹🇷', 1, 1, 1, '2026-01-26 09:59:05'),
(2, 'en', 'English', 'English', '🇬🇧', 0, 1, 2, '2026-01-26 09:59:05');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `api_order_id` varchar(100) DEFAULT NULL,
  `link` varchar(1000) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,4) NOT NULL,
  `refund_amount` decimal(10,2) DEFAULT 0.00,
  `start_count` int(11) DEFAULT NULL,
  `remains` int(11) DEFAULT NULL,
  `status` enum('pending','processing','in_progress','completed','partial','cancelled','refunded','error') DEFAULT 'pending',
  `refill_enabled` tinyint(1) DEFAULT 0 COMMENT 'Refill aktif mi?',
  `refill_until` date DEFAULT NULL COMMENT 'Refill son tarihi',
  `refill_used` int(11) DEFAULT 0 COMMENT 'Kullanılan refill hakkı',
  `refill_max` int(11) DEFAULT 0 COMMENT 'Maksimum refill hakkı',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `api_provider_id` int(11) DEFAULT NULL,
  `api_response` text DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `dripfeed_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `orders_dripfeed`
--

CREATE TABLE `orders_dripfeed` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `link` varchar(500) NOT NULL,
  `quantity` int(11) NOT NULL COMMENT 'Her gönderimdeki miktar',
  `runs` int(11) NOT NULL COMMENT 'Kaç kez gönderilecek',
  `completed_runs` int(11) NOT NULL DEFAULT 0,
  `interval_time` int(11) NOT NULL COMMENT 'Dakika cinsinden aralık',
  `total_quantity` int(11) NOT NULL,
  `total_price` decimal(10,4) NOT NULL,
  `status` enum('active','completed','canceled','partial') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `next_run_at` datetime DEFAULT NULL,
  `last_run_at` datetime DEFAULT NULL,
  `error_count` int(11) NOT NULL DEFAULT 0,
  `last_error` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` varchar(100) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `password_resets`
--

-- `password_resets` tablosu temiz kurulumda boş başlatılır.

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` enum('bank','iyzico','papara','paytr') NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `config` text DEFAULT NULL,
  `min_amount` decimal(10,2) DEFAULT 10.00,
  `max_amount` decimal(10,2) DEFAULT 10000.00,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `name`, `type`, `status`, `config`, `min_amount`, `max_amount`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, 'Havale/EFT', 'bank', 'inactive', NULL, 10.00, 10000.00, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(2, 'İyzico', 'iyzico', 'inactive', '{"api_key":"","secret_key":"","base_url":"https:\/\/sandbox-api.iyzipay.com"}', 10.00, 10000.00, 2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `payment_requests`
--

CREATE TABLE `payment_requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `package_id` int(11) DEFAULT NULL COMMENT 'Seçilen kredi paketi',
  `payment_method_id` int(11) DEFAULT NULL,
  `bank_account_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `credit_amount` decimal(10,2) DEFAULT NULL COMMENT 'Paket kredi miktarı',
  `sender_name` varchar(255) NOT NULL,
  `transfer_date` datetime NOT NULL,
  `receipt_image` varchar(255) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `admin_note` text DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL,
  `processed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `popups`
--

CREATE TABLE `popups` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `media_type` enum('image','video') NOT NULL DEFAULT 'image',
  `media_path` varchar(500) NOT NULL,
  `link_url` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `popups`
--

-- `popups` tablosu temiz kurulumda boş başlatılır.

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `referral_earnings`
--

CREATE TABLE `referral_earnings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL COMMENT 'Kazancı alan kullanıcı (referans veren)',
  `referred_user_id` int(11) NOT NULL COMMENT 'Referans olan kullanıcı',
  `order_id` int(11) DEFAULT NULL COMMENT 'İlgili sipariş',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Kazanç miktarı',
  `commission_rate` decimal(5,2) NOT NULL DEFAULT 0.00 COMMENT 'Komisyon oranı %',
  `order_amount` decimal(10,2) DEFAULT 0.00 COMMENT 'Sipariş tutarı',
  `status` enum('pending','paid','cancelled') DEFAULT 'pending',
  `paid_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `referral_logs`
--

CREATE TABLE `referral_logs` (
  `id` int(11) NOT NULL,
  `referrer_id` int(11) NOT NULL COMMENT 'Referans veren kullanıcı',
  `referred_id` int(11) NOT NULL COMMENT 'Referans olan (yeni kayıt) kullanıcı',
  `bonus_amount` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Kazanılan bonus',
  `status` enum('pending','completed') DEFAULT 'pending' COMMENT 'pending=bekliyor, completed=bakiyeye aktarıldı',
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `refill_requests`
--

CREATE TABLE `refill_requests` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `api_order_id` varchar(100) DEFAULT NULL COMMENT 'Orijinal API sipariş ID',
  `api_refill_id` varchar(100) DEFAULT NULL COMMENT 'API refill sipariş ID (varsa)',
  `quantity` int(11) NOT NULL COMMENT 'Orijinal sipariş miktarı',
  `status` enum('pending','processing','completed','rejected','error') DEFAULT 'pending',
  `admin_note` text DEFAULT NULL COMMENT 'Admin notu / red sebebi',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `processed_at` timestamp NULL DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL,
  `new_order_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `scheduled_orders`
--

CREATE TABLE `scheduled_orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `link` text NOT NULL,
  `last_processed_link` text DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `max_quantity` int(11) DEFAULT 0,
  `price` decimal(15,4) NOT NULL,
  `type` enum('subscription','scheduled') NOT NULL DEFAULT 'scheduled',
  `status` enum('active','completed','cancelled','paused','expired') NOT NULL DEFAULT 'active',
  `scheduled_time` datetime DEFAULT NULL COMMENT 'Siparişin işleme alınacağı tarih',
  `posts` int(11) DEFAULT 0 COMMENT 'Kaç gönderiye işlem yapılacak (Auto-Like vb.)',
  `posts_done` int(11) DEFAULT 0 COMMENT 'Tamamlanan gönderi sayısı',
  `delay` int(11) DEFAULT 0 COMMENT 'Gecikme süresi (dakika)',
  `expiry_date` datetime DEFAULT NULL COMMENT 'Abonelik bitiş tarihi',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `api_service_id` int(11) DEFAULT NULL,
  `api_provider_id` int(11) DEFAULT NULL,
  `name` varchar(500) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('default','package','custom_comments','subscriptions') DEFAULT 'default',
  `price_per_1000` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `cost_per_1000` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `min_quantity` int(11) NOT NULL DEFAULT 100,
  `max_quantity` int(11) NOT NULL DEFAULT 10000,
  `refill` tinyint(1) DEFAULT 0,
  `refill_days` int(11) DEFAULT 0,
  `refill_count` int(11) DEFAULT 1 COMMENT 'Refill hakkı sayısı',
  `cancel` tinyint(1) DEFAULT 0,
  `average_time` varchar(100) DEFAULT NULL,
  `speed_per_hour` int(11) DEFAULT NULL,
  `dripfeed` tinyint(1) DEFAULT 0,
  `status` enum('active','inactive','pending') DEFAULT 'active',
  `sort_order` int(11) DEFAULT 0,
  `total_orders` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `settings`
--

INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES
(1, 'site_name', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(2, 'site_logo', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(3, 'site_favicon', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(4, 'site_description', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(5, 'contact_email', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(6, 'contact_phone', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(7, 'currency', 'TRY', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(8, 'currency_symbol', '₺', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(9, 'active_theme', 'bogurtlen', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(10, 'homepage_services_title', 'Popüler Hizmetlerimiz', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(11, 'homepage_services_subtitle', 'En çok tercih edilen sosyal medya hizmetlerimiz', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(52, 'smtp_host', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(53, 'smtp_port', '587', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(54, 'smtp_username', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(55, 'smtp_password', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(56, 'smtp_encryption', 'tls', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(57, 'smtp_from_email', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(58, 'smtp_from_name', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(59, 'smtp_enabled', '0', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(86, 'footer_email', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(87, 'footer_phone', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(88, 'footer_address', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(89, 'footer_working_hours', '7/24', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(90, 'footer_contact_enabled', '1', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(97, 'referral_enabled', '1', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(98, 'referral_commission_rate', '10', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(99, 'referral_min_withdraw', '50', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(100, 'referral_bonus_type', 'percentage', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(101, 'referral_welcome_bonus', '0', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(102, 'referral_max_earnings_per_user', '0', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(103, 'referral_bonus_amount', '2', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(104, 'referral_min_transfer', '2', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(144, 'demo_mode', '0', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(150, 'maintenance_mode', '0', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(151, 'maintenance_message', 'Sitemiz şu anda bakım çalışması nedeniyle geçici olarak kapalıdır. Kısa süre içinde tekrar hizmetinizdeyiz.', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(152, 'maintenance_end_time', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(153, 'maintenance_allowed_ips', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(198, 'email_verification_enabled', '0', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(523, 'hero_image', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(524, 'hero_image_position', 'right', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(525, 'site_url', '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `social_links`
--

CREATE TABLE `social_links` (
  `id` int(11) NOT NULL,
  `platform` varchar(100) NOT NULL,
  `url` varchar(500) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `social_links`
--

INSERT INTO `social_links` (`id`, `platform`, `url`, `icon`, `sort_order`, `status`, `created_at`) VALUES
(1, 'Facebook', '#', 'fab fa-facebook-f', 1, 'inactive', CURRENT_TIMESTAMP),
(2, 'Twitter', '#', 'fab fa-twitter', 2, 'inactive', CURRENT_TIMESTAMP),
(3, 'Instagram', '#', 'fab fa-instagram', 3, 'inactive', CURRENT_TIMESTAMP),
(4, 'Telegram', '#', 'fab fa-telegram-plane', 4, 'inactive', CURRENT_TIMESTAMP);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `social_logins`
--

CREATE TABLE `social_logins` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `provider_id` varchar(255) NOT NULL,
  `provider_email` varchar(255) DEFAULT NULL,
  `provider_name` varchar(255) DEFAULT NULL,
  `provider_avatar` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `social_login_settings`
--

CREATE TABLE `social_login_settings` (
  `id` int(11) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `client_id` varchar(255) DEFAULT NULL,
  `client_secret` varchar(255) DEFAULT NULL,
  `redirect_uri` varchar(255) DEFAULT NULL,
  `is_enabled` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `social_login_settings`
--

INSERT INTO `social_login_settings` (`id`, `provider`, `client_id`, `client_secret`, `redirect_uri`, `is_enabled`, `created_at`, `updated_at`) VALUES
(1, 'google', NULL, NULL, NULL, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(2, 'discord', NULL, NULL, NULL, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `support_messages`
--

CREATE TABLE `support_messages` (
  `id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT 0,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `support_tickets`
--

CREATE TABLE `support_tickets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `status` enum('open','answered','closed') DEFAULT 'open',
  `priority` enum('low','medium','high') DEFAULT 'medium',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `closed_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `support_ticket_orders`
--

CREATE TABLE `support_ticket_orders` (
  `ticket_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `theme_defaults`
--

CREATE TABLE `theme_defaults` (
  `id` int(11) NOT NULL,
  `theme_name` varchar(50) NOT NULL,
  `primary_color` varchar(20) DEFAULT NULL,
  `secondary_color` varchar(20) DEFAULT NULL,
  `background_color` varchar(20) DEFAULT NULL,
  `text_color` varchar(20) DEFAULT NULL,
  `button_color` varchar(20) DEFAULT NULL,
  `button_hover_color` varchar(20) DEFAULT NULL,
  `button_text_color` varchar(20) DEFAULT NULL,
  `header_bg_color` varchar(20) DEFAULT NULL,
  `footer_bg_color` varchar(20) DEFAULT NULL,
  `sidebar_bg_color` varchar(20) DEFAULT NULL,
  `card_bg_color` varchar(20) DEFAULT NULL,
  `border_color` varchar(20) DEFAULT NULL,
  `success_color` varchar(20) DEFAULT NULL,
  `danger_color` varchar(20) DEFAULT NULL,
  `warning_color` varchar(20) DEFAULT NULL,
  `info_color` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `theme_defaults`
--

INSERT INTO `theme_defaults` (`id`, `theme_name`, `primary_color`, `secondary_color`, `background_color`, `text_color`, `button_color`, `button_hover_color`, `button_text_color`, `header_bg_color`, `footer_bg_color`, `sidebar_bg_color`, `card_bg_color`, `border_color`, `success_color`, `danger_color`, `warning_color`, `info_color`) VALUES
(1, 'dark', '#6c5ce7', '#a29bfe', '#1a1a2e', '#ffffff', '#6c5ce7', '#5b4cdb', '#ffffff', '#16213e', '#0f0f1a', '#16213e', '#1f1f3d', '#2d2d5a', '#00b894', '#d63031', '#fdcb6e', '#0984e3'),
(2, 'light', '#667eea', '#764ba2', '#f5f7fa', '#333333', '#667eea', '#5a6fd6', '#ffffff', '#ffffff', '#2d3436', '#ffffff', '#ffffff', '#e0e0e0', '#28a745', '#dc3545', '#ffc107', '#17a2b8'),
(3, 'bogurtlen', '#6a0572', '#ab83a1', '#1a0a1f', '#e8d5e8', '#6a0572', '#8b0a8c', '#ffffff', '#2d0a36', '#0d0410', '#2d0a36', '#3d1a46', '#5a2d66', '#9b59b6', '#e74c3c', '#f39c12', '#3498db'),
(4, 'ananas', '#f9ca24', '#f0932b', '#fffdf0', '#2d2d2d', '#f9ca24', '#e8b91c', '#2d2d2d', '#f9ca24', '#2d2d2d', '#fff9e6', '#ffffff', '#f0e68c', '#27ae60', '#c0392b', '#f39c12', '#2980b9'),
(5, 'okyanus', '#00b4d8', '#0077b6', '#caf0f8', '#03045e', '#0096c7', '#0077b6', '#ffffff', '#03045e', '#023e8a', '#e0f7fa', '#ffffff', '#90e0ef', '#00cec9', '#ff7675', '#ffeaa7', '#74b9ff'),
(6, 'orman', '#2d6a4f', '#40916c', '#d8f3dc', '#1b4332', '#40916c', '#2d6a4f', '#ffffff', '#1b4332', '#081c15', '#ebf5ee', '#ffffff', '#95d5b2', '#52b788', '#e76f51', '#e9c46a', '#219ebc');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `theme_settings`
--

CREATE TABLE `theme_settings` (
  `id` int(11) NOT NULL,
  `theme_name` varchar(50) NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `primary_color` varchar(20) DEFAULT '#667eea',
  `secondary_color` varchar(20) DEFAULT '#764ba2',
  `background_color` varchar(20) DEFAULT '#f5f7fa',
  `text_color` varchar(20) DEFAULT '#333333',
  `button_color` varchar(20) DEFAULT '#667eea',
  `button_hover_color` varchar(20) DEFAULT '#5a6fd6',
  `button_text_color` varchar(20) DEFAULT '#ffffff',
  `header_bg_color` varchar(20) DEFAULT '#667eea',
  `footer_bg_color` varchar(20) DEFAULT '#1a1a2e',
  `sidebar_bg_color` varchar(20) DEFAULT '#ffffff',
  `card_bg_color` varchar(20) DEFAULT '#ffffff',
  `border_color` varchar(20) DEFAULT '#e0e0e0',
  `success_color` varchar(20) DEFAULT '#28a745',
  `danger_color` varchar(20) DEFAULT '#dc3545',
  `warning_color` varchar(20) DEFAULT '#ffc107',
  `info_color` varchar(20) DEFAULT '#17a2b8',
  `is_default` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `theme_settings`
--

INSERT INTO `theme_settings` (`id`, `theme_name`, `is_active`, `primary_color`, `secondary_color`, `background_color`, `text_color`, `button_color`, `button_hover_color`, `button_text_color`, `header_bg_color`, `footer_bg_color`, `sidebar_bg_color`, `card_bg_color`, `border_color`, `success_color`, `danger_color`, `warning_color`, `info_color`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 'dark', 1, '#6c5ce7', '#a29bfe', '#1a1a2e', '#ffffff', '#6c5ce7', '#5b4cdb', '#ffffff', '#16213e', '#0f0f1a', '#16213e', '#1f1f3d', '#2d2d5a', '#28a745', '#dc3545', '#ffc107', '#17a2b8', 1, '2026-01-25 15:20:43', '2026-01-25 15:20:43'),
(2, 'light', 0, '#667eea', '#764ba2', '#f5f7fa', '#333333', '#667eea', '#5a6fd6', '#ffffff', '#ffffff', '#2d3436', '#ffffff', '#ffffff', '#e0e0e0', '#28a745', '#dc3545', '#ffc107', '#17a2b8', 1, '2026-01-25 15:20:43', '2026-02-06 20:37:14'),
(3, 'bogurtlen', 0, '#6a0572', '#ab83a1', '#1a0a1f', '#e8d5e8', '#6a0572', '#8b0a8c', '#ffffff', '#2d0a36', '#0d0410', '#2d0a36', '#3d1a46', '#5a2d66', '#28a745', '#dc3545', '#ffc107', '#17a2b8', 1, '2026-01-25 15:20:43', '2026-01-25 15:20:43'),
(4, 'ananas', 0, '#f9ca24', '#f0932b', '#fffdf0', '#2d2d2d', '#f9ca24', '#e8b91c', '#2d2d2d', '#f9ca24', '#2d2d2d', '#fff9e6', '#ffffff', '#f0e68c', '#28a745', '#dc3545', '#ffc107', '#17a2b8', 1, '2026-01-25 15:20:43', '2026-01-31 00:32:15'),
(5, 'okyanus', 0, '#00b4d8', '#0077b6', '#caf0f8', '#03045e', '#0096c7', '#0077b6', '#ffffff', '#03045e', '#023e8a', '#e0f7fa', '#ffffff', '#90e0ef', '#28a745', '#dc3545', '#ffc107', '#17a2b8', 1, '2026-01-25 15:20:43', '2026-01-25 15:20:43'),
(6, 'orman', 0, '#2d6a4f', '#40916c', '#d8f3dc', '#1b4332', '#40916c', '#2d6a4f', '#ffffff', '#1b4332', '#081c15', '#ebf5ee', '#ffffff', '#95d5b2', '#28a745', '#dc3545', '#ffc107', '#17a2b8', 1, '2026-01-25 15:20:43', '2026-01-25 15:20:43');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL COMMENT 'deposit, withdraw, order, refund, referral_bonus',
  `amount` decimal(10,2) NOT NULL,
  `balance_after` decimal(10,2) DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `status` enum('pending','completed','failed','cancelled') DEFAULT 'completed',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `transactions`
--

-- `transactions` tablosu temiz kurulumda boş başlatılır.

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `translations`
--

CREATE TABLE `translations` (
  `id` int(11) NOT NULL,
  `lang_code` varchar(5) NOT NULL,
  `translation_key` varchar(255) NOT NULL,
  `translation_value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `translations`
--

INSERT INTO `translations` (`id`, `lang_code`, `translation_key`, `translation_value`, `created_at`, `updated_at`) VALUES
(1, 'tr', 'site_name', 'SMM Panel', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(2, 'tr', 'home', 'Ana Sayfa', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(3, 'tr', 'services', 'Servisler', '2026-01-26 09:59:29', '2026-02-03 12:43:09'),
(4, 'tr', 'new_order', 'Yeni Sipariş', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(5, 'tr', 'orders', 'Sipariş', '2026-01-26 09:59:29', '2026-02-03 12:43:09'),
(6, 'tr', 'add_funds', 'Bakiye Yükle', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(7, 'tr', 'support', 'Destek', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(8, 'tr', 'profile', 'Profil', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(9, 'tr', 'logout', 'Çıkış Yap', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(10, 'tr', 'login', 'Giriş Yap', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(11, 'tr', 'register', 'Kayıt Ol', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(12, 'tr', 'balance', 'Bakiye', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(13, 'tr', 'welcome', 'Hoş Geldiniz', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(14, 'tr', 'dashboard', 'Kontrol Paneli', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(15, 'tr', 'total_orders', 'Toplam Sipariş', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(16, 'tr', 'pending_orders', 'Bekleyen Siparişler', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(17, 'tr', 'completed_orders', 'Tamamlanan Siparişler', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(18, 'tr', 'total_spent', 'Toplam Harcama', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(19, 'tr', 'recent_orders', 'Son Siparişler', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(20, 'tr', 'quick_actions', 'Hızlı İşlemler', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(21, 'tr', 'order_id', 'Sipariş No', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(22, 'tr', 'service', 'Hizmet', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(23, 'tr', 'link', 'Link', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(24, 'tr', 'quantity', 'Miktar', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(25, 'tr', 'price', 'Fiyat', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(26, 'tr', 'status', 'Durum', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(27, 'tr', 'date', 'Tarih', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(28, 'tr', 'start_count', 'Başlangıç', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(29, 'tr', 'remains', 'Kalan', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(30, 'tr', 'no_orders', 'Henüz sipariş bulunmuyor', '2026-01-26 09:59:29', '2026-01-26 10:38:07'),
(31, 'tr', 'status_pending', 'Bekleniyor', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(32, 'tr', 'status_processing', 'İşleniyor', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(33, 'tr', 'status_in_progress', 'Devam Ediyor', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(34, 'tr', 'status_completed', 'Tamamlandı', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(35, 'tr', 'status_partial', 'Kısmi Tamamlandı', '2026-01-26 09:59:29', '2026-01-26 10:19:17'),
(36, 'tr', 'status_cancelled', 'İptal', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(37, 'tr', 'status_refunded', 'İade Edildi', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(38, 'tr', 'select_category', 'Kategori Seçin', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(39, 'tr', 'select_service', 'Servis Seçin', '2026-01-26 09:59:29', '2026-01-26 10:09:36'),
(40, 'tr', 'enter_link', 'Link Girin', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(41, 'tr', 'enter_quantity', 'Miktar girin', '2026-01-26 09:59:29', '2026-01-26 10:09:36'),
(42, 'tr', 'min', 'Min', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(43, 'tr', 'max', 'Maks', '2026-01-26 09:59:29', '2026-01-30 11:29:53'),
(44, 'tr', 'price_per_1000', '1000 Adet Fiyatı', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(45, 'tr', 'total_price', 'Toplam Fiyat', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(46, 'tr', 'place_order', 'Sipariş Ver', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(47, 'tr', 'insufficient_balance', 'Yetersiz bakiye', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(48, 'tr', 'order_success', 'Sipariş başarıyla oluşturuldu', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(49, 'tr', 'current_balance', 'Mevcut Bakiye', '2026-01-26 09:59:29', '2026-01-26 10:53:35'),
(50, 'tr', 'add_funds_title', 'Bakiye Yükle', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(51, 'tr', 'amount', 'Tutar', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(52, 'tr', 'payment_method', 'Ödeme Yöntemi', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(53, 'tr', 'bank_transfer', 'Havale/EFT', '2026-01-26 09:59:29', '2026-01-26 10:29:27'),
(54, 'tr', 'credit_card', 'Kredi Kartı', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(55, 'tr', 'support_tickets', 'Destek Talepleri', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(56, 'tr', 'new_ticket', 'Yeni Talep', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(57, 'tr', 'subject', 'Konu', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(58, 'tr', 'message', 'Mesaj', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(59, 'tr', 'send', 'Gönder', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(60, 'tr', 'reply', 'Yanıtla', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(61, 'tr', 'close_ticket', 'Talebi Kapat', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(62, 'tr', 'ticket_open', 'Açık', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(63, 'tr', 'ticket_answered', 'Yanıtlandı', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(64, 'tr', 'ticket_closed', 'Bu talep kapatılmıştır, yanıt gönderemezsiniz', '2026-01-26 09:59:29', '2026-01-30 11:29:53'),
(65, 'tr', 'edit_profile', 'Profil Düzenle', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(66, 'tr', 'change_password', 'Şifre Değiştir', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(67, 'tr', 'current_password', 'Mevcut Şifre', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(68, 'tr', 'new_password', 'Yeni Şifre', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(69, 'tr', 'confirm_password', 'Şifre Tekrar', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(70, 'tr', 'save', 'Tasarruf', '2026-01-26 09:59:29', '2026-01-30 18:15:38'),
(71, 'tr', 'cancel', 'İptal', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(72, 'tr', 'update', 'Güncelle', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(73, 'tr', 'email', 'E-posta', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(74, 'tr', 'username', 'Kullanıcı Adı', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(75, 'tr', 'password', 'Şifre', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(76, 'tr', 'remember_me', 'Beni Hatırla', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(77, 'tr', 'forgot_password', 'Şifremi Unuttum', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(78, 'tr', 'dont_have_account', 'Hesabınız yok mu?', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(79, 'tr', 'already_have_account', 'Zaten hesabınız var mı?', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(80, 'tr', 'success', 'Başarılı', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(81, 'tr', 'error', 'Hata', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(82, 'tr', 'warning', 'Uyarı', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(83, 'tr', 'info', 'Bilgi', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(84, 'tr', 'confirm_delete', 'Silmek istediğinize emin misiniz?', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(85, 'tr', 'no_results', 'Sonuç bulunamadı', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(86, 'tr', 'loading', 'Yükleniyor...', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(87, 'tr', 'all_rights_reserved', 'Tüm hakları saklıdır', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(88, 'tr', 'privacy_policy', 'Gizlilik Politikası', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(89, 'tr', 'terms_of_service', 'Kullanım Şartları', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(90, 'tr', 'contact_us', 'İletişim', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(91, 'tr', 'today', 'Bugün', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(92, 'tr', 'yesterday', 'Dün', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(93, 'tr', 'days_ago', ':count gün önce', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(94, 'tr', 'hours_ago', ':count saat önce', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(95, 'tr', 'minutes_ago', ':count dakika önce', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(96, 'tr', 'just_now', 'Az önce', '2026-01-26 09:59:29', '2026-01-26 09:59:29'),
(97, 'en', 'site_name', 'SMM Panel', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(98, 'en', 'home', 'Home', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(99, 'en', 'services', 'Services', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(100, 'en', 'new_order', 'New Order', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(101, 'en', 'orders', 'Orders', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(102, 'en', 'add_funds', 'Add Funds', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(103, 'en', 'support', 'Support', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(104, 'en', 'profile', 'Profile', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(105, 'en', 'logout', 'Logout', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(106, 'en', 'login', 'Login', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(107, 'en', 'register', 'Register', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(108, 'en', 'balance', 'Balance', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(109, 'en', 'welcome', 'Welcome', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(110, 'en', 'dashboard', 'Dashboard', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(111, 'en', 'total_orders', 'Total Orders', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(112, 'en', 'pending_orders', 'Pending Orders', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(113, 'en', 'completed_orders', 'Completed Orders', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(114, 'en', 'total_spent', 'Total Spent', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(115, 'en', 'recent_orders', 'Recent Orders', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(116, 'en', 'quick_actions', 'Quick Actions', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(117, 'en', 'order_id', 'Order ID', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(118, 'en', 'service', 'Service', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(119, 'en', 'link', 'Link', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(120, 'en', 'quantity', 'Quantity', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(121, 'en', 'price', 'Price', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(122, 'en', 'status', 'Status', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(123, 'en', 'date', 'Date', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(124, 'en', 'start_count', 'Start Count', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(125, 'en', 'remains', 'Remains', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(126, 'en', 'no_orders', 'No orders yet', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(127, 'en', 'status_pending', 'Pending', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(128, 'en', 'status_processing', 'Processing', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(129, 'en', 'status_in_progress', 'In Progress', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(130, 'en', 'status_completed', 'Completed', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(131, 'en', 'status_partial', 'Partial', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(132, 'en', 'status_cancelled', 'Cancelled', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(133, 'en', 'status_refunded', 'Refunded', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(134, 'en', 'select_category', 'Select Category', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(135, 'en', 'select_service', 'Select Service', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(136, 'en', 'enter_link', 'Enter Link', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(137, 'en', 'enter_quantity', 'Enter quantity', '2026-01-26 09:59:55', '2026-01-26 10:09:36'),
(138, 'en', 'min', 'Min', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(139, 'en', 'max', 'Max', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(140, 'en', 'price_per_1000', 'Price per 1000', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(141, 'en', 'total_price', 'Total Price', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(142, 'en', 'place_order', 'Place Order', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(143, 'en', 'insufficient_balance', 'Insufficient balance', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(144, 'en', 'order_success', 'Order placed successfully', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(145, 'en', 'current_balance', 'Current Balance', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(146, 'en', 'add_funds_title', 'Add Funds', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(147, 'en', 'amount', 'Amount', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(148, 'en', 'payment_method', 'Payment Method', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(149, 'en', 'bank_transfer', 'Bank Transfer', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(150, 'en', 'credit_card', 'Credit Card', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(151, 'en', 'support_tickets', 'Support Tickets', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(152, 'en', 'new_ticket', 'New Ticket', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(153, 'en', 'subject', 'Subject', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(154, 'en', 'message', 'Message', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(155, 'en', 'send', 'Send', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(156, 'en', 'reply', 'Reply', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(157, 'en', 'close_ticket', 'Close Ticket', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(158, 'en', 'ticket_open', 'Open', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(159, 'en', 'ticket_answered', 'Answered', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(160, 'en', 'ticket_closed', 'This ticket is closed, you cannot send a reply', '2026-01-26 09:59:55', '2026-01-30 11:30:04'),
(161, 'en', 'edit_profile', 'Edit Profile', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(162, 'en', 'change_password', 'Change Password', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(163, 'en', 'current_password', 'Current Password', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(164, 'en', 'new_password', 'New Password', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(165, 'en', 'confirm_password', 'Confirm Password', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(166, 'en', 'save', 'Save', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(167, 'en', 'cancel', 'Cancel', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(168, 'en', 'update', 'Update', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(169, 'en', 'email', 'Email', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(170, 'en', 'username', 'Username', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(171, 'en', 'password', 'Password', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(172, 'en', 'remember_me', 'Remember Me', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(173, 'en', 'forgot_password', 'Forgot Password', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(174, 'en', 'dont_have_account', 'Don\'t have an account?', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(175, 'en', 'already_have_account', 'Already have an account?', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(176, 'en', 'success', 'Success', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(177, 'en', 'error', 'Error', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(178, 'en', 'warning', 'Warning', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(179, 'en', 'info', 'Info', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(180, 'en', 'confirm_delete', 'Are you sure you want to delete?', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(181, 'en', 'no_results', 'No results found', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(182, 'en', 'loading', 'Loading...', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(183, 'en', 'all_rights_reserved', 'All rights reserved', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(184, 'en', 'privacy_policy', 'Privacy Policy', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(185, 'en', 'terms_of_service', 'Terms of Service', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(186, 'en', 'contact_us', 'Contact Us', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(187, 'en', 'today', 'Today', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(188, 'en', 'yesterday', 'Yesterday', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(189, 'en', 'days_ago', ':count days ago', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(190, 'en', 'hours_ago', ':count hours ago', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(191, 'en', 'minutes_ago', ':count minutes ago', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(192, 'en', 'just_now', 'Just now', '2026-01-26 09:59:55', '2026-01-26 09:59:55'),
(211, 'tr', 'main_menu', 'Ana Menü', '2026-01-26 10:06:29', '2026-01-26 10:06:29'),
(212, 'tr', 'all_services', 'Tüm Servisler', '2026-01-26 10:06:29', '2026-01-26 10:06:29'),
(213, 'tr', 'finance', 'Finans', '2026-01-26 10:06:29', '2026-01-26 10:06:29'),
(214, 'tr', 'transaction_history', 'İşlem Geçmişi', '2026-01-26 10:06:29', '2026-01-26 10:06:29'),
(215, 'tr', 'account', 'Hesap', '2026-01-26 10:06:29', '2026-01-26 10:06:29'),
(217, 'en', 'main_menu', 'Main Menu', '2026-01-26 10:06:29', '2026-01-26 10:06:29'),
(218, 'en', 'all_services', 'All Services', '2026-01-26 10:06:29', '2026-01-26 10:06:29'),
(219, 'en', 'finance', 'Finance', '2026-01-26 10:06:29', '2026-01-26 10:06:29'),
(220, 'en', 'transaction_history', 'Transaction History', '2026-01-26 10:06:29', '2026-01-26 10:06:29'),
(221, 'en', 'account', 'Account', '2026-01-26 10:06:29', '2026-01-26 10:06:29'),
(223, 'tr', 'quick_order', 'Hızlı Sipariş', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(224, 'tr', 'category', 'Kategori', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(225, 'tr', 'select_category_first', 'Önce Kategori Seçin', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(226, 'tr', 'service_info', 'Servis Bilgisi', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(227, 'tr', 'estimated_time', 'Tahmini Süre', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(228, 'tr', 'hours', 'Saat', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(229, 'tr', 'active_orders', 'Aktif Sipariş', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(230, 'tr', 'pieces', 'adet', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(231, 'tr', 'view_all_orders', 'Tüm Siparişleri Gör', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(232, 'tr', 'invalid_service', 'Geçersiz servis seçimi!', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(233, 'tr', 'link_required', 'Link alanı zorunludur!', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(234, 'tr', 'minimum_quantity', 'Minimum miktar', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(235, 'tr', 'maximum_quantity', 'Maksimum miktar', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(236, 'tr', 'required', 'Gerekli', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(237, 'tr', 'order_error', 'Sipariş hatası', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(238, 'tr', 'refill_guaranteed', 'Refill Garantili', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(239, 'tr', 'automatic', 'Otomatik', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(240, 'tr', 'please_select_service', 'Lütfen servis seçin!', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(241, 'tr', 'processing', 'İşleniyor', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(245, 'en', 'quick_order', 'Quick Order', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(246, 'en', 'category', 'Category', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(247, 'en', 'select_category_first', 'Select Category First', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(248, 'en', 'service_info', 'Service Info', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(249, 'en', 'estimated_time', 'Estimated Time', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(250, 'en', 'hours', 'Hours', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(251, 'en', 'active_orders', 'Active Orders', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(252, 'en', 'pieces', 'pieces', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(253, 'en', 'view_all_orders', 'View All Orders', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(254, 'en', 'invalid_service', 'Invalid service selection!', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(255, 'en', 'link_required', 'Link field is required!', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(256, 'en', 'minimum_quantity', 'Minimum quantity', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(257, 'en', 'maximum_quantity', 'Maximum quantity', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(258, 'en', 'required', 'Required', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(259, 'en', 'order_error', 'Order error', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(260, 'en', 'refill_guaranteed', 'Refill Guaranteed', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(261, 'en', 'automatic', 'Automatic', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(262, 'en', 'please_select_service', 'Please select a service!', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(263, 'en', 'processing', 'Processing', '2026-01-26 10:09:36', '2026-01-26 10:09:36'),
(267, 'tr', 'create_new_order', 'Yeni Sipariş Oluştur', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(268, 'tr', 'details', 'Detay', '2026-01-26 10:15:20', '2026-02-03 12:43:09'),
(269, 'tr', 'search_service', 'Servis ara...', '2026-01-26 10:15:20', '2026-02-03 12:43:09'),
(270, 'tr', 'link_hint', 'Hizmet alacağınız hesabın veya gönderinin linkini girin', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(271, 'tr', 'order_summary', 'Sipariş Özeti', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(272, 'tr', 'unit_price', 'Birim Fiyat', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(273, 'tr', 'total', 'toplam', '2026-01-26 10:15:20', '2026-01-26 11:41:42'),
(274, 'tr', 'refill', 'Refill', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(275, 'tr', 'service_not_found', 'Servis bulunamadı', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(276, 'tr', 'no_description', 'Bu servis için açıklama bulunmuyor.', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(277, 'tr', 'please_enter_link', 'Lütfen link girin!', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(278, 'tr', 'balance_update_failed', 'Bakiye güncellenemedi!', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(279, 'tr', 'api_error', 'API Hatası', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(280, 'en', 'create_new_order', 'Create New Order', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(281, 'en', 'details', 'Details', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(282, 'en', 'search_service', 'Search service', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(283, 'en', 'link_hint', 'Enter the link of the account or post you want to get service for', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(284, 'en', 'order_summary', 'Order Summary', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(285, 'en', 'unit_price', 'Unit Price', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(286, 'en', 'total', 'total', '2026-01-26 10:15:20', '2026-01-26 11:41:42'),
(287, 'en', 'refill', 'Refill', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(288, 'en', 'service_not_found', 'Service not found', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(289, 'en', 'no_description', 'No description available for this service.', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(290, 'en', 'please_enter_link', 'Please enter a link!', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(291, 'en', 'balance_update_failed', 'Balance could not be updated!', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(292, 'en', 'api_error', 'API Error', '2026-01-26 10:15:20', '2026-01-26 10:15:20'),
(293, 'tr', 'my_orders', 'Siparişlerim', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(294, 'tr', 'update_statuses', 'Durumları Güncelle', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(295, 'tr', 'all', 'Tümü', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(296, 'tr', 'search_order_id_or_link', 'Sipariş ID veya link ara', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(297, 'tr', 'start_date', 'Başlangıç tarihi', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(298, 'tr', 'end_date', 'Bitiş tarihi', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(299, 'tr', 'no_orders_found', 'Sipariş bulunamadı', '2026-01-26 10:19:17', '2026-01-30 11:29:53'),
(300, 'tr', 'no_orders_message', 'Henüz sipariş vermediniz veya filtrelere uygun sipariş yok.', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(301, 'tr', 'place_first_order', 'İlk Siparişini Ver', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(302, 'tr', 'action', 'İşlem', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(303, 'tr', 'detail', 'Detay', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(304, 'tr', 'update_status', 'Durumu Güncelle', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(305, 'tr', 'copy_link', 'Linki Kopyala', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(306, 'tr', 'order_detail', 'Sipariş Detayı', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(307, 'tr', 'api_order_id', 'API Sipariş ID', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(308, 'tr', 'close', 'Kapat', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(309, 'tr', 'order_not_found', 'Sipariş bulunamadı', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(310, 'tr', 'not_api_order', 'API siparişi değil', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(311, 'tr', 'link_copied', 'Link kopyalandı!', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(312, 'tr', 'order_updated', 'Sipariş durumu güncellendi!', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(313, 'tr', 'update_failed', 'Güncelleme başarısız!', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(314, 'tr', 'error_occurred', 'Bir hata oluştu!', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(315, 'tr', 'no_active_orders', 'Güncellenecek aktif sipariş yok!', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(316, 'tr', 'orders_updated', 'sipariş güncellendi!', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(317, 'tr', 'updating', 'Güncelleniyor', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(318, 'tr', 'cancelled_refunded', 'İptal/İade', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(319, 'tr', 'status_error', 'Hata', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(324, 'en', 'my_orders', 'My Orders', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(325, 'en', 'update_statuses', 'Update Statuses', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(326, 'en', 'all', 'All', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(327, 'en', 'search_order_id_or_link', 'Search order ID or link', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(328, 'en', 'start_date', 'Start date', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(329, 'en', 'end_date', 'End date', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(330, 'en', 'no_orders_found', 'No orders found', '2026-01-26 10:19:17', '2026-01-30 11:30:04'),
(331, 'en', 'no_orders_message', 'You have not placed any orders yet or no orders match the filters.', '2026-01-26 10:19:17', '2026-01-26 10:23:23'),
(332, 'en', 'place_first_order', 'Place Your First Order', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(333, 'en', 'action', 'Action', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(334, 'en', 'detail', 'Detail', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(335, 'en', 'update_status', 'Update Status', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(336, 'en', 'copy_link', 'Copy Link', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(337, 'en', 'order_detail', 'Order Detail', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(338, 'en', 'api_order_id', 'API Order ID', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(339, 'en', 'close', 'Close', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(340, 'en', 'order_not_found', 'Order not found', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(341, 'en', 'not_api_order', 'Not an API order', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(342, 'en', 'link_copied', 'Link copied!', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(343, 'en', 'order_updated', 'Order status updated!', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(344, 'en', 'update_failed', 'Update failed!', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(345, 'en', 'error_occurred', 'An error occurred!', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(346, 'en', 'no_active_orders', 'No active orders to update!', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(347, 'en', 'orders_updated', 'orders updated!', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(348, 'en', 'updating', 'Updating', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(349, 'en', 'cancelled_refunded', 'Cancelled/Refunded', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(350, 'en', 'status_error', 'Error', '2026-01-26 10:19:17', '2026-01-26 10:19:17'),
(417, 'tr', 'total_services', 'Toplam Servis', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(418, 'tr', 'lowest_price', 'En Düşük Fiyat', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(419, 'tr', 'search_service_name_or_id', 'Servis adı veya ID ara', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(420, 'tr', 'all_categories', 'Tüm Kategoriler', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(421, 'tr', 'search', 'Ara', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(422, 'tr', 'clear', 'Temizle', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(423, 'tr', 'no_service_match_criteria', 'Arama kriterlerinize uygun servis bulunamadı.', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(424, 'tr', 'show_all_services', 'Tüm Servisleri Göster', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(425, 'tr', 'auto', 'Oto', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(426, 'tr', 'price_1k', 'Fiyat/1K', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(427, 'tr', 'average_time', 'Ortalama Süre', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(428, 'tr', 'order_now', 'Sipariş', '2026-01-26 10:26:06', '2026-02-03 12:43:09'),
(429, 'tr', 'refill_guarantee', 'Refill Garantisi', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(430, 'tr', 'auto_start', 'Otomatik Başlangıç', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(431, 'tr', 'order_24_7', '7/24 Sipariş', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(432, 'tr', 'fast_delivery', 'Hızlı teslimat', '2026-01-26 10:26:06', '2026-02-03 12:43:09'),
(433, 'en', 'total_services', 'Total Services', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(434, 'en', 'lowest_price', 'Lowest Price', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(435, 'en', 'search_service_name_or_id', 'Search service name or ID', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(436, 'en', 'all_categories', 'All Categories', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(437, 'en', 'search', 'Search', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(438, 'en', 'clear', 'Clear', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(439, 'en', 'no_service_match_criteria', 'No services found matching your search criteria.', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(440, 'en', 'show_all_services', 'Show All Services', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(441, 'en', 'auto', 'Auto', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(442, 'en', 'price_1k', 'Price/1K', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(443, 'en', 'average_time', 'Average Time', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(444, 'en', 'order_now', 'Order Now', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(445, 'en', 'refill_guarantee', 'Refill Guarantee', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(446, 'en', 'auto_start', 'Auto Start', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(447, 'en', 'order_24_7', '24/7 Ordering', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(448, 'en', 'fast_delivery', 'Fast Delivery', '2026-01-26 10:26:06', '2026-01-26 10:26:06'),
(449, 'tr', 'your_current_balance', 'Mevcut Bakiyeniz', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(450, 'tr', 'bank_transfer_desc', 'Banka hesabına transfer', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(451, 'tr', 'credit_card_desc', 'Kredi kartı ile öde', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(452, 'tr', 'amount_to_deposit', 'Yüklenecek Tutar', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(453, 'tr', 'no_active_bank_accounts', 'Şu anda aktif banka hesabı bulunmuyor. Lütfen daha sonra tekrar deneyin.', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(454, 'tr', 'select_bank_account', 'Banka Hesabı Seçin', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(455, 'tr', 'account_holder', 'Hesap Sahibi', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(456, 'tr', 'payment_notification', 'Ödeme Bildirimi', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(457, 'tr', 'sender_full_name', 'Gönderen Ad Soyad', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(458, 'tr', 'sender_name_placeholder', 'Banka hesabınızdaki ad soyad', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(459, 'tr', 'transfer_date', 'Transfer Tarihi', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(460, 'tr', 'transfer_time', 'Transfer Saati', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(461, 'tr', 'receipt_optional', 'Dekont / Makbuz (Opsiyonel)', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(462, 'tr', 'click_to_upload_receipt', 'Dekont yüklemek için tıklayın', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(463, 'tr', 'note_optional', 'Not (Opsiyonel)', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(464, 'tr', 'add_note_placeholder', 'Ek bilgi eklemek isterseniz...', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(465, 'tr', 'send_payment_notification', 'Ödeme Bildirimi Gönder', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(466, 'tr', 'secure_payment', 'Güvenli Ödeme', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(467, 'tr', 'iyzico_security_info', 'Kredi kartı bilgileriniz İyzico altyapısı ile güvenle işlenir. Kart bilgileriniz sistemimizde saklanmaz.', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(468, 'tr', 'pay_with_card', 'Kart ile Öde', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(469, 'tr', 'continue_to_secure_payment', 'Güvenli Ödemeye Devam Et', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(470, 'tr', 'credit_card_not_available', 'Kredi kartı ile ödeme şu anda aktif değil.', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(471, 'tr', 'recent_deposits', 'Son Yüklemeler', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(472, 'tr', 'no_payment_history', 'Henüz ödeme geçmişi yok', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(473, 'tr', 'minimum_deposit_amount', 'Minimum yükleme tutarı', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(474, 'tr', 'maximum_deposit_amount', 'Maksimum yükleme tutarı', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(475, 'tr', 'sender_name_required', 'Gönderen adı soyadı zorunludur!', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(476, 'tr', 'transfer_date_time_required', 'Transfer tarihi ve saati zorunludur!', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(477, 'tr', 'invalid_bank_account', 'Geçersiz banka hesabı!', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(478, 'tr', 'allowed_file_types', 'Sadece JPG, PNG, GIF, WEBP ve PDF dosyaları yüklenebilir!', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(479, 'tr', 'max_file_size_10mb', 'Dosya boyutu en fazla 10MB olabilir!', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(480, 'tr', 'payment_notification_received', 'Ödeme bildiriminiz alındı! En kısa sürede kontrol edilip bakiyeniz yüklenecektir.', '2026-01-26 10:29:27', '2026-01-26 10:29:27'),
(482, 'en', 'your_current_balance', 'Your Current Balance', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(483, 'en', 'bank_transfer_desc', 'Transfer to bank account', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(484, 'en', 'credit_card_desc', 'Pay with credit card', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(485, 'en', 'amount_to_deposit', 'Amount to Deposit', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(486, 'en', 'no_active_bank_accounts', 'No active bank accounts available at the moment. Please try again later.', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(487, 'en', 'select_bank_account', 'Select Bank Account', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(488, 'en', 'account_holder', 'Account Holder', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(489, 'en', 'payment_notification', 'Payment Notification', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(490, 'en', 'sender_full_name', 'Sender Full Name', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(491, 'en', 'sender_name_placeholder', 'Name on your bank account', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(492, 'en', 'transfer_date', 'Transfer Date', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(493, 'en', 'transfer_time', 'Transfer Time', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(494, 'en', 'receipt_optional', 'Receipt (Optional)', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(495, 'en', 'click_to_upload_receipt', 'Click to upload receipt', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(496, 'en', 'note_optional', 'Note (Optional)', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(497, 'en', 'add_note_placeholder', 'Add additional information if needed...', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(498, 'en', 'send_payment_notification', 'Send Payment Notification', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(499, 'en', 'secure_payment', 'Secure Payment', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(500, 'en', 'iyzico_security_info', 'Your credit card information is securely processed through iyzico infrastructure. Your card details are not stored in our system.', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(501, 'en', 'pay_with_card', 'Pay with Card', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(502, 'en', 'continue_to_secure_payment', 'Continue to Secure Payment', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(503, 'en', 'credit_card_not_available', 'Credit card payment is currently not available.', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(504, 'en', 'recent_deposits', 'Recent Deposits', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(505, 'en', 'no_payment_history', 'No payment history yet', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(506, 'en', 'minimum_deposit_amount', 'Minimum deposit amount', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(507, 'en', 'maximum_deposit_amount', 'Maximum deposit amount', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(508, 'en', 'sender_name_required', 'Sender name is required!', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(509, 'en', 'transfer_date_time_required', 'Transfer date and time are required!', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(510, 'en', 'invalid_bank_account', 'Invalid bank account!', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(511, 'en', 'allowed_file_types', 'Only JPG, PNG, GIF, WEBP and PDF files are allowed!', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(512, 'en', 'max_file_size_10mb', 'File size can be maximum 10MB!', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(513, 'en', 'payment_notification_received', 'Your payment notification has been received! Your balance will be credited after verification.', '2026-01-26 10:29:28', '2026-01-26 10:29:28'),
(515, 'tr', 'secure_payment_with_iyzico', 'İyzico altyapısı ile güvenli ödeme', '2026-01-26 10:31:38', '2026-01-26 10:31:38'),
(516, 'tr', 'payment_could_not_start', 'Ödeme Başlatılamadı', '2026-01-26 10:31:38', '2026-01-26 10:31:38'),
(517, 'tr', 'go_back', 'Geri Dön', '2026-01-26 10:31:38', '2026-01-26 10:31:38'),
(518, 'tr', 'card_info_security_message', 'Kart bilgileriniz İyzico tarafından güvenle işlenir. Kart bilgileriniz sistemimizde saklanmaz.', '2026-01-26 10:31:38', '2026-01-26 10:31:38'),
(519, 'tr', 'payment_form_error', 'Ödeme formu oluşturulamadı.', '2026-01-26 10:31:38', '2026-01-26 10:31:38'),
(520, 'tr', 'an_error_occurred', 'Bir hata oluştu', '2026-01-26 10:31:38', '2026-01-26 10:31:38'),
(521, 'en', 'secure_payment_with_iyzico', 'Secure payment with iyzico infrastructure', '2026-01-26 10:31:38', '2026-01-26 10:31:38'),
(522, 'en', 'payment_could_not_start', 'Payment Could Not Start', '2026-01-26 10:31:38', '2026-01-26 10:31:38'),
(523, 'en', 'go_back', 'Go Back', '2026-01-26 10:31:38', '2026-01-26 10:31:38'),
(524, 'en', 'card_info_security_message', 'Your card information is securely processed by iyzico. Your card details are not stored in our system.', '2026-01-26 10:31:38', '2026-01-26 10:31:38'),
(525, 'en', 'payment_form_error', 'Payment form could not be created.', '2026-01-26 10:31:38', '2026-01-26 10:31:38'),
(526, 'en', 'an_error_occurred', 'An error occurred', '2026-01-26 10:31:38', '2026-01-26 10:31:38'),
(527, 'tr', 'total_deposits', 'Toplam Yükleme', '2026-01-26 10:35:24', '2026-01-26 10:35:24'),
(528, 'tr', 'transaction_type', 'İşlem Tipi', '2026-01-26 10:35:24', '2026-01-26 10:35:24'),
(529, 'tr', 'balance_deposit', 'Bakiye Yükleme', '2026-01-26 10:35:24', '2026-01-26 10:35:24'),
(530, 'tr', 'filter', 'Filtrele', '2026-01-26 10:35:24', '2026-01-26 10:35:24'),
(531, 'tr', 'transactions', 'işlem', '2026-01-26 10:35:24', '2026-01-26 10:35:24'),
(532, 'tr', 'no_transactions_found', 'İşlem Bulunamadı', '2026-01-26 10:35:24', '2026-01-26 10:35:24'),
(533, 'tr', 'no_transactions_message', 'Henüz hiç işlem yapmadınız veya filtrelere uygun işlem yok.', '2026-01-26 10:35:24', '2026-01-26 10:35:24'),
(534, 'tr', 'order', 'Sipariş', '2026-01-26 10:35:24', '2026-01-26 10:35:24'),
(535, 'en', 'total_deposits', 'Total Deposits', '2026-01-26 10:35:24', '2026-01-26 10:35:24'),
(536, 'en', 'transaction_type', 'Transaction Type', '2026-01-26 10:35:24', '2026-01-26 10:35:24'),
(537, 'en', 'balance_deposit', 'Balance Deposit', '2026-01-26 10:35:24', '2026-01-26 10:35:24'),
(538, 'en', 'filter', 'Filter', '2026-01-26 10:35:24', '2026-01-26 10:35:24'),
(539, 'en', 'transactions', 'transactions', '2026-01-26 10:35:24', '2026-01-26 10:35:24'),
(540, 'en', 'no_transactions_found', 'No Transactions Found', '2026-01-26 10:35:24', '2026-01-26 10:35:24'),
(541, 'en', 'no_transactions_message', 'You have not made any transactions yet or no transactions match the filters.', '2026-01-26 10:35:24', '2026-01-26 10:35:24'),
(542, 'en', 'order', 'Order', '2026-01-26 10:35:24', '2026-01-26 10:35:24'),
(543, 'tr', 'my_profile', 'Profilim', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(544, 'tr', 'fill_all_password_fields', 'Tüm şifre alanlarını doldurun!', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(545, 'tr', 'password_min_length', 'Yeni şifre en az 8 karakter olmalıdır!', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(546, 'tr', 'passwords_not_match', 'Yeni şifreler eşleşmiyor!', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(547, 'tr', 'current_password_wrong', 'Mevcut şifreniz hatalı!', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(548, 'tr', 'password_changed_success', 'Şifreniz başarıyla değiştirildi!', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(549, 'tr', 'completed', 'Tamamlanan', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(550, 'tr', 'spending', 'Harcama', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(551, 'tr', 'registration_date', 'Kayıt Tarihi', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(552, 'tr', 'account_status', 'Hesap Durumu', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(553, 'tr', 'active', 'Aktif', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(554, 'tr', 'account_info', 'Hesap Bilgileri', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(555, 'tr', 'email_address', 'E-posta Adresi', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(556, 'tr', 'account_type', 'Hesap Tipi', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(557, 'tr', 'your_api_key', 'API Anahtarınız', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(558, 'tr', 'copy', 'Kopyala', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(559, 'tr', 'api_key_warning', 'Bu anahtarı kullanarak API üzerinden sipariş verebilirsiniz. Anahtarınızı kimseyle paylaşmayın!', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(560, 'tr', 'security_tip', 'Güvenlik Önerisi', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(561, 'tr', 'password_requirements', 'Güçlü bir şifre kullanın. Şifreniz en az 8 karakter uzunluğunda olmalı ve harf, rakam içermelidir. Şifrenizi kimseyle paylaşmayın.', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(562, 'tr', 'enter_current_password', 'Mevcut şifrenizi girin', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(563, 'tr', 'enter_new_password', 'Yeni şifrenizi girin', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(564, 'tr', 'confirm_new_password', 'Yeni Şifre (Tekrar)', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(565, 'tr', 'reenter_new_password', 'Yeni şifrenizi tekrar girin', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(571, 'en', 'my_profile', 'My Profile', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(572, 'en', 'fill_all_password_fields', 'Fill in all password fields!', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(573, 'en', 'password_min_length', 'New password must be at least 8 characters!', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(574, 'en', 'passwords_not_match', 'New passwords do not match!', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(575, 'en', 'current_password_wrong', 'Your current password is incorrect!', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(576, 'en', 'password_changed_success', 'Your password has been changed successfully!', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(577, 'en', 'completed', 'Completed', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(578, 'en', 'spending', 'Spending', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(579, 'en', 'registration_date', 'Registration Date', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(580, 'en', 'account_status', 'Account Status', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(581, 'en', 'active', 'Active', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(582, 'en', 'account_info', 'Account Info', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(583, 'en', 'email_address', 'Email Address', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(584, 'en', 'account_type', 'Account Type', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(585, 'en', 'your_api_key', 'Your API Key', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(586, 'en', 'copy', 'Copy', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(587, 'en', 'api_key_warning', 'You can use this key to place orders via API. Do not share your key with anyone!', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(588, 'en', 'security_tip', 'Security Tip', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(589, 'en', 'password_requirements', 'Use a strong password. Your password should be at least 8 characters long and contain letters and numbers. Do not share your password with anyone.', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(590, 'en', 'enter_current_password', 'Enter your current password', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(591, 'en', 'enter_new_password', 'Enter your new password', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(592, 'en', 'confirm_new_password', 'New Password (Confirm)', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(593, 'en', 'reenter_new_password', 'Re-enter your new password', '2026-01-26 10:38:07', '2026-01-26 10:38:07'),
(599, 'tr', 'support_center', 'Destek Merkezi', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(600, 'tr', 'subject_required', 'Konu alanı zorunludur', '2026-01-26 10:41:41', '2026-01-30 11:29:53'),
(601, 'tr', 'message_required', 'Mesaj alanı zorunludur', '2026-01-26 10:41:41', '2026-01-30 11:29:53'),
(602, 'tr', 'ticket_not_found', 'Destek talebi bulunamadı', '2026-01-26 10:41:41', '2026-01-30 11:29:53'),
(603, 'tr', 'ticket_created_success', 'Destek talebiniz başarıyla oluşturuldu', '2026-01-26 10:41:41', '2026-01-30 11:29:53'),
(604, 'tr', 'message_sent_success', 'Mesajınız başarıyla gönderildi', '2026-01-26 10:41:41', '2026-01-30 11:29:53'),
(605, 'tr', 'total_tickets', 'Toplam Talep', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(606, 'tr', 'ticket_status_open', 'Açık', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(607, 'tr', 'ticket_status_answered', 'Yanıtlandı', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(608, 'tr', 'ticket_status_closed', 'Kapalı', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(609, 'tr', 'my_tickets', 'Taleplerim', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(610, 'tr', 'no_support_tickets', 'Henüz destek talebiniz yok', '2026-01-26 10:41:41', '2026-01-30 11:29:53'),
(611, 'tr', 'new', 'yeni', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(612, 'tr', 'priority_low', 'Düşük', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(613, 'tr', 'priority_medium', 'Orta', '2026-01-26 10:41:41', '2026-01-30 11:29:53'),
(614, 'tr', 'priority_high', 'Yüksek', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(615, 'tr', 'support_team', 'Destek Ekibi', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(616, 'tr', 'this_ticket_closed', 'Bu talep kapatılmıştır', '2026-01-26 10:41:41', '2026-01-30 11:29:53'),
(617, 'tr', 'write_your_message', 'Mesajınızı yazın', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(618, 'tr', 'attach_file', 'Dosya Ekle', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(619, 'tr', 'support_welcome_message', 'Bir sorun mu yaşıyorsunuz? Size yardımcı olmaktan mutluluk duyarız.', '2026-01-26 10:41:41', '2026-01-30 11:29:53'),
(620, 'tr', 'create_new_support_ticket', 'Yeni Destek Talebi Oluştur', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(621, 'tr', 'new_support_ticket', 'Yeni Destek Talebi', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(622, 'tr', 'select_order', 'Sipariş seçin', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(623, 'tr', 'priority', 'Öncelik', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(624, 'tr', 'briefly_describe_issue', 'Sorununuzu kısaca açıklayın', '2026-01-26 10:41:41', '2026-01-30 11:29:53'),
(625, 'tr', 'describe_issue_detail', 'Sorununuzu detaylı bir şekilde anlatın', '2026-01-26 10:41:41', '2026-01-30 11:29:53'),
(626, 'tr', 'screenshot', 'Ekran Görüntüsü', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(627, 'tr', 'optional', 'isteğe bağlı', '2026-01-26 10:41:41', '2026-01-30 11:29:53'),
(628, 'tr', 'click_to_select_file', 'Dosya seçmek için tıklayın', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(629, 'tr', 'submit_ticket', 'Talebi Gönder', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(630, 'tr', 'attachment', 'Ek Dosya', '2026-01-26 10:41:41', '2026-01-30 11:29:53'),
(631, 'tr', 'only_images_allowed', 'Sadece resim dosyaları yüklenebilir', '2026-01-26 10:41:41', '2026-01-30 11:29:53'),
(632, 'tr', 'max_file_size_5mb', 'Maksimum dosya boyutu 5MB olabilir', '2026-01-26 10:41:41', '2026-01-30 11:29:53');
INSERT INTO `translations` (`id`, `lang_code`, `translation_key`, `translation_value`, `created_at`, `updated_at`) VALUES
(637, 'en', 'support_center', 'Support Center', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(638, 'en', 'subject_required', 'Subject field is required', '2026-01-26 10:41:41', '2026-01-30 11:30:04'),
(639, 'en', 'message_required', 'Message field is required', '2026-01-26 10:41:41', '2026-01-30 11:30:04'),
(640, 'en', 'ticket_not_found', 'Support ticket not found', '2026-01-26 10:41:41', '2026-01-30 11:30:04'),
(641, 'en', 'ticket_created_success', 'Your support ticket has been created successfully', '2026-01-26 10:41:41', '2026-01-30 11:30:04'),
(642, 'en', 'message_sent_success', 'Your message has been sent successfully', '2026-01-26 10:41:41', '2026-01-30 11:30:04'),
(643, 'en', 'total_tickets', 'Total Tickets', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(644, 'en', 'ticket_status_open', 'Open', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(645, 'en', 'ticket_status_answered', 'Answered', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(646, 'en', 'ticket_status_closed', 'Closed', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(647, 'en', 'my_tickets', 'My Tickets', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(648, 'en', 'no_support_tickets', 'You have no support tickets yet', '2026-01-26 10:41:41', '2026-01-30 11:30:04'),
(649, 'en', 'new', 'new', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(650, 'en', 'priority_low', 'Low', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(651, 'en', 'priority_medium', 'Medium', '2026-01-26 10:41:41', '2026-01-30 11:30:04'),
(652, 'en', 'priority_high', 'High', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(653, 'en', 'support_team', 'Support Team', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(654, 'en', 'this_ticket_closed', 'This ticket is closed', '2026-01-26 10:41:41', '2026-01-30 11:30:04'),
(655, 'en', 'write_your_message', 'Write your message', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(656, 'en', 'attach_file', 'Attach File', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(657, 'en', 'support_welcome_message', 'Having an issue? We are happy to help you.', '2026-01-26 10:41:41', '2026-01-30 11:30:04'),
(658, 'en', 'create_new_support_ticket', 'Create New Support Ticket', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(659, 'en', 'new_support_ticket', 'New Support Ticket', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(660, 'en', 'select_order', 'Select order', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(661, 'en', 'priority', 'Priority', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(662, 'en', 'briefly_describe_issue', 'Briefly describe your issue', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(663, 'en', 'describe_issue_detail', 'Describe your issue in detail', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(664, 'en', 'screenshot', 'Screenshot', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(665, 'en', 'optional', 'optional', '2026-01-26 10:41:41', '2026-01-30 11:30:04'),
(666, 'en', 'click_to_select_file', 'Click to select file', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(667, 'en', 'submit_ticket', 'Submit Ticket', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(668, 'en', 'attachment', 'Attachment', '2026-01-26 10:41:41', '2026-01-26 10:41:41'),
(669, 'en', 'only_images_allowed', 'Only image files are allowed', '2026-01-26 10:41:41', '2026-01-30 11:30:04'),
(670, 'en', 'max_file_size_5mb', 'Maximum file size is 5MB', '2026-01-26 10:41:41', '2026-01-30 11:30:04'),
(745, 'tr', 'referral', 'Referans', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(746, 'tr', 'referral_program', 'Referans Programı', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(747, 'tr', 'referral_dashboard', 'Referans Paneli', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(748, 'tr', 'your_referral_link', 'Referans Linkiniz', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(749, 'tr', 'your_referral_code', 'Referans Kodunuz', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(750, 'tr', 'share_and_earn', 'Paylaş ve Kazan', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(751, 'tr', 'total_referrals', 'Toplam Referans', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(752, 'tr', 'active_referrals', 'Aktif Referanslar', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(753, 'tr', 'total_earnings', 'Toplam Kazanç', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(754, 'tr', 'pending_earnings', 'Bekleyen Kazanç', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(755, 'tr', 'paid_earnings', 'Ödenen Kazanç', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(756, 'tr', 'this_month_earnings', 'Bu Ay Kazanç', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(757, 'tr', 'commission_rate', 'Komisyon Oranı', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(758, 'tr', 'earnings_per_referral', 'Referans Başına Kazanç', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(759, 'tr', 'referred_users', 'Referans Olan Kullanıcılar', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(760, 'tr', 'referral_earnings', 'Referans Kazançları', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(761, 'tr', 'earning_history', 'Kazanç Geçmişi', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(762, 'tr', 'user', 'Kullanıcı', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(763, 'tr', 'joined_date', 'Kayıt Tarihi', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(764, 'tr', 'your_earnings', 'Sizin Kazancınız', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(765, 'tr', 'order_amount', 'Sipariş Tutarı', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(766, 'tr', 'commission', 'Komisyon', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(767, 'tr', 'earned_amount', 'Kazanılan Tutar', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(768, 'tr', 'status_paid', 'Ödendi', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(769, 'tr', 'copy_code', 'Kodu Kopyala', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(770, 'tr', 'copied', 'Kopyalandı!', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(771, 'tr', 'share_on_facebook', 'Facebook\'ta Paylaş', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(772, 'tr', 'share_on_twitter', 'Twitter\'da Paylaş', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(773, 'tr', 'share_on_whatsapp', 'WhatsApp\'ta Paylaş', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(774, 'tr', 'share_on_telegram', 'Telegram\'da Paylaş', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(775, 'tr', 'withdraw_earnings', 'Kazancı Çek', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(776, 'tr', 'transfer_to_balance', 'Bakiyeye Aktar', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(777, 'tr', 'referral_how_it_works', 'Nasıl Çalışır?', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(778, 'tr', 'referral_step_1', 'Referans linkinizi arkadaşlarınızla paylaşın', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(779, 'tr', 'referral_step_2', 'Arkadaşlarınız linkinizle kayıt olsun', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(780, 'tr', 'referral_step_3', 'Arkadaşlarınız sipariş verdiğinde komisyon kazanın', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(781, 'tr', 'referral_step_4', 'Kazançlarınızı bakiyenize aktarın', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(782, 'tr', 'referral_terms', 'Referans Programı Koşulları', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(783, 'tr', 'referral_commission_info', 'Her referansınızın siparişlerinden %:rate komisyon kazanırsınız.', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(784, 'tr', 'referral_min_withdraw_info', 'Minimum çekim tutarı: :amount', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(785, 'tr', 'referral_no_limit', 'Referans sayısında limit yoktur', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(786, 'tr', 'referral_lifetime_earnings', 'Referanslarınızdan ömür boyu kazanç elde edersiniz', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(787, 'tr', 'referral_link_copied', 'Referans linki panoya kopyalandı!', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(788, 'tr', 'referral_code_copied', 'Referans kodu panoya kopyalandı!', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(789, 'tr', 'earnings_transferred', 'Kazancınız bakiyenize aktarıldı!', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(790, 'tr', 'transfer_success', ':amount bakiyenize aktarıldı!', '2026-01-26 11:35:52', '2026-01-26 11:41:42'),
(791, 'tr', 'insufficient_earnings', 'Yetersiz kazanç! Minimum :amount gerekli.', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(792, 'tr', 'no_pending_earnings', 'Aktarılacak bekleyen kazanç bulunmuyor.', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(793, 'tr', 'transfer_failed', 'Aktarım başarısız oldu. Lütfen tekrar deneyin.', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(794, 'tr', 'no_referrals_yet', 'Henüz referansınız yok', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(795, 'tr', 'no_referrals_desc', 'Referans linkinizi paylaşarak kazanmaya başlayın!', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(796, 'tr', 'no_earnings_yet', 'Henüz kazancınız yok', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(797, 'tr', 'no_earnings_desc', 'Referanslarınız sipariş verdikçe kazanç elde edeceksiniz.', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(798, 'tr', 'start_sharing', 'Paylaşmaya Başla', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(799, 'tr', 'referral_details', 'Referans Detayları', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(800, 'tr', 'referred_by', 'Referans Veren', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(801, 'tr', 'referral_date', 'Referans Tarihi', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(802, 'tr', 'first_order_date', 'İlk Sipariş Tarihi', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(803, 'tr', 'last_order_date', 'Son Sipariş Tarihi', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(804, 'tr', 'quick_share', 'Hızlı Paylaşım', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(805, 'tr', 'referral_stats', 'Referans İstatistikleri', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(806, 'tr', 'top_referrers', 'En Çok Referans Verenler', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(807, 'tr', 'recent_referrals', 'Son Referanslar', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(808, 'tr', 'recent_earnings', 'Son Kazançlar', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(814, 'en', 'referral', 'Referral', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(815, 'en', 'referral_program', 'Referral Program', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(816, 'en', 'referral_dashboard', 'Referral Dashboard', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(817, 'en', 'your_referral_link', 'Your Referral Link', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(818, 'en', 'your_referral_code', 'Your Referral Code', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(819, 'en', 'share_and_earn', 'Share and Earn', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(820, 'en', 'total_referrals', 'Total Referrals', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(821, 'en', 'active_referrals', 'Active Referrals', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(822, 'en', 'total_earnings', 'Total Earnings', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(823, 'en', 'pending_earnings', 'Pending Earnings', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(824, 'en', 'paid_earnings', 'Paid Earnings', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(825, 'en', 'this_month_earnings', 'This Month Earnings', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(826, 'en', 'commission_rate', 'Commission Rate', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(827, 'en', 'earnings_per_referral', 'Earnings Per Referral', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(828, 'en', 'referred_users', 'Referred Users', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(829, 'en', 'referral_earnings', 'Referral Earnings', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(830, 'en', 'earning_history', 'Earning History', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(831, 'en', 'user', 'User', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(832, 'en', 'joined_date', 'Joined Date', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(833, 'en', 'your_earnings', 'Your Earnings', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(834, 'en', 'order_amount', 'Order Amount', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(835, 'en', 'commission', 'Commission', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(836, 'en', 'earned_amount', 'Earned Amount', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(837, 'en', 'status_paid', 'Paid', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(838, 'en', 'copy_code', 'Copy Code', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(839, 'en', 'copied', 'Copied!', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(840, 'en', 'share_on_facebook', 'Share on Facebook', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(841, 'en', 'share_on_twitter', 'Share on Twitter', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(842, 'en', 'share_on_whatsapp', 'Share on WhatsApp', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(843, 'en', 'share_on_telegram', 'Share on Telegram', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(844, 'en', 'withdraw_earnings', 'Withdraw Earnings', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(845, 'en', 'transfer_to_balance', 'Transfer to Balance', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(846, 'en', 'referral_how_it_works', 'How It Works?', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(847, 'en', 'referral_step_1', 'Share your referral link with friends', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(848, 'en', 'referral_step_2', 'Your friends sign up using your link', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(849, 'en', 'referral_step_3', 'Earn commission when they place orders', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(850, 'en', 'referral_step_4', 'Transfer your earnings to your balance', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(851, 'en', 'referral_terms', 'Referral Program Terms', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(852, 'en', 'referral_commission_info', 'You earn :rate% commission from your referrals\' orders.', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(853, 'en', 'referral_min_withdraw_info', 'Minimum withdrawal amount: :amount', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(854, 'en', 'referral_no_limit', 'No limit on number of referrals', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(855, 'en', 'referral_lifetime_earnings', 'Earn lifetime commissions from your referrals', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(856, 'en', 'referral_link_copied', 'Referral link copied to clipboard!', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(857, 'en', 'referral_code_copied', 'Referral code copied to clipboard!', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(858, 'en', 'earnings_transferred', 'Your earnings have been transferred to your balance!', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(859, 'en', 'transfer_success', ':amount transferred to your balance!', '2026-01-26 11:35:52', '2026-01-26 11:41:42'),
(860, 'en', 'insufficient_earnings', 'Insufficient earnings! Minimum :amount required.', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(861, 'en', 'no_pending_earnings', 'No pending earnings to transfer.', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(862, 'en', 'transfer_failed', 'Transfer failed. Please try again.', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(863, 'en', 'no_referrals_yet', 'No referrals yet', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(864, 'en', 'no_referrals_desc', 'Start earning by sharing your referral link!', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(865, 'en', 'no_earnings_yet', 'No earnings yet', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(866, 'en', 'no_earnings_desc', 'You will earn when your referrals place orders.', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(867, 'en', 'start_sharing', 'Start Sharing', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(868, 'en', 'referral_details', 'Referral Details', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(869, 'en', 'referred_by', 'Referred By', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(870, 'en', 'referral_date', 'Referral Date', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(871, 'en', 'first_order_date', 'First Order Date', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(872, 'en', 'last_order_date', 'Last Order Date', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(873, 'en', 'quick_share', 'Quick Share', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(874, 'en', 'referral_stats', 'Referral Statistics', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(875, 'en', 'top_referrers', 'Top Referrers', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(876, 'en', 'recent_referrals', 'Recent Referrals', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(877, 'en', 'recent_earnings', 'Recent Earnings', '2026-01-26 11:35:52', '2026-01-26 11:35:52'),
(883, 'tr', 'transferred_earnings', 'Aktarılan Kazanç', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(884, 'tr', 'available_to_transfer', 'Aktarılabilir Tutar', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(885, 'tr', 'referral_history', 'Referans Geçmişi', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(886, 'tr', 'bonus', 'Bonus', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(887, 'tr', 'deleted_user', 'Silinmiş Kullanıcı', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(888, 'tr', 'referral_bonus_info', 'Arkadaşlarınızı davet edin, her kayıt olan arkadaşınız için :amount kazanın!', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(889, 'tr', 'referral_min_transfer_info', 'Minimum aktarım tutarı: :amount', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(890, 'tr', 'min_transfer_required', 'Minimum :amount gerekli', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(891, 'tr', 'referral_share_text', ':site sitesine sen de katıl!', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(892, 'tr', 'referral_step_1_title', 'Linkinizi Paylaşın', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(893, 'tr', 'referral_step_1_desc', 'Referans linkinizi arkadaşlarınızla paylaşın', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(894, 'tr', 'referral_step_2_title', 'Arkadaşınız Kayıt Olsun', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(895, 'tr', 'referral_step_2_desc', 'Arkadaşınız linkiniz ile siteye kayıt olsun', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(896, 'tr', 'referral_step_3_title', 'Bonus Kazanın', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(897, 'tr', 'referral_step_3_desc', 'Her kayıt için :amount bonus kazanın', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(898, 'tr', 'referral_step_4_title', 'Bakiyenize Aktarın', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(899, 'tr', 'referral_step_4_desc', 'Kazançlarınızı bakiyenize aktararak kullanın', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(926, 'en', 'transferred_earnings', 'Transferred Earnings', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(927, 'en', 'available_to_transfer', 'Available to Transfer', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(928, 'en', 'referral_history', 'Referral History', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(929, 'en', 'bonus', 'Bonus', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(930, 'en', 'deleted_user', 'Deleted User', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(931, 'en', 'referral_bonus_info', 'Invite your friends and earn :amount for each friend who signs up!', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(932, 'en', 'referral_min_transfer_info', 'Minimum transfer amount: :amount', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(933, 'en', 'min_transfer_required', 'Minimum :amount required', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(934, 'en', 'referral_share_text', 'Join :site today!', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(935, 'en', 'referral_step_1_title', 'Share Your Link', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(936, 'en', 'referral_step_1_desc', 'Share your referral link with friends', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(937, 'en', 'referral_step_2_title', 'Friend Signs Up', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(938, 'en', 'referral_step_2_desc', 'Your friend registers using your link', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(939, 'en', 'referral_step_3_title', 'Earn Bonus', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(940, 'en', 'referral_step_3_desc', 'Earn :amount for each registration', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(941, 'en', 'referral_step_4_title', 'Transfer to Balance', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(942, 'en', 'referral_step_4_desc', 'Transfer your earnings to use them', '2026-01-26 11:41:42', '2026-01-26 11:41:42'),
(969, 'tr', 'referral_program_closed', 'Referans Programı Kapalı', '2026-01-26 12:08:48', '2026-01-26 12:08:48'),
(970, 'tr', 'referral_program_closed_desc', 'Referans programı şu anda aktif değil. Daha sonra tekrar kontrol edin veya destek ekibimizle iletişime geçin.', '2026-01-26 12:08:48', '2026-01-26 12:08:48'),
(971, 'tr', 'back_to_dashboard', 'Ana Sayfaya Dön', '2026-01-26 12:08:48', '2026-01-26 12:08:48'),
(972, 'en', 'referral_program_closed', 'Referral Program Closed', '2026-01-26 12:08:48', '2026-01-26 12:08:48'),
(973, 'en', 'referral_program_closed_desc', 'The referral program is currently not active. Please check back later or contact our support team.', '2026-01-26 12:08:48', '2026-01-26 12:08:48'),
(974, 'en', 'back_to_dashboard', 'Back to Dashboard', '2026-01-26 12:08:48', '2026-01-26 12:08:48'),
(975, 'tr', 'per_referral', 'Referans Başına', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(976, 'tr', 'referral_invite_text', 'Arkadaşlarınızı davet edin, her kayıt olan arkadaşınız için :amount kazanın!', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(977, 'tr', 'min_transfer_amount', 'Minimum aktarım tutarı', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(978, 'tr', 'min_required', 'Minimum :amount gerekli', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(979, 'tr', 'transfer_error', 'Aktarım başarısız oldu. Lütfen tekrar deneyin.', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(980, 'tr', 'pending_earnings_stat', 'Bekleyen Kazanç', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(981, 'tr', 'status_transferred', 'Aktarıldı', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(982, 'tr', 'how_it_works', 'Nasıl Çalışır?', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(983, 'tr', 'step1_title', 'Linkinizi Paylaşın', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(984, 'tr', 'step1_desc', 'Referans linkinizi arkadaşlarınızla paylaşın', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(985, 'tr', 'step2_title', 'Arkadaşınız Kayıt Olsun', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(986, 'tr', 'step2_desc', 'Arkadaşınız linkiniz ile siteye kayıt olsun', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(987, 'tr', 'step3_title', 'Bonus Kazanın', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(988, 'tr', 'step3_desc', 'Her kayıt için :amount bonus kazanın', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(989, 'tr', 'step4_title', 'Bakiyenize Aktarın', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(990, 'tr', 'step4_desc', 'Kazançlarınızı bakiyenize aktararak kullanın', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(1019, 'en', 'per_referral', 'Per Referral', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(1020, 'en', 'referral_invite_text', 'Invite your friends and earn :amount for each friend who signs up!', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(1021, 'en', 'min_transfer_amount', 'Minimum transfer amount', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(1022, 'en', 'min_required', 'Minimum :amount required', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(1023, 'en', 'transfer_error', 'Transfer failed. Please try again.', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(1024, 'en', 'pending_earnings_stat', 'Pending Earnings', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(1025, 'en', 'status_transferred', 'Transferred', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(1026, 'en', 'how_it_works', 'How It Works?', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(1027, 'en', 'step1_title', 'Share Your Link', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(1028, 'en', 'step1_desc', 'Share your referral link with friends', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(1029, 'en', 'step2_title', 'Friend Signs Up', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(1030, 'en', 'step2_desc', 'Your friend registers using your link', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(1031, 'en', 'step3_title', 'Earn Bonus', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(1032, 'en', 'step3_desc', 'Earn :amount for each registration', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(1033, 'en', 'step4_title', 'Transfer to Balance', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(1034, 'en', 'step4_desc', 'Transfer your earnings to use them', '2026-01-26 12:09:13', '2026-01-26 12:09:13'),
(1057, 'tr', 'daily_bonus', 'Günlük Bonus', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1058, 'tr', 'daily_bonus_title', 'Günlük Bonus', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1059, 'tr', 'claim_bonus', 'Bonus Al', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1060, 'tr', 'bonus_claimed', 'Bonus Alındı', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1061, 'tr', 'bonus_already_claimed', 'Bugünkü bonusunuzu zaten aldınız', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1062, 'tr', 'bonus_claim_success', 'Tebrikler! Günlük bonusunuz hesabınıza eklendi', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1063, 'tr', 'next_bonus_available', 'Sonraki bonus zamanı', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1064, 'tr', 'bonus_amount', 'Bonus Miktarı', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1065, 'tr', 'consecutive_days', 'Ardışık Gün', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1066, 'tr', 'bonus_streak', 'Bonus Serisi', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1067, 'tr', 'current_streak', 'Mevcut Seri', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1068, 'tr', 'longest_streak', 'En Uzun Seri', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1069, 'tr', 'total_bonus_earned', 'Toplam Kazanılan Bonus', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1070, 'tr', 'days', 'gün', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1071, 'tr', 'minutes', 'dakika', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1072, 'tr', 'seconds', 'saniye', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1073, 'tr', 'bonus_history', 'Bonus Geçmişi', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1074, 'tr', 'no_bonus_history', 'Henüz bonus geçmişiniz bulunmuyor', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1075, 'tr', 'day', 'Gün', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1076, 'tr', 'come_back_tomorrow', 'Yarın tekrar gelin!', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1077, 'tr', 'daily_bonus_description', 'Her gün giriş yaparak bonus kazanın. Ardışık günlerde bonus miktarı artar!', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1079, 'en', 'daily_bonus', 'Daily Bonus', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1080, 'en', 'daily_bonus_title', 'Daily Bonus', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1081, 'en', 'claim_bonus', 'Claim Bonus', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1082, 'en', 'bonus_claimed', 'Bonus Claimed', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1083, 'en', 'bonus_already_claimed', 'You have already claimed your bonus today', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1084, 'en', 'bonus_claim_success', 'Congratulations! Your daily bonus has been added to your account', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1085, 'en', 'next_bonus_available', 'Next bonus available', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1086, 'en', 'bonus_amount', 'Bonus Amount', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1087, 'en', 'consecutive_days', 'Consecutive Days', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1088, 'en', 'bonus_streak', 'Bonus Streak', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1089, 'en', 'current_streak', 'Current Streak', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1090, 'en', 'longest_streak', 'Longest Streak', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1091, 'en', 'total_bonus_earned', 'Total Bonus Earned', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1092, 'en', 'days', 'days', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1093, 'en', 'minutes', 'minutes', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1094, 'en', 'seconds', 'seconds', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1095, 'en', 'bonus_history', 'Bonus History', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1096, 'en', 'no_bonus_history', 'No bonus history yet', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1097, 'en', 'day', 'Day', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1098, 'en', 'come_back_tomorrow', 'Come back tomorrow!', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1099, 'en', 'daily_bonus_description', 'Earn bonus by logging in every day. Bonus amount increases on consecutive days!', '2026-01-27 22:52:47', '2026-01-27 22:52:47'),
(1101, 'tr', 'bonus_inactive', 'Günlük bonus sistemi şu anda aktif değil', '2026-01-27 22:54:52', '2026-01-27 22:54:52'),
(1102, 'tr', 'bonus_cooldown', 'Bir sonraki bonus için beklemeniz gereken süre', '2026-01-27 22:54:52', '2026-01-27 22:54:52'),
(1103, 'tr', 'claim_your_bonus', 'Bonusunuzu Alın', '2026-01-27 22:54:52', '2026-01-27 22:54:52'),
(1104, 'tr', 'bonus_ready', 'Bonus Hazır!', '2026-01-27 22:54:52', '2026-01-27 22:54:52'),
(1105, 'tr', 'streak_bonus', 'Seri Bonusu', '2026-01-27 22:54:52', '2026-01-27 22:54:52'),
(1106, 'tr', 'day_streak', 'günlük seri', '2026-01-27 22:54:52', '2026-01-27 22:54:52'),
(1107, 'en', 'bonus_inactive', 'Daily bonus system is currently inactive', '2026-01-27 22:54:52', '2026-01-27 22:54:52'),
(1108, 'en', 'bonus_cooldown', 'Time remaining until next bonus', '2026-01-27 22:54:52', '2026-01-27 22:54:52'),
(1109, 'en', 'claim_your_bonus', 'Claim Your Bonus', '2026-01-27 22:54:52', '2026-01-27 22:54:52'),
(1110, 'en', 'bonus_ready', 'Bonus Ready!', '2026-01-27 22:54:52', '2026-01-27 22:54:52'),
(1111, 'en', 'streak_bonus', 'Streak Bonus', '2026-01-27 22:54:52', '2026-01-27 22:54:52'),
(1112, 'en', 'day_streak', 'day streak', '2026-01-27 22:54:52', '2026-01-27 22:54:52'),
(1113, 'tr', 'total_claims', 'Toplam Bonus Alımı', '2026-01-27 23:02:14', '2026-01-27 23:02:14'),
(1114, 'tr', 'come_back_later', 'Daha Sonra Tekrar Gelin!', '2026-01-27 23:02:14', '2026-01-27 23:02:14'),
(1115, 'en', 'total_claims', 'Total Claims', '2026-01-27 23:02:14', '2026-01-27 23:02:14'),
(1116, 'en', 'come_back_later', 'Come Back Later!', '2026-01-27 23:02:14', '2026-01-27 23:02:14'),
(1119, 'tr', 'bonus_earnings', 'Bonus Kazancı', '2026-01-27 23:39:10', '2026-01-27 23:39:10'),
(1120, 'tr', 'referral_earning', 'Referans Kazancı', '2026-01-27 23:39:10', '2026-01-27 23:39:10'),
(1121, 'tr', 'description', 'Açıklama', '2026-01-27 23:39:10', '2026-01-27 23:39:10'),
(1122, 'en', 'bonus_earnings', 'Bonus Earnings', '2026-01-27 23:39:10', '2026-01-27 23:39:10'),
(1123, 'en', 'referral_earning', 'Referral Earning', '2026-01-27 23:39:10', '2026-01-27 23:39:10'),
(1124, 'en', 'description', 'Description', '2026-01-27 23:39:10', '2026-01-27 23:39:10'),
(1125, 'tr', 'api', 'API', '2026-01-28 12:13:37', '2026-01-28 12:13:37'),
(1126, 'en', 'api', 'API', '2026-01-28 12:13:37', '2026-01-28 12:13:37'),
(1127, 'tr', 'api_documentation', 'API Dokümantasyonu', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1128, 'tr', 'api_description', 'Servislerimize programatik erişim için HTTP API kullanabilirsiniz.', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1129, 'tr', 'api_key_active', 'API anahtarınız aktif. Hesap sayfanızdan görüntüleyebilirsiniz.', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1130, 'tr', 'api_key_not_created', 'Henüz API anahtarı oluşturmadınız.', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1131, 'tr', 'view_api_key', 'API Anahtarını Görüntüle', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1132, 'tr', 'create_api_key', 'API Anahtarı Oluştur', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1133, 'tr', 'view_documentation', 'Dokümantasyon', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1134, 'tr', 'api_key_info', 'API kullanmak için bir API anahtarına ihtiyacınız var. API anahtarınızı', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1135, 'tr', 'profile_page', 'Hesap sayfanızdan', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1136, 'tr', 'api_key_info_2', 'oluşturabilir ve görüntüleyebilirsiniz.', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1137, 'tr', 'api_base_url', 'API Base URL', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1138, 'tr', 'authentication', 'Kimlik Doğrulama', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1139, 'tr', 'auth_description', 'Tüm API isteklerinde <code>key</code> parametresi ile API anahtarınızı göndermeniz gerekmektedir.', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1140, 'tr', 'parameter', 'Parametre', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1141, 'tr', 'type', 'Tip', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1142, 'tr', 'api_key_param_desc', 'Hesap sayfanızdan aldığınız API anahtarı', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1143, 'tr', 'endpoints', 'Endpoints', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1144, 'tr', 'services_endpoint_desc', 'Tüm servislerin listesini döndürür.', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1145, 'tr', 'balance_endpoint_desc', 'Hesap bakiyenizi döndürür.', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1146, 'tr', 'add_endpoint_desc', 'Yeni sipariş oluşturur.', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1147, 'tr', 'status_endpoint_desc', 'Sipariş durumunu sorgular.', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1148, 'tr', 'example_response', 'Örnek Yanıt', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1149, 'tr', 'example_requests', 'Örnek İstekler', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1150, 'tr', 'error_codes', 'Hata Kodları', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1151, 'tr', 'error_invalid_key', 'Geçersiz veya eksik API anahtarı', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1152, 'tr', 'error_invalid_action', 'Geçersiz veya eksik action parametresi', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1153, 'tr', 'error_invalid_service', 'Geçersiz servis ID', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1154, 'tr', 'error_insufficient_balance', 'Yetersiz bakiye', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1155, 'tr', 'error_invalid_quantity', 'Miktar min/max aralığında değil', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1156, 'tr', 'error_order_not_found', 'Sipariş bulunamadı', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1157, 'en', 'api_documentation', 'API Documentation', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1158, 'en', 'api_description', 'You can use our HTTP API for programmatic access to our services.', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1159, 'en', 'api_key_active', 'Your API key is active. You can view it from your account page.', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1160, 'en', 'api_key_not_created', 'You have not created an API key yet.', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1161, 'en', 'view_api_key', 'View API Key', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1162, 'en', 'create_api_key', 'Create API Key', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1163, 'en', 'view_documentation', 'Documentation', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1164, 'en', 'api_key_info', 'You need an API key to use the API. You can create and view your API key from', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1165, 'en', 'profile_page', 'your Account page', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1166, 'en', 'api_key_info_2', '.', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1167, 'en', 'api_base_url', 'API Base URL', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1168, 'en', 'authentication', 'Authentication', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1169, 'en', 'auth_description', 'You must send your API key with the <code>key</code> parameter in all API requests.', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1170, 'en', 'parameter', 'Parameter', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1171, 'en', 'type', 'Type', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1172, 'en', 'api_key_param_desc', 'Your API key from your account page', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1173, 'en', 'endpoints', 'Endpoints', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1174, 'en', 'services_endpoint_desc', 'Returns a list of all services.', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1175, 'en', 'balance_endpoint_desc', 'Returns your account balance.', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1176, 'en', 'add_endpoint_desc', 'Creates a new order.', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1177, 'en', 'status_endpoint_desc', 'Queries order status.', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1178, 'en', 'example_response', 'Example Response', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1179, 'en', 'example_requests', 'Example Requests', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1180, 'en', 'error_codes', 'Error Codes', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1181, 'en', 'error_invalid_key', 'Invalid or missing API key', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1182, 'en', 'error_invalid_action', 'Invalid or missing action parameter', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1183, 'en', 'error_invalid_service', 'Invalid service ID', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1184, 'en', 'error_insufficient_balance', 'Insufficient balance', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1185, 'en', 'error_invalid_quantity', 'Quantity not within min/max range', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1186, 'en', 'error_order_not_found', 'Order not found', '2026-01-28 12:18:41', '2026-01-28 12:18:41'),
(1193, 'tr', 'request_methods', 'İstekler GET veya POST ile gönderilebilir.', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1194, 'tr', 'parameters', 'Parametreler', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1195, 'tr', 'default', 'varsayılan', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1196, 'tr', 'returns', 'Döner', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1197, 'tr', 'service_list', 'Servis listesi', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1198, 'tr', 'balance_and_currency', 'Bakiye ve para birimi', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1199, 'tr', 'example', 'örneği', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1200, 'tr', 'response_structure', 'Dönüş Yapısı', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1201, 'tr', 'error_responses', 'Hata Yanıtları', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1202, 'tr', 'error_account_inactive', 'Hesap aktif değil', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1203, 'tr', 'api_key_get_info', 'API anahtarınızı görmek/oluşturmak için', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1204, 'tr', 'page_go', 'sayfasına gidin.', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1205, 'en', 'request_methods', 'Requests can be sent via GET or POST.', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1206, 'en', 'parameters', 'Parameters', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1207, 'en', 'default', 'default', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1208, 'en', 'returns', 'Returns', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1209, 'en', 'service_list', 'Service list', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1210, 'en', 'balance_and_currency', 'Balance and currency', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1211, 'en', 'example', 'example', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1212, 'en', 'response_structure', 'Response Structure', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1213, 'en', 'error_responses', 'Error Responses', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1214, 'en', 'error_account_inactive', 'Account is not active', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1215, 'en', 'api_key_get_info', 'To view/create your API key, go to', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1216, 'en', 'page_go', 'page.', '2026-01-28 12:22:27', '2026-01-28 12:22:27'),
(1223, 'tr', 'api_rate_limit_info', 'API istekleri dakikada belirli bir sayıyla sınırlıdır. Ayrıca IP kısıtlaması uygulanabilir. Detaylar için yönetici ile iletişime geçin.', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1224, 'tr', 'api_features', 'API Özellikleri', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1225, 'tr', 'feature_get_post', 'GET ve POST desteği', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1226, 'tr', 'feature_json', 'JSON formatında yanıt', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1227, 'tr', 'feature_currency', 'Çoklu para birimi desteği', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1228, 'tr', 'feature_rate_limit', 'Rate limiting koruması', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1229, 'tr', 'feature_ip_whitelist', 'IP whitelist desteği', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1230, 'tr', 'feature_auto_exchange', 'Otomatik kur dönüşümü', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1231, 'tr', 'services_endpoint_info', 'Tüm aktif servislerin listesini getirir. Para birimi belirterek fiyatları otomatik dönüştürebilirsiniz.', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1232, 'tr', 'balance_endpoint_info', 'Hesap bakiyenizi sorgular. Farklı para birimine çevirebilirsiniz.', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1233, 'tr', 'currency_param_desc', 'Para birimi kodu (TRY, USD, EUR vb.). Varsayılan: TRY', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1234, 'tr', 'desc_param_desc', 'Eklenirse servis açıklamaları da döner', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1235, 'tr', 'rate_info', '<code>rate</code> değeri 1000 adet için fiyatı gösterir.', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1236, 'tr', 'service_list_with_desc', 'Açıklamalı servis listesi', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1237, 'tr', 'error_key_required', 'API anahtarı gönderilmedi', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1238, 'tr', 'error_ip_blocked', 'IP adresiniz whitelist\'te değil', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1239, 'tr', 'error_rate_limit', 'Dakikalık istek limiti aşıldı', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1240, 'tr', 'error_response_example', 'Hata Yanıt Örneği', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1241, 'tr', 'supported_currencies', 'Desteklenen Para Birimleri', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1242, 'tr', 'currency_info', 'Aşağıdaki para birimleri otomatik kur dönüşümü ile desteklenmektedir:', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1243, 'tr', 'currency_note', 'Kur bilgileri saatlik olarak güncellenir. Desteklenmeyen para birimi girilirse TRY olarak döner.', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1244, 'en', 'api_rate_limit_info', 'API requests are limited per minute. IP restrictions may also apply. Contact the administrator for details.', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1245, 'en', 'api_features', 'API Features', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1246, 'en', 'feature_get_post', 'GET and POST support', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1247, 'en', 'feature_json', 'JSON response format', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1248, 'en', 'feature_currency', 'Multi-currency support', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1249, 'en', 'feature_rate_limit', 'Rate limiting protection', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1250, 'en', 'feature_ip_whitelist', 'IP whitelist support', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1251, 'en', 'feature_auto_exchange', 'Automatic currency conversion', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1252, 'en', 'services_endpoint_info', 'Returns a list of all active services. You can specify a currency to automatically convert prices.', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1253, 'en', 'balance_endpoint_info', 'Queries your account balance. You can convert to a different currency.', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1254, 'en', 'currency_param_desc', 'Currency code (TRY, USD, EUR, etc.). Default: TRY', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1255, 'en', 'desc_param_desc', 'If included, service descriptions are also returned', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1256, 'en', 'rate_info', 'The <code>rate</code> value shows the price per 1000 units.', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1257, 'en', 'service_list_with_desc', 'Service list with descriptions', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1258, 'en', 'error_key_required', 'API key was not sent', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1259, 'en', 'error_ip_blocked', 'Your IP address is not in the whitelist', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1260, 'en', 'error_rate_limit', 'Per-minute request limit exceeded', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1261, 'en', 'error_response_example', 'Error Response Example', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1262, 'en', 'supported_currencies', 'Supported Currencies', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1263, 'en', 'currency_info', 'The following currencies are supported with automatic exchange rate conversion:', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1264, 'en', 'currency_note', 'Exchange rates are updated hourly. If an unsupported currency is entered, it returns as TRY.', '2026-01-28 12:25:52', '2026-01-28 12:25:52'),
(1265, 'tr', 'maintenance_mode', 'Bakım Modu', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1266, 'tr', 'maintenance_mode_settings', 'Bakım Modu Ayarları', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1267, 'tr', 'maintenance_message', 'Bakım Mesajı', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1268, 'tr', 'maintenance_end_time', 'Tahmini Bitiş Zamanı', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1269, 'tr', 'maintenance_allowed_ips', 'İzin Verilen IP Adresleri', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1270, 'tr', 'maintenance_allowed_ips_hint', 'Virgülle ayırarak birden fazla IP girebilirsiniz', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1271, 'tr', 'maintenance_title', 'Bakım Çalışması', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1272, 'tr', 'maintenance_subtitle', 'Kısa süre içinde döneceğiz', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1273, 'tr', 'maintenance_end_estimate', 'Tahmini bitiş', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1274, 'tr', 'enable_maintenance', 'Bakım Modunu Aç', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1275, 'tr', 'disable_maintenance', 'Bakım Modunu Kapat', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1276, 'tr', 'maintenance_warning', 'Bakım modu açıldığında sadece izin verilen IP adreslerinden siteye erişilebilir.', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1277, 'tr', 'maintenance_your_ip', 'Sizin IP Adresiniz', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1278, 'tr', 'maintenance_saved', 'Bakım modu ayarları kaydedildi.', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1279, 'tr', 'maintenance_activated', 'Bakım modu aktif edildi.', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1280, 'tr', 'maintenance_deactivated', 'Bakım modu kapatıldı.', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1281, 'tr', 'maintenance_status', 'Durum', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1282, 'tr', 'maintenance_active', 'Aktif', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1283, 'tr', 'maintenance_inactive', 'Kapalı', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1284, 'en', 'maintenance_mode', 'Maintenance Mode', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1285, 'en', 'maintenance_mode_settings', 'Maintenance Mode Settings', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1286, 'en', 'maintenance_message', 'Maintenance Message', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1287, 'en', 'maintenance_end_time', 'Estimated End Time', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1288, 'en', 'maintenance_allowed_ips', 'Allowed IP Addresses', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1289, 'en', 'maintenance_allowed_ips_hint', 'You can enter multiple IPs separated by commas', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1290, 'en', 'maintenance_title', 'Under Maintenance', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1291, 'en', 'maintenance_subtitle', 'We will be back soon', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1292, 'en', 'maintenance_end_estimate', 'Estimated end', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1293, 'en', 'enable_maintenance', 'Enable Maintenance Mode', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1294, 'en', 'disable_maintenance', 'Disable Maintenance Mode', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1295, 'en', 'maintenance_warning', 'When maintenance mode is enabled, only allowed IP addresses can access the site.', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1296, 'en', 'maintenance_your_ip', 'Your IP Address', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1297, 'en', 'maintenance_saved', 'Maintenance mode settings saved.', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1298, 'en', 'maintenance_activated', 'Maintenance mode activated.', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1299, 'en', 'maintenance_deactivated', 'Maintenance mode deactivated.', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1300, 'en', 'maintenance_status', 'Status', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1301, 'en', 'maintenance_active', 'Active', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1302, 'en', 'maintenance_inactive', 'Inactive', '2026-01-28 14:44:42', '2026-01-28 14:44:42'),
(1303, 'tr', 'maintenance_default_message', 'Sitemiz şu anda bakım çalışması nedeniyle geçici olarak kapalıdır. Kısa süre içinde tekrar hizmetinizdeyiz.', '2026-01-28 14:51:05', '2026-01-28 14:51:05'),
(1304, 'en', 'maintenance_default_message', 'Our site is temporarily closed due to maintenance work. We will be back shortly.', '2026-01-28 14:51:05', '2026-01-28 14:51:05'),
(1314, 'tr', 'select_orders', 'Sipariş seç', '2026-01-28 22:23:26', '2026-01-28 22:23:26'),
(1315, 'tr', 'multi_select', 'çoklu seçim', '2026-01-28 22:23:26', '2026-01-28 22:23:26'),
(1316, 'tr', 'you_can_select_multiple_orders', 'Birden fazla siparişi seçebilirsiniz.', '2026-01-28 22:23:26', '2026-01-28 22:23:26'),
(1317, 'tr', 'related_orders', 'İlgili Siparişler', '2026-01-28 22:23:26', '2026-01-30 11:29:53');
INSERT INTO `translations` (`id`, `lang_code`, `translation_key`, `translation_value`, `created_at`, `updated_at`) VALUES
(1318, 'en', 'select_orders', 'Select order', '2026-01-28 22:23:26', '2026-01-28 22:23:26'),
(1319, 'en', 'multi_select', 'multi select', '2026-01-28 22:23:26', '2026-01-28 22:23:26'),
(1320, 'en', 'you_can_select_multiple_orders', 'You can select multiple orders.', '2026-01-28 22:23:26', '2026-01-28 22:23:26'),
(1321, 'en', 'related_orders', 'Related Orders', '2026-01-28 22:23:26', '2026-01-30 11:30:04'),
(1376, 'tr', 'search_order', 'Sipariş ara', '2026-01-30 11:29:53', '2026-01-30 11:29:53'),
(1377, 'tr', 'select_all', 'Tümünü Seç', '2026-01-30 11:29:53', '2026-01-30 11:29:53'),
(1378, 'tr', 'order_selected', 'sipariş seçildi', '2026-01-30 11:29:53', '2026-01-30 11:29:53'),
(1379, 'tr', 'order_status_pending', 'Bekleniyor', '2026-01-30 11:29:53', '2026-01-30 11:29:53'),
(1380, 'tr', 'order_status_processing', 'İşleniyor', '2026-01-30 11:29:53', '2026-01-30 11:29:53'),
(1381, 'tr', 'order_status_completed', 'Tamamlandı', '2026-01-30 11:29:53', '2026-01-30 11:29:53'),
(1382, 'tr', 'order_status_cancelled', 'İptal Edildi', '2026-01-30 11:29:53', '2026-01-30 11:29:53'),
(1383, 'tr', 'order_status_partial', 'Kısmi', '2026-01-30 11:29:53', '2026-01-30 11:29:53'),
(1384, 'tr', 'order_status_inprogress', 'Devam Ediyor', '2026-01-30 11:29:53', '2026-01-30 11:29:53'),
(1385, 'tr', 'order_status_refunded', 'İade Edildi', '2026-01-30 11:29:53', '2026-01-30 11:29:53'),
(1430, 'en', 'search_order', 'Search order', '2026-01-30 11:30:04', '2026-01-30 11:30:04'),
(1431, 'en', 'select_all', 'Select All', '2026-01-30 11:30:04', '2026-01-30 11:30:04'),
(1432, 'en', 'order_selected', 'order(s) selected', '2026-01-30 11:30:04', '2026-01-30 11:30:04'),
(1433, 'en', 'order_status_pending', 'Pending', '2026-01-30 11:30:04', '2026-01-30 11:30:04'),
(1434, 'en', 'order_status_processing', 'Processing', '2026-01-30 11:30:04', '2026-01-30 11:30:04'),
(1435, 'en', 'order_status_completed', 'Completed', '2026-01-30 11:30:04', '2026-01-30 11:30:04'),
(1436, 'en', 'order_status_cancelled', 'Cancelled', '2026-01-30 11:30:04', '2026-01-30 11:30:04'),
(1437, 'en', 'order_status_partial', 'Partial', '2026-01-30 11:30:04', '2026-01-30 11:30:04'),
(1438, 'en', 'order_status_inprogress', 'In Progress', '2026-01-30 11:30:04', '2026-01-30 11:30:04'),
(1439, 'en', 'order_status_refunded', 'Refunded', '2026-01-30 11:30:04', '2026-01-30 11:30:04'),
(1484, 'tr', 'refill_request', 'Refill Talebi', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1485, 'tr', 'refill_available', 'Refill Hakkı', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1486, 'tr', 'refill_used', 'Kullanılan', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1487, 'tr', 'refill_remaining', 'Kalan Hak', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1488, 'tr', 'refill_until', 'Geçerlilik', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1489, 'tr', 'refill_days_left', 'gün kaldı', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1490, 'tr', 'refill_expired', 'Refill süresi doldu', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1491, 'tr', 'refill_no_rights', 'Refill hakkı kalmadı', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1492, 'tr', 'refill_requested', 'Refill talebiniz alındı', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1493, 'tr', 'refill_already_pending', 'Bekleyen bir refill talebiniz var', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1494, 'tr', 'refill_not_available', 'Bu sipariş için refill kullanılamaz', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1495, 'tr', 'refill_only_completed', 'Sadece tamamlanmış siparişler için refill talep edilebilir', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1496, 'tr', 'request_refill', 'Refill Talep Et', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1497, 'tr', 'refill_pending', 'Refill Bekliyor', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1498, 'tr', 'cancel_order', 'Siparişi İptal Et', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1499, 'tr', 'order_cancelled', 'Sipariş iptal edildi ve ücret iade edildi', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1500, 'tr', 'cancel_not_available', 'Bu sipariş iptal edilemez', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1501, 'tr', 'cancel_confirm', 'Bu siparişi iptal etmek istediğinize emin misiniz? Ücret bakiyenize iade edilecektir.', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1502, 'tr', 'order_cancel_failed', 'Sipariş iptal edilemedi', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1503, 'tr', 'api_cancel_failed', 'API siparişi iptal edilemedi', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1504, 'en', 'refill_request', 'Refill Request', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1505, 'en', 'refill_available', 'Refill Available', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1506, 'en', 'refill_used', 'Used', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1507, 'en', 'refill_remaining', 'Remaining', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1508, 'en', 'refill_until', 'Valid Until', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1509, 'en', 'refill_days_left', 'days left', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1510, 'en', 'refill_expired', 'Refill period expired', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1511, 'en', 'refill_no_rights', 'No refill rights remaining', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1512, 'en', 'refill_requested', 'Your refill request has been received', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1513, 'en', 'refill_already_pending', 'You already have a pending refill request', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1514, 'en', 'refill_not_available', 'Refill is not available for this order', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1515, 'en', 'refill_only_completed', 'Refill can only be requested for completed orders', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1516, 'en', 'request_refill', 'Request Refill', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1517, 'en', 'refill_pending', 'Refill Pending', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1518, 'en', 'cancel_order', 'Cancel Order', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1519, 'en', 'order_cancelled', 'Order cancelled and refunded', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1520, 'en', 'cancel_not_available', 'This order cannot be cancelled', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1521, 'en', 'cancel_confirm', 'Are you sure you want to cancel this order? The amount will be refunded to your balance.', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1522, 'en', 'order_cancel_failed', 'Failed to cancel order', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1523, 'en', 'api_cancel_failed', 'Failed to cancel API order', '2026-01-30 12:01:55', '2026-01-30 12:01:55'),
(1524, 'tr', 'dripfeed_support', 'Dripfeed Desteği', '2026-01-30 17:56:51', '2026-01-30 17:56:51'),
(1525, 'tr', 'cancel_support', 'İptal Edilebilir', '2026-01-30 17:56:51', '2026-01-30 17:56:51'),
(1526, 'tr', 'dripfeed', 'Dripfeed', '2026-01-30 17:56:51', '2026-01-30 17:56:51'),
(1620, 'en', 'dripfeed_support', 'Dripfeed Support', '2026-01-30 17:56:51', '2026-01-30 17:56:51'),
(1621, 'en', 'cancel_support', 'Cancelable', '2026-01-30 17:56:51', '2026-01-30 17:56:51'),
(1622, 'en', 'dripfeed', 'Dripfeed', '2026-01-30 17:56:51', '2026-01-30 17:56:51'),
(1716, 'tr', 'credit_packages', 'Kredi Paketleri', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1717, 'tr', 'select_package', 'Paket Seç', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1718, 'tr', 'or_enter_custom_amount', 'veya özel tutar girin', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1719, 'tr', 'custom_amount', 'Özel Tutar', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1720, 'tr', 'you_pay', 'Ödeyeceğiniz', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1721, 'tr', 'you_get', 'Alacağınız', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1722, 'tr', 'popular', 'Popüler', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1723, 'tr', 'best_value', 'En Avantajlı', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1724, 'tr', 'select_this_package', 'Bu Paketi Seç', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1725, 'tr', 'package_selected', 'Paket Seçildi', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1726, 'tr', 'selected_package', 'Seçilen Paket', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1727, 'tr', 'payment_amount', 'Ödeme Tutarı', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1728, 'tr', 'credit_to_receive', 'Alınacak Bakiye', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1729, 'tr', 'no_package_selected', 'Paket seçilmedi', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1730, 'tr', 'package_not_found', 'Paket bulunamadı', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1731, 'tr', 'discount', 'İndirim', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1734, 'en', 'credit_packages', 'Credit Packages', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1735, 'en', 'select_package', 'Select Package', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1736, 'en', 'or_enter_custom_amount', 'or enter custom amount', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1737, 'en', 'custom_amount', 'Custom Amount', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1738, 'en', 'you_pay', 'You Pay', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1739, 'en', 'you_get', 'You Get', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1740, 'en', 'popular', 'Popular', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1741, 'en', 'best_value', 'Best Value', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1742, 'en', 'select_this_package', 'Select This Package', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1743, 'en', 'package_selected', 'Package Selected', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1744, 'en', 'selected_package', 'Selected Package', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1745, 'en', 'payment_amount', 'Payment Amount', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1746, 'en', 'credit_to_receive', 'Credit to Receive', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1747, 'en', 'no_package_selected', 'No package selected', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1748, 'en', 'package_not_found', 'Package not found', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1749, 'en', 'discount', 'Discount', '2026-01-30 18:06:11', '2026-01-30 18:06:11'),
(1754, 'tr', 'extra_credit', 'ekstra bakiye', '2026-01-30 18:19:50', '2026-01-30 18:19:50'),
(1758, 'en', 'extra_credit', 'extra credit', '2026-01-30 18:19:50', '2026-01-30 18:19:50'),
(1762, 'tr', 'select_package_and_save', 'Paket seçerek tasarruf edin', '2026-01-30 18:27:06', '2026-01-30 18:27:06'),
(1763, 'tr', 'package', 'Paket', '2026-01-30 18:27:06', '2026-01-30 18:27:06'),
(1764, 'tr', 'paid', 'Ödenen', '2026-01-30 18:27:06', '2026-01-30 18:27:06'),
(1768, 'en', 'select_package_and_save', 'Select a package and save', '2026-01-30 18:27:06', '2026-01-30 18:27:06'),
(1769, 'en', 'package', 'Package', '2026-01-30 18:27:06', '2026-01-30 18:27:06'),
(1770, 'en', 'paid', 'Paid', '2026-01-30 18:27:06', '2026-01-30 18:27:06'),
(1774, 'tr', 'package_deposit', 'Paket ile Yükleme', '2026-01-30 19:39:02', '2026-01-30 19:39:02'),
(1775, 'tr', 'no_package', 'Paket Seçilmedi', '2026-01-30 19:39:02', '2026-01-30 19:39:02'),
(1776, 'tr', 'popular_package', 'Popüler', '2026-01-30 19:39:02', '2026-01-30 19:39:02'),
(1777, 'tr', 'credit_amount', 'Alınacak Bakiye', '2026-01-30 19:39:02', '2026-01-30 19:39:02'),
(1778, 'tr', 'discount_percent', 'İndirim', '2026-01-30 19:39:02', '2026-01-30 19:39:02'),
(1779, 'tr', 'save_amount', 'Kazancınız', '2026-01-30 19:39:02', '2026-01-30 19:39:02'),
(1780, 'tr', 'paid_amount', 'Ödenen Tutar', '2026-01-30 19:39:02', '2026-01-30 19:39:02'),
(1781, 'tr', 'loaded_amount', 'Yüklenen Bakiye', '2026-01-30 19:39:02', '2026-01-30 19:39:02'),
(1782, 'tr', 'total_credit_received', 'Toplam Alınan Bakiye', '2026-01-30 19:39:02', '2026-01-30 19:39:02'),
(1783, 'tr', 'package_bonus_info', 'Bu paket ile ekstra bonus kazanırsınız', '2026-01-30 19:39:02', '2026-01-30 19:39:02'),
(1784, 'tr', 'select_package_or_enter_amount', 'Paket seçin veya tutar girin', '2026-01-30 19:39:02', '2026-01-30 19:39:02'),
(1796, 'en', 'package_deposit', 'Package Deposit', '2026-01-30 19:39:22', '2026-01-30 19:39:22'),
(1797, 'en', 'no_package', 'No Package Selected', '2026-01-30 19:39:22', '2026-01-30 19:39:22'),
(1798, 'en', 'popular_package', 'Popular', '2026-01-30 19:39:22', '2026-01-30 19:39:22'),
(1799, 'en', 'credit_amount', 'Credit Amount', '2026-01-30 19:39:22', '2026-01-30 19:39:22'),
(1800, 'en', 'discount_percent', 'Discount', '2026-01-30 19:39:22', '2026-01-30 19:39:22'),
(1801, 'en', 'save_amount', 'You Save', '2026-01-30 19:39:22', '2026-01-30 19:39:22'),
(1802, 'en', 'paid_amount', 'Paid Amount', '2026-01-30 19:39:22', '2026-01-30 19:39:22'),
(1803, 'en', 'loaded_amount', 'Loaded Balance', '2026-01-30 19:39:22', '2026-01-30 19:39:22'),
(1804, 'en', 'total_credit_received', 'Total Credit Received', '2026-01-30 19:39:22', '2026-01-30 19:39:22'),
(1805, 'en', 'package_bonus_info', 'Earn extra bonus with this package', '2026-01-30 19:39:22', '2026-01-30 19:39:22'),
(1806, 'en', 'select_package_or_enter_amount', 'Select a package or enter amount', '2026-01-30 19:39:22', '2026-01-30 19:39:22'),
(1852, 'tr', 'api_description_v2', 'SMM Panel API v2 standardı ile uyumlu. Standart SMM API istemcileri ve benzeri sistemlerle entegre çalışır.', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1853, 'tr', 'api_security_warning', 'API anahtarınızı kimseyle paylaşmayın. Aşırı istek gönderimi hesabınızın askıya alınmasına neden olabilir.', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1854, 'tr', 'both_methods_supported', 'Her iki HTTP metodu da desteklenir.', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1855, 'tr', 'feature_smm_standard', 'SMM Panel v2 standardı', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1856, 'tr', 'feature_order_tracking', 'Sipariş takibi', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1857, 'tr', 'add_endpoint_info', 'Yeni sipariş oluşturur. Bakiyenizden otomatik düşülür.', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1858, 'tr', 'status_endpoint_info', 'Mevcut bir siparişin durumunu sorgular.', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1859, 'tr', 'service_id_desc', 'Servis ID numarası', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1860, 'tr', 'link_desc', 'Hedef URL (profil, gönderi vb.)', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1861, 'tr', 'quantity_desc', 'Sipariş miktarı (min-max aralığında)', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1862, 'tr', 'order_id_desc', 'Sipariş ID numarası', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1863, 'tr', 'success_response', 'Başarılı Yanıt', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1864, 'tr', 'price_formula', 'Fiyat hesaplama: <code>(quantity / 1000) × rate</code>', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1865, 'tr', 'order_statuses', 'Sipariş Durumları', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1866, 'tr', 'status_canceled', 'Sipariş iptal edildi', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1867, 'tr', 'balance_query', 'Bakiye Sorgulama', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1868, 'tr', 'create_order', 'Sipariş Oluşturma', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1869, 'tr', 'order_status', 'Sipariş Durumu', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1870, 'tr', 'error_key_missing', 'API anahtarı gönderilmedi', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1871, 'tr', 'error_missing_params', 'Zorunlu parametreler eksik', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1872, 'tr', 'error_service_not_found', 'Servis bulunamadı veya pasif', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1873, 'tr', 'error_qty_below_min', 'Miktar minimum limitin altında', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1874, 'tr', 'error_qty_above_max', 'Miktar maksimum limitin üstünde', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1875, 'tr', 'error_not_enough_funds', 'Yetersiz bakiye', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1876, 'tr', 'error_system', 'Sistem hatası oluştu', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1877, 'tr', 'important_notes', 'Önemli Notlar', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1878, 'tr', 'note_currency', 'Tüm fiyatlar TRY (Türk Lirası) cinsindendir', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1879, 'tr', 'note_rate', '<code>rate</code> değeri 1000 adet için fiyattır', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1880, 'tr', 'note_string_values', 'Tüm değerler string olarak döner', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1881, 'tr', 'note_api_key_security', 'API anahtarınızı kimseyle paylaşmayın', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1882, 'tr', 'key', 'anahtarı', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1896, 'en', 'api_description_v2', 'Compatible with the SMM Panel API v2 standard and standard SMM API clients.', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1897, 'en', 'api_security_warning', 'Do not share your API key with anyone. Excessive requests may result in account suspension.', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1898, 'en', 'both_methods_supported', 'Both HTTP methods are supported.', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1899, 'en', 'feature_smm_standard', 'SMM Panel v2 standard', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1900, 'en', 'feature_order_tracking', 'Order tracking', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1901, 'en', 'add_endpoint_info', 'Creates a new order. Automatically deducted from your balance.', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1902, 'en', 'status_endpoint_info', 'Queries the status of an existing order.', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1903, 'en', 'service_id_desc', 'Service ID number', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1904, 'en', 'link_desc', 'Target URL (profile, post, etc.)', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1905, 'en', 'quantity_desc', 'Order quantity (within min-max range)', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1906, 'en', 'order_id_desc', 'Order ID number', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1907, 'en', 'success_response', 'Success Response', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1908, 'en', 'price_formula', 'Price calculation: <code>(quantity / 1000) × rate</code>', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1909, 'en', 'order_statuses', 'Order Statuses', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1910, 'en', 'status_canceled', 'Order canceled', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1911, 'en', 'balance_query', 'Balance Query', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1912, 'en', 'create_order', 'Create Order', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1913, 'en', 'order_status', 'Order Status', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1914, 'en', 'error_key_missing', 'API key not provided', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1915, 'en', 'error_missing_params', 'Required parameters missing', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1916, 'en', 'error_service_not_found', 'Service not found or inactive', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1917, 'en', 'error_qty_below_min', 'Quantity below minimum limit', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1918, 'en', 'error_qty_above_max', 'Quantity above maximum limit', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1919, 'en', 'error_not_enough_funds', 'Insufficient balance', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1920, 'en', 'error_system', 'System error occurred', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1921, 'en', 'important_notes', 'Important Notes', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1922, 'en', 'note_currency', 'All prices are in TRY (Turkish Lira)', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1923, 'en', 'note_rate', '<code>rate</code> value is the price per 1000 units', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1924, 'en', 'note_string_values', 'All values are returned as strings', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1925, 'en', 'note_api_key_security', 'Do not share your API key with anyone', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1926, 'en', 'key', 'key', '2026-02-01 16:59:50', '2026-02-01 16:59:50'),
(1940, 'tr', 'two_factor_title', 'İki Faktörlü Doğrulama (2FA)', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1941, 'tr', 'two_factor_active', '2FA Aktif', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1942, 'tr', 'two_factor_passive', '2FA Pasif', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1943, 'tr', 'two_factor_success_msg', 'Hesabınız İki Faktörlü Doğrulama ile korunuyor.', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1944, 'tr', 'two_factor_warning_msg', 'Google Authenticator uygulamasını kaldırırsanız hesabınıza erişimi kaybedebilirsiniz.', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1945, 'tr', 'disable_2fa_btn', '2FA\'yı Devre Dışı Bırak', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1946, 'tr', 'disable_2fa_confirm', 'Güvenliği devre dışı bırakmak istediğinize emin misiniz?', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1947, 'tr', 'how_to_setup', 'Nasıl Kurulur?', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1948, 'tr', 'two_factor_step_1', '1. Google Authenticator veya Authy uygulamasını telefonunuza indirin.', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1949, 'tr', 'two_factor_step_2', '2. Aşağıdaki QR kodu uygulama ile taratın.', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1950, 'tr', 'two_factor_step_3', '3. Uygulamanın ürettiği 6 haneli kodu kutucuğa girip doğrulayın.', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1951, 'tr', 'manual_entry_hint', 'QR okutamazsanız, bu kodu elle girin:', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1952, 'tr', 'verification_code_label', 'Doğrulama Kodu', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1953, 'tr', 'verify_and_enable_btn', 'Doğrula ve Aktifleştir', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1954, 'tr', 'security_and_password', 'Güvenlik & Şifre', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1955, 'tr', 'api_key_title', 'API Anahtarınız', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1956, 'tr', 'generate_api_key_btn', 'API Anahtarı Oluştur', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1957, 'tr', 'no_api_key_hint', 'Henüz bir API anahtarın yok. Oluştur butonuna basınca üretilecek.', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1958, 'tr', 'api_endpoint_hint', 'Endpoint Adresi', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1959, 'tr', 'copy_btn', 'Kopyala', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1960, 'tr', 'copied_msg', 'Kopyalandı!', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1961, 'tr', 'enter_verification_code', 'Lütfen doğrulama kodunu girin.', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1962, 'tr', 'invalid_verification_code', 'Geçersiz doğrulama kodu!', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1963, 'tr', 'user_not_found', 'Kullanıcı bulunamadı.', '2026-02-02 10:00:27', '2026-02-02 10:00:27'),
(1977, 'tr', 'security_title', 'Güvenlik', '2026-02-02 10:10:29', '2026-02-02 10:10:29'),
(1978, 'tr', 'disable_2fa_success_msg', 'İki faktörlü doğrulama devre dışı bırakıldı.', '2026-02-02 10:10:29', '2026-02-02 10:10:29'),
(1979, 'tr', 'api_key_generated', 'API anahtarınız oluşturuldu.', '2026-02-02 10:10:29', '2026-02-02 10:10:29'),
(1980, 'tr', 'api_key_error', 'API anahtarı oluşturulamadı', '2026-02-02 10:10:29', '2026-02-02 10:10:29'),
(1990, 'en', 'two_factor_title', 'Two-Factor Authentication (2FA)', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(1991, 'en', 'two_factor_active', '2FA Active', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(1992, 'en', 'two_factor_passive', '2FA Passive', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(1993, 'en', 'two_factor_success_msg', 'Your account is protected with Two-Factor Authentication.', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(1994, 'en', 'two_factor_warning_msg', 'If you uninstall the Google Authenticator app, you may lose access to your account.', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(1995, 'en', 'disable_2fa_btn', 'Disable 2FA', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(1996, 'en', 'disable_2fa_confirm', 'Are you sure you want to disable security?', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(1997, 'en', 'security_title', 'Security', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(1998, 'en', 'how_to_setup', 'How to Setup?', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(1999, 'en', 'two_factor_step_1', '1. Download Google Authenticator or Authy app to your phone.', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2000, 'en', 'two_factor_step_2', '2. Scan the QR code below with the app.', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2001, 'en', 'two_factor_step_3', '3. Enter the 6-digit code generated by the app to verify.', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2002, 'en', 'manual_entry_hint', 'If you cannot scan the QR, enter this code manually:', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2003, 'en', 'verification_code_label', 'Verification Code', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2004, 'en', 'verify_and_enable_btn', 'Verify and Enable', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2005, 'en', 'disable_2fa_success_msg', 'Two-Factor Authentication has been disabled.', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2006, 'en', 'security_and_password', 'Security & Password', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2007, 'en', 'api_key_title', 'Your API Key', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2008, 'en', 'generate_api_key_btn', 'Generate API Key', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2009, 'en', 'no_api_key_hint', 'You do not have an API key yet. Click Generate to create one.', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2010, 'en', 'api_endpoint_hint', 'Endpoint URL', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2011, 'en', 'copy_btn', 'Copy', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2012, 'en', 'copied_msg', 'Copied!', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2013, 'en', 'api_key_generated', 'API key generated successfully.', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2014, 'en', 'api_key_error', 'API key could not be generated', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2015, 'en', 'enter_verification_code', 'Please enter the verification code.', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2016, 'en', 'invalid_verification_code', 'Invalid verification code!', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2017, 'en', 'user_not_found', 'User not found.', '2026-02-02 10:11:03', '2026-02-02 10:11:03'),
(2018, 'tr', 'subscriptions', 'Abonelikler', '2026-02-02 13:42:40', '2026-02-02 13:42:40'),
(2019, 'tr', 'scheduled_orders', 'Süreli Siparişler', '2026-02-02 13:42:40', '2026-02-02 13:42:40'),
(2020, 'tr', 'advanced_orders', 'Özel Siparişler', '2026-02-02 13:42:40', '2026-02-02 13:42:40'),
(2021, 'en', 'subscriptions', 'Subscriptions', '2026-02-02 13:42:40', '2026-02-02 13:42:40'),
(2022, 'en', 'scheduled_orders', 'Scheduled Orders', '2026-02-02 13:42:40', '2026-02-02 13:42:40'),
(2023, 'en', 'advanced_orders', 'Advanced Orders', '2026-02-02 13:42:40', '2026-02-02 13:42:40'),
(2024, 'tr', 'orders_menu', 'Sipariş Yönetimi', '2026-02-02 13:44:58', '2026-02-02 13:44:58'),
(2025, 'en', 'orders_menu', 'Orders Management', '2026-02-02 13:44:58', '2026-02-02 13:44:58'),
(2026, 'tr', 'posts_progress', 'İlerleme', '2026-02-02 13:46:33', '2026-02-02 13:46:33'),
(2027, 'tr', 'no_subscriptions_found', 'Henüz aktif bir aboneliğiniz yok.', '2026-02-02 13:46:33', '2026-02-02 13:46:33'),
(2028, 'tr', 'no_scheduled_orders', 'Zamanlanmış bir siparişiniz bulunmuyor.', '2026-02-02 13:46:33', '2026-02-02 13:46:33'),
(2029, 'tr', 'scheduled_time', 'Planlanan Zaman', '2026-02-02 13:46:33', '2026-02-02 13:46:33'),
(2030, 'tr', 'scheduled_orders_info', 'Bu siparişler, belirlediğiniz tarih ve saat geldiğinde otomatik olarak sisteme işlenecektir.', '2026-02-02 13:46:33', '2026-02-02 13:46:33'),
(2031, 'tr', 'new_subscription', 'Yeni Abonelik', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2032, 'tr', 'choose_category', 'Kategori Seçiniz', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2033, 'tr', 'choose_service_first', 'Önce Kategori Seçiniz', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2034, 'tr', 'choose_service', 'Seçiniz...', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2035, 'tr', 'posts_count', 'Gönderi Sayısı', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2036, 'tr', 'delay_minutes', 'Gecikme (Dakika)', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2037, 'tr', 'total_cost', 'Toplam Tutar', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2038, 'tr', 'pay_and_start', 'Öde ve Başlat', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2039, 'tr', 'min_quantity_error', 'Minimum miktar en az:', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2040, 'tr', 'max_quantity_error', 'Maksimum miktar en fazla:', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2041, 'tr', 'required_amount', 'Gerekli Tutar', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2042, 'tr', 'subscription_created', 'Abonelik başarıyla oluşturuldu ve ücreti tahsil edildi.', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2043, 'tr', 'new_scheduled_order', 'Sipariş Planla', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2044, 'tr', 'pay_and_plan', 'Öde ve Planla', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2045, 'tr', 'quantity_range_error', 'Miktar şu aralıkta olmalıdır:', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2046, 'tr', 'scheduled_order_created', 'Sipariş başarıyla planlandı.', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2047, 'tr', 'invalid_date', 'Geçmiş bir tarihe işlem yapamazsınız.', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2048, 'tr', 'min_quantity', 'Min Miktar', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2049, 'tr', 'max_quantity', 'Max Miktar', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2050, 'tr', 'time', 'Saat', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2051, 'en', 'new_subscription', 'New Subscription', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2052, 'en', 'no_subscriptions_found', 'No active subscriptions found.', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2053, 'en', 'choose_category', 'Choose Category', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2054, 'en', 'choose_service_first', 'Choose Category First', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2055, 'en', 'choose_service', 'Choose...', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2056, 'en', 'posts_count', 'Posts Count', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2057, 'en', 'delay_minutes', 'Delay (Minutes)', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2058, 'en', 'total_cost', 'Total Cost', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2059, 'en', 'pay_and_start', 'Pay & Start', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2060, 'en', 'min_quantity_error', 'Minimum quantity must be at least:', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2061, 'en', 'max_quantity_error', 'Maximum quantity can be at most:', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2062, 'en', 'required_amount', 'Required Amount', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2063, 'en', 'subscription_created', 'Subscription created successfully and charged.', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2064, 'en', 'new_scheduled_order', 'Schedule Order', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2065, 'en', 'pay_and_plan', 'Pay & Plan', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2066, 'en', 'quantity_range_error', 'Quantity must be between:', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2067, 'en', 'scheduled_order_created', 'Order scheduled successfully.', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2068, 'en', 'invalid_date', 'Cannot schedule for a past date.', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2069, 'en', 'min_quantity', 'Min Quantity', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2070, 'en', 'max_quantity', 'Max Quantity', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2071, 'en', 'time', 'Time', '2026-02-02 13:55:24', '2026-02-02 13:55:24'),
(2077, 'tr', 'status_active', 'Aktif', '2026-02-02 13:57:35', '2026-02-02 13:57:35'),
(2078, 'tr', 'status_expired', 'Süresi Doldu', '2026-02-02 13:57:35', '2026-02-02 13:57:35'),
(2079, 'tr', 'status_paused', 'Durduruldu', '2026-02-02 13:57:35', '2026-02-02 13:57:35'),
(2080, 'tr', 'status_scheduled', 'Planlandı', '2026-02-02 13:57:35', '2026-02-02 13:57:35'),
(2081, 'en', 'status_active', 'Active', '2026-02-02 13:57:35', '2026-02-02 13:57:35'),
(2082, 'en', 'status_expired', 'Expired', '2026-02-02 13:57:35', '2026-02-02 13:57:35'),
(2083, 'en', 'status_paused', 'Paused', '2026-02-02 13:57:35', '2026-02-02 13:57:35'),
(2084, 'en', 'status_scheduled', 'Scheduled', '2026-02-02 13:57:35', '2026-02-02 13:57:35'),
(2099, 'tr', 'total_subscriptions', 'Toplam Abonelik', '2026-02-02 14:17:39', '2026-02-02 14:17:39'),
(2100, 'tr', 'active_subscriptions', 'Aktif Abonelikler', '2026-02-02 14:17:39', '2026-02-02 14:17:39'),
(2101, 'tr', 'completed_subscriptions', 'Tamamlananlar', '2026-02-02 14:17:39', '2026-02-02 14:17:39'),
(2102, 'tr', 'fill_all_fields', 'Lütfen tüm alanları doldurun.', '2026-02-02 14:17:39', '2026-02-02 14:17:39'),
(2127, 'en', 'total_subscriptions', 'Total Subscriptions', '2026-02-02 14:17:46', '2026-02-02 14:17:46'),
(2128, 'en', 'active_subscriptions', 'Active Subscriptions', '2026-02-02 14:17:46', '2026-02-02 14:17:46'),
(2129, 'en', 'completed_subscriptions', 'Completed', '2026-02-02 14:17:46', '2026-02-02 14:17:46'),
(2130, 'en', 'posts_progress', 'Posts Progress', '2026-02-02 14:17:46', '2026-02-02 14:17:46'),
(2131, 'en', 'fill_all_fields', 'Please fill in all fields.', '2026-02-02 14:17:46', '2026-02-02 14:17:46'),
(2132, 'en', 'scheduled_orders_info', 'These orders will be processed automatically at the scheduled date and time.', '2026-02-02 14:17:46', '2026-02-02 14:17:46'),
(2133, 'en', 'scheduled_time', 'Scheduled Time', '2026-02-02 14:17:46', '2026-02-02 14:17:46'),
(2134, 'en', 'no_scheduled_orders', 'No scheduled orders found.', '2026-02-02 14:17:46', '2026-02-02 14:17:46'),
(2155, 'tr', 'prepayment_warning', '⚠️ DİKKAT: Ücret bakiyenizden peşin tahsil edilir. İşlem planlandıktan sonra iptal veya iade yapılamaz!', '2026-02-02 14:34:41', '2026-02-02 14:34:41'),
(2156, 'tr', 'all_orders', 'Tüm Siparişler', '2026-02-02 14:34:41', '2026-02-02 14:34:41'),
(2157, 'tr', 'link_placeholder', 'https://... veya kullanıcı adı', '2026-02-02 14:34:41', '2026-02-02 14:34:41'),
(2158, 'tr', 'filter_by_status', 'Duruma Göre Filtrele', '2026-02-02 14:34:41', '2026-02-02 14:34:41'),
(2159, 'en', 'prepayment_warning', '⚠️ WARNING: Payment is collected in advance. Once scheduled, the transaction cannot be cancelled or refunded!', '2026-02-02 14:34:41', '2026-02-02 14:34:41'),
(2160, 'en', 'all_orders', 'All Orders', '2026-02-02 14:34:41', '2026-02-02 14:34:41'),
(2161, 'en', 'link_placeholder', 'https://... or username', '2026-02-02 14:34:41', '2026-02-02 14:34:41'),
(2162, 'en', 'filter_by_status', 'Filter by Status', '2026-02-02 14:34:41', '2026-02-02 14:34:41'),
(2163, 'tr', 'use_coupon', 'Kupon Kodu Kullan', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2164, 'tr', 'coupon_code', 'Kupon Kodu', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2165, 'tr', 'enter_coupon_code', 'Kupon kodunuzu girerek bakiye kazanın', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2166, 'tr', 'enter_coupon_placeholder', 'Kupon kodunu girin', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2167, 'tr', 'use_coupon_btn', 'Kuponu Kullan', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2168, 'tr', 'coupon_case_insensitive', 'Kupon kodları büyük/küçük harf duyarlı değildir', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2169, 'tr', 'coupon_empty', 'Kupon kodu giriniz.', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2170, 'tr', 'coupon_invalid', 'Geçersiz kupon kodu.', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2171, 'tr', 'coupon_not_active_yet', 'Bu kupon henüz aktif değil.', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2172, 'tr', 'coupon_expired', 'Bu kuponun süresi dolmuş.', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2173, 'tr', 'coupon_usage_limit_reached', 'Bu kupon kullanım limitine ulaşmış.', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2174, 'tr', 'coupon_user_limit_reached', 'Bu kuponu daha fazla kullanamazsınız.', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2175, 'tr', 'coupon_min_balance_required', 'Bu kuponu kullanmak için minimum %s bakiyeniz olmalı.', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2176, 'tr', 'coupon_success', 'Kupon başarıyla kullanıldı! %s bakiyenize eklendi.', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2177, 'tr', 'coupon_error', 'Kupon kullanılırken bir hata oluştu.', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2178, 'tr', 'checking', 'Kontrol ediliyor', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2179, 'en', 'use_coupon', 'Use Coupon Code', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2180, 'en', 'coupon_code', 'Coupon Code', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2181, 'en', 'enter_coupon_code', 'Enter your coupon code to earn balance', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2182, 'en', 'enter_coupon_placeholder', 'Enter coupon code', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2183, 'en', 'use_coupon_btn', 'Use Coupon', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2184, 'en', 'coupon_case_insensitive', 'Coupon codes are not case sensitive', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2185, 'en', 'coupon_empty', 'Please enter a coupon code.', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2186, 'en', 'coupon_invalid', 'Invalid coupon code.', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2187, 'en', 'coupon_not_active_yet', 'This coupon is not active yet.', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2188, 'en', 'coupon_expired', 'This coupon has expired.', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2189, 'en', 'coupon_usage_limit_reached', 'This coupon has reached its usage limit.', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2190, 'en', 'coupon_user_limit_reached', 'You cannot use this coupon anymore.', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2191, 'en', 'coupon_min_balance_required', 'You need minimum %s balance to use this coupon.', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2192, 'en', 'coupon_success', 'Coupon used successfully! %s added to your balance.', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2193, 'en', 'coupon_error', 'An error occurred while using the coupon.', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2194, 'en', 'checking', 'Checking', '2026-02-02 18:51:13', '2026-02-02 18:51:13'),
(2239, 'tr', 'service_compare', 'Servis Karşılaştır', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2240, 'tr', 'compare_services', 'Servisleri Karşılaştır', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2241, 'tr', 'select_services_to_compare', 'Karşılaştırmak istediğiniz servisleri seçin', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2242, 'tr', 'add_to_compare', 'Karşılaştırmaya Ekle', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2243, 'tr', 'remove_from_compare', 'Karşılaştırmadan Çıkar', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2244, 'tr', 'compare_now', 'Karşılaştır', '2026-02-03 10:38:27', '2026-02-03 12:43:09'),
(2245, 'tr', 'clear_compare', 'Listeyi Temizle', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2246, 'tr', 'min_two_services', 'En az 2 servis seçmelisiniz', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2247, 'tr', 'max_services_compare', 'En fazla 4 servis karşılaştırabilirsiniz', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2248, 'tr', 'no_services_selected', 'Henüz servis seçilmedi', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2249, 'tr', 'service_name', 'Servis Adı', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2250, 'tr', 'min_max_order', 'Min/Max Sipariş', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2251, 'tr', 'service_quality', 'Kalite', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2252, 'tr', 'cancel_available', 'İptal', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2253, 'tr', 'best_price', 'En Ucuz', '2026-02-03 10:38:27', '2026-02-03 12:43:09'),
(2254, 'tr', 'fastest_service', 'En Hızlı', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2255, 'tr', 'order_this_service', 'Bu Servisi Sipariş Ver', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2256, 'tr', 'compare_result', 'Karşılaştırma Sonucu', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2257, 'tr', 'services_in_compare', 'Karşılaştırmada %d servis var', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2258, 'tr', 'selected_services', 'Seçilenler', '2026-02-03 10:38:27', '2026-02-03 12:43:09'),
(2259, 'en', 'service_compare', 'Compare Services', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2260, 'en', 'compare_services', 'Compare Services', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2261, 'en', 'select_services_to_compare', 'Select services to compare', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2262, 'en', 'add_to_compare', 'Add to Compare', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2263, 'en', 'remove_from_compare', 'Remove from Compare', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2264, 'en', 'compare_now', 'Compare Now', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2265, 'en', 'clear_compare', 'Clear List', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2266, 'en', 'min_two_services', 'You must select at least 2 services', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2267, 'en', 'max_services_compare', 'You can compare up to 4 services', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2268, 'en', 'no_services_selected', 'No services selected yet', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2269, 'en', 'service_name', 'Service Name', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2270, 'en', 'min_max_order', 'Min/Max Order', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2271, 'en', 'service_quality', 'Quality', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2272, 'en', 'cancel_available', 'Cancel', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2273, 'en', 'best_price', 'Best Price', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2274, 'en', 'fastest_service', 'Fastest', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2275, 'en', 'order_this_service', 'Order This Service', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2276, 'en', 'compare_result', 'Comparison Result', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2277, 'en', 'services_in_compare', '%d services in compare', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2278, 'en', 'selected_services', 'Selected Services', '2026-02-03 10:38:27', '2026-02-03 10:38:27'),
(2319, 'tr', 'service_analysis_title', 'Servis Analiz ve Karşılaştırma', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2320, 'tr', 'service_analysis_desc', 'Servislerin gerçek performans verilerini analiz edin ve en iyisini seçin.', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2321, 'tr', 'select_service_1', '1. Servis (Ana Seçim)', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2322, 'tr', 'select_service_2', '2. Servis (Kıyaslanacak)', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2323, 'tr', 'analyze_compare_btn', 'Analiz Et ve Karşılaştır', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2324, 'tr', 'performance_winner', 'Performans Lideri', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2325, 'tr', 'price_perf_winner', 'Fiyat/Performans Lideri', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2326, 'tr', 'score_out_of_10', '10 Üzerinden Puan', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2327, 'tr', 'health_score', 'Sağlık Puanı', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2328, 'tr', 'speed_score', 'Hız Puanı', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2329, 'tr', 'reliability_score', 'Güvenilirlik', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2330, 'tr', 'delivery_rate', 'Teslimat Oranı', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2331, 'tr', 'avg_completion_time', 'Ort. Tamamlanma', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2332, 'tr', 'price_score', 'Fiyat Avantajı', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2333, 'tr', 'refill_reliability', 'Telafi (Refill) Başarısı', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2334, 'tr', 'dripfeed_stability', 'Dripfeed Stabilitesi', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2335, 'tr', 'data_reliability_warning', 'Veri Güvenilirliği Düşük', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2336, 'tr', 'not_enough_data', 'Analiz için yeterli veri yok', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2337, 'tr', 'calculating', 'Hesaplanıyor...', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2338, 'tr', 'winner_badge', 'KAZANAN', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2339, 'tr', 'metrics', 'Detaylı Metrikler', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2340, 'tr', 'service_1', 'Servis 1', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2341, 'tr', 'service_2', 'Servis 2', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2342, 'tr', 'metric_price', 'Birim Fiyat (1000 Adet)', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2343, 'tr', 'metric_min_max', 'Min - Max', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2344, 'tr', 'metric_refill', 'Telafi Desteği', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2345, 'tr', 'metric_cancel_rate', 'İptal Oranı', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2346, 'tr', 'select_two_different', 'Lütfen karşılaştırma için iki farklı servis seçiniz.', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2347, 'tr', 'select_at_least_one', 'Lütfen analiz edilecek en az bir servis seçiniz.', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2348, 'tr', 'recommended', 'Tavsiye Edilen', '2026-02-03 11:13:36', '2026-02-03 11:13:36'),
(2351, 'tr', 'compare_title', 'Ürün Karşılaştırma', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2352, 'tr', 'compare_empty', 'Karşılaştırma listeniz boş', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2353, 'tr', 'compare_empty_desc', 'Karşılaştırmak istediğiniz ürünleri ekleyin', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2354, 'tr', 'compare_browse_products', 'Ürünlere Göz At', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2355, 'tr', 'compare_max_warning', 'En fazla 4 ürün karşılaştırabilirsiniz', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2356, 'tr', 'compare_remove', 'Kaldır', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2357, 'tr', 'compare_remove_all', 'Tümünü Temizle', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2358, 'tr', 'compare_add_to_cart', 'Sepete Ekle', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2359, 'tr', 'compare_view_product', 'Ürünü İncele', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2360, 'tr', 'compare_product', 'Ürün', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2361, 'tr', 'compare_price', 'Fiyat', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2362, 'tr', 'compare_stock', 'Stok Durumu', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2363, 'tr', 'compare_in_stock', 'Stokta', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2364, 'tr', 'compare_out_of_stock', 'Tükendi', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2365, 'tr', 'compare_brand', 'Marka', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2366, 'tr', 'compare_category', 'Kategori', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2367, 'tr', 'compare_description', 'Açıklama', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2368, 'tr', 'compare_features', 'Özellikler', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2369, 'tr', 'compare_added_to_cart', 'Ürün sepete eklendi', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2370, 'tr', 'compare_removed', 'Ürün karşılaştırmadan kaldırıldı', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2371, 'tr', 'compare_cleared', 'Karşılaştırma listesi temizlendi', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2372, 'tr', 'compare_no_image', 'Resim Yok', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2373, 'tr', 'compare_add_more', 'Ürün Ekle', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2374, 'tr', 'compare_items', 'ürün', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2375, 'en', 'compare_title', 'Product Comparison', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2376, 'en', 'compare_empty', 'Your comparison list is empty', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2377, 'en', 'compare_empty_desc', 'Add products you want to compare', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2378, 'en', 'compare_browse_products', 'Browse Products', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2379, 'en', 'compare_max_warning', 'You can compare up to 4 products', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2380, 'en', 'compare_remove', 'Remove', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2381, 'en', 'compare_remove_all', 'Clear All', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2382, 'en', 'compare_add_to_cart', 'Add to Cart', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2383, 'en', 'compare_view_product', 'View Product', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2384, 'en', 'compare_product', 'Product', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2385, 'en', 'compare_price', 'Price', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2386, 'en', 'compare_stock', 'Stock Status', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2387, 'en', 'compare_in_stock', 'In Stock', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2388, 'en', 'compare_out_of_stock', 'Out of Stock', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2389, 'en', 'compare_brand', 'Brand', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2390, 'en', 'compare_category', 'Category', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2391, 'en', 'compare_description', 'Description', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2392, 'en', 'compare_features', 'Features', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2393, 'en', 'compare_added_to_cart', 'Product added to cart', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2394, 'en', 'compare_removed', 'Product removed from comparison', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2395, 'en', 'compare_cleared', 'Comparison list cleared', '2026-02-03 11:18:07', '2026-02-03 11:18:07');
INSERT INTO `translations` (`id`, `lang_code`, `translation_key`, `translation_value`, `created_at`, `updated_at`) VALUES
(2396, 'en', 'compare_no_image', 'No Image', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2397, 'en', 'compare_add_more', 'Add Product', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2398, 'en', 'compare_items', 'items', '2026-02-03 11:18:07', '2026-02-03 11:18:07'),
(2437, 'tr', 'compare_subtitle', 'Servisleri detaylı karşılaştırın ve en iyisini seçin', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2438, 'tr', 'select_services', 'Servis seçin', '2026-02-03 11:30:43', '2026-02-03 12:43:09'),
(2439, 'tr', 'select_min_services', 'En az 2 servis seçip karşılaştırın', '2026-02-03 11:30:43', '2026-02-03 12:43:09'),
(2440, 'tr', 'comparing', 'Karşılaştırılıyor...', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2441, 'tr', 'price_performance', 'Fiyat/Performans', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2442, 'tr', 'price_performance_mode', 'Fiyat/Performans', '2026-02-03 11:30:43', '2026-02-03 12:43:09'),
(2443, 'tr', 'clear_selection', 'Temizle', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2444, 'tr', 'comparison_results', 'Karşılaştırma Sonuçları', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2445, 'tr', 'winner', 'KAZANAN', '2026-02-03 11:30:43', '2026-02-03 12:43:09'),
(2446, 'tr', 'best_choice', 'En İyi Seçim', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2447, 'tr', 'best_speed', 'En Hızlı', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2448, 'tr', 'best_quality', 'En Kaliteli', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2449, 'tr', 'overall_score', 'Genel Puan', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2450, 'tr', 'detailed_analysis', 'Detaylı Analiz', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2451, 'tr', 'completion_rate', 'Tamamlanma Oranı', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2452, 'tr', 'refill_approval_rate', 'Refill Onay Oranı', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2453, 'tr', 'dripfeed_success_rate', 'Dripfeed Başarı Oranı', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2454, 'tr', 'total_orders_count', 'Toplam Sipariş', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2455, 'tr', 'cancelled_orders', 'İptal Edilen', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2456, 'tr', 'partial_orders', 'Kısmi Tamamlanan', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2457, 'tr', 'price_per_1k', 'Fiyat/1K', '2026-02-03 11:30:43', '2026-02-03 12:43:09'),
(2458, 'tr', 'min_order', 'Min. Sipariş', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2459, 'tr', 'max_order', 'Max. Sipariş', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2460, 'tr', 'has_refill', 'Refill', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2461, 'tr', 'refill_period', 'Refill Süresi', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2462, 'tr', 'has_cancel', 'İptal', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2463, 'tr', 'has_dripfeed', 'Dripfeed', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2464, 'tr', 'average_time_label', 'Tahmini Süre', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2465, 'tr', 'speed_label', 'Hız', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2466, 'tr', 'speed_per_hour_label', 'Saatlik Hız', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2467, 'tr', 'quality_score', 'Kalite Puanı', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2468, 'tr', 'value_score', 'Değer Puanı', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2469, 'tr', 'features', 'Özellikler', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2470, 'tr', 'statistics', 'İstatistikler', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2471, 'tr', 'scores', 'Puanlar', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2472, 'tr', 'service_details', 'Servis Detayları', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2473, 'tr', 'yes', 'Evet', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2474, 'tr', 'no', 'Hayır', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2475, 'tr', 'per_hour', '/saat', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2476, 'tr', 'no_data', 'Veri Yok', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2477, 'tr', 'insufficient_data', 'Yetersiz Veri', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2478, 'tr', 'recommendation', 'Öneri', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2479, 'tr', 'recommendation_text', 'Analiz sonuçlarına göre önerimiz', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2480, 'tr', 'why_winner', 'Neden Kazandı?', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2481, 'tr', 'strengths', 'Güçlü', '2026-02-03 11:30:43', '2026-02-03 12:43:09'),
(2482, 'tr', 'weaknesses', 'Zayıf', '2026-02-03 11:30:43', '2026-02-03 12:43:09'),
(2483, 'tr', 'high_completion', 'Yüksek tamamlanma', '2026-02-03 11:30:43', '2026-02-03 12:43:09'),
(2484, 'tr', 'good_refill', 'İyi refill desteği', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2485, 'tr', 'affordable_price', 'Uygun fiyat', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2486, 'tr', 'low_completion', 'Düşük tamamlanma', '2026-02-03 11:30:43', '2026-02-03 12:43:09'),
(2487, 'tr', 'slow_delivery', 'Yavaş teslimat', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2488, 'tr', 'no_refill', 'Refill yok', '2026-02-03 11:30:43', '2026-02-03 12:43:09'),
(2489, 'tr', 'expensive', 'Pahalı', '2026-02-03 11:30:43', '2026-02-03 12:43:09'),
(2490, 'tr', 'compare_more', 'Daha Fazla Karşılaştır', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2491, 'tr', 'export_results', 'Sonuçları İndir', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2492, 'tr', 'share_results', 'Sonuçları Paylaş', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2493, 'tr', 'back_to_services', 'Servislere Dön', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2494, 'tr', 'loading_services', 'Servisler yükleniyor...', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2495, 'tr', 'error_loading', 'Yüklenirken hata oluştu', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2496, 'tr', 'select_different_category', 'Farklı bir kategori seçin', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2497, 'tr', 'no_services_in_category', 'Bu kategoride servis bulunamadı', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2498, 'tr', 'comparison_note', 'Not: Puanlar son 30 günlük verilere göre hesaplanmıştır.', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2499, 'tr', 'rank', 'Sıra', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2500, 'tr', 'filter_by_features', 'Özelliklere Göre Filtrele', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2501, 'tr', 'only_refill', 'Sadece Refill\'li', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2502, 'tr', 'only_dripfeed', 'Sadece Dripfeed\'li', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2503, 'tr', 'only_cancelable', 'Sadece İptal Edilebilir', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2504, 'tr', 'sort_by', 'Sırala', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2505, 'tr', 'sort_price_low', 'Fiyat (Düşükten Yükseğe)', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2506, 'tr', 'sort_price_high', 'Fiyat (Yüksekten Düşüğe)', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2507, 'tr', 'sort_popular', 'Popülerlik', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2508, 'tr', 'sort_newest', 'En Yeni', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2509, 'tr', 'view_mode', 'Görünüm', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2510, 'tr', 'view_table', 'Tablo', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2511, 'tr', 'view_cards', 'Kartlar', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2512, 'tr', 'comparing_services', 'Servisler karşılaştırılıyor', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2513, 'tr', 'analysis_complete', 'Analiz tamamlandı', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2514, 'tr', 'winner_announcement', 'Ve kazanan...', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2515, 'tr', 'points_out_of_10', 'puan / 10', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2516, 'tr', 'detailed_breakdown', 'Detaylı Puan Dağılımı', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2517, 'tr', 'metric', 'Metrik', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2518, 'tr', 'value', 'Değer', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2519, 'tr', 'score', 'Puan', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2520, 'tr', 'weight', 'Ağırlık', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2521, 'tr', 'weighted_score', 'Ağırlıklı Puan', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2522, 'tr', 'final_verdict', 'Sonuç', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2523, 'tr', 'price_focused', 'Fiyat Odaklı', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2524, 'tr', 'quality_focused', 'Kalite Odaklı', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2525, 'tr', 'balanced', 'Dengeli', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2526, 'tr', 'comparison_mode', 'Karşılaştırma Modu', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2527, 'tr', 'standard_mode', 'Standart Mod', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2528, 'tr', 'price_performance_desc', 'Fiyat/performans oranını ön plana çıkarır', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2529, 'tr', 'standard_mode_desc', 'Tüm faktörleri eşit değerlendirir', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2530, 'tr', 'chart_view', 'Grafik Görünümü', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2531, 'tr', 'radar_chart', 'Radar Grafiği', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2532, 'tr', 'bar_chart', 'Çubuk Grafik', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2533, 'tr', 'trend_positive', 'Yükseliş Trendi', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2534, 'tr', 'trend_negative', 'Düşüş Trendi', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2535, 'tr', 'trend_stable', 'Stabil', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2536, 'tr', 'last_30_days', 'Son 30 Gün', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2537, 'tr', 'last_7_days', 'Son 7 Gün', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2538, 'tr', 'all_time', 'Tüm Zamanlar', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2562, 'en', 'compare_subtitle', 'Compare services in detail and choose the best one', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2563, 'en', 'select_services', 'Select Services', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2564, 'en', 'select_min_services', 'You can select minimum 2, maximum 5 services', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2565, 'en', 'comparing', 'Comparing...', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2566, 'en', 'price_performance', 'Price/Performance', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2567, 'en', 'price_performance_mode', 'Price/Performance Mode', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2568, 'en', 'clear_selection', 'Clear', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2569, 'en', 'comparison_results', 'Comparison Results', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2570, 'en', 'winner', 'Winner', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2571, 'en', 'best_choice', 'Best Choice', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2572, 'en', 'best_speed', 'Fastest', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2573, 'en', 'best_quality', 'Best Quality', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2574, 'en', 'overall_score', 'Overall Score', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2575, 'en', 'detailed_analysis', 'Detailed Analysis', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2576, 'en', 'completion_rate', 'Completion Rate', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2577, 'en', 'avg_completion_time', 'Avg. Completion Time', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2578, 'en', 'refill_approval_rate', 'Refill Approval Rate', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2579, 'en', 'dripfeed_success_rate', 'Dripfeed Success Rate', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2580, 'en', 'total_orders_count', 'Total Orders', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2581, 'en', 'cancelled_orders', 'Cancelled', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2582, 'en', 'partial_orders', 'Partial', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2583, 'en', 'price_per_1k', 'Price (1000)', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2584, 'en', 'min_order', 'Min. Order', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2585, 'en', 'max_order', 'Max. Order', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2586, 'en', 'has_refill', 'Refill', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2587, 'en', 'refill_period', 'Refill Period', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2588, 'en', 'has_cancel', 'Cancel', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2589, 'en', 'has_dripfeed', 'Dripfeed', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2590, 'en', 'average_time_label', 'Estimated Time', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2591, 'en', 'speed_label', 'Speed', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2592, 'en', 'speed_per_hour_label', 'Hourly Speed', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2593, 'en', 'quality_score', 'Quality Score', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2594, 'en', 'speed_score', 'Speed Score', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2595, 'en', 'reliability_score', 'Reliability Score', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2596, 'en', 'value_score', 'Value Score', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2597, 'en', 'price_score', 'Price Score', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2598, 'en', 'features', 'Features', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2599, 'en', 'statistics', 'Statistics', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2600, 'en', 'scores', 'Scores', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2601, 'en', 'service_details', 'Service Details', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2602, 'en', 'yes', 'Yes', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2603, 'en', 'no', 'No', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2604, 'en', 'per_hour', '/hour', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2605, 'en', 'no_data', 'No Data', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2606, 'en', 'insufficient_data', 'Insufficient Data', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2607, 'en', 'calculating', 'Calculating...', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2608, 'en', 'recommendation', 'Recommendation', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2609, 'en', 'recommendation_text', 'Our recommendation based on analysis', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2610, 'en', 'why_winner', 'Why It Won?', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2611, 'en', 'strengths', 'Strengths', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2612, 'en', 'weaknesses', 'Weaknesses', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2613, 'en', 'high_completion', 'High completion rate', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2614, 'en', 'good_refill', 'Good refill support', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2615, 'en', 'affordable_price', 'Affordable price', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2616, 'en', 'low_completion', 'Low completion rate', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2617, 'en', 'slow_delivery', 'Slow delivery', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2618, 'en', 'no_refill', 'No refill support', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2619, 'en', 'expensive', 'Expensive', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2620, 'en', 'compare_more', 'Compare More', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2621, 'en', 'export_results', 'Export Results', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2622, 'en', 'share_results', 'Share Results', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2623, 'en', 'back_to_services', 'Back to Services', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2624, 'en', 'loading_services', 'Loading services...', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2625, 'en', 'error_loading', 'Error loading', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2626, 'en', 'select_different_category', 'Select a different category', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2627, 'en', 'no_services_in_category', 'No services found in this category', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2628, 'en', 'comparison_note', 'Note: Scores are calculated based on last 30 days data.', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2629, 'en', 'rank', 'Rank', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2630, 'en', 'filter_by_features', 'Filter by Features', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2631, 'en', 'only_refill', 'Only with Refill', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2632, 'en', 'only_dripfeed', 'Only with Dripfeed', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2633, 'en', 'only_cancelable', 'Only Cancelable', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2634, 'en', 'sort_by', 'Sort by', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2635, 'en', 'sort_price_low', 'Price (Low to High)', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2636, 'en', 'sort_price_high', 'Price (High to Low)', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2637, 'en', 'sort_popular', 'Popularity', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2638, 'en', 'sort_newest', 'Newest', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2639, 'en', 'view_mode', 'View', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2640, 'en', 'view_table', 'Table', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2641, 'en', 'view_cards', 'Cards', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2642, 'en', 'comparing_services', 'Comparing services', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2643, 'en', 'analysis_complete', 'Analysis complete', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2644, 'en', 'winner_announcement', 'And the winner is...', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2645, 'en', 'points_out_of_10', 'points / 10', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2646, 'en', 'detailed_breakdown', 'Detailed Score Breakdown', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2647, 'en', 'metric', 'Metric', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2648, 'en', 'value', 'Value', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2649, 'en', 'score', 'Score', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2650, 'en', 'weight', 'Weight', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2651, 'en', 'weighted_score', 'Weighted Score', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2652, 'en', 'final_verdict', 'Verdict', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2653, 'en', 'price_focused', 'Price Focused', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2654, 'en', 'quality_focused', 'Quality Focused', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2655, 'en', 'balanced', 'Balanced', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2656, 'en', 'comparison_mode', 'Comparison Mode', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2657, 'en', 'standard_mode', 'Standard Mode', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2658, 'en', 'price_performance_desc', 'Prioritizes price/performance ratio', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2659, 'en', 'standard_mode_desc', 'Evaluates all factors equally', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2660, 'en', 'chart_view', 'Chart View', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2661, 'en', 'radar_chart', 'Radar Chart', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2662, 'en', 'bar_chart', 'Bar Chart', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2663, 'en', 'trend_positive', 'Upward Trend', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2664, 'en', 'trend_negative', 'Downward Trend', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2665, 'en', 'trend_stable', 'Stable', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2666, 'en', 'last_30_days', 'Last 30 Days', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2667, 'en', 'last_7_days', 'Last 7 Days', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2668, 'en', 'all_time', 'All Time', '2026-02-03 11:30:43', '2026-02-03 11:30:43'),
(2669, 'tr', 'no_services_found', 'Servis bulunamadı', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2670, 'tr', 'connection_error', 'Bağlantı hatası', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2671, 'tr', 'try_again', 'Tekrar deneyin', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2672, 'tr', 'completion', 'Tamamlanma', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2673, 'tr', 'speed', 'Hız', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2674, 'tr', 'reliability', 'Güvenilirlik', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2675, 'tr', 'avg_time', 'Süre', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2676, 'tr', 'results_note', 'Son 30 günlük verilere göre hesaplandı.', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2677, 'tr', 'select_services_hint', 'Karşılaştırmak için servis seçin', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2678, 'tr', 'min_short', 'dk', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2679, 'tr', 'hour_short', 'sa', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2680, 'tr', 'day_short', 'g', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2681, 'tr', 'login_required', 'Oturum gerekli', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2682, 'tr', 'min_2_services', 'En az 2 farklı servis seçin', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2683, 'tr', 'max_5_services', 'En fazla 5 servis seçebilirsiniz', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2684, 'tr', 'services_not_found', 'Yeterli servis bulunamadı', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2685, 'tr', 'invalid_request', 'Geçersiz istek', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2686, 'tr', 'comparison_failed', 'Karşılaştırma yapılamadı', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2687, 'tr', 'reliable', 'Güvenilir', '2026-02-03 12:43:09', '2026-02-03 12:43:09'),
(2721, 'en', 'analyze_compare_btn', 'Analyze and Compare', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2722, 'en', 'avg_time', 'Duration', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2723, 'en', 'comparison_failed', 'No comparison could be made.', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2724, 'en', 'completion', 'Completion', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2725, 'en', 'connection_error', 'Connection error', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2726, 'en', 'data_reliability_warning', 'Data security is poor.', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2727, 'en', 'day_short', 'Short Day ', '2026-02-03 13:17:42', '2026-02-03 13:19:54'),
(2728, 'en', 'delivery_rate', 'Delivery rate', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2729, 'en', 'dripfeed_stability', 'Dripfeet Stability', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2730, 'en', 'health_score', 'Health score', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2731, 'en', 'hour_short', 'Hour', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2732, 'en', 'invalid_request', 'Invalid request', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2733, 'en', 'login_required', 'Session Required', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2734, 'en', 'max_5_services', 'You can select a maximum of 5 servings.', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2735, 'en', 'metric_cancel_rate', 'Cancellation Rate', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2736, 'en', 'metric_min_max', 'Min - Max', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2737, 'en', 'metric_price', 'Unit Price (1000 Units)', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2738, 'en', 'metric_refill', 'Compensation Support', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2739, 'en', 'metrics', 'Detailed Metrics', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2740, 'en', 'min_2_services', 'Select at least 2 different services.', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2741, 'en', 'min_short', 'Minute short ', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2742, 'en', 'no_services_found', 'Service Not Found', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2743, 'en', 'not_enough_data', 'Insufficient Data for Analysis', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2744, 'en', 'performance_winner', 'Performance Leader', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2745, 'en', 'price_perf_winner', 'Price-Performance Leader', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2746, 'en', 'recommended', 'Recommended', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2747, 'en', 'refill_reliability', 'Refill Success ', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2748, 'en', 'reliability', 'Reliability', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2749, 'en', 'reliable', 'Trustworthy', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2750, 'en', 'results_note', 'Calculated based on data from the last 30 days.', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2751, 'en', 'score_out_of_10', 'Score out of 10', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2752, 'en', 'select_at_least_one', 'Please select at least one service to be analyzed.', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2753, 'en', 'select_service_1', '1. Service Main Selection ', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2754, 'en', 'select_service_2', '2. Service Main Selection ', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2755, 'en', 'select_services_hint', 'Select a service to compare. ', '2026-02-03 13:17:42', '2026-02-03 13:17:42'),
(2756, 'en', 'select_two_different', 'Please select two different services for comparison.', '2026-02-03 13:17:42', '2026-02-03 13:19:54'),
(2757, 'en', 'service_1', 'Service 1', '2026-02-03 13:17:42', '2026-02-03 13:19:54'),
(2758, 'en', 'service_2', 'Service 2', '2026-02-03 13:17:42', '2026-02-03 13:19:54'),
(2759, 'en', 'service_analysis_desc', 'Analyze the real performance data of the services and choose the best one.', '2026-02-03 13:17:42', '2026-02-03 13:19:54'),
(2760, 'en', 'service_analysis_title', 'Service Analysis and Comparison', '2026-02-03 13:17:42', '2026-02-03 13:19:54'),
(2761, 'en', 'services_not_found', 'No adequate service found. ', '2026-02-03 13:17:42', '2026-02-03 13:19:54'),
(2762, 'en', 'speed', 'Speed', '2026-02-03 13:17:42', '2026-02-03 13:19:54'),
(2763, 'en', 'try_again', 'Try again', '2026-02-03 13:17:42', '2026-02-03 13:19:54'),
(2764, 'en', 'winner_badge', 'Winning', '2026-02-03 13:17:42', '2026-02-03 13:19:54'),
(2777, 'tr', 'hero_title', 'Sosyal Medya Büyütme', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2778, 'tr', 'hero_title_span', 'Platformu', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2779, 'tr', 'hero_description', 'Instagram, TikTok, YouTube ve diğer tüm sosyal medya platformları için en uygun fiyatlarla en kaliteli hizmetler. Hemen başlayın!', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2780, 'tr', 'hero_btn_start', 'Hemen Başla', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2781, 'tr', 'hero_btn_services', 'Hizmetleri Gör', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2782, 'tr', 'stat_orders', 'Tamamlanan Sipariş', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2783, 'tr', 'stat_customers', 'Mutlu Müşteri', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2784, 'tr', 'stat_services', 'Hizmet Çeşidi', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2785, 'tr', 'stat_support', 'Destek', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2786, 'tr', 'features_title', 'Neden Bizi Tercih Etmelisiniz?', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2787, 'tr', 'features_subtitle', 'Binlerce müşterinin güvendiği platform ile sosyal medyada fark yaratın', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2788, 'tr', 'feature_1_title', 'Anında Başlangıç', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2789, 'tr', 'feature_1_desc', 'Siparişleriniz otomatik olarak işleme alınır ve anında başlar. Bekleme yok!', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2790, 'tr', 'feature_2_title', '%100 Güvenli', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2791, 'tr', 'feature_2_desc', 'Şifrenizi asla istemiyoruz. SSL sertifikası ile güvenli ödeme altyapısı.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2792, 'tr', 'feature_3_title', 'En Uygun Fiyat', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2793, 'tr', 'feature_3_desc', 'Piyasadaki en uygun fiyat garantisi. Toplu alımlarda ekstra indirimler.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2794, 'tr', 'feature_4_title', '7/24 Destek', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2795, 'tr', 'feature_4_desc', 'Uzman destek ekibimiz her an yanınızda. Anında cevap, hızlı çözüm.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2796, 'tr', 'feature_5_title', 'Otomatik Sistem', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2797, 'tr', 'feature_5_desc', 'Tamamen otomatik sipariş sistemi. API desteği ile entegrasyon imkanı.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2798, 'tr', 'feature_6_title', 'Kalite Garantisi', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2799, 'tr', 'feature_6_desc', 'Yüksek kaliteli hizmetler ve düşüş garantisi. Memnuniyet odaklı çalışıyoruz.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2800, 'tr', 'services_title', 'Popüler Hizmetler', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2801, 'tr', 'services_subtitle', 'En çok tercih edilen hizmetlerimiz', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2802, 'tr', 'service_default_desc', 'Kaliteli ve hızlı hizmet', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2803, 'tr', 'no_services', 'Henüz popüler hizmet eklenmemiş.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2804, 'tr', 'view_all_services', 'Tüm Hizmetleri Gör', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2805, 'tr', 'how_it_works_title', 'Nasıl Çalışır?', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2806, 'tr', 'how_it_works_subtitle', 'Sadece 3 adımda sosyal medyanızı büyütün', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2807, 'tr', 'step_1_title', 'Kayıt Olun', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2808, 'tr', 'step_1_desc', 'Ücretsiz hesap oluşturun ve panele giriş yapın. Sadece birkaç saniye sürer.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2809, 'tr', 'step_2_title', 'Bakiye Yükleyin', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2810, 'tr', 'step_2_desc', 'Güvenli ödeme yöntemlerimizle hesabınıza bakiye yükleyin.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2811, 'tr', 'step_3_title', 'Sipariş Verin', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2812, 'tr', 'step_3_desc', 'İstediğiniz hizmeti seçin, linkinizi girin ve siparişinizi tamamlayın.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2813, 'tr', 'testimonials_title', 'Müşteri Yorumları', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2814, 'tr', 'testimonials_subtitle', 'Binlerce mutlu müşterimizden bazıları', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2815, 'tr', 'testimonial_1_role', 'E-ticaret Girişimcisi', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2816, 'tr', 'testimonial_1_text', 'Instagram mağazam için harika bir destek aldım. Takipçi kalitesi çok iyi ve düşüş yaşamadım. Kesinlikle tavsiye ederim!', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2817, 'tr', 'testimonial_2_role', 'İçerik Üreticisi', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2818, 'tr', 'testimonial_2_text', 'TikTok hesabımı büyütmek için kullandım. Siparişler anında başlıyor ve destek ekibi her zaman yardımcı oluyor.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2819, 'tr', 'testimonial_3_role', 'Dijital Pazarlamacı', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2820, 'tr', 'testimonial_3_text', 'API entegrasyonu sayesinde müşterilerime otomatik hizmet sunabiliyorum. Fiyatlar çok uygun ve sistem stabil çalışıyor.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2821, 'tr', 'cta_title', 'Hemen Başlamaya Hazır mısınız?', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2822, 'tr', 'cta_description', 'Binlerce kullanıcının güvendiği platformda yerinizi alın ve sosyal medyada fark yaratın!', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2823, 'tr', 'cta_button', 'Ücretsiz Kayıt Ol', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2824, 'tr', 'blog_title', 'Blog Yazılarımız', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2825, 'tr', 'blog_subtitle', 'En son haberler, ipuçları ve güncellemeler', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2826, 'tr', 'read_more', 'Devamını Oku', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2827, 'tr', 'view_all_posts', 'Tüm Yazıları Gör', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2828, 'tr', 'settings', 'Ayarlar', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2829, 'tr', 'contact', 'İletişim', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2830, 'tr', 'about', 'Hakkımızda', '2026-02-04 12:07:31', '2026-02-07 14:27:40'),
(2831, 'tr', 'faq', 'SSS', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2832, 'tr', 'terms', 'Kullanım Şartları', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2833, 'tr', 'privacy', 'Gizlilik Politikası', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2841, 'en', 'hero_title', 'Social Media Growth', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2842, 'en', 'hero_title_span', 'Platform', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2843, 'en', 'hero_description', 'The highest quality services at the most affordable prices for Instagram, TikTok, YouTube and all other social media platforms. Start now!', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2844, 'en', 'hero_btn_start', 'Get Started', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2845, 'en', 'hero_btn_services', 'View Services', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2846, 'en', 'stat_orders', 'Completed Orders', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2847, 'en', 'stat_customers', 'Happy Customers', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2848, 'en', 'stat_services', 'Service Types', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2849, 'en', 'stat_support', 'Support', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2850, 'en', 'features_title', 'Why Choose Us?', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2851, 'en', 'features_subtitle', 'Make a difference in social media with the platform trusted by thousands of customers', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2852, 'en', 'feature_1_title', 'Instant Start', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2853, 'en', 'feature_1_desc', 'Your orders are automatically processed and start instantly. No waiting!', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2854, 'en', 'feature_2_title', '100% Secure', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2855, 'en', 'feature_2_desc', 'We never ask for your password. Secure payment infrastructure with SSL certificate.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2856, 'en', 'feature_3_title', 'Best Prices', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2857, 'en', 'feature_3_desc', 'Best price guarantee in the market. Extra discounts on bulk purchases.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2858, 'en', 'feature_4_title', '24/7 Support', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2859, 'en', 'feature_4_desc', 'Our expert support team is always by your side. Instant response, quick solution.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2860, 'en', 'feature_5_title', 'Automatic System', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2861, 'en', 'feature_5_desc', 'Fully automatic order system. Integration opportunity with API support.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2862, 'en', 'feature_6_title', 'Quality Guarantee', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2863, 'en', 'feature_6_desc', 'High quality services and drop guarantee. We work with customer satisfaction focus.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2864, 'en', 'services_title', 'Popular Services', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2865, 'en', 'services_subtitle', 'Our most preferred services', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2866, 'en', 'service_default_desc', 'Quality and fast service', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2867, 'en', 'no_services', 'No popular services added yet.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2868, 'en', 'view_all_services', 'View All Services', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2869, 'en', 'how_it_works_title', 'How It Works?', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2870, 'en', 'how_it_works_subtitle', 'Grow your social media in just 3 steps', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2871, 'en', 'step_1_title', 'Sign Up', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2872, 'en', 'step_1_desc', 'Create a free account and log in to the panel. It only takes a few seconds.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2873, 'en', 'step_2_title', 'Add Funds', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2874, 'en', 'step_2_desc', 'Add balance to your account with our secure payment methods.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2875, 'en', 'step_3_title', 'Place Order', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2876, 'en', 'step_3_desc', 'Select the service you want, enter your link and complete your order.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2877, 'en', 'testimonials_title', 'Customer Reviews', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2878, 'en', 'testimonials_subtitle', 'Some of our thousands of happy customers', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2879, 'en', 'testimonial_1_role', 'E-commerce Entrepreneur', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2880, 'en', 'testimonial_1_text', 'I got great support for my Instagram store. Follower quality is very good and I have not experienced any drops. Definitely recommended!', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2881, 'en', 'testimonial_2_role', 'Content Creator', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2882, 'en', 'testimonial_2_text', 'I used it to grow my TikTok account. Orders start instantly and the support team is always helpful.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2883, 'en', 'testimonial_3_role', 'Digital Marketer', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2884, 'en', 'testimonial_3_text', 'Thanks to API integration, I can provide automatic service to my customers. Prices are very affordable and the system works stable.', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2885, 'en', 'cta_title', 'Ready to Get Started?', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2886, 'en', 'cta_description', 'Take your place on the platform trusted by thousands of users and make a difference in social media!', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2887, 'en', 'cta_button', 'Sign Up Free', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2888, 'en', 'blog_title', 'Our Blog Posts', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2889, 'en', 'blog_subtitle', 'Latest news, tips and updates', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2890, 'en', 'read_more', 'Read More', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2891, 'en', 'view_all_posts', 'View All Posts', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2892, 'en', 'settings', 'Settings', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2893, 'en', 'contact', 'Contact', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2894, 'en', 'about', 'About Us', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2895, 'en', 'faq', 'FAQ', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2896, 'en', 'terms', 'Terms of Service', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2897, 'en', 'privacy', 'Privacy Policy', '2026-02-04 12:07:31', '2026-02-04 12:07:31'),
(2905, 'tr', 'select_language', 'Dil Seçin', '2026-02-04 12:10:30', '2026-02-04 12:10:30'),
(2906, 'tr', 'admin_panel', 'Admin Panel', '2026-02-04 12:10:30', '2026-02-04 12:10:30'),
(2907, 'tr', 'user_panel', 'Kullanıcı Paneli', '2026-02-04 12:10:30', '2026-02-04 12:10:30'),
(2909, 'en', 'select_language', 'Select Language', '2026-02-04 12:10:30', '2026-02-04 12:10:30'),
(2910, 'en', 'admin_panel', 'Admin Panel', '2026-02-04 12:10:30', '2026-02-04 12:10:30'),
(2911, 'en', 'user_panel', 'User Panel', '2026-02-04 12:10:30', '2026-02-04 12:10:30'),
(2914, 'tr', 'services_page_title', 'Hizmetler', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2915, 'tr', 'services_page_heading', 'Hizmetlerimiz', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2916, 'tr', 'services_page_description', 'Sosyal medya hesaplarınızı büyütmek için en kaliteli ve uygun fiyatlı hizmetler', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2917, 'tr', 'services_stat_category', 'Kategori', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2918, 'tr', 'services_stat_service', 'Servis', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2919, 'tr', 'services_stat_lowest_price', 'En Düşük Fiyat', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2920, 'tr', 'services_search_placeholder', 'Servis ara...', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2921, 'tr', 'services_all', 'Tümü', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2922, 'tr', 'services_table_id', 'ID', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2923, 'tr', 'services_table_service', 'Servis', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2924, 'tr', 'services_table_price', 'Fiyat / 1000', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2925, 'tr', 'services_table_minmax', 'Min / Max', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2926, 'tr', 'services_table_feature', 'Özellik', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2927, 'tr', 'services_min', 'Min', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2928, 'tr', 'services_max', 'Max', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2929, 'tr', 'services_refill', 'Refill', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2930, 'tr', 'services_service_count', 'servis', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2931, 'tr', 'services_empty_title', 'Henüz Servis Bulunmuyor', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2932, 'tr', 'services_empty_desc', 'Yakında yeni servisler eklenecek.', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2933, 'tr', 'services_cta_guest_title', 'Hemen Başlayın!', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2934, 'tr', 'services_cta_guest_desc', 'Ücretsiz hesap oluşturun ve sosyal medya hesaplarınızı büyütmeye başlayın.', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2935, 'tr', 'services_cta_guest_btn', 'Ücretsiz Kayıt Ol', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2936, 'tr', 'services_cta_user_title', 'Sipariş Vermeye Hazır mısınız?', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2937, 'tr', 'services_cta_user_desc', 'Hemen sipariş verin, saniyeler içinde işleme alınsın.', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2938, 'tr', 'services_cta_user_btn', 'Sipariş Ver', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2939, 'en', 'services_page_title', 'Services', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2940, 'en', 'services_page_heading', 'Our Services', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2941, 'en', 'services_page_description', 'The highest quality and most affordable services to grow your social media accounts', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2942, 'en', 'services_stat_category', 'Category', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2943, 'en', 'services_stat_service', 'Service', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2944, 'en', 'services_stat_lowest_price', 'Lowest Price', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2945, 'en', 'services_search_placeholder', 'Search service...', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2946, 'en', 'services_all', 'All', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2947, 'en', 'services_table_id', 'ID', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2948, 'en', 'services_table_service', 'Service', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2949, 'en', 'services_table_price', 'Price / 1000', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2950, 'en', 'services_table_minmax', 'Min / Max', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2951, 'en', 'services_table_feature', 'Feature', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2952, 'en', 'services_min', 'Min', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2953, 'en', 'services_max', 'Max', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2954, 'en', 'services_refill', 'Refill', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2955, 'en', 'services_service_count', 'services', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2956, 'en', 'services_empty_title', 'No Services Available', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2957, 'en', 'services_empty_desc', 'New services will be added soon.', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2958, 'en', 'services_cta_guest_title', 'Get Started Now!', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2959, 'en', 'services_cta_guest_desc', 'Create a free account and start growing your social media accounts.', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2960, 'en', 'services_cta_guest_btn', 'Sign Up Free', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2961, 'en', 'services_cta_user_title', 'Ready to Order?', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2962, 'en', 'services_cta_user_desc', 'Place your order now, it will be processed in seconds.', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2963, 'en', 'services_cta_user_btn', 'Place Order', '2026-02-04 12:52:02', '2026-02-04 12:52:02'),
(2964, 'tr', 'register_page_title', 'Kayıt Ol', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2965, 'tr', 'register_heading', 'Hesap Oluştur', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2966, 'tr', 'register_subheading', 'Hemen ücretsiz kayıt olun', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2967, 'tr', 'register_referral_title', 'Referans ile Kayıt', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2968, 'tr', 'register_referral_invited', 'tarafından davet edildiniz', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2969, 'tr', 'register_label_username', 'Kullanıcı Adı', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2970, 'tr', 'register_label_email', 'E-posta Adresi', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2971, 'tr', 'register_label_password', 'Şifre', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2972, 'tr', 'register_label_password_confirm', 'Şifre Tekrar', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2973, 'tr', 'register_placeholder_username', 'kullanici_adi', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2974, 'tr', 'register_placeholder_email', 'ornek@email.com', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2975, 'tr', 'register_password_hint', 'En az 8 karakter', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2976, 'tr', 'register_terms_link', 'Kullanım Şartları', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2977, 'tr', 'register_terms_and', '\'nı ve ', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2978, 'tr', 'register_privacy_link', 'Gizlilik Politikası', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2979, 'tr', 'register_terms_accept', '\'nı okudum, kabul ediyorum.', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2980, 'tr', 'register_btn_submit', 'Kayıt Ol', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2981, 'tr', 'register_btn_google', 'Google ile Kayıt Ol', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2982, 'tr', 'register_btn_discord', 'Discord ile Kayıt Ol', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2983, 'tr', 'register_social_divider', 'veya şununla kayıt ol', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2984, 'tr', 'register_have_account', 'Zaten hesabınız var mı?', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2985, 'tr', 'register_login_link', 'Giriş Yapın', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2986, 'tr', 'register_back_home', 'Ana Sayfaya Dön', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2987, 'tr', 'register_error_fill_all', 'Tüm alanları doldurun!', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2988, 'tr', 'register_error_username_length', 'Kullanıcı adı 3-30 karakter arasında olmalı!', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2989, 'tr', 'register_error_username_chars', 'Kullanıcı adı sadece harf, rakam ve alt çizgi içerebilir!', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2990, 'tr', 'register_error_invalid_email', 'Geçerli bir e-posta adresi girin!', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2991, 'tr', 'register_error_password_length', 'Şifre en az 8 karakter olmalı!', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2992, 'tr', 'register_error_password_mismatch', 'Şifreler eşleşmiyor!', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2993, 'tr', 'register_error_user_exists', 'Bu kullanıcı adı veya e-posta zaten kullanılıyor!', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2994, 'tr', 'register_error_general', 'Bir hata oluştu. Lütfen tekrar deneyin.', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2995, 'tr', 'register_success_verify_email', 'Kayıt başarılı! Lütfen e-posta adresinizi doğrulayın.', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2996, 'en', 'register_page_title', 'Register', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2997, 'en', 'register_heading', 'Create Account', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2998, 'en', 'register_subheading', 'Sign up for free now', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(2999, 'en', 'register_referral_title', 'Referral Registration', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3000, 'en', 'register_referral_invited', 'invited you', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3001, 'en', 'register_label_username', 'Username', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3002, 'en', 'register_label_email', 'Email Address', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3003, 'en', 'register_label_password', 'Password', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3004, 'en', 'register_label_password_confirm', 'Confirm Password', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3005, 'en', 'register_placeholder_username', 'username', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3006, 'en', 'register_placeholder_email', 'example@email.com', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3007, 'en', 'register_password_hint', 'At least 8 characters', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3008, 'en', 'register_terms_link', 'Terms of Service', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3009, 'en', 'register_terms_and', ' and ', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3010, 'en', 'register_privacy_link', 'Privacy Policy', '2026-02-04 12:55:00', '2026-02-04 12:55:00');
INSERT INTO `translations` (`id`, `lang_code`, `translation_key`, `translation_value`, `created_at`, `updated_at`) VALUES
(3011, 'en', 'register_terms_accept', ', I have read and accept.', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3012, 'en', 'register_btn_submit', 'Sign Up', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3013, 'en', 'register_btn_google', 'Sign up with Google', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3014, 'en', 'register_btn_discord', 'Sign up with Discord', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3015, 'en', 'register_social_divider', 'or sign up with', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3016, 'en', 'register_have_account', 'Already have an account?', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3017, 'en', 'register_login_link', 'Login', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3018, 'en', 'register_back_home', 'Back to Home', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3019, 'en', 'register_error_fill_all', 'Please fill in all fields!', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3020, 'en', 'register_error_username_length', 'Username must be between 3-30 characters!', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3021, 'en', 'register_error_username_chars', 'Username can only contain letters, numbers and underscore!', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3022, 'en', 'register_error_invalid_email', 'Please enter a valid email address!', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3023, 'en', 'register_error_password_length', 'Password must be at least 8 characters!', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3024, 'en', 'register_error_password_mismatch', 'Passwords do not match!', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3025, 'en', 'register_error_user_exists', 'This username or email is already in use!', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3026, 'en', 'register_error_general', 'An error occurred. Please try again.', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3027, 'en', 'register_success_verify_email', 'Registration successful! Please verify your email address.', '2026-02-04 12:55:00', '2026-02-04 12:55:00'),
(3028, 'tr', 'login_page_title', 'Giriş Yap', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3029, 'tr', 'login_heading', 'Hoş Geldiniz', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3030, 'tr', 'login_subheading', 'Hesabınıza giriş yapın', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3031, 'tr', 'login_label_username', 'Kullanıcı Adı veya E-posta', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3032, 'tr', 'login_label_password', 'Şifre', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3033, 'tr', 'login_placeholder_username', 'Kullanıcı adı veya e-posta', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3034, 'tr', 'login_remember_me', 'Beni hatırla', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3035, 'tr', 'login_forgot_password', 'Şifremi unuttum', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3036, 'tr', 'login_btn_submit', 'Giriş Yap', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3037, 'tr', 'login_btn_google', 'Google ile Giriş Yap', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3038, 'tr', 'login_btn_discord', 'Discord ile Giriş Yap', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3039, 'tr', 'login_resend_email', 'E-postayı yeniden gönder', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3040, 'tr', 'login_social_divider', 'veya şununla devam et', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3041, 'tr', 'login_security_note', 'Bilgileriniz SSL ile güvende', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3042, 'tr', 'login_no_account', 'Hesabınız yok mu?', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3043, 'tr', 'login_register_link', 'Kayıt Olun', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3044, 'tr', 'login_back_home', 'Ana Sayfaya Dön', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3045, 'tr', 'login_success_registered', 'Kayıt başarılı! Şimdi giriş yapabilirsiniz.', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3046, 'tr', 'login_success_logout', 'Başarıyla çıkış yaptınız.', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3047, 'tr', 'login_error_empty', 'Kullanıcı adı ve şifre gerekli!', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3048, 'tr', 'login_error_invalid', 'Kullanıcı adı veya şifre hatalı!', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3049, 'tr', 'login_error_inactive', 'Hesabınız aktif değil. Lütfen destek ile iletişime geçin.', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3050, 'tr', 'login_error_email_not_verified', 'E-posta adresiniz doğrulanmamış. Lütfen doğrulayın.', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3051, 'tr', 'login_2fa_heading', 'İki Faktörlü Doğrulama', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3052, 'tr', 'login_2fa_subheading', 'Uygulamadaki 6 haneli kodu girin', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3053, 'tr', 'login_2fa_label', 'Doğrulama Kodu', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3054, 'tr', 'login_2fa_placeholder', 'Örn: 123456', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3055, 'tr', 'login_2fa_btn_verify', 'Doğrula ve Giriş Yap', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3056, 'tr', 'login_2fa_back', 'Giriş Ekranına Dön', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3057, 'tr', 'login_2fa_error_empty', 'Lütfen doğrulama kodunu girin.', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3058, 'tr', 'login_2fa_error_invalid', 'Geçersiz doğrulama kodu!', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3059, 'tr', 'login_2fa_error_user_not_found', 'Kullanıcı bulunamadı.', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3060, 'en', 'login_page_title', 'Login', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3061, 'en', 'login_heading', 'Welcome Back', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3062, 'en', 'login_subheading', 'Sign in to your account', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3063, 'en', 'login_label_username', 'Username or Email', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3064, 'en', 'login_label_password', 'Password', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3065, 'en', 'login_placeholder_username', 'Username or email', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3066, 'en', 'login_remember_me', 'Remember me', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3067, 'en', 'login_forgot_password', 'Forgot password', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3068, 'en', 'login_btn_submit', 'Login', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3069, 'en', 'login_btn_google', 'Login with Google', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3070, 'en', 'login_btn_discord', 'Login with Discord', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3071, 'en', 'login_resend_email', 'Resend verification email', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3072, 'en', 'login_social_divider', 'or continue with', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3073, 'en', 'login_security_note', 'Your data is secured with SSL', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3074, 'en', 'login_no_account', 'Don\'t have an account?', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3075, 'en', 'login_register_link', 'Sign Up', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3076, 'en', 'login_back_home', 'Back to Home', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3077, 'en', 'login_success_registered', 'Registration successful! You can now login.', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3078, 'en', 'login_success_logout', 'You have been logged out successfully.', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3079, 'en', 'login_error_empty', 'Username and password are required!', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3080, 'en', 'login_error_invalid', 'Invalid username or password!', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3081, 'en', 'login_error_inactive', 'Your account is not active. Please contact support.', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3082, 'en', 'login_error_email_not_verified', 'Your email is not verified. Please verify it.', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3083, 'en', 'login_2fa_heading', 'Two-Factor Authentication', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3084, 'en', 'login_2fa_subheading', 'Enter the 6-digit code from your app', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3085, 'en', 'login_2fa_label', 'Verification Code', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3086, 'en', 'login_2fa_placeholder', 'e.g. 123456', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3087, 'en', 'login_2fa_btn_verify', 'Verify and Login', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3088, 'en', 'login_2fa_back', 'Back to Login', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3089, 'en', 'login_2fa_error_empty', 'Please enter the verification code.', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3090, 'en', 'login_2fa_error_invalid', 'Invalid verification code!', '2026-02-04 13:00:30', '2026-02-04 13:00:30'),
(3091, 'en', 'login_2fa_error_user_not_found', 'User not found.', '2026-02-04 13:00:30', '2026-02-04 13:00:30');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `balance` decimal(12,4) DEFAULT 0.0000,
  `spent` decimal(12,4) DEFAULT 0.0000,
  `role` enum('user','reseller','admin') DEFAULT 'user',
  `api_key` varchar(64) DEFAULT NULL,
  `status` enum('active','inactive','banned') DEFAULT 'active',
  `email_verified` tinyint(1) DEFAULT 0,
  `last_login` timestamp NULL DEFAULT NULL,
  `last_ip` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `referral_code` varchar(20) DEFAULT NULL,
  `referred_by` int(11) DEFAULT NULL,
  `referral_earnings` decimal(10,2) DEFAULT 0.00,
  `two_factor_enabled` tinyint(1) DEFAULT 0 COMMENT '0: Pasif, 1: Aktif',
  `two_factor_secret` varchar(255) DEFAULT NULL COMMENT 'Google Auth Secret Key'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `users`
--

-- `users` tablosu temiz kurulumda boş başlatılır.

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `user_favorites`
--

CREATE TABLE `user_favorites` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `api_clients`
--
ALTER TABLE `api_clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `api_key` (`api_key`),
  ADD UNIQUE KEY `uniq_user_id` (`user_id`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- Tablo için indeksler `api_providers`
--
ALTER TABLE `api_providers`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `bank_accounts`
--
ALTER TABLE `bank_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `blog_posts`
--
ALTER TABLE `blog_posts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `is_active` (`is_active`);

--
-- Tablo için indeksler `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Tablo için indeksler `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_code` (`code`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_dates` (`start_date`,`end_date`);

--
-- Tablo için indeksler `coupon_usages`
--
ALTER TABLE `coupon_usages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_coupon_id` (`coupon_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_coupon_user` (`coupon_id`,`user_id`);

--
-- Tablo için indeksler `credit_packages`
--
ALTER TABLE `credit_packages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_active_sort` (`is_active`,`sort_order`);

--
-- Tablo için indeksler `cron_logs`
--
ALTER TABLE `cron_logs`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `daily_bonus`
--
ALTER TABLE `daily_bonus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_claimed_at` (`claimed_at`);

--
-- Tablo için indeksler `daily_bonus_logs`
--
ALTER TABLE `daily_bonus_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Tablo için indeksler `daily_bonus_settings`
--
ALTER TABLE `daily_bonus_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Tablo için indeksler `email_verification_tokens`
--
ALTER TABLE `email_verification_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_token` (`token`),
  ADD KEY `idx_user` (`user_id`);

--
-- Tablo için indeksler `footer_links`
--
ALTER TABLE `footer_links`
  ADD PRIMARY KEY (`id`),
  ADD KEY `section_id` (`section_id`);

--
-- Tablo için indeksler `footer_sections`
--
ALTER TABLE `footer_sections`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `homepage_services`
--
ALTER TABLE `homepage_services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `status` (`status`);

--
-- Tablo için indeksler `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Tablo için indeksler `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `status` (`status`),
  ADD KEY `idx_dripfeed_id` (`dripfeed_id`);

--
-- Tablo için indeksler `orders_dripfeed`
--
ALTER TABLE `orders_dripfeed`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`),
  ADD KEY `user_id` (`user_id`);

--
-- Tablo için indeksler `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `payment_requests`
--
ALTER TABLE `payment_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_package` (`package_id`);

--
-- Tablo için indeksler `popups`
--
ALTER TABLE `popups`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `referral_earnings`
--
ALTER TABLE `referral_earnings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_referred_user_id` (`referred_user_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Tablo için indeksler `referral_logs`
--
ALTER TABLE `referral_logs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_referred` (`referred_id`),
  ADD KEY `idx_referrer_id` (`referrer_id`),
  ADD KEY `idx_referred_id` (`referred_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Tablo için indeksler `refill_requests`
--
ALTER TABLE `refill_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_order` (`order_id`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created` (`created_at`);

--
-- Tablo için indeksler `scheduled_orders`
--
ALTER TABLE `scheduled_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `status` (`status`),
  ADD KEY `scheduled_time` (`scheduled_time`);

--
-- Tablo için indeksler `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `status` (`status`);

--
-- Tablo için indeksler `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Tablo için indeksler `social_links`
--
ALTER TABLE `social_links`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `social_logins`
--
ALTER TABLE `social_logins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_provider_account` (`provider`,`provider_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Tablo için indeksler `social_login_settings`
--
ALTER TABLE `social_login_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `provider` (`provider`);

--
-- Tablo için indeksler `support_messages`
--
ALTER TABLE `support_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_ticket_id` (`ticket_id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Tablo için indeksler `support_tickets`
--
ALTER TABLE `support_tickets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Tablo için indeksler `support_ticket_orders`
--
ALTER TABLE `support_ticket_orders`
  ADD PRIMARY KEY (`ticket_id`,`order_id`),
  ADD KEY `fk_sto_order` (`order_id`);

--
-- Tablo için indeksler `theme_defaults`
--
ALTER TABLE `theme_defaults`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `theme_settings`
--
ALTER TABLE `theme_settings`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_type` (`type`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Tablo için indeksler `translations`
--
ALTER TABLE `translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_translation` (`lang_code`,`translation_key`),
  ADD KEY `idx_lang` (`lang_code`),
  ADD KEY `idx_key` (`translation_key`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `referral_code` (`referral_code`),
  ADD KEY `idx_referral_code` (`referral_code`),
  ADD KEY `idx_referred_by` (`referred_by`);

--
-- Tablo için indeksler `user_favorites`
--
ALTER TABLE `user_favorites`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_service` (`user_id`,`service_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_service_id` (`service_id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `api_clients`
--
ALTER TABLE `api_clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `api_providers`
--
ALTER TABLE `api_providers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `bank_accounts`
--
ALTER TABLE `bank_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `blog_posts`
--
ALTER TABLE `blog_posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Tablo için AUTO_INCREMENT değeri `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `coupon_usages`
--
ALTER TABLE `coupon_usages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `credit_packages`
--
ALTER TABLE `credit_packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `cron_logs`
--
ALTER TABLE `cron_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `daily_bonus`
--
ALTER TABLE `daily_bonus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `daily_bonus_logs`
--
ALTER TABLE `daily_bonus_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `daily_bonus_settings`
--
ALTER TABLE `daily_bonus_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `email_verification_tokens`
--
ALTER TABLE `email_verification_tokens`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `footer_links`
--
ALTER TABLE `footer_links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Tablo için AUTO_INCREMENT değeri `footer_sections`
--
ALTER TABLE `footer_sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Tablo için AUTO_INCREMENT değeri `homepage_services`
--
ALTER TABLE `homepage_services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Tablo için AUTO_INCREMENT değeri `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `orders_dripfeed`
--
ALTER TABLE `orders_dripfeed`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `payment_requests`
--
ALTER TABLE `payment_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `popups`
--
ALTER TABLE `popups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `referral_earnings`
--
ALTER TABLE `referral_earnings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `referral_logs`
--
ALTER TABLE `referral_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `refill_requests`
--
ALTER TABLE `refill_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `scheduled_orders`
--
ALTER TABLE `scheduled_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=526;

--
-- Tablo için AUTO_INCREMENT değeri `social_links`
--
ALTER TABLE `social_links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `social_logins`
--
ALTER TABLE `social_logins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `social_login_settings`
--
ALTER TABLE `social_login_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `support_messages`
--
ALTER TABLE `support_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `support_tickets`
--
ALTER TABLE `support_tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `theme_defaults`
--
ALTER TABLE `theme_defaults`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `theme_settings`
--
ALTER TABLE `theme_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `translations`
--
ALTER TABLE `translations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4465;

--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `user_favorites`
--
ALTER TABLE `user_favorites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `coupon_usages`
--
ALTER TABLE `coupon_usages`
  ADD CONSTRAINT `fk_coupon_usages_coupon` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_coupon_usages_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `daily_bonus`
--
ALTER TABLE `daily_bonus`
  ADD CONSTRAINT `daily_bonus_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `footer_links`
--
ALTER TABLE `footer_links`
  ADD CONSTRAINT `footer_links_ibfk_1` FOREIGN KEY (`section_id`) REFERENCES `footer_sections` (`id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `password_resets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `payment_requests`
--
ALTER TABLE `payment_requests`
  ADD CONSTRAINT `payment_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `referral_earnings`
--
ALTER TABLE `referral_earnings`
  ADD CONSTRAINT `referral_earnings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `referral_earnings_ibfk_2` FOREIGN KEY (`referred_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `referral_logs`
--
ALTER TABLE `referral_logs`
  ADD CONSTRAINT `referral_logs_ibfk_1` FOREIGN KEY (`referrer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `referral_logs_ibfk_2` FOREIGN KEY (`referred_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `refill_requests`
--
ALTER TABLE `refill_requests`
  ADD CONSTRAINT `refill_requests_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `refill_requests_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `social_logins`
--
ALTER TABLE `social_logins`
  ADD CONSTRAINT `social_logins_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `support_messages`
--
ALTER TABLE `support_messages`
  ADD CONSTRAINT `support_messages_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `support_messages_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `support_tickets`
--
ALTER TABLE `support_tickets`
  ADD CONSTRAINT `support_tickets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `support_tickets_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL;

--
-- Tablo kısıtlamaları `support_ticket_orders`
--
ALTER TABLE `support_ticket_orders`
  ADD CONSTRAINT `fk_sto_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_sto_ticket` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `user_favorites`
--
ALTER TABLE `user_favorites`
  ADD CONSTRAINT `fk_favorites_service` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_favorites_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

-- ============================================================
-- v2 güvenlik / eklenti / finans / cron genişletmeleri
-- ============================================================
-- v2 mevcut site yükseltme yaması
-- Yalnız ekleme/oluşturma yapar; mevcut tablo veya veriyi silmez.
SET NAMES utf8mb4;
SET time_zone = '+03:00';

CREATE TABLE IF NOT EXISTS `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `slug` varchar(100) NOT NULL,
  `name` varchar(190) NOT NULL,
  `description` text NULL,
  `version` varchar(30) NOT NULL DEFAULT '1.0.0',
  `is_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `is_core` tinyint(1) NOT NULL DEFAULT 0,
  `requires_json` text NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_plugins_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `plugin_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `plugin_slug` varchar(100) NOT NULL,
  `setting_key` varchar(120) NOT NULL,
  `setting_value` text NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_plugin_setting` (`plugin_slug`,`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `plugins` (`slug`,`name`,`description`,`version`,`is_enabled`,`is_core`) VALUES
('provider_failover','Otomatik Sağlayıcı Failover','Bir sağlayıcı siparişi kabul etmezse tanımlı yedek rotalara geçer. En az iki aktif sağlayıcı gerektirir.','1.0.0',0,0),
('order_idempotency','Sipariş Idempotency','Aynı istemci isteğinin ikinci kez sipariş oluşturmasını engeller.','1.0.0',1,0),
('duplicate_order_warning','Mükerrer Sipariş Uyarısı','Aynı servis ve hedefte aktif sipariş varsa uyarı kaydı üretir; siparişi engellemez.','1.0.0',1,0),
('e_invoice','e-Fatura / e-Arşiv','Başarılı ödemeler için harici e-belge sağlayıcısına belge talebi gönderebilir.','1.0.0',0,0),
('tax_vat','Vergi / KDV Profilleri','Ülke ve müşteri tipine göre KDV profilleri uygular.','1.0.0',0,0),
('payment_fraud','Ödeme Hız / Fraud Limitleri','Saatlik/günlük ödeme hızı ve risk eşiklerini uygular.','1.0.0',0,0),
('auto_subscriptions','Otomatik Abonelik / Auto Subscription','Profilde yeni içerik algılandığında belirlenen servisten otomatik sipariş üretir.','1.0.0',1,0),
('auto_start_count','Otomatik Başlangıç Sayısı Tespiti','Sipariş oluşturulurken hedef bağlantının başlangıç metriğini güvenli şekilde tespit etmeyi dener.','1.0.0',1,0),
('real_count_completion','Gerçek Sayıya Göre Otomatik Tamamlama','Gerçek hedef sayısı sipariş hedefini karşıladığında siparişi otomatik tamamlar.','1.0.0',1,0),
('child_panels','Child Panel / Alt Panel','Bayiye özel domain, marka ve fiyat marjıyla alt panel oluşturma ve yönetme sistemi.','1.0.0',0,0);

CREATE TABLE IF NOT EXISTS `remember_tokens` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `selector` char(24) NOT NULL,
  `validator_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `last_used_at` datetime NULL,
  `user_agent_hash` char(64) NULL,
  `device_id` char(64) NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_remember_selector` (`selector`), KEY `idx_remember_user` (`user_id`), KEY `idx_remember_device` (`user_id`,`device_id`), KEY `idx_remember_exp` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `user_sessions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `session_hash` char(64) NOT NULL,
  `device_id` char(64) NOT NULL,
  `device_name` varchar(190) NULL,
  `ip_address` varchar(45) NULL,
  `user_agent` varchar(500) NULL,
  `last_activity_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `revoked_at` datetime NULL,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_session_hash` (`session_hash`), KEY `idx_session_user_active` (`user_id`,`revoked_at`,`last_activity_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `security_events` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NULL,
  `event_type` varchar(80) NOT NULL,
  `severity` enum('info','warning','critical') NOT NULL DEFAULT 'info',
  `ip_address` varchar(45) NULL,
  `device_id` char(64) NULL,
  `user_agent` varchar(500) NULL,
  `metadata_json` text NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_sec_user_time` (`user_id`,`created_at`), KEY `idx_sec_type_time` (`event_type`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `auth_attempts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `identifier_hash` char(64) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `was_successful` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_auth_identifier_time` (`identifier_hash`,`created_at`), KEY `idx_auth_ip_time` (`ip_address`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `webauthn_credentials` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `credential_id` varchar(1024) NOT NULL,
  `public_key_der` mediumtext NOT NULL,
  `algorithm` int NOT NULL DEFAULT -7,
  `sign_count` bigint NOT NULL DEFAULT 0,
  `name` varchar(120) NOT NULL DEFAULT 'Passkey',
  `transports` varchar(255) NULL,
  `last_used_at` datetime NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_webauthn_credential` (`credential_id`(255)), KEY `idx_webauthn_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `api_rate_buckets` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `api_client_id` int NOT NULL,
  `bucket_minute` datetime NOT NULL,
  `request_count` int NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_api_bucket` (`api_client_id`,`bucket_minute`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `provider_health` (
  `provider_id` int NOT NULL,
  `health_score` decimal(5,2) NOT NULL DEFAULT 100.00,
  `success_count` bigint NOT NULL DEFAULT 0,
  `failure_count` bigint NOT NULL DEFAULT 0,
  `consecutive_failures` int NOT NULL DEFAULT 0,
  `avg_latency_ms` decimal(10,2) NOT NULL DEFAULT 0.00,
  `last_latency_ms` int NULL,
  `last_success_at` datetime NULL,
  `last_failure_at` datetime NULL,
  `last_error` text NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`provider_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `provider_health_events` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `provider_id` int NOT NULL,
  `operation` varchar(50) NOT NULL,
  `is_success` tinyint(1) NOT NULL,
  `latency_ms` int NULL,
  `http_code` int NULL,
  `error_message` varchar(1000) NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_provider_event_time` (`provider_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `service_provider_routes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `provider_id` int NOT NULL,
  `api_service_id` varchar(100) NOT NULL,
  `priority` int NOT NULL DEFAULT 10,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_service_provider_route` (`service_id`,`provider_id`,`api_service_id`), KEY `idx_route_service_priority` (`service_id`,`is_enabled`,`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `profit_margin_policies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `scope_type` enum('global','category','service') NOT NULL DEFAULT 'global',
  `scope_id` int NULL,
  `margin_type` enum('percent','fixed') NOT NULL DEFAULT 'percent',
  `margin_value` decimal(12,4) NOT NULL DEFAULT 10.0000,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_margin_scope` (`scope_type`,`scope_id`,`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `user_price_rules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `target_type` enum('user','role') NOT NULL,
  `target_value` varchar(100) NOT NULL,
  `scope_type` enum('all','category','service') NOT NULL DEFAULT 'all',
  `scope_id` int NULL,
  `rule_type` enum('discount_percent','markup_percent','fixed_per_1000') NOT NULL,
  `rule_value` decimal(12,4) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `starts_at` datetime NULL,
  `ends_at` datetime NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_user_price_target` (`target_type`,`target_value`,`is_active`), KEY `idx_user_price_scope` (`scope_type`,`scope_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `order_idempotency` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `source` varchar(40) NOT NULL DEFAULT 'web',
  `idempotency_key` varchar(128) NOT NULL,
  `request_hash` char(64) NOT NULL,
  `order_id` bigint NULL,
  `response_json` text NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` datetime NOT NULL,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_order_idempotency` (`user_id`,`source`,`idempotency_key`), KEY `idx_idem_exp` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `duplicate_order_events` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `service_id` int NOT NULL,
  `link_hash` char(64) NOT NULL,
  `existing_order_id` bigint NULL,
  `new_order_id` bigint NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_dup_user_time` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `maintenance_windows` (
  `id` int NOT NULL AUTO_INCREMENT,
  `scope_type` enum('service','provider') NOT NULL,
  `scope_id` int NOT NULL,
  `starts_at` datetime NOT NULL,
  `ends_at` datetime NOT NULL,
  `reason` varchar(500) NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_maint_scope_time` (`scope_type`,`scope_id`,`is_active`,`starts_at`,`ends_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `order_financial_snapshots` (
  `order_id` bigint NOT NULL,
  `currency_code` varchar(10) NOT NULL DEFAULT 'TRY',
  `sale_per_1000` decimal(15,6) NOT NULL DEFAULT 0,
  `cost_per_1000` decimal(15,6) NOT NULL DEFAULT 0,
  `expected_cost` decimal(15,6) NOT NULL DEFAULT 0,
  `expected_profit` decimal(15,6) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Mevcut siparişlerin maliyetini yükseltme anında sabitle. Bundan sonraki sağlayıcı fiyat değişiklikleri geçmiş kârı değiştirmez.
INSERT IGNORE INTO `order_financial_snapshots`
(`order_id`,`currency_code`,`sale_per_1000`,`cost_per_1000`,`expected_cost`,`expected_profit`,`created_at`)
SELECT o.id,
       COALESCE((SELECT setting_value FROM settings WHERE setting_key='currency' LIMIT 1),'TRY'),
       CASE WHEN o.quantity > 0 THEN (o.price * 1000.0 / o.quantity) ELSE 0 END,
       COALESCE(s.cost_per_1000,0),
       CASE WHEN o.quantity > 0 THEN (o.quantity / 1000.0) * COALESCE(s.cost_per_1000,0) ELSE 0 END,
       o.price - CASE WHEN o.quantity > 0 THEN (o.quantity / 1000.0) * COALESCE(s.cost_per_1000,0) ELSE 0 END,
       COALESCE(o.created_at,CURRENT_TIMESTAMP)
FROM orders o
LEFT JOIN services s ON s.id=o.service_id;


CREATE TABLE IF NOT EXISTS `dripfeed_refunds` (
  `dripfeed_id` bigint NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`dripfeed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `scheduled_order_refunds` (
  `scheduled_order_id` bigint NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`scheduled_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `currencies` (
  `code` varchar(10) NOT NULL,
  `name` varchar(80) NOT NULL,
  `symbol` varchar(12) NOT NULL,
  `rate_to_base` decimal(20,8) NOT NULL DEFAULT 1.00000000,
  `is_base` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO `currencies` (`code`,`name`,`symbol`,`rate_to_base`,`is_base`,`is_active`) VALUES ('TRY','Türk Lirası','₺',1.00000000,0,0),('USD','ABD Doları','$',1.00000000,0,0),('EUR','Euro','€',1.00000000,0,0);


CREATE TABLE IF NOT EXISTS `currency_rate_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `currency_code` varchar(10) NOT NULL,
  `rate_to_base` decimal(20,8) NOT NULL,
  `effective_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_currency_rate_time` (`currency_code`,`effective_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `currency_rate_history` (`currency_code`,`rate_to_base`,`effective_at`)
SELECT c.code,c.rate_to_base,NOW() FROM `currencies` c
WHERE NOT EXISTS (SELECT 1 FROM `currency_rate_history` h WHERE h.currency_code=c.code);

CREATE TABLE IF NOT EXISTS `user_wallets` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `currency_code` varchar(10) NOT NULL,
  `balance` decimal(20,8) NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_wallet_user_currency` (`user_id`,`currency_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `wallet_ledger` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `currency_code` varchar(10) NOT NULL,
  `entry_type` varchar(50) NOT NULL,
  `amount` decimal(20,8) NOT NULL,
  `balance_after` decimal(20,8) NOT NULL,
  `reference_type` varchar(50) NULL,
  `reference_id` varchar(100) NULL,
  `idempotency_key` varchar(150) NULL,
  `description` varchar(500) NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_wallet_ledger_idem` (`idempotency_key`), KEY `idx_wallet_ledger_user` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `user_currency_preferences` (
  `user_id` int NOT NULL,
  `default_currency` varchar(10) NOT NULL DEFAULT 'TRY',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `payment_fraud_events` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NULL,
  `event_type` varchar(80) NOT NULL,
  `risk_score` int NOT NULL DEFAULT 0,
  `decision` enum('allow','review','block') NOT NULL DEFAULT 'allow',
  `amount` decimal(15,4) NULL,
  `ip_address` varchar(45) NULL,
  `device_id` char(64) NULL,
  `details_json` text NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_fraud_user_time` (`user_id`,`created_at`), KEY `idx_fraud_decision_time` (`decision`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `financial_closings` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `closing_date` date NOT NULL,
  `status` enum('draft','closed','reopened') NOT NULL DEFAULT 'draft',
  `opening_wallet_total` decimal(20,4) NOT NULL DEFAULT 0,
  `deposit_total` decimal(20,4) NOT NULL DEFAULT 0,
  `order_total` decimal(20,4) NOT NULL DEFAULT 0,
  `refund_total` decimal(20,4) NOT NULL DEFAULT 0,
  `bonus_total` decimal(20,4) NOT NULL DEFAULT 0,
  `referral_total` decimal(20,4) NOT NULL DEFAULT 0,
  `closing_wallet_total` decimal(20,4) NOT NULL DEFAULT 0,
  `expected_wallet_total` decimal(20,4) NOT NULL DEFAULT 0,
  `variance` decimal(20,4) NOT NULL DEFAULT 0,
  `prepared_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `closed_at` datetime NULL,
  `closed_by` int NULL,
  `notes` text NULL,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_financial_closing_date` (`closing_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `payment_gateway_adapters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `slug` varchar(80) NOT NULL,
  `name` varchar(120) NOT NULL,
  `class_name` varchar(190) NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `config_json` text NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_gateway_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO `payment_gateway_adapters` (`slug`,`name`,`class_name`,`is_enabled`,`config_json`) VALUES
('bank_transfer','Havale / EFT','BankTransferGateway',1,'{}'),
('iyzico','İyzico','IyzicoGateway',0,'{}');

CREATE TABLE IF NOT EXISTS `gateway_transactions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `gateway_slug` varchar(80) NOT NULL,
  `local_token` varchar(190) NOT NULL,
  `gateway_transaction_id` varchar(190) NULL,
  `user_id` int NOT NULL,
  `payment_request_id` bigint NULL,
  `amount` decimal(15,4) NOT NULL,
  `credit_amount` decimal(15,4) NOT NULL,
  `currency_code` varchar(10) NOT NULL DEFAULT 'TRY',
  `status` enum('created','pending','paid','failed','refunded') NOT NULL DEFAULT 'created',
  `payload_json` mediumtext NULL,
  `verified_json` mediumtext NULL,
  `completed_at` datetime NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_gateway_local_token` (`gateway_slug`,`local_token`), UNIQUE KEY `uq_gateway_transaction` (`gateway_slug`,`gateway_transaction_id`), KEY `idx_gateway_user` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `tax_profiles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `country_code` char(2) NULL,
  `customer_type` enum('all','individual','company') NOT NULL DEFAULT 'all',
  `vat_rate` decimal(6,3) NOT NULL DEFAULT 0,
  `prices_include_tax` tinyint(1) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `user_tax_profiles` (
  `user_id` int NOT NULL,
  `customer_type` enum('individual','company') NOT NULL DEFAULT 'individual',
  `legal_name` varchar(255) NULL,
  `tax_office` varchar(190) NULL,
  `tax_number` varchar(50) NULL,
  `national_id` varchar(50) NULL,
  `country_code` char(2) NOT NULL DEFAULT 'TR',
  `city` varchar(120) NULL,
  `address` text NULL,
  `invoice_email` varchar(255) NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `e_invoice_documents` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `gateway_transaction_id` bigint NULL,
  `document_type` enum('e_invoice','e_archive') NOT NULL DEFAULT 'e_archive',
  `external_id` varchar(190) NULL,
  `document_number` varchar(190) NULL,
  `amount` decimal(15,4) NOT NULL,
  `tax_amount` decimal(15,4) NOT NULL DEFAULT 0,
  `currency_code` varchar(10) NOT NULL DEFAULT 'TRY',
  `status` enum('pending','issued','failed','cancelled') NOT NULL DEFAULT 'pending',
  `error_message` text NULL,
  `payload_json` mediumtext NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_invoice_gateway_tx` (`gateway_transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cron_tasks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `task_key` varchar(100) NOT NULL,
  `name` varchar(190) NOT NULL,
  `interval_minutes` int NOT NULL DEFAULT 5,
  `batch_size` int NOT NULL DEFAULT 50,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `last_started_at` datetime NULL,
  `last_finished_at` datetime NULL,
  `last_status` enum('never','running','success','error','skipped') NOT NULL DEFAULT 'never',
  `last_message` varchar(1000) NULL,
  `next_run_at` datetime NULL,
  `locked_until` datetime NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_cron_task_key` (`task_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cron_runs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `task_key` varchar(100) NOT NULL,
  `started_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `finished_at` datetime NULL,
  `status` enum('running','success','error','skipped') NOT NULL DEFAULT 'running',
  `processed_count` int NOT NULL DEFAULT 0,
  `message` varchar(1000) NULL,
  `duration_ms` int NULL,
  PRIMARY KEY (`id`), KEY `idx_cron_run_task_time` (`task_key`,`started_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `cron_tasks` (`task_key`,`name`,`interval_minutes`,`batch_size`,`is_enabled`) VALUES
('scheduled_orders','Süreli Siparişleri Çalıştır',1,50,1),
('dripfeed','Dripfeed Siparişlerini Çalıştır',1,50,1),
('update_orders','Sağlayıcı Sipariş Durumlarını Güncelle',2,50,1),
('provider_health','Sağlayıcı Sağlık ve Bakiye Kontrolü',5,50,1),
('sync_prices','Sağlayıcı Fiyatlarını Senkronize Et',15,200,1),
('financial_closing','Gün Sonu Finansal Kapanış Taslağı',60,1,1),
('cleanup','Eski Token / Log / Idempotency Temizliği',60,500,1),
('e_invoice','e-Fatura / e-Arşiv Kuyruğu',5,25,1);

CREATE TABLE IF NOT EXISTS `custom_pages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `slug` varchar(190) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content_html` mediumtext NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_custom_page_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
('moni_secret_storage_v1','0'),
('fraud_max_payments_hour','5'),
('fraud_max_amount_day','50000'),
('fraud_block_score','80'),
('invoice_provider_url',''),
('invoice_provider_api_key',''),
('invoice_auto_issue','0')
ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;


-- Finansal hassasiyet: mevcut 2 ondalıklı alanları veri kaybetmeden genişlet.
ALTER TABLE `transactions` MODIFY `amount` decimal(15,4) NOT NULL, MODIFY `balance_after` decimal(15,4) DEFAULT 0.0000;
ALTER TABLE `orders` MODIFY `price` decimal(15,4) NOT NULL, MODIFY `refund_amount` decimal(15,4) DEFAULT 0.0000;
ALTER TABLE `orders_dripfeed` MODIFY `total_price` decimal(15,4) NOT NULL;
ALTER TABLE `payment_requests` MODIFY `amount` decimal(15,4) NOT NULL, MODIFY `credit_amount` decimal(15,4) DEFAULT NULL;
ALTER TABLE `payment_methods` MODIFY `min_amount` decimal(15,4) DEFAULT 10.0000, MODIFY `max_amount` decimal(15,4) DEFAULT 10000.0000;
ALTER TABLE `coupons` MODIFY `amount` decimal(15,4) NOT NULL DEFAULT 0.0000, MODIFY `max_amount` decimal(15,4) DEFAULT NULL, MODIFY `min_balance` decimal(15,4) DEFAULT NULL;
ALTER TABLE `coupon_usages` MODIFY `amount` decimal(15,4) NOT NULL;
ALTER TABLE `credit_packages` MODIFY `credit_amount` decimal(15,4) NOT NULL, MODIFY `price` decimal(15,4) NOT NULL, MODIFY `bonus_amount` decimal(15,4) DEFAULT 0.0000;
ALTER TABLE `daily_bonus` MODIFY `amount` decimal(15,4) NOT NULL DEFAULT 0.0000;
ALTER TABLE `daily_bonus_logs` MODIFY `amount` decimal(15,4) NOT NULL, MODIFY `balance_before` decimal(15,4) DEFAULT NULL, MODIFY `balance_after` decimal(15,4) DEFAULT NULL;
ALTER TABLE `referral_earnings` MODIFY `amount` decimal(15,4) NOT NULL DEFAULT 0.0000, MODIFY `order_amount` decimal(15,4) DEFAULT 0.0000;
ALTER TABLE `referral_logs` MODIFY `bonus_amount` decimal(15,4) NOT NULL DEFAULT 0.0000;
ALTER TABLE `users` MODIFY `balance` decimal(15,4) DEFAULT 0.0000, MODIFY `spent` decimal(15,4) DEFAULT 0.0000, MODIFY `referral_earnings` decimal(15,4) DEFAULT 0.0000;


-- v2 gelişmiş otomasyon ve operasyon tabloları
-- v2 profesyonel otomasyon / operasyon paketi
-- Veri silmez. Mevcut tablolara yalnız yeni alanlar ekler ve yeni tablolar oluşturur.


ALTER TABLE `users`
  ADD COLUMN `staff_role_id` int NULL AFTER `role`,
  ADD COLUMN `child_panel_id` bigint NULL AFTER `staff_role_id`;

ALTER TABLE `api_providers`
  ADD COLUMN `alias_name` varchar(190) NULL AFTER `name`;

ALTER TABLE `services`
  ADD COLUMN `overflow_percent` decimal(6,2) NOT NULL DEFAULT 0 AFTER `max_quantity`,
  ADD COLUMN `sync_min_max` tinyint(1) NOT NULL DEFAULT 1 AFTER `overflow_percent`,
  ADD COLUMN `sync_status` tinyint(1) NOT NULL DEFAULT 1 AFTER `sync_min_max`,
  ADD COLUMN `sync_description` tinyint(1) NOT NULL DEFAULT 0 AFTER `sync_status`;

ALTER TABLE `orders`
  ADD COLUMN `provider_quantity` int NULL AFTER `quantity`,
  ADD COLUMN `last_metric_count` bigint NULL AFTER `start_count`,
  ADD COLUMN `last_metric_at` datetime NULL AFTER `last_metric_count`,
  ADD COLUMN `auto_completed_by_metric` tinyint(1) NOT NULL DEFAULT 0 AFTER `last_metric_at`,
  ADD COLUMN `auto_refill_last_at` datetime NULL AFTER `auto_completed_by_metric`;

ALTER TABLE `payment_requests`
  ADD COLUMN `fee_amount` decimal(15,4) NOT NULL DEFAULT 0 AFTER `amount`,
  ADD COLUMN `payable_amount` decimal(15,4) NULL AFTER `fee_amount`;

ALTER TABLE `languages`
  ADD COLUMN `direction` enum('ltr','rtl') NOT NULL DEFAULT 'ltr' AFTER `native_name`;

CREATE TABLE IF NOT EXISTS `auto_subscriptions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `service_id` int NOT NULL,
  `profile_url` varchar(1000) NOT NULL,
  `quantity` int NOT NULL,
  `check_interval_minutes` int NOT NULL DEFAULT 10,
  `max_new_items_per_run` int NOT NULL DEFAULT 3,
  `status` enum('active','paused','completed','cancelled','error') NOT NULL DEFAULT 'active',
  `expires_at` datetime NULL,
  `last_checked_at` datetime NULL,
  `next_check_at` datetime NULL,
  `last_error` text NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_auto_sub_user` (`user_id`,`status`), KEY `idx_auto_sub_next` (`status`,`next_check_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `auto_subscription_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `subscription_id` bigint NOT NULL,
  `item_url` varchar(1000) NOT NULL,
  `order_id` bigint NULL,
  `status` enum('seen','ordered','error') NOT NULL DEFAULT 'seen',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_subscription_item` (`subscription_id`,`item_url`(190)), KEY `idx_subscription_order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `likes_spreads` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `service_id` int NOT NULL,
  `total_quantity` int NOT NULL,
  `item_count` int NOT NULL,
  `completed_items` int NOT NULL DEFAULT 0,
  `status` enum('processing','completed','partial','error') NOT NULL DEFAULT 'processing',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_spread_user` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `likes_spread_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `spread_id` bigint NOT NULL,
  `item_url` varchar(1000) NOT NULL,
  `quantity` int NOT NULL,
  `order_id` bigint NULL,
  `status` enum('ordered','error') NOT NULL,
  `error_message` text NULL,
  PRIMARY KEY (`id`), KEY `idx_spread_items` (`spread_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `auto_refill_checks` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_id` bigint NOT NULL,
  `current_count` bigint NULL,
  `target_count` bigint NULL,
  `drop_count` bigint NOT NULL DEFAULT 0,
  `action` enum('none','refill','error') NOT NULL DEFAULT 'none',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_auto_refill_order` (`order_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `registration_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `field_key` varchar(80) NOT NULL,
  `label` varchar(190) NOT NULL,
  `field_type` enum('text','number','email','url','textarea','select','checkbox') NOT NULL DEFAULT 'text',
  `placeholder` varchar(255) NULL,
  `options_json` text NULL,
  `validation_regex` varchar(500) NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_registration_field_key` (`field_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `registration_field_values` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `field_id` int NOT NULL,
  `field_value` text NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_registration_value` (`user_id`,`field_id`), KEY `idx_registration_field` (`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `starting_balance_grants` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_starting_balance_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `user_access_policies` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `capability` varchar(100) NOT NULL,
  `decision` enum('allow','deny') NOT NULL DEFAULT 'allow',
  `reason` varchar(500) NULL,
  `expires_at` datetime NULL,
  `created_by` int NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_user_access_cap` (`user_id`,`capability`,`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `staff_roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `description` varchar(500) NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_staff_role_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `staff_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permission_key` varchar(120) NOT NULL,
  `name` varchar(190) NOT NULL,
  `group_name` varchar(100) NOT NULL DEFAULT 'Genel',
  PRIMARY KEY (`id`), UNIQUE KEY `uq_staff_permission_key` (`permission_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `staff_role_permissions` (
  `role_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `staff_permissions` (`permission_key`,`name`,`group_name`) VALUES
('dashboard.view','Dashboard görüntüleme','Genel'),
('orders.manage','Sipariş yönetimi','Sipariş'),
('users.manage','Kullanıcı yönetimi','Kullanıcı'),
('payments.manage','Ödeme yönetimi','Finans'),
('services.manage','Servis yönetimi','Servis'),
('providers.manage','Sağlayıcı yönetimi','Servis'),
('providers.view_real_name','Gerçek sağlayıcı adını görme','Servis'),
('support.manage','Destek yönetimi','Destek'),
('settings.manage','Sistem ayarları','Sistem'),
('exports.use','Dışa aktarma','Raporlama'),
('files.manage','Dosya yöneticisi','İçerik'),
('pages.manage','Sayfa oluşturucu','İçerik'),
('seo.manage','SEO / robots / sitemap','İçerik'),
('child_panels.manage','Child Panel yönetimi','Child Panel');

CREATE TABLE IF NOT EXISTS `payment_method_fees` (
  `id` int NOT NULL AUTO_INCREMENT,
  `payment_method_id` int NOT NULL,
  `label` varchar(120) NULL,
  `fee_type` enum('fixed','percent') NOT NULL DEFAULT 'percent',
  `fee_value` decimal(10,4) NOT NULL DEFAULT 0,
  `min_fee` decimal(15,4) NOT NULL DEFAULT 0,
  `max_fee` decimal(15,4) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_payment_method_fee` (`payment_method_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `managed_files` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `path` varchar(500) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `mime_type` varchar(120) NULL,
  `size_bytes` bigint NOT NULL DEFAULT 0,
  `sha256` char(64) NULL,
  `title` varchar(255) NULL,
  `alt_text` varchar(500) NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_managed_file_path` (`path`(190))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `page_builder_pages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `slug` varchar(190) NOT NULL,
  `title` varchar(255) NOT NULL,
  `meta_title` varchar(255) NULL,
  `meta_description` varchar(500) NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_builder_page_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `page_builder_blocks` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `page_id` int NOT NULL,
  `block_type` enum('hero','text','image','cta') NOT NULL DEFAULT 'text',
  `config_json` mediumtext NULL,
  `sort_order` int NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_builder_blocks` (`page_id`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `child_panels` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `owner_user_id` int NOT NULL,
  `panel_name` varchar(190) NOT NULL,
  `domain` varchar(190) NOT NULL,
  `logo_url` varchar(500) NULL,
  `primary_color` varchar(20) NULL,
  `markup_percent` decimal(8,3) NOT NULL DEFAULT 0,
  `monthly_price` decimal(15,4) NOT NULL DEFAULT 0,
  `status` enum('pending','active','suspended','expired','cancelled') NOT NULL DEFAULT 'pending',
  `expires_at` datetime NULL,
  `admin_note` text NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_child_panel_domain` (`domain`), KEY `idx_child_panel_owner` (`owner_user_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `child_panel_payments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `child_panel_id` bigint NOT NULL,
  `user_id` int NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `period_months` int NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_child_panel_payment` (`child_panel_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
('registration_start_balance','0'),
('auto_refill_enabled','1'),
('auto_refill_drop_percent','5'),
('social_metric_endpoint',''),
('provider_sync_copy_description','1'),
('child_panel_monthly_price','250'),
('child_panel_default_markup','15'),
('child_panel_min_markup','0'),
('child_panel_max_markup','100'),
('child_panel_max_per_user','1'),
('child_panel_require_approval','1'),
('child_panel_allow_custom_branding','1'),
('child_panel_default_primary_color','#6d5dfc'),
('robots_txt','User-agent: *\nDisallow: /admin/\nDisallow: /kullanici/\nSitemap: /sitemap.xml\n')
ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;

INSERT IGNORE INTO `cron_tasks` (`task_key`,`name`,`interval_minutes`,`batch_size`,`is_enabled`) VALUES
('auto_subscriptions','Auto Subscription / Yeni İçerik Kontrolü',5,30,1),
('real_count_completion','Gerçek Sayıya Göre Otomatik Tamamlama',10,50,1),
('auto_refill','Otomatik Refill Kontrol Motoru',30,50,1),
('provider_catalog_sync','Sağlayıcı Min/Max/Status/Açıklama Senkronizasyonu',60,250,1),
('sitemap','Otomatik sitemap.xml Üretimi',360,1,1),
('managed_files_scan','Merkezi Dosya Yöneticisi İndeksi',60,500,1),
('child_panel_maintenance','Child Panel Süre / Durum Kontrolü',30,200,1);


-- --------------------------------------------------------
-- v2 profesyonel operasyon / ölçekleme paketi
-- --------------------------------------------------------
ALTER TABLE `users`
  ADD COLUMN `customer_group_id` int NULL AFTER `staff_role_id`,
  ADD COLUMN `credit_limit` decimal(15,4) NOT NULL DEFAULT 0 AFTER `balance`,
  ADD COLUMN `timezone` varchar(64) NOT NULL DEFAULT 'Europe/Istanbul' AFTER `last_ip`;

ALTER TABLE `services`
  ADD COLUMN `quantity_increment` int NOT NULL DEFAULT 1 AFTER `max_quantity`,
  ADD COLUMN `deleted_at` datetime NULL AFTER `status`,
  ADD COLUMN `deleted_by` int NULL AFTER `deleted_at`;

ALTER TABLE `payment_requests`
  ADD COLUMN `bonus_amount` decimal(15,4) NOT NULL DEFAULT 0 AFTER `fee_amount`;

CREATE TABLE IF NOT EXISTS `mass_orders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `line_count` int NOT NULL DEFAULT 0,
  `total_price` decimal(15,4) NOT NULL DEFAULT 0,
  `success_count` int NOT NULL DEFAULT 0,
  `failure_count` int NOT NULL DEFAULT 0,
  `status` enum('processing','completed','partial','error') NOT NULL DEFAULT 'processing',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_mass_user` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mass_order_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `mass_order_id` bigint NOT NULL,
  `line_no` int NOT NULL,
  `service_id` int NOT NULL,
  `link` varchar(1000) NOT NULL,
  `quantity` int NOT NULL,
  `price` decimal(15,4) NOT NULL DEFAULT 0,
  `order_id` bigint NULL,
  `status` enum('ordered','error') NOT NULL,
  `error_message` text NULL,
  PRIMARY KEY (`id`), KEY `idx_mass_item` (`mass_order_id`,`line_no`), KEY `idx_mass_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `service_trash` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `snapshot_json` longtext NOT NULL,
  `deleted_by` int NULL,
  `deleted_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `restored_at` datetime NULL,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_service_trash_service` (`service_id`), KEY `idx_service_trash_deleted` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cancel_jobs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_id` bigint NOT NULL,
  `user_id` int NULL,
  `requested_by` int NULL,
  `reason` varchar(500) NULL,
  `status` enum('queued','processing','retry','completed','failed') NOT NULL DEFAULT 'queued',
  `attempts` int NOT NULL DEFAULT 0,
  `last_error` text NULL,
  `next_attempt_at` datetime NULL,
  `completed_at` datetime NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_cancel_order` (`order_id`), KEY `idx_cancel_queue` (`status`,`next_attempt_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `provider_sync_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `provider_id` int NOT NULL,
  `status` enum('running','success','error') NOT NULL DEFAULT 'running',
  `processed_count` int NOT NULL DEFAULT 0,
  `message` varchar(1000) NULL,
  `started_at` datetime NULL,
  `finished_at` datetime NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_provider_sync` (`provider_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `provider_sync_log_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sync_log_id` bigint NOT NULL,
  `service_id` int NULL,
  `remote_service_id` varchar(100) NULL,
  `changes_json` longtext NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_provider_sync_item` (`sync_log_id`,`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `provider_request_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `provider_id` int NOT NULL,
  `operation` varchar(80) NOT NULL,
  `request_json` longtext NULL,
  `response_body` longtext NULL,
  `http_code` int NOT NULL DEFAULT 0,
  `latency_ms` int NOT NULL DEFAULT 0,
  `is_success` tinyint(1) NOT NULL DEFAULT 0,
  `error_message` varchar(1000) NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_provider_request` (`provider_id`,`operation`,`created_at`), KEY `idx_provider_request_success` (`is_success`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `service_bundles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(190) NOT NULL,
  `description` text NULL,
  `icon` varchar(120) NULL,
  `discount_percent` decimal(6,2) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `service_bundle_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `bundle_id` int NOT NULL,
  `service_id` int NOT NULL,
  `quantity` int NOT NULL,
  `label` varchar(190) NULL,
  `sort_order` int NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_bundle_service` (`bundle_id`,`service_id`), KEY `idx_bundle_items` (`bundle_id`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bundle_orders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `bundle_id` int NOT NULL,
  `user_id` int NOT NULL,
  `total_price` decimal(15,4) NOT NULL DEFAULT 0,
  `success_count` int NOT NULL DEFAULT 0,
  `failure_count` int NOT NULL DEFAULT 0,
  `status` enum('processing','completed','partial','error') NOT NULL DEFAULT 'processing',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_bundle_orders_user` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bundle_order_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `bundle_order_id` bigint NOT NULL,
  `bundle_item_id` bigint NOT NULL,
  `order_id` bigint NULL,
  `status` enum('ordered','error') NOT NULL,
  `error_message` varchar(1000) NULL,
  PRIMARY KEY (`id`), KEY `idx_bundle_order_items` (`bundle_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `customer_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `description` varchar(500) NULL,
  `badge` varchar(80) NULL,
  `min_spent` decimal(15,4) NOT NULL DEFAULT 0,
  `discount_percent` decimal(6,2) NOT NULL DEFAULT 0,
  `priority` int NOT NULL DEFAULT 0,
  `auto_upgrade` tinyint(1) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_customer_group_name` (`name`), KEY `idx_customer_group_auto` (`is_active`,`auto_upgrade`,`min_spent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `group_service_visibility` (
  `service_id` int NOT NULL,
  `customer_group_id` int NOT NULL,
  `is_visible` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`service_id`,`customer_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `payment_method_bonuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `payment_method_id` int NOT NULL,
  `label` varchar(120) NULL,
  `bonus_type` enum('fixed','percent') NOT NULL DEFAULT 'percent',
  `bonus_value` decimal(10,4) NOT NULL DEFAULT 0,
  `max_bonus` decimal(15,4) NOT NULL DEFAULT 0,
  `starts_at` datetime NULL,
  `ends_at` datetime NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_payment_bonus_method` (`payment_method_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `provider_balance_snapshots` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `provider_id` int NOT NULL,
  `balance` decimal(18,6) NOT NULL,
  `currency_code` varchar(10) NOT NULL,
  `captured_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_provider_balance_snap` (`provider_id`,`captured_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `provider_reconciliations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `provider_id` int NOT NULL,
  `reconcile_date` date NOT NULL,
  `currency_code` varchar(10) NOT NULL,
  `opening_balance` decimal(18,6) NULL,
  `closing_balance` decimal(18,6) NULL,
  `expected_cost` decimal(18,6) NOT NULL DEFAULT 0,
  `actual_spend` decimal(18,6) NULL,
  `variance` decimal(18,6) NULL,
  `status` enum('draft','reviewed','closed') NOT NULL DEFAULT 'draft',
  `note` varchar(1000) NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_provider_reconcile` (`provider_id`,`reconcile_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `admin_api_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `token_prefix` varchar(16) NOT NULL,
  `scopes` text NOT NULL,
  `allowed_ips` text NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `expires_at` datetime NULL,
  `last_used_at` datetime NULL,
  `last_ip` varchar(45) NULL,
  `created_by` int NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_admin_api_token_hash` (`token_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `user_notifications` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `type` varchar(80) NOT NULL,
  `title` varchar(190) NOT NULL,
  `message` text NULL,
  `url` varchar(500) NULL,
  `severity` enum('info','success','warning','danger') NOT NULL DEFAULT 'info',
  `read_at` datetime NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_user_notification` (`user_id`,`read_at`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `admin_notifications` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `type` varchar(80) NOT NULL,
  `title` varchar(190) NOT NULL,
  `message` text NULL,
  `url` varchar(500) NULL,
  `severity` enum('info','success','warning','danger') NOT NULL DEFAULT 'info',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_admin_notification_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `admin_notification_reads` (
  `notification_id` bigint NOT NULL,
  `admin_user_id` int NOT NULL,
  `read_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`notification_id`,`admin_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `email_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `slug` varchar(100) NOT NULL,
  `name` varchar(190) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body_html` mediumtext NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `updated_by` int NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_email_template_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `admin_audit_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `admin_user_id` int NOT NULL,
  `action` varchar(190) NOT NULL,
  `entity_type` varchar(100) NOT NULL,
  `entity_id` varchar(190) NULL,
  `metadata_json` longtext NULL,
  `ip_address` varchar(45) NULL,
  `user_agent` varchar(500) NULL,
  `prev_hash` char(64) NOT NULL,
  `row_hash` char(64) NOT NULL,
  `hash_version` tinyint NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`), KEY `idx_audit_admin` (`admin_user_id`,`created_at`), UNIQUE KEY `uq_audit_hash` (`row_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `backup_records` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) NOT NULL,
  `status` enum('running','completed','failed','deleted') NOT NULL DEFAULT 'running',
  `file_size` bigint NOT NULL DEFAULT 0,
  `sha256` char(64) NULL,
  `created_by` int NULL,
  `error_message` varchar(1000) NULL,
  `started_at` datetime NULL,
  `finished_at` datetime NULL,
  `deleted_at` datetime NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_backup_status` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `email_templates` (`slug`,`name`,`subject`,`body_html`,`is_active`) VALUES
('welcome','Hoş Geldiniz','{{site_name}} hesabınız hazır','<h2>Hoş geldiniz {{username}}</h2><p>{{site_name}} hesabınız başarıyla oluşturuldu.</p>',1),
('order_status','Sipariş Durumu','Siparişiniz güncellendi: #{{order_id}}','<h2>Sipariş durumu</h2><p>#{{order_id}} numaralı siparişinizin yeni durumu: <strong>{{status}}</strong></p>',1),
('payment_approved','Ödeme Onayı','Bakiyeniz hesabınıza eklendi','<h2>Ödemeniz onaylandı</h2><p>{{amount}} tutarındaki bakiye hesabınıza eklendi.</p>',1),
('security_alert','Güvenlik Uyarısı','{{site_name}} güvenlik bildirimi','<h2>Güvenlik bildirimi</h2><p>{{message}}</p>',1);

INSERT IGNORE INTO `staff_permissions` (`permission_key`,`name`,`group_name`) VALUES
('bulk.manage','Toplu yönetim işlemleri','Operasyon'),
('provider.logs','Sağlayıcı istek/senkron logları','Servis'),
('provider.test','Provider API test laboratuvarı','Servis'),
('bundles.manage','Birleşik servis paketleri','Servis'),
('customer_groups.manage','Müşteri grupları / bayi seviyeleri','Kullanıcı'),
('postpaid.manage','Vadeli bayi kredisi yönetimi','Finans'),
('admin_api.manage','Admin API v2 yönetimi','Sistem'),
('notifications.manage','Admin bildirim merkezi','Sistem'),
('email_templates.manage','E-posta şablon yönetimi','İletişim'),
('telegram.manage','Telegram operasyon entegrasyonu','İletişim'),
('audit.view','Admin audit logunu görüntüleme','Güvenlik'),
('backups.manage','Yedekleme ve geri yükleme','Güvenlik');

INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
('telegram_ops_enabled','0'),
('telegram_ops_bot_token',''),
('telegram_ops_chat_ids',''),
('backup_include_uploads','1'),
('backup_retention_count','10'),
('backup_auto_notify','1')
ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;

INSERT IGNORE INTO `cron_tasks` (`task_key`,`name`,`interval_minutes`,`batch_size`,`is_enabled`) VALUES
('cancel_queue','Asenkron Sipariş İptal Kuyruğu',1,50,1),
('customer_group_upgrade','Müşteri Seviyesi Otomatik Güncelleme',60,500,1),
('provider_reconciliation','Sağlayıcı Maliyet / Borç Mutabakatı',1440,50,1),
('automatic_backup','Otomatik Yedekleme',1440,1,1),
('notification_cleanup','Eski Bildirim Temizliği',1440,1000,1);

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
-- v2 güvenlik + profesyonel özellik paketi
-- Mevcut ayar/değerleri silmez; yalnız gerekli alan ve tabloları ekler.

ALTER TABLE `api_clients` MODIFY `api_key` varchar(80) NOT NULL;
ALTER TABLE `users`
  ADD COLUMN `email_two_factor_enabled` tinyint(1) NOT NULL DEFAULT 0 AFTER `two_factor_secret`,
  ADD COLUMN `telegram_user_id` bigint NULL AFTER `email_two_factor_enabled`;
ALTER TABLE `support_tickets` ADD COLUMN `department_id` int NULL AFTER `priority`;
ALTER TABLE `child_panels`
  ADD COLUMN `dns_status` enum('pending','verified','failed') NOT NULL DEFAULT 'pending' AFTER `domain`,
  ADD COLUMN `dns_last_checked_at` datetime NULL AFTER `dns_status`,
  ADD COLUMN `ssl_status` enum('pending','active','failed','expired') NOT NULL DEFAULT 'pending' AFTER `dns_last_checked_at`,
  ADD COLUMN `ssl_expires_at` datetime NULL AFTER `ssl_status`,
  ADD COLUMN `ssl_last_checked_at` datetime NULL AFTER `ssl_expires_at`,
  ADD COLUMN `ssl_last_error` text NULL AFTER `ssl_last_checked_at`;

CREATE TABLE IF NOT EXISTS `support_departments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `description` varchar(500) NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int NOT NULL DEFAULT 0,
  `working_hours_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `timezone` varchar(64) NOT NULL DEFAULT 'Europe/Istanbul',
  `accept_after_hours` tinyint(1) NOT NULL DEFAULT 1,
  `after_hours_message` varchar(500) NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_support_department_active` (`is_active`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `support_departments` (`name`,`description`,`is_active`,`sort_order`)
SELECT 'Genel Destek','Genel destek talepleri',1,0
WHERE NOT EXISTS (SELECT 1 FROM `support_departments` LIMIT 1);

CREATE TABLE IF NOT EXISTS `support_department_hours` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `department_id` int NOT NULL,
  `day_of_week` tinyint NOT NULL,
  `open_time` time NOT NULL DEFAULT '09:00:00',
  `close_time` time NOT NULL DEFAULT '18:00:00',
  `is_closed` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_support_department_day` (`department_id`,`day_of_week`), KEY `idx_support_hours_department` (`department_id`,`day_of_week`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `service_target_policies` (
  `service_id` int NOT NULL,
  `mode` enum('off','blacklist','whitelist') NOT NULL DEFAULT 'off',
  `block_message` varchar(500) NULL,
  `updated_by` int NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`service_id`), KEY `idx_target_policy_mode` (`mode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `service_target_rules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `rule_type` enum('exact','domain','contains','prefix','username') NOT NULL DEFAULT 'exact',
  `rule_value` varchar(1000) NOT NULL,
  `note` varchar(255) NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_target_rule_service` (`service_id`,`is_active`,`id`), KEY `idx_target_rule_type` (`service_id`,`rule_type`,`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `service_target_block_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `user_id` int NULL,
  `policy_mode` varchar(20) NOT NULL,
  `rule_id` bigint NULL,
  `target` varchar(1000) NOT NULL,
  `source` varchar(50) NOT NULL DEFAULT 'web',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_target_block_service` (`service_id`,`created_at`), KEY `idx_target_block_user` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `settings` (`setting_key`,`setting_value`) VALUES ('moni_support_target_schema_revision','2026-09-29.1');

CREATE TABLE IF NOT EXISTS `service_reviews` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `service_id` int NOT NULL,
  `order_id` bigint NOT NULL,
  `rating` tinyint NOT NULL,
  `comment` varchar(1000) NULL,
  `status` enum('approved','pending','rejected') NOT NULL DEFAULT 'approved',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_service_review_order` (`order_id`), KEY `idx_service_review_service` (`service_id`,`status`,`rating`), KEY `idx_service_review_user` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `email_two_factor_codes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `code_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT 0,
  `ip_address` varchar(45) NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_email2fa_user` (`user_id`,`used`,`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `telegram_miniapp_links` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `link_code_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_telegram_link_hash` (`link_code_hash`), KEY `idx_telegram_link_user` (`user_id`,`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `child_panel_domain_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `child_panel_id` bigint NOT NULL,
  `event_type` varchar(50) NOT NULL,
  `status` varchar(30) NOT NULL,
  `message` text NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_child_domain_log` (`child_panel_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
('trusted_proxy_ips',''),
('telegram_miniapp_bot_token',''),
('telegram_miniapp_bot_username',''),
('child_panel_dns_cname_target',''),
('child_panel_dns_a_target',''),
('child_panel_ssl_automation','0'),
('child_panel_ssl_email',''),
('child_panel_certbot_path','/usr/bin/certbot')
ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;

INSERT INTO `plugins` (`slug`,`name`,`description`,`version`,`is_enabled`,`is_core`) VALUES
('telegram_miniapp','Telegram Mini App','Telegram içinden güvenli kullanıcı paneli erişimi','1.0.0',0,0)
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`),`description`=VALUES(`description`),`version`=VALUES(`version`);

-- Tema kontrast uzantıları

ALTER TABLE `theme_defaults`
  ADD COLUMN `header_text_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `sidebar_text_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `card_text_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `muted_text_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `input_text_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `link_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `secondary_button_text_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `font_family` varchar(30) NOT NULL DEFAULT 'inter',
  ADD COLUMN `heading_font_family` varchar(30) NOT NULL DEFAULT 'inter',
  ADD COLUMN `input_bg_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `input_border_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `secondary_button_bg_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `secondary_button_hover_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `wallet_button_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `wallet_button_hover_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `wallet_button_text_color` varchar(20) DEFAULT NULL;
ALTER TABLE `theme_settings`
  ADD COLUMN `header_text_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `sidebar_text_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `card_text_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `muted_text_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `input_text_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `link_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `secondary_button_text_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `font_family` varchar(30) NOT NULL DEFAULT 'inter',
  ADD COLUMN `heading_font_family` varchar(30) NOT NULL DEFAULT 'inter',
  ADD COLUMN `input_bg_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `input_border_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `secondary_button_bg_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `secondary_button_hover_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `wallet_button_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `wallet_button_hover_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `wallet_button_text_color` varchar(20) DEFAULT NULL;

UPDATE `theme_defaults` SET header_text_color='#f8fafc',sidebar_text_color='#e5e7eb',card_text_color='#f8fafc',muted_text_color='#a7b0c0',input_text_color='#f8fafc',link_color='#c4b5fd',secondary_button_text_color='#f8fafc' WHERE theme_name='dark';
UPDATE `theme_defaults` SET header_text_color='#1f2937',sidebar_text_color='#1f2937',card_text_color='#1f2937',muted_text_color='#6b7280',input_text_color='#1f2937',link_color='#4f46e5',secondary_button_text_color='#1f2937' WHERE theme_name='light';
UPDATE `theme_defaults` SET header_text_color='#f7eafa',sidebar_text_color='#f7eafa',card_text_color='#f7eafa',muted_text_color='#caa6cf',input_text_color='#f7eafa',link_color='#e9b7ef',secondary_button_text_color='#f7eafa' WHERE theme_name='bogurtlen';
UPDATE `theme_defaults` SET header_text_color='#2d2d2d',sidebar_text_color='#3a3214',card_text_color='#2d2d2d',muted_text_color='#6b5d2e',input_text_color='#2d2d2d',link_color='#6b4c00',secondary_button_text_color='#2d2d2d' WHERE theme_name='ananas';
UPDATE `theme_defaults` SET header_text_color='#ffffff',sidebar_text_color='#023047',card_text_color='#03045e',muted_text_color='#46616f',input_text_color='#03045e',link_color='#005f73',secondary_button_text_color='#03045e' WHERE theme_name='okyanus';
UPDATE `theme_defaults` SET header_text_color='#ffffff',sidebar_text_color='#1b4332',card_text_color='#1b4332',muted_text_color='#46635c',input_text_color='#1b4332',link_color='#1b5e40',secondary_button_text_color='#1b4332' WHERE theme_name='orman';

UPDATE `theme_defaults` SET font_family='inter',heading_font_family='inter',input_bg_color='#17172f',input_border_color='#373763',secondary_button_bg_color='#2a2a4a',secondary_button_hover_color='#34345a',wallet_button_color='#117a57',wallet_button_hover_color='#0f7654',wallet_button_text_color='#ffffff' WHERE theme_name='dark';
UPDATE `theme_defaults` SET font_family='inter',heading_font_family='inter',input_bg_color='#ffffff',input_border_color='#d5d9e2',secondary_button_bg_color='#eef1f7',secondary_button_hover_color='#e2e7f0',wallet_button_color='#198754',wallet_button_hover_color='#146c43',wallet_button_text_color='#ffffff' WHERE theme_name='light';
UPDATE `theme_defaults` SET font_family='inter',heading_font_family='trebuchet',input_bg_color='#25102d',input_border_color='#5a2d66',secondary_button_bg_color='#482050',secondary_button_hover_color='#5b2a65',wallet_button_color='#17835c',wallet_button_hover_color='#126b4b',wallet_button_text_color='#ffffff' WHERE theme_name='bogurtlen';
UPDATE `theme_defaults` SET font_family='system',heading_font_family='trebuchet',input_bg_color='#fffef6',input_border_color='#e5d77e',secondary_button_bg_color='#fff4bf',secondary_button_hover_color='#f6e68d',wallet_button_color='#198754',wallet_button_hover_color='#146c43',wallet_button_text_color='#ffffff' WHERE theme_name='ananas';
UPDATE `theme_defaults` SET font_family='inter',heading_font_family='inter',input_bg_color='#f4fdff',input_border_color='#90e0ef',secondary_button_bg_color='#dff8fc',secondary_button_hover_color='#c7f0f7',wallet_button_color='#007f73',wallet_button_hover_color='#00665d',wallet_button_text_color='#ffffff' WHERE theme_name='okyanus';
UPDATE `theme_defaults` SET font_family='system',heading_font_family='trebuchet',input_bg_color='#f4fbf6',input_border_color='#95d5b2',secondary_button_bg_color='#e5f4e9',secondary_button_hover_color='#d3ebda',wallet_button_color='#2d6a4f',wallet_button_hover_color='#24563f',wallet_button_text_color='#ffffff' WHERE theme_name='orman';

UPDATE `theme_settings` t JOIN `theme_defaults` d ON d.theme_name=t.theme_name
SET t.header_text_color=COALESCE(t.header_text_color,d.header_text_color),
    t.sidebar_text_color=COALESCE(t.sidebar_text_color,d.sidebar_text_color),
    t.card_text_color=COALESCE(t.card_text_color,d.card_text_color),
    t.muted_text_color=COALESCE(t.muted_text_color,d.muted_text_color),
    t.input_text_color=COALESCE(t.input_text_color,d.input_text_color),
    t.link_color=COALESCE(t.link_color,d.link_color),
    t.secondary_button_text_color=COALESCE(t.secondary_button_text_color,d.secondary_button_text_color),
    t.font_family=COALESCE(NULLIF(t.font_family,''),d.font_family),
    t.heading_font_family=COALESCE(NULLIF(t.heading_font_family,''),d.heading_font_family),
    t.input_bg_color=COALESCE(t.input_bg_color,d.input_bg_color),
    t.input_border_color=COALESCE(t.input_border_color,d.input_border_color),
    t.secondary_button_bg_color=COALESCE(t.secondary_button_bg_color,d.secondary_button_bg_color),
    t.secondary_button_hover_color=COALESCE(t.secondary_button_hover_color,d.secondary_button_hover_color),
    t.wallet_button_color=COALESCE(t.wallet_button_color,d.wallet_button_color),
    t.wallet_button_hover_color=COALESCE(t.wallet_button_hover_color,d.wallet_button_hover_color),
    t.wallet_button_text_color=COALESCE(t.wallet_button_text_color,d.wallet_button_text_color);


-- v2 - Yalnız Ana Sayfa için bağımsız çoklu arayüz sistemi
CREATE TABLE IF NOT EXISTS `homepage_interfaces` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `layout_key` varchar(40) NOT NULL DEFAULT 'nebula',
  `description` varchar(500) DEFAULT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `background_color` varchar(20) NOT NULL DEFAULT '#070B18',
  `surface_color` varchar(20) NOT NULL DEFAULT '#10172B',
  `surface_alt_color` varchar(20) NOT NULL DEFAULT '#151E36',
  `text_color` varchar(20) NOT NULL DEFAULT '#F8FAFC',
  `muted_color` varchar(20) NOT NULL DEFAULT '#9BA8C7',
  `primary_color` varchar(20) NOT NULL DEFAULT '#7C5CFC',
  `secondary_color` varchar(20) NOT NULL DEFAULT '#00D084',
  `accent_color` varchar(20) NOT NULL DEFAULT '#22D3EE',
  `button_text_color` varchar(20) NOT NULL DEFAULT '#FFFFFF',
  `header_bg_color` varchar(20) NOT NULL DEFAULT '#080D1B',
  `header_text_color` varchar(20) NOT NULL DEFAULT '#F8FAFC',
  `border_color` varchar(20) NOT NULL DEFAULT '#253151',
  `hero_badge` varchar(180) DEFAULT NULL,
  `hero_title` varchar(320) DEFAULT NULL,
  `hero_description` text DEFAULT NULL,
  `primary_cta_text` varchar(100) DEFAULT NULL,
  `primary_cta_url` varchar(500) DEFAULT NULL,
  `secondary_cta_text` varchar(100) DEFAULT NULL,
  `secondary_cta_url` varchar(500) DEFAULT NULL,
  `hero_image` varchar(500) DEFAULT NULL,
  `secondary_image` varchar(500) DEFAULT NULL,
  `background_image` varchar(500) DEFAULT NULL,
  `announcement_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `announcement_text` varchar(500) DEFAULT NULL,
  `announcement_cta_text` varchar(120) DEFAULT NULL,
  `announcement_cta_url` varchar(500) DEFAULT NULL,
  `options_json` mediumtext DEFAULT NULL,
  `custom_css` mediumtext DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_homepage_interface_slug` (`slug`), KEY `idx_homepage_interface_active` (`is_enabled`,`is_active`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `homepage_interfaces` (`name`,`slug`,`layout_key`,`description`,`is_enabled`,`is_active`,`background_color`,`surface_color`,`surface_alt_color`,`text_color`,`muted_color`,`primary_color`,`secondary_color`,`accent_color`,`button_text_color`,`header_bg_color`,`header_text_color`,`border_color`,`hero_badge`,`hero_title`,`hero_description`,`primary_cta_text`,`primary_cta_url`,`secondary_cta_text`,`secondary_cta_url`,`announcement_enabled`,`announcement_text`,`announcement_cta_text`,`announcement_cta_url`,`options_json`,`sort_order`) VALUES
('Nebula Split','nebula-split','nebula','Koyu ve modern sosyal medya hizmet vitrini.',1,1,'#070B18','#10172B','#151E36','#F8FAFC','#9BA8C7','#7C5CFC','#00D084','#22D3EE','#FFFFFF','#080D1B','#F8FAFC','#253151','Hızlı, güvenli ve kolay sipariş','Sosyal medya hizmetlerini tek yerden yönetin','Instagram, TikTok, YouTube ve daha fazlası için güncel hizmetleri keşfedin; hesabınızı oluşturup hemen sipariş verin.','Ücretsiz Başla','/register.php','Servisleri İncele','/services.php',0,NULL,NULL,NULL,'{}',10),
('Ivory Commerce','ivory-commerce','ivory','Aydınlık, servis keşfi ve dönüşüm odaklı ticari ana sayfa.',1,0,'#F7F9FC','#FFFFFF','#EEF3FA','#15213A','#64748B','#2257D6','#14B8A6','#FF7A59','#FFFFFF','#FFFFFF','#15213A','#DBE3EF','İhtiyacınız olan hizmetler tek yerde','İhtiyacınız olan sosyal medya servisini daha hızlı bulun','Kategorileri keşfedin, güncel fiyat ve limitleri inceleyin, hesabınızı oluşturup hemen sipariş verin.','Hemen Başla','/register.php','Kataloğu Aç','/services.php',0,NULL,NULL,NULL,'{}',20),
('Pulse Campaign','pulse-campaign','pulse','Kampanya barı, merkez görsel ve güçlü müşteri mesajlarıyla hareketli arayüz.',1,0,'#0D0E13','#171923','#202332','#FAFAFB','#A9ADBD','#FF4D8D','#8B5CF6','#FFB800','#FFFFFF','#0C0D12','#FFFFFF','#2C3041','Sosyal medyada büyümek şimdi daha kolay','Hedeflerinize uygun hizmetleri kolayca keşfedin','Popüler sosyal medya hizmetlerini inceleyin, size uygun seçeneği bulun ve siparişlerinizi kolayca takip edin.','Ücretsiz Hesap Aç','/register.php','Servisleri Gör','/services.php',1,'Yeni ve popüler sosyal medya hizmetlerini keşfedin.','Keşfet','/services.php','{}',30),
('Aurora Bento','aurora-bento','aurora','Bento kartlar ve sosyal medya hizmetlerini öne çıkaran canlı düzen.',1,0,'#08111F','#0F1B31','#142441','#F3F8FF','#91A4C2','#4F46E5','#10B981','#22D3EE','#FFFFFF','#08101D','#F8FAFC','#263B5A','Popüler sosyal medya hizmetleri bir arada','Sosyal medyada ihtiyaç duyduğunuz hizmetlere kolayca ulaşın','Güncel seçenekleri karşılaştırın, bütçenize uygun hizmeti seçin ve siparişinizi hesabınızdan takip edin.','Başlayın','/register.php','Servisleri İncele','/services.php',0,NULL,NULL,NULL,'{}',40),
('Glass Studio','glass-studio','glass','Cam yüzeyler, ışık efektleri ve premium hizmet sunumuna odaklı.',1,0,'#071119','#0D1B26','#132633','#F3FAFC','#91A9B6','#8B5CF6','#14B8A6','#38BDF8','#FFFFFF','#08121A','#F8FAFC','#24404D','Kolay sipariş, güvenli ödeme, düzenli takip','Sosyal medya hedeflerinize birkaç adımda ulaşın','İhtiyacınız olan hizmeti seçin, güvenle ödeme yapın ve siparişinizin durumunu hesabınızdan izleyin.','Hesap Oluştur','/register.php','Servislere Bak','/services.php',0,NULL,NULL,NULL,'{}',50),
('Editorial Trust','editorial-trust','editorial','Büyük tipografi ve kurumsal güven diliyle sade ama iddialı görünüm.',1,0,'#F4F0E7','#FBF9F4','#EAE3D7','#171717','#6B645A','#1F2937','#9A5B2E','#C46A31','#FFFFFF','#F4F0E7','#171717','#D8D0C2','SOSYAL MEDYA HİZMETLERİ','Sosyal medya hizmetlerinde sade ve güvenilir deneyim.','Güncel hizmetleri inceleyin, şeffaf fiyatları karşılaştırın ve siparişlerinizi kolayca takip edin.','Ücretsiz Başla','/register.php','Servis Kataloğu','/services.php',0,NULL,NULL,NULL,'{}',60),
('Market Grid','market-grid','market','Katalog, kategori ve popüler hizmetleri mağaza mantığıyla öne çıkarır.',1,0,'#F8FAFC','#FFFFFF','#EEF2F7','#172033','#64748B','#0F766E','#16A34A','#F97316','#FFFFFF','#FFFFFF','#172033','#DCE3EC','Güncel sosyal medya hizmetleri','Aradığınız hizmeti saniyeler içinde bulun','Aktif kategoriler, güncel fiyatlar ve size uygun seçenekler tek bir yerde.','Hesap Aç','/register.php','Katalogda Ara','/services.php',0,NULL,NULL,NULL,'{}',70),
('Neon Social','neon-ops','neon','Dinamik renkler ve sosyal medya hizmetlerini öne çıkaran enerjik arayüz.',1,0,'#050816','#0B1022','#111833','#F5F7FF','#8D99B7','#00CFA5','#8B5CF6','#00D9FF','#04110E','#060918','#F5F7FF','#1D2A4D','HIZLI • GÜVENLİ • KOLAY','Sosyal medyada hedeflerinize daha kolay ulaşın','Popüler hizmetleri keşfedin, bütçenize uygun seçimi yapın ve siparişinizi anlık olarak takip edin.','Ücretsiz Başla','/register.php','Servisleri İncele','/services.php',0,NULL,NULL,NULL,'{}',80);

-- ============================================================
-- v2 - ek özellikler / mevcut site güvenli yükseltme
-- Yalnız yeni tablo/kolon ve eksik seed ekler. Mevcut değerleri silmez veya sıfırlamaz.
-- ============================================================
SET NAMES utf8mb4;

ALTER TABLE `api_clients`
  ADD COLUMN `updated_at` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

ALTER TABLE `child_panels`
  ADD COLUMN `allow_custom_smtp` tinyint(1) NOT NULL DEFAULT 0,
  ADD COLUMN `allow_custom_payments` tinyint(1) NOT NULL DEFAULT 0;

ALTER TABLE `payment_requests`
  ADD COLUMN `child_panel_id` bigint NULL,
  ADD COLUMN `child_payment_method_id` bigint NULL,
  ADD COLUMN `child_bank_account_id` bigint NULL;

ALTER TABLE `gateway_transactions`
  ADD COLUMN `child_panel_id` bigint NULL;

CREATE TABLE IF NOT EXISTS `customer_api_request_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `api_client_id` int NULL,
  `user_id` int NULL,
  `endpoint` varchar(190) NOT NULL DEFAULT '',
  `action` varchar(80) NOT NULL DEFAULT '',
  `http_method` varchar(10) NOT NULL DEFAULT 'GET',
  `ip_address` varchar(45) NOT NULL DEFAULT '',
  `http_status` smallint NOT NULL DEFAULT 200,
  `duration_ms` int NOT NULL DEFAULT 0,
  `request_json` mediumtext NULL,
  `response_json` mediumtext NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_customer_api_user_time` (`user_id`,`created_at`),
  KEY `idx_customer_api_client_time` (`api_client_id`,`created_at`),
  KEY `idx_customer_api_action_status` (`action`,`http_status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `notification_preferences` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `category` varchar(50) NOT NULL,
  `in_app_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `email_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `push_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_notification_preference` (`user_id`,`category`),
  KEY `idx_notification_preference_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `favorite_service_alert_state` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `service_id` int NOT NULL,
  `last_price` decimal(15,4) NULL,
  `last_status` varchar(30) NULL,
  `initialized_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_notified_at` datetime NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_favorite_alert_user_service` (`user_id`,`service_id`),
  KEY `idx_favorite_alert_update` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `child_panel_smtp_settings` (
  `child_panel_id` bigint NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `smtp_host` varchar(255) NULL,
  `smtp_port` int NOT NULL DEFAULT 587,
  `smtp_username` varchar(255) NULL,
  `smtp_password` text NULL,
  `smtp_encryption` enum('tls','ssl','none') NOT NULL DEFAULT 'tls',
  `from_email` varchar(255) NULL,
  `from_name` varchar(190) NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`child_panel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `child_panel_email_templates` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `child_panel_id` bigint NOT NULL,
  `slug` varchar(100) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body_html` mediumtext NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_child_email_template` (`child_panel_id`,`slug`),
  KEY `idx_child_email_panel` (`child_panel_id`,`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `child_panel_payment_methods` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `child_panel_id` bigint NOT NULL,
  `type` enum('bank','iyzico') NOT NULL,
  `name` varchar(120) NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `min_amount` decimal(15,4) NOT NULL DEFAULT 10,
  `max_amount` decimal(15,4) NOT NULL DEFAULT 50000,
  `config_json` mediumtext NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_child_payment_type` (`child_panel_id`,`type`),
  KEY `idx_child_payment_active` (`child_panel_id`,`is_enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `child_panel_bank_accounts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `child_panel_id` bigint NOT NULL,
  `bank_name` varchar(190) NOT NULL,
  `account_holder` varchar(190) NOT NULL,
  `iban` varchar(64) NOT NULL,
  `branch_code` varchar(80) NULL,
  `account_number` varchar(100) NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_child_bank_panel` (`child_panel_id`,`is_active`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `plugins` (`slug`,`name`,`description`,`version`,`is_enabled`,`is_core`) VALUES
('customer_api_history','Müşteri API İstek Geçmişi','Müşteri API çağrılarını gizli alanları sansürleyerek kaydeder.','2.0.0',0,0),
('provider_smart_matcher','Akıllı Provider Servis Eşleştirme','Sağlayıcı servislerini yerel servislerle benzerlik puanına göre eşleştirir.','2.0.0',1,0),
('real_delivery_eta','Gerçek Teslim Süresi Tahmini','Gerçek tamamlanan siparişlerden teslim süresi tahmini üretir.','2.0.0',0,0),
('favorite_service_alerts','Favori Servis Fiyat / Durum Alarmı','Favori servis fiyat veya durum değişimlerini bildirir.','2.0.0',1,0),
('notification_preferences','Bildirim Tercih Merkezi','Kullanıcı bildirimlerini kategori bazında yönetir.','2.0.0',1,0),
('human_captcha','Turnstile / hCaptcha','Cloudflare Turnstile veya hCaptcha insan doğrulaması sağlar.','2.0.0',0,0);

INSERT IGNORE INTO `cron_tasks` (`task_key`,`name`,`interval_minutes`,`batch_size`,`is_enabled`) VALUES
('favorite_service_alerts','Favori Servis Fiyat / Durum Alarmı',5,250,1);



-- v2 sabit marka temizliği: yalnız bilinen eski varsayılan değerler değiştirilir; özelleştirilmiş içerikler korunur.
UPDATE `homepage_interfaces`
SET `hero_badge`='SOSYAL MEDYA HİZMETLERİ'
WHERE `slug`='editorial-trust' AND `hero_badge`='MONI / SOSYAL MEDYA HİZMETLERİ';

UPDATE `translations`
SET `translation_value`='SMM Panel API v2 standardı ile uyumlu. Standart SMM API istemcileri ve benzeri sistemlerle entegre çalışır.'
WHERE `lang_code`='tr' AND `translation_key`='api_description_v2'
  AND `translation_value`='SMM Panel API v2 standardı ile uyumlu. PerfectPanel, Glycon, JAP, SmartPanel ve benzeri sistemlerle entegre çalışır.';
UPDATE `translations`
SET `translation_value`='Compatible with the SMM Panel API v2 standard and standard SMM API clients.'
WHERE `lang_code`='en' AND `translation_key`='api_description_v2'
  AND `translation_value`='Compatible with SMM Panel API v2 standard. Integrates with PerfectPanel, Glycon, JAP, SmartPanel and similar systems.';

-- ============================================================
-- v2 operasyon ölçekleme / kalite / OpenAPI genişletmeleri
-- ============================================================
ALTER TABLE `services`
  ADD COLUMN `geo_supported` tinyint(1) NOT NULL DEFAULT 0,
  ADD COLUMN `geo_targets_json` mediumtext NULL,
  ADD COLUMN `geo_target_param` varchar(40) NOT NULL DEFAULT 'country',
  ADD COLUMN `quality_score` decimal(6,2) NULL,
  ADD COLUMN `quality_checked_at` datetime NULL;

ALTER TABLE `orders`
  ADD COLUMN `geo_target` varchar(80) NULL;

CREATE TABLE IF NOT EXISTS `order_dispatch_jobs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `status` enum('queued','processing','retry','completed','manual_review','failed','cancelled') NOT NULL DEFAULT 'queued',
  `manual_priority` enum('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
  `priority_updated_by` int NULL,
  `priority_updated_at` datetime NULL,
  `attempts` int NOT NULL DEFAULT 0,
  `next_attempt_at` datetime NULL,
  `locked_at` datetime NULL,
  `last_error` varchar(1000) NULL,
  `completed_at` datetime NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_order_dispatch_order` (`order_id`), KEY `idx_order_dispatch_queue` (`status`,`next_attempt_at`,`id`), KEY `idx_order_dispatch_manual_priority` (`status`,`manual_priority`,`next_attempt_at`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `service_working_hours` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `day_of_week` tinyint NOT NULL,
  `start_time` time NOT NULL DEFAULT '00:00:00',
  `end_time` time NOT NULL DEFAULT '23:59:59',
  `is_closed` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_service_working_day` (`service_id`,`day_of_week`), KEY `idx_service_hours_service` (`service_id`,`day_of_week`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `service_quality_metrics` (
  `service_id` int NOT NULL,
  `quality_score` decimal(6,2) NULL,
  `sample_size` int NOT NULL DEFAULT 0,
  `completed_count` int NOT NULL DEFAULT 0,
  `partial_count` int NOT NULL DEFAULT 0,
  `cancelled_count` int NOT NULL DEFAULT 0,
  `refunded_count` int NOT NULL DEFAULT 0,
  `error_count` int NOT NULL DEFAULT 0,
  `avg_completion_seconds` int NULL,
  `calculated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`service_id`), KEY `idx_quality_score` (`quality_score`,`sample_size`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `service_quarantines` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `quality_score` decimal(6,2) NULL,
  `reason` varchar(500) NOT NULL,
  `status` enum('active','released') NOT NULL DEFAULT 'active',
  `released_by` int NULL,
  `released_at` datetime NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_quarantine_service_status` (`service_id`,`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `provider_status_mappings` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `provider_id` int NULL,
  `raw_status` varchar(100) NOT NULL,
  `local_status` enum('pending','processing','in_progress','completed','partial','cancelled','refunded','error') NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_provider_status_map` (`provider_id`,`raw_status`), KEY `idx_provider_status_raw` (`raw_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `api_sandbox_orders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `service_id` int NULL,
  `link` varchar(1000) NULL,
  `quantity` int NOT NULL DEFAULT 0,
  `status` varchar(40) NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_sandbox_user_time` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `plugins` (`slug`,`name`,`description`,`version`,`is_enabled`,`is_core`) VALUES
('api_sandbox','API Sandbox / Mock Modu','Gerçek bakiye veya provider çağrısı olmadan API entegrasyon testleri sağlar.','2.0.0',0,0),
('social_account_precheck','Sosyal Hesap Ön Kontrolü','Sipariş öncesi sosyal bağlantı biçimi, güvenli hedef ve isteğe bağlı erişilebilirlik kontrolü yapar.','2.0.0',0,0);

INSERT IGNORE INTO `cron_tasks` (`task_key`,`name`,`interval_minutes`,`batch_size`,`is_enabled`) VALUES
('order_dispatch','Bekleyen Siparişleri API’ye Gönder',1,100,1),
('service_quality','Servis Kalite Puanı / Karantina',5,200,1),
('profit_protection','Minimum Kâr Koruma',1,500,1);

INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
('api_default_rate_limit_per_min','300'),
('order_dispatch_max_attempts','5'),
('service_auto_quarantine_enabled','1'),
('service_auto_quarantine_threshold','35'),
('service_auto_quarantine_min_sample','20'),
('min_profit_protection_enabled','0'),
('min_profit_protection_type','percent'),
('min_profit_protection_value','20'),
('moni_v2_runtime_schema_revision','2026-09-30.1')
ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;

-- v2 geo hedefinin zamanlanmış/drip-feed alt siparişlerinde korunması
ALTER TABLE `orders_dripfeed` ADD COLUMN `geo_target` varchar(80) NULL;
ALTER TABLE `scheduled_orders` ADD COLUMN `geo_target` varchar(80) NULL;

-- =====================================================
-- Moni v2 - kullanıcı paneli tema yüzeyleri
-- Büyük API/bakiye/profil/bonus/referral kartlarını aktif temaya bağlar.
-- =====================================================
ALTER TABLE `theme_defaults`
  ADD COLUMN `panel_hero_start_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `panel_hero_end_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `panel_hero_text_color` varchar(20) DEFAULT NULL;
ALTER TABLE `theme_settings`
  ADD COLUMN `panel_hero_start_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `panel_hero_end_color` varchar(20) DEFAULT NULL,
  ADD COLUMN `panel_hero_text_color` varchar(20) DEFAULT NULL;

UPDATE `theme_defaults` SET panel_hero_start_color='#29294d',panel_hero_end_color='#34345f',panel_hero_text_color='#f8fafc' WHERE theme_name='dark';
UPDATE `theme_defaults` SET panel_hero_start_color='#eef0ff',panel_hero_end_color='#e5e8fb',panel_hero_text_color='#1f2937' WHERE theme_name='light';
UPDATE `theme_defaults` SET panel_hero_start_color='#35143f',panel_hero_end_color='#482050',panel_hero_text_color='#f7eafa' WHERE theme_name='bogurtlen';
UPDATE `theme_defaults` SET panel_hero_start_color='#fff8d4',panel_hero_end_color='#ffedaa',panel_hero_text_color='#3a3214' WHERE theme_name='ananas';
UPDATE `theme_defaults` SET panel_hero_start_color='#e5f8fc',panel_hero_end_color='#c9f1f8',panel_hero_text_color='#03045e' WHERE theme_name='okyanus';
UPDATE `theme_defaults` SET panel_hero_start_color='#e8f5ec',panel_hero_end_color='#d4eadb',panel_hero_text_color='#1b4332' WHERE theme_name='orman';

UPDATE `theme_settings` t
JOIN `theme_defaults` d ON d.theme_name=t.theme_name
SET t.panel_hero_start_color=COALESCE(t.panel_hero_start_color,d.panel_hero_start_color),
    t.panel_hero_end_color=COALESCE(t.panel_hero_end_color,d.panel_hero_end_color),
    t.panel_hero_text_color=COALESCE(t.panel_hero_text_color,d.panel_hero_text_color);

-- ============================================================
-- Moni v2 Commerce Pro: planlı fiyat, miktar kademeleri, banka mutabakatı
-- ============================================================
ALTER TABLE `users` ADD COLUMN `bank_reference_code` varchar(32) NULL;
ALTER TABLE `payment_requests` ADD COLUMN `payment_reference` varchar(40) NULL;

CREATE TABLE IF NOT EXISTS `service_price_schedules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `requested_price` decimal(15,4) NOT NULL,
  `previous_price` decimal(15,4) NULL,
  `applied_price` decimal(15,4) NULL,
  `execute_at` datetime NOT NULL,
  `status` enum('pending','applied','cancelled','failed') NOT NULL DEFAULT 'pending',
  `floor_adjusted` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int NULL,
  `cancelled_by` int NULL,
  `applied_at` datetime NULL,
  `cancelled_at` datetime NULL,
  `error_message` varchar(1000) NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_price_schedule_due` (`status`,`execute_at`,`id`), KEY `idx_price_schedule_service` (`service_id`,`execute_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `service_price_tiers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `min_quantity` int NOT NULL,
  `max_quantity` int NULL,
  `pricing_type` enum('fixed_per_1000','discount_percent') NOT NULL,
  `pricing_value` decimal(15,4) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_service_tiers` (`service_id`,`is_active`,`min_quantity`,`max_quantity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bank_statement_imports` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `bank_account_id` int NOT NULL,
  `filename` varchar(255) NOT NULL,
  `file_hash` char(64) NOT NULL,
  `file_format` varchar(10) NOT NULL,
  `status` enum('processing','completed','failed') NOT NULL DEFAULT 'processing',
  `row_count` int NOT NULL DEFAULT 0,
  `imported_count` int NOT NULL DEFAULT 0,
  `matched_count` int NOT NULL DEFAULT 0,
  `duplicate_count` int NOT NULL DEFAULT 0,
  `created_by` int NULL,
  `error_message` varchar(1000) NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` datetime NULL,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_bank_import_file` (`bank_account_id`,`file_hash`), KEY `idx_bank_import_time` (`bank_account_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bank_statement_entries` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `import_id` bigint NOT NULL,
  `bank_account_id` int NOT NULL,
  `entry_hash` char(64) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `currency_code` varchar(8) NOT NULL DEFAULT 'TRY',
  `direction` enum('credit','debit') NOT NULL,
  `sender_name` varchar(255) NULL,
  `description` text NULL,
  `reference_no` varchar(190) NULL,
  `raw_json` mediumtext NULL,
  `match_status` enum('unmatched','suggested','matched','approved','ignored') NOT NULL DEFAULT 'unmatched',
  `matched_payment_request_id` int NULL,
  `match_score` decimal(6,2) NULL,
  `match_reason` varchar(500) NULL,
  `matched_at` datetime NULL,
  `matched_by` int NULL,
  `approved_at` datetime NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_bank_statement_entry` (`bank_account_id`,`entry_hash`), KEY `idx_bank_entry_match` (`match_status`,`direction`,`transaction_date`), KEY `idx_bank_entry_payment` (`matched_payment_request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `cron_tasks` (`task_key`,`name`,`interval_minutes`,`batch_size`,`is_enabled`) VALUES
('scheduled_service_prices','Zamanlanmış Servis Fiyat Değişiklikleri',1,200,1),
('bank_reconciliation','Banka Ekstresi Otomatik Mutabakat',5,250,1);

INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
('bank_reconciliation_date_window_days','7'),
('bank_reconciliation_amount_tolerance','0.01'),
('bank_reconciliation_auto_approve_exact','0'),
('moni_commerce_pro_schema_revision','2026-09-29.1')
ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;

UPDATE settings SET setting_value='2026-09-29.1' WHERE setting_key='moni_commerce_pro_schema_revision';

-- ============================================================================
-- Moni v2 Ops Pro: kârlılık, servis şablonları, muhasebe ve cron watchdog
-- ============================================================================
CREATE TABLE IF NOT EXISTS `service_description_templates` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(190) NOT NULL,
  `category_id` int NULL,
  `content` mediumtext NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int NOT NULL DEFAULT 0,
  `created_by` int NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_desc_tpl_active` (`is_active`,`sort_order`,`id`), KEY `idx_desc_tpl_category` (`category_id`,`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `service_clone_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source_service_id` int NOT NULL,
  `cloned_service_id` int NOT NULL,
  `cloned_by` int NULL,
  `copied_relations` varchar(500) NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_clone_source` (`source_service_id`,`created_at`), KEY `idx_clone_target` (`cloned_service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `accounting_integrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(190) NOT NULL,
  `adapter` varchar(50) NOT NULL DEFAULT 'generic_rest',
  `base_url` varchar(800) NOT NULL,
  `auth_mode` enum('none','bearer','api_key','basic') NOT NULL DEFAULT 'bearer',
  `auth_header` varchar(120) NULL,
  `api_token` text NULL,
  `api_username` text NULL,
  `api_password` text NULL,
  `company_code` varchar(190) NULL,
  `event_types` varchar(255) NOT NULL DEFAULT 'deposit,order,refund',
  `allow_private_network` tinyint(1) NOT NULL DEFAULT 0,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `auto_sync` tinyint(1) NOT NULL DEFAULT 1,
  `last_transaction_id` int NOT NULL DEFAULT 0,
  `last_sync_at` datetime NULL,
  `last_success_at` datetime NULL,
  `last_error` varchar(1000) NULL,
  `created_by` int NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_accounting_enabled` (`is_enabled`,`auto_sync`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `accounting_sync_queue` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `integration_id` bigint NOT NULL,
  `transaction_id` int NOT NULL,
  `event_type` varchar(80) NOT NULL,
  `payload_json` mediumtext NULL,
  `status` enum('pending','processing','sent','failed','ignored') NOT NULL DEFAULT 'pending',
  `attempts` int NOT NULL DEFAULT 0,
  `next_attempt_at` datetime NULL,
  `locked_until` datetime NULL,
  `http_code` int NULL,
  `external_id` varchar(255) NULL,
  `response_body` text NULL,
  `last_error` varchar(1000) NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sent_at` datetime NULL,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_accounting_tx` (`integration_id`,`transaction_id`), KEY `idx_accounting_queue` (`status`,`next_attempt_at`,`id`), KEY `idx_accounting_integration` (`integration_id`,`status`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `cron_watchdog_state` (
  `task_key` varchar(100) NOT NULL,
  `is_missed` tinyint(1) NOT NULL DEFAULT 0,
  `missed_since` datetime NULL,
  `last_alert_at` datetime NULL,
  `last_recovered_at` datetime NULL,
  `last_message` varchar(1000) NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`task_key`), KEY `idx_watchdog_missed` (`is_missed`,`last_alert_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `cron_tasks` (`task_key`,`name`,`interval_minutes`,`batch_size`,`is_enabled`) VALUES
('accounting_sync','Muhasebe Programı Entegrasyon Senkronu',5,100,1),
('cron_watchdog','Cron Kaçırma ve Görev Sağlığı Kontrolü',5,100,1);

INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
('profit_heatmap_critical_threshold','10'),
('profit_heatmap_healthy_threshold','25'),
('accounting_sync_max_attempts','5'),
('cron_watchdog_enabled','1'),
('cron_watchdog_main_threshold_minutes','3'),
('cron_watchdog_task_grace_minutes','5'),
('cron_watchdog_repeat_minutes','60'),
('cron_watchdog_email_enabled','0'),
('cron_watchdog_last_web_check_at',''),
('cron_main_last_heartbeat_at',''),
('moni_ops_pro_schema_revision','2026-09-29.1')
ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;


-- ============================================================================
-- Moni v2 Growth Pro: hedef önizleme, kişisel sıralama, drop rate, çok dil,
-- PWA, Web Push ve e-posta teslim edilebilirlik merkezi
-- ============================================================================
CREATE TABLE IF NOT EXISTS `service_translations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `language_code` varchar(12) NOT NULL,
  `description` text NULL,
  `updated_by` int NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_service_language` (`service_id`,`language_code`), KEY `idx_service_translation_lang` (`language_code`,`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `user_service_affinity` (
  `user_id` int NOT NULL,
  `service_id` int NOT NULL,
  `order_count` bigint NOT NULL DEFAULT 0,
  `total_quantity` bigint NOT NULL DEFAULT 0,
  `last_order_at` datetime NULL,
  `score` decimal(16,4) NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`service_id`), KEY `idx_affinity_user_score` (`user_id`,`score`,`last_order_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `order_drop_observations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `service_id` int NOT NULL,
  `start_count` bigint NOT NULL,
  `ordered_quantity` bigint NOT NULL,
  `expected_count` bigint NOT NULL,
  `observed_count` bigint NOT NULL,
  `drop_amount` bigint NOT NULL DEFAULT 0,
  `drop_percent` decimal(7,3) NOT NULL DEFAULT 0,
  `observed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_checked_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_drop_order` (`order_id`), KEY `idx_drop_service_time` (`service_id`,`last_checked_at`), KEY `idx_drop_percent` (`service_id`,`drop_percent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `service_drop_metrics` (
  `service_id` int NOT NULL,
  `sample_orders` int NOT NULL DEFAULT 0,
  `dropped_orders` int NOT NULL DEFAULT 0,
  `average_drop_percent` decimal(7,3) NOT NULL DEFAULT 0,
  `max_drop_percent` decimal(7,3) NOT NULL DEFAULT 0,
  `last_observed_at` datetime NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`service_id`), KEY `idx_drop_metric_average` (`average_drop_percent`,`sample_orders`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `web_push_subscriptions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `endpoint` text NOT NULL,
  `endpoint_hash` char(64) NOT NULL,
  `p256dh` varchar(255) NULL,
  `auth_secret` varchar(255) NULL,
  `user_agent` varchar(500) NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_seen_at` datetime NULL,
  `last_push_at` datetime NULL,
  `last_error` varchar(1000) NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_push_endpoint` (`endpoint_hash`), KEY `idx_push_user` (`user_id`,`is_active`), KEY `idx_push_active` (`is_active`,`last_push_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `web_push_queue` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `notification_type` varchar(80) NOT NULL DEFAULT 'general',
  `title` varchar(190) NOT NULL,
  `body` varchar(1000) NULL,
  `url` varchar(500) NULL,
  `icon` varchar(500) NULL,
  `status` enum('pending','sent','failed') NOT NULL DEFAULT 'pending',
  `attempts` int NOT NULL DEFAULT 0,
  `next_attempt_at` datetime NULL,
  `last_error` varchar(1000) NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sent_at` datetime NULL,
  PRIMARY KEY (`id`), KEY `idx_push_queue` (`status`,`next_attempt_at`,`id`), KEY `idx_push_queue_user` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `email_delivery_events` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `event_type` enum('sent','failed','delivered','bounce','complaint','deferred','opened','clicked') NOT NULL,
  `recipient` varchar(320) NULL,
  `message_id` varchar(255) NULL,
  `provider` varchar(80) NULL,
  `detail` varchar(1000) NULL,
  `payload_json` mediumtext NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_email_event_type` (`event_type`,`created_at`), KEY `idx_email_event_recipient` (`recipient`,`created_at`), KEY `idx_email_message` (`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `plugins` (`slug`,`name`,`description`,`version`,`is_enabled`,`is_core`) VALUES
('target_preview','Hedef Canlı Önizleme','Girilen hedef URL adresini sunucudan veri çekmeden kullanıcının tarayıcısında küçük, güvenli bir tarayıcı önizlemesi olarak açar. Demo modunda otomatik aktiftir.','3.2.0',0,0),
('pwa_app','PWA / Telefona Uygulama Gibi Kurulum','Kullanıcı panelini yönetilebilir Progressive Web App olarak kurulabilir hale getirir.','2.0.0',0,0);

INSERT IGNORE INTO `cron_tasks` (`task_key`,`name`,`interval_minutes`,`batch_size`,`is_enabled`) VALUES
('service_drop_analysis','Servis Drop Rate Analizi',60,50,1),
('web_push_delivery','Web Push Bildirim Kuyruğu',1,100,1);

INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
('personalized_service_sorting_enabled','1'),
('drop_analysis_min_age_minutes','60'),
('drop_analysis_recheck_hours','24'),
('web_push_enabled','1'),
('web_push_ttl','120'),
('pwa_app_name','Moni'),
('pwa_short_name','Moni'),
('pwa_description','SMM Panel'),
('pwa_theme_color','#6c5ce7'),
('pwa_background_color','#111327'),
('pwa_display','standalone'),
('pwa_start_url','/kullanici/'),
('pwa_scope','/'),
('pwa_icon_192',''),
('pwa_icon_512',''),
('pwa_offline_title','Bağlantı yok'),
('pwa_offline_message','İnternet bağlantınızı kontrol edip tekrar deneyin.'),
('pwa_install_prompt','1'),
('email_dkim_enabled','0'),
('email_dkim_domain',''),
('email_dkim_selector','default'),
('email_dkim_private_key',''),
('email_bounce_webhook_token',''),
('moni_growth_pro_schema_revision','2026-09-29.1')
ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;

-- =====================================================
-- MONI v2 Shield Pro
-- =====================================================
CREATE TABLE IF NOT EXISTS `service_capacity_settings` (`service_id` int NOT NULL,`capacity_mode` enum('auto','manual') NOT NULL DEFAULT 'auto',`hourly_capacity` bigint NOT NULL DEFAULT 0,`warning_percent` decimal(6,2) NOT NULL DEFAULT 70.00,`critical_percent` decimal(6,2) NOT NULL DEFAULT 100.00,`manual_status` enum('available','busy','critical','paused') NOT NULL DEFAULT 'available',`show_exact_percent` tinyint(1) NOT NULL DEFAULT 0,`updated_by` int NULL,`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,`updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(`service_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `service_capacity_metrics` (`service_id` int NOT NULL,`effective_capacity` bigint NOT NULL DEFAULT 0,`last_hour_quantity` bigint NOT NULL DEFAULT 0,`active_quantity` bigint NOT NULL DEFAULT 0,`pending_orders` int NOT NULL DEFAULT 0,`utilization_percent` decimal(8,2) NOT NULL DEFAULT 0.00,`capacity_status` enum('unknown','available','busy','critical','paused') NOT NULL DEFAULT 'unknown',`calculated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(`service_id`),KEY `idx_capacity_status`(`capacity_status`,`calculated_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `referral_fraud_events` (`id` bigint NOT NULL AUTO_INCREMENT,`referral_log_id` int NULL,`referrer_id` int NOT NULL,`referred_id` int NOT NULL,`risk_score` smallint NOT NULL DEFAULT 0,`decision` enum('allow','review','blocked') NOT NULL DEFAULT 'allow',`ip_address` varchar(45) NULL,`device_id` char(64) NULL,`user_agent_hash` char(64) NULL,`reasons_json` text NULL,`reviewed_by` int NULL,`reviewed_at` datetime NULL,`review_note` varchar(1000) NULL,`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(`id`),KEY `idx_ref_fraud_decision`(`decision`,`created_at`),KEY `idx_ref_fraud_referrer`(`referrer_id`,`created_at`),KEY `idx_ref_fraud_referred`(`referred_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE `referral_logs` ADD COLUMN `fraud_status` enum('clear','review','blocked') NOT NULL DEFAULT 'clear', ADD COLUMN `fraud_score` smallint NOT NULL DEFAULT 0, ADD COLUMN `fraud_event_id` bigint NULL;
CREATE TABLE IF NOT EXISTS `email_domain_rules` (`id` bigint NOT NULL AUTO_INCREMENT,`domain` varchar(255) NOT NULL,`rule_type` enum('allow','block') NOT NULL DEFAULT 'block',`source` enum('builtin','custom') NOT NULL DEFAULT 'custom',`is_active` tinyint(1) NOT NULL DEFAULT 1,`note` varchar(500) NULL,`created_by` int NULL,`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,`updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(`id`),UNIQUE KEY `uq_email_domain_rule`(`domain`,`rule_type`),KEY `idx_email_domain_active`(`rule_type`,`is_active`,`domain`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `email_domain_block_logs` (`id` bigint NOT NULL AUTO_INCREMENT,`email_hash` char(64) NOT NULL,`domain` varchar(255) NOT NULL,`source` varchar(40) NOT NULL DEFAULT 'register',`ip_address` varchar(45) NULL,`device_id` char(64) NULL,`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(`id`),KEY `idx_email_block_domain`(`domain`,`created_at`),KEY `idx_email_block_time`(`created_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO `plugins` (`slug`,`name`,`description`,`version`,`is_enabled`,`is_core`) VALUES ('service_capacity_indicator','Servis Kapasite Göstergesi','Servislerin mevcut yükünü ve kapasite durumunu kullanıcı kataloğunda gösterir.','2.0.0',0,0);
INSERT IGNORE INTO `cron_tasks` (`task_key`,`name`,`interval_minutes`,`batch_size`,`is_enabled`) VALUES ('service_capacity_refresh','Servis Kapasite Göstergesi Yenileme',5,250,1);
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('service_capacity_default_warning','70'),('service_capacity_default_critical','100'),('service_capacity_show_user','1'),('referral_fraud_enabled','1'),('referral_fraud_review_threshold','60'),('referral_fraud_block_threshold','90'),('referral_fraud_hold_suspicious_bonus','1'),('disposable_email_block_enabled','1'),('moni_shield_pro_schema_revision','2026-09-29.1') ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;
INSERT IGNORE INTO `email_domain_rules` (`domain`,`rule_type`,`source`,`is_active`,`note`) VALUES ('10minutemail.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('10minutemail.net','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('20minutemail.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('dispostable.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('emailondeck.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('fakeinbox.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('getairmail.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('getnada.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('guerrillamail.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('guerrillamail.net','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('guerrillamail.org','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('guerrillamailblock.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('inboxkitten.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('maildrop.cc','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('mailinator.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('mailinator.net','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('mailnesia.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('mintemail.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('mohmal.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('mytemp.email','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('sharklasers.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('spam4.me','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('temp-mail.org','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('temp-mail.io','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('tempmail.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('tempmail.net','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('tempmailaddress.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('throwawaymail.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('trashmail.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('trashmail.net','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('yopmail.com','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('yopmail.fr','block','builtin',1,'Yerleşik geçici e-posta alan adı'),('yopmail.net','block','builtin',1,'Yerleşik geçici e-posta alan adı');

-- =========================================================
-- MONI Premium Üyelik Sistemi (2026-09-29)
-- =========================================================
ALTER TABLE `users`
  ADD COLUMN `deleted_at` datetime NULL,
  ADD COLUMN `deleted_by` int NULL;

CREATE TABLE IF NOT EXISTS `premium_packages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `description` text NULL,
  `price` decimal(15,4) NOT NULL DEFAULT 0,
  `duration_days` int NOT NULL DEFAULT 30,
  `dispatch_priority_percent` decimal(5,2) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_premium_packages_active` (`is_active`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `user_premium_memberships` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `package_id` int NOT NULL,
  `starts_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `status` enum('active','expired','cancelled') NOT NULL DEFAULT 'active',
  `auto_renew` tinyint(1) NOT NULL DEFAULT 0,
  `source` enum('admin','balance','system') NOT NULL DEFAULT 'admin',
  `last_renewed_at` datetime NULL,
  `cashback_checked_at` datetime NULL,
  `cancelled_at` datetime NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_premium_user_status` (`user_id`,`status`,`expires_at`),
  KEY `idx_premium_package` (`package_id`,`status`,`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `premium_cashback_rules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `package_id` int NOT NULL,
  `name` varchar(150) NOT NULL,
  `spend_threshold` decimal(15,4) NOT NULL,
  `reward_type` enum('fixed','percent') NOT NULL DEFAULT 'fixed',
  `reward_value` decimal(15,4) NOT NULL,
  `cycle` enum('membership','monthly') NOT NULL DEFAULT 'membership',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cashback_package` (`package_id`,`is_active`,`spend_threshold`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `premium_cashback_rewards` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `membership_id` bigint NOT NULL,
  `rule_id` bigint NOT NULL,
  `cycle_key` varchar(40) NOT NULL,
  `eligible_spend` decimal(15,4) NOT NULL DEFAULT 0,
  `reward_amount` decimal(15,4) NOT NULL DEFAULT 0,
  `transaction_id` bigint NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_premium_reward` (`membership_id`,`rule_id`,`cycle_key`),
  KEY `idx_premium_reward_user` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `staff_permissions` (`permission_key`,`name`,`group_name`) VALUES
('premium.manage','Premium üyelik yönetimi','Kullanıcı');

INSERT IGNORE INTO `cron_tasks` (`task_key`,`name`,`interval_minutes`,`batch_size`,`is_enabled`) VALUES
('premium_memberships','Premium Üyelik / Cashback İşlemleri',5,250,1);

INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('moni_premium_schema_revision','2026-09-29.2') ON DUPLICATE KEY UPDATE `setting_value`=VALUES(`setting_value`);

-- =========================================================
-- MONI Premium Membership Plugin v3 (2026-09-29)
-- Gerçek eklenti mimarisi + fiyat/servis/API/rozet/trial/cashback hakları
-- =========================================================
INSERT INTO `plugins` (`slug`,`name`,`description`,`version`,`is_enabled`,`is_core`)
VALUES ('premium_memberships','Premium Üyelik Sistemi','Paket bazlı sipariş önceliği, servis/kategori indirimi, premium özel servis, API hız avantajı, rozet, trial, paket geçişleri ve gelişmiş cashback.','3.0.0',1,0)
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`),`description`=VALUES(`description`),`version`=VALUES(`version`);

ALTER TABLE `premium_packages`
  ADD COLUMN `tier_level` int NOT NULL DEFAULT 0 AFTER `duration_days`,
  ADD COLUMN `service_discount_percent` decimal(5,2) NOT NULL DEFAULT 0 AFTER `dispatch_priority_percent`,
  ADD COLUMN `api_rate_bonus_percent` int NOT NULL DEFAULT 0 AFTER `service_discount_percent`,
  ADD COLUMN `badge_text` varchar(80) NULL AFTER `api_rate_bonus_percent`,
  ADD COLUMN `badge_color` varchar(20) NOT NULL DEFAULT '#7c3aed' AFTER `badge_text`,
  ADD COLUMN `cashback_multiplier` decimal(6,2) NOT NULL DEFAULT 1.00 AFTER `badge_color`,
  ADD COLUMN `cashback_cap_amount` decimal(15,4) NOT NULL DEFAULT 0 AFTER `cashback_multiplier`,
  ADD COLUMN `cashback_cap_cycle` enum('membership','monthly') NOT NULL DEFAULT 'monthly' AFTER `cashback_cap_amount`,
  ADD COLUMN `cashback_wait_days` int NOT NULL DEFAULT 0 AFTER `cashback_cap_cycle`,
  ADD COLUMN `trial_days` int NOT NULL DEFAULT 0 AFTER `cashback_wait_days`;
ALTER TABLE `user_premium_memberships`
  ADD COLUMN `scheduled_package_id` int NULL AFTER `cashback_checked_at`,
  ADD COLUMN `scheduled_auto_renew` tinyint(1) NOT NULL DEFAULT 0 AFTER `scheduled_package_id`;
ALTER TABLE `user_premium_memberships` MODIFY COLUMN `source` enum('admin','balance','system','trial','upgrade','downgrade') NOT NULL DEFAULT 'admin';
ALTER TABLE `premium_cashback_rewards`
  ADD COLUMN `cap_cycle_key` varchar(60) NOT NULL DEFAULT '' AFTER `cycle_key`,
  ADD COLUMN `status` enum('pending','paid','cancelled') NOT NULL DEFAULT 'paid' AFTER `reward_amount`,
  ADD COLUMN `available_at` datetime NULL AFTER `status`,
  ADD COLUMN `paid_at` datetime NULL AFTER `available_at`,
  ADD COLUMN `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`;
UPDATE `premium_cashback_rewards` SET `status`='paid',`paid_at`=COALESCE(`paid_at`,`created_at`) WHERE `transaction_id` IS NOT NULL;
CREATE TABLE IF NOT EXISTS `premium_category_discounts` (`id` bigint NOT NULL AUTO_INCREMENT,`package_id` int NOT NULL,`category_id` int NOT NULL,`discount_percent` decimal(5,2) NOT NULL DEFAULT 0,`is_active` tinyint(1) NOT NULL DEFAULT 1,`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,`updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(`id`),UNIQUE KEY `uq_premium_cat_discount`(`package_id`,`category_id`),KEY `idx_premium_cat`(`category_id`,`is_active`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `premium_service_access` (`id` bigint NOT NULL AUTO_INCREMENT,`package_id` int NOT NULL,`service_id` int NOT NULL,`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(`id`),UNIQUE KEY `uq_premium_service_access`(`package_id`,`service_id`),KEY `idx_premium_service`(`service_id`,`package_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `premium_trial_claims` (`id` bigint NOT NULL AUTO_INCREMENT,`user_id` int NOT NULL,`package_id` int NOT NULL,`membership_id` bigint NULL,`claimed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(`id`),UNIQUE KEY `uq_premium_trial`(`user_id`,`package_id`),KEY `idx_premium_trial_pkg`(`package_id`,`claimed_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `premium_membership_changes` (`id` bigint NOT NULL AUTO_INCREMENT,`user_id` int NOT NULL,`membership_id` bigint NULL,`from_package_id` int NULL,`to_package_id` int NULL,`change_type` enum('purchase','renew','upgrade','downgrade_scheduled','downgrade_applied','trial','cancel','admin_change') NOT NULL,`credit_amount` decimal(15,4) NOT NULL DEFAULT 0,`charged_amount` decimal(15,4) NOT NULL DEFAULT 0,`effective_at` datetime NOT NULL,`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(`id`),KEY `idx_premium_changes_user`(`user_id`,`created_at`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE `premium_membership_changes` MODIFY COLUMN `change_type` enum('purchase','renew','upgrade','downgrade_scheduled','downgrade_applied','trial','cancel','admin_change') NOT NULL;
INSERT IGNORE INTO `staff_permissions` (`permission_key`,`name`,`group_name`) VALUES ('premium.manage','Premium üyelik yönetimi','Kullanıcı');
INSERT IGNORE INTO `cron_tasks` (`task_key`,`name`,`interval_minutes`,`batch_size`,`is_enabled`) VALUES ('premium_memberships','Premium Üyelik / Cashback İşlemleri',5,250,1);
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES ('moni_premium_schema_revision','2026-09-29.3') ON DUPLICATE KEY UPDATE `setting_value`=VALUES(`setting_value`);


-- Operations Intelligence schema
-- Moni Operations Intelligence - mevcut site yükseltme yaması
-- Veri silmez. SLA izleme tablolarını, cron görevini ve dashboard eşiklerini ekler.

CREATE TABLE IF NOT EXISTS `provider_sla_policies` (
  `provider_id` int NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `window_hours` int NOT NULL DEFAULT 24,
  `min_success_rate` decimal(6,2) NOT NULL DEFAULT 98.00,
  `max_avg_latency_ms` int NOT NULL DEFAULT 3000,
  `min_health_score` decimal(6,2) NOT NULL DEFAULT 90.00,
  `max_consecutive_failures` int NOT NULL DEFAULT 3,
  `alert_on_breach` tinyint(1) NOT NULL DEFAULT 1,
  `updated_by` int NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`provider_id`), KEY `idx_sla_enabled` (`is_enabled`,`provider_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `provider_sla_snapshots` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `provider_id` int NOT NULL,
  `window_hours` int NOT NULL,
  `total_requests` int NOT NULL DEFAULT 0,
  `successful_requests` int NOT NULL DEFAULT 0,
  `failed_requests` int NOT NULL DEFAULT 0,
  `success_rate` decimal(6,2) NOT NULL DEFAULT 100.00,
  `avg_latency_ms` decimal(12,2) NOT NULL DEFAULT 0.00,
  `health_score` decimal(6,2) NOT NULL DEFAULT 100.00,
  `consecutive_failures` int NOT NULL DEFAULT 0,
  `is_breached` tinyint(1) NOT NULL DEFAULT 0,
  `breach_reasons` varchar(1000) NULL,
  `bucket_at` datetime NOT NULL,
  `captured_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_sla_provider_bucket` (`provider_id`,`bucket_at`), KEY `idx_sla_snap_time` (`provider_id`,`captured_at`), KEY `idx_sla_snap_breach` (`is_breached`,`captured_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `provider_sla_breaches` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `provider_id` int NOT NULL,
  `status` enum('open','resolved') NOT NULL DEFAULT 'open',
  `reasons` varchar(1000) NOT NULL,
  `metrics_json` mediumtext NULL,
  `opened_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_seen_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `resolved_at` datetime NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_sla_breach_open` (`provider_id`,`status`,`opened_at`), KEY `idx_sla_breach_status` (`status`,`last_seen_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `cron_tasks` (`task_key`,`name`,`interval_minutes`,`batch_size`,`is_enabled`) VALUES ('provider_sla','Sağlayıcı SLA Kontrolü',5,100,1);
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
 ('provider_balance_forecast_window_hours','168'),
 ('provider_balance_forecast_critical_hours','12'),
 ('provider_balance_forecast_warning_hours','72'),
 ('queue_health_warning_seconds','300'),
 ('queue_health_critical_seconds','1800'),
 ('moni_ops_intelligence_schema_revision','2026-09-29.1')
ON DUPLICATE KEY UPDATE `setting_value`=IF(`setting_key`='moni_ops_intelligence_schema_revision',VALUES(`setting_value`),`setting_value`);



-- ============================================================
-- 2026-09-30: Manuel sipariş önceliği + kısmi bakım + canlı hedef önizleme
-- ============================================================
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
 ('partial_maintenance_orders','0'),
 ('partial_maintenance_payments','0'),
 ('partial_maintenance_api','0'),
 ('partial_maintenance_child_panels','0'),
 ('partial_maintenance_orders_message',''),
 ('partial_maintenance_payments_message',''),
 ('partial_maintenance_api_message',''),
 ('partial_maintenance_child_panels_message','')
ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;

INSERT INTO `plugins` (`slug`,`name`,`description`,`version`,`is_enabled`,`is_core`) VALUES
 ('target_preview','Hedef Canlı Önizleme','Girilen hedef URL adresini sunucudan veri çekmeden kullanıcının tarayıcısında küçük, güvenli bir tarayıcı önizlemesi olarak açar. Demo modunda otomatik aktiftir.','3.2.0',0,0)
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`),`description`=VALUES(`description`),`version`=VALUES(`version`);

-- ============================================================
-- 2026-09-30: Otomatik servis rozetleri + sipariş neden kodları + sandbox senaryoları
-- ============================================================
-- MONI selected feature pack 2026-09-30
-- Veri silmez. Mevcut eklenti aktif/pasif tercihleri korunur.
CREATE TABLE IF NOT EXISTS service_auto_badges (service_id int NOT NULL,badge_key varchar(40) NOT NULL,label varchar(80) NOT NULL,icon varchar(60) NOT NULL DEFAULT 'fa-award',score decimal(8,2) NOT NULL DEFAULT 0,reason varchar(500) NULL,calculated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(service_id,badge_key),KEY idx_auto_badges_key_score(badge_key,score,calculated_at),KEY idx_auto_badges_service_time(service_id,calculated_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS order_status_reason_catalog (code varchar(64) NOT NULL,status varchar(40) NOT NULL,user_label varchar(190) NOT NULL,admin_label varchar(255) NOT NULL,user_description varchar(500) NULL,admin_description varchar(1000) NULL,is_user_visible tinyint(1) NOT NULL DEFAULT 1,is_active tinyint(1) NOT NULL DEFAULT 1,sort_order int NOT NULL DEFAULT 0,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(code),KEY idx_reason_status(status,is_active,sort_order)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS order_status_reason_mappings (id bigint NOT NULL AUTO_INCREMENT,provider_id int NULL,match_field enum('status','message','both') NOT NULL DEFAULT 'both',match_type enum('contains','equals','regex') NOT NULL DEFAULT 'contains',raw_pattern varchar(255) NOT NULL,reason_code varchar(64) NOT NULL,priority int NOT NULL DEFAULT 100,is_active tinyint(1) NOT NULL DEFAULT 1,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY idx_reason_mapping_provider(provider_id,is_active,priority),KEY idx_reason_mapping_code(reason_code)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS order_status_reason_history (id bigint NOT NULL AUTO_INCREMENT,order_id int NOT NULL,status varchar(40) NOT NULL,reason_code varchar(64) NOT NULL,source varchar(40) NOT NULL DEFAULT 'system',provider_id int NULL,raw_status varchar(190) NULL,raw_message varchar(1000) NULL,user_message varchar(500) NULL,admin_message varchar(1000) NULL,created_by int NULL,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY idx_reason_history_order(order_id,id),KEY idx_reason_history_code(reason_code,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO plugins(slug,name,description,version,is_enabled,is_core) VALUES
('service_auto_badges','Otomatik Servis Rozet Motoru','Gerçek sipariş, kalite, hız, drop, fiyat ve talep verilerinden servis rozetleri üretir.','1.0.0',0,0),
('order_status_reasons','Sipariş Durum Neden Kodları','Sipariş durumlarının nedenini standart kod, kullanıcı açıklaması, provider eşleme ve geçmiş ile yönetir.','1.0.0',0,0)
ON DUPLICATE KEY UPDATE name=VALUES(name),description=VALUES(description),version=VALUES(version);
INSERT INTO cron_tasks(task_key,name,interval_minutes,batch_size,is_enabled) VALUES('service_auto_badges','Otomatik Servis Rozetlerini Hesapla',15,300,0) ON DUPLICATE KEY UPDATE name=VALUES(name);
INSERT INTO plugin_settings(plugin_slug,setting_key,setting_value) VALUES
('service_auto_badges','auto_badge_min_sample','10'),('service_auto_badges','auto_badge_fast_seconds','3600'),('service_auto_badges','auto_badge_stable_score','90'),('service_auto_badges','auto_badge_low_drop_percent','2.5'),('service_auto_badges','auto_badge_popular_30d_orders','50'),('service_auto_badges','auto_badge_best_price_percentile','20'),('service_auto_badges','auto_badge_max_per_service','3') ON DUPLICATE KEY UPDATE setting_value=setting_value;

ALTER TABLE `orders`
  ADD COLUMN `reason_code` varchar(64) NULL,
  ADD COLUMN `reason_source` varchar(40) NULL,
  ADD COLUMN `reason_updated_at` datetime NULL;
ALTER TABLE `api_sandbox_orders`
  ADD COLUMN `scenario` varchar(60) NOT NULL DEFAULT 'happy_path',
  ADD COLUMN `scenario_started_at` datetime NULL,
  ADD COLUMN `scenario_data_json` mediumtext NULL;

INSERT INTO order_status_reason_catalog(code,status,user_label,admin_label,user_description,admin_description,is_user_visible,is_active,sort_order) VALUES
('pending_queue','pending','Kuyrukta bekliyor','Sipariş gönderim kuyruğunda','Siparişiniz sıraya alındı ve sağlayıcıya gönderilmeyi bekliyor.','Henüz provider order ID oluşmadı.',0,1,10),
('provider_processing','processing','İşleme alındı','Sağlayıcı işliyor','Siparişiniz sağlayıcı tarafından işleme alındı.','Provider processing/in progress yanıtı.',1,1,20),
('completed_success','completed','Başarıyla tamamlandı','Tamamlandı','Sipariş başarıyla tamamlandı.','Provider terminal completed sonucu.',1,1,30),
('partial_provider','partial','Kısmi tamamlandı','Sağlayıcı kısmi tamamladı','Siparişin bir bölümü tamamlandı; eksik bölüm için sistem politikası uygulanır.','Provider partial sonucu veya remains > 0.',1,1,40),
('cancelled_provider','cancelled','Sağlayıcı tarafından iptal edildi','Provider iptali','Sağlayıcı siparişi iptal etti. Uygunsa bakiye iadesi otomatik işlenir.','Provider cancelled/canceled sonucu.',1,1,50),
('cancelled_user','cancelled','Kullanıcı tarafından iptal edildi','Kullanıcı iptali','Sipariş sizin talebinizle iptal edildi.','Kullanıcı iptal akışı.',1,1,55),
('cancelled_admin','cancelled','Yetkili tarafından iptal edildi','Admin iptali','Sipariş operasyon ekibi tarafından iptal edildi.','Admin manuel durum değişikliği.',1,1,56),
('refunded_provider','refunded','Ücret iade edildi','Provider iadesi','Sipariş ücreti bakiyenize iade edildi.','Provider refunded sonucu.',1,1,60),
('provider_rejected','error','Sağlayıcı siparişi reddetti','Provider rejected','Sağlayıcı siparişi kabul etmedi.','Rejected/invalid/denied benzeri provider cevabı.',1,1,70),
('invalid_target','cancelled','Hedef bağlantı uygun değil','Hedef politikası reddi','Girilen hedef bu servis için uygun olmadığı için sipariş işlenemedi.','Target validation veya platform kuralı reddi.',1,1,80),
('provider_timeout','error','Sağlayıcı yanıt vermedi','Provider timeout','Sağlayıcı geçici olarak yanıt vermedi. Sipariş operasyon ekibi tarafından kontrol ediliyor.','Timeout/connection failure.',1,1,90),
('provider_unknown','error','Sağlayıcı sonucu doğrulanamadı','Belirsiz provider sonucu','Sağlayıcı sonucu doğrulanamadığı için sipariş güvenli incelemeye alındı.','Ambiguous/unknown provider response.',1,1,100),
('manual_review','processing','Kontrol ediliyor','Manuel inceleme','Siparişiniz operasyon ekibi tarafından kontrol ediliyor.','Manuel review veya güvenlik kontrolü.',1,1,110),
('system_error','error','Teknik işlem hatası','Sistem hatası','Sipariş işlenirken teknik bir hata oluştu.','Genel güvenli fallback nedeni.',1,1,999)
ON DUPLICATE KEY UPDATE status=VALUES(status),user_label=VALUES(user_label),admin_label=VALUES(admin_label),user_description=VALUES(user_description),admin_description=VALUES(admin_description),is_user_visible=VALUES(is_user_visible),sort_order=VALUES(sort_order);
INSERT INTO settings(setting_key,setting_value) VALUES('moni_feature_pack_20260930_revision','2026-09-30.5') ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value);

-- --------------------------------------------------------
-- Completion Pack 2026-10-02: etiketler, eşzamanlı hedef koruması,
-- gecikmiş postpaid borç ve child panel uzak yedekleme.
-- --------------------------------------------------------
ALTER TABLE `users`
  ADD COLUMN `credit_due_days` int NOT NULL DEFAULT 7,
  ADD COLUMN `credit_due_at` datetime NULL,
  ADD COLUMN `credit_overdue_since` datetime NULL,
  ADD COLUMN `credit_overdue_notified_at` datetime NULL;

ALTER TABLE `child_panels`
  ADD COLUMN `remote_backup_enabled` tinyint(1) NOT NULL DEFAULT 0,
  ADD COLUMN `remote_backup_url` varchar(500) NULL,
  ADD COLUMN `remote_backup_token` text NULL,
  ADD COLUMN `remote_backup_interval_hours` int NOT NULL DEFAULT 24,
  ADD COLUMN `remote_backup_last_at` datetime NULL,
  ADD COLUMN `remote_backup_last_status` varchar(30) NULL,
  ADD COLUMN `remote_backup_last_error` varchar(1000) NULL;

CREATE TABLE IF NOT EXISTS `service_tags` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `slug` varchar(90) NOT NULL,
  `icon` varchar(80) NOT NULL DEFAULT 'fa-tag',
  `color` varchar(20) NOT NULL DEFAULT '#6d5dfc',
  `sort_order` int NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_service_tag_slug` (`slug`), KEY `idx_service_tag_active` (`is_active`,`sort_order`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `service_tag_map` (
  `service_id` int NOT NULL,
  `tag_id` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`service_id`,`tag_id`), KEY `idx_service_tag_map_tag` (`tag_id`,`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `same_target_order_guards` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `service_id` int NOT NULL,
  `target_hash` char(64) NOT NULL,
  `entity_type` enum('order','dripfeed') NOT NULL DEFAULT 'order',
  `entity_id` bigint NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_same_target_guard` (`user_id`,`service_id`,`target_hash`), KEY `idx_same_target_entity` (`entity_type`,`entity_id`), KEY `idx_same_target_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `child_panel_remote_backups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `child_panel_id` bigint NOT NULL,
  `status` enum('queued','success','failed') NOT NULL DEFAULT 'queued',
  `http_status` smallint NULL,
  `payload_sha256` char(64) NULL,
  `error_message` varchar(1000) NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `finished_at` datetime NULL,
  PRIMARY KEY (`id`), KEY `idx_child_backup_panel` (`child_panel_id`,`created_at`), KEY `idx_child_backup_status` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `plugins` (`slug`,`name`,`description`,`version`,`is_enabled`,`is_core`) VALUES
('same_target_concurrency','Aynı Hedefte Eşzamanlı Sipariş Koruması','Aynı servis ve hedefte önceki aktif sipariş tamamlanmadan yeni sipariş açılmasını engeller.','1.0.0',0,0);

INSERT IGNORE INTO `cron_tasks` (`task_key`,`name`,`interval_minutes`,`batch_size`,`is_enabled`) VALUES
('postpaid_overdue','Gecikmiş Borç Otomasyonu',30,500,1),
('child_panel_remote_backup','Child Panel Uzak Yedekleme',60,50,1);

INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
('postpaid_default_due_days','7'),
('postpaid_overdue_block_orders','1'),
('postpaid_overdue_notify_user','1'),
('postpaid_overdue_notify_admin','1'),
('service_reviews_require_moderation','0')
ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;
