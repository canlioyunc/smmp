<?php
error_reporting(E_ALL);ini_set('display_errors','0');set_time_limit(0);ignore_user_abort(true);
require_once __DIR__.'/config.php';
require_once __DIR__ . '/includes/MoniV2Compat.php';
require_once __DIR__.'/includes/MoniCron.php';
if(function_exists('moni_cron_watchdog_heartbeat'))moni_cron_watchdog_heartbeat($db);
$isCli=PHP_SAPI==='cli';$secret=defined('CRON_SECRET_KEY')?CRON_SECRET_KEY:'';
if(!$isCli){$key=(string)($_SERVER['HTTP_X_CRON_KEY']??'');if($secret===''||!hash_equals($secret,$key)){http_response_code(403);exit('Access Denied');}}
$only=null;if($isCli&&isset($argv[1])&&preg_match('/^[a-z0-9_]+$/',$argv[1]))$only=$argv[1];elseif(!$isCli&&!empty($_GET['task'])&&preg_match('/^[a-z0-9_]+$/',$_GET['task']))$only=$_GET['task'];
$result=moni_cron_run($db,$only);if(!$isCli){header('Content-Type: application/json; charset=utf-8');echo json_encode($result,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);}else{echo json_encode($result,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT).PHP_EOL;}
