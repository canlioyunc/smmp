<?php
require_once __DIR__ . '/config.php';
$userId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
if ($userId) {
    moni_security_event($userId, 'logout', 'info');
    if (moni_table_ready($db, 'user_sessions')) {
        $db->prepare("UPDATE user_sessions SET revoked_at=NOW() WHERE user_id=? AND session_hash=? AND revoked_at IS NULL")->execute([$userId, hash('sha256', session_id())]);
    }
}
moni_forget_remember_token($db);
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', ['expires'=>time()-42000,'path'=>$p['path'] ?: '/','domain'=>$p['domain'] ?: '','secure'=>(bool)$p['secure'],'httponly'=>true,'samesite'=>'Lax']);
}
session_destroy();
header('Location: /login.php?logout=1');
exit;
