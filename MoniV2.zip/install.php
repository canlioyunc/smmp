<?php
/**
 * Moni SMM Panel - Otomatik Kurulum Sihirbazı
 * Adım 1: Lisans Sözleşmesi
 * Adım 2: Veritabanı ve Temiz Kurulum
 * Adım 3: Admin Hesabı
 * Adım 4: Site Ayarları
 * Adım 5: Merkezi Cron
 */

// Hata raporlama
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Kurulum oturumunu da uygulama ile aynı güvenlik seviyesinde başlat.
if (session_status() === PHP_SESSION_NONE) {
    $installIsHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
        (getenv('MONI_TRUST_PROXY_HTTPS') === '1' && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $installIsHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

// Kurulum sihirbazı POST işlemlerini CSRF saldırılarına karşı koru.
if (empty($_SESSION['install_csrf'])) {
    $_SESSION['install_csrf'] = bin2hex(random_bytes(32));
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $installToken = (string)($_POST['_install_token'] ?? '');
    if ($installToken === '' || !hash_equals((string)$_SESSION['install_csrf'], $installToken)) {
        http_response_code(419);
        exit('Kurulum oturumu doğrulanamadı. Sayfayı yenileyip tekrar deneyin.');
    }
}

// Kurulum sayfası da temel güvenlik başlıklarını gönderir.
if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: same-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    if ($installIsHttps ?? false) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

// Kurulum kilidi kontrolü. Tamamlama ekranı yalnız kurulumu bitiren aynı oturumda bir kez gösterilebilir.
$lockFile = __DIR__ . '/install.lock';
$requestedInstallStep = $_GET['step'] ?? 1;
$allowInstallCompleteView = ((string)$requestedInstallStep === 'complete' && !empty($_SESSION['install_complete_view']));
if (file_exists($lockFile) && !$allowInstallCompleteView) {
    die('
    <!DOCTYPE html>
    <html lang="tr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Kurulum Tamamlandı</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                color: #fff;
            }
            .container {
                background: rgba(255,255,255,0.05);
                border: 1px solid rgba(255,255,255,0.1);
                border-radius: 20px;
                padding: 40px;
                text-align: center;
                max-width: 500px;
            }
            .icon { font-size: 60px; margin-bottom: 20px; }
            h1 { margin-bottom: 15px; color: #ff6b6b; }
            p { color: rgba(255,255,255,0.7); line-height: 1.6; }
            a { color: #6c5ce7; text-decoration: none; }
            code { background: rgba(0,0,0,0.3); padding: 2px 8px; border-radius: 4px; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="icon">🔒</div>
            <h1>Kurulum Kilitli</h1>
            <p>Kurulum daha önce tamamlanmış ve güvenlik için kilitlenmiştir.</p>
            <p style="margin-top: 15px;">Yeniden kurulum yapmak için <code>install.lock</code> dosyasını silin.</p>
            <p style="margin-top: 16px;">Geliştirici: <strong>Forium</strong> · <a href="https://forium.tr" target="_blank" rel="noopener noreferrer">forium.tr</a></p>
            <p style="margin-top: 20px;"><a href="/">Ana Sayfaya Git</a></p>
        </div>
    </body>
    </html>
    ');
}

// Mevcut adım
$step = $requestedInstallStep;
if ($step !== 'complete') {
    $step = (int)$step;
} elseif ($allowInstallCompleteView) {
    // Yenilemede tekrar tamamlama ekranı yerine normal kurulum kilidi gösterilsin.
    unset($_SESSION['install_complete_view']);
}
$error = '';
$success = '';

if ($step === 2 && isset($_GET['reset_db'])) {
    unset($_SESSION['pending_database']);
    $dbNeedsWipe = false;
}


// Config dosyası yolu
$configFile = __DIR__ . '/config.php';


// ==================== LİSANS / GELİŞTİRİCİ BİLGİLERİ ====================
const INSTALLER_LICENSE_VERSION = '2026.09.26-1';
const INSTALLER_LICENSE_MIN_READ_SECONDS = 45;
const INSTALLER_DEVELOPER_NAME = 'Forium';
const INSTALLER_DEVELOPER_URL = 'https://forium.tr';

$licenseClauses = [
    "Bu Son Kullanıcı Lisans, Kurulum, Kullanım ve Sorumluluk Sözleşmesi (“Sözleşme”), Moni SMM Panel yazılımının kurulması, çalıştırılması, kullanılması, değiştirilmesi ve yönetilmesine ilişkin şartları düzenler.",
    "Yazılımın geliştiricisi Forium olarak belirtilir; geliştirici internet adresi https://forium.tr’dir.",
    "Kuruluma devam eden kişi veya kuruluş, bu Sözleşme’yi kendi adına ve varsa temsil ettiği tüzel kişi adına kabul etmeye yetkili olduğunu beyan eder.",
    "Sözleşme kabul edilmeden yazılımın otomatik kurulumuna devam edilemez.",
    "Kullanıcı, sözleşmenin tamamını incelemek, anlamadığı hükümler için bağımsız hukuki veya teknik danışmanlık almak ve ancak bundan sonra kabul kararı vermekle sorumludur.",
    "Yazılım ‘olduğu gibi’ ve ‘mevcut olduğu şekliyle’ sağlanır; kanunen vazgeçilemeyen haklar dışında açık veya zımni ek garanti verilmez.",
    "Geliştirici, yazılımın kesintisiz, hatasız, her sunucuda uyumlu veya her kullanım senaryosuna uygun çalışacağını garanti etmez.",
    "Geliştirici, yazılımın belirli bir ticari amaca, belirli bir iş modeline veya belirli bir gelir beklentisine uygun olacağını garanti etmez.",
    "Yazılımın geliştirme, kod üretme, kod inceleme, hata ayıklama, dokümantasyon veya test süreçlerinin bir bölümünde yapay zekâ destekli araçlardan yararlanılmış olabilir.",
    "Yapay zekâ destekli araç kullanılmış olması, üretilen veya değiştirilen kodun hatasız, güvenli, mevzuata uyumlu ya da üçüncü taraf haklarından tamamen ari olduğu anlamına gelmez.",
    "Dağıtım paketinin bağımsız ve akredite bir üçüncü taraf tarafından kapsamlı penetrasyon testinden veya profesyonel sızma testinden geçirildiğine ilişkin bir beyan veya garanti verilmez.",
    "Yazılım üzerinde statik analiz, sözdizimi kontrolü, geliştirici testi veya otomatik güvenlik kontrolü yapılmış olması, bağımsız penetrasyon testi yerine geçmez.",
    "Geliştirici, yazılımın hiçbir güvenlik açığı, mantık hatası, yanlış yapılandırma riski veya sıfırıncı gün açığı içermediğini garanti etmez.",
    "Kullanıcı, yazılımı internete açmadan önce kendi risk profiline uygun güvenlik incelemesi, penetrasyon testi ve yapılandırma denetimi yaptırmaktan sorumludur.",
    "Kullanıcı, işletim sistemi, web sunucusu, PHP, veritabanı, TLS, DNS, CDN, güvenlik duvarı ve diğer altyapı bileşenlerini güvenli tutmakla sorumludur.",
    "Kullanıcı, yazılım ve bağımlılıklar için yayımlanan güvenlik güncellemelerini takip etmek ve makul sürede uygulamakla sorumludur.",
    "Kullanıcı, üretim sisteminde değişiklik yapmadan önce güncel ve geri döndürülebilir yedek almakla sorumludur.",
    "Kurulum, güncelleme veya kullanım sırasında veri kaybı meydana gelebileceği kabul edilir; yedek alınmamasından doğan zararlar geliştiriciye yüklenemez.",
    "Geliştirici, kanunen izin verilen azami ölçüde veri kaybı, gelir kaybı, kâr kaybı, iş kesintisi, itibar kaybı veya dolaylı zararlardan sorumlu tutulamaz.",
    "Geliştiricinin sorumluluğunu sınırlayan hükümler, uygulanabilir emredici mevzuatın izin verdiği ölçüde geçerlidir.",
    "Kanunen izin verilen azami ölçüde geliştiricinin bu yazılım ve bağlantılı hizmetler nedeniyle doğabilecek toplam ve birikimli mali sorumluluğu, kullanıcının ilgili yazılım lisansı için geliştiriciye son on iki ayda fiilen ödediği toplam bedeli aşmayacak şekilde sınırlandırılabilir; emredici hukuk hükümleri saklıdır.",
    "Kullanıcının hukuka aykırı kullanımı, yetkisiz üçüncü taraf entegrasyonu, kendi müşteri taahhütleri veya üçüncü taraf haklarını ihlal eden faaliyeti nedeniyle geliştiriciye yöneltilen taleplerde, kanunen izin verilen ölçüde kullanıcı kendi fiil ve işlemlerinden sorumludur.",
    "Kullanıcı, kendi eylem veya ihmallerinden kaynaklanan üçüncü taraf taleplerinde geliştiricinin makul savunma giderleri dahil doğrudan zararlarını, ancak uygulanabilir hukukun izin verdiği kapsamda karşılamakla yükümlü olabilir.",
    "Hiçbir hüküm geliştiricinin kanunen sınırlandırılması mümkün olmayan kasıt, ağır kusur veya emredici sorumluluklarını ortadan kaldıracak şekilde yorumlanmaz.",
    "Tüketici mevzuatı veya diğer emredici hukuk kurallarından doğan vazgeçilemez haklar bu Sözleşme ile ortadan kaldırılmaz.",
    "Kullanıcı, yazılımı yalnız hukuka uygun amaçlarla kullanacağını kabul eder.",
    "Kullanıcı, yazılımı dolandırıcılık, kimlik avı, yetkisiz erişim, zararlı yazılım dağıtımı veya başka hukuka aykırı faaliyetler için kullanamaz.",
    "Kullanıcı, hizmet sunduğu sosyal ağların, ödeme kuruluşlarının, barındırma şirketlerinin ve diğer üçüncü tarafların sözleşme ve politikalarına uymaktan kendisi sorumludur.",
    "Üçüncü taraf platformların hesabı askıya alması, kısıtlaması veya kapatması geliştiricinin kontrolünde değildir.",
    "Üçüncü taraf API’lerin kapanması, değişmesi, fiyat değiştirmesi, kota koyması veya erişimi engellemesi geliştirici açısından garanti kapsamında değildir.",
    "Sağlayıcı API’lerinden gelen hatalı, eksik, gecikmiş veya manipüle edilmiş verilerden doğabilecek sonuçların ayrıca doğrulanması kullanıcının sorumluluğundadır.",
    "Kullanıcı, sağlayıcı API anahtarlarını yalnız yetkili hesaplarda kullanmalı ve bu anahtarların güvenliğini sağlamalıdır.",
    "API anahtarlarının, ödeme sırlarının, SMTP parolalarının veya diğer gizli bilgilerin üçüncü kişilere açıklanmasından doğan risk kullanıcıya aittir.",
    "Kullanıcı, güçlü ve benzersiz yönetici parolaları kullanmayı kabul eder.",
    "Kurulum aracı yönetici parolası için asgari sekiz karakter şartı uygular; bu şart tek başına güçlü parola garantisi değildir.",
    "Kullanıcı, mümkün olan hesaplarda Passkey/WebAuthn veya iki aşamalı doğrulama gibi ek güvenlik katmanlarını etkinleştirmelidir.",
    "Aktif oturumlar ve cihazlar düzenli olarak gözden geçirilmeli, tanınmayan oturumlar sonlandırılmalıdır.",
    "Giriş ve güvenlik geçmişi kayıtları yardımcı denetim verisidir; mutlak saldırı tespiti garantisi vermez.",
    "IP adresi, cihaz bilgisi veya tarayıcı tanımları tek başına kesin kimlik doğrulaması olarak kabul edilmemelidir.",
    "Ters proxy, CDN veya yük dengeleyici kullanılan sistemlerde gerçek istemci IP’sinin doğru yapılandırılması kullanıcıya aittir.",
    "Sunucu saatinin ve zaman diliminin doğru olması oturum, cron, ödeme ve kayıt süreçleri için gereklidir.",
    "Kullanıcı, cronmoni.php merkezi görevini güvenli biçimde ve yalnız gerekli sıklıkta çalıştırmaktan sorumludur.",
    "Cron görevlerinin çok sık, çok seyrek veya hatalı yapılandırılması hizmet sonuçlarını etkileyebilir.",
    "Her cron görevinin işlem limiti ve çalışma aralığı yönetim panelinden ayrıca ayarlanabilir; kullanıcı bu değerleri kapasitesine göre belirlemelidir.",
    "Merkezi cron görevlerinin çalışmamasından kaynaklanan gecikme, senkronizasyon veya otomatik işlem sorunları sunucu yapılandırmasına bağlı olabilir.",
    "Sağlayıcı sağlık skoru geçmiş teknik verilerden üretilir ve gelecekteki performansı garanti etmez.",
    "Otomatik sağlayıcı failover özelliği varsayılan olarak kapalıdır ve etkinleştirme için en az iki aktif sağlayıcı gerektirir.",
    "Failover özelliği etkin olsa dahi alternatif sağlayıcının siparişi kabul edeceği veya aynı kaliteyi sunacağı garanti edilmez.",
    "Failover sırasında farklı sağlayıcı maliyetleri, hızları ve teslimat davranışları ortaya çıkabilir.",
    "Kullanıcı, failover kurallarını üretimde kullanmadan önce test etmelidir.",
    "Minimum kâr marjı politikaları hesaplamaya yardımcı olur; kur değişimleri, sağlayıcı hataları veya yuvarlama farkları nedeniyle gerçek kâr garanti edilmez.",
    "Kullanıcı veya bayiye özel fiyat listeleri, doğru hedef kullanıcı/grup seçimi ile yapılandırılmalıdır.",
    "Yanlış fiyatlandırma, yanlış kâr marjı veya hatalı kur ayarından doğan ticari kayıp kullanıcının yapılandırma sorumluluğundadır.",
    "Çoklu para birimi cüzdanı özelliğinde döviz kurları ve dönüşüm politikaları düzenli olarak kontrol edilmelidir.",
    "Döviz kuru kaynakları gecikebilir, kesilebilir veya hatalı veri sağlayabilir.",
    "Kur dönüşümünde yuvarlama farkları oluşabileceği kabul edilir.",
    "Sipariş Idempotency Key sistemi varsayılan olarak aktiftir ve yinelenen istek riskini azaltmayı amaçlar; tüm dış sistemlerde mutlak tekillik garantisi vermez.",
    "API istemcileri her mantıksal sipariş için benzersiz ve yeniden kullanılmayan idempotency anahtarı üretmelidir.",
    "Mükerrer Sipariş Tespiti özelliği varsayılan olarak aktiftir ve kullanıcıyı uyarır; siparişi otomatik olarak engellemez.",
    "Mükerrer sipariş uyarısına rağmen devam etme kararı ve sonucu kullanıcıya aittir.",
    "Servis veya sağlayıcı bakım pencereleri doğru saat dilimi ve tarih aralıklarıyla yapılandırılmalıdır.",
    "Bakım penceresinde kabul edilen veya kuyrukta bekleyen siparişlerin gecikmesi mümkündür.",
    "Modüler ödeme gateway adaptör sistemi, üçüncü taraf ödeme kuruluşlarının API ve sözleşme şartlarına tabidir.",
    "Her ödeme gateway’i üretime alınmadan önce test/sandbox ortamında denenmelidir.",
    "Ödeme kuruluşundan başarılı cevap alınması, kullanıcının bankacılık veya muhasebe süreçlerinin tamamlandığı anlamına gelmeyebilir.",
    "Ödeme callback/webhook uçları HTTPS altında çalıştırılmalı ve sağlayıcı imza/doğrulama mekanizmaları etkin tutulmalıdır.",
    "Ödeme Hız/Fraud Limitleri eklentisi varsayılan olarak kapalıdır; etkinleştirildiğinde yanlış pozitif veya yanlış negatif sonuç verebilir.",
    "Fraud skorları yardımcı karar verisidir ve hukuki suç isnadı veya kesin dolandırıcılık tespiti değildir.",
    "Şüpheli ödemelerde bağımsız inceleme ve gerekiyorsa ödeme kuruluşu doğrulaması yapılmalıdır.",
    "Gün Sonu Finansal Kapanış sistemi muhasebe kontrolünü destekler; resmi muhasebe kayıtlarının yerine geçmez.",
    "Finansal kapanıştan önce bakiye, ödeme, iade ve sipariş kayıtları kullanıcı tarafından kontrol edilmelidir.",
    "Finansal kayıtların vergi veya muhasebe mevzuatına uygunluğunu sağlamak kullanıcının sorumluluğundadır.",
    "e-Fatura/e-Arşiv entegrasyonu varsayılan olarak kapalıdır ve etkinleştirme öncesi yetkili entegratör bilgileri doğru girilmelidir.",
    "e-Fatura/e-Arşiv çıktılarının mevzuata uygunluğu kullanılan entegratör, vergi mükellefi statüsü ve güncel mevzuata bağlıdır.",
    "Geliştirici mali müşavir, vergi danışmanı veya özel entegratör sıfatıyla hizmet verdiğini beyan etmez.",
    "Vergi/KDV Profil Sistemi varsayılan olarak kapalıdır ve hukuki/vergi danışmanlığı niteliğinde değildir.",
    "Vergi oranları, istisnalar ve ülke kuralları değişebileceğinden kullanıcı güncel mevzuatı takip etmelidir.",
    "Yanlış vergi profili veya oran seçiminin mali sonuçları kullanıcıya aittir.",
    "Yazılım içindeki raporlar, grafikler ve istatistikler operasyonel amaçlıdır; bağımsız denetim veya resmi mali rapor değildir.",
    "Raporların doğruluğu, girilen verilerin ve üçüncü taraf kaynaklardan gelen bilgilerin doğruluğuna bağlıdır.",
    "Kullanıcı, ödeme ve sipariş kayıtları için gerektiğinde kendi harici mutabakat süreçlerini yürütmelidir.",
    "Kullanıcı, kişisel verileri yalnız geçerli hukuki sebep ve gerekli bilgilendirme/izin mekanizmalarıyla işlemelidir.",
    "KVKK, GDPR veya başka veri koruma mevzuatına uyum, kullanıcının faaliyet alanı ve veri işleme biçimine göre ayrıca değerlendirilmelidir.",
    "Geliştirici, kullanıcının veri sorumlusu/veri işleyen yükümlülüklerini otomatik olarak üstlenmez.",
    "Kişisel verilerin saklama süreleri kullanıcı tarafından hukuki gerekliliklere göre ayarlanmalıdır.",
    "Kullanıcı, destek talepleri, ödeme kayıtları ve erişim loglarında gereksiz hassas veri toplamamaya özen göstermelidir.",
    "Dosya yükleme özellikleri güvenlik kontrolleri içerse de kötü amaçlı dosya riskini tamamen ortadan kaldırmaz.",
    "Yükleme dizinlerinde sunucu tarafı script çalıştırma engeli ayrıca web sunucusu seviyesinde korunmalıdır.",
    "Yüklenen dosyalar gerektiğinde antivirüs veya kötü amaçlı yazılım taramasından geçirilmelidir.",
    "Kullanıcı tarafından eklenen özel kod, tema, eklenti veya entegrasyonlar güvenlik modelini değiştirebilir.",
    "Üçüncü taraf eklentiler geliştirici tarafından ayrıca denetlenmedikçe güvenilir kabul edilmemelidir.",
    "Eklenti sistemi üzerinden etkinleştirilen özellikler kendi yapılandırma koşullarına tabidir.",
    "Bir eklentinin devre dışı bırakılması geçmişte oluşturduğu verileri otomatik olarak silmek zorunda değildir.",
    "Eklenti kaldırma veya veri temizleme işlemlerinden önce yedek alınmalıdır.",
    "Yazılımın kaynak dosyalarının izinsiz satılması, kiralanması veya lisans hakkı varmış gibi yeniden pazarlanması yasaktır.",
    "Yazılımın tamamının veya esaslı bölümünün geliştiricinin izni olmaksızın yeniden dağıtılması yasaktır.",
    "Yazılımın değiştirilmiş bir kopyasının geliştiriciye ait resmi sürüm gibi sunulması yasaktır.",
    "Geliştirici adı, telif/lisans bildirimi veya teknik sahiplik bilgisini yanıltıcı biçimde değiştirmek yasaktır.",
    "Forium adı ve forium.tr adresi geliştirici bilgisini belirtmek amacıyla kullanılır; kullanıcıya marka veya alan adı üzerinde mülkiyet hakkı vermez.",
    "Yazılımı kendi hizmetinde kullanan kişi, son kullanıcılarına sunduğu hizmetin şartlarından kendisi sorumludur.",
    "Kullanıcı, kendi müşterilerine verdiği teslimat, iade, süre, kalite veya sonuç vaatlerinden geliştiriciyi sorumlu tutamaz.",
    "SMM hizmetlerinin niteliği gereği üçüncü taraf platformlarda düşüş, silinme, gecikme veya kalite değişimi yaşanabilir.",
    "Refill veya iptal özelliğinin bulunması, sağlayıcının her siparişte bu işlemi kabul edeceği anlamına gelmez.",
    "Sipariş statüleri sağlayıcıların bildirdiği verilere bağlı olarak gecikmeli değişebilir.",
    "Kullanıcı, yüksek hacimli siparişlerde sağlayıcı kapasitesini ve hesabının bakiyesini kontrol etmelidir.",
    "Sağlayıcı bakiyesinin yetersiz olması nedeniyle oluşabilecek gecikmeler geliştiricinin kontrolünde değildir.",
    "Sağlayıcı sağlık ve bakiye bildirimleri yardımcı uyarıdır; kullanıcının manuel kontrol sorumluluğunu kaldırmaz.",
    "SMTP ve e-posta teslimi alıcının sunucusu, DNS kayıtları, SPF/DKIM/DMARC ve spam filtrelerinden etkilenebilir.",
    "E-postanın uygulamada ‘gönderildi’ görünmesi alıcının gelen kutusuna ulaştığı anlamına gelmez.",
    "Web push, Telegram, WhatsApp veya benzeri harici bildirim kanalları ilgili sağlayıcıların erişilebilirliğine bağlıdır.",
    "Sosyal giriş sağlayıcıları callback adreslerini, API kapsamlarını veya doğrulama süreçlerini değiştirebilir.",
    "Google, Discord veya diğer OAuth entegrasyonlarının sürekliliği garanti edilmez.",
    "Passkey/WebAuthn desteği tarayıcı, işletim sistemi, alan adı ve HTTPS koşullarına bağlıdır.",
    "Passkey kaybı halinde alternatif kurtarma mekanizmalarını güvenli biçimde yapılandırmak kullanıcıya aittir.",
    "Tarayıcı veya cihazın güvenliği ihlal edilmişse Passkey dahil hiçbir istemci tarafı mekanizma mutlak koruma sağlayamaz.",
    "Oturum çerezleri Secure, HttpOnly ve SameSite ayarlarıyla korunmaya çalışılır; yanlış proxy/HTTPS yapılandırması korumayı zayıflatabilir.",
    "Kullanıcı, yönetim panelini herkese açık ve gereksiz ağlardan erişilebilir bırakmamaya özen göstermelidir.",
    "Gerekli durumlarda yönetim paneli IP/VPN veya ek erişim politikalarıyla sınırlandırılmalıdır.",
    "Sunucudaki diğer hesapların veya uygulamaların ele geçirilmesi bu yazılımın güvenliğini de etkileyebilir.",
    "Paylaşımlı hosting ortamlarında izolasyon seviyesi hosting sağlayıcısının güvenlik modeline bağlıdır.",
    "Dosya ve klasör izinleri sunucuya uygun en düşük yetkiyle tutulmalıdır.",
    "config.php ve benzeri gizli yapılandırma dosyaları web üzerinden doğrudan indirilebilir olmamalıdır.",
    "install.php kurulum sonrasında install.lock ile kilitlense de mümkünse sunucudan kaldırılmalıdır.",
    "database.install.php doğrudan web erişimine karşı korunur; kullanıcı bu korumayı kaldırmamalıdır.",
    "Kurulum sırasında seçilen veritabanının boş olması tavsiye edilir.",
    "Dolu veritabanı ile devam edilirse kurulum aracı, kullanıcının ayrıca verdiği açık ve ikinci onay sonrasında seçilen veritabanındaki tabloları ve görünümleri kaldırabilir.",
    "Dolu veritabanı temizleme işlemi geri döndürülemez niteliktedir; kullanıcı doğru veritabanını seçtiğini bizzat doğrulamakla sorumludur.",
    "Veritabanı adını tekrar yazarak verilen temizlik onayı, geri döndürülemez veri silme talebinin açık teyidi olarak kabul edilir.",
    "Geliştirici, kullanıcının yanlış veritabanını seçmesi veya yanlış temizlik onayı vermesi nedeniyle oluşan veri kaybından kanunen izin verilen ölçüde sorumlu değildir.",
    "Dolu veritabanı kullanılacaksa temizlik onayından önce ayrı bir yedek alınması kuvvetle tavsiye edilir.",
    "Kurulum aracı seçilen veritabanının dışında başka bir veritabanını bilerek temizlemek üzere tasarlanmamıştır.",
    "Veritabanı kullanıcısına yalnız ihtiyaç duyulan yetkilerin verilmesi tavsiye edilir.",
    "Kurulum veya güncelleme sırasında internet bağlantısının, disk alanının veya veritabanı bağlantısının kesilmesi yarım kalmış işlem oluşturabilir.",
    "Yarım kalan kurulumlarda yeniden denemeden önce veritabanı ve dosya sistemi kontrol edilmelidir.",
    "Yazılımın güncellenmiş sürümü eski özelleştirmelerle tam uyumlu olmayabilir.",
    "Çekirdek dosyalarda manuel değişiklik yapılmışsa güncelleme öncesi fark analizi yapılmalıdır.",
    "Kullanıcı, güncellemeleri önce test/staging ortamında denemeyi kabul eder.",
    "Güncelleme SQL yamaları mümkün olduğunca veri koruyucu tasarlansa da kullanıcı yedek alma yükümlülüğünden kurtulmaz.",
    "Kullanıcının üçüncü taraf kod veya veritabanı değişiklikleri resmi güncelleme davranışını etkileyebilir.",
    "Yazılımın yeni özellikleri zaman içinde değiştirilebilir, iyileştirilebilir, kaldırılabilir veya farklı bir lisans koşuluna bağlanabilir.",
    "Belirli bir özellik için ‘varsayılan açık’ veya ‘varsayılan kapalı’ ifadesi ilk kurulum varsayılanını belirtir; yönetici daha sonra ayarı değiştirebilir.",
    "Sipariş Idempotency Key ve Mükerrer Sipariş Tespiti özellikleri ilk kurulumda varsayılan olarak aktiftir.",
    "Otomatik Sağlayıcı Failover, e-Fatura/e-Arşiv, Vergi/KDV Profil Sistemi ve Ödeme Hız/Fraud Limitleri ilk kurulumda varsayılan olarak kapalıdır.",
    "Kullanıcı, varsayılan kapalı riskli/harici entegrasyonları yapılandırmadan etkinleştirmemelidir.",
    "Yazılımın sağlayıcı, ödeme, vergi veya fatura entegrasyonları için gereken resmi sözleşmeleri kullanıcı ilgili üçüncü taraflarla ayrıca yapmak zorundadır.",
    "Geliştirici üçüncü taraf hizmet sağlayıcıların temsilcisi, acentesi veya garantörü değildir.",
    "Üçüncü taraf hizmet koşullarının değiştirilmesi yazılımda ek geliştirme gerektirebilir.",
    "Geliştiricinin destek vermesi, belirli bir hatanın belirli sürede çözüleceğine dair sürekli hizmet seviyesi garantisi oluşturmaz; ayrıca yazılı SLA varsa o hükümler saklıdır.",
    "Kullanıcı, hata bildirirken gizli API anahtarı, kart verisi, parola veya gereksiz kişisel veri paylaşmamalıdır.",
    "Hata kayıtları ve ekran görüntüleri paylaşılmadan önce hassas bilgiler maskelenmelidir.",
    "Geliştirici, kullanıcı tarafından üçüncü taraflara açıklanan sırların korunmasından sorumlu değildir.",
    "Kullanıcı, yasal saklama yükümlülüğü bulunmayan gereksiz logları süre sonunda silmek veya anonimleştirmekten sorumludur.",
    "Yedek dosyalarının üretim web kökünde herkese açık biçimde tutulmaması gerekir.",
    "Yedeklerin şifreli ve erişim kontrollü tutulması tavsiye edilir.",
    "Kullanıcı, felaket kurtarma ve iş sürekliliği planlarını kendi operasyonuna göre oluşturmalıdır.",
    "Yazılım tek başına yüksek erişilebilirlik, felaket kurtarma veya sıfır veri kaybı garantisi sağlamaz.",
    "Kullanıcı, kritik finansal hareketlerde uygulama kayıtlarını ödeme kuruluşu ve banka kayıtlarıyla karşılaştırmalıdır.",
    "Manuel bakiye düzenlemeleri yetkili personel tarafından ve açıklama/audit kaydıyla yapılmalıdır.",
    "Kullanıcı hesaplarına yanlış bakiye yüklenmesi veya yanlış iade yapılması durumunda düzeltme sorumluluğu panel işletmecisine aittir.",
    "Kullanıcı, fiyat, hizmet açıklaması, teslim süresi ve iade koşullarını müşterilerine doğru biçimde duyurmalıdır.",
    "Platformların hizmet politikalarına aykırı hizmetlerin satışa sunulmasından panel işletmecisi sorumludur.",
    "Yazılımın bulunabilirliği barındırma sağlayıcısının ağ, enerji, donanım ve güvenlik koşullarından etkilenebilir.",
    "DDoS, ağ kesintisi, doğal afet, savaş, mevzuat değişikliği veya mücbir sebep niteliğindeki olaylarda kesintisiz hizmet garantisi verilmez.",
    "Geliştirici, kendi makul kontrolü dışındaki olaylardan kaynaklanan ifa gecikmesinden kanunen izin verilen ölçüde sorumlu tutulamaz.",
    "Bu Sözleşme’nin herhangi bir hükmünün geçersiz sayılması diğer hükümlerin geçerliliğini mümkün olduğu ölçüde etkilemez.",
    "Başlıklar yalnız kolaylık amacıyla kullanılır ve hükümlerin kapsamını tek başına belirlemez.",
    "Bir hakkın derhal kullanılmaması o haktan kalıcı olarak vazgeçildiği anlamına gelmez.",
    "Yazılı ve açık bir yetkilendirme olmaksızın kullanıcı geliştirici adına taahhütte bulunamaz.",
    "Kullanıcı, kendi faaliyetinden doğan vergi, lisans, izin, tüketici ve ticaret yükümlülüklerini yerine getirmekle sorumludur.",
    "Bu Sözleşme, profesyonel hukuk, vergi, muhasebe, siber güvenlik veya mevzuat danışmanlığının yerine geçmez.",
    "Kullanıcı, yüksek riskli veya düzenlemeye tabi kullanım öncesinde ilgili uzmanlardan bağımsız görüş almalıdır.",
    "Uygulanabilir emredici kurallar saklı kalmak üzere Sözleşme’nin yorumunda Türkiye Cumhuriyeti hukuku dikkate alınır.",
    "Yetkili mahkeme ve uyuşmazlık çözüm kuralları, tarafların sıfatı ve emredici yetki kurallarına göre belirlenir; tüketicinin kanuni yetkileri saklıdır.",
    "Sözleşmenin güncellenmiş sürümü yeni kurulumlarda farklı bir sürüm numarasıyla sunulabilir.",
    "Kurulum ekranında görünen sözleşme sürümü, kabul edilen şartların hangi metne ait olduğunun belirlenmesi amacıyla kaydedilebilir.",
    "Kullanıcı, elektronik ortamda verdiği kabulün kurulumun devamı için bağlayıcı bir irade açıklaması olduğunu kabul eder.",
    "Kullanıcı, kritik risk onay kutularını ayrı ayrı işaretleyerek güvenlik, yedekleme, üçüncü taraf ve sorumluluk sınırlaması hükümlerini özellikle gördüğünü beyan eder.",
    "Sözleşme alanının sonuna kadar kaydırılması ve asgari okuma süresinin geçmesi, metnin kullanıcıya sunulduğunu teknik olarak doğrulamaya yarar; gerçek hukuki okuma ve anlama sorumluluğu kullanıcıya aittir.",
    "Kullanıcı, ‘Kabul Ediyorum’ işlemini otomasyon, bot veya yetkisiz kişi aracılığıyla yaptırmamalıdır.",
    "Kuruluma devam edilmesi, bu Sözleşme’nin tamamının kabul edildiği anlamına gelir.",
    "Sözleşmeyi kabul etmeyen kullanıcı kurulumu sonlandırmalı ve yazılımı kullanmamalıdır."
];

$installerFeatures = [
    "Eklenti sistemi ve merkezi eklenti yönetimi",
    "Passkey / WebAuthn ile şifresiz giriş",
    "Aktif Oturumlar ve Cihaz Yönetimi",
    "Giriş ve Güvenlik Geçmişi",
    "Otomatik Sağlayıcı Failover eklentisi (varsayılan kapalı, minimum 2 sağlayıcı)",
    "Canlı Sağlayıcı Sağlık Skoru",
    "Minimum Kâr Marjı Politikaları",
    "Kullanıcı / Bayiye Özel Fiyat Listeleri",
    "Sipariş Idempotency Key eklentisi (varsayılan aktif)",
    "Mükerrer Sipariş Tespiti eklentisi (varsayılan aktif, yalnız uyarır)",
    "Servis / Provider Bakım Pencereleri",
    "e-Fatura / e-Arşiv eklentisi (varsayılan kapalı)",
    "Vergi / KDV Profil Sistemi eklentisi (varsayılan kapalı)",
    "Kullanıcı Cüzdanında Çoklu Para Birimi",
    "Ödeme Hız / Fraud Limitleri eklentisi (varsayılan kapalı)",
    "Gün Sonu Finansal Kapanış Sistemi",
    "Modüler Ödeme Gateway Adaptör Sistemi",
    "Tek merkezi cronmoni.php görevi",
    "Cron görevleri için yönetilebilir çalışma aralığı ve işlem limitleri",
    "Merkezi CSRF, oturum, yükleme, TLS, ödeme ve finansal atomiklik güvenlik iyileştirmeleri",
    "Otomatik Abonelik / Auto Subscription eklentisi (varsayılan aktif)",
    "Likes Spread / İçeriklere Dağıtılmış Sipariş",
    "Otomatik Refill Kontrol Motoru",
    "Otomatik Başlangıç Sayısı Tespiti eklentisi (varsayılan aktif)",
    "Gerçek Sayıya Göre Otomatik Tamamlama eklentisi (varsayılan aktif)",
    "Servis bazlı Overflow Sistemi",
    "Sağlayıcı Min/Max/Status/Açıklama otomatik senkronizasyonu",
    "Child Panel / Alt Panel eklentisi (varsayılan kapalı)",
    "Dinamik Kayıt Formu Oluşturucu",
    "Kullanıcı Erişim Politikaları",
    "Yeni üyeye tek seferlik başlangıç bakiyesi",
    "Personel Rolleri ve Ayrıntılı Yetki Sistemi",
    "Provider Alias / Sağlayıcı Gizleme",
    "Ödeme Yöntemi Ek Ücret Politikaları",
    "Sipariş / Ödeme / Kullanıcı CSV Dışa Aktarımları",
    "Merkezi Dosya Yöneticisi",
    "Görsel Sayfa Oluşturucu",
    "Otomatik sitemap.xml ve robots.txt yönetimi",
    "RTL dil desteği"
];

if (!isset($_SESSION['license_presented_at']) || $step !== 1) {
    if ($step === 1 && !isset($_SESSION['license_presented_at'])) {
        $_SESSION['license_presented_at'] = time();
    }
}

// ==================== SUNUCU UYUMLULUK KONTROLÜ ====================
function getEnvironmentChecks($configFile) {
    $requiredExtensions = ['pdo', 'pdo_mysql', 'curl', 'mbstring', 'openssl', 'fileinfo'];
    $recommendedExtensions = ['intl', 'xml', 'zip', 'gd', 'bcmath'];
    $missingRequired = [];
    $missingRecommended = [];

    foreach ($requiredExtensions as $extension) {
        if (!extension_loaded($extension)) {
            $missingRequired[] = $extension;
        }
    }
    foreach ($recommendedExtensions as $extension) {
        if (!extension_loaded($extension)) {
            $missingRecommended[] = $extension;
        }
    }

    $phpOk = version_compare(PHP_VERSION, '7.4.0', '>=');
    $configWritable = file_exists($configFile) && is_readable($configFile) && is_writable($configFile);
    $rootWritable = is_writable(__DIR__);

    return [
        'php_ok' => $phpOk,
        'config_writable' => $configWritable,
        'root_writable' => $rootWritable,
        'missing_required' => $missingRequired,
        'missing_recommended' => $missingRecommended,
        'ready' => $phpOk && $configWritable && $rootWritable && empty($missingRequired)
    ];
}

$environmentChecks = getEnvironmentChecks($configFile);

// ==================== CONFIG DOSYASINI GÜNCELLEME FONKSİYONU ====================

function updateConfigFile($configFile, $dbHost, $dbName, $dbUser, $dbPass, $siteUrl) {
    // Mevcut config.php dosyasını oku
    if (!file_exists($configFile)) {
        return ['success' => false, 'error' => 'config.php dosyası bulunamadı!'];
    }
    
    $configContent = file_get_contents($configFile);
    if ($configContent === false) {
        return ['success' => false, 'error' => 'config.php dosyası okunamadı!'];
    }
    
    // Veritabanı ayarlarını değiştir
    $patterns = [
        "/define\s*\(\s*['\"]DB_HOST['\"]\s*,\s*['\"][^'\"]*['\"]\s*\)/",
        "/define\s*\(\s*['\"]DB_NAME['\"]\s*,\s*['\"][^'\"]*['\"]\s*\)/",
        "/define\s*\(\s*['\"]DB_USER['\"]\s*,\s*['\"][^'\"]*['\"]\s*\)/",
        "/define\s*\(\s*['\"]DB_PASS['\"]\s*,\s*['\"][^'\"]*['\"]\s*\)/",
        "/define\s*\(\s*['\"]SITE_URL['\"]\s*,\s*['\"][^'\"]*['\"]\s*\)/",
        "/define\s*\(\s*['\"]CRON_SECRET_KEY['\"]\s*,\s*['\"][^'\"]*['\"]\s*\)/"
    ];
    
    // PHP string literalini var_export ile üret; özellikle çift tırnak veya ters eğik çizgi
    // içeren veritabanı parolalarının config.php'ye farklı yazılmasını engeller.
    $phpLiteral = static function ($value) {
        return var_export((string)$value, true);
    };
    $replacements = [
        "define('DB_HOST', " . $phpLiteral($dbHost) . ")",
        "define('DB_NAME', " . $phpLiteral($dbName) . ")",
        "define('DB_USER', " . $phpLiteral($dbUser) . ")",
        "define('DB_PASS', " . $phpLiteral($dbPass) . ")",
        "define('SITE_URL', " . $phpLiteral($siteUrl) . ")",
        "define('CRON_SECRET_KEY', " . $phpLiteral(bin2hex(random_bytes(32))) . ")"
    ];
    
    // Her bir pattern'i değiştir
    foreach ($patterns as $index => $pattern) {
        $configContent = preg_replace($pattern, $replacements[$index], $configContent);
    }
    
    // Dosyayı kaydet
    if (file_put_contents($configFile, $configContent) === false) {
        return ['success' => false, 'error' => 'config.php dosyası yazılamadı! Dosya izinlerini kontrol edin.'];
    }
    
    return ['success' => true];
}

// Yarım kalan temiz kurulumda oluşturulmuş tabloları geri temizle.
function cleanupPartialInstall($pdo) {
    if (!$pdo instanceof PDO) {
        return;
    }
    try {
        $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
        $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
        foreach ($tables as $table) {
            $safeTable = str_replace('`', '``', $table);
            $pdo->exec("DROP TABLE IF EXISTS `{$safeTable}`");
        }
        $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
    } catch (Exception $ignored) {
        // Ana kurulum hatasını gölgelememek için temizlik hatası ayrıca gösterilmez.
    }
}


// Seçilen veritabanını, kullanıcı açıkça ikinci onay verdikten sonra temizle.
function purgeSelectedDatabase($pdo) {
    if (!$pdo instanceof PDO) {
        throw new Exception('Veritabanı bağlantısı bulunamadı.');
    }

    $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
    try {
        $objects = $pdo->query("SHOW FULL TABLES")->fetchAll(PDO::FETCH_NUM);
        // Önce VIEW nesnelerini kaldır; tablolar sonrasında güvenle silinir.
        foreach ($objects as $object) {
            $name = (string)($object[0] ?? '');
            $type = strtoupper((string)($object[1] ?? 'BASE TABLE'));
            if ($name === '' || $type !== 'VIEW') {
                continue;
            }
            $safe = str_replace('`', '``', $name);
            $pdo->exec("DROP VIEW IF EXISTS `{$safe}`");
        }
        foreach ($objects as $object) {
            $name = (string)($object[0] ?? '');
            $type = strtoupper((string)($object[1] ?? 'BASE TABLE'));
            if ($name === '' || $type === 'VIEW') {
                continue;
            }
            $safe = str_replace('`', '``', $name);
            $pdo->exec("DROP TABLE IF EXISTS `{$safe}`");
        }
    } finally {
        $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
    }
}

// Temiz kurulum şemasını yükle ve config.php'yi seçilen veritabanına bağla.
function performFreshDatabaseInstall($pdo, $install, $configFile) {
    $sqlFile = __DIR__ . '/database.install.php';
    if (!file_exists($sqlFile)) {
        throw new Exception('Kurulum veritabanı paketi bulunamadı!');
    }

    $sqlPayload = file_get_contents($sqlFile);
    if ($sqlPayload === false || $sqlPayload === '') {
        throw new Exception('Kurulum veritabanı paketi okunamadı veya boş!');
    }

    $payloadPrefix = "<?php http_response_code(404); exit; ?>\n";
    if (strncmp($sqlPayload, $payloadPrefix, strlen($payloadPrefix)) !== 0) {
        throw new Exception('Kurulum veritabanı paketi geçersiz veya değiştirilmiş.');
    }
    $sql = substr($sqlPayload, strlen($payloadPrefix));
    if (trim($sql) === '') {
        throw new Exception('Kurulum SQL içeriği boş!');
    }

    $pdo->exec($sql);

    $settings = [
        'site_url' => $install['site_url'],
        'installer_license_version' => INSTALLER_LICENSE_VERSION,
        'installer_license_accepted_at' => (string)($install['license_accepted_at'] ?? date('c')),
        'developer_name' => INSTALLER_DEVELOPER_NAME,
        'developer_url' => INSTALLER_DEVELOPER_URL,
    ];
    $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
    foreach ($settings as $key => $value) {
        $stmt->execute([$key, $value]);
    }

    $stmt = $pdo->prepare("UPDATE social_login_settings SET redirect_uri = ? WHERE provider = 'google'");
    $stmt->execute([$install['site_url'] . '/auth/google/callback.php']);
    $stmt = $pdo->prepare("UPDATE social_login_settings SET redirect_uri = ? WHERE provider = 'discord'");
    $stmt->execute([$install['site_url'] . '/auth/discord/callback.php']);

    $updateResult = updateConfigFile(
        $configFile,
        $install['db_host'],
        $install['db_name'],
        $install['db_user'],
        $install['db_pass'],
        $install['site_url']
    );
    if (!$updateResult['success']) {
        throw new Exception($updateResult['error']);
    }
}

// ==================== ADIM İŞLEMLERİ ====================

// ADIM 1: Zorunlu Lisans Sözleşmesi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['step1'])) {
    $licenseAccepted = isset($_POST['license_accept']) && $_POST['license_accept'] === '1';
    $criticalRiskAccepted = isset($_POST['critical_risk_accept']) && $_POST['critical_risk_accept'] === '1';
    $backupRiskAccepted = isset($_POST['backup_risk_accept']) && $_POST['backup_risk_accept'] === '1';
    $scrollCompleted = isset($_POST['license_scrolled']) && $_POST['license_scrolled'] === '1';
    $presentedAt = (int)($_SESSION['license_presented_at'] ?? time());
    $elapsed = time() - $presentedAt;

    if (!$scrollCompleted) {
        $error = 'Lisans sözleşmesinin tamamını sonuna kadar görüntülemeden kuruluma devam edemezsiniz.';
    } elseif ($elapsed < INSTALLER_LICENSE_MIN_READ_SECONDS) {
        $remaining = INSTALLER_LICENSE_MIN_READ_SECONDS - $elapsed;
        $error = 'Lisans sözleşmesini incelemek için ayrılan minimum süre henüz dolmadı. Yaklaşık ' . $remaining . ' saniye sonra tekrar deneyin.';
    } elseif (!$criticalRiskAccepted || !$backupRiskAccepted || !$licenseAccepted) {
        $error = 'Kuruluma devam etmek için lisans, güvenlik/sorumluluk ve yedekleme risk onaylarının tamamını açıkça kabul etmelisiniz.';
    } else {
        $_SESSION['install'] = [
            'license_accepted' => true,
            'license_version' => INSTALLER_LICENSE_VERSION,
            'license_accepted_at' => date('c'),
        ];
        header('Location: install.php?step=2');
        exit;
    }
    $step = 1;
}

// ADIM 2: Veritabanı Bağlantısı + Gerekirse Açık Temizlik Onayı + Temiz Kurulum
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['step2']) || isset($_POST['confirm_db_wipe']))) {
    if (empty($_SESSION['install']['license_accepted'])) {
        header('Location: install.php?step=1');
        exit;
    }

    $isWipeConfirmation = isset($_POST['confirm_db_wipe']);
    if ($isWipeConfirmation) {
        $pending = $_SESSION['pending_database'] ?? null;
        if (!is_array($pending)) {
            $error = 'Veritabanı temizleme oturumu bulunamadı. Bilgileri yeniden girin.';
            $step = 2;
        } else {
            $dbHost = $pending['db_host'];
            $dbName = $pending['db_name'];
            $dbUser = $pending['db_user'];
            $dbPass = $pending['db_pass'];
            $siteUrl = $pending['site_url'];
            $typedName = trim((string)($_POST['wipe_db_name'] ?? ''));
            $wipeAccepted = isset($_POST['wipe_warning_accept']) && $_POST['wipe_warning_accept'] === '1';

            if (!$wipeAccepted || !hash_equals((string)$dbName, $typedName)) {
                $error = 'Veritabanı temizleme onayı geçersiz. Veritabanı adını birebir yazmalı ve geri döndürülemez silme onayını işaretlemelisiniz.';
                $step = 2;
            } else {
                try {
                    $dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
                    $pdo = new PDO($dsn, $dbUser, $dbPass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 5, PDO::MYSQL_ATTR_MULTI_STATEMENTS => true]);
                    purgeSelectedDatabase($pdo);

                    $_SESSION['install'] = array_merge($_SESSION['install'], $pending);
                    performFreshDatabaseInstall($pdo, $_SESSION['install'], $configFile);
                    $_SESSION['install']['db_imported'] = true;
                    unset($_SESSION['pending_database']);
                    header('Location: install.php?step=3');
                    exit;
                } catch (Exception $e) {
                    $error = 'Veritabanı temizleme/kurulum hatası: ' . $e->getMessage();
                    $step = 2;
                }
            }
        }
    } else {
        $dbHost = trim($_POST['db_host'] ?? '');
        $dbName = trim($_POST['db_name'] ?? '');
        $dbUser = trim($_POST['db_user'] ?? '');
        $dbPass = $_POST['db_pass'] ?? '';
        $siteUrl = rtrim(trim($_POST['site_url'] ?? ''), '/');

        if (!$environmentChecks['ready']) {
            $missing = [];
            if (!$environmentChecks['php_ok']) $missing[] = 'PHP 7.4 veya üzeri';
            if (!empty($environmentChecks['missing_required'])) $missing[] = 'PHP eklentileri: ' . implode(', ', $environmentChecks['missing_required']);
            if (!$environmentChecks['config_writable']) $missing[] = 'config.php yazma izni';
            if (!$environmentChecks['root_writable']) $missing[] = 'ana dizin yazma izni (install.lock için)';
            $error = 'Sunucu kurulum için hazır değil: ' . implode(' • ', $missing);
            $step = 2;
        } elseif (empty($dbHost) || empty($dbName) || empty($dbUser) || empty($siteUrl)) {
            $error = 'Tüm zorunlu alanları doldurunuz.';
            $step = 2;
        } elseif (!preg_match('/^[A-Za-z0-9_-]{1,64}$/', $dbName)) {
            $error = 'Veritabanı adı yalnızca harf, rakam, alt çizgi (_) ve tire (-) içerebilir.';
            $step = 2;
        } elseif (!filter_var($siteUrl, FILTER_VALIDATE_URL) || !preg_match('#^https?://#i', $siteUrl)) {
            $error = 'Geçerli bir http/https site URL adresi giriniz.';
            $step = 2;
        } else {
            try {
                $dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
                $pdo = new PDO($dsn, $dbUser, $dbPass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 5, PDO::MYSQL_ATTR_MULTI_STATEMENTS => true]);
                $objects = $pdo->query('SHOW FULL TABLES')->fetchAll(PDO::FETCH_NUM);

                $pending = [
                    'db_host' => $dbHost,
                    'db_name' => $dbName,
                    'db_user' => $dbUser,
                    'db_pass' => $dbPass,
                    'site_url' => $siteUrl,
                ];

                if (!empty($objects)) {
                    $pending['object_count'] = count($objects);
                    $_SESSION['pending_database'] = $pending;
                    $dbNeedsWipe = true;
                    $dbObjectCount = count($objects);
                    $error = 'Seçilen veritabanı boş değil. Boş bir veritabanı kullanmanız önerilir. Mevcut veritabanını temizlemek istiyorsanız aşağıdaki ikinci onayı tamamlayın.';
                    $step = 2;
                } else {
                    $_SESSION['install'] = array_merge($_SESSION['install'], $pending);
                    performFreshDatabaseInstall($pdo, $_SESSION['install'], $configFile);
                    $_SESSION['install']['db_imported'] = true;
                    unset($_SESSION['pending_database']);
                    header('Location: install.php?step=3');
                    exit;
                }
            } catch (PDOException $e) {
                $error = 'Veritabanı bağlantısı kurulamadı. Bilgileri ve veritabanının oluşturulmuş olduğunu kontrol edin.';
                $step = 2;
            } catch (Exception $e) {
                $error = 'Kurulum hatası: ' . $e->getMessage();
                $step = 2;
            }
        }
    }
}

// Kurulum adımlarına doğrudan atlamayı engelle.
if ($step !== 'complete' && (int)$step > 1 && empty($_SESSION['install']['license_accepted'])) {
    header('Location: install.php?step=1');
    exit;
}
if ($step !== 'complete' && (int)$step >= 3 && empty($_SESSION['install']['db_imported'])) {
    header('Location: install.php?step=2');
    exit;
}
if ($step !== 'complete' && (int)$step >= 4 && empty($_SESSION['install']['admin_created'])) {
    header('Location: install.php?step=3');
    exit;
}
if ($step !== 'complete' && (int)$step >= 5 && empty($_SESSION['install']['settings_saved'])) {
    header('Location: install.php?step=4');
    exit;
}

// ADIM 3: Admin Hesabı
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['step3'])) {
    if (!isset($_SESSION['install'])) {
        header('Location: install.php?step=1');
        exit;
    }
    
    $adminUser = trim($_POST['admin_username'] ?? '');
    $adminEmail = trim($_POST['admin_email'] ?? '');
    $adminPass = $_POST['admin_password'] ?? '';
    $adminPassConfirm = $_POST['admin_password_confirm'] ?? '';
    $adminFirstName = trim($_POST['admin_first_name'] ?? '');
    $adminLastName = trim($_POST['admin_last_name'] ?? '');
    
    if (empty($adminUser) || empty($adminEmail) || empty($adminPass)) {
        $error = 'Kullanıcı adı, e-posta ve şifre zorunludur.';
    } elseif ($adminPass !== $adminPassConfirm) {
        $error = 'Şifreler eşleşmiyor.';
    } elseif (strlen($adminPass) < 8) {
        $error = 'Şifre en az 8 karakter olmalıdır.';
    } elseif (!filter_var($adminEmail, FILTER_VALIDATE_EMAIL)) {
        $error = 'Geçerli bir e-posta adresi giriniz.';
    } else {
        try {
            $install = $_SESSION['install'];
            $dsn = "mysql:host={$install['db_host']};dbname={$install['db_name']};charset=utf8mb4";
            $pdo = new PDO($dsn, $install['db_user'], $install['db_pass'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
            ]);
            
            // Mevcut admin var mı kontrol et
            $stmt = $pdo->prepare("SELECT id FROM users WHERE role = 'admin' LIMIT 1");
            $stmt->execute();
            $existingAdmin = $stmt->fetch();
            
            $hashedPassword = password_hash($adminPass, PASSWORD_DEFAULT);
            $apiKey = bin2hex(random_bytes(32));
            $referralCode = strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8));
            
            if ($existingAdmin) {
                throw new Exception('Temiz kurulumda mevcut admin hesabı bulunmamalıdır. Kurulum güvenlik için durduruldu.');
            }

            // Yeni ve tek admin hesabını kurulum sırasında oluştur.
            $stmt = $pdo->prepare("INSERT INTO users 
                (username, email, password, first_name, last_name, role, api_key, status, email_verified, referral_code, created_at) 
                VALUES (?, ?, ?, ?, ?, 'admin', ?, 'active', 1, ?, NOW())");
            $stmt->execute([$adminUser, $adminEmail, $hashedPassword, $adminFirstName, $adminLastName, $apiKey, $referralCode]);
            
            $_SESSION['install']['admin_created'] = true;
            
            header('Location: install.php?step=4');
            exit;
            
        } catch (Exception $e) {
            $error = 'Admin hesabı oluşturma hatası: ' . $e->getMessage();
        }
    }
    $step = 3;
}

// ADIM 4: Site Ayarları
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['step4'])) {
    if (!isset($_SESSION['install'])) {
        header('Location: install.php?step=1');
        exit;
    }

    $siteName = trim($_POST['site_name'] ?? '');
    if ($siteName === '') {
        $error = 'Site adı zorunludur.';
        $step = 4;
    } else try {
        $install = $_SESSION['install'];
        $dsn = "mysql:host={$install['db_host']};dbname={$install['db_name']};charset=utf8mb4";
        $pdo = new PDO($dsn, $install['db_user'], $install['db_pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
        
        $settings = [
            'site_name' => $siteName,
            'site_description' => trim($_POST['site_description'] ?? ''),
            'contact_email' => trim($_POST['contact_email'] ?? ''),
            'contact_phone' => trim($_POST['contact_phone'] ?? ''),
            'currency' => trim($_POST['currency'] ?? 'TRY'),
            'currency_symbol' => trim($_POST['currency_symbol'] ?? '₺'),
            'footer_email' => trim($_POST['footer_email'] ?? ''),
            'footer_phone' => trim($_POST['footer_phone'] ?? ''),
            'footer_address' => trim($_POST['footer_address'] ?? ''),
            'footer_working_hours' => trim($_POST['footer_working_hours'] ?? '7/24'),
            'site_url' => $install['site_url']
        ];
        
        foreach ($settings as $key => $value) {
            $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) 
                                   ON DUPLICATE KEY UPDATE setting_value = ?");
            $stmt->execute([$key, $value, $value]);
        }
        
        $_SESSION['install']['settings_saved'] = true;
        
        header('Location: install.php?step=5');
        exit;
        
    } catch (PDOException $e) {
        $error = 'Ayarlar kaydedilirken hata: ' . $e->getMessage();
    }
    $step = 4;
}

// ADIM 5: Kurulumu Bitir
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['finish'])) {
    if (empty($_SESSION['install']['db_imported']) || empty($_SESSION['install']['admin_created']) || empty($_SESSION['install']['settings_saved'])) {
        header('Location: install.php?step=1');
        exit;
    }

    // Kilit dosyasında kişisel/sunucu bilgisi tutulmaz.
    $lockContent = "installed\n";
    
    if (file_put_contents($lockFile, $lockContent) === false) {
        $error = 'install.lock oluşturulamadı. Ana dizinin yazma izinlerini kontrol edin.';
        $step = 5;
    } else {
    
    // Kurulum verilerini temizle; tamamlandı ekranını aynı oturum için tek kullanımlık aç.
    unset($_SESSION['install']);
    $_SESSION['install_complete_view'] = 1;
    if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
    
    header('Location: install.php?step=complete');
    exit;
    }
}

// ==================== YARDIMCI FONKSİYONLAR ====================

// Sunucu yolu tespiti
function getServerPath() {
    $scriptPath = dirname($_SERVER['SCRIPT_FILENAME']);
    
    // cPanel tarzı yol tespiti (/home/username/public_html)
    if (preg_match('#^(/home/[^/]+)/public_html#', $scriptPath, $matches)) {
        return $matches[1] . '/public_html';
    }
    
    // cPanel alternatif (/home/username/domain.com)
    if (preg_match('#^(/home/[^/]+/[^/]+)#', $scriptPath, $matches)) {
        return $matches[1];
    }
    
    // Plesk tarzı (/var/www/vhosts/domain.com/httpdocs)
    if (preg_match('#^(/var/www/vhosts/[^/]+/httpdocs)#', $scriptPath, $matches)) {
        return $matches[1];
    }
    
    // DirectAdmin tarzı
    if (preg_match('#^(/home/[^/]+/domains/[^/]+/public_html)#', $scriptPath, $matches)) {
        return $matches[1];
    }
    
    return $scriptPath;
}

// Mevcut admin bilgilerini getir
function getExistingAdmin($install) {
    try {
        $dsn = "mysql:host={$install['db_host']};dbname={$install['db_name']};charset=utf8mb4";
        $pdo = new PDO($dsn, $install['db_user'], $install['db_pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
        
        $stmt = $pdo->prepare("SELECT * FROM users WHERE role = 'admin' LIMIT 1");
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return null;
    }
}

// Mevcut site ayarlarını getir
function getExistingSettings($install) {
    try {
        $dsn = "mysql:host={$install['db_host']};dbname={$install['db_name']};charset=utf8mb4";
        $pdo = new PDO($dsn, $install['db_user'], $install['db_pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
        
        $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
        $settings = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
        return $settings;
    } catch (Exception $e) {
        return [];
    }
}

// Mevcut config.php'den değerleri oku
function getCurrentConfigValues($configFile) {
    $values = [
        'db_host' => 'localhost',
        'db_name' => '',
        'db_user' => '',
        'db_pass' => '',
        'site_url' => ''
    ];
    
    if (!file_exists($configFile)) {
        return $values;
    }
    
    $content = file_get_contents($configFile);
    
    // DB_HOST
    if (preg_match("/define\s*\(\s*['\"]DB_HOST['\"]\s*,\s*['\"]([^'\"]*)['\"]/",$content, $m)) {
        $values['db_host'] = $m[1];
    }
    // DB_NAME
    if (preg_match("/define\s*\(\s*['\"]DB_NAME['\"]\s*,\s*['\"]([^'\"]*)['\"]/",$content, $m)) {
        $values['db_name'] = $m[1];
    }
    // DB_USER
    if (preg_match("/define\s*\(\s*['\"]DB_USER['\"]\s*,\s*['\"]([^'\"]*)['\"]/",$content, $m)) {
        $values['db_user'] = $m[1];
    }
    // DB_PASS
    if (preg_match("/define\s*\(\s*['\"]DB_PASS['\"]\s*,\s*['\"]([^'\"]*)['\"]/",$content, $m)) {
        $values['db_pass'] = $m[1];
    }
    // SITE_URL
    if (preg_match("/define\s*\(\s*['\"]SITE_URL['\"]\s*,\s*['\"]([^'\"]*)['\"]/",$content, $m)) {
        $values['site_url'] = $m[1];
    }
    
    return $values;
}

// Adım 3-4-5 için verileri hazırla
$existingAdmin = null;
$existingSettings = [];
if (isset($_SESSION['install']) && ($step >= 3)) {
    $existingAdmin = getExistingAdmin($_SESSION['install']);
    $existingSettings = getExistingSettings($_SESSION['install']);
}

// Mevcut config değerlerini al (Adım 1 için)
$currentConfig = getCurrentConfigValues($configFile);

// Sunucu yolunu tespit et
function detectPhpCliPath() {
    $candidates = [];
    if (defined('PHP_BINDIR') && PHP_BINDIR) $candidates[] = rtrim(PHP_BINDIR, '/\\') . DIRECTORY_SEPARATOR . 'php';
    $candidates[] = '/usr/bin/php';
    $candidates[] = '/usr/local/bin/php';
    foreach (array_unique($candidates) as $candidate) {
        if (is_file($candidate) && is_executable($candidate)) return $candidate;
    }
    $disabled = array_filter(array_map('trim', explode(',', (string)ini_get('disable_functions'))));
    if (function_exists('shell_exec') && !in_array('shell_exec', $disabled, true)) {
        $which = trim((string)@shell_exec('command -v php 2>/dev/null'));
        if ($which !== '' && is_file($which) && is_executable($which)) return $which;
    }
    return 'php';
}

$serverPath = getServerPath();
$phpCliPath = detectPhpCliPath();

// Site URL'i otomatik belirle
$isHttps = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off')
    || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https');
$scheme = $isHttps ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/install.php'));
$scriptDir = ($scriptDir === '/' || $scriptDir === '.') ? '' : rtrim($scriptDir, '/');
$autoSiteUrl = $scheme . '://' . $host . $scriptDir;
$dbNeedsWipe = $dbNeedsWipe ?? false;
$dbObjectCount = $dbObjectCount ?? (int)($_SESSION['pending_database']['object_count'] ?? 0);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moni SMM Panel - Kurulum Sihirbazı</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            min-height: 100vh;
            color: #fff;
            padding: 20px;
        }
        .installer { max-width: 700px; margin: 0 auto; }
        .installer-header { text-align: center; padding: 30px 0; }
        .installer-logo {
            width: 80px; height: 80px;
            background: linear-gradient(135deg, #6c5ce7, #a29bfe);
            border-radius: 20px;
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 20px; font-size: 2.5rem;
        }
        .installer-header h1 { font-size: 1.8rem; margin-bottom: 8px; }
        .installer-header p { color: rgba(255,255,255,0.6); }
        
        .steps { display: flex; justify-content: center; gap: 8px; margin-bottom: 30px; flex-wrap: wrap; }
        .step-item {
            display: flex; align-items: center; gap: 8px;
            padding: 10px 14px;
            background: rgba(255,255,255,0.05);
            border-radius: 30px; font-size: 0.8rem;
            border: 1px solid rgba(255,255,255,0.1);
            transition: all 0.3s ease;
        }
        .step-item.active { background: linear-gradient(135deg, #6c5ce7, #a29bfe); border-color: transparent; }
        .step-item.completed { background: rgba(40, 167, 69, 0.2); border-color: #28a745; }
        .step-item .step-num {
            width: 22px; height: 22px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-weight: 600; font-size: 0.7rem;
        }
        .step-item.completed .step-num { background: #28a745; }
        
        .installer-card {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 20px; padding: 30px;
            backdrop-filter: blur(10px);
        }
        .card-header {
            display: flex; align-items: center; gap: 15px;
            margin-bottom: 25px; padding-bottom: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .card-header-icon {
            width: 50px; height: 50px;
            background: linear-gradient(135deg, #6c5ce7, #a29bfe);
            border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.3rem;
        }
        .card-header h2 { font-size: 1.2rem; margin-bottom: 4px; }
        .card-header p { color: rgba(255,255,255,0.6); font-size: 0.9rem; }
        
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 500; font-size: 0.9rem; }
        .form-group label span { color: #ff6b6b; }
        .form-control {
            width: 100%; padding: 14px 16px;
            background: rgba(255,255,255,0.08);
            border: 1px solid rgba(255,255,255,0.15);
            border-radius: 10px; color: #fff; font-size: 0.95rem;
            transition: all 0.3s ease;
        }
        .form-control:focus { outline: none; border-color: #6c5ce7; background: rgba(108, 92, 231, 0.1); }
        .form-control::placeholder { color: rgba(255,255,255,0.4); }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        .form-hint { margin-top: 6px; font-size: 0.8rem; color: rgba(255,255,255,0.5); }
        
        select.form-control { cursor: pointer; }
        select.form-control option { background: #1a1a2e; color: #fff; }
        
        .btn {
            display: inline-flex; align-items: center; justify-content: center; gap: 10px;
            padding: 14px 28px; border-radius: 10px;
            font-size: 0.95rem; font-weight: 600; cursor: pointer;
            transition: all 0.3s ease; border: none; text-decoration: none; color: #fff;
        }
        .btn-primary { background: linear-gradient(135deg, #6c5ce7, #a29bfe); }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 10px 30px rgba(108, 92, 231, 0.4); }
        .btn-success { background: linear-gradient(135deg, #00b894, #55efc4); }
        .btn-success:hover { transform: translateY(-2px); box-shadow: 0 10px 30px rgba(0, 184, 148, 0.4); }
        .btn-secondary { background: rgba(255,255,255,0.1); }
        .btn-secondary:hover { background: rgba(255,255,255,0.15); }
        .form-actions { display: flex; gap: 12px; margin-top: 25px; flex-wrap: wrap; }
        
        .alert { padding: 15px 20px; border-radius: 10px; margin-bottom: 20px; display: flex; align-items: flex-start; gap: 12px; }
        .alert-danger { background: rgba(220, 53, 69, 0.15); border: 1px solid rgba(220, 53, 69, 0.3); color: #ff6b6b; }
        .alert-success { background: rgba(40, 167, 69, 0.15); border: 1px solid rgba(40, 167, 69, 0.3); color: #55efc4; }
        .alert-info { background: rgba(0, 123, 255, 0.15); border: 1px solid rgba(0, 123, 255, 0.3); color: #74b9ff; }
        .alert-warning { background: rgba(255, 193, 7, 0.15); border: 1px solid rgba(255, 193, 7, 0.3); color: #ffeaa7; }
        .alert i { margin-top: 2px; flex-shrink: 0; }
        
        .cron-box {
            background: rgba(0,0,0,0.3);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 10px; padding: 15px; margin-bottom: 15px;
        }
        .cron-box-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; flex-wrap: wrap; gap: 10px; }
        .cron-box-title { font-weight: 600; font-size: 0.9rem; }
        .cron-box-interval { font-size: 0.75rem; padding: 4px 10px; background: rgba(108,92,231,0.3); border-radius: 20px; }
        .cron-box-desc { font-size: 0.8rem; color: rgba(255,255,255,0.6); margin-bottom: 10px; }
        .cron-command {
            background: rgba(0,0,0,0.4); padding: 12px; border-radius: 8px;
            font-family: monospace; font-size: 0.78rem; color: #55efc4;
            word-break: break-all; position: relative; padding-right: 80px;
            min-height: 44px; display: flex; align-items: center;
        }
        .copy-btn {
            position: absolute; top: 50%; right: 8px; transform: translateY(-50%);
            background: rgba(255,255,255,0.1); border: none;
            padding: 6px 12px; border-radius: 5px;
            color: #fff; cursor: pointer; font-size: 0.75rem;
            transition: all 0.2s;
        }
        .copy-btn:hover { background: rgba(255,255,255,0.2); }
        .copy-btn.copied { background: #28a745; }
        
        .success-container { text-align: center; padding: 40px 20px; }
        .success-icon { font-size: 80px; color: #55efc4; margin-bottom: 20px; }
        .success-container h2 { font-size: 1.8rem; margin-bottom: 15px; color: #55efc4; }
        .success-container p { color: rgba(255,255,255,0.7); margin-bottom: 10px; line-height: 1.6; }
        .countdown { font-size: 2.5rem; color: #6c5ce7; font-weight: bold; margin: 25px 0; }
        
        .info-list { list-style: none; margin: 15px 0; }
        .info-list li { padding: 8px 0; color: rgba(255,255,255,0.7); display: flex; align-items: center; gap: 10px; }
        .info-list li i { color: #6c5ce7; width: 20px; text-align: center; }
        
        code { background: rgba(0,0,0,0.3); padding: 2px 8px; border-radius: 4px; font-family: monospace; }
        hr { border: none; border-top: 1px solid rgba(255,255,255,0.1); margin: 25px 0; }
        

        .developer-strip { display:flex; justify-content:center; gap:8px; align-items:center; flex-wrap:wrap; margin-top:12px; color:rgba(255,255,255,.72); font-size:.9rem; }
        .developer-strip a { color:#a29bfe; text-decoration:none; font-weight:700; }
        .license-meta { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:14px; }
        .license-badge { padding:6px 10px; border-radius:999px; background:rgba(108,92,231,.18); border:1px solid rgba(162,155,254,.25); color:#dcd7ff; font-size:.78rem; }
        .license-box { height:430px; overflow:auto; padding:18px; border-radius:14px; background:rgba(0,0,0,.28); border:1px solid rgba(255,255,255,.12); scroll-behavior:smooth; }
        .license-box h3 { margin:18px 0 10px; font-size:1rem; color:#cfc9ff; }
        .license-clause { padding:9px 0; border-bottom:1px solid rgba(255,255,255,.06); color:rgba(255,255,255,.78); font-size:.86rem; line-height:1.55; }
        .license-clause strong { color:#fff; }
        .license-progress { margin-top:12px; padding:12px 14px; border-radius:10px; background:rgba(255,255,255,.05); color:rgba(255,255,255,.72); font-size:.84rem; }
        .license-check { display:flex; gap:10px; align-items:flex-start; padding:12px 14px; margin-top:10px; background:rgba(255,255,255,.045); border:1px solid rgba(255,255,255,.08); border-radius:10px; line-height:1.45; }
        .license-check input { margin-top:4px; }
        .license-check.disabled { opacity:.48; }
        .feature-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:10px; margin-top:15px; }
        .feature-item { padding:11px 12px; border-radius:10px; background:rgba(255,255,255,.05); border:1px solid rgba(255,255,255,.08); color:rgba(255,255,255,.76); font-size:.82rem; line-height:1.4; }
        .feature-item i { color:#55efc4; margin-right:7px; }
        .danger-confirm { padding:18px; border-radius:14px; background:rgba(220,53,69,.12); border:1px solid rgba(255,107,107,.38); margin-top:20px; }
        .danger-confirm h3 { color:#ff8f8f; margin-bottom:10px; }

        @media (max-width: 600px) {
            .form-row { grid-template-columns: 1fr; }
            .steps { gap: 5px; }
            .step-item { padding: 8px 10px; font-size: 0.7rem; }
            .step-item .step-text { display: none; }
            .installer-card { padding: 20px; }
            .cron-command { font-size: 0.7rem; padding-right: 12px; padding-bottom: 45px; }
            .cron-command .copy-btn { top: auto; bottom: 8px; transform: none; right: 8px; }
            .card-header { flex-direction: column; text-align: center; }
            .feature-grid { grid-template-columns:1fr; }
            .license-box { height:360px; }
        }
    </style>
</head>
<body>
    <div class="installer">
        <div class="installer-header">
            <div class="installer-logo">🚀</div>
            <h1>Moni SMM Panel Kurulum Sihirbazı</h1>
            <p>Güvenli ve kontrollü kurulum için adımları takip edin</p>
            <div class="developer-strip"><span>Geliştirici: <strong><?php echo htmlspecialchars(INSTALLER_DEVELOPER_NAME); ?></strong></span><span>•</span><a href="<?php echo htmlspecialchars(INSTALLER_DEVELOPER_URL); ?>" target="_blank" rel="noopener noreferrer">forium.tr</a></div>
        </div>
        
        <?php if ($step === 'complete'): ?>
        <div class="installer-card">
            <div class="success-container">
                <div class="success-icon"><i class="fas fa-check-circle"></i></div>
                <h2>🎉 Kurulum Tamamlandı!</h2>
                <p>Moni SMM Panel başarıyla kuruldu ve kullanıma hazır.</p>
                <div class="developer-strip" style="margin:12px 0 18px;"><span>Geliştirici: <strong><?php echo htmlspecialchars(INSTALLER_DEVELOPER_NAME); ?></strong></span><span>•</span><a href="<?php echo htmlspecialchars(INSTALLER_DEVELOPER_URL); ?>" target="_blank" rel="noopener noreferrer">forium.tr</a></div>
                <div style="text-align:left;margin:22px 0;"><h3 style="margin-bottom:8px;">Bu sürümde bulunan yeni altyapı ve özellikler</h3><div class="feature-grid"><?php foreach ($installerFeatures as $feature): ?><div class="feature-item"><i class="fas fa-check-circle"></i><?php echo htmlspecialchars($feature); ?></div><?php endforeach; ?></div></div>
                
                <div class="alert alert-warning" style="text-align: left; margin: 25px 0;">
                    <i class="fas fa-exclamation-triangle"></i>
                    <div>
                        <strong>Güvenlik Uyarısı:</strong><br>
                        Güvenliğiniz için <code>install.php</code> dosyasını sunucunuzdan silin!
                    </div>
                </div>
                
                <p style="margin-top: 15px;">Ana sayfaya yönlendiriliyorsunuz...</p>
                <div class="countdown" id="countdown">10</div>
                
                <div class="form-actions" style="justify-content: center; margin-top: 20px;">
                    <a href="/" class="btn btn-primary"><i class="fas fa-home"></i> Ana Sayfaya Git</a>
                    <a href="/admin/" class="btn btn-success"><i class="fas fa-cog"></i> Admin Paneli</a>
                </div>
            </div>
        </div>
        
        <script>
            let count = 10;
            const countdownEl = document.getElementById('countdown');
            const timer = setInterval(() => {
                count--;
                countdownEl.textContent = count;
                if (count <= 0) { clearInterval(timer); window.location.href = '/'; }
            }, 1000);
        </script>
        
        <?php else: ?>
        
        <div class="steps">
            <div class="step-item <?php echo $step == 1 ? 'active' : ($step > 1 ? 'completed' : ''); ?>">
                <span class="step-num"><?php echo $step > 1 ? '<i class="fas fa-check"></i>' : '1'; ?></span>
                <span class="step-text">Lisans</span>
            </div>
            <div class="step-item <?php echo $step == 2 ? 'active' : ($step > 2 ? 'completed' : ''); ?>">
                <span class="step-num"><?php echo $step > 2 ? '<i class="fas fa-check"></i>' : '2'; ?></span>
                <span class="step-text">Veritabanı</span>
            </div>
            <div class="step-item <?php echo $step == 3 ? 'active' : ($step > 3 ? 'completed' : ''); ?>">
                <span class="step-num"><?php echo $step > 3 ? '<i class="fas fa-check"></i>' : '3'; ?></span>
                <span class="step-text">Admin</span>
            </div>
            <div class="step-item <?php echo $step == 4 ? 'active' : ($step > 4 ? 'completed' : ''); ?>">
                <span class="step-num"><?php echo $step > 4 ? '<i class="fas fa-check"></i>' : '4'; ?></span>
                <span class="step-text">Ayarlar</span>
            </div>
            <div class="step-item <?php echo $step == 5 ? 'active' : ''; ?>">
                <span class="step-num">5</span>
                <span class="step-text">Cron Jobs</span>
            </div>
        </div>
        
        <div class="installer-card">
            <?php if (!empty($error)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <div><?php echo $error; ?></div>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($success)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <div><?php echo $success; ?></div>
            </div>
            <?php endif; ?>
            
            <?php if ($step == 1): ?>
            <!-- ADIM 1: LİSANS -->
            <div class="card-header">
                <div class="card-header-icon"><i class="fas fa-file-signature"></i></div>
                <div>
                    <h2>Lisans ve Risk Kabulü</h2>
                    <p>Sözleşmenin tamamını inceleyip açıkça kabul etmeden kuruluma geçilemez.</p>
                </div>
            </div>

            <div class="license-meta">
                <span class="license-badge"><i class="fas fa-code-branch"></i> Sürüm: <?php echo htmlspecialchars(INSTALLER_LICENSE_VERSION); ?></span>
                <span class="license-badge"><i class="fas fa-list-ol"></i> <?php echo count($licenseClauses); ?> madde</span>
                <span class="license-badge"><i class="fas fa-user-shield"></i> Geliştirici: <?php echo htmlspecialchars(INSTALLER_DEVELOPER_NAME); ?></span>
            </div>

            <div class="alert alert-warning">
                <i class="fas fa-shield-halved"></i>
                <div><strong>Önemli güvenlik ve sorumluluk bildirimi:</strong><br>
                Yazılımın geliştirme/test süreçlerinde yapay zekâ destekli araçlardan yararlanılmış olabilir. Bağımsız akredite penetrasyon testi yapılmış olduğuna dair garanti verilmez. Statik/otomatik kontroller profesyonel sızma testinin yerine geçmez. Üretime almadan önce kendi güvenlik denetiminizi ve yedeğinizi yapmanız gerekir.</div>
            </div>

            <div id="licenseBox" class="license-box" tabindex="0" aria-label="Moni SMM Panel lisans sözleşmesi">
                <h3>Moni SMM Panel — Son Kullanıcı Lisans, Kurulum, Kullanım ve Sorumluluk Sözleşmesi</h3>
                <?php foreach ($licenseClauses as $i => $clause): ?>
                    <div class="license-clause"><strong><?php echo (int)$i + 1; ?>.</strong> <?php echo htmlspecialchars($clause, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endforeach; ?>
                <div id="licenseEnd" class="alert alert-success" style="margin:16px 0 0;">
                    <i class="fas fa-flag-checkered"></i><div><strong>Sözleşmenin sonuna ulaştınız.</strong><br>Aşağıdaki açık kabul alanları, minimum inceleme süresi de dolduğunda etkinleşecektir.</div>
                </div>
            </div>
            <div class="license-progress" id="licenseProgress"><i class="fas fa-lock"></i> Sözleşmenin sonuna kadar kaydırın ve minimum inceleme süresinin dolmasını bekleyin.</div>

            <form method="POST" id="licenseForm" style="margin-top:22px;">
                <input type="hidden" name="_install_token" value="<?php echo htmlspecialchars($_SESSION['install_csrf'], ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="step1" value="1">
                <input type="hidden" name="license_scrolled" id="licenseScrolled" value="0">

                <label class="license-check disabled" data-license-check>
                    <input type="checkbox" name="critical_risk_accept" value="1" disabled required>
                    <span><strong>Güvenlik / AI / sorumluluk risklerini özel olarak kabul ediyorum.</strong><br>Yapay zekâ destekli geliştirme ihtimali bulunduğunu, bağımsız penetrasyon testi garantisi verilmediğini, güvenlik açığı bulunmayacağına dair garanti olmadığını ve üretim güvenlik denetiminin bana ait olduğunu okudum.</span>
                </label>
                <label class="license-check disabled" data-license-check>
                    <input type="checkbox" name="backup_risk_accept" value="1" disabled required>
                    <span><strong>Yedekleme ve geri döndürülemez işlem riskini kabul ediyorum.</strong><br>Kurulum/güncelleme öncesi yedek almanın benim sorumluluğum olduğunu ve yanlış veritabanı seçimi dahil veri kaybı riskini anladım.</span>
                </label>
                <label class="license-check disabled" data-license-check>
                    <input type="checkbox" name="license_accept" value="1" disabled required>
                    <span><strong><?php echo count($licenseClauses); ?> maddelik sözleşmenin tamamını kabul ediyorum.</strong><br>Sözleşmeyi incelemek için tarafıma sunulduğunu, hükümleri kabul ettiğimi ve kuruluma devam etmek istediğimi beyan ederim.</span>
                </label>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary" id="licenseContinue" disabled><i class="fas fa-arrow-right"></i> Lisansı Kabul Et ve Devam Et</button>
                </div>
            </form>

            <?php elseif ($step == 2): ?>
            <!-- ADIM 2 -->
            <div class="card-header">
                <div class="card-header-icon"><i class="fas fa-database"></i></div>
                <div>
                    <h2>Veritabanı ve Temiz Kurulum</h2>
                    <p>MySQL bağlantısını kurun. Boş veritabanı kullanmanız önemle önerilir.</p>
                </div>
            </div>

            <div class="alert <?php echo $environmentChecks['ready'] ? 'alert-success' : 'alert-danger'; ?>" style="margin-bottom:20px;">
                <i class="fas <?php echo $environmentChecks['ready'] ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
                <div>
                    <strong>Sunucu Kontrolü:</strong> PHP <?php echo htmlspecialchars(PHP_VERSION); ?> — <?php echo $environmentChecks['ready'] ? 'kuruluma hazır' : 'eksik gereksinim var'; ?>.
                    <?php if (!empty($environmentChecks['missing_required'])): ?><br>Zorunlu eksik PHP eklentileri: <strong><?php echo htmlspecialchars(implode(', ', $environmentChecks['missing_required'])); ?></strong><?php endif; ?>
                    <?php if (!empty($environmentChecks['missing_recommended'])): ?><br>Önerilen eklentiler: <?php echo htmlspecialchars(implode(', ', $environmentChecks['missing_recommended'])); ?><?php endif; ?>
                    <?php if (!$environmentChecks['config_writable']): ?><br><code>config.php</code> okunabilir ve yazılabilir olmalıdır.<?php endif; ?>
                    <?php if (!$environmentChecks['root_writable']): ?><br>Ana dizin, kurulum kilidinin oluşturulabilmesi için yazılabilir olmalıdır.<?php endif; ?>
                </div>
            </div>

            <div class="alert alert-warning">
                <i class="fas fa-triangle-exclamation"></i>
                <div><strong>Boş veritabanı kullanın.</strong><br>Kurulum için yeni/boş bir veritabanı önerilir. Dolu veritabanı tespit edilirse hiçbir veri otomatik silinmez; kuruluma devam edebilmek için ayrıca geri döndürülemez temizlik onayı vermeniz gerekir.</div>
            </div>

            <?php if ($dbNeedsWipe || !empty($_SESSION['pending_database'])): $pendingDb = $_SESSION['pending_database'] ?? []; ?>
            <div class="danger-confirm">
                <h3><i class="fas fa-skull-crossbones"></i> Dolu Veritabanı Tespit Edildi</h3>
                <p style="color:rgba(255,255,255,.82);line-height:1.55;">Seçilen <strong><?php echo htmlspecialchars($pendingDb['db_name'] ?? ''); ?></strong> veritabanında yaklaşık <strong><?php echo (int)($pendingDb['object_count'] ?? $dbObjectCount); ?></strong> tablo/görünüm bulundu. <strong>Boş veritabanı kullanmanız önerilir.</strong> Devam ederseniz bu veritabanındaki mevcut tablo ve görünümler geri döndürülemez biçimde kaldırılacak ve Moni SMM Panel temiz kurulum şeması yüklenecektir.</p>
                <form method="POST" style="margin-top:16px;">
                    <input type="hidden" name="_install_token" value="<?php echo htmlspecialchars($_SESSION['install_csrf'], ENT_QUOTES, 'UTF-8'); ?>">
                    <input type="hidden" name="confirm_db_wipe" value="1">
                    <div class="form-group">
                        <label>Onay için veritabanı adını birebir yazın: <code><?php echo htmlspecialchars($pendingDb['db_name'] ?? ''); ?></code> <span>*</span></label>
                        <input type="text" name="wipe_db_name" class="form-control" autocomplete="off" required placeholder="<?php echo htmlspecialchars($pendingDb['db_name'] ?? ''); ?>">
                    </div>
                    <label class="license-check" style="border-color:rgba(255,107,107,.34);">
                        <input type="checkbox" name="wipe_warning_accept" value="1" required>
                        <span><strong>Geri döndürülemez silme işlemini açıkça onaylıyorum.</strong><br>Doğru veritabanını seçtiğimi, yedeğimi aldığımı ve mevcut tablo/görünümlerin silineceğini anladım.</span>
                    </label>
                    <div class="form-actions">
                        <a href="install.php?step=2&reset_db=1" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Başka Veritabanı Kullan</a>
                        <button type="submit" class="btn btn-success" style="background:linear-gradient(135deg,#d63031,#ff7675);"><i class="fas fa-trash-can"></i> Veritabanını Temizle ve Kuruluma Devam Et</button>
                    </div>
                </form>
            </div>
            <?php else: ?>
            <form method="POST">
                <input type="hidden" name="_install_token" value="<?php echo htmlspecialchars($_SESSION['install_csrf'], ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="step2" value="1">
                <div class="form-group">
                    <label>Veritabanı Sunucusu <span>*</span></label>
                    <input type="text" name="db_host" class="form-control" value="<?php echo htmlspecialchars($_POST['db_host'] ?? $currentConfig['db_host'] ?? 'localhost'); ?>" placeholder="localhost" required>
                    <div class="form-hint">Genellikle localhost olarak kalabilir.</div>
                </div>
                <div class="form-row">
                    <div class="form-group"><label>Veritabanı Adı <span>*</span></label><input type="text" name="db_name" class="form-control" value="<?php echo htmlspecialchars($_POST['db_name'] ?? $currentConfig['db_name'] ?? ''); ?>" required></div>
                    <div class="form-group"><label>Veritabanı Kullanıcısı <span>*</span></label><input type="text" name="db_user" class="form-control" value="<?php echo htmlspecialchars($_POST['db_user'] ?? $currentConfig['db_user'] ?? ''); ?>" required></div>
                </div>
                <div class="form-group"><label>Veritabanı Şifresi</label><input type="password" name="db_pass" class="form-control" autocomplete="new-password"><div class="form-hint">Sunucunuz izin veriyorsa boş olabilir; güçlü veritabanı parolası önerilir.</div></div>
                <div class="form-group"><label>Site URL <span>*</span></label><input type="url" name="site_url" class="form-control" value="<?php echo htmlspecialchars($_POST['site_url'] ?? (!empty($currentConfig['site_url']) ? $currentConfig['site_url'] : $autoSiteUrl)); ?>" required><div class="form-hint">Otomatik algılanır. Gerekirse düzenleyin; sonunda / kullanmayın.</div></div>
                <div class="form-actions">
                    <a href="install.php?step=1" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Lisansa Dön</a>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-database"></i> Bağlantıyı Kontrol Et ve Kur</button>
                </div>
            </form>
            <?php endif; ?>

            <?php elseif ($step == 3): ?>
            <!-- ADIM 3 -->
            <div class="card-header">
                <div class="card-header-icon"><i class="fas fa-user-shield"></i></div>
                <div>
                    <h2>Admin Hesabı</h2>
                    <p>Yeni yönetici hesabınızı oluşturun</p>
                </div>
            </div>
            
            <form method="POST">
                <input type="hidden" name="_install_token" value="<?php echo htmlspecialchars($_SESSION['install_csrf'], ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="step3" value="1">
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Ad</label>
                        <input type="text" name="admin_first_name" class="form-control" value="<?php echo htmlspecialchars($existingAdmin['first_name'] ?? ''); ?>" placeholder="John">
                    </div>
                    <div class="form-group">
                        <label>Soyad</label>
                        <input type="text" name="admin_last_name" class="form-control" value="<?php echo htmlspecialchars($existingAdmin['last_name'] ?? ''); ?>" placeholder="Doe">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Kullanıcı Adı <span>*</span></label>
                    <input type="text" name="admin_username" class="form-control" value="<?php echo htmlspecialchars($existingAdmin['username'] ?? 'admin'); ?>" placeholder="admin" required>
                </div>
                
                <div class="form-group">
                    <label>E-posta Adresi <span>*</span></label>
                    <input type="email" name="admin_email" class="form-control" value="<?php echo htmlspecialchars($existingAdmin['email'] ?? ''); ?>" placeholder="admin@example.com" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Şifre <span>*</span></label>
                        <input type="password" name="admin_password" class="form-control" placeholder="••••••••" required minlength="8">
                        <div class="form-hint">En az 8 karakter</div>
                    </div>
                    <div class="form-group">
                        <label>Şifre Tekrar <span>*</span></label>
                        <input type="password" name="admin_password_confirm" class="form-control" placeholder="••••••••" required minlength="8">
                    </div>
                </div>
                
                <div class="form-actions">
                    <a href="install.php?step=2" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Geri</a>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-arrow-right"></i> Oluştur ve Devam Et</button>
                </div>
            </form>
            
            <?php elseif ($step == 4): ?>
            <!-- ADIM 4 -->
            <div class="card-header">
                <div class="card-header-icon"><i class="fas fa-sliders-h"></i></div>
                <div>
                    <h2>Site Ayarları</h2>
                    <p>Temel site bilgilerini girin</p>
                </div>
            </div>
            
            <form method="POST">
                <input type="hidden" name="_install_token" value="<?php echo htmlspecialchars($_SESSION['install_csrf'], ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="step4" value="1">
                
                <div class="form-group">
                    <label>Site Adı <span>*</span></label>
                    <input type="text" name="site_name" class="form-control" value="<?php echo htmlspecialchars($existingSettings['site_name'] ?? 'SMM Panel'); ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Site Açıklaması</label>
                    <input type="text" name="site_description" class="form-control" value="<?php echo htmlspecialchars($existingSettings['site_description'] ?? 'En iyi SMM Panel Hizmeti'); ?>">
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>İletişim E-posta</label>
                        <input type="email" name="contact_email" class="form-control" value="<?php echo htmlspecialchars($existingSettings['contact_email'] ?? ''); ?>" placeholder="info@example.com">
                    </div>
                    <div class="form-group">
                        <label>İletişim Telefon</label>
                        <input type="text" name="contact_phone" class="form-control" value="<?php echo htmlspecialchars($existingSettings['contact_phone'] ?? ''); ?>" placeholder="+90 555 555 55 55">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Para Birimi</label>
                        <select name="currency" class="form-control">
                            <option value="TRY" <?php echo ($existingSettings['currency'] ?? 'TRY') === 'TRY' ? 'selected' : ''; ?>>TRY - Türk Lirası</option>
                            <option value="USD" <?php echo ($existingSettings['currency'] ?? '') === 'USD' ? 'selected' : ''; ?>>USD - Amerikan Doları</option>
                            <option value="EUR" <?php echo ($existingSettings['currency'] ?? '') === 'EUR' ? 'selected' : ''; ?>>EUR - Euro</option>
                            <option value="GBP" <?php echo ($existingSettings['currency'] ?? '') === 'GBP' ? 'selected' : ''; ?>>GBP - İngiliz Sterlini</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Para Birimi Sembolü</label>
                        <input type="text" name="currency_symbol" class="form-control" value="<?php echo htmlspecialchars($existingSettings['currency_symbol'] ?? '₺'); ?>" placeholder="₺">
                    </div>
                </div>
                
                <hr>
                <h4 style="margin-bottom: 15px; font-size: 1rem; color: rgba(255,255,255,0.8);"><i class="fas fa-shoe-prints"></i> Footer Bilgileri</h4>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Footer E-posta</label>
                        <input type="email" name="footer_email" class="form-control" value="<?php echo htmlspecialchars($existingSettings['footer_email'] ?? ''); ?>" placeholder="info@example.com">
                    </div>
                    <div class="form-group">
                        <label>Footer Telefon</label>
                        <input type="text" name="footer_phone" class="form-control" value="<?php echo htmlspecialchars($existingSettings['footer_phone'] ?? ''); ?>" placeholder="+90 555 555 55 55">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Adres</label>
                        <input type="text" name="footer_address" class="form-control" value="<?php echo htmlspecialchars($existingSettings['footer_address'] ?? ''); ?>" placeholder="İstanbul, Türkiye">
                    </div>
                    <div class="form-group">
                        <label>Çalışma Saatleri</label>
                        <input type="text" name="footer_working_hours" class="form-control" value="<?php echo htmlspecialchars($existingSettings['footer_working_hours'] ?? '7/24'); ?>" placeholder="7/24">
                    </div>
                </div>
                
                <div class="form-actions">
                    <a href="install.php?step=3" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Geri</a>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-arrow-right"></i> Kaydet ve Devam Et</button>
                </div>
            </form>
            
            <?php elseif ($step == 5): ?>
            <!-- ADIM 5 -->
            <div class="card-header">
                <div class="card-header-icon"><i class="fas fa-clock"></i></div>
                <div>
                    <h2>Cron Jobs Ayarları</h2>
                    <p>Otomatik görevler için cron job'ları ekleyin</p>
                </div>
            </div>
            
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i>
                <div><strong>Önemli!</strong> Sistemin düzgün çalışması için aşağıdaki cron job'ları hosting panelinize eklemeniz gerekmektedir. Hosting panelinizden aşağıdaki görevleri belirtilen aralıklarla ekleyin.</div>
            </div>
            
            <p style="margin-bottom: 20px; color: rgba(255,255,255,0.7);">
                <i class="fas fa-server"></i> Sunucu Yolu: <code><?php echo htmlspecialchars($serverPath); ?></code>
            </p>
            
            <div class="cron-box">
                <div class="cron-box-header">
                    <span class="cron-box-title"><i class="fas fa-gears"></i> Moni Merkezi Cron</span>
                    <span class="cron-box-interval">Her Dakika (* * * * *)</span>
                </div>
                <div class="cron-box-desc">
                    Tüm otomatik görevler yalnız bu dosya üzerinden çalışır. Dripfeed, süreli siparişler,
                    sipariş durumları, sağlayıcı sağlık kontrolü, fiyat senkronizasyonu, e-belge kuyruğu,
                    finansal kapanış ve temizlik görevlerinin gerçek çalışma aralığı ile işlem limiti
                    Yönetim Paneli &gt; Moni Sistem Merkezi &gt; Cron bölümünden ayrı ayrı ayarlanır.
                </div>
                <div class="cron-command">
                    <span><?php echo htmlspecialchars($phpCliPath); ?> <?php echo htmlspecialchars($serverPath); ?>/cronmoni.php</span>
                    <button type="button" class="copy-btn" onclick="copyText(this)"><i class="fas fa-copy"></i> Kopyala</button>
                </div>
            </div>

            <div class="alert alert-info" style="margin-top: 20px;">
                <i class="fas fa-info-circle"></i>
                <div>
                    <strong>Nasıl Eklenir?</strong><br>
                    1. cPanel &gt; Cron Jobs bölümüne gidin<br>
                    2. Zaman aralığını her dakika (* * * * *) olarak seçin<br>
                    3. Tek cronmoni.php komutunu yapıştırın ve kaydedin<br>
                    4. Görev aralıklarını ve işlem limitlerini daha sonra yönetim panelinden düzenleyin
                </div>
            </div>
            
            <form method="POST">
                <input type="hidden" name="_install_token" value="<?php echo htmlspecialchars($_SESSION['install_csrf'], ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="finish" value="1">
                <div class="form-actions">
                    <a href="install.php?step=4" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Geri</a>
                    <button type="submit" class="btn btn-success"><i class="fas fa-check-circle"></i> Kurulumu Tamamla</button>
                </div>
            </form>
            
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <div style="text-align: center; margin-top: 30px; color: rgba(255,255,255,0.4); font-size: 0.85rem;">
            <p>Moni SMM Panel Kurulum Sihirbazı &copy; <?php echo date('Y'); ?> · Geliştirici: <strong>Forium</strong> · <a href="https://forium.tr" target="_blank" rel="noopener noreferrer" style="color:#a29bfe;">forium.tr</a></p>
        </div>
    </div>
    
    <script>

    <?php if ($step == 1): ?>
    (function() {
        const box = document.getElementById('licenseBox');
        const scrolled = document.getElementById('licenseScrolled');
        const progress = document.getElementById('licenseProgress');
        const checks = Array.from(document.querySelectorAll('[data-license-check]'));
        const inputs = checks.map(x => x.querySelector('input'));
        const submit = document.getElementById('licenseContinue');
        const minSeconds = <?php echo (int)INSTALLER_LICENSE_MIN_READ_SECONDS; ?>;
        const serverElapsed = <?php echo max(0, time() - (int)($_SESSION['license_presented_at'] ?? time())); ?>;
        let remaining = Math.max(0, minSeconds - serverElapsed);
        let reachedEnd = false;

        function updateState() {
            const unlocked = reachedEnd && remaining <= 0;
            inputs.forEach(i => i.disabled = !unlocked);
            checks.forEach(c => c.classList.toggle('disabled', !unlocked));
            submit.disabled = !unlocked;
            if (unlocked) {
                progress.innerHTML = '<i class="fas fa-unlock"></i> Sözleşmenin sonuna ulaşıldı ve minimum inceleme süresi tamamlandı. Açık kabul kutularını işaretleyebilirsiniz.';
            } else if (!reachedEnd) {
                progress.innerHTML = '<i class="fas fa-arrow-down"></i> Sözleşmenin sonuna kadar kaydırın' + (remaining > 0 ? ' · minimum inceleme süresi: ' + remaining + ' sn' : '') + '.';
            } else {
                progress.innerHTML = '<i class="fas fa-hourglass-half"></i> Metnin sonuna ulaştınız. Kabul alanlarının açılması için ' + remaining + ' saniye kaldı.';
            }
        }

        box.addEventListener('scroll', function() {
            const threshold = box.scrollHeight - box.clientHeight - 8;
            if (box.scrollTop >= threshold) {
                reachedEnd = true;
                scrolled.value = '1';
                updateState();
            }
        });
        updateState();
        const timer = setInterval(function() {
            if (remaining > 0) remaining--;
            updateState();
            if (remaining <= 0) clearInterval(timer);
        }, 1000);
    })();
    <?php endif; ?>

    function copyText(btn) {
        const container = btn.parentElement;
        const span = container.querySelector('span');
        const text = span ? span.innerText.trim() : '';
        
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(function() {
                btn.innerHTML = '<i class="fas fa-check"></i> Kopyalandı';
                btn.classList.add('copied');
                setTimeout(function() {
                    btn.innerHTML = '<i class="fas fa-copy"></i> Kopyala';
                    btn.classList.remove('copied');
                }, 2000);
            });
        } else {
            const textarea = document.createElement('textarea');
            textarea.value = text;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.select();
            try {
                document.execCommand('copy');
                btn.innerHTML = '<i class="fas fa-check"></i> Kopyalandı';
                btn.classList.add('copied');
                setTimeout(function() {
                    btn.innerHTML = '<i class="fas fa-copy"></i> Kopyala';
                    btn.classList.remove('copied');
                }, 2000);
            } catch (e) {
                alert('Kopyalama başarısız. Manuel kopyalayın.');
            }
            document.body.removeChild(textarea);
        }
    }
    </script>
</body>
</html>