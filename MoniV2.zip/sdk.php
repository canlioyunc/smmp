<?php
/**
 * Moni v2 SDK download endpoint.
 * IMPORTANT: config.php uses ?lang= for UI language switching, therefore the SDK
 * selector is captured before bootstrap and uses ?sdk= as the canonical parameter.
 * Legacy ?lang=php/python/node links remain supported without triggering a language redirect.
 */
$rawSdk = strtolower(trim((string)($_GET['sdk'] ?? $_GET['type'] ?? $_GET['language'] ?? $_GET['lang'] ?? '')));
$aliases = ['py'=>'python','python3'=>'python','js'=>'node','nodejs'=>'node','php8'=>'php'];
if (isset($aliases[$rawSdk])) $rawSdk = $aliases[$rawSdk];
if (isset($_GET['lang']) && in_array($rawSdk, ['php','python','node'], true)) {
    // Prevent config.php from treating an SDK selector as a UI-language change.
    unset($_GET['lang']);
}
require_once __DIR__.'/config.php';
require_once __DIR__ . '/includes/MoniV2Compat.php';
if (!function_exists('moni_sdk_source')) { require_once __DIR__ . '/includes/MoniV2Ops.php'; }
$lang = $rawSdk;
if ($lang === '') {
    $uri=(string)($_SERVER['REQUEST_URI']??'');
    if (preg_match('~(?:[?&](?:sdk|type|language|lang)=|/sdk(?:\.php)?/)(php|python|node|py|python3|js|nodejs|php8)(?:[&/?#]|$)~i',$uri,$m)) {
        $lang=strtolower($m[1]);
        if (isset($aliases[$lang])) $lang=$aliases[$lang];
    }
}
if(!function_exists('moni_sdk_source')){http_response_code(503);header('Content-Type: text/plain; charset=utf-8');exit("SDK üretici modülü yüklenemedi.\n");}
if(!in_array($lang,['php','python','node'],true)){http_response_code(400);header('Content-Type: text/plain; charset=utf-8');exit("Geçersiz SDK dili. Desteklenen değerler: php, python, node\n");}
$sdk=moni_sdk_source($lang);
if(!$sdk||empty($sdk['source'])){http_response_code(503);header('Content-Type: text/plain; charset=utf-8');exit("SDK şu anda üretilemedi.\n");}
header('Content-Type: '.$sdk['mime'].'; charset=utf-8');
header('Content-Disposition: attachment; filename="'.preg_replace('/[^a-zA-Z0-9._-]/','_',$sdk['filename']).'"');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
echo $sdk['source'];
