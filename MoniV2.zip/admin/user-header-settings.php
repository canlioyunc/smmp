<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';
require_once __DIR__ . '/../includes/MoniAdminUI.php';
require_once __DIR__ . '/../includes/MoniUserHeaderManager.php';

if (!isLoggedIn() || !isAdmin()) {
    header('Location: /login.php');
    exit;
}
if (function_exists('moni_staff_can') && !moni_staff_can($db, 'settings.manage')) {
    http_response_code(403);
    exit('Bu yönetim sayfası için yetkiniz yok.');
}

$demoMode = (string)getSetting('demo_mode', '0') === '1';
$error = '';
$config = moni_user_header_config($db);

function moni_header_manager_redirect(): void {
    header('Location: user-header-settings.php');
    exit;
}

function moni_header_manager_assert_write(bool $demoMode): void {
    if ($demoMode) throw new RuntimeException('Demo modunda kullanıcı header ayarları değiştirilemez.');
    if (!validateCSRFToken((string)($_POST['csrf_token'] ?? ''))) throw new RuntimeException('Güvenlik doğrulaması başarısız. Sayfayı yenileyip tekrar deneyin.');
}

function moni_header_manager_unique_id(array $items, string $base, string $prefix): string {
    $existing = [];
    foreach ($items as $item) $existing[(string)($item['id'] ?? '')] = true;
    $base = moni_user_header_safe_id($base, $prefix);
    $id = $base;
    $i = 2;
    while (isset($existing[$id])) $id = $base . '-' . $i++;
    return $id;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        moni_header_manager_assert_write($demoMode);
        $action = (string)($_POST['action'] ?? 'save');

        if ($action === 'reset_defaults') {
            if (!moni_user_header_reset_config($db)) throw new RuntimeException('Varsayılan ayarlara dönüş kaydedilemedi.');
            setAlert('Kullanıcı paneli header yapısı tek tuşla fabrika varsayılanına döndürüldü.', 'success');
            moni_header_manager_redirect();
        }

        if ($action === 'add_section') {
            $label = moni_user_header_truncate(trim((string)($_POST['new_section_label'] ?? 'Yeni Menü Grubu')), 80);
            if ($label === '') $label = 'Yeni Menü Grubu';
            $id = moni_header_manager_unique_id($config['sections'], $label, 'section');
            $max = 0; foreach ($config['sections'] as $row) $max = max($max, (int)$row['order']);
            $config['sections'][] = ['id'=>$id,'label'=>$label,'enabled'=>1,'order'=>$max+10,'static'=>0,'default_open'=>0];
            moni_user_header_save_config($db, $config);
            setAlert('Yeni menü grubu eklendi.', 'success');
            moni_header_manager_redirect();
        }

        if ($action === 'add_sidebar_item') {
            $label = moni_user_header_truncate(trim((string)($_POST['new_item_label'] ?? 'Yeni Menü')), 100);
            if ($label === '') $label = 'Yeni Menü';
            $id = moni_header_manager_unique_id($config['sidebar_items'], $label, 'menu');
            $section = (string)($_POST['new_item_section'] ?? ($config['sections'][0]['id'] ?? 'quick'));
            $url = moni_user_header_safe_url($_POST['new_item_url'] ?? '#', '#');
            $icon = moni_user_header_safe_icon($_POST['new_item_icon'] ?? 'fas fa-link');
            $max = 0; foreach ($config['sidebar_items'] as $row) if (($row['section'] ?? '') === $section) $max = max($max, (int)$row['order']);
            $config['sidebar_items'][] = ['id'=>$id,'core'=>'custom','label'=>$label,'url'=>$url,'icon'=>$icon,'section'=>$section,'enabled'=>1,'order'=>$max+10,'target'=>'_self'];
            moni_user_header_save_config($db, $config);
            setAlert('Yeni kullanıcı menüsü eklendi.', 'success');
            moni_header_manager_redirect();
        }

        if ($action === 'add_topbar_item') {
            $label = moni_user_header_truncate(trim((string)($_POST['new_topbar_label'] ?? 'Yeni Kısayol')), 100);
            if ($label === '') $label = 'Yeni Kısayol';
            $id = moni_header_manager_unique_id($config['topbar_items'], $label, 'topbar');
            $url = moni_user_header_safe_url($_POST['new_topbar_url'] ?? '#', '#');
            $icon = moni_user_header_safe_icon($_POST['new_topbar_icon'] ?? 'fas fa-link');
            $max = 0; foreach ($config['topbar_items'] as $row) $max = max($max, (int)$row['order']);
            $config['topbar_items'][] = ['id'=>$id,'core'=>'custom','label'=>$label,'url'=>$url,'icon'=>$icon,'enabled'=>1,'order'=>$max+10,'target'=>'_self'];
            moni_user_header_save_config($db, $config);
            setAlert('Yeni üst header kısayolu eklendi.', 'success');
            moni_header_manager_redirect();
        }

        if ($action === 'add_profile_item') {
            $label = moni_user_header_truncate(trim((string)($_POST['new_profile_label'] ?? 'Yeni Profil Menüsü')), 100);
            if ($label === '') $label = 'Yeni Profil Menüsü';
            $id = moni_header_manager_unique_id($config['profile_items'], $label, 'profile');
            $url = moni_user_header_safe_url($_POST['new_profile_url'] ?? '#', '#');
            $icon = moni_user_header_safe_icon($_POST['new_profile_icon'] ?? 'fas fa-link');
            $max = 0; foreach ($config['profile_items'] as $row) $max = max($max, (int)$row['order']);
            $config['profile_items'][] = ['id'=>$id,'core'=>'custom','label'=>$label,'url'=>$url,'icon'=>$icon,'enabled'=>1,'order'=>$max+10,'target'=>'_self','danger'=>0,'separator_after'=>0];
            moni_user_header_save_config($db, $config);
            setAlert('Yeni profil açılır menüsü bağlantısı eklendi.', 'success');
            moni_header_manager_redirect();
        }

        // Ana düzeni kaydet.
        $new = $config;
        $new['general'] = [
            'sidebar_logo_link' => (string)($_POST['general']['sidebar_logo_link'] ?? '/'),
            'sidebar_search_enabled' => isset($_POST['general']['sidebar_search_enabled']) ? 1 : 0,
            'sidebar_logout_enabled' => isset($_POST['general']['sidebar_logout_enabled']) ? 1 : 0,
            'topbar_toggle_enabled' => isset($_POST['general']['topbar_toggle_enabled']) ? 1 : 0,
            'page_kicker_enabled' => isset($_POST['general']['page_kicker_enabled']) ? 1 : 0,
            'page_kicker_text' => (string)($_POST['general']['page_kicker_text'] ?? 'Kullanıcı Paneli'),
        ];

        $deleteSections = array_fill_keys(array_map('strval', (array)($_POST['delete_section'] ?? [])), true);
        $sectionRows = [];
        foreach ((array)($_POST['sections'] ?? []) as $id => $row) {
            $id = moni_user_header_safe_id($id, 'section');
            if (isset($deleteSections[$id]) || !is_array($row)) continue;
            $sectionRows[] = [
                'id'=>$id,
                'label'=>(string)($row['label'] ?? 'Menü'),
                'enabled'=>isset($row['enabled']) ? 1 : 0,
                'order'=>(int)($row['order'] ?? 0),
                'static'=>isset($row['static']) ? 1 : 0,
                'default_open'=>isset($row['default_open']) ? 1 : 0,
            ];
        }
        if (!$sectionRows) throw new RuntimeException('En az bir menü grubu kalmalıdır.');
        $new['sections'] = $sectionRows;
        $validSectionIds = array_fill_keys(array_column($sectionRows, 'id'), true);

        $deleteItems = array_fill_keys(array_map('strval', (array)($_POST['delete_sidebar'] ?? [])), true);
        $sidebarRows = [];
        $existingById = [];
        foreach ($config['sidebar_items'] as $row) $existingById[(string)$row['id']] = $row;
        foreach ((array)($_POST['sidebar'] ?? []) as $id => $row) {
            $id = moni_user_header_safe_id($id, 'item');
            if (isset($deleteItems[$id]) || !is_array($row)) continue;
            $old = $existingById[$id] ?? ['core'=>'custom'];
            $section = moni_user_header_safe_id($row['section'] ?? '', 'section');
            if (!isset($validSectionIds[$section])) continue; // Silinen grubun içeriği de kaldırılır.
            $sidebarRows[] = [
                'id'=>$id,
                'core'=>(string)($old['core'] ?? 'custom'),
                'label'=>(string)($row['label'] ?? 'Menü'),
                'url'=>(string)($row['url'] ?? '#'),
                'icon'=>(string)($row['icon'] ?? 'fas fa-link'),
                'section'=>$section,
                'enabled'=>isset($row['enabled']) ? 1 : 0,
                'order'=>(int)($row['order'] ?? 0),
                'target'=>(string)($row['target'] ?? '_self'),
            ];
        }
        $new['sidebar_items'] = $sidebarRows;

        $deleteTop = array_fill_keys(array_map('strval', (array)($_POST['delete_topbar'] ?? [])), true);
        $topRows = [];
        $existingTop = [];
        foreach ($config['topbar_items'] as $row) $existingTop[(string)$row['id']] = $row;
        foreach ((array)($_POST['topbar'] ?? []) as $id => $row) {
            $id = moni_user_header_safe_id($id, 'top');
            if (isset($deleteTop[$id]) || !is_array($row)) continue;
            $old = $existingTop[$id] ?? ['core'=>'custom'];
            $topRows[] = [
                'id'=>$id,
                'core'=>(string)($old['core'] ?? 'custom'),
                'label'=>(string)($row['label'] ?? 'Kısayol'),
                'url'=>(string)($row['url'] ?? ''),
                'icon'=>(string)($row['icon'] ?? 'fas fa-link'),
                'enabled'=>isset($row['enabled']) ? 1 : 0,
                'order'=>(int)($row['order'] ?? 0),
                'target'=>(string)($row['target'] ?? '_self'),
            ];
        }
        $new['topbar_items'] = $topRows;

        $deleteProfile = array_fill_keys(array_map('strval', (array)($_POST['delete_profile'] ?? [])), true);
        $profileRows = [];
        $existingProfile = [];
        foreach ($config['profile_items'] as $row) $existingProfile[(string)$row['id']] = $row;
        foreach ((array)($_POST['profilemenu'] ?? []) as $id => $row) {
            $id = moni_user_header_safe_id($id, 'profile');
            if (isset($deleteProfile[$id]) || !is_array($row)) continue;
            $old = $existingProfile[$id] ?? ['core'=>'custom'];
            $profileRows[] = [
                'id'=>$id,
                'core'=>(string)($old['core'] ?? 'custom'),
                'label'=>(string)($row['label'] ?? 'Menü'),
                'url'=>(string)($row['url'] ?? '#'),
                'icon'=>(string)($row['icon'] ?? 'fas fa-link'),
                'enabled'=>isset($row['enabled']) ? 1 : 0,
                'order'=>(int)($row['order'] ?? 0),
                'target'=>(string)($row['target'] ?? '_self'),
                'danger'=>isset($row['danger']) ? 1 : 0,
                'separator_after'=>isset($row['separator_after']) ? 1 : 0,
            ];
        }
        $new['profile_items'] = $profileRows;

        if (!moni_user_header_save_config($db, $new)) throw new RuntimeException('Header ayarları veritabanına kaydedilemedi.');
        setAlert('Kullanıcı paneli header ve menü yapısı güncellendi.', 'success');
        moni_header_manager_redirect();
    } catch (Throwable $e) {
        $error = $e->getMessage();
        $config = moni_user_header_config($db);
    }
}

$pageTitle = 'Kullanıcı Paneli Header Yönetimi';
require_once __DIR__ . '/header.php';
echo moni_admin_ui_styles();

$sectionOptions = [];
foreach ($config['sections'] as $section) $sectionOptions[$section['id']] = $section['label'];
?>
<style>
.moni-header-manager{max-width:1600px;margin:0 auto}.hm-toolbar{display:flex;gap:10px;flex-wrap:wrap;align-items:center}.hm-tabs{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 18px}.hm-tab{border:1px solid var(--border-color);background:var(--card-bg-color);color:var(--text-color);padding:10px 14px;border-radius:10px;font-weight:700;cursor:pointer}.hm-tab.active{background:var(--primary-color);border-color:var(--primary-color);color:var(--on-primary-color)}.hm-pane{display:none}.hm-pane.active{display:block}.hm-table-wrap{overflow:auto;border:1px solid var(--border-color);border-radius:14px}.hm-table{width:100%;border-collapse:collapse;min-width:1100px;background:var(--card-bg-color)}.hm-table th,.hm-table td{padding:11px;border-bottom:1px solid var(--border-color);vertical-align:middle;text-align:left}.hm-table th{font-size:.72rem;text-transform:uppercase;letter-spacing:.055em;color:var(--muted-text-color);background:var(--background-color);position:sticky;top:0;z-index:1}.hm-table tr:last-child td{border-bottom:0}.hm-table input[type=text],.hm-table input[type=number],.hm-table select{width:100%;min-width:90px;padding:9px 10px;border:1px solid var(--border-color);border-radius:9px;background:var(--background-color);color:var(--text-color)}.hm-table .hm-url{min-width:245px}.hm-table .hm-label{min-width:165px}.hm-table .hm-icon{min-width:175px}.hm-switch{display:inline-flex;align-items:center;gap:8px;font-weight:700;font-size:.8rem;white-space:nowrap}.hm-switch input{width:18px;height:18px}.hm-delete{display:inline-flex;align-items:center;gap:6px;color:var(--danger-color);font-weight:700;font-size:.78rem;white-space:nowrap}.hm-delete input{width:17px;height:17px}.hm-preview-icon{width:34px;height:34px;border-radius:9px;display:grid;place-items:center;background:var(--primary-alpha-01);border:1px solid var(--border-color);font-size:.9rem}.hm-row-id{font-size:.67rem;color:var(--muted-text-color);margin-top:4px}.hm-inline-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}.hm-note{padding:12px 14px;border-radius:12px;background:var(--primary-alpha-01);border:1px solid var(--border-color);font-size:.82rem;line-height:1.6}.hm-danger-zone{border-color:var(--danger-soft-border)!important}.hm-danger-zone .moni-card-head{border-bottom-color:var(--danger-soft-border)}.hm-order{max-width:85px}.hm-add-grid{display:grid;grid-template-columns:1.1fr 1.6fr 1.2fr 1fr auto;gap:10px;align-items:end}.hm-add-grid.section{grid-template-columns:1fr auto}.hm-badge-core{font-size:.64rem;padding:4px 7px;border-radius:999px;background:var(--primary-alpha-01);color:var(--accent-text-color);font-weight:800;display:inline-flex;align-items:center;gap:5px}@media(max-width:980px){.hm-inline-grid{grid-template-columns:1fr}.hm-add-grid,.hm-add-grid.section{grid-template-columns:1fr}.hm-add-grid .moni-btn{width:100%;justify-content:center}}
</style>
<div class="moni-page moni-header-manager">
    <div class="moni-hero">
        <div>
            <span class="moni-kicker"><i class="fas fa-window-maximize"></i> Kullanıcı Arayüzü</span>
            <h2>Kullanıcı Paneli Header Yönetimi</h2>
            <p>Sol menü gruplarını, menüleri, bağlantıları, ikonları ve üst header kısayollarını kod düzenlemeden yönetin. İsterseniz bir öğeyi pasife alın, tamamen kaldırın veya yeni bağlantı ekleyin.</p>
        </div>
        <div class="moni-hero-actions hm-toolbar">
            <a class="moni-btn secondary" href="/kullanici/" target="_blank" rel="noopener"><i class="fas fa-arrow-up-right-from-square"></i> Kullanıcı Panelini Aç</a>
            <button type="submit" form="headerManagerForm" class="moni-btn" <?= $demoMode ? 'disabled' : '' ?>><i class="fas fa-floppy-disk"></i> Değişiklikleri Kaydet</button>
        </div>
    </div>

    <?= showAlert() ?>
    <?php if ($error): ?><div class="moni-alert danger"><?= clean($error) ?></div><?php endif; ?>

    <div class="hm-tabs" role="tablist">
        <button class="hm-tab active" type="button" data-hm-tab="general"><i class="fas fa-sliders"></i> Genel</button>
        <button class="hm-tab" type="button" data-hm-tab="sections"><i class="fas fa-layer-group"></i> Menü Grupları</button>
        <button class="hm-tab" type="button" data-hm-tab="sidebar"><i class="fas fa-bars-staggered"></i> Sol Menü</button>
        <button class="hm-tab" type="button" data-hm-tab="topbar"><i class="fas fa-window-maximize"></i> Üst Header</button>
        <button class="hm-tab" type="button" data-hm-tab="profilemenu"><i class="fas fa-user-gear"></i> Profil Menüsü</button>
    </div>

    <form id="headerManagerForm" method="post">
        <?= csrf_field() ?><input type="hidden" name="action" value="save">
        <section class="hm-pane active" data-hm-pane="general">
            <div class="moni-grid">
                <div class="moni-card two-thirds">
                    <div class="moni-card-head"><div><h3>Genel Header Davranışı</h3><p>Logo, arama alanı, sayfa başlığı ve temel kontroller.</p></div><div class="moni-kpi"><i class="fas fa-sliders"></i></div></div>
                    <div class="hm-inline-grid">
                        <label class="moni-field"><span>Logo tıklama bağlantısı</span><input name="general[sidebar_logo_link]" value="<?= clean($config['general']['sidebar_logo_link']) ?>" placeholder="/"></label>
                        <label class="moni-field"><span>Sayfa üst etiketi</span><input name="general[page_kicker_text]" value="<?= clean($config['general']['page_kicker_text']) ?>" maxlength="60"></label>
                        <div class="moni-field"><span>Görünürlük</span><div style="display:grid;gap:10px;padding-top:5px">
                            <label class="hm-switch"><input type="checkbox" name="general[sidebar_search_enabled]" value="1" <?= !empty($config['general']['sidebar_search_enabled'])?'checked':'' ?>> Menü araması</label>
                            <label class="hm-switch"><input type="checkbox" name="general[sidebar_logout_enabled]" value="1" <?= !empty($config['general']['sidebar_logout_enabled'])?'checked':'' ?>> Sol menü çıkış butonu</label>
                            <label class="hm-switch"><input type="checkbox" name="general[topbar_toggle_enabled]" value="1" <?= !empty($config['general']['topbar_toggle_enabled'])?'checked':'' ?>> Menü aç/kapat butonu</label>
                            <label class="hm-switch"><input type="checkbox" name="general[page_kicker_enabled]" value="1" <?= !empty($config['general']['page_kicker_enabled'])?'checked':'' ?>> Sayfa üst etiketi</label>
                        </div></div>
                    </div>
                </div>
                <div class="moni-card third">
                    <div class="moni-card-head"><div><h3>Güvenli Yönetim</h3><p>Yanlış ayarda kurtarma davranışı.</p></div><div class="moni-kpi"><i class="fas fa-shield-halved"></i></div></div>
                    <div class="hm-note"><strong>Menü bağlantıları güvenli protokollerle sınırlandırılır.</strong><br>`javascript:` ve benzeri çalıştırılabilir URL şemaları kaydedilmez. Dış bağlantılarda yeni sekme seçeneği kullanılabilir.</div>
                    <div class="hm-note" style="margin-top:12px"><strong>Varsayılan yapı kod içinde korunur.</strong><br>Özel ayarlar bozulsa bile sistem güvenli biçimde varsayılan header yapısına dönebilir.</div>
                </div>
            </div>
        </section>

        <section class="hm-pane" data-hm-pane="sections">
            <div class="moni-card">
                <div class="moni-card-head"><div><h3>Menü Grupları</h3><p>Sol menü başlıklarını yeniden adlandırın, sıralayın, pasife alın veya kaldırın.</p></div><div class="moni-kpi"><i class="fas fa-layer-group"></i></div></div>
                <div class="hm-table-wrap"><table class="hm-table"><thead><tr><th>Aktif</th><th>Başlık</th><th>Sıra</th><th>Varsayılan</th><th>Sabit grup</th><th>Kaldır</th></tr></thead><tbody>
                <?php foreach ($config['sections'] as $section): ?>
                    <tr>
                        <td><label class="hm-switch"><input type="checkbox" name="sections[<?=clean($section['id'])?>][enabled]" value="1" <?=$section['enabled']?'checked':''?>> Aktif</label></td>
                        <td><input class="hm-label" type="text" name="sections[<?=clean($section['id'])?>][label]" value="<?=clean($section['label'])?>"><div class="hm-row-id"><?=clean($section['id'])?></div></td>
                        <td><input class="hm-order" type="number" name="sections[<?=clean($section['id'])?>][order]" value="<?=(int)$section['order']?>"></td>
                        <td><label class="hm-switch"><input type="checkbox" name="sections[<?=clean($section['id'])?>][default_open]" value="1" <?=!empty($section['default_open'])?'checked':''?>> Açık gelsin</label></td>
                        <td><label class="hm-switch"><input type="checkbox" name="sections[<?=clean($section['id'])?>][static]" value="1" <?=$section['static']?'checked':''?>> Sabit / kapanmaz</label></td>
                        <td><label class="hm-delete"><input type="checkbox" name="delete_section[]" value="<?=clean($section['id'])?>"> Grubu ve içeriğini kaldır</label></td>
                    </tr>
                <?php endforeach; ?>
                </tbody></table></div>
            </div>
        </section>

        <section class="hm-pane" data-hm-pane="sidebar">
            <div class="moni-card">
                <div class="moni-card-head"><div><h3>Sol Menü Öğeleri</h3><p>Mevcut sistem menüleri dahil tüm bağlantılar yönetilebilir. Sistem öğesini kaldırırsanız “Varsayılana Dön” ile geri gelir.</p></div><div class="moni-kpi"><i class="fas fa-bars-staggered"></i></div></div>
                <div class="hm-table-wrap"><table class="hm-table"><thead><tr><th>Durum</th><th>İkon</th><th>Menü adı</th><th>Bağlantı</th><th>Grup</th><th>Sıra</th><th>Açılış</th><th>Kaldır</th></tr></thead><tbody>
                <?php foreach ($config['sidebar_items'] as $item): ?>
                    <tr>
                        <td><label class="hm-switch"><input type="checkbox" name="sidebar[<?=clean($item['id'])?>][enabled]" value="1" <?=$item['enabled']?'checked':''?>> Aktif</label><div class="hm-row-id"><span class="hm-badge-core"><i class="fas fa-code-branch"></i><?=clean($item['core']==='custom'?'Özel':'Sistem')?></span></div></td>
                        <td><div style="display:flex;gap:8px;align-items:center"><span class="hm-preview-icon"><i class="<?=clean($item['icon'])?>"></i></span><input class="hm-icon" type="text" name="sidebar[<?=clean($item['id'])?>][icon]" value="<?=clean($item['icon'])?>"></div></td>
                        <td><input class="hm-label" type="text" name="sidebar[<?=clean($item['id'])?>][label]" value="<?=clean($item['label'])?>"><div class="hm-row-id"><?=clean($item['id'])?></div></td>
                        <td><input class="hm-url" type="text" name="sidebar[<?=clean($item['id'])?>][url]" value="<?=clean($item['url'])?>"></td>
                        <td><select name="sidebar[<?=clean($item['id'])?>][section]"><?php foreach($sectionOptions as $sid=>$slabel):?><option value="<?=clean($sid)?>" <?=$item['section']===$sid?'selected':''?>><?=clean($slabel)?></option><?php endforeach;?></select></td>
                        <td><input class="hm-order" type="number" name="sidebar[<?=clean($item['id'])?>][order]" value="<?=(int)$item['order']?>"></td>
                        <td><select name="sidebar[<?=clean($item['id'])?>][target]"><option value="_self" <?=$item['target']==='_self'?'selected':''?>>Aynı sekme</option><option value="_blank" <?=$item['target']==='_blank'?'selected':''?>>Yeni sekme</option></select></td>
                        <td><label class="hm-delete"><input type="checkbox" name="delete_sidebar[]" value="<?=clean($item['id'])?>"> Kaldır</label></td>
                    </tr>
                <?php endforeach; ?>
                </tbody></table></div>
            </div>
        </section>

        <section class="hm-pane" data-hm-pane="topbar">
            <div class="moni-card">
                <div class="moni-card-head"><div><h3>Üst Header Kısayolları</h3><p>Bakiye, dil, bildirim, referans, sipariş ve profil alanları dahil üst header sırasını ve görünürlüğünü yönetin.</p></div><div class="moni-kpi"><i class="fas fa-window-maximize"></i></div></div>
                <div class="hm-table-wrap"><table class="hm-table"><thead><tr><th>Durum</th><th>İkon</th><th>Ad / tooltip</th><th>Bağlantı</th><th>Sıra</th><th>Açılış</th><th>Kaldır</th></tr></thead><tbody>
                <?php foreach ($config['topbar_items'] as $item): ?>
                    <tr>
                        <td><label class="hm-switch"><input type="checkbox" name="topbar[<?=clean($item['id'])?>][enabled]" value="1" <?=$item['enabled']?'checked':''?>> Aktif</label><div class="hm-row-id"><span class="hm-badge-core"><i class="fas fa-code-branch"></i><?=clean($item['core']==='custom'?'Özel':'Sistem')?></span></div></td>
                        <td><div style="display:flex;gap:8px;align-items:center"><span class="hm-preview-icon"><i class="<?=clean($item['icon'])?>"></i></span><input class="hm-icon" type="text" name="topbar[<?=clean($item['id'])?>][icon]" value="<?=clean($item['icon'])?>"></div></td>
                        <td><input class="hm-label" type="text" name="topbar[<?=clean($item['id'])?>][label]" value="<?=clean($item['label'])?>"><div class="hm-row-id"><?=clean($item['id'])?> / <?=clean($item['core'])?></div></td>
                        <td><input class="hm-url" type="text" name="topbar[<?=clean($item['id'])?>][url]" value="<?=clean($item['url'])?>" placeholder="Sistem öğelerinde boş olabilir"></td>
                        <td><input class="hm-order" type="number" name="topbar[<?=clean($item['id'])?>][order]" value="<?=(int)$item['order']?>"></td>
                        <td><select name="topbar[<?=clean($item['id'])?>][target]"><option value="_self" <?=$item['target']==='_self'?'selected':''?>>Aynı sekme</option><option value="_blank" <?=$item['target']==='_blank'?'selected':''?>>Yeni sekme</option></select></td>
                        <td><label class="hm-delete"><input type="checkbox" name="delete_topbar[]" value="<?=clean($item['id'])?>"> Kaldır</label></td>
                    </tr>
                <?php endforeach; ?>
                </tbody></table></div>
            </div>
        </section>

        <section class="hm-pane" data-hm-pane="profilemenu">
            <div class="moni-card">
                <div class="moni-card-head"><div><h3>Profil Açılır Menüsü</h3><p>Kullanıcı adına tıklanınca açılan menüyü de tamamen yönetin. Bakiye, profil, güvenlik, admin geçişi ve çıkış bağlantıları düzenlenebilir.</p></div><div class="moni-kpi"><i class="fas fa-user-gear"></i></div></div>
                <div class="hm-table-wrap"><table class="hm-table"><thead><tr><th>Durum</th><th>İkon</th><th>Menü adı</th><th>Bağlantı</th><th>Sıra</th><th>Açılış</th><th>Uyarı rengi</th><th>Ayırıcı</th><th>Kaldır</th></tr></thead><tbody>
                <?php foreach ($config['profile_items'] as $item): ?>
                    <tr>
                        <td><label class="hm-switch"><input type="checkbox" name="profilemenu[<?=clean($item['id'])?>][enabled]" value="1" <?=$item['enabled']?'checked':''?>> Aktif</label><div class="hm-row-id"><span class="hm-badge-core"><i class="fas fa-code-branch"></i><?=clean($item['core']==='custom'?'Özel':'Sistem')?></span></div></td>
                        <td><div style="display:flex;gap:8px;align-items:center"><span class="hm-preview-icon"><i class="<?=clean($item['icon'])?>"></i></span><input class="hm-icon" type="text" name="profilemenu[<?=clean($item['id'])?>][icon]" value="<?=clean($item['icon'])?>"></div></td>
                        <td><input class="hm-label" type="text" name="profilemenu[<?=clean($item['id'])?>][label]" value="<?=clean($item['label'])?>"><div class="hm-row-id"><?=clean($item['id'])?></div></td>
                        <td><input class="hm-url" type="text" name="profilemenu[<?=clean($item['id'])?>][url]" value="<?=clean($item['url'])?>"></td>
                        <td><input class="hm-order" type="number" name="profilemenu[<?=clean($item['id'])?>][order]" value="<?=(int)$item['order']?>"></td>
                        <td><select name="profilemenu[<?=clean($item['id'])?>][target]"><option value="_self" <?=$item['target']==='_self'?'selected':''?>>Aynı sekme</option><option value="_blank" <?=$item['target']==='_blank'?'selected':''?>>Yeni sekme</option></select></td>
                        <td><label class="hm-switch"><input type="checkbox" name="profilemenu[<?=clean($item['id'])?>][danger]" value="1" <?=!empty($item['danger'])?'checked':''?>> Kırmızı</label></td>
                        <td><label class="hm-switch"><input type="checkbox" name="profilemenu[<?=clean($item['id'])?>][separator_after]" value="1" <?=!empty($item['separator_after'])?'checked':''?>> Sonra ayır</label></td>
                        <td><label class="hm-delete"><input type="checkbox" name="delete_profile[]" value="<?=clean($item['id'])?>"> Kaldır</label></td>
                    </tr>
                <?php endforeach; ?>
                </tbody></table></div>
            </div>
        </section>
    </form>

    <div class="moni-grid" style="margin-top:18px">
        <section class="moni-card">
            <div class="moni-card-head"><div><h3>Yeni Menü Grubu</h3><p>Sol menüye yeni bir kategori başlığı oluşturun.</p></div></div>
            <form method="post" class="hm-add-grid section"><?=csrf_field()?><input type="hidden" name="action" value="add_section"><label class="moni-field"><span>Grup adı</span><input name="new_section_label" maxlength="80" placeholder="Örn. Araçlar" required></label><button class="moni-btn" <?=$demoMode?'disabled':''?>><i class="fas fa-plus"></i> Grup Ekle</button></form>
        </section>
        <section class="moni-card">
            <div class="moni-card-head"><div><h3>Yeni Sol Menü Bağlantısı</h3><p>Herhangi bir iç veya dış bağlantıyı kullanıcı menüsüne ekleyin.</p></div></div>
            <form method="post" class="hm-add-grid"><?=csrf_field()?><input type="hidden" name="action" value="add_sidebar_item"><label class="moni-field"><span>Menü adı</span><input name="new_item_label" placeholder="Örn. Kampanyalar" required></label><label class="moni-field"><span>Bağlantı</span><input name="new_item_url" placeholder="/kullanici/kampanyalar.php" required></label><label class="moni-field"><span>Font Awesome ikon</span><input name="new_item_icon" value="fas fa-link"></label><label class="moni-field"><span>Grup</span><select name="new_item_section"><?php foreach($sectionOptions as $sid=>$slabel):?><option value="<?=clean($sid)?>"><?=clean($slabel)?></option><?php endforeach;?></select></label><button class="moni-btn" <?=$demoMode?'disabled':''?>><i class="fas fa-plus"></i> Menü Ekle</button></form>
        </section>
        <section class="moni-card">
            <div class="moni-card-head"><div><h3>Yeni Üst Header Kısayolu</h3><p>Üst bara özel ikon bağlantısı ekleyin.</p></div></div>
            <form method="post" class="hm-add-grid"><?=csrf_field()?><input type="hidden" name="action" value="add_topbar_item"><label class="moni-field"><span>Tooltip adı</span><input name="new_topbar_label" placeholder="Örn. Kampanyalar" required></label><label class="moni-field"><span>Bağlantı</span><input name="new_topbar_url" placeholder="/kullanici/kampanyalar.php" required></label><label class="moni-field"><span>Font Awesome ikon</span><input name="new_topbar_icon" value="fas fa-link"></label><div></div><button class="moni-btn" <?=$demoMode?'disabled':''?>><i class="fas fa-plus"></i> Kısayol Ekle</button></form>
        </section>
        <section class="moni-card">
            <div class="moni-card-head"><div><h3>Yeni Profil Menüsü Bağlantısı</h3><p>Kullanıcı profil açılır menüsüne özel bağlantı ekleyin.</p></div></div>
            <form method="post" class="hm-add-grid"><?=csrf_field()?><input type="hidden" name="action" value="add_profile_item"><label class="moni-field"><span>Menü adı</span><input name="new_profile_label" placeholder="Örn. Faturalarım" required></label><label class="moni-field"><span>Bağlantı</span><input name="new_profile_url" placeholder="/kullanici/faturalarim.php" required></label><label class="moni-field"><span>Font Awesome ikon</span><input name="new_profile_icon" value="fas fa-link"></label><div></div><button class="moni-btn" <?=$demoMode?'disabled':''?>><i class="fas fa-plus"></i> Profil Menüsü Ekle</button></form>
        </section>
        <section class="moni-card hm-danger-zone">
            <div class="moni-card-head"><div><h3>Tek Tuşla Varsayılana Dön</h3><p>Tüm özel header ayarlarını siler ve yazılımın şu anki orijinal kullanıcı header yapısını geri getirir.</p></div><div class="moni-kpi"><i class="fas fa-rotate-left"></i></div></div>
            <div class="hm-note">Bu işlem özel eklediğiniz menüleri, bağlantı düzenlemelerini, sıralamaları ve pasif durumları sıfırlar. Kullanıcı verilerine veya siparişlere dokunmaz.</div>
            <form method="post" style="margin-top:14px" onsubmit="return confirm('Kullanıcı paneli header ayarlarını tamamen varsayılana döndürmek istediğinize emin misiniz?');"><?=csrf_field()?><input type="hidden" name="action" value="reset_defaults"><button class="moni-btn danger" <?=$demoMode?'disabled':''?>><i class="fas fa-rotate-left"></i> Varsayılan Header Yapısını Geri Yükle</button></form>
        </section>
    </div>
</div>
<script>
(function(){
    const tabs=[...document.querySelectorAll('[data-hm-tab]')], panes=[...document.querySelectorAll('[data-hm-pane]')];
    function openTab(id){tabs.forEach(t=>t.classList.toggle('active',t.dataset.hmTab===id));panes.forEach(p=>p.classList.toggle('active',p.dataset.hmPane===id));try{sessionStorage.setItem('moniHeaderManagerTab',id)}catch(e){}}
    tabs.forEach(t=>t.addEventListener('click',()=>openTab(t.dataset.hmTab)));
    try{const saved=sessionStorage.getItem('moniHeaderManagerTab');if(saved&&panes.some(p=>p.dataset.hmPane===saved))openTab(saved)}catch(e){}
    document.querySelectorAll('.hm-icon').forEach(input=>input.addEventListener('input',function(){const preview=this.closest('td')?.querySelector('.hm-preview-icon i');if(preview)preview.className=this.value||'fas fa-circle'}));
})();
</script>
<?php require_once __DIR__ . '/footer.php'; ?>
