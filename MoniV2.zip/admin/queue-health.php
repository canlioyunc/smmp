<?php
require_once __DIR__.'/../config.php';
require_once __DIR__.'/../includes/MoniAdminUI.php';

if (!isLoggedIn() || !isAdmin()) {
    header('Location: /admin/');
    exit;
}
if (function_exists('moni_staff_can') && !moni_staff_can($db, 'settings.manage')) {
    http_response_code(403);
    exit('Yetkiniz yok.');
}

$msg = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!validateCSRFToken((string)($_POST['csrf_token'] ?? ''))) {
            throw new RuntimeException('Güvenlik doğrulaması başarısız.');
        }

        // Yeni arayüz dakika ile çalışır; eski entegrasyonlar için saniye alanları da desteklenir.
        if (isset($_POST['warning_minutes']) || isset($_POST['critical_minutes'])) {
            $warningMinutes = max(1, min(1440, (int)($_POST['warning_minutes'] ?? 5)));
            $criticalMinutes = max($warningMinutes + 1, min(10080, (int)($_POST['critical_minutes'] ?? 30)));
            $warning = $warningMinutes * 60;
            $critical = $criticalMinutes * 60;
        } else {
            $warning = max(30, min(86400, (int)($_POST['warning_seconds'] ?? 300)));
            $critical = max($warning + 30, min(604800, (int)($_POST['critical_seconds'] ?? 1800)));
        }

        updateSetting('queue_health_warning_seconds', (string)$warning);
        updateSetting('queue_health_critical_seconds', (string)$critical);
        $msg = 'Kuyruk sağlık eşikleri güncellendi.';
    } catch (Throwable $e) {
        $err = $e->getMessage();
    }
}

$health = moni_queue_health($db);
$summary = $health['summary'];
$queues = array_values(array_filter($health['queues'], static fn($q) => !empty($q['available'])));

$riskLabel = static function (string $risk): string {
    if ($risk === 'critical') return 'Kritik';
    if ($risk === 'warning') return 'Dikkat';
    return 'Sağlıklı';
};

$riskIcon = static function (string $risk): string {
    if ($risk === 'critical') return 'fa-circle-exclamation';
    if ($risk === 'warning') return 'fa-triangle-exclamation';
    return 'fa-circle-check';
};

$healthyCount = 0;
$warningCount = 0;
$criticalCount = 0;
$totalRetries = 0;
$totalProcessing = 0;
$totalSamples = 0;
$maxP95 = 0;
foreach ($queues as $q) {
    if (($q['risk'] ?? 'ok') === 'critical') $criticalCount++;
    elseif (($q['risk'] ?? 'ok') === 'warning') $warningCount++;
    else $healthyCount++;
    $totalRetries += (int)($q['retry'] ?? 0);
    $totalProcessing += (int)($q['processing'] ?? 0);
    $totalSamples += (int)($q['completed_sample'] ?? 0);
    $maxP95 = max($maxP95, (int)($q['p95_latency_seconds'] ?? 0));
}

$warningMinutes = max(1, (int)round(((int)$health['warning_seconds']) / 60));
$criticalMinutes = max($warningMinutes + 1, (int)round(((int)$health['critical_seconds']) / 60));
$problemCount = (int)$summary['failed'] + (int)$summary['manual'];
$overallRisk = (string)($summary['risk'] ?? 'ok');

$pageTitle = 'Kuyruk Yaşı ve Gecikme';
require 'header.php';
echo moni_admin_ui_styles();
?>
<style>
.qhx-page{--qh-ok:#198754;--qh-warn:#c47a00;--qh-danger:#dc3545;--qh-info:#3b82f6}
.qhx-hero-status{display:flex;align-items:center;gap:10px;min-width:max-content;padding:8px 11px;border:1px solid var(--border-color);border-radius:10px;background:var(--card-bg-color);font-size:.75rem;font-weight:700}
.qhx-hero-status .dot{width:8px;height:8px;border-radius:50%;box-shadow:0 0 0 4px color-mix(in srgb,currentColor 12%,transparent)}
.qhx-hero-status.ok{color:var(--qh-ok)}.qhx-hero-status.warning{color:var(--qh-warn)}.qhx-hero-status.critical{color:var(--qh-danger)}
.qhx-refresh-meta{display:flex;align-items:center;gap:8px;color:var(--muted-text-color);font-size:.7rem;white-space:nowrap}
.qhx-refresh-meta .live-dot{width:6px;height:6px;border-radius:50%;background:var(--qh-ok);box-shadow:0 0 0 3px color-mix(in srgb,var(--qh-ok) 12%,transparent)}
.qhx-summary{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px;margin:0 0 14px}
.qhx-kpi{position:relative;overflow:hidden;min-height:94px;padding:14px 15px;border:1px solid var(--border-color);border-radius:11px;background:var(--card-bg-color)}
.qhx-kpi:after{content:"";position:absolute;right:-18px;bottom:-28px;width:72px;height:72px;border-radius:50%;background:var(--primary-alpha-009);pointer-events:none}
.qhx-kpi-top{display:flex;align-items:center;justify-content:space-between;gap:10px;color:var(--muted-text-color);font-size:.68rem;font-weight:720}
.qhx-kpi-icon{width:30px;height:30px;border-radius:8px;display:grid;place-items:center;background:var(--primary-alpha-01);color:var(--accent-text-color)}
.qhx-kpi strong{display:block;margin-top:8px;font-size:1.3rem;line-height:1;font-weight:780;letter-spacing:-.03em;font-variant-numeric:tabular-nums}
.qhx-kpi small{display:block;margin-top:5px;color:var(--muted-text-color);font-size:.66rem;line-height:1.35}
.qhx-main-grid{display:grid;grid-template-columns:minmax(0,1.7fr) minmax(300px,.7fr);gap:13px;align-items:start}
.qhx-panel{border:1px solid var(--border-color);border-radius:11px;background:var(--card-bg-color);overflow:hidden}
.qhx-panel-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;padding:15px 16px;border-bottom:1px solid var(--border-color);background:color-mix(in srgb,var(--card-bg-color) 94%,var(--background-color))}
.qhx-panel-head h3{margin:0;font-size:.9rem;font-weight:730}.qhx-panel-head p{margin:4px 0 0;color:var(--muted-text-color);font-size:.73rem;line-height:1.45}
.qhx-health-strip{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;padding:12px 16px;border-bottom:1px solid var(--border-color)}
.qhx-health-chip{display:flex;align-items:center;gap:9px;padding:9px 10px;border:1px solid var(--border-color);border-radius:9px;background:var(--background-color)}
.qhx-health-chip i{width:28px;height:28px;border-radius:8px;display:grid;place-items:center}.qhx-health-chip strong{font-size:.86rem;display:block}.qhx-health-chip span{display:block;margin-top:1px;font-size:.64rem;color:var(--muted-text-color)}
.qhx-health-chip.ok i{background:color-mix(in srgb,var(--qh-ok) 10%,transparent);color:var(--qh-ok)}.qhx-health-chip.warning i{background:color-mix(in srgb,var(--qh-warn) 10%,transparent);color:var(--qh-warn)}.qhx-health-chip.critical i{background:color-mix(in srgb,var(--qh-danger) 10%,transparent);color:var(--qh-danger)}
.qhx-queue-list{display:flex;flex-direction:column}
.qhx-queue-row{display:grid;grid-template-columns:minmax(190px,1.3fr) minmax(150px,.85fr) repeat(4,minmax(76px,.55fr));gap:12px;align-items:center;padding:14px 16px;border-bottom:1px solid var(--border-color);transition:background .15s ease}
.qhx-queue-row:last-child{border-bottom:0}.qhx-queue-row:hover{background:var(--primary-alpha-009)}
.qhx-queue-name{display:flex;align-items:center;gap:11px;min-width:0}.qhx-queue-name .ico{width:34px;height:34px;flex:0 0 auto;border-radius:9px;display:grid;place-items:center;background:var(--primary-alpha-01);color:var(--accent-text-color)}
.qhx-queue-name strong{display:block;font-size:.8rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.qhx-queue-name small{display:block;margin-top:3px;color:var(--muted-text-color);font-size:.64rem}
.qhx-age-block{min-width:0}.qhx-age-line{display:flex;justify-content:space-between;gap:8px;align-items:center;margin-bottom:6px}.qhx-age-line strong{font-size:.78rem}.qhx-age-line span{font-size:.62rem;color:var(--muted-text-color)}
.qhx-progress{height:5px;border-radius:999px;background:color-mix(in srgb,var(--border-color) 78%,transparent);overflow:hidden}.qhx-progress span{display:block;height:100%;border-radius:inherit;background:var(--qh-ok)}.qhx-progress.warning span{background:var(--qh-warn)}.qhx-progress.critical span{background:var(--qh-danger)}
.qhx-metric{text-align:right}.qhx-metric strong{display:block;font-size:.77rem;font-weight:740;font-variant-numeric:tabular-nums}.qhx-metric span{display:block;margin-top:3px;color:var(--muted-text-color);font-size:.61rem}
.qhx-badge{display:inline-flex;align-items:center;gap:5px;border-radius:999px;padding:4px 7px;font-size:.61rem;font-weight:800;text-transform:uppercase;letter-spacing:.035em;border:1px solid transparent}
.qhx-badge.ok{color:var(--qh-ok);background:color-mix(in srgb,var(--qh-ok) 8%,transparent);border-color:color-mix(in srgb,var(--qh-ok) 20%,transparent)}.qhx-badge.warning{color:var(--qh-warn);background:color-mix(in srgb,var(--qh-warn) 8%,transparent);border-color:color-mix(in srgb,var(--qh-warn) 20%,transparent)}.qhx-badge.critical{color:var(--qh-danger);background:color-mix(in srgb,var(--qh-danger) 8%,transparent);border-color:color-mix(in srgb,var(--qh-danger) 20%,transparent)}
.qhx-settings-body{padding:16px}.qhx-field{margin-bottom:14px}.qhx-field:last-child{margin-bottom:0}.qhx-field-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:7px}.qhx-field-head label{font-size:.72rem;font-weight:720}.qhx-field-head span{font-size:.62rem;color:var(--muted-text-color)}
.qhx-input-wrap{display:flex;align-items:stretch}.qhx-input-wrap input{min-width:0;width:100%;height:40px;border:1px solid var(--border-color);border-right:0;border-radius:8px 0 0 8px;background:var(--background-color);color:var(--text-color);padding:0 11px;font:inherit;font-size:.81rem;outline:none}.qhx-input-wrap input:focus{border-color:var(--accent-text-color);box-shadow:0 0 0 3px var(--primary-alpha-01)}.qhx-input-wrap span{display:grid;place-items:center;min-width:62px;border:1px solid var(--border-color);border-radius:0 8px 8px 0;background:color-mix(in srgb,var(--card-bg-color) 88%,var(--background-color));color:var(--muted-text-color);font-size:.68rem;font-weight:700}
.qhx-threshold-visual{margin:14px 0 15px;padding:12px;border:1px solid var(--border-color);border-radius:9px;background:var(--background-color)}
.qhx-threshold-bar{display:grid;grid-template-columns:minmax(20%,1fr) minmax(20%,1fr) minmax(20%,1fr);height:8px;border-radius:999px;overflow:hidden}.qhx-threshold-bar span:nth-child(1){background:color-mix(in srgb,var(--qh-ok) 72%,transparent)}.qhx-threshold-bar span:nth-child(2){background:color-mix(in srgb,var(--qh-warn) 72%,transparent)}.qhx-threshold-bar span:nth-child(3){background:color-mix(in srgb,var(--qh-danger) 72%,transparent)}
.qhx-threshold-legend{display:flex;justify-content:space-between;gap:8px;margin-top:7px;color:var(--muted-text-color);font-size:.59rem}
.qhx-presets{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:14px}.qhx-preset{border:1px solid var(--border-color);border-radius:8px;background:var(--card-bg-color);color:var(--text-color);padding:8px 5px;font-size:.65rem;font-weight:700;cursor:pointer}.qhx-preset:hover{border-color:var(--accent-text-color);color:var(--accent-text-color);background:var(--primary-alpha-009)}
.qhx-setting-note{display:flex;align-items:flex-start;gap:8px;margin:0 0 14px;padding:10px;border-radius:9px;background:var(--primary-alpha-009);border:1px solid color-mix(in srgb,var(--accent-text-color) 12%,var(--border-color));color:var(--muted-text-color);font-size:.67rem;line-height:1.45}.qhx-setting-note i{color:var(--accent-text-color);margin-top:1px}
.qhx-save{width:100%}
.qhx-table-card{margin-top:13px}.qhx-table-status{display:flex;align-items:center;gap:8px}.qhx-table-status .ico{width:27px;height:27px;border-radius:7px;display:grid;place-items:center;background:var(--primary-alpha-01);color:var(--accent-text-color)}
.qhx-autorefresh{display:inline-flex;align-items:center;gap:7px;font-size:.7rem;color:var(--muted-text-color);cursor:pointer;user-select:none}.qhx-autorefresh input{accent-color:var(--primary-color)}
@media(max-width:1180px){.qhx-summary{grid-template-columns:repeat(3,minmax(0,1fr))}.qhx-main-grid{grid-template-columns:1fr}.qhx-queue-row{grid-template-columns:minmax(190px,1.4fr) minmax(160px,.9fr) repeat(2,minmax(70px,.5fr))}.qhx-queue-row .qhx-metric:nth-last-child(-n+2){display:none}}
@media(max-width:760px){.qhx-summary{grid-template-columns:repeat(2,minmax(0,1fr))}.qhx-kpi:last-child{grid-column:1/-1}.qhx-health-strip{grid-template-columns:1fr}.qhx-queue-row{grid-template-columns:1fr 1fr;gap:10px}.qhx-queue-name{grid-column:1/-1}.qhx-queue-row .qhx-metric{display:block!important;text-align:left}.qhx-queue-row .qhx-metric:nth-of-type(n+5){display:none!important}.qhx-panel-head{flex-direction:column}.qhx-refresh-meta{white-space:normal}}
@media(max-width:480px){.qhx-summary{grid-template-columns:1fr 1fr;gap:7px}.qhx-kpi{padding:12px;min-height:86px}.qhx-queue-row{padding:12px}.qhx-presets{grid-template-columns:1fr}.qhx-hero-status{width:100%;justify-content:center}}
</style>

<div class="moni-page qhx-page">
    <div class="moni-hero">
        <div>
            <span class="moni-kicker"><i class="fas fa-wave-square"></i> Operasyon Merkezi</span>
            <h2>Kuyruk Yaşı ve Gecikme Dashboard'u</h2>
            <p>Sipariş, iptal, muhasebe ve bildirim işlerinin gerçek kuyruk yaşını; işlem gecikmesini ve hata yükünü tek ekranda izleyin.</p>
        </div>
        <div class="moni-hero-actions">
            <div class="qhx-hero-status <?=clean($overallRisk)?>">
                <span class="dot"></span>
                <span>Genel durum: <?=clean($riskLabel($overallRisk))?></span>
            </div>
            <a class="moni-btn secondary" href="cron-center.php"><i class="fas fa-gears"></i> Cron Merkezi</a>
            <button type="button" class="moni-btn secondary" onclick="window.location.reload()"><i class="fas fa-rotate"></i> Yenile</button>
        </div>
    </div>

    <?php if ($msg): ?><div class="moni-alert success"><?=clean($msg)?></div><?php endif; ?>
    <?php if ($err): ?><div class="moni-alert danger"><?=clean($err)?></div><?php endif; ?>

    <div class="qhx-summary">
        <div class="qhx-kpi">
            <div class="qhx-kpi-top"><span>Toplam bekleyen</span><span class="qhx-kpi-icon"><i class="fas fa-layer-group"></i></span></div>
            <strong><?=number_format((int)$summary['waiting'])?></strong>
            <small><?=number_format($totalProcessing)?> iş şu anda işleniyor.</small>
        </div>
        <div class="qhx-kpi">
            <div class="qhx-kpi-top"><span>En eski aktif iş</span><span class="qhx-kpi-icon"><i class="fas fa-hourglass-half"></i></span></div>
            <strong><?=clean(moni_ops_seconds_human((int)$summary['oldest_seconds']))?></strong>
            <small>Kritik eşik: <?=clean(moni_ops_seconds_human((int)$health['critical_seconds']))?></small>
        </div>
        <div class="qhx-kpi">
            <div class="qhx-kpi-top"><span>Hata / manuel</span><span class="qhx-kpi-icon"><i class="fas fa-triangle-exclamation"></i></span></div>
            <strong><?=number_format($problemCount)?></strong>
            <small><?=number_format((int)$summary['failed'])?> failed · <?=number_format((int)$summary['manual'])?> manuel.</small>
        </div>
        <div class="qhx-kpi">
            <div class="qhx-kpi-top"><span>En yüksek P95</span><span class="qhx-kpi-icon"><i class="fas fa-chart-line"></i></span></div>
            <strong><?=clean(moni_ops_seconds_human($maxP95))?></strong>
            <small>Son 24 saat, <?=number_format($totalSamples)?> tamamlanan örnek.</small>
        </div>
        <div class="qhx-kpi">
            <div class="qhx-kpi-top"><span>Retry yükü</span><span class="qhx-kpi-icon"><i class="fas fa-rotate-left"></i></span></div>
            <strong><?=number_format($totalRetries)?></strong>
            <small>Kuyruklarda tekrar denenecek toplam iş.</small>
        </div>
    </div>

    <div class="qhx-main-grid">
        <section class="qhx-panel">
            <div class="qhx-panel-head">
                <div>
                    <h3>Canlı Kuyruk Durumu</h3>
                    <p>Yaş göstergesi, en eski aktif işin kritik eşiğe ne kadar yaklaştığını gösterir.</p>
                </div>
                <div class="qhx-refresh-meta"><span class="live-dot"></span><span>Son görüntüleme: <?=date('H:i:s')?></span></div>
            </div>

            <div class="qhx-health-strip">
                <div class="qhx-health-chip ok"><i class="fas fa-circle-check"></i><div><strong><?=$healthyCount?></strong><span>Sağlıklı kuyruk</span></div></div>
                <div class="qhx-health-chip warning"><i class="fas fa-triangle-exclamation"></i><div><strong><?=$warningCount?></strong><span>Dikkat gereken</span></div></div>
                <div class="qhx-health-chip critical"><i class="fas fa-circle-exclamation"></i><div><strong><?=$criticalCount?></strong><span>Kritik kuyruk</span></div></div>
            </div>

            <div class="qhx-queue-list">
                <?php if (!$queues): ?>
                    <div class="moni-empty"><i class="fas fa-inbox"></i>İzlenebilir aktif kuyruk bulunamadı.</div>
                <?php endif; ?>
                <?php foreach ($queues as $q):
                    $oldest = (int)($q['oldest_seconds'] ?? 0);
                    $agePct = $oldest > 0 ? min(100, (int)round(($oldest / max(1, (int)$health['critical_seconds'])) * 100)) : 0;
                    $risk = (string)($q['risk'] ?? 'ok');
                    $issues = (int)($q['failed'] ?? 0) + (int)($q['manual'] ?? 0);
                ?>
                <div class="qhx-queue-row">
                    <div class="qhx-queue-name">
                        <span class="ico"><i class="fas <?=clean($q['icon'])?>"></i></span>
                        <div>
                            <strong><?=clean($q['name'])?></strong>
                            <small><span class="qhx-badge <?=clean($risk)?>"><i class="fas <?=clean($riskIcon($risk))?>"></i><?=clean($riskLabel($risk))?></span></small>
                        </div>
                    </div>
                    <div class="qhx-age-block">
                        <div class="qhx-age-line"><strong><?=clean(moni_ops_seconds_human($oldest))?></strong><span><?=$agePct?>%</span></div>
                        <div class="qhx-progress <?=clean($risk)?>"><span style="width:<?=$agePct?>%"></span></div>
                    </div>
                    <div class="qhx-metric"><strong><?=number_format((int)$q['waiting'])?></strong><span>Bekleyen</span></div>
                    <div class="qhx-metric"><strong><?=clean(moni_ops_seconds_human((int)($q['avg_latency_seconds'] ?? 0)))?></strong><span>Ort. gecikme</span></div>
                    <div class="qhx-metric"><strong><?=clean(moni_ops_seconds_human((int)($q['p95_latency_seconds'] ?? 0)))?></strong><span>P95 / 24s</span></div>
                    <div class="qhx-metric"><strong><?=number_format($issues)?></strong><span>Hata / manuel</span></div>
                </div>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="qhx-panel">
            <div class="qhx-panel-head">
                <div>
                    <h3>Alarm Eşikleri</h3>
                    <p>Kuyruk yaşına göre uyarı ve kritik durumun ne zaman başlayacağını belirleyin.</p>
                </div>
                <i class="fas fa-sliders" style="color:var(--accent-text-color)"></i>
            </div>
            <div class="qhx-settings-body">
                <div class="qhx-setting-note"><i class="fas fa-circle-info"></i><span>Değerler artık saniye yerine dakika olarak yönetilir. Kritik eşik, uyarı eşiğinden büyük olmalıdır.</span></div>
                <div class="qhx-presets">
                    <button type="button" class="qhx-preset" data-warning="5" data-critical="30">Standart<br><small>5 / 30 dk</small></button>
                    <button type="button" class="qhx-preset" data-warning="10" data-critical="60">Rahat<br><small>10 / 60 dk</small></button>
                    <button type="button" class="qhx-preset" data-warning="2" data-critical="10">Hassas<br><small>2 / 10 dk</small></button>
                </div>

                <form method="post" id="qhxThresholdForm">
                    <input type="hidden" name="csrf_token" value="<?=clean(generateCSRFToken())?>">
                    <div class="qhx-field">
                        <div class="qhx-field-head"><label for="warning_minutes">Uyarı eşiği</label><span>Dikkat durumu başlar</span></div>
                        <div class="qhx-input-wrap"><input id="warning_minutes" type="number" name="warning_minutes" min="1" max="1440" value="<?=$warningMinutes?>" required><span>Dakika</span></div>
                    </div>
                    <div class="qhx-field">
                        <div class="qhx-field-head"><label for="critical_minutes">Kritik eşik</label><span>Acil müdahale gerekir</span></div>
                        <div class="qhx-input-wrap"><input id="critical_minutes" type="number" name="critical_minutes" min="2" max="10080" value="<?=$criticalMinutes?>" required><span>Dakika</span></div>
                    </div>

                    <div class="qhx-threshold-visual">
                        <div class="qhx-threshold-bar"><span></span><span></span><span></span></div>
                        <div class="qhx-threshold-legend"><span>Normal</span><span>Uyarı</span><span>Kritik</span></div>
                    </div>

                    <label class="qhx-autorefresh"><input type="checkbox" id="qhxAutoRefresh"> Bu sayfayı 30 saniyede bir otomatik yenile</label>
                    <div style="height:14px"></div>
                    <button class="moni-btn qhx-save"><i class="fas fa-floppy-disk"></i> Eşikleri Kaydet</button>
                </form>
            </div>
        </section>
    </div>

    <section class="qhx-panel qhx-table-card">
        <div class="qhx-panel-head">
            <div>
                <h3>Kuyruk Karşılaştırması</h3>
                <p>Son 24 saatlik gecikme dağılımı ve mevcut operasyon yükünün ayrıntılı görünümü.</p>
            </div>
            <span class="moni-badge"><i class="fas fa-database"></i> <?=$totalSamples?> örnek</span>
        </div>
        <div class="moni-table-wrap" style="border:0;border-radius:0">
            <table class="moni-table">
                <thead><tr><th>Kuyruk</th><th>Durum</th><th>Bekleyen</th><th>En eski</th><th>Retry</th><th>İşleniyor</th><th>Ort. 24s</th><th>P95 24s</th><th>Maks. 24s</th><th>Örnek</th></tr></thead>
                <tbody>
                <?php if (!$queues): ?><tr><td colspan="10" class="moni-table-empty">Kuyruk verisi bulunamadı.</td></tr><?php endif; ?>
                <?php foreach ($queues as $q): $risk = (string)($q['risk'] ?? 'ok'); ?>
                    <tr>
                        <td><div class="qhx-table-status"><span class="ico"><i class="fas <?=clean($q['icon'])?>"></i></span><strong><?=clean($q['name'])?></strong></div></td>
                        <td><span class="qhx-badge <?=clean($risk)?>"><?=clean($riskLabel($risk))?></span></td>
                        <td><?=number_format((int)$q['waiting'])?></td>
                        <td><strong><?=clean(moni_ops_seconds_human((int)($q['oldest_seconds'] ?? 0)))?></strong></td>
                        <td><?=number_format((int)($q['retry'] ?? 0))?></td>
                        <td><?=number_format((int)($q['processing'] ?? 0))?></td>
                        <td><?=clean(moni_ops_seconds_human((int)($q['avg_latency_seconds'] ?? 0)))?></td>
                        <td><strong><?=clean(moni_ops_seconds_human((int)($q['p95_latency_seconds'] ?? 0)))?></strong></td>
                        <td><?=clean(moni_ops_seconds_human((int)($q['max_latency_seconds'] ?? 0)))?></td>
                        <td><?=number_format((int)($q['completed_sample'] ?? 0))?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>

<script>
(function(){
    const warning = document.getElementById('warning_minutes');
    const critical = document.getElementById('critical_minutes');
    document.querySelectorAll('.qhx-preset').forEach(btn => {
        btn.addEventListener('click', () => {
            warning.value = btn.dataset.warning || '5';
            critical.value = btn.dataset.critical || '30';
            warning.focus();
        });
    });

    const auto = document.getElementById('qhxAutoRefresh');
    const storageKey = 'moni_queue_health_auto_refresh';
    try { auto.checked = localStorage.getItem(storageKey) === '1'; } catch(e) {}
    auto.addEventListener('change', () => {
        try { localStorage.setItem(storageKey, auto.checked ? '1' : '0'); } catch(e) {}
    });
    window.setInterval(() => {
        if (auto.checked && document.visibilityState === 'visible') window.location.reload();
    }, 30000);

    document.getElementById('qhxThresholdForm').addEventListener('submit', function(e){
        const w = parseInt(warning.value || '0', 10);
        const c = parseInt(critical.value || '0', 10);
        if (c <= w) {
            e.preventDefault();
            critical.setCustomValidity('Kritik eşik, uyarı eşiğinden büyük olmalıdır.');
            critical.reportValidity();
        } else {
            critical.setCustomValidity('');
        }
    });
    critical.addEventListener('input', () => critical.setCustomValidity(''));
})();
</script>
<?php require 'footer.php'; ?>
