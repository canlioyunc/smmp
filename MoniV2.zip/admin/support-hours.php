<?php
require_once __DIR__.'/../config.php';
require_once __DIR__.'/../includes/MoniAdminUI.php';
if(!isLoggedIn()||!isAdmin()){header('Location:/login.php');exit;}
if(function_exists('moni_staff_can')&&!moni_staff_can($db,'support.manage')){http_response_code(403);exit('Bu işlem için yetkiniz yok.');}

$departments=$db->query("SELECT * FROM support_departments ORDER BY sort_order,id")->fetchAll(PDO::FETCH_ASSOC);
$departmentId=(int)($_GET['department_id']??$_POST['department_id']??($departments[0]['id']??0));
$selected=null;foreach($departments as $d)if((int)$d['id']===$departmentId){$selected=$d;break;}

if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['save_hours'])){
    try{
        if(!validateCSRFToken($_POST['csrf_token']??''))throw new RuntimeException('Güvenlik doğrulaması başarısız.');
        if(!$selected)throw new RuntimeException('Destek departmanı bulunamadı.');
        $enabled=!empty($_POST['working_hours_enabled'])?1:0;$accept=!empty($_POST['accept_after_hours'])?1:0;
        $timezone=moni_support_safe_timezone(trim((string)($_POST['timezone']??'Europe/Istanbul')));
        $message=mb_substr(trim((string)($_POST['after_hours_message']??'')),0,500,'UTF-8');
        $db->beginTransaction();
        $db->prepare("UPDATE support_departments SET working_hours_enabled=?,timezone=?,accept_after_hours=?,after_hours_message=?,updated_at=NOW() WHERE id=?")
           ->execute([$enabled,$timezone,$accept,$message,$departmentId]);
        $up=$db->prepare("INSERT INTO support_department_hours(department_id,day_of_week,open_time,close_time,is_closed,created_at,updated_at) VALUES(?,?,?,?,?,NOW(),NOW()) ON DUPLICATE KEY UPDATE open_time=VALUES(open_time),close_time=VALUES(close_time),is_closed=VALUES(is_closed),updated_at=NOW()");
        for($day=1;$day<=7;$day++){
            $open=(string)($_POST['open_time'][$day]??'09:00');$close=(string)($_POST['close_time'][$day]??'18:00');
            if(!preg_match('/^\d{2}:\d{2}$/',$open)||!preg_match('/^\d{2}:\d{2}$/',$close))throw new RuntimeException('Çalışma saati biçimi geçersiz.');
            $up->execute([$departmentId,$day,$open.':00',$close.':00',!empty($_POST['closed'][$day])?1:0]);
        }
        $db->commit();setAlert('Destek çalışma saatleri kaydedildi.','success');header('Location: support-hours.php?department_id='.$departmentId);exit;
    }catch(Throwable $e){if($db->inTransaction())$db->rollBack();setAlert($e->getMessage(),'danger');}
}

$hours=[];if($selected){$q=$db->prepare("SELECT * FROM support_department_hours WHERE department_id=? ORDER BY day_of_week");$q->execute([$departmentId]);foreach($q->fetchAll(PDO::FETCH_ASSOC) as $r)$hours[(int)$r['day_of_week']]=$r;$q=$db->prepare("SELECT * FROM support_departments WHERE id=?");$q->execute([$departmentId]);$selected=$q->fetch(PDO::FETCH_ASSOC);}
$status=$selected?moni_support_department_status($db,$departmentId):['open'=>true,'enabled'=>false,'label'=>'-'];
$days=moni_support_weekdays();$tzOptions=['Europe/Istanbul'=>'Türkiye / İstanbul','UTC'=>'UTC','Europe/London'=>'Londra','Europe/Berlin'=>'Berlin','Asia/Dubai'=>'Dubai','America/New_York'=>'New York'];
$pageTitle='Destek Çalışma Saatleri';require_once __DIR__.'/header.php';echo moni_admin_ui_styles();
?>
<style>
.support-hours-page{--support-soft:color-mix(in srgb,var(--primary-color) 8%,var(--card-bg-color));}
.support-hours-page .support-status-value{display:inline-flex;align-items:center;gap:7px;font-size:1.05rem!important;font-weight:800;white-space:nowrap}
.support-hours-page .support-status-value:before{content:"";width:8px;height:8px;border-radius:50%;background:currentColor;box-shadow:0 0 0 4px color-mix(in srgb,currentColor 13%,transparent)}
.support-hours-page .support-status-value.open{color:#22a06b}.support-hours-page .support-status-value.closed{color:#e05260}
.support-department-card{position:sticky;top:86px;align-self:start}
.support-department-summary{display:grid;gap:9px;margin-top:14px}
.support-summary-row{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:11px 12px;border:1px solid var(--border-color);border-radius:10px;background:color-mix(in srgb,var(--background-color) 74%,var(--card-bg-color));font-size:.78rem}
.support-summary-row>span:first-child{display:flex;align-items:center;gap:8px;color:var(--muted-text-color)}
.support-summary-row i{width:22px;color:var(--accent-text-color);text-align:center}.support-summary-row strong{text-align:right;font-size:.78rem}
.support-settings-strip{display:grid;grid-template-columns:minmax(0,1.08fr) minmax(260px,.92fr);gap:12px;margin-bottom:18px}
.support-setting-tile{min-width:0;border:1px solid var(--border-color);border-radius:12px;padding:14px;background:color-mix(in srgb,var(--background-color) 72%,var(--card-bg-color))}
.support-setting-toggle{display:flex;align-items:center;gap:12px}.support-setting-icon{width:40px;height:40px;border-radius:11px;display:grid;place-items:center;background:var(--primary-alpha-01);color:var(--accent-text-color);flex:0 0 auto}
.support-setting-copy{min-width:0;flex:1}.support-setting-copy strong{display:block;font-size:.84rem;margin-bottom:3px}.support-setting-copy span{display:block;color:var(--muted-text-color);font-size:.73rem;line-height:1.45}
.support-setting-switch{margin-left:auto;flex:0 0 auto}
.support-timezone-tile .moni-field{gap:7px}.support-timezone-label{display:flex;align-items:center;gap:7px}.support-timezone-label i{color:var(--accent-text-color)}
.support-schedule{border:1px solid var(--border-color);border-radius:13px;overflow:hidden;background:var(--card-bg-color)}
.support-schedule-head,.support-schedule-row{display:grid;grid-template-columns:minmax(145px,1.15fr) minmax(135px,.95fr) minmax(135px,.95fr) minmax(120px,.7fr);align-items:center;gap:12px}
.support-schedule-head{padding:10px 14px;background:color-mix(in srgb,var(--card-bg-color) 84%,var(--background-color));border-bottom:1px solid var(--border-color);color:var(--muted-text-color);font-size:.66rem;font-weight:800;text-transform:uppercase;letter-spacing:.07em}
.support-schedule-row{padding:11px 14px;border-bottom:1px solid var(--border-color);transition:background .16s ease,opacity .16s ease}.support-schedule-row:last-child{border-bottom:0}.support-schedule-row:hover{background:var(--primary-alpha-009)}
.support-day{display:flex;align-items:center;gap:10px;min-width:0}.support-day-icon{width:34px;height:34px;border-radius:9px;display:grid;place-items:center;background:var(--primary-alpha-01);color:var(--accent-text-color);font-size:.76rem;flex:0 0 auto}.support-day strong{font-size:.82rem}.support-day small{display:block;color:var(--muted-text-color);font-size:.68rem;margin-top:2px}
.support-time-input{position:relative}.support-time-input i{position:absolute;left:10px;top:50%;transform:translateY(-50%);font-size:.72rem;color:var(--muted-text-color);pointer-events:none}.support-time-input input{padding-left:31px!important}
.support-day-state{display:flex;justify-content:flex-end}.support-day-state .moni-switch{gap:8px}.support-day-state-text{font-size:.75rem;font-weight:700;min-width:40px;color:var(--card-text-color)}
.support-schedule-row.is-closed{background:color-mix(in srgb,var(--background-color) 82%,var(--card-bg-color));opacity:.72}.support-schedule-row.is-closed .support-time-input{opacity:.55}.support-schedule-row.is-closed .support-time-input input{pointer-events:none}
.support-after-hours{margin-top:18px;padding:16px;border:1px solid var(--border-color);border-radius:13px;background:linear-gradient(145deg,color-mix(in srgb,var(--primary-color) 5%,var(--card-bg-color)),var(--card-bg-color))}
.support-after-hours-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:14px}.support-after-hours-title{display:flex;align-items:flex-start;gap:11px}.support-after-hours-title>i{width:38px;height:38px;border-radius:10px;display:grid;place-items:center;background:var(--primary-alpha-01);color:var(--accent-text-color);flex:0 0 auto}.support-after-hours-title strong{display:block;font-size:.86rem;margin:2px 0 3px}.support-after-hours-title span{display:block;color:var(--muted-text-color);font-size:.73rem;line-height:1.45}
.support-savebar{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-top:18px;padding-top:16px;border-top:1px solid var(--border-color)}.support-savebar-note{display:flex;align-items:center;gap:8px;color:var(--muted-text-color);font-size:.72rem}.support-savebar-note i{color:var(--accent-text-color)}
@media(max-width:1050px){.support-department-card{position:static}.support-settings-strip{grid-template-columns:1fr}.support-schedule-head,.support-schedule-row{grid-template-columns:minmax(125px,1.05fr) 1fr 1fr minmax(100px,.7fr)}}
@media(max-width:760px){.support-schedule-head{display:none}.support-schedule-row{grid-template-columns:1fr 1fr;gap:10px}.support-day{grid-column:1/-1}.support-day-state{justify-content:flex-start}.support-time-input:before{display:block;margin-bottom:5px;color:var(--muted-text-color);font-size:.65rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.support-time-input.open:before{content:"Açılış"}.support-time-input.close:before{content:"Kapanış"}.support-after-hours-head{flex-direction:column}.support-savebar{align-items:stretch;flex-direction:column}.support-savebar .moni-btn{width:100%}}
</style>
<div class="moni-page support-hours-page">
  <div class="moni-hero">
    <div>
      <span class="moni-kicker"><i class="fas fa-headset"></i> Destek Operasyonu</span>
      <h2>Destek Çalışma Saatleri</h2>
      <p>Departman bazında mesai planı, saat dilimi ve mesai dışı talep politikasını tek merkezden yönetin. Tanımlanan plan kullanıcı destek formuna anlık olarak uygulanır.</p>
    </div>
    <div class="moni-hero-actions">
      <a class="moni-btn secondary" href="support-departments.php"><i class="fas fa-users"></i> Departmanlar</a>
      <a class="moni-btn secondary" href="support.php"><i class="fas fa-ticket"></i> Destek Talepleri</a>
    </div>
  </div>

  <?=showAlert()?>
  <?php if(!$departments):?>
    <div class="moni-card full"><div class="moni-empty"><i class="fas fa-building-circle-exclamation"></i>Önce bir destek departmanı oluşturun.</div></div>
  <?php else:?>
  <div class="moni-grid">
    <div class="moni-card quarter compact"><div class="moni-kpi"><i class="fas fa-building"></i><div><strong><?=count($departments)?></strong><span class="moni-muted">Toplam departman</span></div></div></div>
    <div class="moni-card quarter compact"><div class="moni-kpi"><i class="fas fa-signal"></i><div><strong class="support-status-value <?=$status['open']?'open':'closed'?>"><?=clean($status['label']??'-')?></strong><span class="moni-muted">Şu anki durum</span></div></div></div>
    <div class="moni-card quarter compact"><div class="moni-kpi"><i class="fas fa-earth-europe"></i><div><strong><?=clean($selected['timezone']??'Europe/Istanbul')?></strong><span class="moni-muted">Saat dilimi</span></div></div></div>
    <div class="moni-card quarter compact"><div class="moni-kpi"><i class="fas fa-inbox"></i><div><strong><?=!empty($selected['accept_after_hours'])?'Açık':'Kapalı'?></strong><span class="moni-muted">Mesai dışı talep</span></div></div></div>

    <aside class="moni-card third support-department-card">
      <div class="moni-card-head"><div><h3>Departman</h3><p>Düzenlemek istediğiniz destek ekibini seçin.</p></div><span class="moni-badge <?=$status['open']?'ok':'danger'?>"><?=clean($status['label']??'-')?></span></div>
      <form method="get">
        <div class="moni-field"><label>Destek departmanı</label><select name="department_id" onchange="this.form.submit()"><?php foreach($departments as $d):?><option value="<?=$d['id']?>" <?=$departmentId===(int)$d['id']?'selected':''?>><?=clean($d['name'])?></option><?php endforeach;?></select></div>
      </form>
      <div class="support-department-summary">
        <div class="support-summary-row"><span><i class="fas fa-clock"></i> Çalışma planı</span><strong><?=!empty($selected['working_hours_enabled'])?'Etkin':'7/24'?></strong></div>
        <div class="support-summary-row"><span><i class="fas fa-globe"></i> Saat dilimi</span><strong><?=clean($selected['timezone']??'Europe/Istanbul')?></strong></div>
        <div class="support-summary-row"><span><i class="fas fa-envelope-open-text"></i> Mesai dışı</span><strong><?=!empty($selected['accept_after_hours'])?'Talep kabul':'Talep kapalı'?></strong></div>
      </div>
      <div class="moni-divider"></div>
      <div class="moni-help"><i class="fas fa-shield-halved"></i><div><strong>Geriye uyumlu davranış</strong><br>Çalışma saatleri etkinleştirilmemiş departmanlar 7/24 açık kabul edilir. Bu sayfadaki değişiklikler mevcut destek kayıtlarını etkilemez.</div></div>
    </aside>

    <section class="moni-card two-third">
      <div class="moni-card-head">
        <div><h3><?=clean($selected['name']??'Departman')?> çalışma planı</h3><p>Haftalık çalışma saatlerini ve mesai dışı davranışı yapılandırın. Gece vardiyası için 22:00 → 06:00 gibi çapraz saat aralıkları kullanabilirsiniz.</p></div>
        <span class="moni-badge <?=$status['open']?'ok':'danger'?>"><?=clean($status['label']??'-')?></span>
      </div>
      <form method="post" id="supportHoursForm">
        <input type="hidden" name="csrf_token" value="<?=clean(generateCSRFToken())?>">
        <input type="hidden" name="department_id" value="<?=$departmentId?>">

        <div class="support-settings-strip">
          <div class="support-setting-tile">
            <div class="support-setting-toggle">
              <div class="support-setting-icon"><i class="fas fa-calendar-check"></i></div>
              <div class="support-setting-copy"><strong>Çalışma planını etkinleştir</strong><span>Kapalıysa bu departman haftanın her günü 7/24 açık kabul edilir.</span></div>
              <label class="moni-switch support-setting-switch" aria-label="Çalışma planını etkinleştir">
                <input type="checkbox" name="working_hours_enabled" value="1" <?=!empty($selected['working_hours_enabled'])?'checked':''?>>
                <span class="moni-switch-track"></span>
              </label>
            </div>
          </div>
          <div class="support-setting-tile support-timezone-tile">
            <div class="moni-field"><label class="support-timezone-label"><i class="fas fa-earth-europe"></i> Saat dilimi</label><select name="timezone"><?php foreach($tzOptions as $tz=>$label):?><option value="<?=clean($tz)?>" <?=($selected['timezone']??'Europe/Istanbul')===$tz?'selected':''?>><?=clean($label)?> · <?=clean($tz)?></option><?php endforeach;?></select><small>Tüm açık/kapalı hesaplamaları bu saat dilimine göre yapılır.</small></div>
          </div>
        </div>

        <div class="moni-card-head" style="margin-bottom:10px"><div><h3>Haftalık takvim</h3><p>Her gün için açılış ve kapanış saatini belirleyin veya günü tamamen kapatın.</p></div></div>
        <div class="support-schedule">
          <div class="support-schedule-head"><span>Gün</span><span>Açılış</span><span>Kapanış</span><span style="text-align:right">Durum</span></div>
          <?php foreach($days as $day=>$name):$r=$hours[$day]??['open_time'=>'09:00:00','close_time'=>'18:00:00','is_closed'=>($day>=6?1:0)];$isClosed=!empty($r['is_closed']);?>
            <div class="support-schedule-row <?=$isClosed?'is-closed':''?>" data-day-row>
              <div class="support-day"><span class="support-day-icon"><i class="fas fa-calendar-day"></i></span><div><strong><?=clean($name)?></strong><small><?=$day>=6?'Hafta sonu':'Hafta içi'?></small></div></div>
              <div class="support-time-input open"><i class="far fa-clock"></i><input type="time" aria-label="<?=clean($name)?> açılış" name="open_time[<?=$day?>]" value="<?=clean(substr((string)$r['open_time'],0,5))?>"></div>
              <div class="support-time-input close"><i class="far fa-clock"></i><input type="time" aria-label="<?=clean($name)?> kapanış" name="close_time[<?=$day?>]" value="<?=clean(substr((string)$r['close_time'],0,5))?>"></div>
              <div class="support-day-state"><label class="moni-switch"><input type="checkbox" name="closed[<?=$day?>]" value="1" <?=$isClosed?'checked':''?> data-day-closed><span class="moni-switch-track"></span><span class="support-day-state-text" data-day-state-text><?=$isClosed?'Kapalı':'Açık'?></span></label></div>
            </div>
          <?php endforeach;?>
        </div>

        <div class="support-after-hours">
          <div class="support-after-hours-head">
            <div class="support-after-hours-title"><i class="fas fa-moon"></i><div><strong>Mesai dışı talep politikası</strong><span>Departman kapalıyken kullanıcıların yeni destek talebi oluşturup oluşturamayacağını belirleyin.</span></div></div>
            <label class="moni-switch"><input type="checkbox" name="accept_after_hours" value="1" <?=!isset($selected['accept_after_hours'])||!empty($selected['accept_after_hours'])?'checked':''?>><span class="moni-switch-track"></span><span class="support-day-state-text"><?=!isset($selected['accept_after_hours'])||!empty($selected['accept_after_hours'])?'Kabul et':'Engelle'?></span></label>
          </div>
          <div class="moni-field"><label>Mesai dışı kullanıcı mesajı</label><textarea name="after_hours_message" rows="3" maxlength="500" placeholder="Örn: Destek ekibimiz şu anda mesai dışında. Talebiniz ilk çalışma saatinde ele alınacaktır."><?=clean($selected['after_hours_message']??'')?></textarea><small>Bu mesaj, departman kapalıyken destek formunda kullanıcıya gösterilir.</small></div>
        </div>

        <div class="support-savebar">
          <div class="support-savebar-note"><i class="fas fa-circle-info"></i> Değişiklikler yalnız seçili departmana uygulanır.</div>
          <button class="moni-btn" name="save_hours" value="1"><i class="fas fa-floppy-disk"></i> Çalışma Planını Kaydet</button>
        </div>
      </form>
    </section>
  </div>
  <?php endif;?>
</div>
<script>
(function(){
  document.querySelectorAll('[data-day-row]').forEach(function(row){
    var box=row.querySelector('[data-day-closed]');
    var text=row.querySelector('[data-day-state-text]');
    if(!box)return;
    function sync(){
      row.classList.toggle('is-closed',box.checked);
      if(text)text.textContent=box.checked?'Kapalı':'Açık';
    }
    box.addEventListener('change',sync);sync();
  });
  var after=document.querySelector('input[name="accept_after_hours"]');
  if(after){
    var label=after.closest('.moni-switch')?.querySelector('.support-day-state-text');
    after.addEventListener('change',function(){if(label)label.textContent=after.checked?'Kabul et':'Engelle';});
  }
})();
</script>
<?php require_once __DIR__.'/footer.php'; ?>
