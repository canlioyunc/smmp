<?php
require_once __DIR__.'/../config.php';
require_once __DIR__.'/../includes/MoniAdminUI.php';
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['toggle_plugin'])){
    $slug=(string)($_POST['slug']??'');$enable=!empty($_POST['enable'])?1:0;
    try{
        if($slug==='provider_failover'&&$enable){$cnt=(int)$db->query("SELECT COUNT(*) FROM api_providers WHERE status='active'")->fetchColumn();if($cnt<2)throw new RuntimeException('Otomatik Sağlayıcı Failover için en az 2 aktif sağlayıcı gerekir.');}
        $st=$db->prepare("UPDATE plugins SET is_enabled=? WHERE slug=?");$st->execute([$enable,$slug]);if(moni_table_ready($db,'cron_tasks')){if($slug==='premium_memberships'){$db->prepare("UPDATE cron_tasks SET is_enabled=? WHERE task_key='premium_memberships'")->execute([$enable]);}if($slug==='service_auto_badges'){$db->prepare("UPDATE cron_tasks SET is_enabled=? WHERE task_key='service_auto_badges'")->execute([$enable]);}}moni_security_event((int)$_SESSION['user_id'],'plugin_toggle','info',['slug'=>$slug,'enabled'=>$enable]);setAlert('Eklenti durumu güncellendi.','success');header('Location: plugins.php');exit;
    }catch(Throwable $e){$error=$e->getMessage();}
}
$discovered=moni_discover_plugins();
foreach($discovered as $slug=>$m){
    // Mevcut etkin/pasif tercihini bozmadan manifest adı/açıklaması/sürümünü güncel tut.
    $db->prepare("INSERT INTO plugins(slug,name,description,version,is_enabled) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),description=VALUES(description),version=VALUES(version)")
       ->execute([$slug,$m['name'],$m['description'],$m['version'],!empty($m['default_enabled'])?1:0]);
}
$plugins=$db->query("SELECT * FROM plugins ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$providerCount=(int)$db->query("SELECT COUNT(*) FROM api_providers WHERE status='active'")->fetchColumn();
$demoMode=(string)getSetting('demo_mode','0')==='1';
$pluginSettingsRoutes=['service_auto_badges'=>'service-auto-badges.php','order_status_reasons'=>'order-reason-codes.php'];
$activeCount=count(array_filter($plugins,fn($p)=>!empty($p['is_enabled']) || ($demoMode && in_array(($p['slug']??''),['target_preview','order_status_reasons','service_capacity_indicator','same_target_concurrency'],true))));
$pageTitle='Eklenti Sistemi';require_once 'header.php';echo moni_admin_ui_styles();
?>
<style>
.plugin-search{display:flex;align-items:center;gap:10px;padding:12px;border:1px solid var(--border-color);border-radius:16px;background:var(--card-bg-color);box-shadow:0 10px 28px rgba(0,0,0,.05);margin-bottom:16px}
.plugin-search-box{position:relative;flex:1;min-width:220px}.plugin-search-box>i{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:var(--muted-text-color);pointer-events:none}.plugin-search-box input{width:100%;padding-left:42px;padding-right:42px;min-height:44px;border-radius:12px}.plugin-search-clear{position:absolute;right:8px;top:50%;transform:translateY(-50%);width:30px;height:30px;border:0;border-radius:9px;background:transparent;color:var(--muted-text-color);cursor:pointer;display:none}.plugin-search-clear:hover{background:var(--background-color);color:var(--text-color)}
.plugin-search-meta{display:flex;align-items:center;gap:8px;white-space:nowrap;color:var(--muted-text-color);font-size:.82rem}.plugin-search-meta strong{color:var(--text-color)}
.plugin-empty{display:none;grid-column:1/-1;text-align:center;padding:46px 20px}.plugin-empty i{font-size:2rem;color:var(--muted-text-color);margin-bottom:12px}.plugin-empty h3{margin:0 0 6px}.plugin-empty p{margin:0;color:var(--muted-text-color)}
@media(max-width:760px){.plugin-search{flex-wrap:wrap}.plugin-search-box{flex-basis:100%}.plugin-search>.moni-btn{flex:1}.plugin-search-meta{width:100%;justify-content:center}}
</style>
<div class="moni-page">
  <div class="plugin-search" role="search" aria-label="Eklenti ara">
    <div class="plugin-search-box">
      <i class="fas fa-magnifying-glass"></i>
      <input id="pluginSearchInput" type="search" autocomplete="off" placeholder="Eklenti adı, açıklaması veya kısa kodu ile ara…" aria-label="Eklentilerde ara">
      <button type="button" class="plugin-search-clear" id="pluginSearchClear" title="Aramayı temizle"><i class="fas fa-xmark"></i></button>
    </div>
    <button type="button" class="moni-btn" id="pluginSearchButton"><i class="fas fa-magnifying-glass"></i> Ara</button>
    <div class="plugin-search-meta"><strong id="pluginSearchCount"><?=count($plugins)?></strong> / <?=count($plugins)?> eklenti</div>
  </div>

  <div class="moni-hero">
    <div>
      <span class="moni-kicker"><i class="fas fa-puzzle-piece"></i> Modüler Sistem</span>
      <h2>Eklenti Sistemi</h2>
      <p>Çekirdek yapıyı bozmadan gelişmiş özellikleri açıp kapatın. Bağımlılık koşulları etkinleştirme sırasında sunucu tarafında doğrulanır.</p>
    </div>
    <div class="moni-hero-actions">
      <span class="moni-badge ok"><i class="fas fa-circle-check"></i> <?=$activeCount?> aktif</span>
      <a href="/admin/moni-system.php" class="moni-btn secondary"><i class="fas fa-sliders"></i> Sistem Merkezi</a>
    </div>
  </div>
  <?php if($error):?><div class="moni-alert danger"><?=clean($error)?></div><?php endif;?>
  <?=showAlert()?>
  <div class="moni-grid" id="pluginGrid">
    <?php foreach($plugins as $p): $demoForced=$demoMode&&in_array(($p['slug']??''),['target_preview','order_status_reasons','service_capacity_indicator','same_target_concurrency'],true); $on=(bool)$p['is_enabled']||$demoForced; $blocked=$p['slug']==='provider_failover'&&!$on&&$providerCount<2; $searchText=mb_strtolower(trim(($p['name']??'').' '.($p['description']??'').' '.($p['slug']??'').' '.($on?'aktif':'pasif')),'UTF-8'); ?>
      <section class="moni-card third plugin-card" data-plugin-card data-search="<?=clean($searchText)?>" style="display:flex;flex-direction:column;min-height:230px">
        <div class="moni-card-head">
          <div>
            <div class="moni-actions" style="margin-bottom:9px">
              <span class="moni-badge <?=$on?'ok':'off'?>"><i class="fas <?=$on?'fa-circle-check':'fa-circle-pause'?>"></i> <?=$on?'Aktif':'Pasif'?></span>
              <span class="moni-badge">v<?=clean($p['version'])?></span><?php if($demoForced):?><span class="moni-badge ok"><i class="fas fa-flask"></i> Demo modunda aktif</span><?php endif;?>
            </div>
            <h3><?=clean($p['name'])?></h3>
            <p><?=clean($p['description'])?></p>
          </div>
          <div class="moni-kpi"><i class="fas fa-puzzle-piece"></i></div>
        </div>
        <?php if($p['slug']==='provider_failover'):?>
          <div class="moni-help" style="margin-top:auto;margin-bottom:14px"><i class="fas fa-server"></i><div><strong><?=$providerCount?> aktif sağlayıcı</strong><br>Failover için en az 2 aktif sağlayıcı gerekir.</div></div>
        <?php elseif($demoForced):?>
          <div class="moni-help" style="margin-top:auto;margin-bottom:14px"><i class="fas fa-flask"></i><div><strong>Demo istisnası etkin</strong><br>Bu eklenti normal kurulumlarda varsayılan kapalıdır; demo_mode açık olduğu için bu sitede zorunlu aktiftir.</div></div>
        <?php else:?><div style="flex:1"></div><?php endif;?>
        <?php if(isset($pluginSettingsRoutes[$p['slug']])):?><a class="moni-btn secondary" style="width:100%;margin-bottom:8px" href="<?=clean($pluginSettingsRoutes[$p['slug']])?>"><i class="fas fa-sliders"></i> Ayarlar ve Raporlar</a><?php endif;?>
        <?php if($demoForced):?>
          <button class="moni-btn secondary" style="width:100%" disabled><i class="fas fa-lock"></i> Demo Modunda Aktif</button>
        <?php else:?>
        <form method="post">
          <?=csrf_field()?>
          <input type="hidden" name="toggle_plugin" value="1"><input type="hidden" name="slug" value="<?=clean($p['slug'])?>"><input type="hidden" name="enable" value="<?=$on?0:1?>">
          <button class="moni-btn <?=$on?'danger':''?>" style="width:100%" <?=$blocked?'disabled title="En az 2 aktif sağlayıcı gerekir"':''?>>
            <i class="fas <?=$on?'fa-power-off':'fa-play'?>"></i> <?=$on?'Devre Dışı Bırak':'Etkinleştir'?>
          </button>
        </form>
        <?php endif;?>
      </section>
    <?php endforeach;?>
    <div class="moni-card full plugin-empty" id="pluginSearchEmpty">
      <i class="fas fa-magnifying-glass"></i><h3>Eşleşen eklenti bulunamadı</h3><p>Farklı bir ad, açıklama veya eklenti kısa kodu deneyin.</p>
    </div>
  </div>
</div>
<script>
(function(){
  const input=document.getElementById('pluginSearchInput'),button=document.getElementById('pluginSearchButton'),clear=document.getElementById('pluginSearchClear'),count=document.getElementById('pluginSearchCount'),empty=document.getElementById('pluginSearchEmpty');
  const cards=[...document.querySelectorAll('[data-plugin-card]')];
  if(!input)return;
  function norm(v){return String(v||'').toLocaleLowerCase('tr-TR').trim();}
  function apply(){const q=norm(input.value);let shown=0;cards.forEach(card=>{const hit=!q||norm(card.dataset.search).includes(q);card.style.display=hit?'flex':'none';if(hit)shown++;});count.textContent=String(shown);empty.style.display=shown?'none':'block';clear.style.display=q?'block':'none';}
  input.addEventListener('input',apply);button.addEventListener('click',()=>{apply();input.focus();});clear.addEventListener('click',()=>{input.value='';apply();input.focus();});
  input.addEventListener('keydown',e=>{if(e.key==='Escape'&&input.value){input.value='';apply();}});
  document.addEventListener('keydown',e=>{if(e.key==='/'&&!/input|textarea|select/i.test(document.activeElement?.tagName||'')){e.preventDefault();input.focus();}});
})();
</script>
<?php require_once 'footer.php'; ?>
