<?php
/**
 * Admin - Site Ayarları + Ana Sayfa Servisleri + Sosyal Login + Hero Resim
 */

require_once __DIR__ . '/../config.php';

if (!isLoggedIn() || !isAdmin()) {
    header('Location: index.php');
    exit;
}

/** Parametreli sorgular için küçük yardımcı */
function dbExec(string $sql, array $params = []) {
    global $db;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

// Demo mode kontrolü - EN BAŞTA
$demoMode = false;
try {
    $dm = $db->prepare("SELECT setting_value FROM settings WHERE setting_key = 'demo_mode' LIMIT 1");
    $dm->execute();
    $demoMode = trim((string)$dm->fetchColumn()) === '1';
} catch (Exception $e) {
    $demoMode = false;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Demo modda tüm POST işlemlerini engelle
    if ($demoMode) {
        setAlert('Demo modunda ayarlar değiştirilemez.', 'warning');
        $redirectTab = '';
        if (isset($_POST['save_settings'])) $redirectTab = '';
        elseif (isset($_POST['delete_logo']) || isset($_POST['delete_favicon']) || isset($_POST['save_hero_image']) || isset($_POST['delete_hero_image'])) $redirectTab = '#logo';
        elseif (isset($_POST['save_homepage_service'])) $redirectTab = '#homepage-services';
        elseif (isset($_POST['save_social_login'])) $redirectTab = '#social-login';
        header('Location: settings.php' . $redirectTab);
        exit;
    }
    
    // Ana sayfa servisi silme yalnız POST + merkezi CSRF ile yapılır.
    if (isset($_POST['delete_hs']) && is_numeric($_POST['delete_hs'])) {
        dbExec("DELETE FROM homepage_services WHERE id = ?", [(int)$_POST['delete_hs']]);
        setAlert('Servis silindi!', 'success');
        header('Location: settings.php#homepage-services');
        exit;
    }

    // Genel Ayarları Kaydet
    if (isset($_POST['save_settings'])) {
        $fields = ['site_name', 'site_description', 'contact_email', 'contact_phone', 'currency', 'currency_symbol', 'homepage_services_title', 'homepage_services_subtitle'];
        foreach ($fields as $f) {
            if (isset($_POST[$f])) updateSetting($f, $_POST[$f]);
        }
        updateSetting('email_verification_enabled', isset($_POST['email_verification_enabled']) ? '1' : '0');
        
        // Logo/Favicon: gerçek MIME doğrulaması ve sabit güvenli uzantı.
        foreach (['site_logo' => ['purpose'=>'branding','mimes'=>['image/jpeg','image/png','image/gif','image/webp']],
                  'site_favicon' => ['purpose'=>'branding','mimes'=>['image/png','image/jpeg','image/gif','image/webp','image/x-icon','image/vnd.microsoft.icon']]] as $field => $cfg) {
            if (isset($_FILES[$field]) && $_FILES[$field]['error'] === UPLOAD_ERR_OK) {
                $up = moni_safe_upload($_FILES[$field], $cfg['purpose'], $cfg['mimes'], 5 * 1024 * 1024);
                if ($up['ok']) updateSetting($field, SITE_URL . '/' . $up['path']);
                else setAlert($up['error'], 'danger');
            }
        }
        
        setAlert('Ayarlar kaydedildi!', 'success');
        header('Location: settings.php');
        exit;
    }
    
    // Logo/Favicon Silme
    if (isset($_POST['delete_logo'])) { updateSetting('site_logo', ''); header('Location: settings.php#logo'); exit; }
    if (isset($_POST['delete_favicon'])) { updateSetting('site_favicon', ''); header('Location: settings.php#logo'); exit; }
    
    // ===== HERO RESİM KAYDET =====
    if (isset($_POST['save_hero_image'])) {
        if (isset($_FILES['hero_image']) && $_FILES['hero_image']['error'] === UPLOAD_ERR_OK && $_FILES['hero_image']['size'] > 0) {
            $up = moni_safe_upload($_FILES['hero_image'], 'hero', ['image/jpeg','image/png','image/gif','image/webp'], 5 * 1024 * 1024);
            if ($up['ok']) {
                $oldHero = getSetting('hero_image', '');
                if ($oldHero && str_contains($oldHero, '/uploads/hero/')) {
                    $oldPath = SITE_PATH . '/uploads/hero/' . basename(parse_url($oldHero, PHP_URL_PATH));
                    if (is_file($oldPath)) @unlink($oldPath);
                }
                updateSetting('hero_image', SITE_URL . '/' . $up['path']);
                setAlert('Hero görseli başarıyla yüklendi!', 'success');
            } else setAlert($up['error'], 'danger');
        } else {
            setAlert('Lütfen geçerli bir görsel dosyası seçin.', 'warning');
        }
        header('Location: settings.php#logo');
        exit;
    }
    
    // Hero Resim Silme
    if (isset($_POST['delete_hero_image'])) {
        $heroImage = getSetting('hero_image', '');
        if (!empty($heroImage)) {
            $fileName = basename($heroImage);
            $filePath = SITE_PATH . '/uploads/hero/' . $fileName;
            if (file_exists($filePath)) {
                @unlink($filePath);
            }
            updateSetting('hero_image', '');
            setAlert('Hero görseli silindi. Paketle gelen varsayılan gerçekçi insan görseli kullanılacak.', 'success');
        }
        header('Location: settings.php#logo');
        exit;
    }
    // ===== HERO RESİM KAYDET SON =====
    
    // Ana Sayfa Servisi Ekle/Güncelle
    if (isset($_POST['save_homepage_service'])) {
        $id              = (int)($_POST['hs_id'] ?? 0);
        $customTitle     = trim($_POST['custom_title'] ?? '') ?: null;
        $customDesc      = trim($_POST['custom_description'] ?? '') ?: null;
        $customIcon      = trim($_POST['custom_icon'] ?? 'fas fa-star');
        $customIconStyle = trim($_POST['custom_icon_style'] ?? 'linear-gradient(135deg, #6366f1, #8b5cf6)');
        $customPriceText = trim($_POST['custom_price_text'] ?? '') ?: null;
        $badgeText       = trim($_POST['badge_text'] ?? '') ?: null;
        $badgeColor      = trim($_POST['badge_color'] ?? '#ff6b6b');
        $sortOrder       = (int)($_POST['sort_order'] ?? 0);
        $status          = $_POST['status'] ?? 'active';
        
        if ($id > 0) {
            dbExec(
                "UPDATE homepage_services SET custom_title=?, custom_description=?, custom_icon=?, custom_icon_style=?, custom_price_text=?, badge_text=?, badge_color=?, sort_order=?, status=? WHERE id=?",
                [$customTitle, $customDesc, $customIcon, $customIconStyle, $customPriceText, $badgeText, $badgeColor, $sortOrder, $status, $id]
            );
        } else {
            dbExec(
                "INSERT INTO homepage_services (service_id, custom_title, custom_description, custom_icon, custom_icon_style, custom_price_text, badge_text, badge_color, sort_order, status) VALUES (0, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                [$customTitle, $customDesc, $customIcon, $customIconStyle, $customPriceText, $badgeText, $badgeColor, $sortOrder, $status]
            );
        }
        setAlert($id ? 'Güncellendi!' : 'Eklendi!', 'success');
        header('Location: settings.php#homepage-services');
        exit;
    }
    
    // ===== SOSYAL LOGIN KAYDET =====
    if (isset($_POST['save_social_login'])) {
        foreach (['google', 'discord'] as $provider) {
            
            $redirectUri = rtrim(SITE_URL, '/') . '/auth/' . $provider . '/callback.php';
            $clientId = trim($_POST[$provider]['client_id'] ?? '');
            $newSecret = trim($_POST[$provider]['client_secret'] ?? '');
            if ($newSecret !== '') {
                $stmt = $db->prepare("UPDATE social_login_settings SET client_id=?,client_secret=?,redirect_uri=?,is_enabled=?,updated_at=NOW() WHERE provider=?");
                $stmt->execute([$clientId,moni_encrypt_secret($newSecret),$redirectUri,isset($_POST[$provider]['enabled'])?1:0,$provider]);
            } else {
                $stmt = $db->prepare("UPDATE social_login_settings SET client_id=?,redirect_uri=?,is_enabled=?,updated_at=NOW() WHERE provider=?");
                $stmt->execute([$clientId,$redirectUri,isset($_POST[$provider]['enabled'])?1:0,$provider]);
            }
        }
        
        setAlert('Sosyal login ayarları kaydedildi!', 'success');
        header('Location: settings.php#social-login');
        exit;
    }
    // ===== SOSYAL LOGIN KAYDET SON =====
}

// Ayarları al
$s = [];
foreach (['site_name' => 'SMM Panel', 'site_logo' => '', 'site_favicon' => '', 'site_description' => '', 'contact_email' => '', 'contact_phone' => '', 'currency' => 'TRY', 'currency_symbol' => '₺', 'homepage_services_title' => 'Popüler Hizmetlerimiz', 'homepage_services_subtitle' => '', 'email_verification_enabled' => '1', 'hero_image' => ''] as $k => $v) {
    $s[$k] = getSetting($k, $v);
}

// Ana sayfa servisleri
$hServices = dbExec("SELECT * FROM homepage_services ORDER BY sort_order ASC")->fetchAll();

// Sosyal login ayarlarını al
$socialSettings = [];
try {
    $stmt = $db->query("SELECT * FROM social_login_settings");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $socialSettings[$row['provider']] = $row;
    }
} catch (Exception $e) {
    $socialSettings = [];
}

// Redirect URI'ları sabit olarak "alandiniz" ile oluştur
$googleRedirectUri = rtrim(SITE_URL, '/') . '/auth/google/callback.php';
$discordRedirectUri = rtrim(SITE_URL, '/') . '/auth/discord/callback.php';

$pageTitle = "Site Ayarları";
require_once 'header.php';
?>

<style>
.tabs{display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap}
.tab{padding:10px 20px;background:var(--surface-alt-color);border:1px solid var(--border-color);border-radius:8px;color:var(--muted-text-color);cursor:pointer;transition:.3s}
.tab:hover,.tab.active{background:linear-gradient(135deg,var(--primary-color),var(--secondary-color));color:var(--on-accent-color);border-color:transparent}
.section{display:none}.section.active{display:block}
.logo-box{display:flex;align-items:center;gap:15px;padding:15px;background:var(--surface-alt-color);border-radius:10px;margin-top:10px}
.logo-box img{max-height:80px;max-width:150px;object-fit:contain}
.hs-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:15px}
.hs-card{background:var(--surface-alt-color);border:1px solid var(--border-color);border-radius:12px;padding:20px;position:relative}
.hs-card .icon{width:50px;height:50px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;color:#fff;margin-bottom:12px}
.hs-card h4{margin:0 0 5px;color:var(--card-text-color)}
.hs-card p{margin:0;color:var(--muted-text-color);font-size:.85rem}
.hs-card .badge{position:absolute;top:10px;right:10px;padding:3px 8px;border-radius:12px;font-size:.7rem;font-weight:600}
.hs-card .actions{margin-top:15px;display:flex;gap:8px}
.hs-card .status{font-size:.75rem;padding:3px 8px;border-radius:10px}
.hs-card .status.active{background:rgba(16,185,129,.2);color:#10b981}
.hs-card .status.inactive{background:rgba(239,68,68,.2);color:#ef4444}
.modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.8);z-index:9999;justify-content:center;align-items:center;padding:20px}
.modal.active{display:flex}
.modal-box{background:var(--card-bg-color);border:1px solid var(--border-color);border-radius:12px;max-width:500px;width:100%;max-height:90vh;overflow-y:auto}
.modal-head{padding:15px 20px;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center}
.modal-head h3{margin:0;color:var(--card-text-color)}
.modal-body{padding:20px}
.modal-foot{padding:15px 20px;border-top:1px solid var(--border-color);display:flex;justify-content:flex-end;gap:10px}
.close-btn{background:none;border:none;color:var(--muted-text-color);font-size:1.5rem;cursor:pointer}
.empty{text-align:center;padding:40px;color:var(--muted-text-color)}

.hero-preview{background:linear-gradient(135deg,var(--surface-alt-color),var(--card-bg-color));border:2px dashed var(--primary-alpha-03);border-radius:12px;padding:20px;text-align:center;margin-top:15px}
.hero-preview img{max-width:100%;max-height:250px;object-fit:contain;border-radius:8px}
.hero-preview .placeholder{color:var(--muted-text-color);padding:40px 20px}
.hero-preview .placeholder i{font-size:3rem;opacity:.3;margin-bottom:10px;display:block}
.hero-info{background:var(--primary-alpha-01);border:1px solid var(--primary-alpha-03);border-radius:8px;padding:12px 15px;margin-top:15px;font-size:.85rem;color:var(--accent-text-color)}
.hero-info i{margin-right:8px}

.social-card{border-radius:12px;margin-bottom:20px;overflow:hidden}
.social-card .social-header{padding:15px 20px;color:#fff;display:flex;align-items:center;gap:10px}
.social-card .social-header i{font-size:1.3rem}
.social-card .social-header h4{margin:0;font-size:1rem}
.social-card .social-body{padding:20px;background:var(--surface-alt-color)}
.social-card.google{border:2px solid #DB4437}
.social-card.google .social-header{background:#DB4437}
.social-card.discord{border:2px solid #5865F2}
.social-card.discord .social-header{background:#5865F2}
.switch-label{display:flex;align-items:center;gap:10px;cursor:pointer;margin-bottom:15px}
.switch-label input[type="checkbox"]{width:18px;height:18px}
.info-box{background:var(--primary-alpha-01);border:1px solid var(--primary-alpha-03);border-radius:8px;padding:15px;margin-top:15px}
.info-box strong{color:var(--accent-text-color)}
.info-box a{color:var(--accent-text-color)}
.copy-btn{position:absolute;right:10px;top:50%;transform:translateY(-50%);background:rgba(16,185,129,.2);border:none;color:#10b981;width:32px;height:32px;border-radius:6px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:.3s}
.copy-btn:hover{background:#10b981;color:#fff}
.redirect-input{background:rgba(243,156,18,.1)!important;border-color:rgba(243,156,18,.3)!important;padding-right:50px!important;color:#f39c12!important}
.demo-hidden-input{background:var(--surface-alt-color)!important;color:var(--muted-text-color)!important;letter-spacing:2px;cursor:not-allowed}

/* Demo Mode Styles */
.demo-banner{display:flex;align-items:center;gap:15px;background:linear-gradient(135deg,#f39c12,#e67e22);color:#fff;padding:18px 25px;border-radius:12px;margin-bottom:25px;box-shadow:0 4px 15px rgba(243,156,18,.3)}
.demo-banner i{font-size:1.8rem;animation:pulse-demo 2s infinite}
@keyframes pulse-demo{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.7;transform:scale(1.1)}}
.demo-banner-content h4{font-size:1.1rem;font-weight:700;margin-bottom:3px}
.demo-banner-content p{font-size:.85rem;opacity:.9;margin:0}

.form-disabled{opacity:.7;pointer-events:none}
.form-disabled input,.form-disabled select,.form-disabled textarea{background:var(--surface-alt-color)!important;cursor:not-allowed}
.btn-disabled{opacity:.5!important;cursor:not-allowed!important;pointer-events:none!important}
.action-disabled{opacity:.4;cursor:not-allowed;pointer-events:none}

.redirect-note{background:rgba(243,156,18,.1);border:1px solid rgba(243,156,18,.3);border-radius:8px;padding:10px 15px;margin-top:10px;font-size:.8rem;color:#f39c12}
.redirect-note i{margin-right:6px}
</style>

<?php if ($demoMode): ?>
<div class="demo-banner">
    <i class="fas fa-flask"></i>
    <div class="demo-banner-content">
        <h4>Demo Modu Aktif</h4>
        <p>Ayarları görüntüleyebilirsiniz ancak değişiklik yapamazsınız. Hassas bilgiler (API anahtarları vb.) gizlenmektedir.</p>
    </div>
</div>
<?php endif; ?>

<div class="tabs">
    <button class="tab active" data-tab="general"><i class="fas fa-cog"></i> Genel</button>
    <button class="tab" data-tab="logo"><i class="fas fa-image"></i> Logo & Görseller</button>
    <button class="tab" data-tab="homepage-services"><i class="fas fa-star"></i> Ana Sayfa Servisleri</button>
    <button class="tab" data-tab="social-login"><i class="fas fa-share-alt"></i> Sosyal Login</button>
</div>

<!-- GENEL AYARLAR -->
<div id="general" class="section active">
<form method="POST" enctype="multipart/form-data" class="<?php echo $demoMode ? 'form-disabled' : ''; ?>">
    <div class="admin-card">
        <div class="card-header"><h2><i class="fas fa-cog"></i> Genel Ayarlar</h2></div>
        <div class="card-body">
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Site Adı</label>
                    <input type="text" name="site_name" class="form-control" value="<?=clean($s['site_name'])?>" required <?php echo $demoMode ? 'disabled' : ''; ?>>
                </div>
                <div class="form-group">
                    <label class="form-label">Site Açıklaması</label>
                    <input type="text" name="site_description" class="form-control" value="<?=clean($s['site_description'])?>" <?php echo $demoMode ? 'disabled' : ''; ?>>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">E-posta</label>
                    <input type="email" name="contact_email" class="form-control" value="<?=clean($s['contact_email'])?>" <?php echo $demoMode ? 'disabled' : ''; ?>>
                </div>
                <div class="form-group">
                    <label class="form-label">Telefon</label>
                    <input type="text" name="contact_phone" class="form-control" value="<?=clean($s['contact_phone'])?>" <?php echo $demoMode ? 'disabled' : ''; ?>>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Para Birimi</label>
                    <select name="currency" class="form-control" <?php echo $demoMode ? 'disabled' : ''; ?>>
                        <option value="TRY" <?=$s['currency']==='TRY'?'selected':''?>>TRY</option>
                        <option value="USD" <?=$s['currency']==='USD'?'selected':''?>>USD</option>
                        <option value="EUR" <?=$s['currency']==='EUR'?'selected':''?>>EUR</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Sembol</label>
                    <input type="text" name="currency_symbol" class="form-control" value="<?=clean($s['currency_symbol'])?>" maxlength="5" <?php echo $demoMode ? 'disabled' : ''; ?>>
                </div>
            </div>
            <div class="form-group">
                <label style="display:flex;align-items:center;gap:10px;cursor:<?php echo $demoMode ? 'not-allowed' : 'pointer'; ?>">
                    <input type="checkbox" name="email_verification_enabled" <?=$s['email_verification_enabled']==='1'?'checked':''?> <?php echo $demoMode ? 'disabled' : ''; ?>>
                    E-posta doğrulamayı etkinleştir
                </label>
            </div>
            <hr style="border-color:rgba(255,255,255,.1);margin:20px 0">
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Servisler Başlığı</label>
                    <input type="text" name="homepage_services_title" class="form-control" value="<?=clean($s['homepage_services_title'])?>" <?php echo $demoMode ? 'disabled' : ''; ?>>
                </div>
                <div class="form-group">
                    <label class="form-label">Servisler Alt Başlığı</label>
                    <input type="text" name="homepage_services_subtitle" class="form-control" value="<?=clean($s['homepage_services_subtitle'])?>" <?php echo $demoMode ? 'disabled' : ''; ?>>
                </div>
            </div>
        </div>
    </div>
    <?php if ($demoMode): ?>
    <button type="button" class="btn btn-primary btn-disabled" disabled><i class="fas fa-lock"></i> Demo Modunda Kaydetme Kapalı</button>
    <?php else: ?>
    <button type="submit" name="save_settings" class="btn btn-primary"><i class="fas fa-save"></i> Kaydet</button>
    <?php endif; ?>
</form>
</div>

<!-- LOGO & GÖRSELLER -->
<div id="logo" class="section">
    
    <!-- Logo & Favicon -->
    <form method="POST" enctype="multipart/form-data" class="<?php echo $demoMode ? 'form-disabled' : ''; ?>">
        <div class="admin-card">
            <div class="card-header"><h2><i class="fas fa-image"></i> Logo & Favicon</h2></div>
            <div class="card-body">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Site Logosu</label>
                        <input type="file" name="site_logo" class="form-control" accept="image/*" <?php echo $demoMode ? 'disabled' : ''; ?>>
                        <?php if($s['site_logo']): ?>
                        <div class="logo-box">
                            <img src="<?=clean($s['site_logo'])?>" alt="Logo">
                            <?php if (!$demoMode): ?>
                            <button type="submit" name="delete_logo" class="btn btn-danger btn-sm" onclick="return confirm('Logo silinsin mi?')"><i class="fas fa-trash"></i></button>
                            <?php else: ?>
                            <button type="button" class="btn btn-danger btn-sm btn-disabled" disabled><i class="fas fa-lock"></i></button>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Favicon</label>
                        <input type="file" name="site_favicon" class="form-control" accept=".ico,.png,.jpg,.jpeg,.gif,.webp" <?php echo $demoMode ? 'disabled' : ''; ?>>
                        <?php if($s['site_favicon']): ?>
                        <div class="logo-box">
                            <img src="<?=clean($s['site_favicon'])?>" alt="Favicon" style="max-height:32px">
                            <?php if (!$demoMode): ?>
                            <button type="submit" name="delete_favicon" class="btn btn-danger btn-sm" onclick="return confirm('Favicon silinsin mi?')"><i class="fas fa-trash"></i></button>
                            <?php else: ?>
                            <button type="button" class="btn btn-danger btn-sm btn-disabled" disabled><i class="fas fa-lock"></i></button>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php foreach(['site_name','site_description','contact_email','contact_phone','currency','currency_symbol','homepage_services_title','homepage_services_subtitle'] as $f): ?>
        <input type="hidden" name="<?=$f?>" value="<?=clean($s[$f])?>">
        <?php endforeach; ?>
        <?php if($s['email_verification_enabled']==='1'): ?><input type="hidden" name="email_verification_enabled" value="1"><?php endif; ?>
        <?php if ($demoMode): ?>
        <button type="button" class="btn btn-primary btn-disabled" style="margin-bottom:30px" disabled><i class="fas fa-lock"></i> Demo Modunda Kaydetme Kapalı</button>
        <?php else: ?>
        <button type="submit" name="save_settings" class="btn btn-primary" style="margin-bottom:30px"><i class="fas fa-save"></i> Logo & Favicon Kaydet</button>
        <?php endif; ?>
    </form>
    
    <!-- Hero Görseli -->
    <form method="POST" enctype="multipart/form-data" class="<?php echo $demoMode ? 'form-disabled' : ''; ?>">
        <div class="admin-card">
            <div class="card-header"><h2><i class="fas fa-desktop"></i> Ana Sayfa Hero Görseli</h2></div>
            <div class="card-body">
                <div class="form-group">
                    <label class="form-label">Hero Görseli Yükle</label>
                    <input type="file" name="hero_image" class="form-control" accept=".jpg,.jpeg,.png,.gif,.webp" id="heroImageInput" <?php echo $demoMode ? 'disabled' : ''; ?>>
                    <small style="color:var(--muted-text-color);display:block;margin-top:8px">
                        Desteklenen formatlar: JPG, PNG, GIF, WebP | Maksimum boyut: 5MB
                    </small>
                </div>
                
                <div class="hero-preview" id="heroPreview">
                    <?php if(!empty($s['hero_image'])): ?>
                        <img src="<?=clean($s['hero_image'])?>" alt="Hero Görseli" id="heroPreviewImg">
                        <div style="margin-top:15px">
                            <?php if (!$demoMode): ?>
                            <button type="submit" name="delete_hero_image" class="btn btn-danger btn-sm" onclick="return confirm('Hero görseli silinsin mi?')">
                                <i class="fas fa-trash"></i> Görseli Sil
                            </button>
                            <?php else: ?>
                            <button type="button" class="btn btn-danger btn-sm btn-disabled" disabled>
                                <i class="fas fa-lock"></i> Demo Modunda Silme Kapalı
                            </button>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <img src="<?=clean(rtrim(SITE_URL, '/') . '/assets/images/default-hero-woman.webp')?>" alt="Varsayılan Hero Görseli" id="heroPreviewImg">
                        <div style="margin-top:10px;color:var(--muted-text-color);font-size:.82rem">
                            <i class="fas fa-circle-info"></i> Şu anda paketle gelen varsayılan gerçekçi insan görseli kullanılıyor.
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="hero-info">
                    <i class="fas fa-info-circle"></i>
                    <strong>Bilgi:</strong> Özel bir görsel yüklenmezse ana sayfada paketle gelen varsayılan gerçekçi insan görseli gösterilir. Yeni bir görsel yüklediğinizde varsayılan görsel otomatik olarak devreden çıkar.
                </div>
            </div>
        </div>
        <?php if ($demoMode): ?>
        <button type="button" class="btn btn-primary btn-disabled" disabled><i class="fas fa-lock"></i> Demo Modunda Kaydetme Kapalı</button>
        <?php else: ?>
        <button type="submit" name="save_hero_image" class="btn btn-primary"><i class="fas fa-save"></i> Hero Görseli Kaydet</button>
        <?php endif; ?>
    </form>
</div>

<!-- ANA SAYFA SERVİSLERİ -->
<div id="homepage-services" class="section">
    <div class="admin-card">
        <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
            <h2><i class="fas fa-star"></i> Ana Sayfa Servisleri</h2>
            <?php if ($demoMode): ?>
            <button type="button" class="btn btn-primary btn-sm btn-disabled" disabled><i class="fas fa-lock"></i> Demo Modu</button>
            <?php else: ?>
            <button type="button" class="btn btn-primary btn-sm" onclick="openModal()"><i class="fas fa-plus"></i> Ekle</button>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <?php if(empty($hServices)): ?>
            <div class="empty">
                <i class="fas fa-inbox" style="font-size:3rem;opacity:.3"></i>
                <p>Henüz servis eklenmemiş</p>
            </div>
            <?php else: ?>
            <div class="hs-grid">
                <?php foreach($hServices as $hs): ?>
                <div class="hs-card">
                    <?php if($hs['badge_text']): ?>
                    <span class="badge" style="background:<?=clean($hs['badge_color'])?>20;color:<?=clean($hs['badge_color'])?>"><?=clean($hs['badge_text'])?></span>
                    <?php endif; ?>
                    <div class="icon" style="background:<?=clean($hs['custom_icon_style'] ?: 'linear-gradient(135deg,#6366f1,#8b5cf6)')?>">
                        <i class="<?=clean($hs['custom_icon'] ?: 'fas fa-star')?>"></i>
                    </div>
                    <h4><?=clean($hs['custom_title'] ?: 'Başlıksız')?></h4>
                    <p><?=clean($hs['custom_description'] ?: '-')?></p>
                    <?php if($hs['custom_price_text']): ?><p style="color:#10b981;margin-top:5px"><?=clean($hs['custom_price_text'])?></p><?php endif; ?>
                    <div style="margin-top:10px">
                        <span class="status <?=$hs['status']?>"><?=$hs['status']==='active'?'Aktif':'Pasif'?></span>
                        <span style="color:var(--muted-text-color);font-size:.75rem;margin-left:10px">Sıra: <?=$hs['sort_order']?></span>
                    </div>
                    <div class="actions">
                        <?php if ($demoMode): ?>
                        <button type="button" class="btn btn-sm action-disabled" style="background:rgba(99,102,241,.2);color:#6366f1" disabled><i class="fas fa-lock"></i></button>
                        <button type="button" class="btn btn-danger btn-sm action-disabled" disabled><i class="fas fa-lock"></i></button>
                        <?php else: ?>
                        <button type="button" class="btn btn-sm" style="background:rgba(99,102,241,.2);color:#6366f1" onclick='editHS(<?=json_encode($hs, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT)?>)'><i class="fas fa-edit"></i></button>
                        <form method="post" style="display:inline" onsubmit="return confirm('Sil?')"><input type="hidden" name="delete_hs" value="<?=$hs['id']?>"><button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button></form>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- SOSYAL LOGIN -->
<div id="social-login" class="section">
    <form method="POST" class="<?php echo $demoMode ? 'form-disabled' : ''; ?>">
        <div class="admin-card">
            <div class="card-header">
                <h2><i class="fas fa-share-alt"></i> Sosyal Medya ile Giriş</h2>
            </div>
            <div class="card-body">
                
                <!-- GOOGLE -->
                <div class="social-card google">
                    <div class="social-header">
                        <i class="fab fa-google"></i>
                        <h4>Google Login</h4>
                    </div>
                    <div class="social-body">
                        <label class="switch-label" style="<?php echo $demoMode ? 'cursor:not-allowed' : ''; ?>">
                            <input type="checkbox" name="google[enabled]" <?=($socialSettings['google']['is_enabled'] ?? 0) ? 'checked' : ''?> <?php echo $demoMode ? 'disabled' : ''; ?>>
                            <strong>Google ile Giriş Aktif</strong>
                        </label>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Client ID</label>
                                <?php if ($demoMode): ?>
                                    <?php if (!empty($socialSettings['google']['client_id'])): ?>
                                    <input type="text" class="form-control demo-hidden-input" value="••••••••••••••••••••••••••••••••" disabled>
                                    <input type="hidden" name="google[client_id]" value="<?=htmlspecialchars($socialSettings['google']['client_id'])?>">
                                    <?php else: ?>
                                    <input type="text" class="form-control" value="Ayarlanmamış" disabled>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <input type="text" class="form-control" name="google[client_id]" value="<?=htmlspecialchars($socialSettings['google']['client_id'] ?? '')?>" placeholder="xxxxx.apps.googleusercontent.com">
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Client Secret</label>
                                <?php if ($demoMode): ?>
                                    <?php if (!empty($socialSettings['google']['client_secret'])): ?>
                                    <input type="text" class="form-control demo-hidden-input" value="••••••••••••••••••••••••••••••••" disabled>
                                    <?php else: ?>
                                    <input type="text" class="form-control" value="Ayarlanmamış" disabled>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <input type="password" class="form-control" name="google[client_secret]" value="" placeholder="Değiştirmek için yeni Client Secret girin">
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Redirect URI</label>
                            <div style="position:relative">
                                <input type="text" class="form-control redirect-input" name="google[redirect_uri]" id="google_redirect_uri" value="<?=htmlspecialchars($googleRedirectUri)?>" readonly>
                                <button type="button" class="copy-btn" onclick="copyToClipboard('google_redirect_uri')" title="Kopyala"><i class="fas fa-copy"></i></button>
                            </div>
                            <div class="redirect-note">
                                <i class="fas fa-exclamation-triangle"></i>
                                <strong>"alandiniz"</strong> kısmını kendi domain adresinizle değiştirin. Örn: <code>https://siteniz.com/auth/google/callback.php</code>
                            </div>
                        </div>
                        
                        <div class="info-box">
                            <strong><i class="fas fa-info-circle"></i> Google Kurulum:</strong><br>
                            <a href="https://console.cloud.google.com" target="_blank">console.cloud.google.com</a> → APIs & Services → Credentials → OAuth 2.0 Client ID
                        </div>
                    </div>
                </div>
                
                <!-- DISCORD -->
                <div class="social-card discord">
                    <div class="social-header">
                        <i class="fab fa-discord"></i>
                        <h4>Discord Login</h4>
                    </div>
                    <div class="social-body">
                        <label class="switch-label" style="<?php echo $demoMode ? 'cursor:not-allowed' : ''; ?>">
                            <input type="checkbox" name="discord[enabled]" <?=($socialSettings['discord']['is_enabled'] ?? 0) ? 'checked' : ''?> <?php echo $demoMode ? 'disabled' : ''; ?>>
                            <strong>Discord ile Giriş Aktif</strong>
                        </label>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Client ID</label>
                                <?php if ($demoMode): ?>
                                    <?php if (!empty($socialSettings['discord']['client_id'])): ?>
                                    <input type="text" class="form-control demo-hidden-input" value="••••••••••••••••••••••••••••••••" disabled>
                                    <input type="hidden" name="discord[client_id]" value="<?=htmlspecialchars($socialSettings['discord']['client_id'])?>">
                                    <?php else: ?>
                                    <input type="text" class="form-control" value="Ayarlanmamış" disabled>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <input type="text" class="form-control" name="discord[client_id]" value="<?=htmlspecialchars($socialSettings['discord']['client_id'] ?? '')?>" placeholder="123456789012345678">
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Client Secret</label>
                                <?php if ($demoMode): ?>
                                    <?php if (!empty($socialSettings['discord']['client_secret'])): ?>
                                    <input type="text" class="form-control demo-hidden-input" value="••••••••••••••••••••••••••••••••" disabled>
                                    <?php else: ?>
                                    <input type="text" class="form-control" value="Ayarlanmamış" disabled>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <input type="password" class="form-control" name="discord[client_secret]" value="" placeholder="Değiştirmek için yeni Client Secret girin">
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Redirect URI</label>
                            <div style="position:relative">
                                <input type="text" class="form-control redirect-input" name="discord[redirect_uri]" id="discord_redirect_uri" value="<?=htmlspecialchars($discordRedirectUri)?>" readonly>
                                <button type="button" class="copy-btn" onclick="copyToClipboard('discord_redirect_uri')" title="Kopyala"><i class="fas fa-copy"></i></button>
                            </div>
                            <div class="redirect-note">
                                <i class="fas fa-exclamation-triangle"></i>
                                <strong>"alandiniz"</strong> kısmını kendi domain adresinizle değiştirin. Örn: <code>https://siteniz.com/auth/discord/callback.php</code>
                            </div>
                        </div>
                        
                        <div class="info-box">
                            <strong><i class="fas fa-info-circle"></i> Discord Kurulum:</strong><br>
                            <a href="https://discord.com/developers/applications" target="_blank">discord.com/developers</a> → New Application → OAuth2
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
        <?php if ($demoMode): ?>
        <button type="button" class="btn btn-primary btn-disabled" disabled><i class="fas fa-lock"></i> Demo Modunda Kaydetme Kapalı</button>
        <?php else: ?>
        <button type="submit" name="save_social_login" class="btn btn-primary"><i class="fas fa-save"></i> Sosyal Login Kaydet</button>
        <?php endif; ?>
    </form>
</div>

<!-- MODAL -->
<div class="modal" id="hsModal">
    <div class="modal-box">
        <div class="modal-head">
            <h3 id="modalTitle"><i class="fas fa-plus"></i> Servis Ekle</h3>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="hs_id" id="hs_id" value="0">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Başlık *</label>
                    <input type="text" name="custom_title" id="f_title" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Açıklama</label>
                    <textarea name="custom_description" id="f_desc" class="form-control" rows="2"></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">İkon</label>
                        <input type="text" name="custom_icon" id="f_icon" class="form-control" value="fas fa-star">
                    </div>
                    <div class="form-group">
                        <label class="form-label">İkon Stili</label>
                        <input type="text" name="custom_icon_style" id="f_style" class="form-control" value="linear-gradient(135deg, #6366f1, #8b5cf6)">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Fiyat Metni</label>
                    <input type="text" name="custom_price_text" id="f_price" class="form-control" placeholder="örn: 0.50₺'den başlayan">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Badge</label>
                        <input type="text" name="badge_text" id="f_badge" class="form-control" placeholder="Popüler">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Badge Renk</label>
                        <input type="color" name="badge_color" id="f_color" class="form-control" value="#ff6b6b" style="height:42px">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Sıra</label>
                        <input type="number" name="sort_order" id="f_sort" class="form-control" value="0">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Durum</label>
                        <select name="status" id="f_status" class="form-control">
                            <option value="active">Aktif</option>
                            <option value="inactive">Pasif</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-foot">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">İptal</button>
                <button type="submit" name="save_homepage_service" class="btn btn-primary"><i class="fas fa-save"></i> Kaydet</button>
            </div>
        </form>
    </div>
</div>

<script>
const demoMode = <?php echo $demoMode ? 'true' : 'false'; ?>;

// Tab
document.querySelectorAll('.tab').forEach(t => {
    t.onclick = function() {
        document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
        document.querySelectorAll('.section').forEach(x => x.classList.remove('active'));
        this.classList.add('active');
        document.getElementById(this.dataset.tab).classList.add('active');
        history.replaceState(null, null, '#' + this.dataset.tab);
    };
});
if(location.hash) document.querySelector('.tab[data-tab="'+location.hash.slice(1)+'"]')?.click();

// Modal
function openModal() {
    if (demoMode) {
        alert('Demo modunda bu işlem yapılamaz.');
        return;
    }
    document.getElementById('modalTitle').innerHTML = '<i class="fas fa-plus"></i> Servis Ekle';
    document.getElementById('hs_id').value = 0;
    document.getElementById('f_title').value = '';
    document.getElementById('f_desc').value = '';
    document.getElementById('f_icon').value = 'fas fa-star';
    document.getElementById('f_style').value = 'linear-gradient(135deg, #6366f1, #8b5cf6)';
    document.getElementById('f_price').value = '';
    document.getElementById('f_badge').value = '';
    document.getElementById('f_color').value = '#ff6b6b';
    document.getElementById('f_sort').value = 0;
    document.getElementById('f_status').value = 'active';
    document.getElementById('hsModal').classList.add('active');
}

function editHS(d) {
    if (demoMode) {
        alert('Demo modunda bu işlem yapılamaz.');
        return;
    }
    document.getElementById('modalTitle').innerHTML = '<i class="fas fa-edit"></i> Düzenle';
    document.getElementById('hs_id').value = d.id;
    document.getElementById('f_title').value = d.custom_title || '';
    document.getElementById('f_desc').value = d.custom_description || '';
    document.getElementById('f_icon').value = d.custom_icon || 'fas fa-star';
    document.getElementById('f_style').value = d.custom_icon_style || '';
    document.getElementById('f_price').value = d.custom_price_text || '';
    document.getElementById('f_badge').value = d.badge_text || '';
    document.getElementById('f_color').value = d.badge_color || '#ff6b6b';
    document.getElementById('f_sort').value = d.sort_order || 0;
    document.getElementById('f_status').value = d.status || 'active';
    document.getElementById('hsModal').classList.add('active');
}

function closeModal() { document.getElementById('hsModal').classList.remove('active'); }
document.getElementById('hsModal').onclick = e => { if(e.target.id === 'hsModal') closeModal(); };
document.onkeydown = e => { if(e.key === 'Escape') closeModal(); };

// Kopyala
function copyToClipboard(id) {
    const input = document.getElementById(id);
    input.select();
    navigator.clipboard.writeText(input.value).then(() => {
        const btn = input.parentElement.querySelector('.copy-btn');
        btn.innerHTML = '<i class="fas fa-check"></i>';
        btn.style.background = '#10b981';
        setTimeout(() => { btn.innerHTML = '<i class="fas fa-copy"></i>'; btn.style.background = ''; }, 2000);
    });
}

// Hero görsel önizleme
document.getElementById('heroImageInput')?.addEventListener('change', function(e) {
    if (demoMode) return;
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const preview = document.getElementById('heroPreview');
            preview.innerHTML = '<img src="' + e.target.result + '" alt="Önizleme" style="max-width:100%;max-height:250px;border-radius:8px"><p style="margin-top:10px;color:#10b981;font-size:.85rem"><i class="fas fa-check-circle"></i> Görsel seçildi - Kaydetmek için butona tıklayın</p>';
        };
        reader.readAsDataURL(file);
    }
});

// Demo modda form gönderimini engelle
if (demoMode) {
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Demo modunda ayarlar değiştirilemez.');
            return false;
        });
    });
}
</script>

</main>
</body>
</html>