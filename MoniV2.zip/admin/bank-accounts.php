<?php
/**
 * Admin Panel - Banka Hesapları Yönetimi
 */

require_once __DIR__ . '/../config.php';

$success = '';
$error = '';

// Banka hesabı ekle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_bank'])) {
    $bankName = trim($_POST['bank_name']);
    $accountHolder = trim($_POST['account_holder']);
    $iban = trim($_POST['iban']);
    $status = $_POST['status'] ?? 'active';
    
    if (empty($bankName) || empty($accountHolder) || empty($iban)) {
        $error = 'Tüm alanları doldurun!';
    } else {
        $stmt = $db->prepare("INSERT INTO bank_accounts (bank_name, account_holder, iban, status, sort_order) VALUES (?, ?, ?, ?, (SELECT IFNULL(MAX(so), 0) + 1 FROM (SELECT sort_order as so FROM bank_accounts) as ba))");
        $stmt->execute([$bankName, $accountHolder, $iban, $status]);
        $success = 'Banka hesabı eklendi!';
    }
}

// Banka hesabı güncelle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_bank'])) {
    $bankId = (int)$_POST['bank_id'];
    $bankName = trim($_POST['bank_name']);
    $accountHolder = trim($_POST['account_holder']);
    $iban = trim($_POST['iban']);
    $status = $_POST['status'] ?? 'active';
    
    if (empty($bankName) || empty($accountHolder) || empty($iban)) {
        $error = 'Tüm alanları doldurun!';
    } else {
        $stmt = $db->prepare("UPDATE bank_accounts SET bank_name = ?, account_holder = ?, iban = ?, status = ? WHERE id = ?");
        $stmt->execute([$bankName, $accountHolder, $iban, $status, $bankId]);
        $success = 'Banka hesabı güncellendi!';
    }
}

// Banka hesabı sil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_bank'])) {
    $bankId = (int)$_POST['bank_id'];
    $db->prepare("DELETE FROM bank_accounts WHERE id = ?")->execute([$bankId]);
    $success = 'Banka hesabı silindi!';
}

// Banka hesaplarını getir
$bankAccounts = $db->query("SELECT * FROM bank_accounts ORDER BY sort_order ASC")->fetchAll();

$pageTitle = "Banka Hesapları";
require_once 'header.php';
?>

<style>
.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
    flex-wrap: wrap;
    gap: 15px;
}

.bank-cards {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
    gap: 20px;
}

@media (max-width: 576px) {
    .bank-cards { grid-template-columns: 1fr; }
}

.bank-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    overflow: hidden;
    transition: all 0.3s ease;
}

.bank-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 40px rgba(0,0,0,0.1);
}

.bank-card-header {
    padding: 20px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--on-accent-color);
    display: flex;
    align-items: center;
    gap: 15px;
}

.bank-card-header .icon {
    width: 50px;
    height: 50px;
    background: rgba(255,255,255,0.2);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
}

.bank-card-header .info h3 { font-size: 1.1rem; font-weight: 600; }
.bank-card-header .info span { font-size: 0.85rem; opacity: 0.8; }

.bank-card-body { padding: 20px; }

.bank-detail {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 0;
    border-bottom: 1px solid var(--border-color);
}

.bank-detail:last-child { border-bottom: none; }
.bank-detail .label { font-size: 0.85rem; opacity: 0.6; }
.bank-detail .value { font-weight: 600; font-size: 0.9rem; }

.bank-card-footer {
    padding: 15px 20px;
    background: var(--background-color);
    display: flex;
    gap: 10px;
    justify-content: flex-end;
}

.bank-card-footer .btn { padding: 8px 16px; font-size: 0.85rem; }

.status-active { color: #28a745; }
.status-inactive { color: var(--muted-text-color); }

/* Modal */
.modal-overlay {
    display: none;
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.7);
    z-index: 2000;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.modal-overlay.active { display: flex; }

.modal-box {
    background: var(--card-bg-color);
    border-radius: 20px;
    width: 100%;
    max-width: 500px;
    max-height: 90vh;
    overflow-y: auto;
    animation: modalSlide 0.3s ease;
}

@keyframes modalSlide {
    from { opacity: 0; transform: translateY(-30px); }
    to { opacity: 1; transform: translateY(0); }
}

.modal-header {
    padding: 25px;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h3 { font-size: 1.1rem; font-weight: 600; display: flex; align-items: center; gap: 10px; }

.modal-close {
    background: var(--background-color);
    border: none;
    width: 40px;
    height: 40px;
    border-radius: 10px;
    cursor: pointer;
    font-size: 1.2rem;
    color: var(--text-color);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
}

.modal-close:hover { background: var(--danger-color); color: var(--on-danger-color); }

.modal-body { padding: 25px; }

.form-group { margin-bottom: 20px; }
.form-label { display: block; margin-bottom: 8px; font-weight: 500; font-size: 0.9rem; }

.form-control {
    width: 100%;
    padding: 14px 18px;
    border: 2px solid var(--border-color);
    border-radius: 12px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 0.95rem;
    transition: all 0.3s ease;
}

.form-control:focus {
    outline: none;
    border-color: var(--accent-text-color);
}

.modal-footer {
    padding: 20px 25px;
    border-top: 1px solid var(--border-color);
    display: flex;
    gap: 15px;
}

.modal-footer .btn { flex: 1; padding: 14px; justify-content: center; }

.empty-state {
    text-align: center;
    padding: 80px 20px;
}

.empty-state i { font-size: 4rem; margin-bottom: 20px; opacity: 0.2; color: var(--accent-text-color); }
.empty-state h3 { font-size: 1.2rem; margin-bottom: 10px; opacity: 0.8; }
.empty-state p { opacity: 0.5; }
</style>

<?php if ($success): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
<?php endif; ?>

<div class="page-header">
    <h2 style="font-size: 1.5rem; font-weight: 600;"><i class="fas fa-university" style="color: var(--accent-text-color); margin-right: 10px;"></i> Banka Hesapları</h2>
    <button type="button" class="btn btn-primary" onclick="openModal('addModal')"><i class="fas fa-plus"></i> Yeni Hesap Ekle</button>
</div>

<?php if (empty($bankAccounts)): ?>
    <div class="admin-card">
        <div class="card-body">
            <div class="empty-state">
                <i class="fas fa-university"></i>
                <h3>Banka Hesabı Yok</h3>
                <p>Henüz banka hesabı eklenmemiş.</p>
                <button type="button" class="btn btn-primary" onclick="openModal('addModal')" style="margin-top: 20px;"><i class="fas fa-plus"></i> İlk Hesabı Ekle</button>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="bank-cards">
        <?php foreach ($bankAccounts as $bank): ?>
            <div class="bank-card">
                <div class="bank-card-header">
                    <div class="icon"><i class="fas fa-university"></i></div>
                    <div class="info">
                        <h3><?php echo clean($bank['bank_name']); ?></h3>
                        <span class="status-<?php echo $bank['status']; ?>">
                            <i class="fas fa-circle" style="font-size: 0.5rem;"></i>
                            <?php echo $bank['status'] === 'active' ? 'Aktif' : 'Pasif'; ?>
                        </span>
                    </div>
                </div>
                <div class="bank-card-body">
                    <div class="bank-detail">
                        <span class="label">Hesap Sahibi</span>
                        <span class="value"><?php echo clean($bank['account_holder']); ?></span>
                    </div>
                    <div class="bank-detail">
                        <span class="label">IBAN</span>
                        <span class="value" style="font-family: monospace; font-size: 0.85rem;"><?php echo clean($bank['iban']); ?></span>
                    </div>
                </div>
                <div class="bank-card-footer">
                    <button type="button" class="btn btn-secondary" onclick='editBank(<?php echo json_encode($bank, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'><i class="fas fa-edit"></i> Düzenle</button>
                    <form method="POST" style="display: inline;" onsubmit="return confirm('Bu hesabı silmek istediğinize emin misiniz?');">
                        <input type="hidden" name="bank_id" value="<?php echo $bank['id']; ?>">
                        <button type="submit" name="delete_bank" class="btn btn-danger"><i class="fas fa-trash"></i></button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<!-- Add Modal -->
<div class="modal-overlay" id="addModal">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fas fa-plus-circle" style="color: var(--accent-text-color);"></i> Yeni Banka Hesabı</h3>
            <button type="button" class="modal-close" onclick="closeModal('addModal')">&times;</button>
        </div>
        <form method="POST">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Banka Adı *</label>
                    <input type="text" name="bank_name" class="form-control" placeholder="Örn: Ziraat Bankası" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Hesap Sahibi *</label>
                    <input type="text" name="account_holder" class="form-control" placeholder="Ad Soyad" required>
                </div>
                <div class="form-group">
                    <label class="form-label">IBAN *</label>
                    <input type="text" name="iban" class="form-control" placeholder="TR00 0000 0000 0000 0000 0000 00" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Durum</label>
                    <select name="status" class="form-control">
                        <option value="active">Aktif</option>
                        <option value="inactive">Pasif</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('addModal')">İptal</button>
                <button type="submit" name="add_bank" class="btn btn-primary"><i class="fas fa-plus"></i> Ekle</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="editModal">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fas fa-edit" style="color: var(--accent-text-color);"></i> Banka Hesabını Düzenle</h3>
            <button type="button" class="modal-close" onclick="closeModal('editModal')">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="bank_id" id="editBankId">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Banka Adı *</label>
                    <input type="text" name="bank_name" id="editBankName" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Hesap Sahibi *</label>
                    <input type="text" name="account_holder" id="editAccountHolder" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">IBAN *</label>
                    <input type="text" name="iban" id="editIban" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Durum</label>
                    <select name="status" id="editStatus" class="form-control">
                        <option value="active">Aktif</option>
                        <option value="inactive">Pasif</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('editModal')">İptal</button>
                <button type="submit" name="update_bank" class="btn btn-primary"><i class="fas fa-save"></i> Kaydet</button>
            </div>
        </form>
    </div>
</div>

<script>
// Modal fonksiyonları
function openModal(modalId) {
    document.getElementById(modalId).classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
    document.body.style.overflow = '';
}

// Modal dışına tıklayınca kapat
document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) {
            this.classList.remove('active');
            document.body.style.overflow = '';
        }
    });
});

// ESC tuşu ile kapat
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(modal => {
            modal.classList.remove('active');
        });
        document.body.style.overflow = '';
    }
});

// Banka düzenleme
function editBank(bank) {
    document.getElementById('editBankId').value = bank.id;
    document.getElementById('editBankName').value = bank.bank_name;
    document.getElementById('editAccountHolder').value = bank.account_holder;
    document.getElementById('editIban').value = bank.iban;
    document.getElementById('editStatus').value = bank.status;
    openModal('editModal');
}

// Sidebar toggle (header.php için)
function toggleSidebar() {
    const sidebar = document.getElementById('adminSidebar');
    const body = document.body;
    
    if (window.innerWidth <= 992) {
        sidebar.classList.toggle('mobile-open');
    } else {
        sidebar.classList.toggle('collapsed');
        body.classList.toggle('sidebar-collapsed');
    }
}
</script>

<?php require_once 'footer.php'; ?>