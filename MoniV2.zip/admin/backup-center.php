<?php
require_once __DIR__.'/../config.php';
require_once __DIR__.'/../includes/MoniAdminUI.php';
require_once __DIR__.'/../includes/MoniV2Compat.php';
if(!isLoggedIn()||!isAdmin()){header('Location:/admin/');exit;}
if(function_exists('moni_staff_can')&&!moni_staff_can($db,'backups.manage')){http_response_code(403);exit('Yetkiniz yok.');}
$msg='';$err='';

function backup_superadmin_password(PDO $db,string $password): void {
    if(!function_exists('moni_is_super_admin')||!moni_is_super_admin($db))throw new RuntimeException('Bu kritik işlem yalnız Süper Admin tarafından yapılabilir.');
    $s=$db->prepare("SELECT password FROM users WHERE id=?");$s->execute([(int)$_SESSION['user_id']]);
    if(!password_verify($password,(string)$s->fetchColumn()))throw new RuntimeException('Admin parolası doğrulanamadı.');
}

if(isset($_GET['download'])){
    $id=(int)$_GET['download'];$s=$db->prepare("SELECT * FROM backup_records WHERE id=? AND status='completed'");$s->execute([$id]);$r=$s->fetch(PDO::FETCH_ASSOC);
    if(!$r){http_response_code(404);exit('Yedek bulunamadı.');}
    $f=moni_backup_dir().'/'.basename($r['file_name']);
    if(!is_file($f)||!hash_equals((string)$r['sha256'],hash_file('sha256',$f))){http_response_code(409);exit('Yedek bütünlüğü doğrulanamadı.');}
    header('Content-Type: application/zip');header('Content-Disposition: attachment; filename="'.basename($f).'"');header('Content-Length: '.filesize($f));readfile($f);exit;
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        $a=$_POST['action']??'';
        if($a==='create'){
            $r=moni_backup_create($db,(int)$_SESSION['user_id'],!empty($_POST['include_uploads']));
            $r['ok']?$msg='Yedek başarıyla oluşturuldu. Kurtarma anahtarınızı ayrıca güvenli yerde saklayın.':$err=$r['error'];
        }elseif($a==='settings'){
            updateSetting('backup_include_uploads',!empty($_POST['backup_include_uploads'])?'1':'0');
            updateSetting('backup_retention_count',(string)max(1,min(90,(int)$_POST['backup_retention_count'])));$msg='Yedekleme ayarları kaydedildi.';
        }elseif($a==='delete'){
            $id=(int)$_POST['id'];$s=$db->prepare("SELECT file_name FROM backup_records WHERE id=?");$s->execute([$id]);$f=$s->fetchColumn();
            if($f)@unlink(moni_backup_dir().'/'.basename($f));$db->prepare("UPDATE backup_records SET status='deleted',deleted_at=NOW() WHERE id=?")->execute([$id]);$msg='Yedek silindi.';
        }elseif($a==='export_key'){
            backup_superadmin_password($db,(string)($_POST['password']??''));
            if(trim((string)($_POST['confirm_text']??''))!=='ANAHTARI DISA AKTAR')throw new RuntimeException('Onay metni hatalı.');
            $key=bin2hex(moni_secret_key());$fp=moni_secret_key_fingerprint();
            $body="MONI RECOVERY KEY\n\nKey: $key\nFingerprint: $fp\nCreated: ".date(DATE_ATOM)."\n\nBu dosyayı backup ZIP dosyasından AYRI ve güvenli bir yerde saklayın.\n";
            header('Content-Type: text/plain; charset=utf-8');header('Content-Disposition: attachment; filename="moni-recovery-key-'.date('Ymd_His').'.txt"');header('Cache-Control: no-store');echo $body;exit;
        }elseif($a==='import_key'){
            backup_superadmin_password($db,(string)($_POST['password']??''));
            if(trim((string)($_POST['confirm_text']??''))!=='ANAHTARI ICE AKTAR')throw new RuntimeException('Onay metni hatalı.');
            $raw=trim((string)($_POST['recovery_key']??''));
            if(preg_match('/Key:\s*([a-fA-F0-9]{64})/',$raw,$m))$raw=$m[1];
            $r=moni_install_secret_key_hex($raw);if(empty($r['ok']))throw new RuntimeException($r['error']??'Anahtar yazılamadı.');
            $msg='Kurtarma anahtarı içe aktarıldı. Şimdi bu anahtara ait yedeği geri yükleyebilirsiniz.';
        }elseif($a==='restore'){
            backup_superadmin_password($db,(string)($_POST['password']??''));
            if(trim((string)($_POST['confirm_text']??''))!=='GERI YUKLE')throw new RuntimeException('Onay metni hatalı.');
            $r=moni_backup_restore($db,(int)$_POST['id']);if(!$r['ok'])throw new RuntimeException($r['error']);session_regenerate_id(true);$msg='Yedek geri yüklendi. Sayfaları yeniden kontrol edin.';
        }
    }catch(Throwable $e){$err=$e->getMessage();}
}

$rows=$db->query("SELECT b.*,u.username FROM backup_records b LEFT JOIN users u ON u.id=b.created_by ORDER BY b.id DESC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
$currentFingerprint='';try{$currentFingerprint=moni_secret_key_fingerprint();}catch(Throwable $e){$err=$err?:$e->getMessage();}
$pageTitle='Otomatik Yedekleme ve Geri Yükleme';require 'header.php';echo moni_admin_ui_styles();
?>
<div class="moni-page">
 <div class="moni-hero"><div><span class="moni-kicker"><i class="fas fa-database"></i> Disaster Recovery</span><h2>Yedekleme ve Geri Yükleme Merkezi</h2><p>Veritabanı ve isteğe bağlı uploads arşivi; SHA-256 bütünlük kontrolü, şifreleme anahtarı fingerprint doğrulaması, saklama politikası ve cron tabanlı otomatik yedekleme. Gerçek kurtarma anahtarı ZIP içine eklenmez.</p></div><form method="post"><input type="hidden" name="action" value="create"><input type="hidden" name="include_uploads" value="1"><button class="moni-btn"><i class="fas fa-plus"></i> Şimdi Yedekle</button></form></div>
 <?php if($msg):?><div class="moni-alert success"><?=clean($msg)?></div><?php endif;?><?php if($err):?><div class="moni-alert danger"><?=clean($err)?></div><?php endif;?>
 <div class="moni-grid">
  <section class="moni-card"><h3>Otomatik Yedek Ayarları</h3><form method="post" class="moni-form-grid"><input type="hidden" name="action" value="settings"><label class="moni-check"><input type="checkbox" name="backup_include_uploads" value="1" <?=getSetting('backup_include_uploads','1')==='1'?'checked':''?>> Uploads klasörünü dahil et</label><div class="moni-field"><label>Saklanacak yedek sayısı</label><input type="number" min="1" max="90" name="backup_retention_count" value="<?=clean(getSetting('backup_retention_count','10'))?>"></div><div class="moni-field full"><button class="moni-btn">Kaydet</button></div></form></section>
  <section class="moni-card"><div class="moni-help"><i class="fas fa-triangle-exclamation"></i><span><strong>Geri yükleme tüm veritabanını yedek anına döndürür.</strong> Restore yalnız Süper Admin + parola + açık onayla çalışır. Şifreli API/SMTP/TOTP sırlarının açılabilmesi için yedekle aynı Kurtarma Anahtarı gerekir.</span></div></section>
  <?php if(function_exists('moni_is_super_admin')&&moni_is_super_admin($db)):?>
  <section class="moni-card full"><h3><i class="fas fa-key"></i> Şifreleme Kurtarma Anahtarı</h3><p>Fingerprint: <code><?=clean($currentFingerprint?:'oluşturulamadı')?></code></p><div class="moni-grid">
    <form method="post" class="moni-form-grid"><input type="hidden" name="action" value="export_key"><div class="moni-field"><label>Admin parolası</label><input type="password" name="password" required></div><div class="moni-field"><label>Onay</label><input name="confirm_text" placeholder="ANAHTARI DISA AKTAR" required></div><div class="moni-field full"><button class="moni-btn"><i class="fas fa-download"></i> Kurtarma Anahtarını Dışa Aktar</button></div></form>
    <form method="post" class="moni-form-grid"><input type="hidden" name="action" value="import_key"><div class="moni-field full"><label>Kurtarma anahtarı veya dışa aktarılan dosyanın içeriği</label><textarea name="recovery_key" rows="4" required></textarea></div><div class="moni-field"><label>Admin parolası</label><input type="password" name="password" required></div><div class="moni-field"><label>Onay</label><input name="confirm_text" placeholder="ANAHTARI ICE AKTAR" required></div><div class="moni-field full"><button class="moni-btn warning" onclick="return confirm('Aktif şifreleme anahtarı değişecek. Bu işlemi yalnız restore öncesinde doğru anahtarla yapın. Devam?')"><i class="fas fa-upload"></i> Kurtarma Anahtarını İçe Aktar</button></div></form>
  </div></section>
  <?php endif;?>
  <section class="moni-card full"><div class="moni-table-wrap"><table class="moni-table"><thead><tr><th>Tarih</th><th>Dosya</th><th>Boyut</th><th>SHA-256</th><th>Oluşturan</th><th>Durum</th><th>İşlem</th></tr></thead><tbody>
  <?php foreach($rows as $r):?><tr><td><?=clean($r['created_at'])?></td><td><?=clean($r['file_name'])?></td><td><?=number_format((int)$r['file_size']/1048576,2)?> MB</td><td><code><?=clean(substr((string)$r['sha256'],0,12))?>…</code></td><td><?=clean($r['username']??'Cron')?></td><td><span class="moni-badge <?=$r['status']==='completed'?'ok':($r['status']==='failed'?'danger':'off')?>"><?=clean($r['status'])?></span></td><td><?php if($r['status']==='completed'):?><div class="moni-actions"><a class="moni-btn secondary sm" href="?download=<?=$r['id']?>"><i class="fas fa-download"></i></a><?php if(function_exists('moni_is_super_admin')&&moni_is_super_admin($db)):?><details><summary class="moni-btn warning sm" style="list-style:none">Geri Yükle</summary><form method="post" style="min-width:250px;padding:10px"><input type="hidden" name="action" value="restore"><input type="hidden" name="id" value="<?=$r['id']?>"><div class="moni-field"><input type="password" name="password" placeholder="Admin parolası" required></div><div class="moni-field"><input name="confirm_text" placeholder="GERI YUKLE" required></div><button class="moni-btn danger sm" onclick="return confirm('Tüm veritabanı geri yüklenecek. Emin misiniz?')">Onayla</button></form></details><?php endif;?><form method="post"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="moni-btn danger sm" onclick="return confirm('Yedek silinsin mi?')"><i class="fas fa-trash"></i></button></form></div><?php endif;?></td></tr><?php endforeach;?>
  </tbody></table></div></section>
 </div>
</div>
<?php require 'footer.php';?>
