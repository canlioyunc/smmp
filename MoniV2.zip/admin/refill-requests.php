<?php
/**
 * Admin Panel - Refill Talepleri Yönetimi
 * Türkiye Saat Dilimi: Europe/Istanbul
 */

$pageTitle = 'Refill Talepleri';
require_once 'header.php';

// Türkiye saat dilimi
date_default_timezone_set('Europe/Istanbul');
$db->exec("SET time_zone = '+03:00'");

// İşlem mesajları
$success = '';
$error = '';

// Refill talebini işle. Sağlayıcı HTTP çağrısı DB transaction dışında yapılır.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $refillId = (int)($_POST['refill_id'] ?? 0);
    $action = (string)($_POST['action'] ?? '');
    $loadRefill = static function(PDO $db, int $id, bool $lock = false): ?array {
        $sql = "SELECT r.*, o.user_id AS order_user_id, o.service_id, o.link, o.quantity AS order_quantity,
                       o.api_provider_id, s.api_service_id, s.name AS service_name, s.price_per_1000,
                       u.username, u.email
                FROM refill_requests r
                JOIN orders o ON r.order_id=o.id
                JOIN services s ON o.service_id=s.id
                JOIN users u ON r.user_id=u.id
                WHERE r.id=?" . ($lock ? " FOR UPDATE" : "");
        $st=$db->prepare($sql);$st->execute([$id]);$row=$st->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    };

    if ($refillId <= 0) {
        $error='Geçersiz refill talebi.';
    } elseif ($action === 'approve') {
        $newOrderId=0;$refill=null;
        try {
            // Yerel siparişi ve processing durumunu atomik oluştur; sonra DB kilidini bırak.
            $db->beginTransaction();
            $refill=$loadRefill($db,$refillId,true);
            if(!$refill) throw new RuntimeException('Refill talebi bulunamadı!');
            if($refill['status']!=='pending') throw new RuntimeException('Bu talep zaten işlenmiş!');
            $nowTurkey=date('Y-m-d H:i:s');
            $ins=$db->prepare("INSERT INTO orders(user_id,service_id,api_provider_id,link,quantity,price,status,refill_enabled,refill_max,refill_used,created_at) VALUES(?,?,?,?,?,0,'pending',0,0,0,?)");
            $ins->execute([$refill['user_id'],$refill['service_id'],$refill['api_provider_id'],$refill['link'],$refill['quantity'],$nowTurkey]);
            $newOrderId=(int)$db->lastInsertId();
            $db->prepare("UPDATE refill_requests SET status='processing',processed_by=?,new_order_id=?,admin_note=? WHERE id=? AND status='pending'")
               ->execute([$_SESSION['user_id'],$newOrderId,'Sağlayıcıya gönderiliyor',$refillId]);
            $db->commit();

            $provider=moni_provider_by_id($db,(int)$refill['api_provider_id']);
            if(!$provider || ($provider['status']??'')!=='active') {
                $api=['success'=>false,'error'=>'API sağlayıcı bulunamadı veya pasif'];
            } elseif(empty($refill['api_service_id'])) {
                $api=['success'=>false,'error'=>'Servis API kimliği eksik'];
            } else {
                $api=moni_provider_request($provider,[
                    'action'=>'add','service'=>$refill['api_service_id'],'link'=>$refill['link'],'quantity'=>(int)$refill['quantity']
                ],'add',60);
            }

            // Sonucu yeniden kilitleyerek tek kez uygula.
            $db->beginTransaction();
            $locked=$loadRefill($db,$refillId,true);
            if(!$locked || $locked['status']!=='processing') throw new RuntimeException('Refill talebinin durumu başka bir işlem tarafından değiştirildi.');
            if(!empty($api['success']) && !empty($api['data']['order'])) {
                $apiOrderId=(string)$api['data']['order'];
                $db->prepare("UPDATE orders SET api_order_id=?,api_response=?,status='processing',updated_at=NOW() WHERE id=?")
                   ->execute([$apiOrderId,$api['raw']??json_encode($api['data']),$newOrderId]);
                $db->prepare("UPDATE refill_requests SET status='completed',processed_at=NOW(),api_refill_id=?,admin_note=? WHERE id=? AND status='processing'")
                   ->execute([$apiOrderId,'Onaylandı - API Order ID: '.$apiOrderId,$refillId]);
                $db->commit();
                $success='Refill talebi onaylandı! Yeni sipariş #'.$newOrderId.' oluşturuldu. (API: '.$apiOrderId.')';
            } else {
                $apiError=(string)($api['error']??'Bilinmeyen API hatası');
                // Belirsiz add sonucunda sağlayıcı siparişi almış olabilir: hakkı otomatik geri verme.
                if(!empty($api['ambiguous'])) {
                    $db->prepare("UPDATE orders SET status='pending',admin_note=CONCAT(IFNULL(admin_note,''),?),updated_at=NOW() WHERE id=?")
                       ->execute(["
Sağlayıcı sonucu belirsiz; manuel kontrol gerekli. ".$apiError,$newOrderId]);
                    $db->prepare("UPDATE refill_requests SET status='error',processed_at=NOW(),admin_note=? WHERE id=? AND status='processing'")
                       ->execute(['Belirsiz sağlayıcı sonucu - manuel kontrol gerekli: '.$apiError,$refillId]);
                    $db->commit();
                    $error='Sağlayıcı sonucu belirsiz. Refill hakkı otomatik iade edilmedi; manuel kontrol gerekli. '.$apiError;
                } else {
                    $db->prepare("UPDATE orders SET status='error',updated_at=NOW() WHERE id=?")->execute([$newOrderId]);
                    $db->prepare("UPDATE refill_requests SET status='error',processed_at=NOW(),admin_note=? WHERE id=? AND status='processing'")
                       ->execute(['API Hatası: '.$apiError,$refillId]);
                    $db->prepare("UPDATE orders SET refill_used=GREATEST(0,refill_used-1) WHERE id=?")->execute([$refill['order_id']]);
                    $db->commit();
                    $error='API hatası: '.$apiError.' - Refill hakkı iade edildi.';
                }
            }
        } catch (Throwable $e) {
            if($db->inTransaction())$db->rollBack();
            $error='Hata: '.$e->getMessage();
        }
    } elseif ($action === 'reject') {
        try {
            $db->beginTransaction();
            $refill=$loadRefill($db,$refillId,true);
            if(!$refill) throw new RuntimeException('Refill talebi bulunamadı!');
            if($refill['status']!=='pending') throw new RuntimeException('Bu talep zaten işlenmiş!');
            $reason=trim((string)($_POST['reject_reason']??''));
            $db->prepare("UPDATE refill_requests SET status='rejected',processed_at=NOW(),processed_by=?,admin_note=? WHERE id=? AND status='pending'")
               ->execute([$_SESSION['user_id'],$reason?:'Reddedildi',$refillId]);
            $db->prepare("UPDATE orders SET refill_used=GREATEST(0,refill_used-1) WHERE id=?")->execute([$refill['order_id']]);
            $db->commit();
            $success='Refill talebi reddedildi. Refill hakkı kullanıcıya iade edildi.';
        } catch(Throwable $e) {
            if($db->inTransaction())$db->rollBack();
            $error='Hata: '.$e->getMessage();
        }
    } else {
        $error='Geçersiz işlem.';
    }
}

// Filtreler
$statusFilter = $_GET['status'] ?? 'pending';
$search = trim($_GET['search'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

// Sorgu oluştur
$whereConditions = [];
$params = [];

if ($statusFilter && $statusFilter !== 'all') {
    $whereConditions[] = "r.status = ?";
    $params[] = $statusFilter;
}

if ($search) {
    $whereConditions[] = "(u.username LIKE ? OR u.email LIKE ? OR o.link LIKE ? OR o.id = ?)";
    $searchParam = '%' . $search . '%';
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = (int)$search;
}

$whereSQL = $whereConditions ? 'WHERE ' . implode(' AND ', $whereConditions) : '';

// Toplam sayı
$countSQL = "
    SELECT COUNT(*) 
    FROM refill_requests r
    JOIN orders o ON r.order_id = o.id
    JOIN users u ON r.user_id = u.id
    $whereSQL
";
$stmt = $db->prepare($countSQL);
$stmt->execute($params);
$totalRequests = $stmt->fetchColumn();
$totalPages = ceil($totalRequests / $perPage);

// Refill taleplerini al
$sql = "
    SELECT r.*, 
           o.id as orig_order_id, o.link, o.quantity as order_quantity, o.price as original_price, o.status as order_status,
           o.refill_enabled, o.refill_max, o.refill_used, o.refill_until, o.created_at as order_date,
           s.name as service_name, s.price_per_1000,
           u.username, u.email,
           admin.username as processed_by_name
    FROM refill_requests r
    JOIN orders o ON r.order_id = o.id
    JOIN services s ON o.service_id = s.id
    JOIN users u ON r.user_id = u.id
    LEFT JOIN users admin ON r.processed_by = admin.id
    $whereSQL
    ORDER BY 
        CASE r.status WHEN 'pending' THEN 0 ELSE 1 END,
        r.created_at DESC
    LIMIT $perPage OFFSET $offset
";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$requests = $stmt->fetchAll();

// İstatistikler
$stats = $db->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'processing' THEN 1 ELSE 0 END) as processing,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
        SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected,
        SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as error
    FROM refill_requests
")->fetch();
?>

<style>
.stats-row{display:grid;grid-template-columns:repeat(5,1fr);gap:15px;margin-bottom:25px}
@media(max-width:992px){.stats-row{grid-template-columns:repeat(3,1fr)}}
@media(max-width:576px){.stats-row{grid-template-columns:repeat(2,1fr)}}
.stat-box{background:var(--card-bg-color);border:1px solid var(--border-color);border-radius:12px;padding:20px;text-align:center;text-decoration:none;color:inherit;transition:all .3s ease}
.stat-box:hover{border-color:var(--accent-text-color);transform:translateY(-2px)}
.stat-box.active{border-color:var(--accent-text-color);background:var(--primary-alpha-01)}
.stat-box h3{font-size:1.8rem;font-weight:700;margin-bottom:5px}
.stat-box p{font-size:.85rem;opacity:.7}
.stat-box.pending h3{color:#f39c12}
.stat-box.completed h3{color:#28a745}
.stat-box.rejected h3{color:#dc3545}
.stat-box.error h3{color:var(--muted-text-color)}
.filter-bar{display:flex;gap:15px;flex-wrap:wrap;align-items:center}
.filter-bar .form-control{max-width:300px}
.refill-table{width:100%;border-collapse:collapse}
.refill-table th,.refill-table td{padding:15px;text-align:left;border-bottom:1px solid var(--border-color)}
.refill-table th{font-weight:600;font-size:.85rem;opacity:.7;white-space:nowrap}
.refill-table tr:hover{background:var(--background-color)}
.user-info{display:flex;align-items:center;gap:10px}
.user-avatar{width:36px;height:36px;background:linear-gradient(135deg,var(--primary-color),var(--secondary-color));border-radius:8px;display:flex;align-items:center;justify-content:center;color:var(--on-accent-color);font-weight:600;font-size:.85rem;flex-shrink:0}
.user-details h4{font-size:.9rem;font-weight:600;margin-bottom:2px}
.user-details span{font-size:.75rem;opacity:.6}
.order-info{max-width:300px}
.order-info h4{font-size:.85rem;font-weight:600;margin-bottom:4px}
.order-info .link{font-size:.75rem;color:var(--accent-text-color);word-break:break-all;display:block;margin-bottom:4px;text-decoration:none}
.order-info .link:hover{text-decoration:underline}
.order-info .meta{font-size:.75rem;opacity:.6}
.refill-badge{padding:4px 10px;border-radius:6px;font-size:.75rem;font-weight:600;display:inline-block}
.refill-badge.pending{background:rgba(243,156,18,.15);color:#f39c12}
.refill-badge.processing{background:rgba(23,162,184,.15);color:#17a2b8}
.refill-badge.completed{background:rgba(40,167,69,.15);color:#28a745}
.refill-badge.rejected{background:rgba(220,53,69,.15);color:#dc3545}
.refill-badge.error{background:rgba(108,117,125,.15);color:var(--muted-text-color)}
.refill-count{font-size:.7rem;opacity:.7}
.action-buttons{display:flex;gap:8px}
.btn-approve{background:rgba(40,167,69,.15);color:#28a745;border:1px solid rgba(40,167,69,.3);padding:8px 12px;border-radius:8px;font-size:.8rem;font-weight:600;cursor:pointer;transition:all .3s ease;display:inline-flex;align-items:center;gap:5px}
.btn-approve:hover{background:#28a745;color:#fff}
.btn-reject{background:rgba(220,53,69,.15);color:#dc3545;border:1px solid rgba(220,53,69,.3);padding:8px 12px;border-radius:8px;font-size:.8rem;font-weight:600;cursor:pointer;transition:all .3s ease;display:inline-flex;align-items:center;gap:5px}
.btn-reject:hover{background:#dc3545;color:#fff}
.btn-view{background:var(--primary-alpha-015);color:var(--accent-text-color);border:1px solid var(--primary-alpha-03);padding:8px 12px;border-radius:8px;font-size:.8rem;font-weight:600;text-decoration:none;transition:all .3s ease;display:inline-flex;align-items:center;gap:5px}
.btn-view:hover{background:var(--primary-color);color:var(--on-primary-color)}
.date-info{font-size:.8rem}
.date-info .date{font-weight:600}
.date-info .time{opacity:.6;font-size:.75rem}
.empty-state{text-align:center;padding:60px 20px}
.empty-state i{font-size:4rem;opacity:.2;margin-bottom:20px}
.empty-state h3{font-size:1.2rem;margin-bottom:10px}
.empty-state p{opacity:.6}
.pagination{display:flex;justify-content:center;gap:5px;margin-top:25px}
.pagination a,.pagination span{padding:10px 15px;border-radius:8px;text-decoration:none;font-size:.9rem;font-weight:500;color:var(--text-color);background:var(--card-bg-color);border:1px solid var(--border-color);transition:all .3s ease}
.pagination a:hover{border-color:var(--accent-text-color);color:var(--accent-text-color)}
.pagination .active{background:var(--primary-color);color:var(--on-primary-color);border-color:var(--accent-text-color)}
.modal-overlay{display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.6);z-index:2000;align-items:center;justify-content:center}
.modal-overlay.show{display:flex}
.modal-content{background:var(--card-bg-color);border-radius:16px;width:90%;max-width:500px;max-height:90vh;overflow-y:auto}
.modal-header{padding:20px;border-bottom:1px solid var(--border-color);display:flex;align-items:center;justify-content:space-between}
.modal-header h3{font-size:1.1rem;font-weight:600;display:flex;align-items:center;gap:10px}
.modal-close{background:none;border:none;font-size:1.5rem;cursor:pointer;color:var(--text-color);opacity:.5;line-height:1}
.modal-close:hover{opacity:1}
.modal-body{padding:20px}
.modal-footer{padding:20px;border-top:1px solid var(--border-color);display:flex;gap:10px;justify-content:flex-end}
.reason-input{width:100%;padding:12px;border:2px solid var(--border-color);border-radius:10px;background:var(--background-color);color:var(--text-color);font-size:.9rem;resize:vertical;min-height:100px;font-family:inherit}
.reason-input:focus{outline:none;border-color:var(--accent-text-color)}
.processed-info{font-size:.7rem;opacity:.6;margin-top:4px}
</style>

<?php if ($success): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo clean($success); ?></div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo clean($error); ?></div>
<?php endif; ?>

<div class="stats-row">
    <a href="?status=all" class="stat-box <?php echo $statusFilter === 'all' ? 'active' : ''; ?>">
        <h3><?php echo number_format($stats['total']); ?></h3>
        <p>Toplam</p>
    </a>
    <a href="?status=pending" class="stat-box pending <?php echo $statusFilter === 'pending' ? 'active' : ''; ?>">
        <h3><?php echo number_format($stats['pending']); ?></h3>
        <p>Bekleyen</p>
    </a>
    <a href="?status=completed" class="stat-box completed <?php echo $statusFilter === 'completed' ? 'active' : ''; ?>">
        <h3><?php echo number_format($stats['completed']); ?></h3>
        <p>Tamamlanan</p>
    </a>
    <a href="?status=rejected" class="stat-box rejected <?php echo $statusFilter === 'rejected' ? 'active' : ''; ?>">
        <h3><?php echo number_format($stats['rejected']); ?></h3>
        <p>Reddedilen</p>
    </a>
    <a href="?status=error" class="stat-box error <?php echo $statusFilter === 'error' ? 'active' : ''; ?>">
        <h3><?php echo number_format($stats['error']); ?></h3>
        <p>Hatalı</p>
    </a>
</div>

<div class="admin-card">
    <div class="card-body">
        <form method="GET" class="filter-bar">
            <input type="hidden" name="status" value="<?php echo clean($statusFilter); ?>">
            <input type="text" name="search" class="form-control" placeholder="Kullanıcı, e-posta, link veya sipariş ID ara..." value="<?php echo clean($search); ?>">
            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Ara</button>
            <?php if ($search): ?>
            <a href="?status=<?php echo clean($statusFilter); ?>" class="btn btn-secondary"><i class="fas fa-times"></i> Temizle</a>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="admin-card">
    <div class="card-header">
        <h2><i class="fas fa-redo"></i> Refill Talepleri</h2>
        <span><?php echo number_format($totalRequests); ?> talep</span>
    </div>
    <div class="card-body" style="padding:0;">
        <?php if (empty($requests)): ?>
        <div class="empty-state">
            <i class="fas fa-inbox"></i>
            <h3>Talep Bulunamadı</h3>
            <p>Seçilen kriterlere uygun refill talebi yok.</p>
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="refill-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Kullanıcı</th>
                        <th>Sipariş & Servis</th>
                        <th>Miktar</th>
                        <th>Tarih</th>
                        <th>Durum</th>
                        <th>İşlem</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requests as $req): ?>
                    <tr>
                        <td><strong>#<?php echo $req['id']; ?></strong></td>
                        <td>
                            <div class="user-info">
                                <div class="user-avatar"><?php echo strtoupper(mb_substr($req['username'], 0, 1, 'UTF-8')); ?></div>
                                <div class="user-details">
                                    <h4><?php echo clean($req['username']); ?></h4>
                                    <span><?php echo clean($req['email']); ?></span>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="order-info">
                                <h4>#<?php echo $req['order_id']; ?> - <?php echo clean($req['service_name']); ?></h4>
                                <a href="<?php echo clean($req['link']); ?>" target="_blank" class="link">
                                    <?php echo clean(mb_strlen($req['link']) > 40 ? mb_substr($req['link'], 0, 40) . '...' : $req['link']); ?>
                                </a>
                            </div>
                        </td>
                        <td>
                            <strong><?php echo number_format($req['quantity']); ?></strong>
                            <div class="refill-count"><?php echo $req['refill_used']; ?>/<?php echo $req['refill_max']; ?> kullanıldı</div>
                        </td>
                        <td>
                            <div class="date-info">
                                <div class="date"><?php echo date('d.m.Y', strtotime($req['created_at'])); ?></div>
                                <div class="time"><?php echo date('H:i', strtotime($req['created_at'])); ?></div>
                            </div>
                        </td>
                        <td>
                            <span class="refill-badge <?php echo $req['status']; ?>">
                                <?php
                                $labels = ['pending'=>'Bekliyor','processing'=>'İşleniyor','completed'=>'Tamamlandı','rejected'=>'Reddedildi','error'=>'Hata'];
                                echo $labels[$req['status']] ?? $req['status'];
                                ?>
                            </span>
                            <?php if ($req['processed_by_name']): ?>
                            <div class="processed-info"><?php echo clean($req['processed_by_name']); ?></div>
                            <?php endif; ?>
                            <?php if ($req['new_order_id']): ?>
                            <div class="processed-info">Yeni: #<?php echo $req['new_order_id']; ?></div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($req['status'] === 'pending'): ?>
                            <div class="action-buttons">
                                <form method="POST" style="display:inline;" onsubmit="return confirm('Refill talebini onaylamak istediğinize emin misiniz?');">
                                    <input type="hidden" name="refill_id" value="<?php echo $req['id']; ?>">
                                    <input type="hidden" name="action" value="approve">
                                    <button type="submit" class="btn-approve"><i class="fas fa-check"></i> Onayla</button>
                                </form>
                                <button type="button" class="btn-reject" onclick="openRejectModal(<?php echo $req['id']; ?>)"><i class="fas fa-times"></i> Reddet</button>
                            </div>
                            <?php else: ?>
                            <a href="/admin/orders.php?search=<?php echo $req['order_id']; ?>" class="btn-view"><i class="fas fa-eye"></i> Sipariş</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php if ($totalPages > 1): ?>
<div class="pagination">
    <?php if ($page > 1): ?>
    <a href="?status=<?php echo clean($statusFilter); ?>&search=<?php echo urlencode($search); ?>&page=<?php echo $page - 1; ?>"><i class="fas fa-chevron-left"></i></a>
    <?php endif; ?>
    <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
        <?php if ($i == $page): ?>
        <span class="active"><?php echo $i; ?></span>
        <?php else: ?>
        <a href="?status=<?php echo clean($statusFilter); ?>&search=<?php echo urlencode($search); ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
        <?php endif; ?>
    <?php endfor; ?>
    <?php if ($page < $totalPages): ?>
    <a href="?status=<?php echo clean($statusFilter); ?>&search=<?php echo urlencode($search); ?>&page=<?php echo $page + 1; ?>"><i class="fas fa-chevron-right"></i></a>
    <?php endif; ?>
</div>
<?php endif; ?>

<div class="modal-overlay" id="rejectModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-times-circle" style="color:#dc3545;"></i> Refill Talebini Reddet</h3>
            <button type="button" class="modal-close" onclick="closeRejectModal()">&times;</button>
        </div>
        <form method="POST" id="rejectForm">
            <input type="hidden" name="refill_id" id="rejectRefillId">
            <input type="hidden" name="action" value="reject">
            <div class="modal-body">
                <div class="form-group" style="margin-bottom:0;">
                    <label class="form-label">Reddetme Sebebi (Opsiyonel)</label>
                    <textarea name="reject_reason" class="reason-input" placeholder="Reddetme sebebini yazın..."></textarea>
                    <small style="opacity:0.6;margin-top:8px;display:block;">
                        <i class="fas fa-info-circle"></i> Reddedilen taleplerde refill hakkı otomatik olarak kullanıcıya iade edilir.
                    </small>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeRejectModal()">İptal</button>
                <button type="submit" class="btn btn-danger"><i class="fas fa-times"></i> Reddet</button>
            </div>
        </form>
    </div>
</div>

<script>
function openRejectModal(id){document.getElementById('rejectRefillId').value=id;document.getElementById('rejectModal').classList.add('show');}
function closeRejectModal(){document.getElementById('rejectModal').classList.remove('show');document.getElementById('rejectForm').reset();}
document.getElementById('rejectModal').addEventListener('click',function(e){if(e.target===this)closeRejectModal();});
document.addEventListener('keydown',function(e){if(e.key==='Escape')closeRejectModal();});
</script>

<?php require_once 'footer.php'; ?>