<?php
/**
 * Admin Panel - Footer Yönetimi
 */

require_once __DIR__ . '/../config.php';

// Demo mode kontrolü
$demoMode = false;
try {
    $dm = $db->prepare("SELECT setting_value FROM settings WHERE setting_key = 'demo_mode' LIMIT 1");
    $dm->execute();
    $demoMode = trim((string)$dm->fetchColumn()) === '1';
} catch (Exception $e) {
    $demoMode = false;
}

// Tabloları oluştur
try {
    $db->query("SELECT 1 FROM footer_sections LIMIT 1");
} catch (Exception $e) {
    $db->exec("
        CREATE TABLE IF NOT EXISTS footer_sections (
            id INT PRIMARY KEY AUTO_INCREMENT,
            title VARCHAR(255) NOT NULL,
            sort_order INT DEFAULT 0,
            status ENUM('active', 'inactive') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS footer_links (
            id INT PRIMARY KEY AUTO_INCREMENT,
            section_id INT NOT NULL,
            title VARCHAR(255) NOT NULL,
            url VARCHAR(500) NOT NULL,
            icon VARCHAR(100) DEFAULT NULL,
            target ENUM('_self', '_blank') DEFAULT '_self',
            sort_order INT DEFAULT 0,
            status ENUM('active', 'inactive') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS social_links (
            id INT PRIMARY KEY AUTO_INCREMENT,
            platform VARCHAR(100) NOT NULL,
            url VARCHAR(500) NOT NULL,
            icon VARCHAR(100) NOT NULL,
            sort_order INT DEFAULT 0,
            status ENUM('active', 'inactive') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    ");
}

// İletişim ayarlarını kontrol et
$contactKeys = ['footer_email', 'footer_phone', 'footer_address', 'footer_working_hours', 'footer_contact_enabled'];
foreach ($contactKeys as $key) {
    $check = $db->prepare("SELECT COUNT(*) FROM settings WHERE setting_key = ?");
    $check->execute([$key]);
    if ($check->fetchColumn() == 0) {
        $val = $key === 'footer_contact_enabled' ? '1' : '';
        $db->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)")->execute([$key, $val]);
    }
}

// İşlemler
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Demo modda tüm işlemleri engelle
    if ($demoMode) {
        setAlert('Demo modunda footer ayarları değiştirilemez.', 'warning');
        $tab = $_GET['tab'] ?? 'sections';
        header('Location: footer-settings.php?tab=' . $tab);
        exit;
    }
    
    $action = $_POST['action'] ?? '';
    
    // İletişim kaydet
    if ($action === 'save_contact') {
        $fields = [
            'footer_contact_enabled' => isset($_POST['footer_contact_enabled']) ? '1' : '0',
            'footer_email' => trim($_POST['footer_email'] ?? ''),
            'footer_phone' => trim($_POST['footer_phone'] ?? ''),
            'footer_address' => trim($_POST['footer_address'] ?? ''),
            'footer_working_hours' => trim($_POST['footer_working_hours'] ?? '')
        ];
        foreach ($fields as $k => $v) {
            $db->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = ?")->execute([$v, $k]);
        }
        setAlert('İletişim ayarları kaydedildi.', 'success');
        header('Location: footer-settings.php?tab=contact');
        exit;
    }
    
    // Bölüm ekle
    if ($action === 'add_section') {
        $title = trim($_POST['section_title'] ?? '');
        $order = (int)($_POST['section_sort_order'] ?? 0);
        if ($title) {
            $db->prepare("INSERT INTO footer_sections (title, sort_order) VALUES (?, ?)")->execute([$title, $order]);
            setAlert('Bölüm eklendi.', 'success');
        }
        header('Location: footer-settings.php?tab=sections');
        exit;
    }
    
    // Bölüm düzenle
    if ($action === 'edit_section') {
        $id = (int)($_POST['section_id'] ?? 0);
        $title = trim($_POST['section_title'] ?? '');
        $order = (int)($_POST['section_sort_order'] ?? 0);
        $status = $_POST['section_status'] ?? 'active';
        if ($id && $title) {
            $db->prepare("UPDATE footer_sections SET title=?, sort_order=?, status=? WHERE id=?")->execute([$title, $order, $status, $id]);
            setAlert('Bölüm güncellendi.', 'success');
        }
        header('Location: footer-settings.php?tab=sections');
        exit;
    }
    
    // Bölüm sil
    if ($action === 'delete_section') {
        $id = (int)($_POST['section_id'] ?? 0);
        if ($id) {
            $db->prepare("DELETE FROM footer_links WHERE section_id = ?")->execute([$id]);
            $db->prepare("DELETE FROM footer_sections WHERE id = ?")->execute([$id]);
            setAlert('Bölüm silindi.', 'success');
        }
        header('Location: footer-settings.php?tab=sections');
        exit;
    }
    
    // Link ekle
    if ($action === 'add_link') {
        $sectionId = (int)($_POST['link_section_id'] ?? 0);
        $title = trim($_POST['link_title'] ?? '');
        $url = trim($_POST['link_url'] ?? '');
        $icon = trim($_POST['link_icon'] ?? '');
        $target = $_POST['link_target'] ?? '_self';
        $order = (int)($_POST['link_sort_order'] ?? 0);
        if ($sectionId && $title && $url) {
            $db->prepare("INSERT INTO footer_links (section_id, title, url, icon, target, sort_order) VALUES (?,?,?,?,?,?)")
               ->execute([$sectionId, $title, $url, $icon, $target, $order]);
            setAlert('Link eklendi.', 'success');
        }
        header('Location: footer-settings.php?tab=links');
        exit;
    }
    
    // Link düzenle
    if ($action === 'edit_link') {
        $id = (int)($_POST['link_id'] ?? 0);
        $sectionId = (int)($_POST['link_section_id'] ?? 0);
        $title = trim($_POST['link_title'] ?? '');
        $url = trim($_POST['link_url'] ?? '');
        $icon = trim($_POST['link_icon'] ?? '');
        $target = $_POST['link_target'] ?? '_self';
        $order = (int)($_POST['link_sort_order'] ?? 0);
        $status = $_POST['link_status'] ?? 'active';
        if ($id && $title && $url) {
            $db->prepare("UPDATE footer_links SET section_id=?, title=?, url=?, icon=?, target=?, sort_order=?, status=? WHERE id=?")
               ->execute([$sectionId, $title, $url, $icon, $target, $order, $status, $id]);
            setAlert('Link güncellendi.', 'success');
        }
        header('Location: footer-settings.php?tab=links');
        exit;
    }
    
    // Link sil
    if ($action === 'delete_link') {
        $id = (int)($_POST['link_id'] ?? 0);
        if ($id) {
            $db->prepare("DELETE FROM footer_links WHERE id = ?")->execute([$id]);
            setAlert('Link silindi.', 'success');
        }
        header('Location: footer-settings.php?tab=links');
        exit;
    }
    
    // Sosyal medya ekle
    if ($action === 'add_social') {
        $platform = trim($_POST['social_platform'] ?? '');
        $url = trim($_POST['social_url'] ?? '');
        $icon = trim($_POST['social_icon'] ?? '');
        $order = (int)($_POST['social_sort_order'] ?? 0);
        if ($platform && $url && $icon) {
            $db->prepare("INSERT INTO social_links (platform, url, icon, sort_order) VALUES (?,?,?,?)")
               ->execute([$platform, $url, $icon, $order]);
            setAlert('Sosyal medya eklendi.', 'success');
        }
        header('Location: footer-settings.php?tab=social');
        exit;
    }
    
    // Sosyal medya düzenle
    if ($action === 'edit_social') {
        $id = (int)($_POST['social_id'] ?? 0);
        $platform = trim($_POST['social_platform'] ?? '');
        $url = trim($_POST['social_url'] ?? '');
        $icon = trim($_POST['social_icon'] ?? '');
        $order = (int)($_POST['social_sort_order'] ?? 0);
        $status = $_POST['social_status'] ?? 'active';
        if ($id && $platform && $url && $icon) {
            $db->prepare("UPDATE social_links SET platform=?, url=?, icon=?, sort_order=?, status=? WHERE id=?")
               ->execute([$platform, $url, $icon, $order, $status, $id]);
            setAlert('Sosyal medya güncellendi.', 'success');
        }
        header('Location: footer-settings.php?tab=social');
        exit;
    }
    
    // Sosyal medya sil
    if ($action === 'delete_social') {
        $id = (int)($_POST['social_id'] ?? 0);
        if ($id) {
            $db->prepare("DELETE FROM social_links WHERE id = ?")->execute([$id]);
            setAlert('Sosyal medya silindi.', 'success');
        }
        header('Location: footer-settings.php?tab=social');
        exit;
    }
}

// Verileri çek
$sections = $db->query("SELECT * FROM footer_sections ORDER BY sort_order")->fetchAll();
$links = $db->query("SELECT l.*, s.title as section_title FROM footer_links l LEFT JOIN footer_sections s ON l.section_id = s.id ORDER BY l.section_id, l.sort_order")->fetchAll();
$socialLinks = $db->query("SELECT * FROM social_links ORDER BY sort_order")->fetchAll();

$contactSettings = [];
$stmt = $db->query("SELECT setting_key, setting_value FROM settings WHERE setting_key LIKE 'footer_%'");
while ($row = $stmt->fetch()) {
    $contactSettings[$row['setting_key']] = $row['setting_value'];
}

$activeTab = $_GET['tab'] ?? 'sections';

$pageTitle = "Footer Ayarları";
require_once 'header.php';
?>

<style>
.tabs {
    display: flex;
    gap: 10px;
    margin-bottom: 25px;
    flex-wrap: wrap;
}

.tab {
    padding: 12px 22px;
    background: var(--background-color);
    border: 1px solid var(--border-color);
    border-radius: 10px;
    font-weight: 600;
    font-size: 0.9rem;
    text-decoration: none;
    color: var(--text-color);
    display: flex;
    align-items: center;
    gap: 8px;
    transition: 0.3s;
}

.tab:hover {
    border-color: var(--accent-text-color);
    color: var(--accent-text-color);
}

.tab.active {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--on-accent-color);
    border-color: transparent;
}

.tab-content {
    display: none;
}

.tab-content.active {
    display: block;
}

.tbl {
    width: 100%;
    border-collapse: collapse;
}

.tbl th,
.tbl td {
    padding: 14px 16px;
    text-align: left;
    border-bottom: 1px solid var(--border-color);
}

.tbl th {
    background: var(--background-color);
    font-size: 0.78rem;
    text-transform: uppercase;
    opacity: 0.7;
}

.tbl tr:hover {
    background: var(--background-color);
}

.add-box {
    background: var(--background-color);
    border-radius: 12px;
    padding: 25px;
    margin-top: 25px;
}

.add-box h4 {
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.add-box h4 i {
    color: var(--accent-text-color);
}

.form-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 15px;
    margin-bottom: 15px;
}

.form-group {
    margin-bottom: 0;
}

.form-group label {
    display: block;
    margin-bottom: 6px;
    font-weight: 500;
    font-size: 0.85rem;
}

.form-group small {
    display: block;
    margin-top: 4px;
    opacity: 0.6;
    font-size: 0.78rem;
}

.icon-box {
    width: 34px;
    height: 34px;
    background: var(--background-color);
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--accent-text-color);
}

.section-tag {
    padding: 4px 10px;
    background: var(--primary-alpha-015);
    color: var(--accent-text-color);
    border-radius: 12px;
    font-size: 0.75rem;
    font-weight: 600;
}

.acts {
    display: flex;
    gap: 6px;
}

.act-btn {
    width: 32px;
    height: 32px;
    border: none;
    border-radius: 7px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.85rem;
    transition: 0.2s;
}

.act-btn.edit {
    background: rgba(23, 162, 184, 0.15);
    color: #17a2b8;
}

.act-btn.del {
    background: rgba(220, 53, 69, 0.15);
    color: #dc3545;
}

.act-btn:hover {
    transform: scale(1.1);
}

.act-btn.disabled {
    opacity: 0.4;
    cursor: not-allowed;
    pointer-events: none;
}

.empty {
    text-align: center;
    padding: 40px;
    opacity: 0.5;
}

.empty i {
    font-size: 2.5rem;
    margin-bottom: 10px;
    display: block;
}

.social-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(90px, 1fr));
    gap: 10px;
    margin-top: 10px;
}

.social-btn {
    padding: 12px 8px;
    background: var(--background-color);
    border: 2px solid var(--border-color);
    border-radius: 10px;
    cursor: pointer;
    text-align: center;
    transition: 0.2s;
}

.social-btn:hover {
    border-color: var(--accent-text-color);
}

.social-btn.selected {
    border-color: var(--accent-text-color);
    background: var(--primary-alpha-01);
}

.social-btn i {
    font-size: 1.3rem;
    display: block;
    margin-bottom: 4px;
}

.social-btn span {
    font-size: 0.7rem;
    opacity: 0.7;
}

.toggle-box {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 15px;
    background: var(--background-color);
    border-radius: 10px;
    margin-bottom: 20px;
}

.toggle-switch {
    position: relative;
    width: 50px;
    height: 26px;
}

.toggle-switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.toggle-slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: var(--border-color);
    transition: 0.3s;
    border-radius: 26px;
}

.toggle-slider:before {
    position: absolute;
    content: "";
    height: 20px;
    width: 20px;
    left: 3px;
    bottom: 3px;
    background: white;
    transition: 0.3s;
    border-radius: 50%;
}

.toggle-switch input:checked + .toggle-slider {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
}

.toggle-switch input:checked + .toggle-slider:before {
    transform: translateX(24px);
}

.modal-bg {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    z-index: 2000;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.modal-bg.show {
    display: flex;
}

.modal-box {
    background: var(--card-bg-color);
    border-radius: 16px;
    width: 100%;
    max-width: 480px;
    max-height: 90vh;
    overflow-y: auto;
}

.modal-head {
    padding: 18px 22px;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-head h3 {
    font-size: 1rem;
}

.modal-close {
    background: var(--background-color);
    border: none;
    width: 34px;
    height: 34px;
    border-radius: 8px;
    font-size: 1.1rem;
    cursor: pointer;
    color: var(--text-color);
}

.modal-close:hover {
    background: var(--danger-color);
    color: var(--on-danger-color);
}

.modal-body {
    padding: 22px;
}

.modal-foot {
    padding: 18px 22px;
    border-top: 1px solid var(--border-color);
    display: flex;
    gap: 10px;
    justify-content: flex-end;
}

/* Demo Mode Styles */
.demo-banner {
    display: flex;
    align-items: center;
    gap: 15px;
    background: linear-gradient(135deg, #f39c12, #e67e22);
    color: #fff;
    padding: 18px 25px;
    border-radius: 12px;
    margin-bottom: 25px;
    box-shadow: 0 4px 15px rgba(243, 156, 18, 0.3);
}

.demo-banner i {
    font-size: 1.8rem;
    animation: pulse-demo 2s infinite;
}

@keyframes pulse-demo {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.7; transform: scale(1.1); }
}

.demo-banner-content h4 {
    font-size: 1.1rem;
    font-weight: 700;
    margin-bottom: 3px;
}

.demo-banner-content p {
    font-size: 0.85rem;
    opacity: 0.9;
    margin: 0;
}

.form-disabled {
    opacity: 0.7;
    pointer-events: none;
}

.form-disabled input,
.form-disabled select,
.form-disabled textarea {
    background: var(--surface-alt-color) !important;
    cursor: not-allowed;
}

.btn-disabled {
    opacity: 0.5 !important;
    cursor: not-allowed !important;
    pointer-events: none !important;
}

.add-box-disabled {
    opacity: 0.6;
    pointer-events: none;
}
</style>

<?php if ($demoMode): ?>
<div class="demo-banner">
    <i class="fas fa-flask"></i>
    <div class="demo-banner-content">
        <h4>Demo Modu Aktif</h4>
        <p>Footer ayarlarını görüntüleyebilirsiniz ancak ekleme, düzenleme ve silme işlemleri yapılamaz.</p>
    </div>
</div>
<?php endif; ?>

<!-- Tabs -->
<div class="tabs">
    <a href="?tab=sections" class="tab <?php echo $activeTab === 'sections' ? 'active' : ''; ?>">
        <i class="fas fa-layer-group"></i> Bölümler
    </a>
    <a href="?tab=links" class="tab <?php echo $activeTab === 'links' ? 'active' : ''; ?>">
        <i class="fas fa-link"></i> Linkler
    </a>
    <a href="?tab=social" class="tab <?php echo $activeTab === 'social' ? 'active' : ''; ?>">
        <i class="fas fa-share-alt"></i> Sosyal Medya
    </a>
    <a href="?tab=contact" class="tab <?php echo $activeTab === 'contact' ? 'active' : ''; ?>">
        <i class="fas fa-address-card"></i> İletişim
    </a>
</div>

<!-- BÖLÜMLER TAB -->
<div class="tab-content <?php echo $activeTab === 'sections' ? 'active' : ''; ?>">
    <div class="admin-card">
        <div class="card-header">
            <h2><i class="fas fa-layer-group"></i> Footer Bölümleri</h2>
        </div>
        <div class="card-body">
            <?php if (empty($sections)): ?>
                <div class="empty">
                    <i class="fas fa-folder-open"></i>
                    <p>Henüz bölüm eklenmemiş</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="tbl">
                        <thead>
                            <tr>
                                <th>Başlık</th>
                                <th>Sıra</th>
                                <th>Durum</th>
                                <th>İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($sections as $s): ?>
                                <tr>
                                    <td><strong><?php echo clean($s['title']); ?></strong></td>
                                    <td><?php echo $s['sort_order']; ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $s['status']; ?>">
                                            <?php echo $s['status'] === 'active' ? 'Aktif' : 'Pasif'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="acts">
                                            <?php if ($demoMode): ?>
                                            <button type="button" class="act-btn edit disabled" title="Demo modunda düzenleme kapalı">
                                                <i class="fas fa-lock"></i>
                                            </button>
                                            <button type="button" class="act-btn del disabled" title="Demo modunda silme kapalı">
                                                <i class="fas fa-lock"></i>
                                            </button>
                                            <?php else: ?>
                                            <button type="button" class="act-btn edit" onclick="editSection(<?php echo htmlspecialchars(json_encode($s)); ?>)">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <form method="POST" style="display:inline" onsubmit="return confirm('Bu bölümü ve tüm linklerini silmek istediğinize emin misiniz?')">
                                                <input type="hidden" name="action" value="delete_section">
                                                <input type="hidden" name="section_id" value="<?php echo $s['id']; ?>">
                                                <button type="submit" class="act-btn del">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
            
            <div class="add-box <?php echo $demoMode ? 'add-box-disabled' : ''; ?>">
                <h4><i class="fas fa-plus-circle"></i> Yeni Bölüm Ekle</h4>
                <form method="POST">
                    <input type="hidden" name="action" value="add_section">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Bölüm Başlığı *</label>
                            <input type="text" name="section_title" class="form-control" placeholder="Örn: Hızlı Linkler" required <?php echo $demoMode ? 'disabled' : ''; ?>>
                        </div>
                        <div class="form-group">
                            <label>Sıralama</label>
                            <input type="number" name="section_sort_order" class="form-control" value="0" min="0" <?php echo $demoMode ? 'disabled' : ''; ?>>
                            <small>Küçük sayı önce gösterilir</small>
                        </div>
                    </div>
                    <?php if ($demoMode): ?>
                    <button type="button" class="btn btn-primary btn-disabled" disabled>
                        <i class="fas fa-lock"></i> Demo Modunda Ekleme Kapalı
                    </button>
                    <?php else: ?>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Bölüm Ekle
                    </button>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- LİNKLER TAB -->
<div class="tab-content <?php echo $activeTab === 'links' ? 'active' : ''; ?>">
    <div class="admin-card">
        <div class="card-header">
            <h2><i class="fas fa-link"></i> Footer Linkleri</h2>
        </div>
        <div class="card-body">
            <?php if (empty($sections)): ?>
                <div class="empty">
                    <i class="fas fa-exclamation-circle"></i>
                    <p>Önce bir bölüm eklemelisiniz</p>
                </div>
            <?php elseif (empty($links)): ?>
                <div class="empty">
                    <i class="fas fa-link"></i>
                    <p>Henüz link eklenmemiş</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="tbl">
                        <thead>
                            <tr>
                                <th>İkon</th>
                                <th>Başlık</th>
                                <th>URL</th>
                                <th>Bölüm</th>
                                <th>Durum</th>
                                <th>İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($links as $l): ?>
                                <tr>
                                    <td>
                                        <div class="icon-box">
                                            <i class="<?php echo clean($l['icon'] ?: 'fas fa-link'); ?>"></i>
                                        </div>
                                    </td>
                                    <td><strong><?php echo clean($l['title']); ?></strong></td>
                                    <td style="max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                        <a href="<?php echo clean($l['url']); ?>" target="_blank"><?php echo clean($l['url']); ?></a>
                                    </td>
                                    <td><span class="section-tag"><?php echo clean($l['section_title']); ?></span></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $l['status']; ?>">
                                            <?php echo $l['status'] === 'active' ? 'Aktif' : 'Pasif'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="acts">
                                            <?php if ($demoMode): ?>
                                            <button type="button" class="act-btn edit disabled" title="Demo modunda düzenleme kapalı">
                                                <i class="fas fa-lock"></i>
                                            </button>
                                            <button type="button" class="act-btn del disabled" title="Demo modunda silme kapalı">
                                                <i class="fas fa-lock"></i>
                                            </button>
                                            <?php else: ?>
                                            <button type="button" class="act-btn edit" onclick="editLink(<?php echo htmlspecialchars(json_encode($l)); ?>)">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <form method="POST" style="display:inline" onsubmit="return confirm('Bu linki silmek istediğinize emin misiniz?')">
                                                <input type="hidden" name="action" value="delete_link">
                                                <input type="hidden" name="link_id" value="<?php echo $l['id']; ?>">
                                                <button type="submit" class="act-btn del">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($sections)): ?>
                <div class="add-box <?php echo $demoMode ? 'add-box-disabled' : ''; ?>">
                    <h4><i class="fas fa-plus-circle"></i> Yeni Link Ekle</h4>
                    <form method="POST">
                        <input type="hidden" name="action" value="add_link">
                        <div class="form-row">
                            <div class="form-group">
                                <label>Bölüm *</label>
                                <select name="link_section_id" class="form-control" required <?php echo $demoMode ? 'disabled' : ''; ?>>
                                    <option value="">-- Bölüm Seçin --</option>
                                    <?php foreach ($sections as $s): ?>
                                        <option value="<?php echo $s['id']; ?>"><?php echo clean($s['title']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Link Başlığı *</label>
                                <input type="text" name="link_title" class="form-control" placeholder="Örn: Hakkımızda" required <?php echo $demoMode ? 'disabled' : ''; ?>>
                            </div>
                            <div class="form-group">
                                <label>URL *</label>
                                <input type="text" name="link_url" class="form-control" placeholder="/pages/hakkimizda.php" required <?php echo $demoMode ? 'disabled' : ''; ?>>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>İkon (Font Awesome)</label>
                                <input type="text" name="link_icon" class="form-control" placeholder="fas fa-info-circle" <?php echo $demoMode ? 'disabled' : ''; ?>>
                                <small>Boş bırakılırsa ok ikonu kullanılır</small>
                            </div>
                            <div class="form-group">
                                <label>Hedef</label>
                                <select name="link_target" class="form-control" <?php echo $demoMode ? 'disabled' : ''; ?>>
                                    <option value="_self">Aynı Sayfada Aç</option>
                                    <option value="_blank">Yeni Sekmede Aç</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Sıralama</label>
                                <input type="number" name="link_sort_order" class="form-control" value="0" min="0" <?php echo $demoMode ? 'disabled' : ''; ?>>
                            </div>
                        </div>
                        <?php if ($demoMode): ?>
                        <button type="button" class="btn btn-primary btn-disabled" disabled>
                            <i class="fas fa-lock"></i> Demo Modunda Ekleme Kapalı
                        </button>
                        <?php else: ?>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Link Ekle
                        </button>
                        <?php endif; ?>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- SOSYAL MEDYA TAB -->
<div class="tab-content <?php echo $activeTab === 'social' ? 'active' : ''; ?>">
    <div class="admin-card">
        <div class="card-header">
            <h2><i class="fas fa-share-alt"></i> Sosyal Medya Linkleri</h2>
        </div>
        <div class="card-body">
            <?php if (empty($socialLinks)): ?>
                <div class="empty">
                    <i class="fas fa-share-alt"></i>
                    <p>Henüz sosyal medya eklenmemiş</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="tbl">
                        <thead>
                            <tr>
                                <th>İkon</th>
                                <th>Platform</th>
                                <th>URL</th>
                                <th>Sıra</th>
                                <th>Durum</th>
                                <th>İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($socialLinks as $s): ?>
                                <tr>
                                    <td>
                                        <div class="icon-box">
                                            <i class="<?php echo clean($s['icon']); ?>"></i>
                                        </div>
                                    </td>
                                    <td><strong><?php echo clean($s['platform']); ?></strong></td>
                                    <td style="max-width: 180px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                        <a href="<?php echo clean($s['url']); ?>" target="_blank"><?php echo clean($s['url']); ?></a>
                                    </td>
                                    <td><?php echo $s['sort_order']; ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $s['status']; ?>">
                                            <?php echo $s['status'] === 'active' ? 'Aktif' : 'Pasif'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="acts">
                                            <?php if ($demoMode): ?>
                                            <button type="button" class="act-btn edit disabled" title="Demo modunda düzenleme kapalı">
                                                <i class="fas fa-lock"></i>
                                            </button>
                                            <button type="button" class="act-btn del disabled" title="Demo modunda silme kapalı">
                                                <i class="fas fa-lock"></i>
                                            </button>
                                            <?php else: ?>
                                            <button type="button" class="act-btn edit" onclick="editSocial(<?php echo htmlspecialchars(json_encode($s)); ?>)">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <form method="POST" style="display:inline" onsubmit="return confirm('Bu sosyal medyayı silmek istediğinize emin misiniz?')">
                                                <input type="hidden" name="action" value="delete_social">
                                                <input type="hidden" name="social_id" value="<?php echo $s['id']; ?>">
                                                <button type="submit" class="act-btn del">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
            
            <div class="add-box <?php echo $demoMode ? 'add-box-disabled' : ''; ?>">
                <h4><i class="fas fa-plus-circle"></i> Yeni Sosyal Medya Ekle</h4>
                <form method="POST">
                    <input type="hidden" name="action" value="add_social">
                    <input type="hidden" name="social_icon" id="selectedIcon" value="">
                    
                    <div class="form-group">
                        <label>Platform Seçin *</label>
                        <div class="social-grid">
                            <div class="social-btn <?php echo $demoMode ? 'disabled' : ''; ?>" data-icon="fab fa-facebook-f" data-name="Facebook" onclick="<?php echo $demoMode ? '' : 'pickSocial(this)'; ?>">
                                <i class="fab fa-facebook-f"></i>
                                <span>Facebook</span>
                            </div>
                            <div class="social-btn <?php echo $demoMode ? 'disabled' : ''; ?>" data-icon="fab fa-twitter" data-name="Twitter" onclick="<?php echo $demoMode ? '' : 'pickSocial(this)'; ?>">
                                <i class="fab fa-twitter"></i>
                                <span>Twitter</span>
                            </div>
                            <div class="social-btn <?php echo $demoMode ? 'disabled' : ''; ?>" data-icon="fab fa-instagram" data-name="Instagram" onclick="<?php echo $demoMode ? '' : 'pickSocial(this)'; ?>">
                                <i class="fab fa-instagram"></i>
                                <span>Instagram</span>
                            </div>
                            <div class="social-btn <?php echo $demoMode ? 'disabled' : ''; ?>" data-icon="fab fa-youtube" data-name="YouTube" onclick="<?php echo $demoMode ? '' : 'pickSocial(this)'; ?>">
                                <i class="fab fa-youtube"></i>
                                <span>YouTube</span>
                            </div>
                            <div class="social-btn <?php echo $demoMode ? 'disabled' : ''; ?>" data-icon="fab fa-tiktok" data-name="TikTok" onclick="<?php echo $demoMode ? '' : 'pickSocial(this)'; ?>">
                                <i class="fab fa-tiktok"></i>
                                <span>TikTok</span>
                            </div>
                            <div class="social-btn <?php echo $demoMode ? 'disabled' : ''; ?>" data-icon="fab fa-telegram-plane" data-name="Telegram" onclick="<?php echo $demoMode ? '' : 'pickSocial(this)'; ?>">
                                <i class="fab fa-telegram-plane"></i>
                                <span>Telegram</span>
                            </div>
                            <div class="social-btn <?php echo $demoMode ? 'disabled' : ''; ?>" data-icon="fab fa-whatsapp" data-name="WhatsApp" onclick="<?php echo $demoMode ? '' : 'pickSocial(this)'; ?>">
                                <i class="fab fa-whatsapp"></i>
                                <span>WhatsApp</span>
                            </div>
                            <div class="social-btn <?php echo $demoMode ? 'disabled' : ''; ?>" data-icon="fab fa-discord" data-name="Discord" onclick="<?php echo $demoMode ? '' : 'pickSocial(this)'; ?>">
                                <i class="fab fa-discord"></i>
                                <span>Discord</span>
                            </div>
                            <div class="social-btn <?php echo $demoMode ? 'disabled' : ''; ?>" data-icon="fab fa-linkedin-in" data-name="LinkedIn" onclick="<?php echo $demoMode ? '' : 'pickSocial(this)'; ?>">
                                <i class="fab fa-linkedin-in"></i>
                                <span>LinkedIn</span>
                            </div>
                            <div class="social-btn <?php echo $demoMode ? 'disabled' : ''; ?>" data-icon="fab fa-pinterest" data-name="Pinterest" onclick="<?php echo $demoMode ? '' : 'pickSocial(this)'; ?>">
                                <i class="fab fa-pinterest"></i>
                                <span>Pinterest</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-row" style="margin-top: 20px;">
                        <div class="form-group">
                            <label>Platform Adı *</label>
                            <input type="text" name="social_platform" id="socialName" class="form-control" placeholder="Örn: Instagram" required <?php echo $demoMode ? 'disabled' : ''; ?>>
                        </div>
                        <div class="form-group">
                            <label>URL *</label>
                            <input type="url" name="social_url" class="form-control" placeholder="https://instagram.com/kullaniciadi" required <?php echo $demoMode ? 'disabled' : ''; ?>>
                        </div>
                        <div class="form-group">
                            <label>Sıralama</label>
                            <input type="number" name="social_sort_order" class="form-control" value="0" min="0" <?php echo $demoMode ? 'disabled' : ''; ?>>
                        </div>
                    </div>
                    <?php if ($demoMode): ?>
                    <button type="button" class="btn btn-primary btn-disabled" disabled>
                        <i class="fas fa-lock"></i> Demo Modunda Ekleme Kapalı
                    </button>
                    <?php else: ?>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Sosyal Medya Ekle
                    </button>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- İLETİŞİM TAB -->
<div class="tab-content <?php echo $activeTab === 'contact' ? 'active' : ''; ?>">
    <div class="admin-card">
        <div class="card-header">
            <h2><i class="fas fa-address-card"></i> Footer İletişim Bilgileri</h2>
        </div>
        <div class="card-body">
            <form method="POST" class="<?php echo $demoMode ? 'form-disabled' : ''; ?>">
                <input type="hidden" name="action" value="save_contact">
                
                <div class="toggle-box">
                    <label class="toggle-switch">
                        <input type="checkbox" name="footer_contact_enabled" value="1" <?php echo ($contactSettings['footer_contact_enabled'] ?? '1') === '1' ? 'checked' : ''; ?> <?php echo $demoMode ? 'disabled' : ''; ?>>
                        <span class="toggle-slider"></span>
                    </label>
                    <div>
                        <strong>İletişim Bölümünü Göster</strong>
                        <small style="display: block; opacity: 0.6;">Footer'da iletişim bilgilerini göster/gizle</small>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-envelope"></i> E-posta Adresi</label>
                        <input type="email" name="footer_email" class="form-control" value="<?php echo clean($contactSettings['footer_email'] ?? ''); ?>" placeholder="destek@siteniz.com" <?php echo $demoMode ? 'disabled' : ''; ?>>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-phone"></i> Telefon Numarası</label>
                        <input type="text" name="footer_phone" class="form-control" value="<?php echo clean($contactSettings['footer_phone'] ?? ''); ?>" placeholder="+90 555 123 4567" <?php echo $demoMode ? 'disabled' : ''; ?>>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-clock"></i> Çalışma Saatleri</label>
                        <input type="text" name="footer_working_hours" class="form-control" value="<?php echo clean($contactSettings['footer_working_hours'] ?? ''); ?>" placeholder="7/24 Destek" <?php echo $demoMode ? 'disabled' : ''; ?>>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-map-marker-alt"></i> Adres</label>
                        <input type="text" name="footer_address" class="form-control" value="<?php echo clean($contactSettings['footer_address'] ?? ''); ?>" placeholder="İstanbul, Türkiye" <?php echo $demoMode ? 'disabled' : ''; ?>>
                    </div>
                </div>
                
                <?php if ($demoMode): ?>
                <button type="button" class="btn btn-primary btn-disabled" disabled>
                    <i class="fas fa-lock"></i> Demo Modunda Kaydetme Kapalı
                </button>
                <?php else: ?>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Kaydet
                </button>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div>

<?php if (!$demoMode): ?>
<!-- BÖLÜM DÜZENLEME MODAL -->
<div class="modal-bg" id="sectionModal">
    <div class="modal-box">
        <div class="modal-head">
            <h3><i class="fas fa-edit"></i> Bölüm Düzenle</h3>
            <button type="button" class="modal-close" onclick="closeModal('sectionModal')">&times;</button>
        </div>
        <form method="POST">
            <div class="modal-body">
                <input type="hidden" name="action" value="edit_section">
                <input type="hidden" name="section_id" id="editSectionId">
                
                <div class="form-group" style="margin-bottom: 15px;">
                    <label>Bölüm Başlığı *</label>
                    <input type="text" name="section_title" id="editSectionTitle" class="form-control" required>
                </div>
                <div class="form-group" style="margin-bottom: 15px;">
                    <label>Sıralama</label>
                    <input type="number" name="section_sort_order" id="editSectionOrder" class="form-control" min="0">
                </div>
                <div class="form-group">
                    <label>Durum</label>
                    <select name="section_status" id="editSectionStatus" class="form-control">
                        <option value="active">Aktif</option>
                        <option value="inactive">Pasif</option>
                    </select>
                </div>
            </div>
            <div class="modal-foot">
                <button type="button" class="btn btn-secondary" onclick="closeModal('sectionModal')">İptal</button>
                <button type="submit" class="btn btn-primary">Kaydet</button>
            </div>
        </form>
    </div>
</div>

<!-- LİNK DÜZENLEME MODAL -->
<div class="modal-bg" id="linkModal">
    <div class="modal-box">
        <div class="modal-head">
            <h3><i class="fas fa-edit"></i> Link Düzenle</h3>
            <button type="button" class="modal-close" onclick="closeModal('linkModal')">&times;</button>
        </div>
        <form method="POST">
            <div class="modal-body">
                <input type="hidden" name="action" value="edit_link">
                <input type="hidden" name="link_id" id="editLinkId">
                
                <div class="form-group" style="margin-bottom: 15px;">
                    <label>Bölüm *</label>
                    <select name="link_section_id" id="editLinkSection" class="form-control" required>
                        <?php foreach ($sections as $s): ?>
                            <option value="<?php echo $s['id']; ?>"><?php echo clean($s['title']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group" style="margin-bottom: 15px;">
                    <label>Link Başlığı *</label>
                    <input type="text" name="link_title" id="editLinkTitle" class="form-control" required>
                </div>
                <div class="form-group" style="margin-bottom: 15px;">
                    <label>URL *</label>
                    <input type="text" name="link_url" id="editLinkUrl" class="form-control" required>
                </div>
                <div class="form-group" style="margin-bottom: 15px;">
                    <label>İkon</label>
                    <input type="text" name="link_icon" id="editLinkIcon" class="form-control" placeholder="fas fa-link">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Hedef</label>
                        <select name="link_target" id="editLinkTarget" class="form-control">
                            <option value="_self">Aynı Sayfa</option>
                            <option value="_blank">Yeni Sekme</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Sıra</label>
                        <input type="number" name="link_sort_order" id="editLinkOrder" class="form-control" min="0">
                    </div>
                </div>
                <div class="form-group" style="margin-top: 15px;">
                    <label>Durum</label>
                    <select name="link_status" id="editLinkStatus" class="form-control">
                        <option value="active">Aktif</option>
                        <option value="inactive">Pasif</option>
                    </select>
                </div>
            </div>
            <div class="modal-foot">
                <button type="button" class="btn btn-secondary" onclick="closeModal('linkModal')">İptal</button>
                <button type="submit" class="btn btn-primary">Kaydet</button>
            </div>
        </form>
    </div>
</div>

<!-- SOSYAL MEDYA DÜZENLEME MODAL -->
<div class="modal-bg" id="socialModal">
    <div class="modal-box">
        <div class="modal-head">
            <h3><i class="fas fa-edit"></i> Sosyal Medya Düzenle</h3>
            <button type="button" class="modal-close" onclick="closeModal('socialModal')">&times;</button>
        </div>
        <form method="POST">
            <div class="modal-body">
                <input type="hidden" name="action" value="edit_social">
                <input type="hidden" name="social_id" id="editSocialId">
                
                <div class="form-group" style="margin-bottom: 15px;">
                    <label>Platform Adı *</label>
                    <input type="text" name="social_platform" id="editSocialPlatform" class="form-control" required>
                </div>
                <div class="form-group" style="margin-bottom: 15px;">
                    <label>URL *</label>
                    <input type="url" name="social_url" id="editSocialUrl" class="form-control" required>
                </div>
                <div class="form-group" style="margin-bottom: 15px;">
                    <label>İkon (Font Awesome) *</label>
                    <input type="text" name="social_icon" id="editSocialIcon" class="form-control" required>
                    <small>Örn: fab fa-instagram</small>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Sıralama</label>
                        <input type="number" name="social_sort_order" id="editSocialOrder" class="form-control" min="0">
                    </div>
                    <div class="form-group">
                        <label>Durum</label>
                        <select name="social_status" id="editSocialStatus" class="form-control">
                            <option value="active">Aktif</option>
                            <option value="inactive">Pasif</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-foot">
                <button type="button" class="btn btn-secondary" onclick="closeModal('socialModal')">İptal</button>
                <button type="submit" class="btn btn-primary">Kaydet</button>
            </div>
        </form>
    </div>
</div>

<script>
// Modal kapat
function closeModal(id) {
    document.getElementById(id).classList.remove('show');
}

// Bölüm düzenle
function editSection(s) {
    document.getElementById('editSectionId').value = s.id;
    document.getElementById('editSectionTitle').value = s.title;
    document.getElementById('editSectionOrder').value = s.sort_order;
    document.getElementById('editSectionStatus').value = s.status;
    document.getElementById('sectionModal').classList.add('show');
}

// Link düzenle
function editLink(l) {
    document.getElementById('editLinkId').value = l.id;
    document.getElementById('editLinkSection').value = l.section_id;
    document.getElementById('editLinkTitle').value = l.title;
    document.getElementById('editLinkUrl').value = l.url;
    document.getElementById('editLinkIcon').value = l.icon || '';
    document.getElementById('editLinkTarget').value = l.target;
    document.getElementById('editLinkOrder').value = l.sort_order;
    document.getElementById('editLinkStatus').value = l.status;
    document.getElementById('linkModal').classList.add('show');
}

// Sosyal medya düzenle
function editSocial(s) {
    document.getElementById('editSocialId').value = s.id;
    document.getElementById('editSocialPlatform').value = s.platform;
    document.getElementById('editSocialUrl').value = s.url;
    document.getElementById('editSocialIcon').value = s.icon;
    document.getElementById('editSocialOrder').value = s.sort_order;
    document.getElementById('editSocialStatus').value = s.status;
    document.getElementById('socialModal').classList.add('show');
}

// Sosyal medya seç
function pickSocial(el) {
    document.querySelectorAll('.social-btn').forEach(b => b.classList.remove('selected'));
    el.classList.add('selected');
    document.getElementById('selectedIcon').value = el.dataset.icon;
    document.getElementById('socialName').value = el.dataset.name;
}

// Modal dışına tıklayınca kapat
document.querySelectorAll('.modal-bg').forEach(m => {
    m.addEventListener('click', function(e) {
        if (e.target === this) this.classList.remove('show');
    });
});

// ESC ile kapat
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-bg.show').forEach(m => m.classList.remove('show'));
    }
});
</script>
<?php endif; ?>

<?php require_once 'footer.php'; ?>