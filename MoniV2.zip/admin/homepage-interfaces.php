<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';
require_once __DIR__ . '/../includes/MoniHomepage.php';

if (!isLoggedIn() || !isAdmin()) {
    header('Location:index.php');
    exit;
}
if (function_exists('moni_staff_can') && !moni_staff_can($db, 'settings.manage')) {
    http_response_code(403);
    exit('Yetkiniz yok.');
}

$tableReady = moni_home_table_ready($db);
if (function_exists('moni_home_seed_translations')) {
    moni_home_seed_translations($db);
}

function hp_upload_image(string $field, string $current = ''): string
{
    if (empty($_FILES[$field]) || ($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return $current;
    }
    $file = $_FILES[$field];
    if (($file['error'] ?? 1) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Görsel yüklenemedi.');
    }
    if ((int) $file['size'] > 6 * 1024 * 1024) {
        throw new RuntimeException('Görsel en fazla 6 MB olabilir.');
    }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    if (!isset($allowed[$mime])) {
        throw new RuntimeException('Yalnız JPG, PNG, WEBP veya GIF yüklenebilir.');
    }
    $directory = dirname(__DIR__) . '/uploads/homepage-interfaces';
    if (!is_dir($directory) && !mkdir($directory, 0755, true)) {
        throw new RuntimeException('Görsel klasörü oluşturulamadı.');
    }
    $name = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
    $target = $directory . '/' . $name;
    if (!move_uploaded_file($file['tmp_name'], $target)) {
        throw new RuntimeException('Görsel kaydedilemedi.');
    }
    @chmod($target, 0644);
    return '/uploads/homepage-interfaces/' . $name;
}

$layoutMeta = [
    'nebula' => ['Nebula Suite', 'Premium hizmet vitrini', 'Derin koyu zemin, 3B sosyal medya hizmet görseli ve güçlü güven kartları.'],
    'ivory' => ['Ivory Social', 'Aydınlık ve samimi', 'İçerik üreticisi görseli, hızlı katalog kartı ve ferah ticari düzen.'],
    'pulse' => ['Pulse Creator', 'Kampanya odaklı', 'Merkez kompozisyon, yaratıcı görseli ve hareketli sosyal kanıt kartları.'],
    'aurora' => ['Aurora Commerce', 'Bento ve hizmet odaklı', 'Sosyal medya hizmet görseli, asimetrik bento kartlar ve güçlü müşteri mesajları.'],
    'glass' => ['Glass Flow', 'Cam yüzeyli premium', 'Transparan mobil panel görseli, blur ışıklar ve modern güven rozetleri.'],
    'editorial' => ['Editorial Trust', 'Kurumsal ve iddialı', 'Büyük tipografi, güçlü insan görseli ve dergi karakterinde sade düzen.'],
    'market' => ['Market Hub', 'Katalog ve mağaza', 'Servis arama, kategori keşfi ve ticaret odaklı sosyal medya görseli.'],
    'neon' => ['Neon Social', 'Dinamik ve enerjik', 'Sosyal medya hizmet ekranı, yörünge ikonları ve canlı kampanya atmosferi.'],
];

$palettes = [
    'nebula' => ['#070B18', '#10172B', '#151E36', '#F8FAFC', '#9BA8C7', '#7C5CFC', '#20D6A4', '#43C7FF', '#FFFFFF', '#080D1B', '#F8FAFC', '#253151'],
    'ivory' => ['#F7F8FC', '#FFFFFF', '#EEF2F8', '#17213A', '#64748B', '#5B4EF5', '#13B98E', '#FF6B8A', '#FFFFFF', '#FFFFFF', '#17213A', '#DCE3EF'],
    'pulse' => ['#0D0E14', '#181923', '#222431', '#FAFAFC', '#A9ADBD', '#FF4D8D', '#8B5CF6', '#FFB547', '#FFFFFF', '#0D0E14', '#FFFFFF', '#2D3040'],
    'aurora' => ['#08111F', '#0F1B31', '#142441', '#F3F8FF', '#91A4C2', '#5B5CF0', '#16C995', '#31D6E7', '#FFFFFF', '#08101D', '#F8FAFC', '#263B5A'],
    'glass' => ['#071119', '#0D1B26', '#132633', '#F3FAFC', '#91A9B6', '#9B6BFF', '#24CDB3', '#5AC8FA', '#FFFFFF', '#08121A', '#F8FAFC', '#294452'],
    'editorial' => ['#F4F0E8', '#FBF9F4', '#EAE3D7', '#171717', '#6B645A', '#7D3D67', '#B26136', '#D77943', '#FFFFFF', '#F4F0E8', '#171717', '#D8D0C2'],
    'market' => ['#F7FAFC', '#FFFFFF', '#EDF3F6', '#172033', '#64748B', '#0F766E', '#16A34A', '#F97316', '#FFFFFF', '#FFFFFF', '#172033', '#DCE5EA'],
    'neon' => ['#050816', '#0B1022', '#111833', '#F5F7FF', '#8D99B7', '#00CFA5', '#8B5CF6', '#00D9FF', '#04110E', '#060918', '#F5F7FF', '#1D2A4D'],
];

$colorKeys = [
    'background_color', 'surface_color', 'surface_alt_color', 'text_color', 'muted_color', 'primary_color',
    'secondary_color', 'accent_color', 'button_text_color', 'header_bg_color', 'header_text_color', 'border_color',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $tableReady) {
    $id = (int) ($_POST['id'] ?? 0);
    $action = $_POST['action'] ?? '';
    try {
        if (!csrf_check($_POST['_token'] ?? '')) {
            throw new RuntimeException('Güvenlik doğrulaması başarısız.');
        }

        if ($action === 'activate') {
            $query = $db->prepare('SELECT is_enabled FROM homepage_interfaces WHERE id=?');
            $query->execute([$id]);
            if (!(int) $query->fetchColumn()) {
                throw new RuntimeException('Pasif arayüz aktif edilemez.');
            }
            $db->beginTransaction();
            $db->exec('UPDATE homepage_interfaces SET is_active=0');
            $db->prepare('UPDATE homepage_interfaces SET is_active=1 WHERE id=?')->execute([$id]);
            $db->commit();
            setAlert('Ana sayfa arayüzü aktif edildi.', 'success');
        } elseif ($action === 'toggle') {
            $query = $db->prepare('SELECT is_active,is_enabled FROM homepage_interfaces WHERE id=?');
            $query->execute([$id]);
            $row = $query->fetch();
            if (!$row) {
                throw new RuntimeException('Kayıt bulunamadı.');
            }
            if ($row['is_active']) {
                throw new RuntimeException('Aktif arayüz pasife alınamaz; önce başka bir arayüz seçin.');
            }
            $db->prepare('UPDATE homepage_interfaces SET is_enabled=? WHERE id=?')->execute([$row['is_enabled'] ? 0 : 1, $id]);
            setAlert('Arayüz durumu güncellendi.', 'success');
        } elseif ($action === 'delete') {
            $query = $db->prepare('SELECT is_active FROM homepage_interfaces WHERE id=?');
            $query->execute([$id]);
            if ((int) $query->fetchColumn()) {
                throw new RuntimeException('Aktif arayüz silinemez.');
            }
            $db->prepare('DELETE FROM homepage_interfaces WHERE id=?')->execute([$id]);
            setAlert('Arayüz silindi.', 'success');
        } elseif ($action === 'duplicate') {
            $query = $db->prepare('SELECT * FROM homepage_interfaces WHERE id=?');
            $query->execute([$id]);
            $row = $query->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                throw new RuntimeException('Arayüz bulunamadı.');
            }
            unset($row['id'], $row['created_at'], $row['updated_at']);
            $row['slug'] .= '-' . substr(bin2hex(random_bytes(3)), 0, 6);
            $row['name'] .= ' Kopya';
            $row['is_active'] = 0;
            $columns = array_keys($row);
            $db->prepare('INSERT INTO homepage_interfaces (`' . implode('`,`', $columns) . '`) VALUES (' . implode(',', array_fill(0, count($columns), '?')) . ')')->execute(array_values($row));
            setAlert('Arayüz kopyalandı.', 'success');
        } elseif (in_array($action, ['save', 'create'], true)) {
            $layout = array_key_exists($_POST['layout_key'] ?? '', $layoutMeta) ? $_POST['layout_key'] : 'nebula';
            $name = trim($_POST['name'] ?? '');
            if ($name === '') {
                throw new RuntimeException('Arayüz adı zorunludur.');
            }
            $slug = strtolower(trim(preg_replace('/[^a-z0-9]+/i', '-', $_POST['slug'] ?? $name), '-'));
            if ($slug === '') {
                $slug = 'arayuz-' . substr(bin2hex(random_bytes(3)), 0, 6);
            }

            $current = ['hero_image' => '', 'secondary_image' => '', 'background_image' => '', 'is_active' => 0];
            if ($id) {
                $query = $db->prepare('SELECT * FROM homepage_interfaces WHERE id=?');
                $query->execute([$id]);
                $current = $query->fetch(PDO::FETCH_ASSOC) ?: $current;
            }
            if ($id && !empty($current['is_active']) && empty($_POST['is_enabled'])) {
                throw new RuntimeException('Aktif arayüz pasife alınamaz; önce başka bir arayüzü aktif edin.');
            }
            foreach (['hero_image', 'secondary_image', 'background_image'] as $field) {
                if (!empty($_POST['remove_' . $field])) {
                    $current[$field] = '';
                }
                $current[$field] = hp_upload_image($field, $current[$field] ?? '');
            }

            $options = [];
            foreach (['stats', 'categories', 'features', 'process', 'services', 'reviews', 'faq', 'blog', 'cta'] as $section) {
                $options[$section] = !empty($_POST['section_' . $section]) ? 1 : 0;
            }
            $safeColors = [];
            foreach ($colorKeys as $index => $key) {
                $safeColors[$key] = moni_home_hex($_POST[$key] ?? '', $palettes[$layout][$index]);
            }

            $values = [
                $name, $slug, $layout, trim($_POST['description'] ?? ''), !empty($_POST['is_enabled']) ? 1 : 0,
                ...array_values($safeColors),
                trim($_POST['hero_badge'] ?? ''), trim($_POST['hero_title'] ?? ''), trim($_POST['hero_description'] ?? ''),
                trim($_POST['primary_cta_text'] ?? ''), trim($_POST['primary_cta_url'] ?? ''),
                trim($_POST['secondary_cta_text'] ?? ''), trim($_POST['secondary_cta_url'] ?? ''),
                $current['hero_image'], $current['secondary_image'], $current['background_image'],
                !empty($_POST['announcement_enabled']) ? 1 : 0, trim($_POST['announcement_text'] ?? ''),
                trim($_POST['announcement_cta_text'] ?? ''), trim($_POST['announcement_cta_url'] ?? ''),
                json_encode($options, JSON_UNESCAPED_UNICODE), moni_home_sanitize_css(trim($_POST['custom_css'] ?? '')),
                (int) ($_POST['sort_order'] ?? 0),
            ];

            if ($id) {
                $sql = 'UPDATE homepage_interfaces SET name=?,slug=?,layout_key=?,description=?,is_enabled=?,background_color=?,surface_color=?,surface_alt_color=?,text_color=?,muted_color=?,primary_color=?,secondary_color=?,accent_color=?,button_text_color=?,header_bg_color=?,header_text_color=?,border_color=?,hero_badge=?,hero_title=?,hero_description=?,primary_cta_text=?,primary_cta_url=?,secondary_cta_text=?,secondary_cta_url=?,hero_image=?,secondary_image=?,background_image=?,announcement_enabled=?,announcement_text=?,announcement_cta_text=?,announcement_cta_url=?,options_json=?,custom_css=?,sort_order=? WHERE id=?';
                $values[] = $id;
                $db->prepare($sql)->execute($values);
                setAlert('Arayüz kaydedildi.', 'success');
            } else {
                $sql = 'INSERT INTO homepage_interfaces(name,slug,layout_key,description,is_enabled,is_active,background_color,surface_color,surface_alt_color,text_color,muted_color,primary_color,secondary_color,accent_color,button_text_color,header_bg_color,header_text_color,border_color,hero_badge,hero_title,hero_description,primary_cta_text,primary_cta_url,secondary_cta_text,secondary_cta_url,hero_image,secondary_image,background_image,announcement_enabled,announcement_text,announcement_cta_text,announcement_cta_url,options_json,custom_css,sort_order) VALUES(?,?,?,?,?,0,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
                $db->prepare($sql)->execute($values);
                setAlert('Yeni ana sayfa arayüzü oluşturuldu.', 'success');
            }
        }
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        setAlert($e->getMessage(), 'danger');
    }

    header('Location: homepage-interfaces.php' . ($id && $action === 'save' ? '?edit=' . $id : ''));
    exit;
}

$rows = [];
$edit = null;
if ($tableReady) {
    $rows = $db->query('SELECT * FROM homepage_interfaces ORDER BY is_active DESC,sort_order,id')->fetchAll(PDO::FETCH_ASSOC);
    if (isset($_GET['edit'])) {
        $query = $db->prepare('SELECT * FROM homepage_interfaces WHERE id=?');
        $query->execute([(int) $_GET['edit']]);
        $edit = $query->fetch(PDO::FETCH_ASSOC);
    }
}

$creating = isset($_GET['new']);
$pageTitle = 'Ana Sayfa Arayüzleri';
require_once 'header.php';

$defaults = $edit ?: [
    'id' => 0, 'name' => 'Yeni Arayüz', 'slug' => '', 'layout_key' => 'nebula', 'description' => '', 'is_enabled' => 1,
    'background_color' => '#070B18', 'surface_color' => '#10172B', 'surface_alt_color' => '#151E36',
    'text_color' => '#F8FAFC', 'muted_color' => '#9BA8C7', 'primary_color' => '#7C5CFC',
    'secondary_color' => '#20D6A4', 'accent_color' => '#43C7FF', 'button_text_color' => '#FFFFFF',
    'header_bg_color' => '#080D1B', 'header_text_color' => '#F8FAFC', 'border_color' => '#253151',
    'hero_badge' => 'Hızlı, güvenli ve kolay sipariş',
    'hero_title' => 'Sosyal medya hizmetlerini tek yerden yönetin',
    'hero_description' => 'Instagram, TikTok, YouTube ve daha fazlası için güncel hizmetleri keşfedin; hesabınızı oluşturup hemen sipariş verin.',
    'primary_cta_text' => 'Ücretsiz Başla', 'primary_cta_url' => '/register.php',
    'secondary_cta_text' => 'Servisleri İncele', 'secondary_cta_url' => '/services.php',
    'hero_image' => '', 'secondary_image' => '', 'background_image' => '',
    'announcement_enabled' => 0, 'announcement_text' => '', 'announcement_cta_text' => '', 'announcement_cta_url' => '',
    'options_json' => '{}', 'custom_css' => '', 'sort_order' => 0,
];
$defaults['layout_key'] = array_key_exists($defaults['layout_key'], $layoutMeta) ? $defaults['layout_key'] : 'nebula';
$options = json_decode($defaults['options_json'] ?? '{}', true) ?: [];
$translationIdentity = strtolower(trim(preg_replace('/[^a-z0-9]+/i', '_', (string) ($defaults['slug'] ?: $defaults['layout_key'])), '_')) ?: 'default';
$translationPrefix = 'homepage_interface_' . $translationIdentity . '_';
?>
<link rel="stylesheet" href="<?= rtrim(SITE_URL, '/') ?>/assets/css/homepage-admin.css?v=2.5.0">

<div class="hpi-page-head">
    <div>
        <span class="hpi-eyebrow">Ana sayfa görünüm stüdyosu</span>
        <h1><i class="fas fa-wand-magic-sparkles"></i> Ana Sayfa Arayüzleri</h1>
        <p>Sekiz profesyonel vitrin arasından seçim yapın; metin, renk, bölüm ve görselleri kaydetmeden gerçek ana sayfa üzerinde izleyin.</p>
    </div>
    <?php if ($tableReady && !$edit && !$creating): ?>
        <a class="moni-btn" href="?new=1"><i class="fas fa-plus"></i> Yeni Arayüz</a>
    <?php endif; ?>
</div>

<?php if (!$tableReady): ?>
    <div class="moni-alert danger"><strong>Mevcut veritabanı yapısı eksik.</strong> Kurulumunuzdaki homepage_interfaces tablosunu kontrol edin. Bu tasarım güncellemesi yeni bir SQL şeması eklemez.</div>
<?php elseif ($edit || $creating): ?>
    <div class="hpi-workspace">
        <form id="interfaceForm" class="hpi-editor" method="post" enctype="multipart/form-data" data-preview-endpoint="homepage-preview.php?embedded=1">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="<?= $edit ? 'save' : 'create' ?>">
            <input type="hidden" name="id" value="<?= (int) $defaults['id'] ?>">

            <section class="hpi-panel">
                <div class="hpi-panel-head"><span><i class="fas fa-fingerprint"></i> Kimlik ve düzen</span><small>Temel yapı</small></div>
                <div class="hpi-form-grid">
                    <label class="hpi-field"><span>Arayüz adı</span><input name="name" required value="<?= clean($defaults['name']) ?>"></label>
                    <label class="hpi-field"><span>Slug</span><input name="slug" value="<?= clean($defaults['slug']) ?>" placeholder="otomatik-olusturulur"></label>
                    <label class="hpi-field full"><span>Tasarım karakteri</span><select name="layout_key" id="layoutKey"><?php foreach ($layoutMeta as $key => $meta): ?><option value="<?= $key ?>" data-description="<?= clean($meta[2]) ?>" <?= $defaults['layout_key'] === $key ? 'selected' : '' ?>><?= clean($meta[0]) ?> — <?= clean($meta[1]) ?></option><?php endforeach; ?></select><small id="layoutDescription"><?= clean($layoutMeta[$defaults['layout_key']][2]) ?></small></label>
                    <label class="hpi-field"><span>Sıra</span><input type="number" name="sort_order" value="<?= (int) $defaults['sort_order'] ?>"></label>
                    <label class="hpi-switch"><input type="checkbox" name="is_enabled" <?= $defaults['is_enabled'] ? 'checked' : '' ?>><span></span> Kullanılabilir</label>
                    <label class="hpi-field full"><span>Kısa açıklama</span><input name="description" value="<?= clean($defaults['description']) ?>"></label>
                </div>
            </section>

            <section class="hpi-panel">
                <div class="hpi-panel-head"><span><i class="fas fa-palette"></i> Renk sistemi</span><button class="hpi-text-button" type="button" id="applyPalette"><i class="fas fa-rotate"></i> Önerilen paleti uygula</button></div>
                <div class="hpi-colors">
                    <?php foreach (['background_color' => 'Arka plan', 'surface_color' => 'Kart', 'surface_alt_color' => 'İkincil yüzey', 'text_color' => 'Ana yazı', 'muted_color' => 'Soluk yazı', 'primary_color' => 'Ana vurgu', 'secondary_color' => 'İkincil vurgu', 'accent_color' => 'Parlak vurgu', 'button_text_color' => 'Buton yazı', 'header_bg_color' => 'Header', 'header_text_color' => 'Header yazı', 'border_color' => 'Kenarlık'] as $key => $label): ?>
                        <label class="hpi-color"><input type="color" name="<?= $key ?>" value="<?= clean($defaults[$key]) ?>"><span><?= $label ?><small><?= clean($defaults[$key]) ?></small></span></label>
                    <?php endforeach; ?>
                </div>
            </section>

            <section class="hpi-panel">
                <div class="hpi-panel-head"><span><i class="fas fa-pen-nib"></i> Hero içeriği</span><small>İlk izlenim</small></div>
                <p class="hpi-help"><i class="fas fa-language"></i> Buradaki metinler varsayılan dili belirler. Diğer diller için <a href="translations.php?search=<?= clean($translationPrefix) ?>">Çeviriler</a> ekranındaki <code><?= clean($translationPrefix) ?>…</code> anahtarlarını düzenleyin.</p>
                <div class="hpi-form-grid">
                    <label class="hpi-field full"><span>Üst rozet</span><input name="hero_badge" value="<?= clean($defaults['hero_badge']) ?>"></label>
                    <label class="hpi-field full"><span>Ana başlık</span><input name="hero_title" value="<?= clean($defaults['hero_title']) ?>"></label>
                    <label class="hpi-field full"><span>Açıklama</span><textarea rows="3" name="hero_description"><?= clean($defaults['hero_description']) ?></textarea></label>
                    <label class="hpi-field"><span>Birincil buton</span><input name="primary_cta_text" value="<?= clean($defaults['primary_cta_text']) ?>"></label>
                    <label class="hpi-field"><span>Bağlantı</span><input name="primary_cta_url" value="<?= clean($defaults['primary_cta_url']) ?>"></label>
                    <label class="hpi-field"><span>İkincil buton</span><input name="secondary_cta_text" value="<?= clean($defaults['secondary_cta_text']) ?>"></label>
                    <label class="hpi-field"><span>Bağlantı</span><input name="secondary_cta_url" value="<?= clean($defaults['secondary_cta_url']) ?>"></label>
                </div>
            </section>

            <section class="hpi-panel">
                <div class="hpi-panel-head"><span><i class="fas fa-images"></i> Görsel stüdyosu</span><small>6 MB'a kadar</small></div>
                <p class="hpi-help">Görsel yüklemezseniz her tasarım, paketle gelen profesyonel SMM görselini otomatik kullanır.</p>
                <div class="hpi-upload-grid">
                    <?php foreach (['hero_image' => ['Hero görseli', 'Ana görselin yerini alır'], 'secondary_image' => ['İkincil görsel', 'Kolaj üzerinde küçük kart'], 'background_image' => ['Arka plan', 'Hero arkasında kaplama']] as $key => $meta): ?>
                        <div class="hpi-upload"><i class="fas fa-cloud-arrow-up"></i><strong><?= $meta[0] ?></strong><span><?= $meta[1] ?></span><input type="file" name="<?= $key ?>" accept="image/jpeg,image/png,image/webp,image/gif"><?php if ($defaults[$key]): ?><img src="<?= clean($defaults[$key]) ?>" alt=""><label class="hpi-remove"><input type="checkbox" name="remove_<?= $key ?>"> Mevcut görseli kaldır</label><?php endif; ?></div>
                    <?php endforeach; ?>
                </div>
            </section>

            <section class="hpi-panel">
                <div class="hpi-panel-head"><span><i class="fas fa-bullhorn"></i> Kampanya şeridi</span><small>İsteğe bağlı</small></div>
                <div class="hpi-form-grid">
                    <label class="hpi-switch full"><input type="checkbox" name="announcement_enabled" <?= $defaults['announcement_enabled'] ? 'checked' : '' ?>><span></span> Üst kampanya şeridini göster</label>
                    <label class="hpi-field full"><span>Metin</span><input name="announcement_text" value="<?= clean($defaults['announcement_text']) ?>" placeholder="Yeni servisleri ve güncel avantajları keşfedin."></label>
                    <label class="hpi-field"><span>Aksiyon metni</span><input name="announcement_cta_text" value="<?= clean($defaults['announcement_cta_text']) ?>"></label>
                    <label class="hpi-field"><span>Bağlantı</span><input name="announcement_cta_url" value="<?= clean($defaults['announcement_cta_url']) ?>"></label>
                </div>
            </section>

            <section class="hpi-panel">
                <div class="hpi-panel-head"><span><i class="fas fa-layer-group"></i> Ana sayfa bölümleri</span><small>Göster / gizle</small></div>
                <div class="hpi-checks">
                    <?php foreach (['stats' => ['Gerçek istatistikler', 'fa-chart-simple'], 'categories' => ['Kategoriler', 'fa-table-cells-large'], 'features' => ['Özellikler', 'fa-gem'], 'process' => ['Nasıl çalışır', 'fa-route'], 'services' => ['Popüler servisler', 'fa-bolt'], 'reviews' => ['Doğrulanmış yorumlar', 'fa-star'], 'faq' => ['Sık sorulanlar', 'fa-circle-question'], 'blog' => ['Blog', 'fa-newspaper'], 'cta' => ['Final çağrı', 'fa-arrow-pointer']] as $key => $item): ?>
                        <label><input type="checkbox" name="section_<?= $key ?>" <?= (!array_key_exists($key, $options) || $options[$key]) ? 'checked' : '' ?>><i class="fas <?= $item[1] ?>"></i><span><?= $item[0] ?></span></label>
                    <?php endforeach; ?>
                </div>
            </section>

            <details class="hpi-panel hpi-advanced">
                <summary><span><i class="fas fa-code"></i> Gelişmiş CSS</span><small>Uzman ayarı</small></summary>
                <label class="hpi-field"><span>Yalnız bu ana sayfaya özel CSS</span><textarea name="custom_css" rows="8" spellcheck="false"><?= clean($defaults['custom_css']) ?></textarea></label>
            </details>

            <div class="hpi-savebar"><div><i class="fas fa-circle-info"></i> Önizleme otomatik yenilenir; değişiklikler yalnız kaydettiğinizde yayınlanır.</div><a class="moni-btn secondary" href="homepage-interfaces.php">Vazgeç</a><button class="moni-btn"><i class="fas fa-floppy-disk"></i> Kaydet</button></div>
        </form>

        <aside class="hpi-live-panel">
            <div class="hpi-live-head"><div><span class="hpi-live-dot"></span><div><strong>Canlı önizleme</strong><small id="previewStatus">Hazır</small></div></div><button type="button" id="refreshPreview" title="Yenile"><i class="fas fa-rotate-right"></i></button></div>
            <div class="hpi-device-bar" role="group" aria-label="Önizleme boyutu"><button type="button" class="active" data-device="desktop" title="1440 px masaüstü görünümü"><i class="fas fa-display"></i> Masaüstü <small>1440</small></button><button type="button" data-device="tablet" title="834 px tablet görünümü"><i class="fas fa-tablet-screen-button"></i><small>834</small></button><button type="button" data-device="mobile" title="390 px mobil görünümü"><i class="fas fa-mobile-screen-button"></i><small>390</small></button></div>
            <div class="hpi-frame-stage"><div class="hpi-frame-shell" data-device="desktop" data-preview-message="Tema hazırlanıyor…"><iframe id="homepagePreview" name="moniHomepagePreviewFrame" title="Ana sayfa canlı önizleme" sandbox="allow-scripts allow-same-origin" src="about:blank"></iframe></div></div>
            <p><i class="fas fa-lock"></i> Bu önizleme yalnız yönetici oturumunda çalışır ve kaydedilmemiş içeriği yayınlamaz.</p>
        </aside>
    </div>

<?php else: ?>
    <div class="hpi-summary"><div><i class="fas fa-layer-group"></i><span><b><?= count($rows) ?></b> arayüz</span></div><div><i class="fas fa-circle-check"></i><span><b><?= count(array_filter($rows, static fn($row) => $row['is_enabled'])) ?></b> kullanıma hazır</span></div><p>Kartlardaki önizleme tasarımın kendi görselini ve kayıtlı renklerini kullanır. Tam sayfa görünüm için <b>Canlı önizle</b> seçeneğini açın.</p></div>
    <div class="hpi-grid">
        <?php foreach ($rows as $row): $layout = $row['layout_key']; ?>
            <article class="hpi-card <?= $row['is_active'] ? 'is-active' : '' ?>" style="--preview-bg:<?= clean($row['background_color']) ?>;--preview-surface:<?= clean($row['surface_color']) ?>;--preview-text:<?= clean($row['text_color']) ?>;--preview-primary:<?= clean($row['primary_color']) ?>;--preview-accent:<?= clean($row['accent_color']) ?>;--preview-border:<?= clean($row['border_color']) ?>">
                <button type="button" class="hpi-card-preview" data-preview-id="<?= (int) $row['id'] ?>" aria-label="<?= clean($row['name']) ?> canlı önizle">
                    <span class="hpi-mini-nav"><i></i><i></i><i></i></span>
                    <span class="hpi-mini-copy"><b></b><strong></strong><em></em><small></small></span>
                    <img src="<?= clean(moni_home_default_visual($layout)) ?>" alt="">
                    <span class="hpi-preview-action"><i class="fas fa-expand"></i> Canlı önizle</span>
                </button>
                <div class="hpi-card-body">
                    <div class="hpi-card-title"><div><strong><?= clean($row['name']) ?></strong><small><?= clean($layoutMeta[$layout][0] ?? $layout) ?></small></div><span class="hpi-state <?= $row['is_active'] ? 'live' : ($row['is_enabled'] ? 'ready' : 'off') ?>"><?= $row['is_active'] ? 'Kullanımda' : ($row['is_enabled'] ? 'Hazır' : 'Pasif') ?></span></div>
                    <p><?= clean($row['description']) ?></p>
                    <div class="hpi-swatches"><i style="background:<?= clean($row['primary_color']) ?>"></i><i style="background:<?= clean($row['secondary_color']) ?>"></i><i style="background:<?= clean($row['accent_color']) ?>"></i><span><?= clean($layoutMeta[$layout][1] ?? '') ?></span></div>
                    <div class="hpi-actions">
                        <?php if (!$row['is_active'] && $row['is_enabled']): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="activate"><input type="hidden" name="id" value="<?= (int) $row['id'] ?>"><button class="moni-btn sm"><i class="fas fa-check"></i> Aktif Et</button></form><?php endif; ?>
                        <a class="moni-btn secondary sm" href="?edit=<?= (int) $row['id'] ?>"><i class="fas fa-sliders"></i> Düzenle</a>
                        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="duplicate"><input type="hidden" name="id" value="<?= (int) $row['id'] ?>"><button class="moni-btn secondary sm" title="Kopyala"><i class="fas fa-copy"></i></button></form>
                        <?php if (!$row['is_active']): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $row['id'] ?>"><button class="moni-btn secondary sm" title="<?= $row['is_enabled'] ? 'Pasife al' : 'Aktifleştir' ?>"><i class="fas <?= $row['is_enabled'] ? 'fa-toggle-on' : 'fa-toggle-off' ?>"></i></button></form><form method="post" onsubmit="return confirm('Bu arayüz silinsin mi?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $row['id'] ?>"><button class="moni-btn danger sm" title="Sil"><i class="fas fa-trash"></i></button></form><?php endif; ?>
                    </div>
                </div>
            </article>
        <?php endforeach; ?>
    </div>

    <dialog class="hpi-dialog" id="previewDialog" data-preview-endpoint="homepage-preview.php"><div class="hpi-dialog-head"><div><span class="hpi-live-dot"></span><strong>Canlı ana sayfa önizlemesi</strong></div><button type="button" id="closePreview"><i class="fas fa-xmark"></i></button></div><iframe id="dialogFrame" title="Ana sayfa önizlemesi" sandbox="allow-scripts allow-same-origin" src="about:blank"></iframe></dialog>
<?php endif; ?>

<script src="<?= rtrim(SITE_URL, '/') ?>/assets/js/homepage-admin.js?v=2.5.0" defer></script>
<?php require_once 'footer.php'; ?>
