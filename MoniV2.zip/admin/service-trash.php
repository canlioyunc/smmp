<?php
require_once __DIR__.'/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';
require_once __DIR__.'/../includes/MoniAdminUI.php';
if(!isLoggedIn()||!isAdmin()){header('Location: index.php');exit;}
if(function_exists('moni_require_staff_permission'))moni_require_staff_permission($db,'services.manage');

$message='';$error='';$trashReady=moni_table_ready($db,'service_trash');

function moni_trash_purge_service(PDO $db,int $id,bool $trashReady): array {
    if($id<=0)return ['ok'=>false,'blocked'=>false,'message'=>'Geçersiz servis.'];
    $check=$db->prepare("SELECT COUNT(*) FROM orders WHERE service_id=?");$check->execute([$id]);
    if((int)$check->fetchColumn()>0)return ['ok'=>false,'blocked'=>true,'message'=>'Sipariş geçmişi bulunduğu için korundu.'];
    try{
        $db->beginTransaction();
        if($trashReady)$db->prepare("DELETE FROM service_trash WHERE service_id=?")->execute([$id]);
        $st=$db->prepare("DELETE FROM services WHERE id=? AND deleted_at IS NOT NULL");$st->execute([$id]);
        if($st->rowCount()<1){$db->rollBack();return ['ok'=>false,'blocked'=>false,'message'=>'Arşivlenmiş servis bulunamadı.'];}
        $db->commit();
        return ['ok'=>true,'blocked'=>false,'message'=>'Kalıcı silindi.'];
    }catch(Throwable $e){if($db->inTransaction())$db->rollBack();return ['ok'=>false,'blocked'=>false,'message'=>$e->getMessage()];}
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        if(!csrf_check($_POST['_token']??''))throw new RuntimeException('Güvenlik doğrulaması başarısız.');
        $singleRestore=isset($_POST['restore']);$singlePurge=isset($_POST['purge']);
        $bulkAction=trim((string)($_POST['bulk_action']??''));
        if(!$singleRestore&&!$singlePurge&&$bulkAction!==''){
            $ids=array_values(array_unique(array_filter(array_map('intval',(array)($_POST['selected_ids']??[])),fn($v)=>$v>0)));
            if(!$ids)throw new RuntimeException('Toplu işlem için en az bir servis seçin.');
            if(count($ids)>1000)throw new RuntimeException('Tek işlemde en fazla 1000 servis seçilebilir.');
            $restored=$purged=$blocked=$failed=0;$failedMessages=[];
            if($bulkAction==='restore'){
                foreach($ids as $id){
                    try{if(moni_restore_service($db,$id)){$restored++;moni_audit_log($db,'service.restore','service',(string)$id);}else{$failed++;}}catch(Throwable $e){$failed++;$failedMessages[]='#'.$id.': '.$e->getMessage();}
                }
                $message=$restored.' servis geri yüklendi'.($failed?' · '.$failed.' servis işlenemedi':'').'.';
            }elseif($bulkAction==='purge'){
                if(!moni_is_super_admin($db))throw new RuntimeException('Toplu kalıcı silme yalnız Süper Admin tarafından yapılabilir.');
                foreach($ids as $id){$r=moni_trash_purge_service($db,$id,$trashReady);if($r['ok']){$purged++;moni_audit_log($db,'service.purge','service',(string)$id);}elseif($r['blocked']){$blocked++;}else{$failed++;if(count($failedMessages)<5)$failedMessages[]='#'.$id.': '.$r['message'];}}
                $message=$purged.' servis kalıcı silindi';if($blocked)$message.=' · '.$blocked.' servis sipariş geçmişi nedeniyle korundu';if($failed)$message.=' · '.$failed.' servis işlenemedi';$message.='.';
            }else throw new RuntimeException('Geçersiz toplu işlem.');
            if($failedMessages)$error='İşlenemeyen örnekler: '.implode(' | ',$failedMessages);
        }else{
            $id=(int)($_POST['service_id']??0);
            if($singleRestore){if(!$id||!moni_restore_service($db,$id))throw new RuntimeException('Servis geri yüklenemedi.');$message='Servis aktif olarak geri yüklendi.';moni_audit_log($db,'service.restore','service',(string)$id);}
            elseif($singlePurge){if(!moni_is_super_admin($db))throw new RuntimeException('Kalıcı silme yalnız Süper Admin tarafından yapılabilir.');$r=moni_trash_purge_service($db,$id,$trashReady);if(!$r['ok'])throw new RuntimeException($r['message']);$message='Servis kalıcı olarak silindi.';moni_audit_log($db,'service.purge','service',(string)$id);}
        }
    }catch(Throwable $e){if($db->inTransaction())$db->rollBack();$error=$e->getMessage();}
}

$rows=[];
try{
    $trashJoin=$trashReady?"LEFT JOIN service_trash t ON t.service_id=s.id":"";
    $deletedAt=$trashReady?"COALESCE(t.deleted_at,s.deleted_at)":"s.deleted_at";
    $deletedBy=$trashReady?"COALESCE(t.deleted_by,s.deleted_by)":"s.deleted_by";
    $rows=$db->query("SELECT s.*,$deletedAt trash_deleted_at,$deletedBy trash_deleted_by,u.username deleted_by_name,c.name category_name,p.name provider_name,p.alias_name provider_alias,(SELECT COUNT(*) FROM orders o WHERE o.service_id=s.id) order_count FROM services s $trashJoin LEFT JOIN users u ON u.id=$deletedBy LEFT JOIN categories c ON c.id=s.category_id LEFT JOIN api_providers p ON p.id=s.api_provider_id WHERE s.deleted_at IS NOT NULL ORDER BY $deletedAt DESC")->fetchAll(PDO::FETCH_ASSOC);
}catch(Throwable $e){$error='Çöp kutusu kayıtları okunamadı: '.$e->getMessage();}
$total=count($rows);$protected=0;$providerCount=[];$categoryCount=[];foreach($rows as $r){if((int)($r['order_count']??0)>0)$protected++;if(!empty($r['api_provider_id']))$providerCount[$r['api_provider_id']]=1;if(!empty($r['category_id']))$categoryCount[$r['category_id']]=1;}
$pageTitle='Servis Çöp Kutusu';require_once 'header.php';echo moni_admin_ui_styles();
?>
<style>
.trash-toolbar{display:grid;grid-template-columns:minmax(220px,1.3fr) minmax(160px,.7fr) minmax(160px,.7fr);gap:10px;padding:14px;border:1px solid var(--border-color);background:var(--background-color);border-radius:14px;margin-bottom:14px}.trash-toolbar .field{position:relative}.trash-toolbar .field i{position:absolute;left:13px;top:50%;transform:translateY(-50%);opacity:.55}.trash-toolbar input,.trash-toolbar select{width:100%;min-height:42px;border:1px solid var(--border-color);background:var(--card-bg-color);color:var(--text-color);border-radius:10px;padding:9px 12px}.trash-toolbar input{padding-left:38px}.bulkbar{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:12px 14px;margin-bottom:12px;border:1px solid var(--border-color);border-radius:12px;background:var(--card-bg-color)}.bulkbar .count{font-weight:700;margin-right:auto}.trash-check{width:18px;height:18px;accent-color:var(--primary-color)}.history-badge{display:inline-flex;align-items:center;gap:5px;border-radius:999px;padding:5px 8px;font-size:.73rem;font-weight:700;background:rgba(245,158,11,.12);color:#b7791f}.safe-badge{display:inline-flex;align-items:center;gap:5px;border-radius:999px;padding:5px 8px;font-size:.73rem;font-weight:700;background:rgba(34,197,94,.12);color:#16803a}.trash-empty-filter{display:none;padding:36px;text-align:center}.trash-row.hidden{display:none}@media(max-width:900px){.trash-toolbar{grid-template-columns:1fr}.moni-table.trash-table thead{display:none}.moni-table.trash-table,.moni-table.trash-table tbody,.moni-table.trash-table tr,.moni-table.trash-table td{display:block;width:100%}.moni-table.trash-table tr{padding:14px;border-bottom:1px solid var(--border-color)}.moni-table.trash-table td{border:0;padding:5px 0 5px 42%;position:relative;min-height:30px}.moni-table.trash-table td:before{content:attr(data-label);position:absolute;left:0;width:38%;font-weight:700;opacity:.65}.moni-table.trash-table td:first-child{padding-left:0}.moni-table.trash-table td:first-child:before{display:none}.bulkbar .count{width:100%;margin-right:0}.bulkbar select,.bulkbar button{flex:1;min-width:145px}}
</style>
<div class="moni-page">
  <div class="moni-hero"><div><span class="moni-kicker"><i class="fas fa-trash-restore"></i> Güvenli servis yaşam döngüsü</span><h2>Servis Çöp Kutusu</h2><p>Arşivlenen servisleri tek tek veya topluca yönetin. Sipariş geçmişi bulunan servisler kalıcı silmede otomatik korunur.</p></div><div class="moni-hero-actions"><a class="moni-btn secondary" href="services.php"><i class="fas fa-arrow-left"></i> Servislere dön</a></div></div>
  <?php if($message):?><div class="moni-alert success"><?=clean($message)?></div><?php endif;?><?php if($error):?><div class="moni-alert danger"><?=clean($error)?></div><?php endif;?>
  <?php if(!$trashReady):?><div class="moni-alert warning"><b>Uyumluluk modu:</b> <code>service_trash</code> tablosu bulunamadığı için silinmiş servisler doğrudan <code>services.deleted_at</code> alanından gösteriliyor.</div><?php endif;?>
  <div class="moni-grid">
    <div class="moni-card quarter"><div class="moni-kpi"><i class="fas fa-trash"></i><div><strong><?=$total?></strong><span class="moni-muted">arşivlenen servis</span></div></div></div>
    <div class="moni-card quarter"><div class="moni-kpi"><i class="fas fa-shield-halved"></i><div><strong><?=$protected?></strong><span class="moni-muted">sipariş geçmişiyle korunan</span></div></div></div>
    <div class="moni-card quarter"><div class="moni-kpi"><i class="fas fa-plug"></i><div><strong><?=count($providerCount)?></strong><span class="moni-muted">sağlayıcı</span></div></div></div>
    <div class="moni-card quarter"><div class="moni-kpi"><i class="fas fa-layer-group"></i><div><strong><?=count($categoryCount)?></strong><span class="moni-muted">kategori</span></div></div></div>
    <div class="moni-card full">
      <div class="moni-card-head"><div><h3>Arşivlenen servisler</h3><p>Arayın, filtreleyin ve seçili kayıtları topluca geri yükleyin veya uygun olanları kalıcı silin.</p></div></div>
      <?php if(!$rows):?>
        <div style="padding:46px 20px;text-align:center"><i class="fas fa-trash-can" style="font-size:2rem;color:var(--accent-text-color);margin-bottom:12px"></i><h3>Çöp kutusu boş</h3><p class="moni-muted">Servisler ekranından sildiğiniz servisler burada görünecek.</p><a href="services.php" class="moni-btn secondary" style="margin-top:12px"><i class="fas fa-list"></i> Servislere Git</a></div>
      <?php else:?>
        <div class="trash-toolbar">
          <div class="field"><i class="fas fa-search"></i><input id="trashSearch" type="search" placeholder="Servis adı, ID, kategori veya sağlayıcı ara…"></div>
          <div class="field"><select id="trashProvider"><option value="">Tüm sağlayıcılar</option><?php $ps=[];foreach($rows as $r){$label=trim((string)($r['provider_alias']?:$r['provider_name']));if($label!=='')$ps[$label]=$label;}ksort($ps);foreach($ps as $v):?><option value="<?=clean(mb_strtolower($v,'UTF-8'))?>"><?=clean($v)?></option><?php endforeach;?></select></div>
          <div class="field"><select id="trashProtection"><option value="">Tüm kayıtlar</option><option value="safe">Kalıcı silinebilir</option><option value="protected">Sipariş geçmişiyle korunan</option></select></div>
        </div>
        <form method="post" id="bulkTrashForm"><?=csrf_field()?>
          <div class="bulkbar"><label style="display:flex;align-items:center;gap:8px"><input class="trash-check" type="checkbox" id="selectAllTrash"> Görünürleri seç</label><span class="count"><span id="selectedTrashCount">0</span> servis seçili</span><select class="moni-input" name="bulk_action" id="bulkAction"><option value="">Toplu işlem seçin…</option><option value="restore">Seçilileri geri yükle</option><?php if(moni_is_super_admin($db)):?><option value="purge">Seçilileri kalıcı sil</option><?php endif;?></select><button type="submit" class="moni-btn primary" id="bulkApply" disabled><i class="fas fa-play"></i> Uygula</button></div>
          <div class="moni-table-wrap"><table class="moni-table trash-table"><thead><tr><th style="width:42px"></th><th>ID</th><th>Servis</th><th>Kategori</th><th>Sağlayıcı</th><th>Silinme</th><th>Koruma</th><th>İşlem</th></tr></thead><tbody id="trashBody">
          <?php foreach($rows as $r):$providerLabel=trim((string)($r['provider_alias']?:$r['provider_name']));$protectedRow=(int)($r['order_count']??0)>0;$search=mb_strtolower(implode(' ',[$r['id'],$r['name'],$r['category_name']??'',$providerLabel,$r['deleted_by_name']??'']),'UTF-8');?>
            <tr class="trash-row" data-search="<?=clean($search)?>" data-provider="<?=clean(mb_strtolower($providerLabel,'UTF-8'))?>" data-protection="<?=$protectedRow?'protected':'safe'?>">
              <td data-label="Seç"><input class="trash-check row-check" type="checkbox" name="selected_ids[]" value="<?=$r['id']?>"></td>
              <td data-label="ID">#<?=$r['id']?></td>
              <td data-label="Servis"><strong><?=clean($r['name'])?></strong><div class="moni-muted"><?=number_format((int)$r['min_quantity'])?>–<?=number_format((int)$r['max_quantity'])?> · adım <?=number_format(max(1,(int)($r['quantity_increment']??1)))?></div></td>
              <td data-label="Kategori"><?=clean($r['category_name']??'-')?></td>
              <td data-label="Sağlayıcı"><?=clean($providerLabel?:'-')?></td>
              <td data-label="Silinme"><?=clean($r['trash_deleted_at']??$r['deleted_at']??'-')?><div class="moni-muted"><?=clean($r['deleted_by_name']??'-')?></div></td>
              <td data-label="Koruma"><?php if($protectedRow):?><span class="history-badge"><i class="fas fa-lock"></i> <?=number_format((int)$r['order_count'])?> sipariş</span><?php else:?><span class="safe-badge"><i class="fas fa-check"></i> Kalıcı silinebilir</span><?php endif;?></td>
              <td data-label="İşlem"><div class="moni-actions"><button type="submit" class="moni-btn sm" name="restore" value="1" formaction="service-trash.php" onclick="this.form.querySelector('[name=service_id]').value='<?=$r['id']?>'"><i class="fas fa-rotate-left"></i> Geri yükle</button><?php if(moni_is_super_admin($db)):?><button type="submit" class="moni-btn sm danger" name="purge" value="1" formaction="service-trash.php" onclick="if(!confirm('Sipariş geçmişi yoksa servis kalıcı silinecek. Devam?'))return false;this.form.querySelector('[name=service_id]').value='<?=$r['id']?>'"><i class="fas fa-trash"></i></button><?php endif;?></div></td>
            </tr>
          <?php endforeach;?></tbody></table></div>
          <input type="hidden" name="service_id" value="">
          <div class="trash-empty-filter" id="trashEmptyFilter"><i class="fas fa-filter" style="font-size:1.7rem;opacity:.5"></i><h3>Filtreye uygun servis yok</h3><p class="moni-muted">Arama veya filtreleri değiştirin.</p></div>
        </form>
      <?php endif;?>
    </div>
  </div>
</div>
<script>
(()=>{const search=document.getElementById('trashSearch'),provider=document.getElementById('trashProvider'),protection=document.getElementById('trashProtection'),all=document.getElementById('selectAllTrash'),rows=[...document.querySelectorAll('.trash-row')],checks=[...document.querySelectorAll('.row-check')],count=document.getElementById('selectedTrashCount'),apply=document.getElementById('bulkApply'),action=document.getElementById('bulkAction'),empty=document.getElementById('trashEmptyFilter'),form=document.getElementById('bulkTrashForm');if(!form)return;
function visibleRows(){return rows.filter(r=>!r.classList.contains('hidden'));}
function updateSelected(){const n=checks.filter(c=>c.checked).length;count.textContent=n;apply.disabled=n<1||!action.value;const vis=visibleRows().map(r=>r.querySelector('.row-check')).filter(Boolean);all.checked=vis.length>0&&vis.every(c=>c.checked);all.indeterminate=vis.some(c=>c.checked)&&!all.checked;}
function filter(){const q=(search.value||'').trim().toLocaleLowerCase('tr'),pv=provider.value,pr=protection.value;let shown=0;rows.forEach(r=>{const ok=(!q||r.dataset.search.includes(q))&&(!pv||r.dataset.provider===pv)&&(!pr||r.dataset.protection===pr);r.classList.toggle('hidden',!ok);if(ok)shown++;});empty.style.display=shown?'none':'block';updateSelected();}
[search,provider,protection].forEach(el=>el&&el.addEventListener(el.tagName==='INPUT'?'input':'change',filter));checks.forEach(c=>c.addEventListener('change',updateSelected));action.addEventListener('change',updateSelected);all.addEventListener('change',()=>{visibleRows().forEach(r=>{const c=r.querySelector('.row-check');if(c)c.checked=all.checked;});updateSelected();});form.addEventListener('submit',e=>{if(e.submitter&&['restore','purge'].includes(e.submitter.name))return;if(!action.value||checks.every(c=>!c.checked)){e.preventDefault();return;}if(action.value==='purge'&&!confirm('Seçili servislerden sipariş geçmişi olmayanlar kalıcı silinecek. Bu işlem geri alınamaz. Devam?'))e.preventDefault();});updateSelected();})();
</script>
<?php require_once 'footer.php'; ?>
