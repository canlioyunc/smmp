<?php
/**
 * Admin Panel - Dil Ayarları
 */

require_once __DIR__ . '/../config.php';

// Demo mode kontrolü
$demoMode = false;
try {
    $dm = $db->prepare("SELECT setting_value FROM settings WHERE setting_key = 'demo_mode' LIMIT 1");
    $dm->execute();
    $demoMode = trim((string)$dm->fetchColumn()) === '1';
} catch (Exception $e) {
    $demoMode = false;
}

$success = '';
$error = '';

// Demo modda tüm POST işlemlerini engelle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $demoMode) {
    $error = 'Demo modunda dil ayarları değiştirilemez.';
} else {

    // Yeni dil ekleme
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_language'])) {
        $code = strtolower(trim($_POST['lang_code']));
        $name = trim($_POST['lang_name']);
        $nativeName = trim($_POST['native_name']);
        $flag = trim($_POST['flag']);
        $direction = (($_POST['direction'] ?? 'ltr') === 'rtl') ? 'rtl' : 'ltr';
        $isDefault = isset($_POST['is_default']) ? 1 : 0;
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        
        if (empty($code) || strlen($code) !== 2) {
            $error = 'Dil kodu 2 karakter olmalıdır! (Örn: tr, en, de)';
        } elseif (empty($name)) {
            $error = 'Dil adı zorunludur!';
        } else {
            // Kod kontrolü
            $check = $db->prepare("SELECT id FROM languages WHERE code = ?");
            $check->execute([$code]);
            if ($check->fetch()) {
                $error = 'Bu dil kodu zaten mevcut!';
            } else {
                try {
                    $db->beginTransaction();
                    
                    // Eğer varsayılan yapılıyorsa diğerlerini kaldır
                    if ($isDefault) {
                        $db->query("UPDATE languages SET is_default = 0");
                    }
                    
                    $stmt = $db->prepare("INSERT INTO languages (code, name, native_name, direction, flag, is_default, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$code, $name, $nativeName ?: $name, $direction, $flag, $isDefault, $isActive]);
                    
                    $db->commit();
                    $success = 'Dil başarıyla eklendi!';
                } catch (Exception $e) {
                    $db->rollBack();
                    $error = 'Hata: ' . $e->getMessage();
                }
            }
        }
    }

    // Dil güncelleme
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_language'])) {
        $langId = (int)$_POST['lang_id'];
        $name = trim($_POST['lang_name']);
        $nativeName = trim($_POST['native_name']);
        $flag = trim($_POST['flag']);
        $direction = (($_POST['direction'] ?? 'ltr') === 'rtl') ? 'rtl' : 'ltr';
        $isDefault = isset($_POST['is_default']) ? 1 : 0;
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        
        if (empty($name)) {
            $error = 'Dil adı zorunludur!';
        } else {
            try {
                $db->beginTransaction();
                
                // Eğer varsayılan yapılıyorsa diğerlerini kaldır
                if ($isDefault) {
                    $db->query("UPDATE languages SET is_default = 0");
                }
                
                $stmt = $db->prepare("UPDATE languages SET name = ?, native_name = ?, direction = ?, flag = ?, is_default = ?, is_active = ? WHERE id = ?");
                $stmt->execute([$name, $nativeName ?: $name, $direction, $flag, $isDefault, $isActive, $langId]);
                
                // En az bir varsayılan dil olmalı
                $defaultCheck = $db->query("SELECT COUNT(*) FROM languages WHERE is_default = 1")->fetchColumn();
                if ($defaultCheck == 0) {
                    $db->query("UPDATE languages SET is_default = 1 ORDER BY id ASC LIMIT 1");
                }
                
                $db->commit();
                $success = 'Dil başarıyla güncellendi!';
            } catch (Exception $e) {
                $db->rollBack();
                $error = 'Hata: ' . $e->getMessage();
            }
        }
    }

    // Dil silme
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_language'])) {
        $langId = (int)$_POST['lang_id'];
        
        // Varsayılan dil silinemez
        $lang = $db->prepare("SELECT * FROM languages WHERE id = ?");
        $lang->execute([$langId]);
        $langData = $lang->fetch();
        
        if (!$langData) {
            $error = 'Dil bulunamadı!';
        } elseif ($langData['is_default']) {
            $error = 'Varsayılan dil silinemez! Önce başka bir dili varsayılan yapın.';
        } else {
            try {
                $db->beginTransaction();
                
                // Çevirileri sil
                $db->prepare("DELETE FROM translations WHERE lang_code = ?")->execute([$langData['code']]);
                
                // Dili sil
                $db->prepare("DELETE FROM languages WHERE id = ?")->execute([$langId]);
                
                $db->commit();
                $success = 'Dil ve tüm çevirileri silindi!';
            } catch (Exception $e) {
                $db->rollBack();
                $error = 'Hata: ' . $e->getMessage();
            }
        }
    }

    // Varsayılan dili değiştir
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_default'])) {
        $langId = (int)$_POST['lang_id'];
        
        $db->query("UPDATE languages SET is_default = 0");
        $db->prepare("UPDATE languages SET is_default = 1, is_active = 1 WHERE id = ?")->execute([$langId]);
        
        $success = 'Varsayılan dil değiştirildi!';
    }
}

// Dilleri getir
$languages = $db->query("SELECT * FROM languages ORDER BY is_default DESC, name ASC")->fetchAll();

// Çeviri istatistikleri
$translationStats = [];
foreach ($languages as $lang) {
    $count = $db->prepare("SELECT COUNT(*) FROM translations WHERE lang_code = ?");
    $count->execute([$lang['code']]);
    $translationStats[$lang['code']] = $count->fetchColumn();
}

// Toplam çeviri anahtarı sayısı (varsayılan dilden)
$defaultLang = $db->query("SELECT code FROM languages WHERE is_default = 1 LIMIT 1")->fetchColumn();
$totalKeys = $db->prepare("SELECT COUNT(DISTINCT translation_key) FROM translations WHERE lang_code = ?");
$totalKeys->execute([$defaultLang ?: 'tr']);
$totalKeys = $totalKeys->fetchColumn();

$pageTitle = "Dil Ayarları";
require_once 'header.php';
?>

<style>
.languages-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 20px;
    margin-bottom: 25px;
}

.language-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    padding: 25px;
    position: relative;
    transition: all 0.3s ease;
}

.language-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.language-card.default {
    border-color: var(--accent-text-color);
    background: var(--primary-alpha-005);
}

.language-header {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 20px;
}

.language-flag {
    width: 50px;
    height: 50px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
    background: var(--background-color);
}

.language-info h3 {
    font-size: 1.1rem;
    font-weight: 600;
    margin-bottom: 3px;
}

.language-info p {
    font-size: 0.85rem;
    opacity: 0.6;
}

.language-badges {
    position: absolute;
    top: 15px;
    right: 15px;
    display: flex;
    gap: 8px;
}

.lang-badge {
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 0.7rem;
    font-weight: 600;
}

.lang-badge.default {
    background: var(--primary-color);
    color: var(--on-primary-color);
}

.lang-badge.active {
    background: rgba(40, 167, 69, 0.15);
    color: #28a745;
}

.lang-badge.inactive {
    background: rgba(108, 117, 125, 0.15);
    color: var(--muted-text-color);
}

.language-stats {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
    margin-bottom: 20px;
    padding: 15px;
    background: var(--background-color);
    border-radius: 12px;
}

.stat-item {
    text-align: center;
}

.stat-item .value {
    font-size: 1.3rem;
    font-weight: 700;
    color: var(--accent-text-color);
}

.stat-item .label {
    font-size: 0.75rem;
    opacity: 0.6;
}

.language-progress {
    margin-bottom: 20px;
}

.progress-label {
    display: flex;
    justify-content: space-between;
    margin-bottom: 8px;
    font-size: 0.85rem;
}

.progress-bar {
    height: 8px;
    background: var(--background-color);
    border-radius: 4px;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 4px;
    transition: width 0.3s ease;
}

.language-actions {
    display: flex;
    gap: 10px;
}

.language-actions .btn {
    flex: 1;
    padding: 10px;
    font-size: 0.85rem;
}

/* Add Language Card */
.add-language-card {
    background: var(--card-bg-color);
    border: 2px dashed var(--border-color);
    border-radius: 16px;
    padding: 40px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    min-height: 300px;
}

.add-language-card:hover {
    border-color: var(--accent-text-color);
    background: var(--primary-alpha-005);
}

.add-language-card.disabled {
    opacity: 0.5;
    cursor: not-allowed;
    pointer-events: none;
}

.add-language-card i {
    font-size: 3rem;
    color: var(--accent-text-color);
    opacity: 0.5;
    margin-bottom: 15px;
}

.add-language-card h4 {
    font-size: 1.1rem;
    margin-bottom: 5px;
}

.add-language-card p {
    font-size: 0.85rem;
    opacity: 0.6;
}

/* Modal */
.modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    z-index: 2000;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.modal-overlay.active {
    display: flex;
}

.modal-box {
    background: var(--card-bg-color);
    border-radius: 20px;
    width: 100%;
    max-width: 500px;
    max-height: 90vh;
    overflow-y: auto;
    animation: modalSlide 0.3s ease;
}

@keyframes modalSlide {
    from { opacity: 0; transform: translateY(-30px) scale(0.95); }
    to { opacity: 1; transform: translateY(0) scale(1); }
}

.modal-header {
    padding: 25px;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h3 {
    font-size: 1.15rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 10px;
}

.modal-header h3 i {
    color: var(--accent-text-color);
}

.modal-close {
    background: var(--background-color);
    border: none;
    width: 40px;
    height: 40px;
    border-radius: 10px;
    font-size: 1.3rem;
    cursor: pointer;
    color: var(--text-color);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
}

.modal-close:hover {
    background: var(--danger-color);
    color: var(--on-danger-color);
}

.modal-body {
    padding: 25px;
}

.modal-footer {
    padding: 20px 25px;
    border-top: 1px solid var(--border-color);
    display: flex;
    gap: 10px;
}

.modal-footer .btn {
    flex: 1;
}

/* Form */
.form-group {
    margin-bottom: 20px;
}

.form-label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    font-size: 0.9rem;
}

.form-label .hint {
    font-weight: 400;
    opacity: 0.6;
    font-size: 0.8rem;
}

.form-control {
    width: 100%;
    padding: 12px 16px;
    border: 2px solid var(--border-color);
    border-radius: 10px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 0.95rem;
    transition: all 0.3s ease;
}

.form-control:focus {
    outline: none;
    border-color: var(--accent-text-color);
    box-shadow: 0 0 0 4px var(--primary-alpha-01);
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}

.checkbox-group {
    display: flex;
    gap: 20px;
    margin-top: 10px;
}

.checkbox-item {
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
}

.checkbox-item input {
    width: 20px;
    height: 20px;
    cursor: pointer;
}

/* Flag Picker */
.flag-picker {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    padding: 15px;
    background: var(--background-color);
    border-radius: 10px;
    max-height: 200px;
    overflow-y: auto;
}

.flag-option {
    width: 40px;
    height: 40px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    cursor: pointer;
    border: 2px solid transparent;
    transition: all 0.2s ease;
}

.flag-option:hover {
    background: var(--card-bg-color);
}

.flag-option.selected {
    border-color: var(--accent-text-color);
    background: var(--primary-alpha-01);
}

/* Info Box */
.info-box {
    background: rgba(23, 162, 184, 0.1);
    border: 1px solid rgba(23, 162, 184, 0.3);
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 25px;
    display: flex;
    align-items: flex-start;
    gap: 15px;
}

.info-box i {
    font-size: 1.5rem;
    color: #17a2b8;
}

.info-box-content h4 {
    font-size: 1rem;
    margin-bottom: 5px;
    color: #17a2b8;
}

.info-box-content p {
    font-size: 0.9rem;
    opacity: 0.8;
    line-height: 1.6;
}

/* Common Flags */
.common-flags {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    margin-top: 10px;
}

.common-flag {
    padding: 8px 12px;
    background: var(--background-color);
    border: 1px solid var(--border-color);
    border-radius: 8px;
    cursor: pointer;
    font-size: 1.2rem;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.2s ease;
}

.common-flag:hover {
    border-color: var(--accent-text-color);
}

.common-flag span {
    font-size: 0.8rem;
}

/* Demo Mode Styles */
.demo-banner {
    display: flex;
    align-items: center;
    gap: 15px;
    background: linear-gradient(135deg, #f39c12, #e67e22);
    color: #fff;
    padding: 18px 25px;
    border-radius: 12px;
    margin-bottom: 25px;
    box-shadow: 0 4px 15px rgba(243, 156, 18, 0.3);
}

.demo-banner i {
    font-size: 1.8rem;
    animation: pulse-demo 2s infinite;
}

@keyframes pulse-demo {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.7; transform: scale(1.1); }
}

.demo-banner-content h4 {
    font-size: 1.1rem;
    font-weight: 700;
    margin-bottom: 3px;
}

.demo-banner-content p {
    font-size: 0.85rem;
    opacity: 0.9;
    margin: 0;
}

.btn-disabled {
    opacity: 0.5 !important;
    cursor: not-allowed !important;
    pointer-events: none !important;
}
</style>

<?php if ($demoMode): ?>
<div class="demo-banner">
    <i class="fas fa-flask"></i>
    <div class="demo-banner-content">
        <h4>Demo Modu Aktif</h4>
        <p>Dil ayarlarını görüntüleyebilirsiniz ancak ekleme, düzenleme ve silme işlemleri yapılamaz.</p>
    </div>
</div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?php echo clean($success); ?>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?php echo clean($error); ?>
    </div>
<?php endif; ?>

<!-- Info Box -->
<div class="info-box">
    <i class="fas fa-info-circle"></i>
    <div class="info-box-content">
        <h4>Çoklu Dil Desteği</h4>
        <p>
            Sitenize yeni diller ekleyebilir, mevcut dilleri düzenleyebilir veya silebilirsiniz. 
            Her dil için çevirileri "Çevirileri Düzenle" butonuyla yönetebilirsiniz.
            Varsayılan dil, çeviri bulunamadığında kullanılacak dildir.
        </p>
    </div>
</div>

<!-- Languages Grid -->
<div class="languages-grid">
    <?php foreach ($languages as $lang): ?>
        <?php 
        $translatedCount = $translationStats[$lang['code']] ?? 0;
        $percentage = $totalKeys > 0 ? round(($translatedCount / $totalKeys) * 100) : 0;
        ?>
        <div class="language-card <?php echo $lang['is_default'] ? 'default' : ''; ?>">
            <div class="language-badges">
                <?php if ($lang['is_default']): ?>
                    <span class="lang-badge default">Varsayılan</span>
                <?php endif; ?>
                <span class="lang-badge <?php echo $lang['is_active'] ? 'active' : 'inactive'; ?>">
                    <?php echo $lang['is_active'] ? 'Aktif' : 'Pasif'; ?>
                </span>
            </div>
            
            <div class="language-header">
                <div class="language-flag"><?php echo $lang['flag'] ?: '🌐'; ?></div>
                <div class="language-info">
                    <h3><?php echo clean($lang['name']); ?></h3>
                    <p><?php echo clean($lang['native_name']); ?> (<?php echo strtoupper($lang['code']); ?>)</p>
                </div>
            </div>
            
            <div class="language-stats">
                <div class="stat-item">
                    <div class="value"><?php echo strtoupper($lang['code']); ?></div>
                    <div class="label">Dil Kodu</div>
                </div>
                <div class="stat-item">
                    <div class="value"><?php echo number_format($translatedCount); ?></div>
                    <div class="label">Çeviri</div>
                </div>
            </div>
            
            <div class="language-progress">
                <div class="progress-label">
                    <span>Çeviri Tamamlanma</span>
                    <span><?php echo $percentage; ?>%</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: <?php echo $percentage; ?>%"></div>
                </div>
            </div>
            
            <div class="language-actions">
                <a href="/admin/translations.php?lang=<?php echo $lang['code']; ?>" class="btn btn-primary btn-sm">
                    <i class="fas fa-language"></i> Çeviriler
                </a>
                <?php if ($demoMode): ?>
                <button type="button" class="btn btn-secondary btn-sm btn-disabled" disabled>
                    <i class="fas fa-lock"></i>
                </button>
                <?php if (!$lang['is_default']): ?>
                <button type="button" class="btn btn-danger btn-sm btn-disabled" disabled>
                    <i class="fas fa-lock"></i>
                </button>
                <?php endif; ?>
                <?php else: ?>
                <button type="button" class="btn btn-secondary btn-sm" onclick="editLanguage(<?php echo htmlspecialchars(json_encode($lang)); ?>)">
                    <i class="fas fa-edit"></i> Düzenle
                </button>
                <?php if (!$lang['is_default']): ?>
                    <button type="button" class="btn btn-danger btn-sm" onclick="deleteLanguage(<?php echo $lang['id']; ?>, '<?php echo clean($lang['name']); ?>')">
                        <i class="fas fa-trash"></i>
                    </button>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
    
    <!-- Add Language Card -->
    <?php if ($demoMode): ?>
    <div class="add-language-card disabled">
        <i class="fas fa-lock"></i>
        <h4>Demo Modu</h4>
        <p>Demo modunda yeni dil eklenemez</p>
    </div>
    <?php else: ?>
    <div class="add-language-card" onclick="openModal('addLanguageModal')">
        <i class="fas fa-plus-circle"></i>
        <h4>Yeni Dil Ekle</h4>
        <p>Sitenize yeni bir dil ekleyin</p>
    </div>
    <?php endif; ?>
</div>

<?php if (!$demoMode): ?>
<!-- Add Language Modal -->
<div class="modal-overlay" id="addLanguageModal">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fas fa-plus-circle"></i> Yeni Dil Ekle</h3>
            <button type="button" class="modal-close" onclick="closeModal('addLanguageModal')">&times;</button>
        </div>
        <form method="POST">
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Dil Kodu <span class="hint">(2 karakter)</span></label>
                        <input type="text" name="lang_code" class="form-control" placeholder="tr" maxlength="2" required pattern="[a-zA-Z]{2}">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Bayrak Emoji</label>
                        <input type="text" name="flag" id="addFlagInput" class="form-control" placeholder="🇹🇷">
                        <div class="common-flags">
                            <!-- Avrupa -->
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇹🇷')">🇹🇷 <span>TR</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇬🇧')">🇬🇧 <span>EN</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇩🇪')">🇩🇪 <span>DE</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇫🇷')">🇫🇷 <span>FR</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇪🇸')">🇪🇸 <span>ES</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇮🇹')">🇮🇹 <span>IT</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇷🇺')">🇷🇺 <span>RU</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇳🇱')">🇳🇱 <span>NL</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇵🇹')">🇵🇹 <span>PT</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇵🇱')">🇵🇱 <span>PL</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇬🇷')">🇬🇷 <span>EL</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇸🇪')">🇸🇪 <span>SV</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇳🇴')">🇳🇴 <span>NO</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇩🇰')">🇩🇰 <span>DA</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇫🇮')">🇫🇮 <span>FI</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇨🇿')">🇨🇿 <span>CS</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇭🇺')">🇭🇺 <span>HU</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇷🇴')">🇷🇴 <span>RO</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇧🇬')">🇧🇬 <span>BG</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇺🇦')">🇺🇦 <span>UK</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇦🇹')">🇦🇹 <span>AT</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇨🇭')">🇨🇭 <span>CH</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇧🇪')">🇧🇪 <span>BE</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇮🇪')">🇮🇪 <span>IE</span></span>
                            <!-- Asya -->
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇸🇦')">🇸🇦 <span>AR</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇨🇳')">🇨🇳 <span>ZH</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇯🇵')">🇯🇵 <span>JA</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇰🇷')">🇰🇷 <span>KO</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇮🇳')">🇮🇳 <span>HI</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇮🇷')">🇮🇷 <span>FA</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇮🇱')">🇮🇱 <span>HE</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇹🇭')">🇹🇭 <span>TH</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇻🇳')">🇻🇳 <span>VI</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇮🇩')">🇮🇩 <span>ID</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇲🇾')">🇲🇾 <span>MS</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇵🇭')">🇵🇭 <span>TL</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇵🇰')">🇵🇰 <span>UR</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇧🇩')">🇧🇩 <span>BN</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇦🇪')">🇦🇪 <span>AE</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇶🇦')">🇶🇦 <span>QA</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇰🇼')">🇰🇼 <span>KW</span></span>
                            <!-- Amerika -->
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇺🇸')">🇺🇸 <span>US</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇧🇷')">🇧🇷 <span>BR</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇲🇽')">🇲🇽 <span>MX</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇦🇷')">🇦🇷 <span>AR</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇨🇦')">🇨🇦 <span>CA</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇨🇴')">🇨🇴 <span>CO</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇨🇱')">🇨🇱 <span>CL</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇵🇪')">🇵🇪 <span>PE</span></span>
                            <!-- Afrika & Okyanusya -->
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇿🇦')">🇿🇦 <span>ZA</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇪🇬')">🇪🇬 <span>EG</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇳🇬')">🇳🇬 <span>NG</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇦🇺')">🇦🇺 <span>AU</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇳🇿')">🇳🇿 <span>NZ</span></span>
                            <!-- Türk Dünyası -->
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇦🇿')">🇦🇿 <span>AZ</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇰🇿')">🇰🇿 <span>KZ</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇺🇿')">🇺🇿 <span>UZ</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇹🇲')">🇹🇲 <span>TM</span></span>
                            <span class="common-flag" onclick="setFlag('addFlagInput', '🇰🇬')">🇰🇬 <span>KG</span></span>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Dil Adı <span class="hint">(İngilizce)</span></label>
                    <input type="text" name="lang_name" class="form-control" placeholder="Turkish" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Yerel Dil Adı</label>
                    <input type="text" name="native_name" class="form-control" placeholder="Türkçe">
                </div>
                <div class="form-group">
                    <label class="form-label">Yazı Yönü</label>
                    <select name="direction" class="form-control"><option value="ltr">LTR — Soldan sağa</option><option value="rtl">RTL — Sağdan sola</option></select>
                </div>
                
                <div class="checkbox-group">
                    <label class="checkbox-item">
                        <input type="checkbox" name="is_active" value="1" checked>
                        <span>Aktif</span>
                    </label>
                    <label class="checkbox-item">
                        <input type="checkbox" name="is_default" value="1">
                        <span>Varsayılan Yap</span>
                    </label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('addLanguageModal')">İptal</button>
                <button type="submit" name="add_language" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Dil Ekle
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Language Modal -->
<div class="modal-overlay" id="editLanguageModal">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fas fa-edit"></i> Dil Düzenle</h3>
            <button type="button" class="modal-close" onclick="closeModal('editLanguageModal')">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="lang_id" id="editLangId">
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Dil Kodu</label>
                        <input type="text" id="editLangCode" class="form-control" disabled>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Bayrak Emoji</label>
                        <input type="text" name="flag" id="editFlagInput" class="form-control" placeholder="🇹🇷">
                        <div class="common-flags">
                            <span class="common-flag" onclick="setFlag('editFlagInput', '🇹🇷')">🇹🇷</span>
                            <span class="common-flag" onclick="setFlag('editFlagInput', '🇬🇧')">🇬🇧</span>
                            <span class="common-flag" onclick="setFlag('editFlagInput', '🇩🇪')">🇩🇪</span>
                            <span class="common-flag" onclick="setFlag('editFlagInput', '🇫🇷')">🇫🇷</span>
                            <span class="common-flag" onclick="setFlag('editFlagInput', '����🇸')">🇪🇸</span>
                            <span class="common-flag" onclick="setFlag('editFlagInput', '🇮🇹')">🇮🇹</span>
                            <span class="common-flag" onclick="setFlag('editFlagInput', '🇷🇺')">🇷🇺</span>
                            <span class="common-flag" onclick="setFlag('editFlagInput', '🇸🇦')">🇸🇦</span>
                            <span class="common-flag" onclick="setFlag('editFlagInput', '🇨🇳')">🇨🇳</span>
                            <span class="common-flag" onclick="setFlag('editFlagInput', '🇯🇵')">🇯🇵</span>
                            <span class="common-flag" onclick="setFlag('editFlagInput', '🇰🇷')">🇰🇷</span>
                            <span class="common-flag" onclick="setFlag('editFlagInput', '🇳🇱')">🇳🇱</span>
                            <span class="common-flag" onclick="setFlag('editFlagInput', '🇵🇹')">🇵🇹</span>
                            <span class="common-flag" onclick="setFlag('editFlagInput', '🇵🇱')">🇵🇱</span>
                            <span class="common-flag" onclick="setFlag('editFlagInput', '🇺🇸')">🇺🇸</span>
                            <span class="common-flag" onclick="setFlag('editFlagInput', '🇧🇷')">🇧🇷</span>
                            <span class="common-flag" onclick="setFlag('editFlagInput', '🇮🇳')">🇮🇳</span>
                            <span class="common-flag" onclick="setFlag('editFlagInput', '🇦🇿')">🇦🇿</span>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Dil Adı <span class="hint">(İngilizce)</span></label>
                    <input type="text" name="lang_name" id="editLangName" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Yerel Dil Adı</label>
                    <input type="text" name="native_name" id="editNativeName" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Yazı Yönü</label>
                    <select name="direction" id="editDirection" class="form-control"><option value="ltr">LTR — Soldan sağa</option><option value="rtl">RTL — Sağdan sola</option></select>
                </div>
                
                <div class="checkbox-group">
                    <label class="checkbox-item">
                        <input type="checkbox" name="is_active" id="editIsActive" value="1">
                        <span>Aktif</span>
                    </label>
                    <label class="checkbox-item">
                        <input type="checkbox" name="is_default" id="editIsDefault" value="1">
                        <span>Varsayılan Yap</span>
                    </label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('editLanguageModal')">İptal</button>
                <button type="submit" name="update_language" class="btn btn-primary">
                    <i class="fas fa-save"></i> Kaydet
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal-overlay" id="deleteModal">
    <div class="modal-box" style="max-width: 400px;">
        <div class="modal-header">
            <h3><i class="fas fa-exclamation-triangle" style="color: var(--danger-color);"></i> Dil Sil</h3>
            <button type="button" class="modal-close" onclick="closeModal('deleteModal')">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="lang_id" id="deleteLangId">
            <div class="modal-body">
                <p style="text-align: center; font-size: 1rem; line-height: 1.6;">
                    <strong id="deleteLangName"></strong> dilini silmek istediğinize emin misiniz?
                    <br><br>
                    <span style="color: var(--danger-color); font-size: 0.9rem;">
                        <i class="fas fa-exclamation-circle"></i> 
                        Bu işlem geri alınamaz ve tüm çeviriler silinecektir!
                    </span>
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('deleteModal')">İptal</button>
                <button type="submit" name="delete_language" class="btn btn-danger">
                    <i class="fas fa-trash"></i> Sil
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Modal functions
function openModal(id) {
    document.getElementById(id).classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeModal(id) {
    document.getElementById(id).classList.remove('active');
    document.body.style.overflow = '';
}

// Close on outside click
document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) {
            this.classList.remove('active');
            document.body.style.overflow = '';
        }
    });
});

// Close on ESC
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(modal => {
            modal.classList.remove('active');
        });
        document.body.style.overflow = '';
    }
});

// Set flag
function setFlag(inputId, flag) {
    document.getElementById(inputId).value = flag;
}

// Edit language
function editLanguage(lang) {
    document.getElementById('editLangId').value = lang.id;
    document.getElementById('editLangCode').value = lang.code.toUpperCase();
    document.getElementById('editLangName').value = lang.name;
    document.getElementById('editNativeName').value = lang.native_name;
    document.getElementById('editDirection').value = lang.direction || 'ltr';
    document.getElementById('editFlagInput').value = lang.flag || '';
    document.getElementById('editIsActive').checked = lang.is_active == 1;
    document.getElementById('editIsDefault').checked = lang.is_default == 1;
    
    openModal('editLanguageModal');
}

// Delete language
function deleteLanguage(id, name) {
    document.getElementById('deleteLangId').value = id;
    document.getElementById('deleteLangName').textContent = name;
    openModal('deleteModal');
}
</script>
<?php endif; ?>

<?php require_once 'footer.php'; ?>