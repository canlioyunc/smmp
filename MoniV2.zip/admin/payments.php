<?php
/**
 * Admin Panel - Ödeme Bildirimleri Yönetimi
 * Paket desteği ile güncellenmiş versiyon
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';

$success = '';
$error = '';

// Ödeme onaylama - yarış koşuluna karşı satır kilidi ve atomik durum geçişi.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve_payment'])) {
    $paymentId = (int)$_POST['payment_id'];
    $adminNote = trim($_POST['admin_note'] ?? '');
    try {
        $db->beginTransaction();
        $lock = $db->prepare("SELECT * FROM payment_requests WHERE id=? FOR UPDATE");
        $lock->execute([$paymentId]);
        $payment = $lock->fetch(PDO::FETCH_ASSOC);
        if (!$payment || $payment['status'] !== 'pending') throw new RuntimeException('Ödeme bulunamadı veya zaten işlenmiş!');
        $balanceToAdd = (float)(!empty($payment['credit_amount']) ? $payment['credit_amount'] : $payment['amount']);
        $u = $db->prepare("SELECT balance FROM users WHERE id=? FOR UPDATE");$u->execute([$payment['user_id']]);$before=$u->fetchColumn();
        if ($before === false) throw new RuntimeException('Kullanıcı bulunamadı.');
        $db->prepare("UPDATE users SET balance=balance+? WHERE id=?")->execute([$balanceToAdd,$payment['user_id']]);
        $up=$db->prepare("UPDATE payment_requests SET status='approved',admin_note=?,processed_by=?,processed_at=NOW() WHERE id=? AND status='pending'");
        $up->execute([$adminNote,$_SESSION['user_id'],$paymentId]);if(!$up->rowCount())throw new RuntimeException('Ödeme başka bir işlem tarafından işlendi.');
        $description='Bakiye yükleme';
        if(!empty($payment['package_id'])){$q=$db->prepare("SELECT name FROM credit_packages WHERE id=?");$q->execute([$payment['package_id']]);$n=$q->fetchColumn();if($n)$description.=' - '.$n.' Paketi';}
        $after=(float)$before+$balanceToAdd;
        $db->prepare("INSERT INTO transactions(user_id,type,amount,balance_after,description,status,created_at) VALUES(?,'deposit',?,?,?,'completed',NOW())")->execute([$payment['user_id'],$balanceToAdd,$after,$description]);
        // Manuel/havale ödemelerinde e-belge kaydını aynı transaction içinde kuyruğa al; commit sonrası kesinti belgeyi kaybettirmez.
        moni_queue_invoice($db,(int)$payment['user_id'],null,(float)$payment['amount'],moni_base_currency($db));
        if(function_exists('moni_table_ready') && moni_table_ready($db,'bank_statement_entries')){
            $db->prepare("UPDATE bank_statement_entries SET match_status='approved',approved_at=NOW(),matched_by=COALESCE(matched_by,?) WHERE matched_payment_request_id=? AND match_status IN('suggested','matched')")->execute([(int)$_SESSION['user_id'],$paymentId]);
        }
        $db->commit();moni_sync_base_wallet($db,(int)$payment['user_id']);
        if(function_exists('moni_user_notify'))moni_user_notify($db,(int)$payment['user_id'],'payment','Ödemeniz onaylandı',$siteSettings['currency_symbol'].number_format($balanceToAdd,2).' bakiyenize eklendi.','/kullanici/add-funds.php','success');
        if(function_exists('moni_send_template_email')){try{$em=$db->prepare("SELECT email,username FROM users WHERE id=?");$em->execute([$payment['user_id']]);$eu=$em->fetch(PDO::FETCH_ASSOC);if($eu&&!empty($eu['email']))moni_send_template_email($db,'payment_approved',$eu['email'],['username'=>$eu['username'],'amount'=>$siteSettings['currency_symbol'].number_format($balanceToAdd,2)]);}catch(Throwable $ignore){}}
        $success='Ödeme onaylandı ve '.$siteSettings['currency_symbol'].number_format($balanceToAdd,2).' bakiye yüklendi!';
    } catch (Throwable $e) { if($db->inTransaction())$db->rollBack(); $error='Hata: '.$e->getMessage(); }
}

// Ödeme reddetme
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reject_payment'])) {
    $paymentId = (int)$_POST['payment_id'];
    $adminNote = trim($_POST['admin_note'] ?? '');
    
    if (empty($adminNote)) {
        $error = 'Red nedeni zorunludur!';
    } else {
        $stmt = $db->prepare("UPDATE payment_requests SET status = 'rejected', admin_note = ?, processed_by = ?, processed_at = NOW() WHERE id = ? AND status = 'pending'");
        $stmt->execute([$adminNote, $_SESSION['user_id'], $paymentId]);
        
        if ($stmt->rowCount() > 0) {
            $u=$db->prepare("SELECT user_id FROM payment_requests WHERE id=?");$u->execute([$paymentId]);$uid=(int)$u->fetchColumn();if($uid&&function_exists('moni_user_notify'))moni_user_notify($db,$uid,'payment','Ödeme bildiriminiz reddedildi',$adminNote,'/kullanici/add-funds.php','danger');
            $success = 'Ödeme reddedildi!';
        } else {
            $error = 'Ödeme bulunamadı veya zaten işlenmiş!';
        }
    }
}

// Filtreler
$statusFilter = $_GET['status'] ?? '';
$search = $_GET['search'] ?? '';
$dateFrom = $_GET['date_from'] ?? '';
$dateTo = $_GET['date_to'] ?? '';

$where = "WHERE 1=1";
$params = [];

if ($statusFilter) {
    $where .= " AND pr.status = ?";
    $params[] = $statusFilter;
}

if ($search) {
    $where .= " AND (pr.id = ? OR u.username LIKE ? OR pr.sender_name LIKE ? OR pr.payment_reference LIKE ?)";
    $params[] = $search;
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($dateFrom) {
    $where .= " AND DATE(pr.created_at) >= ?";
    $params[] = $dateFrom;
}

if ($dateTo) {
    $where .= " AND DATE(pr.created_at) <= ?";
    $params[] = $dateTo;
}

// Sayfalama
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

$countStmt = $db->prepare("SELECT COUNT(*) FROM payment_requests pr LEFT JOIN users u ON pr.user_id = u.id $where");
$countStmt->execute($params);
$totalPayments = $countStmt->fetchColumn();
$totalPages = ceil($totalPayments / $perPage);

// Ödemeleri getir (paket bilgisi dahil)
$stmt = $db->prepare("
    SELECT pr.*, u.username, u.email,
           COALESCE(cba.bank_name, ba.bank_name) AS bank_name,
           COALESCE(cpm.name, pm.name) AS method_name,
           cp.name as package_name, child.panel_name AS child_panel_name
    FROM payment_requests pr
    LEFT JOIN users u ON pr.user_id = u.id
    LEFT JOIN bank_accounts ba ON pr.bank_account_id = ba.id
    LEFT JOIN payment_methods pm ON pr.payment_method_id = pm.id
    LEFT JOIN child_panel_bank_accounts cba ON pr.child_bank_account_id = cba.id AND pr.child_panel_id = cba.child_panel_id
    LEFT JOIN child_panel_payment_methods cpm ON pr.child_payment_method_id = cpm.id AND pr.child_panel_id = cpm.child_panel_id
    LEFT JOIN child_panels child ON pr.child_panel_id = child.id
    LEFT JOIN credit_packages cp ON pr.package_id = cp.id
    $where
    ORDER BY 
        CASE WHEN pr.status = 'pending' THEN 0 ELSE 1 END,
        pr.created_at DESC
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$payments = $stmt->fetchAll();

// İstatistikler (credit_amount dahil)
$stats = $db->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_count,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_count,
        SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected_count,
        SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END) as pending_amount,
        SUM(CASE WHEN status = 'pending' THEN COALESCE(credit_amount, amount) ELSE 0 END) as pending_credit,
        SUM(CASE WHEN status = 'approved' THEN amount ELSE 0 END) as approved_amount,
        SUM(CASE WHEN status = 'approved' THEN COALESCE(credit_amount, amount) ELSE 0 END) as approved_credit,
        SUM(CASE WHEN status = 'approved' AND DATE(created_at) = CURDATE() THEN amount ELSE 0 END) as today_amount,
        SUM(CASE WHEN status = 'approved' AND DATE(created_at) = CURDATE() THEN COALESCE(credit_amount, amount) ELSE 0 END) as today_credit
    FROM payment_requests
")->fetch();

$statusNames = [
    'pending' => 'Bekliyor',
    'approved' => 'Onaylandı',
    'rejected' => 'Reddedildi'
];

$pageTitle = "Ödeme Bildirimleri";
require_once 'header.php';
?>

<style>
/* Stats */
.pay-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
    margin-bottom: 25px;
}

@media (max-width: 1200px) { .pay-stats { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 576px) { .pay-stats { grid-template-columns: 1fr; gap: 15px; } }

.pay-stat {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    padding: 22px;
    display: flex;
    align-items: center;
    gap: 18px;
    transition: all 0.3s ease;
}

.pay-stat:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.08);
}

.pay-stat-icon {
    width: 58px;
    height: 58px;
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.4rem;
    flex-shrink: 0;
}

.pay-stat-icon.pending { background: rgba(243, 156, 18, 0.15); color: #f39c12; }
.pay-stat-icon.approved { background: rgba(40, 167, 69, 0.15); color: #28a745; }
.pay-stat-icon.rejected { background: rgba(220, 53, 69, 0.15); color: #dc3545; }
.pay-stat-icon.today { background: var(--primary-alpha-015); color: var(--accent-text-color); }

.pay-stat-info h4 {
    font-size: 1.6rem;
    font-weight: 700;
    margin: 0 0 4px 0;
}

.pay-stat-info p {
    font-size: 0.82rem;
    opacity: 0.6;
    margin: 0;
}

.pay-stat-info small {
    font-size: 0.75rem;
    opacity: 0.5;
    display: block;
    margin-top: 2px;
}

/* Filters */
.pay-filters {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    padding: 20px;
    margin-bottom: 25px;
}

.pay-filters-row {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
    align-items: flex-end;
}

.pay-filters-row .form-group {
    margin-bottom: 0;
    flex: 1;
    min-width: 140px;
}

.pay-filters-row .form-group label {
    font-size: 0.78rem;
    margin-bottom: 6px;
    display: block;
    opacity: 0.7;
    font-weight: 500;
}

.pay-filters-row .form-control {
    padding: 10px 14px;
    font-size: 0.9rem;
}

@media (max-width: 768px) {
    .pay-filters-row .form-group { min-width: 100%; }
}

/* Table */
.pay-table {
    width: 100%;
    border-collapse: collapse;
}

.pay-table th,
.pay-table td {
    padding: 14px 16px;
    text-align: left;
    border-bottom: 1px solid var(--border-color);
    vertical-align: middle;
}

.pay-table th {
    background: var(--background-color);
    font-weight: 600;
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    opacity: 0.7;
    white-space: nowrap;
}

.pay-table tbody tr {
    transition: background 0.2s ease;
}

.pay-table tbody tr:hover {
    background: var(--background-color);
}

/* User Cell */
.pay-user {
    display: flex;
    align-items: center;
    gap: 12px;
}

.pay-user-avatar {
    width: 42px;
    height: 42px;
    border-radius: 10px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--on-accent-color);
    font-weight: 600;
    font-size: 0.95rem;
    flex-shrink: 0;
}

.pay-user-info h5 {
    font-size: 0.9rem;
    font-weight: 600;
    margin: 0 0 2px 0;
}

.pay-user-info p {
    font-size: 0.78rem;
    opacity: 0.6;
    margin: 0;
}

/* Amount Cell */
.pay-amount {
    text-align: right;
}

.pay-amount-credit {
    font-weight: 700;
    font-size: 1.05rem;
    color: var(--success-color);
}

.pay-amount-price {
    font-size: 0.78rem;
    opacity: 0.6;
    margin-top: 2px;
}

.pay-amount-price span {
    color: var(--accent-text-color);
    font-weight: 600;
}

/* Package Badge */
.pay-package {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 5px 10px;
    background: var(--primary-alpha-01);
    color: var(--accent-text-color);
    border-radius: 8px;
    font-size: 0.75rem;
    font-weight: 600;
}

.pay-package i {
    font-size: 0.7rem;
}

/* Method */
.pay-method {
    font-size: 0.85rem;
}

.pay-method small {
    display: block;
    font-size: 0.75rem;
    opacity: 0.6;
    margin-top: 2px;
}

/* Status */
.pay-status {
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 0.78rem;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

.pay-status.pending {
    background: rgba(243, 156, 18, 0.15);
    color: #f39c12;
}

.pay-status.approved {
    background: rgba(40, 167, 69, 0.15);
    color: #28a745;
}

.pay-status.rejected {
    background: rgba(220, 53, 69, 0.15);
    color: #dc3545;
}

/* Actions */
.pay-actions {
    display: flex;
    gap: 8px;
}

.pay-action {
    width: 36px;
    height: 36px;
    border-radius: 10px;
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.9rem;
    transition: all 0.2s ease;
}

.pay-action.view {
    background: var(--primary-alpha-012);
    color: var(--accent-text-color);
}

.pay-action.approve {
    background: rgba(40, 167, 69, 0.12);
    color: #28a745;
}

.pay-action.reject {
    background: rgba(220, 53, 69, 0.12);
    color: #dc3545;
}

.pay-action:hover {
    transform: scale(1.1);
}

.pay-action.view:hover { background: var(--primary-color); color: var(--on-primary-color); }
.pay-action.approve:hover { background: #28a745; color: #fff; }
.pay-action.reject:hover { background: #dc3545; color: #fff; }

/* Date Cell */
.pay-date {
    font-size: 0.85rem;
    white-space: nowrap;
}

.pay-date small {
    display: block;
    font-size: 0.75rem;
    opacity: 0.5;
}

/* Empty State */
.pay-empty {
    text-align: center;
    padding: 70px 20px;
}

.pay-empty i {
    font-size: 4rem;
    opacity: 0.08;
    margin-bottom: 20px;
}

.pay-empty p {
    font-size: 1rem;
    opacity: 0.5;
}

/* Pagination */
.pay-pagination {
    display: flex;
    justify-content: center;
    gap: 8px;
    margin-top: 25px;
    flex-wrap: wrap;
}

.pay-pagination a,
.pay-pagination span {
    padding: 10px 16px;
    border-radius: 10px;
    text-decoration: none;
    font-size: 0.88rem;
    font-weight: 500;
    transition: all 0.2s ease;
}

.pay-pagination a {
    background: var(--background-color);
    color: var(--text-color);
    border: 1px solid var(--border-color);
}

.pay-pagination a:hover {
    border-color: var(--accent-text-color);
    color: var(--accent-text-color);
}

.pay-pagination .current {
    background: var(--primary-color);
    color: var(--on-primary-color);
}

/* Modal */
.pay-modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.8);
    backdrop-filter: blur(4px);
    z-index: 99999;
    overflow-y: auto;
    padding: 20px;
}

.pay-modal-overlay.active {
    display: block;
}

.pay-modal-wrapper {
    min-height: 100%;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    padding: 20px 0;
}

.pay-modal {
    background: var(--card-bg-color);
    border-radius: 20px;
    width: 100%;
    max-width: 600px;
    animation: payModalIn 0.3s ease;
}

@keyframes payModalIn {
    from { opacity: 0; transform: translateY(30px) scale(0.96); }
    to { opacity: 1; transform: translateY(0) scale(1); }
}

.pay-modal-header {
    padding: 22px 26px;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.pay-modal-header h3 {
    font-size: 1.1rem;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 0;
}

.pay-modal-close {
    width: 38px;
    height: 38px;
    border: none;
    background: var(--background-color);
    border-radius: 10px;
    cursor: pointer;
    font-size: 1.2rem;
    color: var(--text-color);
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
}

.pay-modal-close:hover {
    background: #dc3545;
    color: #fff;
    transform: rotate(90deg);
}

.pay-modal-body {
    padding: 26px;
}

.pay-modal-footer {
    padding: 20px 26px;
    border-top: 1px solid var(--border-color);
    display: flex;
    gap: 12px;
    background: var(--background-color);
    border-radius: 0 0 20px 20px;
}

.pay-modal-footer .btn {
    flex: 1;
    padding: 13px 20px;
    justify-content: center;
}

@media (max-width: 600px) {
    .pay-modal-overlay { padding: 12px; }
    .pay-modal-wrapper { padding: 10px 0; }
    .pay-modal { border-radius: 16px; }
    .pay-modal-header { padding: 18px 20px; }
    .pay-modal-body { padding: 20px; }
    .pay-modal-footer { 
        padding: 16px 20px; 
        flex-direction: column;
        border-radius: 0 0 16px 16px;
    }
}

/* Detail Grid */
.pay-detail-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16px;
    margin-bottom: 20px;
}

@media (max-width: 500px) {
    .pay-detail-grid { grid-template-columns: 1fr; }
}

.pay-detail-item {
    background: var(--background-color);
    padding: 16px;
    border-radius: 12px;
}

.pay-detail-item label {
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    opacity: 0.5;
    display: block;
    margin-bottom: 6px;
    font-weight: 600;
}

.pay-detail-item span {
    font-size: 0.95rem;
    font-weight: 600;
    color: var(--text-color);
}

.pay-detail-item span.credit {
    color: var(--success-color);
    font-size: 1.15rem;
}

.pay-detail-item span.price {
    color: var(--accent-text-color);
}

.pay-detail-item.full {
    grid-column: 1 / -1;
}

/* Amount Summary in Modal */
.pay-amount-summary {
    background: linear-gradient(135deg, rgba(40, 167, 69, 0.1), rgba(40, 167, 69, 0.05));
    border: 1px solid rgba(40, 167, 69, 0.2);
    border-radius: 14px;
    padding: 20px;
    margin-bottom: 20px;
    text-align: center;
}

.pay-amount-summary h4 {
    font-size: 0.85rem;
    opacity: 0.7;
    margin: 0 0 10px 0;
    font-weight: 500;
}

.pay-amount-summary .credit-value {
    font-size: 2rem;
    font-weight: 800;
    color: #28a745;
    margin: 0;
}

.pay-amount-summary .price-info {
    font-size: 0.88rem;
    opacity: 0.7;
    margin-top: 8px;
}

.pay-amount-summary .price-info strong {
    color: var(--accent-text-color);
}

.pay-amount-summary .package-info {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    margin-top: 12px;
    padding: 6px 14px;
    background: var(--primary-alpha-01);
    color: var(--accent-text-color);
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
}

/* Receipt Preview */
.pay-receipt {
    margin-top: 20px;
    text-align: center;
}

.pay-receipt img {
    max-width: 100%;
    max-height: 300px;
    border-radius: 12px;
    cursor: pointer;
    transition: transform 0.3s ease;
}

.pay-receipt img:hover {
    transform: scale(1.02);
}

.pay-receipt-link {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 14px 28px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--on-accent-color);
    border-radius: 12px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s ease;
}

.pay-receipt-link:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px var(--primary-alpha-03);
}

.pay-receipt-empty {
    padding: 30px;
    background: var(--background-color);
    border-radius: 12px;
    opacity: 0.5;
}

/* Approve Modal Highlight */
.pay-approve-info {
    background: linear-gradient(135deg, rgba(40, 167, 69, 0.1), rgba(40, 167, 69, 0.05));
    border: 1px solid rgba(40, 167, 69, 0.2);
    border-radius: 12px;
    padding: 18px;
    margin-bottom: 20px;
    text-align: center;
}

.pay-approve-info p {
    margin: 0 0 10px 0;
    font-size: 0.9rem;
}

.pay-approve-info .amount {
    font-size: 1.8rem;
    font-weight: 800;
    color: #28a745;
}

.pay-approve-info small {
    display: block;
    margin-top: 8px;
    font-size: 0.82rem;
    opacity: 0.7;
}
</style>

<?php if ($success): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
<?php endif; ?>

<!-- Stats -->
<div class="pay-stats">
    <div class="pay-stat">
        <div class="pay-stat-icon pending"><i class="fas fa-clock"></i></div>
        <div class="pay-stat-info">
            <h4><?php echo (int)($stats['pending_count'] ?? 0); ?></h4>
            <p>Bekleyen Ödeme</p>
            <small>
                <?php echo $siteSettings['currency_symbol'] . number_format($stats['pending_amount'] ?? 0, 2); ?> ödeme
                <?php if (($stats['pending_credit'] ?? 0) != ($stats['pending_amount'] ?? 0)): ?>
                    → <?php echo $siteSettings['currency_symbol'] . number_format($stats['pending_credit'] ?? 0, 2); ?> bakiye
                <?php endif; ?>
            </small>
        </div>
    </div>
    <div class="pay-stat">
        <div class="pay-stat-icon approved"><i class="fas fa-check-circle"></i></div>
        <div class="pay-stat-info">
            <h4><?php echo (int)($stats['approved_count'] ?? 0); ?></h4>
            <p>Onaylanan</p>
            <small><?php echo $siteSettings['currency_symbol'] . number_format($stats['approved_credit'] ?? 0, 2); ?> toplam bakiye</small>
        </div>
    </div>
    <div class="pay-stat">
        <div class="pay-stat-icon rejected"><i class="fas fa-times-circle"></i></div>
        <div class="pay-stat-info">
            <h4><?php echo (int)($stats['rejected_count'] ?? 0); ?></h4>
            <p>Reddedilen</p>
        </div>
    </div>
    <div class="pay-stat">
        <div class="pay-stat-icon today"><i class="fas fa-calendar-day"></i></div>
        <div class="pay-stat-info">
            <h4><?php echo $siteSettings['currency_symbol'] . number_format($stats['today_credit'] ?? 0, 2); ?></h4>
            <p>Bugün Yüklenen</p>
            <small>Alınan: <?php echo $siteSettings['currency_symbol'] . number_format($stats['today_amount'] ?? 0, 2); ?></small>
        </div>
    </div>
</div>

<!-- Filters -->
<div class="pay-filters">
    <form method="GET" class="pay-filters-row">
        <div class="form-group">
            <label>Arama</label>
            <input type="text" name="search" class="form-control" placeholder="ID, kullanıcı, gönderen, havale referansı..." value="<?php echo clean($search); ?>">
        </div>
        <div class="form-group">
            <label>Durum</label>
            <select name="status" class="form-control">
                <option value="">Tümü</option>
                <option value="pending" <?php echo $statusFilter === 'pending' ? 'selected' : ''; ?>>Bekliyor</option>
                <option value="approved" <?php echo $statusFilter === 'approved' ? 'selected' : ''; ?>>Onaylandı</option>
                <option value="rejected" <?php echo $statusFilter === 'rejected' ? 'selected' : ''; ?>>Reddedildi</option>
            </select>
        </div>
        <div class="form-group">
            <label>Başlangıç</label>
            <input type="date" name="date_from" class="form-control" value="<?php echo $dateFrom; ?>">
        </div>
        <div class="form-group">
            <label>Bitiş</label>
            <input type="date" name="date_to" class="form-control" value="<?php echo $dateTo; ?>">
        </div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
        <a href="payments.php" class="btn btn-secondary"><i class="fas fa-times"></i></a>
    </form>
</div>

<!-- Payments Table -->
<div class="admin-card">
    <div class="card-header">
        <h2><i class="fas fa-money-check-alt"></i> Ödeme Bildirimleri</h2>
        <span class="badge" style="background: var(--primary-color); color: var(--on-primary-color); padding: 8px 16px; border-radius: 20px; font-size: 0.85rem;">
            Toplam: <?php echo $totalPayments; ?>
        </span>
    </div>
    <div class="card-body">
        <?php if (empty($payments)): ?>
            <div class="pay-empty">
                <i class="fas fa-inbox"></i>
                <p>Ödeme bildirimi bulunamadı</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="pay-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Kullanıcı</th>
                            <th>Tutar</th>
                            <th>Yöntem / Paket</th>
                            <th>Gönderen</th>
                            <th>Havale Ref.</th>
                            <th>Transfer</th>
                            <th>Durum</th>
                            <th>Tarih</th>
                            <th>İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($payments as $payment): 
                            $creditAmount = !empty($payment['credit_amount']) ? $payment['credit_amount'] : $payment['amount'];
                            $hasPackage = !empty($payment['package_id']);
                        ?>
                            <tr>
                                <td><strong>#<?php echo $payment['id']; ?></strong></td>
                                <td>
                                    <div class="pay-user">
                                        <div class="pay-user-avatar">
                                            <?php echo strtoupper(mb_substr($payment['username'] ?? 'U', 0, 1)); ?>
                                        </div>
                                        <div class="pay-user-info">
                                            <h5><?php echo clean($payment['username'] ?? 'Bilinmiyor'); ?></h5>
                                            <p><?php echo clean($payment['email'] ?? ''); ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="pay-amount">
                                        <div class="pay-amount-credit">
                                            <?php echo $siteSettings['currency_symbol'] . number_format($creditAmount, 2); ?>
                                        </div>
                                        <?php if ($hasPackage && $payment['amount'] != $creditAmount): ?>
                                            <div class="pay-amount-price">
                                                Ödenen: <span><?php echo $siteSettings['currency_symbol'] . number_format($payment['amount'], 2); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <div class="pay-method">
                                        <?php echo clean($payment['bank_name'] ?? $payment['method_name'] ?? 'Havale/EFT'); ?>
                                        <?php if ($hasPackage): ?>
                                            <br>
                                            <span class="pay-package">
                                                <i class="fas fa-box"></i>
                                                <?php echo clean($payment['package_name'] ?? 'Paket'); ?>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td><?php echo clean($payment['sender_name']); ?></td>
                                <td><code><?php echo clean($payment['payment_reference'] ?? '-'); ?></code></td>
                                <td>
                                    <div class="pay-date">
                                        <?php echo date('d.m.Y', strtotime($payment['transfer_date'])); ?>
                                        <small><?php echo date('H:i', strtotime($payment['transfer_date'])); ?></small>
                                    </div>
                                </td>
                                <td>
                                    <span class="pay-status <?php echo $payment['status']; ?>">
                                        <i class="fas fa-<?php echo $payment['status'] === 'pending' ? 'clock' : ($payment['status'] === 'approved' ? 'check' : 'times'); ?>"></i>
                                        <?php echo $statusNames[$payment['status']]; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="pay-date">
                                        <?php echo date('d.m.Y', strtotime($payment['created_at'])); ?>
                                        <small><?php echo date('H:i', strtotime($payment['created_at'])); ?></small>
                                    </div>
                                </td>
                                <td>
                                    <div class="pay-actions">
                                        <button type="button" class="pay-action view" onclick='viewPayment(<?php echo json_encode($payment, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>)' title="Detay">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <?php if ($payment['status'] === 'pending'): ?>
                                            <button type="button" class="pay-action approve" onclick='approvePayment(<?php echo json_encode($payment, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>)' title="Onayla">
                                                <i class="fas fa-check"></i>
                                            </button>
                                            <button type="button" class="pay-action reject" onclick='rejectPayment(<?php echo (int)$payment["id"]; ?>)' title="Reddet">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if ($totalPages > 1): ?>
                <div class="pay-pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>&status=<?php echo urlencode($statusFilter); ?>&search=<?php echo urlencode($search); ?>&date_from=<?php echo urlencode($dateFrom); ?>&date_to=<?php echo urlencode($dateTo); ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    <?php endif; ?>
                    
                    <?php 
                    $startPage = max(1, $page - 2);
                    $endPage = min($totalPages, $page + 2);
                    
                    if ($startPage > 1): ?>
                        <a href="?page=1&status=<?php echo urlencode($statusFilter); ?>&search=<?php echo urlencode($search); ?>&date_from=<?php echo urlencode($dateFrom); ?>&date_to=<?php echo urlencode($dateTo); ?>">1</a>
                        <?php if ($startPage > 2): ?><span>...</span><?php endif; ?>
                    <?php endif; ?>
                    
                    <?php for ($i = $startPage; $i <= $endPage; $i++): ?>
                        <?php if ($i == $page): ?>
                            <span class="current"><?php echo $i; ?></span>
                        <?php else: ?>
                            <a href="?page=<?php echo $i; ?>&status=<?php echo urlencode($statusFilter); ?>&search=<?php echo urlencode($search); ?>&date_from=<?php echo urlencode($dateFrom); ?>&date_to=<?php echo urlencode($dateTo); ?>"><?php echo $i; ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($endPage < $totalPages): ?>
                        <?php if ($endPage < $totalPages - 1): ?><span>...</span><?php endif; ?>
                        <a href="?page=<?php echo $totalPages; ?>&status=<?php echo urlencode($statusFilter); ?>&search=<?php echo urlencode($search); ?>&date_from=<?php echo urlencode($dateFrom); ?>&date_to=<?php echo urlencode($dateTo); ?>"><?php echo $totalPages; ?></a>
                    <?php endif; ?>
                    
                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?php echo $page + 1; ?>&status=<?php echo urlencode($statusFilter); ?>&search=<?php echo urlencode($search); ?>&date_from=<?php echo urlencode($dateFrom); ?>&date_to=<?php echo urlencode($dateTo); ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<!-- View Modal -->
<div class="pay-modal-overlay" id="viewModal">
    <div class="pay-modal-wrapper">
        <div class="pay-modal">
            <div class="pay-modal-header">
                <h3><i class="fas fa-receipt" style="color: var(--accent-text-color);"></i> Ödeme Detayı #<span id="viewId"></span></h3>
                <button type="button" class="pay-modal-close" onclick="closeModal('viewModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="pay-modal-body">
                <!-- Amount Summary -->
                <div class="pay-amount-summary">
                    <h4>Yüklenecek Bakiye</h4>
                    <p class="credit-value" id="viewCreditAmount"></p>
                    <p class="price-info" id="viewPriceInfo"></p>
                    <div class="package-info" id="viewPackageInfo" style="display: none;">
                        <i class="fas fa-box"></i>
                        <span id="viewPackageName"></span>
                    </div>
                </div>
                
                <div class="pay-detail-grid">
                    <div class="pay-detail-item">
                        <label>Kullanıcı</label>
                        <span id="viewUser"></span>
                    </div>
                    <div class="pay-detail-item">
                        <label>E-posta</label>
                        <span id="viewEmail"></span>
                    </div>
                    <div class="pay-detail-item">
                        <label>Gönderen Ad Soyad</label>
                        <span id="viewSender"></span>
                    </div>
                    <div class="pay-detail-item">
                        <label>Banka / Yöntem</label>
                        <span id="viewBank"></span>
                    </div>
                    <div class="pay-detail-item">
                        <label>Transfer Tarihi</label>
                        <span id="viewTransferDate"></span>
                    </div>
                    <div class="pay-detail-item">
                        <label>Havale Referansı</label>
                        <span id="viewPaymentReference"></span>
                    </div>
                    <div class="pay-detail-item">
                        <label>Bildirim Tarihi</label>
                        <span id="viewCreatedAt"></span>
                    </div>
                </div>
                
                <div class="pay-detail-item full" id="viewNoteContainer">
                    <label>Kullanıcı Notu</label>
                    <span id="viewNote">-</span>
                </div>
                
                <div class="pay-detail-item full" id="viewAdminNoteContainer" style="display: none;">
                    <label>Admin Notu</label>
                    <span id="viewAdminNote"></span>
                </div>
                
                <div class="pay-receipt" id="viewReceipt"></div>
            </div>
        </div>
    </div>
</div>

<!-- Approve Modal -->
<div class="pay-modal-overlay" id="approveModal">
    <div class="pay-modal-wrapper">
        <div class="pay-modal">
            <div class="pay-modal-header">
                <h3><i class="fas fa-check-circle" style="color: #28a745;"></i> Ödemeyi Onayla</h3>
                <button type="button" class="pay-modal-close" onclick="closeModal('approveModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form method="POST" id="approveForm">
                <div class="pay-modal-body">
                    <input type="hidden" name="payment_id" id="approvePaymentId">
                    
                    <div class="pay-approve-info">
                        <p>Kullanıcıya yüklenecek bakiye:</p>
                        <div class="amount" id="approveCreditAmount"></div>
                        <small id="approvePriceInfo"></small>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Admin Notu (Opsiyonel)</label>
                        <textarea name="admin_note" class="form-control" rows="3" placeholder="İsteğe bağlı not ekleyin..."></textarea>
                    </div>
                </div>
                <div class="pay-modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('approveModal')">
                        <i class="fas fa-times"></i> İptal
                    </button>
                    <button type="submit" name="approve_payment" class="btn btn-success">
                        <i class="fas fa-check"></i> Onayla ve Bakiye Yükle
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Reject Modal -->
<div class="pay-modal-overlay" id="rejectModal">
    <div class="pay-modal-wrapper">
        <div class="pay-modal">
            <div class="pay-modal-header">
                <h3><i class="fas fa-times-circle" style="color: #dc3545;"></i> Ödemeyi Reddet</h3>
                <button type="button" class="pay-modal-close" onclick="closeModal('rejectModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form method="POST" id="rejectForm">
                <div class="pay-modal-body">
                    <input type="hidden" name="payment_id" id="rejectPaymentId">
                    
                    <div class="alert alert-warning" style="margin-bottom: 20px;">
                        <i class="fas fa-exclamation-triangle"></i>
                        Bu işlem geri alınamaz. Kullanıcıya red nedeni gösterilecektir.
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Red Nedeni <span style="color: #dc3545;">*</span></label>
                        <textarea name="admin_note" class="form-control" rows="4" placeholder="Kullanıcıya gösterilecek red nedeni..." required></textarea>
                    </div>
                </div>
                <div class="pay-modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('rejectModal')">
                        <i class="fas fa-times"></i> İptal
                    </button>
                    <button type="submit" name="reject_payment" class="btn btn-danger">
                        <i class="fas fa-ban"></i> Reddet
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
(function() {
    'use strict';
    
    var currency = '<?php echo $siteSettings['currency_symbol']; ?>';
    
    // View Payment Details
    window.viewPayment = function(p) {
        var creditAmount = parseFloat(p.credit_amount) || parseFloat(p.amount);
        var paidAmount = parseFloat(p.amount);
        var hasPackage = p.package_id && p.package_name;
        
        document.getElementById('viewId').textContent = p.id;
        document.getElementById('viewUser').textContent = p.username || 'Bilinmiyor';
        document.getElementById('viewEmail').textContent = p.email || '-';
        document.getElementById('viewCreditAmount').textContent = currency + creditAmount.toFixed(2);
        
        // Price info
        var priceInfo = document.getElementById('viewPriceInfo');
        if (paidAmount !== creditAmount) {
            priceInfo.innerHTML = 'Ödenen tutar: <strong>' + currency + paidAmount.toFixed(2) + '</strong>';
            priceInfo.style.display = 'block';
        } else {
            priceInfo.style.display = 'none';
        }
        
        // Package info
        var packageInfo = document.getElementById('viewPackageInfo');
        if (hasPackage) {
            document.getElementById('viewPackageName').textContent = p.package_name;
            packageInfo.style.display = 'inline-flex';
        } else {
            packageInfo.style.display = 'none';
        }
        
        document.getElementById('viewSender').textContent = p.sender_name || '-';
        document.getElementById('viewBank').textContent = p.bank_name || p.method_name || 'Havale/EFT';
        document.getElementById('viewTransferDate').textContent = formatDate(p.transfer_date);
        document.getElementById('viewPaymentReference').textContent = p.payment_reference || '-';
        document.getElementById('viewCreatedAt').textContent = formatDate(p.created_at);
        document.getElementById('viewNote').textContent = p.note || '-';
        
        // Admin note
        var adminNoteContainer = document.getElementById('viewAdminNoteContainer');
        if (p.admin_note) {
            document.getElementById('viewAdminNote').textContent = p.admin_note;
            adminNoteContainer.style.display = 'block';
        } else {
            adminNoteContainer.style.display = 'none';
        }
        
        // Receipt
        var receiptDiv = document.getElementById('viewReceipt');
        if (p.receipt_image) {
            var ext = p.receipt_image.split('.').pop().toLowerCase();
            if (ext === 'pdf') {
                receiptDiv.innerHTML = '<a href="/' + p.receipt_image + '" target="_blank" class="pay-receipt-link"><i class="fas fa-file-pdf"></i> Dekontu Görüntüle (PDF)</a>';
            } else {
                receiptDiv.innerHTML = '<img src="/' + p.receipt_image + '" onclick="window.open(this.src)" alt="Dekont">';
            }
        } else {
            receiptDiv.innerHTML = '<div class="pay-receipt-empty"><i class="fas fa-image"></i><p>Dekont yüklenmemiş</p></div>';
        }
        
        openModal('viewModal');
    };
    
    // Approve Payment
    window.approvePayment = function(p) {
        var creditAmount = parseFloat(p.credit_amount) || parseFloat(p.amount);
        var paidAmount = parseFloat(p.amount);
        
        document.getElementById('approvePaymentId').value = p.id;
        document.getElementById('approveCreditAmount').textContent = currency + creditAmount.toFixed(2);
        
        var priceInfo = document.getElementById('approvePriceInfo');
        if (paidAmount !== creditAmount) {
            priceInfo.textContent = 'Kullanıcı ' + currency + paidAmount.toFixed(2) + ' ödedi' + (p.package_name ? ' (' + String(p.package_name) + ' Paketi)' : '');
            priceInfo.style.display = 'block';
        } else {
            priceInfo.style.display = 'none';
        }
        
        openModal('approveModal');
    };
    
    // Reject Payment
    window.rejectPayment = function(id) {
        document.getElementById('rejectPaymentId').value = id;
        openModal('rejectModal');
    };
    
    // Modal Functions
    window.openModal = function(id) {
        document.getElementById(id).classList.add('active');
        document.body.style.overflow = 'hidden';
    };
    
    window.closeModal = function(id) {
        document.getElementById(id).classList.remove('active');
        document.body.style.overflow = '';
    };
    
    // Format date
    function formatDate(dateStr) {
        if (!dateStr) return '-';
        var d = new Date(dateStr);
        if (isNaN(d.getTime())) return dateStr;
        
        var day = String(d.getDate()).padStart(2, '0');
        var month = String(d.getMonth() + 1).padStart(2, '0');
        var year = d.getFullYear();
        var hours = String(d.getHours()).padStart(2, '0');
        var minutes = String(d.getMinutes()).padStart(2, '0');
        
        return day + '.' + month + '.' + year + ' ' + hours + ':' + minutes;
    }
    
    // Close modal on overlay click
    document.querySelectorAll('.pay-modal-overlay').forEach(function(overlay) {
        overlay.addEventListener('click', function(e) {
            if (e.target === this || e.target.classList.contains('pay-modal-wrapper')) {
                this.classList.remove('active');
                document.body.style.overflow = '';
            }
        });
    });
    
    // Close modal on ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.pay-modal-overlay.active').forEach(function(modal) {
                modal.classList.remove('active');
            });
            document.body.style.overflow = '';
        }
    });
    
    // Close button events
    document.querySelectorAll('.pay-modal-close').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var modal = this.closest('.pay-modal-overlay');
            if (modal) {
                modal.classList.remove('active');
                document.body.style.overflow = '';
            }
        });
    });
})();
</script>

<?php require_once 'footer.php'; ?>