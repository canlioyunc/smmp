<?php
/**
 * Admin Panel - SMTP Ayarları
 */

require_once __DIR__ . '/../config.php';

// Demo mode kontrolü
$demoMode = false;
try {
    $dm = $db->prepare("SELECT setting_value FROM settings WHERE setting_key = 'demo_mode' LIMIT 1");
    $dm->execute();
    $demoMode = trim((string)$dm->fetchColumn()) === '1';
} catch (Exception $e) {
    $demoMode = false;
}

// SMTP ayarlarını al
$smtpSettings = [];
$stmt = $db->query("SELECT setting_key, setting_value FROM settings WHERE setting_key LIKE 'smtp_%'");
while ($row = $stmt->fetch()) {
    $smtpSettings[$row['setting_key']] = $row['setting_value'];
}

// Form gönderildi mi?
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Demo modda işlemleri engelle
    if ($demoMode) {
        setAlert('Demo modunda SMTP ayarları değiştirilemez.', 'warning');
        header('Location: smtp-settings.php');
        exit;
    }
    
    if (isset($_POST['save_settings'])) {
        $fields = [
            'smtp_enabled' => isset($_POST['smtp_enabled']) ? '1' : '0',
            'smtp_host' => trim($_POST['smtp_host'] ?? ''),
            'smtp_port' => (int)($_POST['smtp_port'] ?? 587),
            'smtp_username' => trim($_POST['smtp_username'] ?? ''),
            'smtp_password' => $_POST['smtp_password'] ?? '',
            'smtp_encryption' => $_POST['smtp_encryption'] ?? 'tls',
            'smtp_from_email' => trim($_POST['smtp_from_email'] ?? ''),
            'smtp_from_name' => trim($_POST['smtp_from_name'] ?? '')
        ];
        
        // Şifre boş bırakıldıysa eskisini koru
        if (empty($fields['smtp_password']) && !empty($smtpSettings['smtp_password'])) {
            $fields['smtp_password'] = $smtpSettings['smtp_password'];
        }
        
        if (!empty($fields['smtp_password'])) $fields['smtp_password'] = moni_encrypt_secret($fields['smtp_password']);
        foreach ($fields as $key => $value) {
            $stmt = $db->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
            $stmt->execute([$key, $value, $value]);
        }
        
        setAlert('SMTP ayarları başarıyla kaydedildi.', 'success');
        header('Location: smtp-settings.php');
        exit;
    }
    
    // Test e-postası gönder
    if (isset($_POST['test_email'])) {
        $testEmail = trim($_POST['test_email_address'] ?? '');
        
        if (empty($testEmail) || !filter_var($testEmail, FILTER_VALIDATE_EMAIL)) {
            setAlert('Geçerli bir e-posta adresi girin.', 'danger');
        } else {
            require_once __DIR__ . '/../includes/mail.php';
            
            $result = sendEmail(
                $testEmail,
                'SMTP Test E-postası - ' . ($siteSettings['name'] ?? 'Site'),
                '<div style="font-family: Arial, sans-serif; padding: 20px;">
                    <h2 style="color: #28a745;">✓ SMTP Bağlantısı Başarılı!</h2>
                    <p>Bu e-posta, SMTP ayarlarınızın doğru yapılandırıldığını göstermektedir.</p>
                    <p><strong>Tarih:</strong> ' . date('d.m.Y H:i:s') . '</p>
                    <hr>
                    <p style="color: #666; font-size: 12px;">' . ($siteSettings['name'] ?? 'Site') . '</p>
                </div>'
            );
            
            if ($result['success']) {
                setAlert('Test e-postası başarıyla gönderildi: ' . $testEmail, 'success');
            } else {
                setAlert($result['message'], 'danger');
            }
        }
        header('Location: smtp-settings.php');
        exit;
    }
}

$pageTitle = "SMTP Ayarları";
require_once 'header.php';
?>

<style>
.settings-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}

@media (max-width: 768px) {
    .settings-grid {
        grid-template-columns: 1fr;
    }
}

.toggle-switch {
    position: relative;
    width: 50px;
    height: 26px;
}

.toggle-switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.toggle-slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: var(--border-color);
    transition: 0.3s;
    border-radius: 26px;
}

.toggle-slider:before {
    position: absolute;
    content: "";
    height: 20px;
    width: 20px;
    left: 3px;
    bottom: 3px;
    background-color: white;
    transition: 0.3s;
    border-radius: 50%;
}

.toggle-switch input:checked + .toggle-slider {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
}

.toggle-switch input:checked + .toggle-slider:before {
    transform: translateX(24px);
}

.info-box {
    background: rgba(23, 162, 184, 0.1);
    border: 1px solid rgba(23, 162, 184, 0.3);
    border-radius: 10px;
    padding: 15px;
    margin-bottom: 20px;
}

.info-box h4 {
    color: #17a2b8;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.info-box ul {
    margin: 0;
    padding-left: 20px;
    color: var(--text-color);
    opacity: 0.8;
}

.info-box li {
    margin-bottom: 5px;
}

.test-section {
    background: var(--background-color);
    border-radius: 12px;
    padding: 20px;
    margin-top: 20px;
}

.test-section h4 {
    margin-bottom: 15px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.test-section h4 i {
    color: var(--accent-text-color);
}

.input-group {
    display: flex;
    gap: 10px;
}

.input-group .form-control {
    flex: 1;
}

/* Demo Mode Styles */
.demo-banner {
    display: flex;
    align-items: center;
    gap: 15px;
    background: linear-gradient(135deg, #f39c12, #e67e22);
    color: #fff;
    padding: 18px 25px;
    border-radius: 12px;
    margin-bottom: 25px;
    box-shadow: 0 4px 15px rgba(243, 156, 18, 0.3);
}

.demo-banner i {
    font-size: 1.8rem;
    animation: pulse-demo 2s infinite;
}

@keyframes pulse-demo {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.7; transform: scale(1.1); }
}

.demo-banner-content h4 {
    font-size: 1.1rem;
    font-weight: 700;
    margin-bottom: 3px;
}

.demo-banner-content p {
    font-size: 0.85rem;
    opacity: 0.9;
    margin: 0;
}

.form-disabled {
    opacity: 0.7;
    pointer-events: none;
}

.form-disabled input,
.form-disabled select,
.form-disabled textarea {
    background: var(--surface-alt-color) !important;
    cursor: not-allowed;
}

.btn-disabled {
    opacity: 0.5 !important;
    cursor: not-allowed !important;
    pointer-events: none !important;
}

.demo-hidden-input {
    background: var(--surface-alt-color) !important;
    color: var(--muted-text-color) !important;
    letter-spacing: 2px;
    cursor: not-allowed;
}
</style>

<?php if ($demoMode): ?>
<div class="demo-banner">
    <i class="fas fa-flask"></i>
    <div class="demo-banner-content">
        <h4>Demo Modu Aktif</h4>
        <p>SMTP ayarlarını görüntüleyebilirsiniz ancak değişiklik yapamazsınız. Hassas bilgiler gizlenmektedir.</p>
    </div>
</div>
<?php endif; ?>

<div class="admin-card">
    <div class="card-header">
        <h2><i class="fas fa-cogs"></i> SMTP Ayarları</h2>
    </div>
    <div class="card-body">
        <div class="info-box">
            <h4><i class="fas fa-info-circle"></i> Popüler SMTP Sunucuları</h4>
            <ul>
                <li><strong>Gmail:</strong> smtp.gmail.com, Port: 587, TLS (Uygulama şifresi gerekli)</li>
                <li><strong>Yandex:</strong> smtp.yandex.com, Port: 465, SSL</li>
                <li><strong>Outlook:</strong> smtp-mail.outlook.com, Port: 587, TLS</li>
                <li><strong>Yahoo:</strong> smtp.mail.yahoo.com, Port: 465, SSL</li>
            </ul>
        </div>
        
        <form method="POST" class="<?php echo $demoMode ? 'form-disabled' : ''; ?>">
            <div class="form-group">
                <label class="form-label">SMTP Durumu</label>
                <label class="toggle-switch">
                    <input type="checkbox" name="smtp_enabled" value="1" <?php echo ($smtpSettings['smtp_enabled'] ?? '0') === '1' ? 'checked' : ''; ?> <?php echo $demoMode ? 'disabled' : ''; ?>>
                    <span class="toggle-slider"></span>
                </label>
                <small style="display: block; margin-top: 5px; opacity: 0.6;">SMTP üzerinden e-posta gönderimini aktif/pasif yapın</small>
            </div>
            
            <div class="settings-grid">
                <div class="form-group">
                    <label class="form-label">SMTP Sunucu</label>
                    <?php if ($demoMode && !empty($smtpSettings['smtp_host'])): ?>
                    <input type="text" class="form-control demo-hidden-input" value="••••••••••••••••" disabled>
                    <?php else: ?>
                    <input type="text" name="smtp_host" class="form-control" value="<?php echo clean($smtpSettings['smtp_host'] ?? ''); ?>" placeholder="smtp.gmail.com" <?php echo $demoMode ? 'disabled' : ''; ?>>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Port</label>
                    <input type="number" name="smtp_port" class="form-control" value="<?php echo clean($smtpSettings['smtp_port'] ?? '587'); ?>" placeholder="587" <?php echo $demoMode ? 'disabled' : ''; ?>>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Kullanıcı Adı (E-posta)</label>
                    <?php if ($demoMode && !empty($smtpSettings['smtp_username'])): ?>
                    <input type="text" class="form-control demo-hidden-input" value="••••••••••••••••" disabled>
                    <?php else: ?>
                    <input type="text" name="smtp_username" class="form-control" value="<?php echo clean($smtpSettings['smtp_username'] ?? ''); ?>" placeholder="ornek@gmail.com" <?php echo $demoMode ? 'disabled' : ''; ?>>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Şifre</label>
                    <?php if ($demoMode): ?>
                    <input type="text" class="form-control demo-hidden-input" value="••••••••••••••••" disabled>
                    <?php else: ?>
                    <input type="password" name="smtp_password" class="form-control" placeholder="<?php echo !empty($smtpSettings['smtp_password']) ? '••••••••' : 'Şifre girin'; ?>">
                    <small style="opacity: 0.6;">Değiştirmek istemiyorsanız boş bırakın</small>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Şifreleme</label>
                    <select name="smtp_encryption" class="form-control" <?php echo $demoMode ? 'disabled' : ''; ?>>
                        <option value="tls" <?php echo ($smtpSettings['smtp_encryption'] ?? 'tls') === 'tls' ? 'selected' : ''; ?>>TLS</option>
                        <option value="ssl" <?php echo ($smtpSettings['smtp_encryption'] ?? '') === 'ssl' ? 'selected' : ''; ?>>SSL</option>
                        <option value="none" <?php echo ($smtpSettings['smtp_encryption'] ?? '') === 'none' ? 'selected' : ''; ?>>Yok</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Gönderen E-posta</label>
                    <?php if ($demoMode && !empty($smtpSettings['smtp_from_email'])): ?>
                    <input type="text" class="form-control demo-hidden-input" value="••••••••••••••••" disabled>
                    <?php else: ?>
                    <input type="email" name="smtp_from_email" class="form-control" value="<?php echo clean($smtpSettings['smtp_from_email'] ?? ''); ?>" placeholder="noreply@siteniz.com" <?php echo $demoMode ? 'disabled' : ''; ?>>
                    <small style="opacity: 0.6;">Boş bırakılırsa kullanıcı adı kullanılır</small>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Gönderen Adı</label>
                    <input type="text" name="smtp_from_name" class="form-control" value="<?php echo clean($smtpSettings['smtp_from_name'] ?? ''); ?>" placeholder="<?php echo clean($siteSettings['name'] ?? 'Site Adı'); ?>" <?php echo $demoMode ? 'disabled' : ''; ?>>
                </div>
            </div>
            
            <?php if ($demoMode): ?>
            <button type="button" class="btn btn-primary btn-disabled" disabled>
                <i class="fas fa-lock"></i> Demo Modunda Kaydetme Kapalı
            </button>
            <?php else: ?>
            <button type="submit" name="save_settings" class="btn btn-primary">
                <i class="fas fa-save"></i> Ayarları Kaydet
            </button>
            <?php endif; ?>
        </form>
        
        <div class="test-section">
            <h4><i class="fas fa-paper-plane"></i> Test E-postası Gönder</h4>
            <?php if ($demoMode): ?>
            <p style="opacity: 0.6; margin-bottom: 15px;">Demo modunda test e-postası gönderilemez.</p>
            <div class="input-group">
                <input type="email" class="form-control" placeholder="test@ornek.com" disabled>
                <button type="button" class="btn btn-success btn-disabled" disabled>
                    <i class="fas fa-lock"></i> Demo Modu
                </button>
            </div>
            <?php else: ?>
            <form method="POST">
                <div class="input-group">
                    <input type="email" name="test_email_address" class="form-control" placeholder="test@ornek.com" required>
                    <button type="submit" name="test_email" class="btn btn-success">
                        <i class="fas fa-paper-plane"></i> Test Gönder
                    </button>
                </div>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php if ($demoMode): ?>
<script>
// Demo modda form gönderimini engelle
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Demo modunda SMTP ayarları değiştirilemez.');
        return false;
    });
});
</script>
<?php endif; ?>

<?php require_once 'footer.php'; ?>