<?php
/**
 * Admin Panel - Blog Yönetimi
 */
require_once __DIR__ . '/../config.php';

// Admin kontrolü
if (!isLoggedIn() || !isAdmin()) {
    header('Location: /login.php');
    exit;
}

// Demo mode kontrolü
$demoMode = false;
try {
    $dm = $db->prepare("SELECT setting_value FROM settings WHERE setting_key = 'demo_mode' LIMIT 1");
    $dm->execute();
    $demoMode = trim((string)$dm->fetchColumn()) === '1';
} catch (Exception $e) {
    $demoMode = false;
}

// Upload klasörünü oluştur
$uploadDir = __DIR__ . '/../uploads/blog/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// Slug oluştur
function createSlug($text) {
    $text = mb_strtolower($text, 'UTF-8');
    $turkce = ['ç', 'ğ', 'ı', 'ö', 'ş', 'ü', 'Ç', 'Ğ', 'İ', 'Ö', 'Ş', 'Ü'];
    $latin = ['c', 'g', 'i', 'o', 's', 'u', 'c', 'g', 'i', 'o', 's', 'u'];
    $text = str_replace($turkce, $latin, $text);
    $text = preg_replace('/[^a-z0-9\-]/', '-', $text);
    $text = preg_replace('/-+/', '-', $text);
    $text = trim($text, '-');
    return $text;
}

// İşlemler
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Demo modda tüm işlemleri engelle
    if ($demoMode) {
        setAlert('Demo modunda blog yazısı eklenemez, düzenlenemez veya silinemez.', 'warning');
        header('Location: blog.php');
        exit;
    }
    
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create' || $action === 'update') {
        $title = trim($_POST['title']);
        $slug = trim($_POST['slug']) ?: createSlug($title);
        $excerpt = trim($_POST['excerpt']);
        $content = moni_sanitize_admin_html((string)($_POST['content'] ?? ''));
        $metaTitle = trim($_POST['meta_title']);
        $metaDescription = trim($_POST['meta_description']);
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $featuredImage = $_POST['current_image'] ?? null;
        
        // Slug benzersizlik kontrolü
        $checkSlug = $db->prepare("SELECT id FROM blog_posts WHERE slug = ? AND id != ?");
        $checkSlug->execute([$slug, $_POST['id'] ?? 0]);
        if ($checkSlug->fetch()) {
            $slug = $slug . '-' . time();
        }
        
        // Görsel yükleme - MIME doğrulaması ve güvenli sunucu uzantısı
        if (!empty($_FILES['featured_image']['name'])) {
            $upload = moni_safe_upload($_FILES['featured_image'], 'blog', ['image/jpeg','image/png','image/gif','image/webp'], 10 * 1024 * 1024);
            if (!$upload['ok']) {
                setAlert($upload['error'], 'danger'); header('Location: blog.php'); exit;
            }
            $newFeaturedImage = '/' . ltrim($upload['path'], '/');
            if ($featuredImage && strpos($featuredImage, '/uploads/blog/') === 0) {
                $oldFile = __DIR__ . '/..' . $featuredImage; if (is_file($oldFile)) @unlink($oldFile);
            }
            $featuredImage = $newFeaturedImage;
        }

        if ($action === 'create') {
            $stmt = $db->prepare("INSERT INTO blog_posts (title, slug, excerpt, content, featured_image, meta_title, meta_description, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$title, $slug, $excerpt, $content, $featuredImage, $metaTitle, $metaDescription, $isActive]);
            setAlert('Blog yazısı eklendi.', 'success');
        } else {
            $stmt = $db->prepare("UPDATE blog_posts SET title=?, slug=?, excerpt=?, content=?, featured_image=?, meta_title=?, meta_description=?, is_active=? WHERE id=?");
            $stmt->execute([$title, $slug, $excerpt, $content, $featuredImage, $metaTitle, $metaDescription, $isActive, (int)$_POST['id']]);
            setAlert('Blog yazısı güncellendi.', 'success');
        }
        header('Location: blog.php');
        exit;
    }
    
    if ($action === 'delete' && !empty($_POST['id'])) {
        // Görseli sil
        $stmt = $db->prepare("SELECT featured_image FROM blog_posts WHERE id = ?");
        $stmt->execute([(int)$_POST['id']]);
        $post = $stmt->fetch();
        
        if ($post && $post['featured_image'] && strpos($post['featured_image'], '/uploads/blog/') === 0) {
            $oldFile = __DIR__ . '/..' . $post['featured_image'];
            if (file_exists($oldFile)) unlink($oldFile);
        }
        
        $stmt = $db->prepare("DELETE FROM blog_posts WHERE id = ?");
        $stmt->execute([(int)$_POST['id']]);
        setAlert('Blog yazısı silindi.', 'success');
        header('Location: blog.php');
        exit;
    }
    
    if ($action === 'toggle' && !empty($_POST['id'])) {
        $stmt = $db->prepare("UPDATE blog_posts SET is_active = 1 - is_active WHERE id = ?");
        $stmt->execute([(int)$_POST['id']]);
        setAlert('Durum değiştirildi.', 'success');
        header('Location: blog.php');
        exit;
    }
}

// Blog yazılarını getir
$posts = $db->query("SELECT * FROM blog_posts ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Blog Yönetimi';
require_once __DIR__ . '/header.php';
?>
<style>
.blog-table { width:100%; border-collapse:collapse; }
.blog-table th, .blog-table td { padding:12px 10px; border-bottom:1px solid var(--border-color); text-align:left; vertical-align:middle; }
.blog-table th { font-weight:600; font-size:.85rem; opacity:.7; }
.blog-thumb { width:60px; height:40px; border-radius:6px; object-fit:cover; background:var(--background-color); }
.blog-thumb-placeholder { width:60px; height:40px; border-radius:6px; background:var(--background-color); display:flex; align-items:center; justify-content:center; color:var(--accent-text-color); font-size:1.2rem; }
.blog-title { font-weight:600; margin-bottom:3px; }
.blog-excerpt { font-size:.8rem; opacity:.6; max-width:300px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.blog-meta { font-size:.75rem; opacity:.5; }
.status-dot { width:10px; height:10px; border-radius:50%; display:inline-block; margin-right:5px; }
.status-on { background:#28a745; }
.status-off { background:#6c757d; }
.blog-actions { display:flex; gap:6px; }
.blog-actions button { border:none; padding:8px 10px; border-radius:8px; cursor:pointer; font-size:.85rem; }
.btn-icon { width:32px; height:32px; display:inline-flex; align-items:center; justify-content:center; }
.btn-soft { background:var(--background-color); color:var(--text-color); border:1px solid var(--border-color); }
.btn-soft.danger { color:#dc3545; border-color:rgba(220,53,69,.4); }
.btn-soft.primary { color:var(--accent-text-color); border-color:var(--primary-alpha-04); }
.btn-soft.disabled { opacity:.4; cursor:not-allowed; pointer-events:none; }
.view-count { display:inline-flex; align-items:center; gap:4px; font-size:.8rem; opacity:.6; }

#blogModal { display:none; position:fixed; top:0; left:0; right:0; bottom:0; z-index:9999; background:rgba(0,0,0,.6); align-items:center; justify-content:center; padding:20px; }
#blogModal.active { display:flex !important; }
.modal-box { background:var(--card-bg-color); border-radius:14px; max-width:900px; width:100%; max-height:90vh; overflow-y:auto; border:1px solid var(--border-color); }
.modal-header { padding:16px 18px; border-bottom:1px solid var(--border-color); display:flex; align-items:center; justify-content:space-between; position:sticky; top:0; background:var(--card-bg-color); z-index:10; }
.modal-header h3 { margin:0; font-size:1.1rem; }
.modal-body { padding:18px; }
.modal-footer { padding:16px 18px; border-top:1px solid var(--border-color); display:flex; gap:10px; justify-content:flex-end; position:sticky; bottom:0; background:var(--card-bg-color); }
.modal-close { background:var(--background-color); border:none; width:34px; height:34px; border-radius:8px; cursor:pointer; font-size:1.2rem; }
.modal-close:hover { background:var(--danger-color); color:var(--on-danger-color); }

.form-row { display:grid; grid-template-columns:1fr 1fr; gap:15px; }
@media (max-width:700px) { .form-row { grid-template-columns:1fr; } }

.form-section { background:var(--background-color); border-radius:10px; padding:15px; margin-bottom:15px; }
.form-section-title { font-size:.85rem; font-weight:600; margin-bottom:12px; color:var(--accent-text-color); display:flex; align-items:center; gap:8px; }

.file-upload-area { border:2px dashed var(--border-color); border-radius:10px; padding:20px; text-align:center; cursor:pointer; transition:all .3s ease; margin-bottom:10px; }
.file-upload-area:hover { border-color:var(--accent-text-color); background:var(--primary-alpha-005); }
.file-upload-area i { font-size:2rem; color:var(--accent-text-color); margin-bottom:10px; }
.file-upload-area p { margin:0; font-size:.85rem; opacity:.7; }
.file-upload-area .file-name { margin-top:8px; font-weight:600; color:var(--accent-text-color); }
.file-upload-area input[type="file"] { display:none; }

.current-image { display:flex; align-items:center; gap:10px; padding:10px; background:var(--card-bg-color); border-radius:8px; margin-bottom:10px; }
.current-image img { width:80px; height:50px; object-fit:cover; border-radius:6px; }
.current-image-info { flex:1; font-size:.8rem; }
.btn-remove-image { background:#dc3545; color:#fff; border:none; padding:5px 10px; border-radius:6px; font-size:.75rem; cursor:pointer; }

.editor-toolbar { display:flex; gap:5px; flex-wrap:wrap; padding:10px; background:var(--card-bg-color); border:1px solid var(--border-color); border-bottom:none; border-radius:8px 8px 0 0; }
.editor-btn { width:32px; height:32px; border:none; background:var(--background-color); border-radius:6px; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:all .2s; }
.editor-btn:hover { background:var(--primary-color); color:var(--on-primary-color); }
.editor-textarea { border-radius:0 0 8px 8px !important; min-height:250px; font-family:inherit; }

/* Demo Mode Styles */
.demo-banner {
    display: flex;
    align-items: center;
    gap: 15px;
    background: linear-gradient(135deg, #f39c12, #e67e22);
    color: #fff;
    padding: 18px 25px;
    border-radius: 12px;
    margin-bottom: 25px;
    box-shadow: 0 4px 15px rgba(243, 156, 18, 0.3);
}

.demo-banner i {
    font-size: 1.8rem;
    animation: pulse-demo 2s infinite;
}

@keyframes pulse-demo {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.7; transform: scale(1.1); }
}

.demo-banner-content h4 {
    font-size: 1.1rem;
    font-weight: 700;
    margin-bottom: 3px;
}

.demo-banner-content p {
    font-size: 0.85rem;
    opacity: 0.9;
    margin: 0;
}

.btn-disabled {
    opacity: 0.5 !important;
    cursor: not-allowed !important;
    pointer-events: none !important;
}

@media (max-width:768px) {
    .blog-table th, .blog-table td { padding:10px 8px; }
    .modal-box { margin:10px; max-width:100%; }
    .blog-excerpt { display:none; }
}
</style>

<?php if ($demoMode): ?>
<div class="demo-banner">
    <i class="fas fa-flask"></i>
    <div class="demo-banner-content">
        <h4>Demo Modu Aktif</h4>
        <p>Blog yazılarını görüntüleyebilirsiniz ancak ekleme, düzenleme ve silme işlemleri yapılamaz.</p>
    </div>
</div>
<?php endif; ?>

<div class="admin-card">
    <div class="card-header">
        <h2><i class="fas fa-blog"></i> Blog Yazıları</h2>
        <?php if ($demoMode): ?>
        <button type="button" class="btn btn-primary btn-disabled" disabled><i class="fas fa-lock"></i> Demo Modu</button>
        <?php else: ?>
        <button type="button" class="btn btn-primary" id="newPostBtn"><i class="fas fa-plus"></i> Yeni Yazı</button>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <?php if (empty($posts)): ?>
            <div class="alert alert-info"><i class="fas fa-info-circle"></i> Henüz blog yazısı yok.</div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="blog-table">
                <thead>
                    <tr>
                        <th>Görsel</th>
                        <th>Başlık</th>
                        <th>Durum</th>
                        <th>Görüntülenme</th>
                        <th>Tarih</th>
                        <th>İşlem</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($posts as $post): ?>
                    <tr>
                        <td>
                            <?php if ($post['featured_image']): ?>
                                <img src="<?php echo clean($post['featured_image']); ?>" alt="" class="blog-thumb">
                            <?php else: ?>
                                <div class="blog-thumb-placeholder"><i class="fas fa-image"></i></div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="blog-title"><?php echo clean($post['title']); ?></div>
                            <div class="blog-excerpt"><?php echo clean($post['excerpt']); ?></div>
                            <div class="blog-meta">/blog/<?php echo clean($post['slug']); ?></div>
                        </td>
                        <td>
                            <span class="status-dot <?php echo $post['is_active'] ? 'status-on' : 'status-off'; ?>"></span>
                            <?php echo $post['is_active'] ? 'Aktif' : 'Pasif'; ?>
                        </td>
                        <td>
                            <span class="view-count"><i class="fas fa-eye"></i> <?php echo number_format($post['view_count']); ?></span>
                        </td>
                        <td><?php echo date('d.m.Y H:i', strtotime($post['created_at'])); ?></td>
                        <td>
                            <div class="blog-actions">
                                <a href="/blog/<?php echo clean($post['slug']); ?>" target="_blank" class="btn-soft btn-icon" title="Görüntüle"><i class="fas fa-eye"></i></a>
                                <?php if ($demoMode): ?>
                                <button type="button" class="btn-soft primary btn-icon disabled" title="Demo modunda düzenleme kapalı"><i class="fas fa-lock"></i></button>
                                <button type="button" class="btn-soft danger btn-icon disabled" title="Demo modunda silme kapalı"><i class="fas fa-lock"></i></button>
                                <button type="button" class="btn-soft btn-icon disabled" title="Demo modunda durum değiştirme kapalı"><i class="fas fa-lock"></i></button>
                                <?php else: ?>
                                <button type="button" class="btn-soft primary btn-icon edit-btn"
                                        data-id="<?php echo $post['id']; ?>"
                                        data-title="<?php echo htmlspecialchars($post['title'], ENT_QUOTES, 'UTF-8'); ?>"
                                        data-slug="<?php echo htmlspecialchars($post['slug'], ENT_QUOTES, 'UTF-8'); ?>"
                                        data-excerpt="<?php echo htmlspecialchars($post['excerpt'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                        data-content="<?php echo htmlspecialchars($post['content'], ENT_QUOTES, 'UTF-8'); ?>"
                                        data-image="<?php echo htmlspecialchars($post['featured_image'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                        data-meta-title="<?php echo htmlspecialchars($post['meta_title'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                        data-meta-description="<?php echo htmlspecialchars($post['meta_description'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                        data-active="<?php echo $post['is_active']; ?>"
                                        title="Düzenle">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('Silinsin mi?');">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?php echo $post['id']; ?>">
                                    <button type="submit" class="btn-soft danger btn-icon" title="Sil"><i class="fas fa-trash"></i></button>
                                </form>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="toggle">
                                    <input type="hidden" name="id" value="<?php echo $post['id']; ?>">
                                    <button type="submit" class="btn-soft btn-icon" title="Aktif/Pasif"><i class="fas fa-power-off"></i></button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php if (!$demoMode): ?>
<!-- Modal - Sadece demo modu kapalıyken göster -->
<div id="blogModal">
    <div class="modal-box">
        <div class="modal-header">
            <h3 id="modalTitle"><i class="fas fa-blog"></i> Blog Yazısı</h3>
            <button type="button" class="modal-close" id="modalCloseBtn">&times;</button>
        </div>
        <form method="POST" id="blogForm" enctype="multipart/form-data">
            <div class="modal-body">
                <input type="hidden" name="action" id="formAction" value="create">
                <input type="hidden" name="id" id="postId">
                <input type="hidden" name="current_image" id="currentImage">
                
                <!-- Temel Bilgiler -->
                <div class="form-section">
                    <div class="form-section-title"><i class="fas fa-info-circle"></i> Temel Bilgiler</div>
                    <div class="form-group">
                        <label class="form-label">Başlık *</label>
                        <input type="text" name="title" id="postTitle" class="form-control" required placeholder="Blog yazısı başlığı">
                    </div>
                    <div class="form-group">
                        <label class="form-label">URL (Slug)</label>
                        <input type="text" name="slug" id="postSlug" class="form-control" placeholder="otomatik-olusturulur">
                        <small style="opacity:.6;">Boş bırakılırsa başlıktan otomatik oluşturulur</small>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Kısa Özet</label>
                        <textarea name="excerpt" id="postExcerpt" class="form-control" rows="2" placeholder="Yazının kısa özeti (liste sayfasında görünür)"></textarea>
                    </div>
                </div>
                
                <!-- İçerik -->
                <div class="form-section">
                    <div class="form-section-title"><i class="fas fa-file-alt"></i> İçerik</div>
                    <div class="form-group">
                        <label class="form-label">Yazı İçeriği *</label>
                        <div class="editor-toolbar">
                            <button type="button" class="editor-btn" onclick="insertTag('b')" title="Kalın"><i class="fas fa-bold"></i></button>
                            <button type="button" class="editor-btn" onclick="insertTag('i')" title="İtalik"><i class="fas fa-italic"></i></button>
                            <button type="button" class="editor-btn" onclick="insertTag('u')" title="Altı Çizili"><i class="fas fa-underline"></i></button>
                            <button type="button" class="editor-btn" onclick="insertTag('h2')" title="Başlık 2"><i class="fas fa-heading"></i></button>
                            <button type="button" class="editor-btn" onclick="insertTag('h3')" title="Başlık 3"><i class="fas fa-heading" style="font-size:.8rem;"></i></button>
                            <button type="button" class="editor-btn" onclick="insertTag('p')" title="Paragraf"><i class="fas fa-paragraph"></i></button>
                            <button type="button" class="editor-btn" onclick="insertTag('ul')" title="Liste"><i class="fas fa-list-ul"></i></button>
                            <button type="button" class="editor-btn" onclick="insertTag('ol')" title="Numaralı Liste"><i class="fas fa-list-ol"></i></button>
                            <button type="button" class="editor-btn" onclick="insertLink()" title="Link"><i class="fas fa-link"></i></button>
                            <button type="button" class="editor-btn" onclick="insertImage()" title="Resim"><i class="fas fa-image"></i></button>
                            <button type="button" class="editor-btn" onclick="insertTag('blockquote')" title="Alıntı"><i class="fas fa-quote-left"></i></button>
                            <button type="button" class="editor-btn" onclick="insertTag('code')" title="Kod"><i class="fas fa-code"></i></button>
                        </div>
                        <textarea name="content" id="postContent" class="form-control editor-textarea" required placeholder="Yazı içeriğini buraya yazın... HTML kullanabilirsiniz."></textarea>
                    </div>
                </div>
                
                <!-- Görsel -->
                <div class="form-section">
                    <div class="form-section-title"><i class="fas fa-image"></i> Öne Çıkan Görsel</div>
                    <div class="current-image" id="currentImageBox" style="display:none;">
                        <img id="currentImagePreview" src="" alt="">
                        <div class="current-image-info">
                            <strong>Mevcut Görsel</strong>
                            <span id="currentImageName"></span>
                        </div>
                        <button type="button" class="btn-remove-image" id="removeImageBtn"><i class="fas fa-trash"></i> Kaldır</button>
                    </div>
                    <div class="file-upload-area" id="fileUploadArea">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <p>Görsel yüklemek için tıklayın veya sürükleyin</p>
                        <p style="font-size:.75rem;margin-top:5px;">JPG, PNG, GIF, WEBP (Max: 10MB)</p>
                        <div class="file-name" id="fileName"></div>
                        <input type="file" name="featured_image" id="featuredImage" accept="image/*">
                    </div>
                </div>
                
                <!-- SEO -->
                <div class="form-section">
                    <div class="form-section-title"><i class="fas fa-search"></i> SEO Ayarları</div>
                    <div class="form-group">
                        <label class="form-label">Meta Başlık</label>
                        <input type="text" name="meta_title" id="metaTitle" class="form-control" placeholder="SEO için sayfa başlığı">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Meta Açıklama</label>
                        <textarea name="meta_description" id="metaDescription" class="form-control" rows="2" placeholder="SEO için sayfa açıklaması"></textarea>
                    </div>
                </div>
                
                <!-- Durum -->
                <div class="form-section">
                    <div class="form-section-title"><i class="fas fa-cog"></i> Yayın Durumu</div>
                    <label class="form-label">
                        <input type="checkbox" name="is_active" id="isActive" value="1" checked> Aktif (Yayında)
                    </label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" id="modalCancelBtn">Vazgeç</button>
                <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Kaydet</button>
            </div>
        </form>
    </div>
</div>

<script>
(function() {
    var modal = document.getElementById('blogModal');
    var newBtn = document.getElementById('newPostBtn');
    var closeBtn = document.getElementById('modalCloseBtn');
    var cancelBtn = document.getElementById('modalCancelBtn');
    var formAction = document.getElementById('formAction');
    var modalTitle = document.getElementById('modalTitle');
    var postId = document.getElementById('postId');
    var postTitle = document.getElementById('postTitle');
    var postSlug = document.getElementById('postSlug');
    var postExcerpt = document.getElementById('postExcerpt');
    var postContent = document.getElementById('postContent');
    var currentImage = document.getElementById('currentImage');
    var metaTitle = document.getElementById('metaTitle');
    var metaDescription = document.getElementById('metaDescription');
    var isActive = document.getElementById('isActive');
    var fileUploadArea = document.getElementById('fileUploadArea');
    var featuredImage = document.getElementById('featuredImage');
    var fileName = document.getElementById('fileName');
    var currentImageBox = document.getElementById('currentImageBox');
    var currentImagePreview = document.getElementById('currentImagePreview');
    var currentImageName = document.getElementById('currentImageName');
    var removeImageBtn = document.getElementById('removeImageBtn');

    // Dosya yükleme
    fileUploadArea.addEventListener('click', function() { featuredImage.click(); });
    fileUploadArea.addEventListener('dragover', function(e) { e.preventDefault(); this.style.borderColor = 'var(--primary-color)'; });
    fileUploadArea.addEventListener('dragleave', function() { this.style.borderColor = ''; });
    fileUploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        this.style.borderColor = '';
        if (e.dataTransfer.files.length) {
            featuredImage.files = e.dataTransfer.files;
            fileName.textContent = e.dataTransfer.files[0].name;
        }
    });
    featuredImage.addEventListener('change', function() {
        fileName.textContent = this.files.length ? this.files[0].name : '';
    });

    // Görsel kaldır
    removeImageBtn.addEventListener('click', function() {
        currentImage.value = '';
        currentImageBox.style.display = 'none';
    });

    function resetForm() {
        formAction.value = 'create';
        modalTitle.innerHTML = '<i class="fas fa-plus"></i> Yeni Blog Yazısı';
        postId.value = '';
        postTitle.value = '';
        postSlug.value = '';
        postExcerpt.value = '';
        postContent.value = '';
        currentImage.value = '';
        metaTitle.value = '';
        metaDescription.value = '';
        isActive.checked = true;
        featuredImage.value = '';
        fileName.textContent = '';
        currentImageBox.style.display = 'none';
    }

    function openModal(mode, data) {
        modal.classList.add('active');
        if (mode === 'edit' && data) {
            formAction.value = 'update';
            modalTitle.innerHTML = '<i class="fas fa-edit"></i> Blog Yazısı Düzenle';
            postId.value = data.id;
            postTitle.value = data.title;
            postSlug.value = data.slug;
            postExcerpt.value = data.excerpt || '';
            postContent.value = data.content;
            currentImage.value = data.image || '';
            metaTitle.value = data.metaTitle || '';
            metaDescription.value = data.metaDescription || '';
            isActive.checked = data.active == 1;
            featuredImage.value = '';
            fileName.textContent = '';
            
            if (data.image) {
                currentImageBox.style.display = 'flex';
                currentImagePreview.src = data.image;
                currentImageName.textContent = data.image.split('/').pop();
            } else {
                currentImageBox.style.display = 'none';
            }
        } else {
            resetForm();
        }
    }

    function closeModal() { modal.classList.remove('active'); }

    newBtn.addEventListener('click', function() { openModal('create', null); });
    closeBtn.addEventListener('click', closeModal);
    cancelBtn.addEventListener('click', closeModal);
    modal.addEventListener('click', function(e) { if (e.target === modal) closeModal(); });

    document.querySelectorAll('.edit-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            openModal('edit', {
                id: this.dataset.id,
                title: this.dataset.title,
                slug: this.dataset.slug,
                excerpt: this.dataset.excerpt,
                content: this.dataset.content,
                image: this.dataset.image,
                metaTitle: this.dataset.metaTitle,
                metaDescription: this.dataset.metaDescription,
                active: this.dataset.active
            });
        });
    });

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && modal.classList.contains('active')) closeModal();
    });

    // Başlıktan slug oluştur
    postTitle.addEventListener('input', function() {
        if (!postSlug.value || formAction.value === 'create') {
            var text = this.value.toLowerCase();
            var turkce = ['ç', 'ğ', 'ı', 'ö', 'ş', 'ü'];
            var latin = ['c', 'g', 'i', 'o', 's', 'u'];
            for (var i = 0; i < turkce.length; i++) {
                text = text.split(turkce[i]).join(latin[i]);
            }
            text = text.replace(/[^a-z0-9\-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
            postSlug.value = text;
        }
    });
})();

// Editor fonksiyonları
function insertTag(tag) {
    var textarea = document.getElementById('postContent');
    var start = textarea.selectionStart;
    var end = textarea.selectionEnd;
    var selected = textarea.value.substring(start, end);
    var before = textarea.value.substring(0, start);
    var after = textarea.value.substring(end);
    
    if (tag === 'ul' || tag === 'ol') {
        textarea.value = before + '<' + tag + '>\n<li>' + (selected || 'Liste öğesi') + '</li>\n</' + tag + '>' + after;
    } else {
        textarea.value = before + '<' + tag + '>' + (selected || '') + '</' + tag + '>' + after;
    }
    textarea.focus();
}

function insertLink() {
    var url = prompt('Link URL:', 'https://');
    if (url) {
        var textarea = document.getElementById('postContent');
        var start = textarea.selectionStart;
        var end = textarea.selectionEnd;
        var selected = textarea.value.substring(start, end) || 'Link metni';
        var before = textarea.value.substring(0, start);
        var after = textarea.value.substring(end);
        textarea.value = before + '<a href="' + url + '">' + selected + '</a>' + after;
        textarea.focus();
    }
}

function insertImage() {
    var url = prompt('Resim URL:', 'https://');
    if (url) {
        var textarea = document.getElementById('postContent');
        var start = textarea.selectionStart;
        var before = textarea.value.substring(0, start);
        var after = textarea.value.substring(start);
        textarea.value = before + '<img src="' + url + '" alt="">' + after;
        textarea.focus();
    }
}
</script>
<?php endif; ?>

<?php require_once __DIR__ . '/footer.php'; ?>