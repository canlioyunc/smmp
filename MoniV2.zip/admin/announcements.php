<?php
/**
 * Admin Panel - Duyurular (Story Sistemi)
 */
require_once __DIR__ . '/../config.php';

// Admin kontrolü
if (!isLoggedIn() || !isAdmin()) {
    header('Location: /login.php');
    exit;
}

// Duyuru alanlarını yalnız güvenli, beklenen biçimlerde kabul et.
function moni_ann_media_type($value): string {
    $value = strtolower(trim((string)$value));
    return in_array($value, ['none','image','video'], true) ? $value : 'none';
}
function moni_ann_icon($value): string {
    $value = trim((string)$value);
    if ($value === '') return 'fas fa-bullhorn';
    return preg_match('/^(?:fas|far|fab|fal|fad|fa-solid|fa-regular|fa-brands)(?:\s+fa-[a-z0-9-]+)+$/i', $value) ? $value : 'fas fa-bullhorn';
}
function moni_ann_url($value, bool $allowLocalStory=false): ?string {
    $value = trim((string)$value);
    if ($value === '') return null;
    if ($allowLocalStory && preg_match('#^/uploads/story/[A-Za-z0-9._/-]+$#', $value)) return $value;
    if (!filter_var($value, FILTER_VALIDATE_URL)) return null;
    $scheme = strtolower((string)parse_url($value, PHP_URL_SCHEME));
    return in_array($scheme, ['http','https'], true) ? $value : null;
}
function moni_ann_button_color($value): string {
    $value = strtolower(trim((string)$value));
    return in_array($value, ['primary','secondary','success','danger','warning','info','dark','light'], true) ? $value : 'primary';
}

// Upload klasörünü oluştur
$uploadDir = __DIR__ . '/../uploads/story/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// İşlemler (header.php'den ÖNCE)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create') {
        $mediaType = moni_ann_media_type($_POST['media_type'] ?? 'none');
        $mediaUrl = null;
        
        // Dosya yükleme - MIME içerik doğrulaması ve sunucu tarafı güvenli uzantı eşlemesi
        if ($mediaType !== 'none' && !empty($_FILES['media_file']['name'])) {
            $allowed = $mediaType === 'image'
                ? ['image/jpeg','image/png','image/gif','image/webp']
                : ($mediaType === 'video' ? ['video/mp4','video/webm','video/ogg'] : []);
            if (!$allowed) {
                setAlert('Geçersiz medya türü.', 'danger'); header('Location: announcements.php'); exit;
            }
            $upload = moni_safe_upload($_FILES['media_file'], 'story', $allowed, 50 * 1024 * 1024);
            if (!$upload['ok']) {
                setAlert($upload['error'], 'danger'); header('Location: announcements.php'); exit;
            }
            $mediaUrl = '/' . ltrim($upload['path'], '/');
        }

        // URL ile ekleme (dosya yüklenmediyse)
        if ($mediaType !== 'none' && !$mediaUrl && !empty($_POST['media_url'])) {
            $mediaUrl = moni_ann_url($_POST['media_url'], false);
            if ($mediaUrl === null) { setAlert('Medya URL yalnız http/https adresi olabilir.', 'danger'); header('Location: announcements.php'); exit; }
        }
        
                if (trim((string)($_POST['link_url'] ?? '')) !== '' && moni_ann_url($_POST['link_url'], false) === null) {
            setAlert('Bağlantı URL yalnız http/https adresi olabilir.', 'danger'); header('Location: announcements.php'); exit;
        }
$stmt = $db->prepare("INSERT INTO announcements (title, body, icon, media_type, media_url, link_url, button_text, button_color, display_order, expires_at, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            trim($_POST['title']),
            trim($_POST['body']),
            moni_ann_icon($_POST['icon'] ?? ''),
            $mediaType,
            $mediaUrl,
            moni_ann_url($_POST['link_url'] ?? '', false),
            trim($_POST['button_text']) ?: null,
            moni_ann_button_color($_POST['button_color'] ?? 'primary'),
            (int)($_POST['display_order'] ?? 0),
            !empty($_POST['expires_at']) ? $_POST['expires_at'] : null,
            isset($_POST['is_active']) ? 1 : 0
        ]);
        setAlert('Duyuru eklendi.', 'success');
        header('Location: announcements.php');
        exit;
    }
    
    if ($action === 'update' && !empty($_POST['id'])) {
        $mediaType = moni_ann_media_type($_POST['media_type'] ?? 'none');
        $currentMediaStmt = $db->prepare("SELECT media_url FROM announcements WHERE id=? LIMIT 1");
        $currentMediaStmt->execute([(int)$_POST['id']]);
        $mediaUrl = $currentMediaStmt->fetchColumn();
        $mediaUrl = $mediaUrl !== false ? (string)$mediaUrl : null;
        
        // Yeni dosya yükleme - önce güvenli biçimde kaydet, başarıdan sonra eski yerel dosyayı sil
        if ($mediaType !== 'none' && !empty($_FILES['media_file']['name'])) {
            $allowed = $mediaType === 'image'
                ? ['image/jpeg','image/png','image/gif','image/webp']
                : ($mediaType === 'video' ? ['video/mp4','video/webm','video/ogg'] : []);
            if (!$allowed) { setAlert('Geçersiz medya türü.', 'danger'); header('Location: announcements.php'); exit; }
            $upload = moni_safe_upload($_FILES['media_file'], 'story', $allowed, 50 * 1024 * 1024);
            if (!$upload['ok']) { setAlert($upload['error'], 'danger'); header('Location: announcements.php'); exit; }
            $newMediaUrl = '/' . ltrim($upload['path'], '/');
            if ($mediaUrl && strpos($mediaUrl, '/uploads/story/') === 0) {
                $oldFile = __DIR__ . '/..' . $mediaUrl; if (is_file($oldFile)) @unlink($oldFile);
            }
            $mediaUrl = $newMediaUrl;
        }

        // URL değişikliği (dosya yüklenmediyse ve URL girildiyse)
        if ($mediaType !== 'none' && empty($_FILES['media_file']['name']) && !empty($_POST['media_url'])) {
            $newUrl = moni_ann_url($_POST['media_url'], false);
            if ($newUrl === null) { setAlert('Medya URL yalnız http/https adresi olabilir.', 'danger'); header('Location: announcements.php'); exit; }
            if ($newUrl !== $mediaUrl) {
                // Eski yerel dosyayı sil
                if ($mediaUrl && strpos($mediaUrl, '/uploads/story/') === 0) {
                    $oldFile = __DIR__ . '/..' . $mediaUrl;
                    if (file_exists($oldFile)) {
                        unlink($oldFile);
                    }
                }
                $mediaUrl = $newUrl;
            }
        }
        
        // Medya tipi "yok" seçilirse dosyayı sil
        if ($mediaType === 'none' && $mediaUrl && strpos($mediaUrl, '/uploads/story/') === 0) {
            $oldFile = __DIR__ . '/..' . $mediaUrl;
            if (file_exists($oldFile)) {
                unlink($oldFile);
            }
            $mediaUrl = null;
        }
        
                if (trim((string)($_POST['link_url'] ?? '')) !== '' && moni_ann_url($_POST['link_url'], false) === null) {
            setAlert('Bağlantı URL yalnız http/https adresi olabilir.', 'danger'); header('Location: announcements.php'); exit;
        }
$stmt = $db->prepare("UPDATE announcements SET title=?, body=?, icon=?, media_type=?, media_url=?, link_url=?, button_text=?, button_color=?, display_order=?, expires_at=?, is_active=? WHERE id=?");
        $stmt->execute([
            trim($_POST['title']),
            trim($_POST['body']),
            moni_ann_icon($_POST['icon'] ?? ''),
            $mediaType,
            $mediaUrl,
            moni_ann_url($_POST['link_url'] ?? '', false),
            trim($_POST['button_text']) ?: null,
            moni_ann_button_color($_POST['button_color'] ?? 'primary'),
            (int)($_POST['display_order'] ?? 0),
            !empty($_POST['expires_at']) ? $_POST['expires_at'] : null,
            isset($_POST['is_active']) ? 1 : 0,
            (int)$_POST['id']
        ]);
        setAlert('Duyuru güncellendi.', 'success');
        header('Location: announcements.php');
        exit;
    }
    
    if ($action === 'delete' && !empty($_POST['id'])) {
        // Önce medya dosyasını sil
        $stmt = $db->prepare("SELECT media_url FROM announcements WHERE id = ?");
        $stmt->execute([(int)$_POST['id']]);
        $ann = $stmt->fetch();
        
        if ($ann && $ann['media_url'] && strpos($ann['media_url'], '/uploads/story/') === 0) {
            $oldFile = __DIR__ . '/..' . $ann['media_url'];
            if (file_exists($oldFile)) {
                unlink($oldFile);
            }
        }
        
        $stmt = $db->prepare("DELETE FROM announcements WHERE id=?");
        $stmt->execute([(int)$_POST['id']]);
        setAlert('Duyuru silindi.', 'success');
        header('Location: announcements.php');
        exit;
    }
    
    if ($action === 'toggle' && !empty($_POST['id'])) {
        $stmt = $db->prepare("UPDATE announcements SET is_active = 1 - is_active WHERE id=?");
        $stmt->execute([(int)$_POST['id']]);
        setAlert('Durum değiştirildi.', 'success');
        header('Location: announcements.php');
        exit;
    }
}

// Liste
$announcements = $db->query("SELECT * FROM announcements ORDER BY display_order ASC, created_at DESC, id DESC")->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Duyurular (Story)';
require_once __DIR__ . '/header.php';
?>
<style>
.ann-table { width:100%; border-collapse:collapse; }
.ann-table th, .ann-table td { padding:12px 10px; border-bottom:1px solid var(--border-color); text-align:left; vertical-align:top; }
.ann-badge { display:inline-flex; align-items:center; gap:6px; padding:5px 10px; border-radius:10px; background:var(--primary-alpha-012); color:var(--accent-text-color); font-size:.85rem; }
.ann-actions { display:flex; gap:6px; flex-wrap:wrap; }
.ann-actions form { display:inline; }
.ann-actions button { border:none; padding:8px 10px; border-radius:8px; cursor:pointer; font-size:.85rem; }
.btn-icon { width:32px; height:32px; display:inline-flex; align-items:center; justify-content:center; }
.btn-soft { background:var(--background-color); color:var(--text-color); border:1px solid var(--border-color); }
.btn-soft.danger { color:#dc3545; border-color:rgba(220,53,69,.4); }
.btn-soft.primary { color:var(--accent-text-color); border-color:var(--primary-alpha-04); }
.status-dot { width:10px; height:10px; border-radius:50%; display:inline-block; margin-right:5px; }
.status-on { background:#28a745; }
.status-off { background:#6c757d; }

.media-badge { display:inline-flex; align-items:center; gap:4px; padding:3px 8px; border-radius:6px; font-size:.75rem; font-weight:600; }
.media-badge.none { background:rgba(108,117,125,.15); color:var(--muted-text-color); }
.media-badge.image { background:rgba(0,123,255,.15); color:#007bff; }
.media-badge.video { background:rgba(220,53,69,.15); color:#dc3545; }

.btn-color-badge { display:inline-flex; align-items:center; gap:4px; padding:3px 8px; border-radius:6px; font-size:.75rem; font-weight:600; }
.btn-color-badge.primary { background:var(--primary-alpha-015); color:var(--accent-text-color); }
.btn-color-badge.success { background:rgba(40,167,69,.15); color:#28a745; }
.btn-color-badge.danger { background:rgba(220,53,69,.15); color:#dc3545; }
.btn-color-badge.warning { background:rgba(255,193,7,.15); color:#f39c12; }
.btn-color-badge.info { background:rgba(23,162,184,.15); color:#17a2b8; }

.order-badge { display:inline-flex; align-items:center; justify-content:center; width:28px; height:28px; border-radius:8px; background:var(--background-color); font-weight:700; font-size:.85rem; }

.expires-text { font-size:.8rem; opacity:.7; }
.expires-text.expired { color:#dc3545; }
.expires-text.active { color:#28a745; }

.story-preview { width:50px; height:50px; border-radius:50%; overflow:hidden; border:3px solid var(--primary-color); display:flex; align-items:center; justify-content:center; background:var(--background-color); }
.story-preview img { width:100%; height:100%; object-fit:cover; }
.story-preview i { font-size:1.2rem; color:var(--accent-text-color); }

#annModal { display:none; position:fixed; top:0; left:0; right:0; bottom:0; z-index:9999; background:rgba(0,0,0,.6); align-items:center; justify-content:center; padding:20px; }
#annModal.active { display:flex !important; }
.modal-box { background:var(--card-bg-color); border-radius:14px; max-width:650px; width:100%; max-height:90vh; overflow-y:auto; border:1px solid var(--border-color); }
.modal-header { padding:16px 18px; border-bottom:1px solid var(--border-color); display:flex; align-items:center; justify-content:space-between; }
.modal-header h3 { margin:0; font-size:1.1rem; }
.modal-body { padding:18px; }
.modal-footer { padding:16px 18px; border-top:1px solid var(--border-color); display:flex; gap:10px; justify-content:flex-end; }
.modal-close { background:var(--background-color); border:none; width:34px; height:34px; border-radius:8px; cursor:pointer; font-size:1.2rem; }
.modal-close:hover { background:var(--danger-color); color:var(--on-danger-color); }

.form-row { display:grid; grid-template-columns:1fr 1fr; gap:15px; }
@media (max-width:600px) { .form-row { grid-template-columns:1fr; } }

.form-section { background:var(--background-color); border-radius:10px; padding:15px; margin-bottom:15px; }
.form-section-title { font-size:.85rem; font-weight:600; margin-bottom:12px; color:var(--accent-text-color); display:flex; align-items:center; gap:8px; }

.media-type-selector { display:flex; gap:10px; margin-bottom:15px; }
.media-type-btn { flex:1; padding:12px; border:2px solid var(--border-color); border-radius:10px; background:var(--background-color); cursor:pointer; text-align:center; transition:all .3s ease; }
.media-type-btn:hover { border-color:var(--accent-text-color); }
.media-type-btn.active { border-color:var(--accent-text-color); background:var(--primary-alpha-01); }
.media-type-btn i { display:block; font-size:1.5rem; margin-bottom:5px; }
.media-type-btn span { font-size:.8rem; }

.color-selector { display:flex; gap:8px; flex-wrap:wrap; }
.color-btn { width:36px; height:36px; border-radius:8px; border:2px solid transparent; cursor:pointer; transition:all .2s ease; }
.color-btn:hover { transform:scale(1.1); }
.color-btn.active { border-color:#fff; box-shadow:0 0 0 2px var(--primary-color); }
.color-btn.primary { background:linear-gradient(135deg,var(--primary-color),var(--secondary-color)); }
.color-btn.success { background:linear-gradient(135deg,#28a745,#20c997); }
.color-btn.danger { background:linear-gradient(135deg,#dc3545,#e74c3c); }
.color-btn.warning { background:linear-gradient(135deg,#ffc107,#fd7e14); }
.color-btn.info { background:linear-gradient(135deg,#17a2b8,#007bff); }

.media-preview { margin-top:10px; padding:10px; background:var(--card-bg-color); border-radius:8px; text-align:center; display:none; }
.media-preview.active { display:block; }
.media-preview img, .media-preview video { max-width:100%; max-height:150px; border-radius:6px; }

.file-upload-area { border:2px dashed var(--border-color); border-radius:10px; padding:20px; text-align:center; cursor:pointer; transition:all .3s ease; margin-bottom:10px; }
.file-upload-area:hover { border-color:var(--accent-text-color); background:var(--primary-alpha-005); }
.file-upload-area.dragover { border-color:var(--accent-text-color); background:var(--primary-alpha-01); }
.file-upload-area i { font-size:2rem; color:var(--accent-text-color); margin-bottom:10px; }
.file-upload-area p { margin:0; font-size:.85rem; opacity:.7; }
.file-upload-area .file-name { margin-top:8px; font-weight:600; color:var(--accent-text-color); }
.file-upload-area input[type="file"] { display:none; }

.upload-or { text-align:center; margin:10px 0; font-size:.8rem; opacity:.6; }

.current-media { display:flex; align-items:center; gap:10px; padding:10px; background:var(--card-bg-color); border-radius:8px; margin-bottom:10px; }
.current-media img, .current-media video { width:60px; height:60px; object-fit:cover; border-radius:6px; }
.current-media-info { flex:1; font-size:.8rem; }
.current-media-info strong { display:block; margin-bottom:2px; }
.btn-remove-media { background:#dc3545; color:#fff; border:none; padding:5px 10px; border-radius:6px; font-size:.75rem; cursor:pointer; }

@media (max-width:768px) {
    .ann-table th, .ann-table td { padding:10px 8px; }
    .ann-table { font-size:.9rem; }
    .ann-actions { gap:4px; }
    .modal-box { margin:10px; max-width:100%; }
}
</style>

<div class="admin-card">
    <div class="card-header">
        <h2><i class="fas fa-bullhorn"></i> Story Duyuruları</h2>
        <button type="button" class="btn btn-primary" id="newAnnBtn"><i class="fas fa-plus"></i> Yeni Duyuru</button>
    </div>
    <div class="card-body">
        <?php if (empty($announcements)): ?>
            <div class="alert alert-info"><i class="fas fa-info-circle"></i> Henüz duyuru yok.</div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="ann-table">
                <thead>
                    <tr>
                        <th>Sıra</th>
                        <th>Önizleme</th>
                        <th>Başlık / İçerik</th>
                        <th>Medya</th>
                        <th>Buton</th>
                        <th>Durum</th>
                        <th>Süre</th>
                        <th>İşlem</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($announcements as $ann): 
                        $isExpired = !empty($ann['expires_at']) && strtotime($ann['expires_at']) < time();
                    ?>
                    <tr style="<?php echo $isExpired ? 'opacity:.5;' : ''; ?>">
                        <td><span class="order-badge"><?php echo $ann['display_order']; ?></span></td>
                        <td>
                            <div class="story-preview">
                                <?php if ($ann['media_type'] === 'image' && !empty($ann['media_url'])): ?>
                                    <img src="<?php echo clean($ann['media_url']); ?>" alt="">
                                <?php else: ?>
                                    <i class="<?php echo clean($ann['icon'] ?: 'fas fa-bullhorn'); ?>"></i>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <div style="font-weight:600;"><?php echo clean($ann['title']); ?></div>
                            <div style="opacity:.7;font-size:.85rem;max-width:300px;"><?php echo nl2br(clean(mb_substr($ann['body'],0,100,'UTF-8'))); ?><?php echo mb_strlen($ann['body'])>100?'...':''; ?></div>
                        </td>
                        <td>
                            <span class="media-badge <?php echo $ann['media_type'] ?: 'none'; ?>">
                                <?php if ($ann['media_type'] === 'image'): ?>
                                    <i class="fas fa-image"></i> Resim
                                <?php elseif ($ann['media_type'] === 'video'): ?>
                                    <i class="fas fa-video"></i> Video
                                <?php else: ?>
                                    <i class="fas fa-ban"></i> Yok
                                <?php endif; ?>
                            </span>
                        </td>
                        <td>
                            <?php if (!empty($ann['link_url'])): ?>
                                <span class="btn-color-badge <?php echo $ann['button_color'] ?: 'primary'; ?>">
                                    <?php echo clean($ann['button_text'] ?: 'Detaylar'); ?>
                                </span>
                            <?php else: ?>
                                <span style="opacity:.5;">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="status-dot <?php echo $ann['is_active'] ? 'status-on' : 'status-off'; ?>"></span>
                            <?php echo $ann['is_active'] ? 'Aktif' : 'Pasif'; ?>
                        </td>
                        <td>
                            <?php if (!empty($ann['expires_at'])): ?>
                                <div class="expires-text <?php echo $isExpired ? 'expired' : 'active'; ?>">
                                    <?php if ($isExpired): ?>
                                        <i class="fas fa-times-circle"></i> Süresi doldu
                                    <?php else: ?>
                                        <i class="fas fa-clock"></i> <?php echo date('d.m.Y H:i', strtotime($ann['expires_at'])); ?>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <span style="opacity:.5;font-size:.8rem;">Süresiz</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="ann-actions">
                                <button type="button" class="btn-soft primary btn-icon edit-btn"
                                        data-id="<?php echo $ann['id']; ?>"
                                        data-title="<?php echo htmlspecialchars($ann['title'], ENT_QUOTES, 'UTF-8'); ?>"
                                        data-body="<?php echo htmlspecialchars($ann['body'], ENT_QUOTES, 'UTF-8'); ?>"
                                        data-icon="<?php echo htmlspecialchars($ann['icon'], ENT_QUOTES, 'UTF-8'); ?>"
                                        data-media-type="<?php echo htmlspecialchars($ann['media_type'] ?? 'none', ENT_QUOTES, 'UTF-8'); ?>"
                                        data-media-url="<?php echo htmlspecialchars($ann['media_url'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                        data-link-url="<?php echo htmlspecialchars($ann['link_url'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                        data-button-text="<?php echo htmlspecialchars($ann['button_text'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                        data-button-color="<?php echo htmlspecialchars($ann['button_color'] ?? 'primary', ENT_QUOTES, 'UTF-8'); ?>"
                                        data-display-order="<?php echo $ann['display_order'] ?? 0; ?>"
                                        data-expires-at="<?php echo $ann['expires_at'] ?? ''; ?>"
                                        data-active="<?php echo $ann['is_active']; ?>"
                                        title="Düzenle">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('Silinsin mi?');">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?php echo $ann['id']; ?>">
                                    <button type="submit" class="btn-soft danger btn-icon" title="Sil"><i class="fas fa-trash"></i></button>
                                </form>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="toggle">
                                    <input type="hidden" name="id" value="<?php echo $ann['id']; ?>">
                                    <button type="submit" class="btn-soft btn-icon" title="Aktif/Pasif"><i class="fas fa-power-off"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal -->
<div id="annModal">
    <div class="modal-box">
        <div class="modal-header">
            <h3 id="modalTitle"><i class="fas fa-bullhorn"></i> Duyuru</h3>
            <button type="button" class="modal-close" id="modalCloseBtn">&times;</button>
        </div>
        <form method="POST" id="annForm" enctype="multipart/form-data">
            <div class="modal-body">
                <input type="hidden" name="action" id="formAction" value="create">
                <input type="hidden" name="id" id="annId">
                <input type="hidden" name="media_type" id="annMediaType" value="none">
                <input type="hidden" name="button_color" id="annButtonColor" value="primary">
                <input type="hidden" name="current_media_url" id="currentMediaUrl" value="">
                
                <!-- Temel Bilgiler -->
                <div class="form-section">
                    <div class="form-section-title"><i class="fas fa-info-circle"></i> Temel Bilgiler</div>
                    <div class="form-group">
                        <label class="form-label">Başlık *</label>
                        <input type="text" name="title" id="annTitle" class="form-control" required placeholder="Duyuru başlığı">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Açıklama *</label>
                        <textarea name="body" id="annBody" class="form-control" rows="3" required placeholder="Duyuru içeriği"></textarea>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">İkon (FontAwesome)</label>
                            <input type="text" name="icon" id="annIcon" class="form-control" placeholder="fas fa-bullhorn">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Sıralama</label>
                            <input type="number" name="display_order" id="annDisplayOrder" class="form-control" value="0" min="0">
                        </div>
                    </div>
                </div>
                
                <!-- Medya -->
                <div class="form-section">
                    <div class="form-section-title"><i class="fas fa-photo-video"></i> Medya (Story Arka Planı)</div>
                    <div class="media-type-selector">
                        <div class="media-type-btn active" data-type="none">
                            <i class="fas fa-ban"></i>
                            <span>Medya Yok</span>
                        </div>
                        <div class="media-type-btn" data-type="image">
                            <i class="fas fa-image"></i>
                            <span>Resim</span>
                        </div>
                        <div class="media-type-btn" data-type="video">
                            <i class="fas fa-video"></i>
                            <span>Video</span>
                        </div>
                    </div>
                    
                    <div id="mediaUploadArea" style="display:none;">
                        <!-- Mevcut medya (düzenlemede) -->
                        <div class="current-media" id="currentMediaBox" style="display:none;">
                            <div id="currentMediaPreview"></div>
                            <div class="current-media-info">
                                <strong>Mevcut Medya</strong>
                                <span id="currentMediaName"></span>
                            </div>
                            <button type="button" class="btn-remove-media" id="removeMediaBtn"><i class="fas fa-trash"></i> Kaldır</button>
                        </div>
                        
                        <!-- Dosya yükleme -->
                        <div class="file-upload-area" id="fileUploadArea">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <p>Dosya yüklemek için tıklayın veya sürükleyin</p>
                            <p style="font-size:.75rem;margin-top:5px;">Resim: JPG, PNG, GIF, WEBP | Video: MP4, WEBM, OGG (Max: 50MB)</p>
                            <div class="file-name" id="fileName"></div>
                            <input type="file" name="media_file" id="mediaFile" accept="image/*,video/*">
                        </div>
                        
                        <div class="upload-or">veya URL ile ekleyin</div>
                        
                        <div class="form-group">
                            <input type="url" name="media_url" id="annMediaUrl" class="form-control" placeholder="https://example.com/image.jpg">
                        </div>
                        
                        <div class="media-preview" id="mediaPreview"></div>
                    </div>
                </div>
                
                <!-- Buton / Link -->
                <div class="form-section">
                    <div class="form-section-title"><i class="fas fa-link"></i> Buton / Link (Opsiyonel)</div>
                    <div class="form-group">
                        <label class="form-label">Link URL</label>
                        <input type="url" name="link_url" id="annLinkUrl" class="form-control" placeholder="https://example.com/sayfa">
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Buton Yazısı</label>
                            <input type="text" name="button_text" id="annButtonText" class="form-control" placeholder="Detaylar">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Buton Rengi</label>
                            <div class="color-selector">
                                <div class="color-btn primary active" data-color="primary" title="Mor"></div>
                                <div class="color-btn success" data-color="success" title="Yeşil"></div>
                                <div class="color-btn danger" data-color="danger" title="Kırmızı"></div>
                                <div class="color-btn warning" data-color="warning" title="Sarı"></div>
                                <div class="color-btn info" data-color="info" title="Mavi"></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Zamanlama -->
                <div class="form-section">
                    <div class="form-section-title"><i class="fas fa-clock"></i> Zamanlama</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Bitiş Tarihi (Opsiyonel)</label>
                            <input type="datetime-local" name="expires_at" id="annExpiresAt" class="form-control">
                            <small style="opacity:.6;">Boş bırakılırsa süresiz olur</small>
                        </div>
                        <div class="form-group">
                            <label class="form-label">&nbsp;</label>
                            <label class="form-label" style="margin-top:10px;">
                                <input type="checkbox" name="is_active" id="annActive" value="1" checked> Aktif
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" id="modalCancelBtn">Vazgeç</button>
                <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Kaydet</button>
            </div>
        </form>
    </div>
</div>

<script>
(function() {
    var modal = document.getElementById('annModal');
    var newBtn = document.getElementById('newAnnBtn');
    var closeBtn = document.getElementById('modalCloseBtn');
    var cancelBtn = document.getElementById('modalCancelBtn');
    var formAction = document.getElementById('formAction');
    var modalTitle = document.getElementById('modalTitle');
    var annId = document.getElementById('annId');
    var annTitle = document.getElementById('annTitle');
    var annBody = document.getElementById('annBody');
    var annIcon = document.getElementById('annIcon');
    var annMediaType = document.getElementById('annMediaType');
    var annMediaUrl = document.getElementById('annMediaUrl');
    var annLinkUrl = document.getElementById('annLinkUrl');
    var annButtonText = document.getElementById('annButtonText');
    var annButtonColor = document.getElementById('annButtonColor');
    var annDisplayOrder = document.getElementById('annDisplayOrder');
    var annExpiresAt = document.getElementById('annExpiresAt');
    var annActive = document.getElementById('annActive');
    var currentMediaUrl = document.getElementById('currentMediaUrl');
    var mediaUploadArea = document.getElementById('mediaUploadArea');
    var mediaPreview = document.getElementById('mediaPreview');
    var mediaTypeBtns = document.querySelectorAll('.media-type-btn');
    var colorBtns = document.querySelectorAll('.color-btn');
    var fileUploadArea = document.getElementById('fileUploadArea');
    var mediaFile = document.getElementById('mediaFile');
    var fileName = document.getElementById('fileName');
    var currentMediaBox = document.getElementById('currentMediaBox');
    var currentMediaPreview = document.getElementById('currentMediaPreview');
    var currentMediaName = document.getElementById('currentMediaName');
    var removeMediaBtn = document.getElementById('removeMediaBtn');

    // Medya tipi seçimi
    mediaTypeBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            mediaTypeBtns.forEach(function(b) { b.classList.remove('active'); });
            btn.classList.add('active');
            var type = btn.getAttribute('data-type');
            annMediaType.value = type;
            
            if (type === 'none') {
                mediaUploadArea.style.display = 'none';
                annMediaUrl.value = '';
                mediaFile.value = '';
                fileName.textContent = '';
                mediaPreview.innerHTML = '';
                mediaPreview.classList.remove('active');
            } else {
                mediaUploadArea.style.display = 'block';
                // Dosya türünü ayarla
                if (type === 'image') {
                    mediaFile.accept = 'image/jpeg,image/png,image/gif,image/webp';
                } else {
                    mediaFile.accept = 'video/mp4,video/webm,video/ogg';
                }
            }
        });
    });

    // Dosya yükleme alanı
    fileUploadArea.addEventListener('click', function() {
        mediaFile.click();
    });

    fileUploadArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        fileUploadArea.classList.add('dragover');
    });

    fileUploadArea.addEventListener('dragleave', function() {
        fileUploadArea.classList.remove('dragover');
    });

    fileUploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        fileUploadArea.classList.remove('dragover');
        if (e.dataTransfer.files.length) {
            mediaFile.files = e.dataTransfer.files;
            handleFileSelect();
        }
    });

    mediaFile.addEventListener('change', handleFileSelect);

    function handleFileSelect() {
        if (mediaFile.files.length > 0) {
            var file = mediaFile.files[0];
            fileName.textContent = file.name;
            
            // Önizleme
            var reader = new FileReader();
            reader.onload = function(e) {
                var type = annMediaType.value;
                if (type === 'image') {
                    mediaPreview.innerHTML = '<img src="' + e.target.result + '" alt="Önizleme">';
                } else if (type === 'video') {
                    mediaPreview.innerHTML = '<video src="' + e.target.result + '" controls style="max-height:150px;"></video>';
                }
                mediaPreview.classList.add('active');
            };
            reader.readAsDataURL(file);
            
            // URL alanını temizle
            annMediaUrl.value = '';
        }
    }

    // Renk seçimi
    colorBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            colorBtns.forEach(function(b) { b.classList.remove('active'); });
            btn.classList.add('active');
            annButtonColor.value = btn.getAttribute('data-color');
        });
    });

    // URL ile önizleme
    annMediaUrl.addEventListener('input', function() {
        var url = this.value.trim();
        var type = annMediaType.value;
        if (url && type !== 'none') {
            mediaPreview.replaceChildren();
            var previewNode = null;
            try {
                var parsed = new URL(url, window.location.origin);
                if (!/^https?:$/i.test(parsed.protocol)) throw new Error('Geçersiz protokol');
                if (type === 'image') {
                    previewNode = document.createElement('img');
                    previewNode.alt = 'Önizleme';
                } else if (type === 'video') {
                    previewNode = document.createElement('video');
                    previewNode.controls = true;
                    previewNode.style.maxHeight = '150px';
                }
                if (previewNode) {
                    previewNode.src = parsed.href;
                    previewNode.addEventListener('error', function(){ this.style.display = 'none'; });
                    mediaPreview.appendChild(previewNode);
                }
            } catch (e) {
                previewNode = null;
            }
            mediaPreview.classList.toggle('active', !!previewNode);
            // Dosya seçimini temizle
            mediaFile.value = '';
            fileName.textContent = '';
        } else {
            mediaPreview.innerHTML = '';
            mediaPreview.classList.remove('active');
        }
    });

    // Medyayı kaldır
    removeMediaBtn.addEventListener('click', function() {
        currentMediaUrl.value = '';
        currentMediaBox.style.display = 'none';
        annMediaUrl.value = '';
    });

    function resetForm() {
        formAction.value = 'create';
        modalTitle.innerHTML = '<i class="fas fa-plus"></i> Yeni Story Duyurusu';
        annId.value = '';
        annTitle.value = '';
        annBody.value = '';
        annIcon.value = 'fas fa-bullhorn';
        annMediaType.value = 'none';
        annMediaUrl.value = '';
        annLinkUrl.value = '';
        annButtonText.value = '';
        annButtonColor.value = 'primary';
        annDisplayOrder.value = '0';
        annExpiresAt.value = '';
        annActive.checked = true;
        currentMediaUrl.value = '';
        mediaFile.value = '';
        fileName.textContent = '';
        
        mediaTypeBtns.forEach(function(b) { b.classList.remove('active'); });
        document.querySelector('.media-type-btn[data-type="none"]').classList.add('active');
        mediaUploadArea.style.display = 'none';
        mediaPreview.innerHTML = '';
        mediaPreview.classList.remove('active');
        currentMediaBox.style.display = 'none';
        
        colorBtns.forEach(function(b) { b.classList.remove('active'); });
        document.querySelector('.color-btn.primary').classList.add('active');
    }

    function openModal(mode, data) {
        modal.classList.add('active');
        if (mode === 'edit' && data) {
            formAction.value = 'update';
            modalTitle.innerHTML = '<i class="fas fa-edit"></i> Duyuru Düzenle';
            annId.value = data.id;
            annTitle.value = data.title;
            annBody.value = data.body;
            annIcon.value = data.icon || 'fas fa-bullhorn';
            annMediaType.value = data.mediaType || 'none';
            annMediaUrl.value = '';
            annLinkUrl.value = data.linkUrl || '';
            annButtonText.value = data.buttonText || '';
            annButtonColor.value = data.buttonColor || 'primary';
            annDisplayOrder.value = data.displayOrder || '0';
            annExpiresAt.value = data.expiresAt ? data.expiresAt.replace(' ', 'T').substring(0, 16) : '';
            annActive.checked = data.active == 1;
            currentMediaUrl.value = data.mediaUrl || '';
            mediaFile.value = '';
            fileName.textContent = '';
            
            // Medya tipi butonları
            mediaTypeBtns.forEach(function(b) { b.classList.remove('active'); });
            var mtBtn = document.querySelector('.media-type-btn[data-type="' + (data.mediaType || 'none') + '"]');
            if (mtBtn) mtBtn.classList.add('active');
            
            if (data.mediaType && data.mediaType !== 'none') {
                mediaUploadArea.style.display = 'block';
                
                // Mevcut medyayı göster
                if (data.mediaUrl) {
                    currentMediaBox.style.display = 'flex';
                    currentMediaName.textContent = data.mediaUrl.split('/').pop();
                    const mediaUrl = String(data.mediaUrl || '');
                    const safeMediaUrl = mediaUrl.startsWith('/uploads/story/') || /^https?:\/\//i.test(mediaUrl);
                    if (!safeMediaUrl) {
                        currentMediaBox.style.display = 'none';
                    } else if (data.mediaType === 'image') {
                        const img = document.createElement('img'); img.src = mediaUrl; img.alt = '';
                        currentMediaPreview.replaceChildren(img);
                        mediaFile.accept = 'image/jpeg,image/png,image/gif,image/webp';
                    } else if (data.mediaType === 'video') {
                        const video = document.createElement('video'); video.src = mediaUrl;
                        video.style.width = '60px'; video.style.height = '60px'; video.style.objectFit = 'cover';
                        currentMediaPreview.replaceChildren(video);
                        mediaFile.accept = 'video/mp4,video/webm,video/ogg';
                    }
                } else {
                    currentMediaBox.style.display = 'none';
                }
            } else {
                mediaUploadArea.style.display = 'none';
                currentMediaBox.style.display = 'none';
            }
            
            mediaPreview.innerHTML = '';
            mediaPreview.classList.remove('active');
            
            // Renk butonları
            colorBtns.forEach(function(b) { b.classList.remove('active'); });
            var cBtn = document.querySelector('.color-btn.' + (data.buttonColor || 'primary'));
            if (cBtn) cBtn.classList.add('active');
        } else {
            resetForm();
        }
    }

    function closeModal() {
        modal.classList.remove('active');
    }

    if (newBtn) {
        newBtn.addEventListener('click', function(e) {
            e.preventDefault();
            openModal('create', null);
        });
    }

    if (closeBtn) closeBtn.addEventListener('click', closeModal);
    if (cancelBtn) cancelBtn.addEventListener('click', closeModal);

    modal.addEventListener('click', function(e) {
        if (e.target === modal) closeModal();
    });

    // Düzenle butonları
    document.querySelectorAll('.edit-btn').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            openModal('edit', {
                id: btn.getAttribute('data-id'),
                title: btn.getAttribute('data-title'),
                body: btn.getAttribute('data-body'),
                icon: btn.getAttribute('data-icon'),
                mediaType: btn.getAttribute('data-media-type'),
                mediaUrl: btn.getAttribute('data-media-url'),
                linkUrl: btn.getAttribute('data-link-url'),
                buttonText: btn.getAttribute('data-button-text'),
                buttonColor: btn.getAttribute('data-button-color'),
                displayOrder: btn.getAttribute('data-display-order'),
                expiresAt: btn.getAttribute('data-expires-at'),
                active: btn.getAttribute('data-active')
            });
        });
    });

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && modal.classList.contains('active')) closeModal();
    });
})();
</script>

<?php require_once __DIR__ . '/footer.php'; ?>