<?php
/** Güvenli, veritabanı tabanlı özel sayfa yönetimi. PHP dosyası üretmez. */
require_once __DIR__.'/../config.php';
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $action=$_POST['action']??'';
    try{
        if($action==='save_page'){
            $id=(int)($_POST['id']??0);$title=trim((string)($_POST['title']??''));$slug=strtolower(trim((string)($_POST['slug']??'')));$content=(string)($_POST['content_html']??'');$active=!empty($_POST['is_active'])?1:0;
            $slug=preg_replace('/[^a-z0-9_-]+/','-',$slug);$slug=trim($slug,'-');
            if($title===''||$slug==='')throw new RuntimeException('Başlık ve URL kısa adı zorunludur.');
            if(strlen($slug)>190)throw new RuntimeException('URL kısa adı çok uzun.');
            // Çalıştırılabilir içerikleri temizle; özel sayfalar yalnız güvenli HTML saklar.
            $content=moni_sanitize_admin_html($content);
            if($id){$db->prepare("UPDATE custom_pages SET slug=?,title=?,content_html=?,is_active=? WHERE id=?")->execute([$slug,$title,$content,$active,$id]);}
            else{$db->prepare("INSERT INTO custom_pages(slug,title,content_html,is_active) VALUES(?,?,?,?)")->execute([$slug,$title,$content,$active]);}
            setAlert('Sayfa kaydedildi.','success');header('Location: pages.php');exit;
        }
        if($action==='delete_page'){$id=(int)($_POST['id']??0);$db->prepare("DELETE FROM custom_pages WHERE id=?")->execute([$id]);setAlert('Sayfa silindi.','success');header('Location: pages.php');exit;}
    }catch(Throwable $e){$error=$e->getMessage();}
}
$edit=null;if(!empty($_GET['edit'])){$s=$db->prepare("SELECT * FROM custom_pages WHERE id=?");$s->execute([(int)$_GET['edit']]);$edit=$s->fetch(PDO::FETCH_ASSOC);}
$pages=$db->query("SELECT * FROM custom_pages ORDER BY updated_at DESC,id DESC")->fetchAll(PDO::FETCH_ASSOC);
$pageTitle='Özel Sayfalar';require_once 'header.php';
?>
<style>.moni-grid{display:grid;grid-template-columns:minmax(0,1fr) 380px;gap:22px}.moni-card{background:var(--card-bg-color);border:1px solid var(--border-color);border-radius:16px;padding:22px;margin-bottom:18px}.moni-card h3{margin:0 0 16px}.f{margin-bottom:14px}.f label{display:block;font-weight:600;margin-bottom:7px}.f input,.f textarea{width:100%;padding:11px 12px;border:1px solid var(--border-color);border-radius:9px;background:var(--background-color);color:var(--text-color)}.f textarea{min-height:330px;font-family:ui-monospace,monospace}.btnx{border:0;border-radius:9px;padding:10px 14px;cursor:pointer;background:var(--primary-color);color:var(--on-primary-color)}.btnx.d{background:#dc3545}.tbl{width:100%;border-collapse:collapse}.tbl th,.tbl td{padding:11px;border-bottom:1px solid var(--border-color);text-align:left}.hint{font-size:.85rem;opacity:.7;margin-top:6px}@media(max-width:1000px){.moni-grid{grid-template-columns:1fr}}</style>
<?php if($error):?><div class="alert alert-danger"><?=clean($error)?></div><?php endif;?>
<div class="moni-grid"><div class="moni-card"><h3>Yayınlanan sayfalar</h3><table class="tbl"><thead><tr><th>Başlık</th><th>URL</th><th>Durum</th><th></th></tr></thead><tbody><?php foreach($pages as $p):?><tr><td><?=clean($p['title'])?></td><td><a href="/page.php?slug=<?=urlencode($p['slug'])?>" target="_blank">/page.php?slug=<?=clean($p['slug'])?></a></td><td><?=$p['is_active']?'Aktif':'Pasif'?></td><td><a class="btnx" href="?edit=<?=$p['id']?>">Düzenle</a> <form method="post" style="display:inline" onsubmit="return confirm('Silinsin mi?')"><input type="hidden" name="action" value="delete_page"><input type="hidden" name="id" value="<?=$p['id']?>"><button class="btnx d">Sil</button></form></td></tr><?php endforeach;?><?php if(!$pages):?><tr><td colspan="4">Henüz özel sayfa yok.</td></tr><?php endif;?></tbody></table></div>
<div class="moni-card"><h3><?=$edit?'Sayfayı düzenle':'Yeni sayfa'?></h3><form method="post"><input type="hidden" name="action" value="save_page"><input type="hidden" name="id" value="<?=intval($edit['id']??0)?>"><div class="f"><label>Başlık</label><input name="title" required value="<?=clean($edit['title']??'')?>"></div><div class="f"><label>URL kısa adı</label><input name="slug" required value="<?=clean($edit['slug']??'')?>"><div class="hint">PHP dosyası oluşturulmaz; içerik veritabanından güvenli renderer ile gösterilir.</div></div><div class="f"><label>HTML içerik</label><textarea name="content_html"><?=htmlspecialchars($edit['content_html']??'',ENT_QUOTES,'UTF-8')?></textarea></div><label><input type="checkbox" name="is_active" value="1" <?=!isset($edit['is_active'])||$edit['is_active']?'checked':''?>> Aktif</label><br><br><button class="btnx">Kaydet</button></form></div></div>
<?php require_once 'footer.php'; ?>
