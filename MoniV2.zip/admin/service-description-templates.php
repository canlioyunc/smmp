<?php
require_once __DIR__.'/../config.php';
require_once __DIR__.'/../includes/MoniV2Compat.php';
require_once __DIR__.'/../includes/MoniAdminUI.php';
if(!isLoggedIn()||!isAdmin()){header('Location: /login.php');exit;}

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        if(!validateCSRFToken($_POST['csrf_token']??''))throw new RuntimeException('Güvenlik doğrulaması başarısız.');
        $action=(string)($_POST['action']??'');
        if($action==='save'){
            $id=(int)($_POST['id']??0);$name=trim((string)($_POST['name']??''));$content=trim((string)($_POST['content']??''));$category=(int)($_POST['category_id']??0);$active=!empty($_POST['is_active'])?1:0;$sort=(int)($_POST['sort_order']??0);
            if($name===''||$content==='')throw new RuntimeException('Şablon adı ve açıklama içeriği zorunludur.');
            if($id>0){$s=$db->prepare("UPDATE service_description_templates SET name=?,category_id=?,content=?,is_active=?,sort_order=?,updated_at=NOW() WHERE id=?");$s->execute([$name,$category?:null,$content,$active,$sort,$id]);setAlert('Açıklama şablonu güncellendi.','success');}
            else{$s=$db->prepare("INSERT INTO service_description_templates(name,category_id,content,is_active,sort_order,created_by) VALUES(?,?,?,?,?,?)");$s->execute([$name,$category?:null,$content,$active,$sort,(int)$_SESSION['user_id']]);setAlert('Açıklama şablonu oluşturuldu.','success');}
        }elseif($action==='delete'){
            $id=(int)($_POST['id']??0);$db->prepare("DELETE FROM service_description_templates WHERE id=?")->execute([$id]);setAlert('Açıklama şablonu silindi.','success');
        }elseif($action==='duplicate'){
            $id=(int)($_POST['id']??0);$s=$db->prepare("INSERT INTO service_description_templates(name,category_id,content,is_active,sort_order,created_by) SELECT CONCAT(name,' (Kopya)'),category_id,content,0,sort_order,? FROM service_description_templates WHERE id=?");$s->execute([(int)$_SESSION['user_id'],$id]);setAlert('Şablon kopyalandı; güvenlik için pasif oluşturuldu.','success');
        }
        header('Location: service-description-templates.php');exit;
    }catch(Throwable $e){setAlert($e->getMessage(),'danger');}
}
$edit=null;if(!empty($_GET['edit'])){$s=$db->prepare("SELECT * FROM service_description_templates WHERE id=?");$s->execute([(int)$_GET['edit']]);$edit=$s->fetch(PDO::FETCH_ASSOC)?:null;}
$templates=$db->query("SELECT t.*,c.name category_name FROM service_description_templates t LEFT JOIN categories c ON c.id=t.category_id ORDER BY t.is_active DESC,t.sort_order,t.id DESC")->fetchAll(PDO::FETCH_ASSOC);
$categories=$db->query("SELECT id,name FROM categories ORDER BY sort_order,name")->fetchAll(PDO::FETCH_ASSOC);
$pageTitle='Servis Açıklama Şablonları';require_once __DIR__.'/header.php';echo moni_admin_ui_styles();
?>
<div class="moni-page">
 <div class="moni-hero"><div><span class="moni-kicker"><i class="fas fa-file-lines"></i> Servis İçeriği</span><h2>Servis Açıklama Şablonları</h2><p>Sık kullandığınız servis açıklamalarını tek merkezde yönetin. Servis eklerken veya düzenlerken şablonu tek tıkla açıklama alanına uygulayabilirsiniz.</p></div><div class="moni-hero-actions"><a class="moni-btn secondary" href="services.php"><i class="fas fa-list"></i> Servislere Dön</a></div></div>
 <?=showAlert()?>
 <div class="moni-grid">
  <div class="moni-card third"><div class="moni-card-head"><div><h3><?=$edit?'Şablonu Düzenle':'Yeni Şablon'?></h3><p>Değişkenler servis formundaki değerlerle uygulanır.</p></div></div>
   <form method="post"><input type="hidden" name="csrf_token" value="<?=clean(generateCSRFToken())?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=intval($edit['id']??0)?>">
    <div class="moni-field"><label>Şablon adı</label><input name="name" maxlength="190" required value="<?=clean($edit['name']??'')?>" placeholder="Örn. Instagram Standart"></div><br>
    <div class="moni-field"><label>Kategori</label><select name="category_id"><option value="0">Tüm kategoriler</option><?php foreach($categories as $c):?><option value="<?=$c['id']?>" <?=((int)($edit['category_id']??0)===(int)$c['id'])?'selected':''?>><?=clean($c['name'])?></option><?php endforeach;?></select><small>Kategori seçimi servis formunda ilgili şablonların öne çıkmasına yardımcı olur.</small></div><br>
    <div class="moni-field"><label>Açıklama içeriği</label><textarea name="content" rows="12" required placeholder="Servis açıklaması..."><?=clean($edit['content']??'')?></textarea></div><br>
    <div class="moni-form-grid"><div class="moni-field"><label>Sıra</label><input type="number" name="sort_order" value="<?=intval($edit['sort_order']??0)?>"></div><div class="moni-field"><label>Durum</label><label class="moni-check"><input type="checkbox" name="is_active" value="1" <?=!isset($edit['is_active'])||$edit['is_active']?'checked':''?>> Aktif şablon</label></div></div><br>
    <div class="moni-actions"><button class="moni-btn"><i class="fas fa-save"></i> <?=$edit?'Güncelle':'Şablon Ekle'?></button><?php if($edit):?><a class="moni-btn secondary" href="service-description-templates.php">Vazgeç</a><?php endif;?></div>
   </form>
   <div class="moni-divider"></div><div class="moni-help"><i class="fas fa-code"></i><div><strong>Kullanılabilir değişkenler</strong><br><span class="moni-code">{{service_name}}</span> <span class="moni-code">{{min}}</span> <span class="moni-code">{{max}}</span> <span class="moni-code">{{refill_days}}</span> <span class="moni-code">{{price}}</span></div></div>
  </div>
  <div class="moni-card two-third"><div class="moni-card-head"><div><h3>Kayıtlı Şablonlar</h3><p><?=count($templates)?> şablon · pasif şablonlar servis formunda gösterilmez.</p></div></div>
   <div class="moni-table-wrap"><table class="moni-table"><thead><tr><th>Şablon</th><th>Kategori</th><th>Önizleme</th><th>Durum</th><th>İşlem</th></tr></thead><tbody>
   <?php foreach($templates as $t):?><tr><td><strong><?=clean($t['name'])?></strong><div class="moni-muted">Sıra <?=$t['sort_order']?> · #<?=$t['id']?></div></td><td><?=clean($t['category_name']?:'Tüm kategoriler')?></td><td><?=clean(mb_strimwidth((string)$t['content'],0,115,'…','UTF-8'))?></td><td><span class="moni-badge <?=$t['is_active']?'ok':'off'?>"><?=$t['is_active']?'Aktif':'Pasif'?></span></td><td><div class="moni-actions"><a class="moni-btn secondary sm" href="?edit=<?=$t['id']?>"><i class="fas fa-pen"></i> Düzenle</a><form method="post"><input type="hidden" name="csrf_token" value="<?=clean(generateCSRFToken())?>"><input type="hidden" name="action" value="duplicate"><input type="hidden" name="id" value="<?=$t['id']?>"><button class="moni-btn secondary sm"><i class="fas fa-copy"></i> Kopyala</button></form><form method="post" onsubmit="return confirm('Şablon silinsin mi?')"><input type="hidden" name="csrf_token" value="<?=clean(generateCSRFToken())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$t['id']?>"><button class="moni-btn danger sm"><i class="fas fa-trash"></i></button></form></div></td></tr><?php endforeach;?>
   <?php if(!$templates):?><tr><td colspan="5" class="moni-table-empty">Henüz açıklama şablonu oluşturulmadı.</td></tr><?php endif;?></tbody></table></div>
  </div>
 </div>
</div>
<?php require_once __DIR__.'/footer.php'; ?>
