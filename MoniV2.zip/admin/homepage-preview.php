<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';
require_once __DIR__ . '/../includes/MoniHomepage.php';

if (!isLoggedIn() || !isAdmin()) {
    http_response_code(403);
    exit('Bu önizleme yalnız yetkili yöneticiler tarafından görüntülenebilir.');
}
if (function_exists('moni_staff_can') && !moni_staff_can($db, 'settings.manage')) {
    http_response_code(403);
    exit('Yetkiniz yok.');
}

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('X-Robots-Tag: noindex, nofollow');
header('Content-Type: text/html; charset=UTF-8');
header('X-Frame-Options: SAMEORIGIN');
header("Content-Security-Policy: frame-ancestors 'self'");

$allowedLayouts = ['nebula', 'ivory', 'pulse', 'aurora', 'glass', 'editorial', 'market', 'neon'];
$interface = moni_home_default_interface();
$id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);

if ($id && moni_home_table_ready($db)) {
    $query = $db->prepare('SELECT * FROM homepage_interfaces WHERE id=? LIMIT 1');
    $query->execute([$id]);
    $stored = $query->fetch(PDO::FETCH_ASSOC);
    if ($stored) {
        $interface = array_merge($interface, $stored);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['_token'] ?? '')) {
        http_response_code(419);
        exit('Önizleme oturumu doğrulanamadı. Sayfayı yenileyin.');
    }

    $textFields = [
        'name', 'slug', 'description', 'hero_badge', 'hero_title', 'hero_description',
        'primary_cta_text', 'primary_cta_url', 'secondary_cta_text', 'secondary_cta_url',
        'announcement_text', 'announcement_cta_text', 'announcement_cta_url', 'custom_css',
    ];
    foreach ($textFields as $field) {
        if (array_key_exists($field, $_POST)) {
            $interface[$field] = trim((string) $_POST[$field]);
        }
    }

    $layout = (string) ($_POST['layout_key'] ?? $interface['layout_key']);
    $interface['layout_key'] = in_array($layout, $allowedLayouts, true) ? $layout : 'nebula';

    foreach (['background_color', 'surface_color', 'surface_alt_color', 'text_color', 'muted_color', 'primary_color', 'secondary_color', 'accent_color', 'button_text_color', 'header_bg_color', 'header_text_color', 'border_color'] as $field) {
        if (array_key_exists($field, $_POST)) {
            $interface[$field] = (string) $_POST[$field];
        }
    }

    $interface['announcement_enabled'] = !empty($_POST['announcement_enabled']) ? 1 : 0;
    $options = [];
    foreach (['stats', 'categories', 'features', 'process', 'services', 'reviews', 'faq', 'blog', 'cta'] as $section) {
        $options[$section] = !empty($_POST['section_' . $section]) ? 1 : 0;
    }
    $interface['options_json'] = json_encode($options, JSON_UNESCAPED_UNICODE);
    $interface['custom_css'] = moni_home_sanitize_css((string) ($interface['custom_css'] ?? ''));
}

$GLOBALS['homepageInterface'] = $interface;
$GLOBALS['moniHomepagePreview'] = true;
$activeLanguages = getLanguages();
$currentLanguageCode = getCurrentLanguage();
$currentLanguageInfo = null;
foreach ($activeLanguages as $language) {
    if ($language['code'] === $currentLanguageCode) {
        $currentLanguageInfo = $language;
        break;
    }
}
$GLOBALS['siteFavicon'] = $siteSettings['favicon'] ?? '';
$GLOBALS['currentLang'] = $currentLanguageCode;
$GLOBALS['activeLanguages'] = $activeLanguages;
$GLOBALS['currentLangInfo'] = $currentLanguageInfo;

$previewBufferLevel = ob_get_level();
ob_start();
try {
    $homeData = moni_home_collect_data($db);
    require __DIR__ . '/../includes/header.php';
?>
<style>
html{scroll-behavior:smooth}.hp-preview-ribbon{position:fixed;z-index:9999;right:13px;bottom:13px;display:inline-flex;align-items:center;gap:7px;padding:8px 11px;border:1px solid rgba(255,255,255,.18);border-radius:999px;color:#fff;background:rgba(8,11,18,.78);box-shadow:0 12px 35px rgba(0,0,0,.22);backdrop-filter:blur(14px);font:700 11px/1.2 Inter,sans-serif}.hp-preview-ribbon i{color:#38d79f}.scroll-to-top{display:none!important}
</style>
<div class="hp-preview-ribbon"><i class="fas fa-eye"></i> Yönetici önizlemesi</div>
<?php
moni_home_render($db, $interface, $homeData);
?>
<script>
document.addEventListener('click',function(event){var link=event.target.closest('a');if(link){event.preventDefault();}});
document.addEventListener('submit',function(event){event.preventDefault();});
</script>
<?php
    require __DIR__ . '/../includes/footer.php';
    $previewHtml = ob_get_clean();
    echo $previewHtml;
} catch (Throwable $exception) {
    while (ob_get_level() > $previewBufferLevel) {
        ob_end_clean();
    }
    error_log('Homepage preview failed: ' . $exception->getMessage());
    http_response_code(500);
    echo '<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Önizleme hazırlanamadı</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:#0b0e18;color:#f7f8ff;font-family:Inter,-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif}.box{max-width:420px;padding:30px;border:1px solid #4b2938;border-radius:20px;background:#18121a;text-align:center}i{display:grid;place-items:center;width:52px;height:52px;margin:0 auto 16px;border-radius:16px;background:#ef476f22;color:#ef476f;font-style:normal;font-size:25px;font-weight:900}h1{font-size:20px}p{color:#bca9b2;line-height:1.65;font-size:13px}</style></head><body><div class="box"><i>!</i><h1>Önizleme hazırlanamadı</h1><p>Dosyaların doğru klasöre yüklendiğini kontrol edin ve yönetim sayfasındaki Yenile düğmesine basın.</p></div></body></html>';
}
?>
