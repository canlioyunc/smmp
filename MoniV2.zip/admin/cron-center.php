<?php
/**
 * Moni Cron Merkezi
 * Tek cronmoni.php giriş noktasındaki görevleri yönetir.
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';
require_once __DIR__ . '/../includes/MoniCron.php';
require_once __DIR__ . '/../includes/MoniAdminUI.php';

function moni_cron_admin_redirect(): void {
    header('Location: /admin/cron-center.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');
    try {
        if ($action === 'cron_save') {
            $tasks = $_POST['tasks'] ?? [];
            if (!is_array($tasks)) $tasks = [];

            $st = $db->prepare("UPDATE cron_tasks
                SET interval_minutes=?, batch_size=?, is_enabled=?,
                    next_run_at=CASE WHEN ?=1 THEN LEAST(COALESCE(next_run_at,NOW()),NOW()) ELSE next_run_at END,
                    updated_at=NOW()
                WHERE id=?");

            foreach ($tasks as $id => $v) {
                if (!is_array($v)) continue;
                $interval = max(1, min(10080, (int)($v['interval'] ?? 5)));
                $batch = max(1, min(5000, (int)($v['batch'] ?? 50)));
                $enabled = !empty($v['enabled']) ? 1 : 0;
                $st->execute([$interval, $batch, $enabled, $enabled, (int)$id]);
            }

            setAlert('Cron görev ayarları kaydedildi.', 'success');
            moni_cron_admin_redirect();
        }

        if ($action === 'cron_watchdog_settings') {
            $enabled=!empty($_POST['enabled'])?'1':'0';
            $main=max(2,min(120,(int)($_POST['main_threshold']??3)));
            $grace=max(1,min(1440,(int)($_POST['task_grace']??5)));
            $repeat=max(5,min(10080,(int)($_POST['repeat_minutes']??60)));
            $email=!empty($_POST['email_enabled'])?'1':'0';
            foreach(['cron_watchdog_enabled'=>$enabled,'cron_watchdog_main_threshold_minutes'=>(string)$main,'cron_watchdog_task_grace_minutes'=>(string)$grace,'cron_watchdog_repeat_minutes'=>(string)$repeat,'cron_watchdog_email_enabled'=>$email] as $k=>$v) updateSetting($k,$v);
            if(function_exists('moni_cron_watchdog_check'))moni_cron_watchdog_check($db,true);
            setAlert('Cron kaçırma alarmı ayarları kaydedildi.','success');
            moni_cron_admin_redirect();
        }

        if ($action === 'cron_run') {
            $key = preg_replace('/[^a-z0-9_]/', '', (string)($_POST['task_key'] ?? ''));
            if ($key === '') throw new RuntimeException('Cron görevi seçilmedi.');

            $s = $db->prepare("SELECT * FROM cron_tasks WHERE task_key=? LIMIT 1");
            $s->execute([$key]);
            $task = $s->fetch(PDO::FETCH_ASSOC);
            if (!$task) throw new RuntimeException('Cron görevi bulunamadı.');

            $db->prepare("UPDATE cron_tasks SET locked_until=NULL,next_run_at=NOW() WHERE id=?")->execute([$task['id']]);
            $result = moni_cron_run($db, $key);
            $r = $result['tasks'][$key] ?? null;
            if (!$r || ($r['status'] ?? 'error') === 'error') {
                throw new RuntimeException($r['message'] ?? 'Cron görevi çalıştırılamadı.');
            }

            setAlert('Cron görevi çalıştırıldı: ' . (int)($r['processed'] ?? 0) . ' işlem.', 'success');
            moni_cron_admin_redirect();
        }
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        setAlert($e->getMessage(), 'danger');
        moni_cron_admin_redirect();
    }
}

$cronReady = moni_table_ready($db, 'cron_tasks') && moni_table_ready($db, 'cron_runs');
$cronTasks = $cronReady
    ? $db->query("SELECT * FROM cron_tasks ORDER BY id")->fetchAll(PDO::FETCH_ASSOC)
    : [];
if(function_exists('moni_plugin_enabled')){ if(!moni_plugin_enabled('premium_memberships',$db))$cronTasks=array_values(array_filter($cronTasks,static fn($t)=>($t['task_key']??'')!=='premium_memberships')); if(!moni_plugin_enabled('service_auto_badges',$db))$cronTasks=array_values(array_filter($cronTasks,static fn($t)=>($t['task_key']??'')!=='service_auto_badges')); }
$cronRuns = $cronReady
    ? $db->query("SELECT * FROM cron_runs ORDER BY id DESC LIMIT 40")->fetchAll(PDO::FETCH_ASSOC)
    : [];

$orderDispatchTask = null;
foreach ($cronTasks as $ct) { if (($ct['task_key'] ?? '') === 'order_dispatch') { $orderDispatchTask = $ct; break; } }
$orderDispatchQueue = ['waiting'=>0,'manual'=>0,'failed'=>0];
if (function_exists('moni_table_ready') && moni_table_ready($db,'order_dispatch_jobs')) {
    try {
        $qr=$db->query("SELECT SUM(status IN ('queued','retry','processing')) waiting_count,SUM(status='manual_review') manual_count,SUM(status='failed') failed_count FROM order_dispatch_jobs")->fetch(PDO::FETCH_ASSOC) ?: [];
        $orderDispatchQueue=['waiting'=>(int)($qr['waiting_count']??0),'manual'=>(int)($qr['manual_count']??0),'failed'=>(int)($qr['failed_count']??0)];
    } catch(Throwable $e) {}
}

$watchdogStates=[];$watchdogMissed=0;
if(function_exists('moni_table_ready')&&moni_table_ready($db,'cron_watchdog_state')){
    try{$watchdogStates=$db->query("SELECT * FROM cron_watchdog_state ORDER BY is_missed DESC,updated_at DESC")->fetchAll(PDO::FETCH_ASSOC);foreach($watchdogStates as $ws)if(!empty($ws['is_missed']))$watchdogMissed++;}catch(Throwable $e){}
}
$cronHeartbeat=(string)getSetting('cron_main_last_heartbeat_at','');

$activeCount = 0;
$runningCount = 0;
$errorTaskCount = 0;
$lastTaskTime = null;
foreach ($cronTasks as $task) {
    if (!empty($task['is_enabled'])) $activeCount++;
    if (($task['last_status'] ?? '') === 'running') $runningCount++;
    if (($task['last_status'] ?? '') === 'error') $errorTaskCount++;
    $ts = $task['last_finished_at'] ?: $task['last_started_at'];
    if ($ts && (!$lastTaskTime || strtotime($ts) > strtotime($lastTaskTime))) $lastTaskTime = $ts;
}

$success24h = 0;
$errors24h = 0;
$processed24h = 0;
if ($cronReady) {
    $summary = $db->query("SELECT
        SUM(status='success') AS success_count,
        SUM(status='error') AS error_count,
        COALESCE(SUM(processed_count),0) AS processed_count
        FROM cron_runs WHERE started_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)")->fetch(PDO::FETCH_ASSOC) ?: [];
    $success24h = (int)($summary['success_count'] ?? 0);
    $errors24h = (int)($summary['error_count'] ?? 0);
    $processed24h = (int)($summary['processed_count'] ?? 0);
}

$taskMeta = [
    'scheduled_orders' => ['icon' => 'fa-calendar-check', 'group' => 'Sipariş', 'desc' => 'Zamanı gelen süreli siparişleri güvenli biçimde kuyruğa alır.'],
    'order_dispatch' => ['icon' => 'fa-paper-plane', 'group' => 'Sipariş', 'desc' => 'Provider API’ye henüz gönderilmemiş siparişleri güvenli kuyruktan toplu olarak iletir.'],
    'premium_memberships' => ['icon' => 'fa-crown', 'group' => 'Kullanıcı', 'desc' => 'Premium sürelerini, otomatik yenilemeyi ve cashback eşiklerini güvenli biçimde işler.'],
    'dripfeed' => ['icon' => 'fa-layer-group', 'group' => 'Sipariş', 'desc' => 'Dripfeed siparişlerinin sıradaki parçalarını işler.'],
    'update_orders' => ['icon' => 'fa-sync-alt', 'group' => 'Sipariş', 'desc' => 'Sağlayıcı sipariş durumlarını ve iadeleri senkronize eder.'],
    'provider_health' => ['icon' => 'fa-heartbeat', 'group' => 'Sağlayıcı', 'desc' => 'API sağlığı, gecikme ve sağlayıcı bakiyelerini kontrol eder.'],
    'provider_sla' => ['icon' => 'fa-wave-square', 'group' => 'Sağlayıcı', 'desc' => 'Sağlayıcı başarı, gecikme, sağlık skoru ve ardışık hata SLA hedeflerini izler.'],
    'sync_prices' => ['icon' => 'fa-tags', 'group' => 'Fiyat', 'desc' => 'Sağlayıcı maliyetlerini ve fiyat koruma kurallarını günceller.'],
    'profit_protection' => ['icon' => 'fa-shield-halved', 'group' => 'Fiyat', 'desc' => 'Maliyeti satış fiyatına ulaşan/aşan servisleri tanımlı minimum kâr marjına yükseltir.'],
    'service_quality' => ['icon' => 'fa-gauge-high', 'group' => 'Servis', 'desc' => 'Gerçek sipariş sonuçlarından kalite puanı üretir ve eşik altındaki servisleri karantinaya alır.'],
    'service_auto_badges' => ['icon' => 'fa-award', 'group' => 'Servis', 'desc' => 'Aktif olduğunda servis hız, kalite, drop, talep ve fiyat verilerinden otomatik rozetleri hesaplar.'],
    'accounting_sync' => ['icon' => 'fa-calculator', 'group' => 'Finans', 'desc' => 'Bakiye ve finans hareketlerini aktif muhasebe entegrasyonlarına güvenli retry kuyruğuyla aktarır.'],
    'cron_watchdog' => ['icon' => 'fa-bell', 'group' => 'Sistem', 'desc' => 'Ana cron heartbeat ve geciken görevleri izler; panel/e-posta uyarısı üretir.'],
    'financial_closing' => ['icon' => 'fa-balance-scale', 'group' => 'Finans', 'desc' => 'Gün sonu finansal kapanış taslağını hazırlar.'],
    'cleanup' => ['icon' => 'fa-broom', 'group' => 'Bakım', 'desc' => 'Süresi dolan token, log ve idempotency kayıtlarını temizler.'],
    'e_invoice' => ['icon' => 'fa-file-invoice', 'group' => 'Finans', 'desc' => 'e-Fatura / e-Arşiv kuyruğundaki belgeleri işler.'],
];

function cron_status_label(string $status): string {
    return [
        'success' => 'Başarılı',
        'error' => 'Hata',
        'running' => 'Çalışıyor',
        'skipped' => 'Atlandı',
        'never' => 'Henüz çalışmadı',
    ][$status] ?? ucfirst($status ?: 'never');
}

function cron_status_class(string $status): string {
    if ($status === 'success') return 'success';
    if ($status === 'error') return 'danger';
    if ($status === 'running') return 'info';
    return 'neutral';
}

function cron_dt(?string $value): string {
    if (!$value) return '—';
    $ts = strtotime($value);
    return $ts ? date('d.m.Y H:i:s', $ts) : $value;
}

$pageTitle = 'Cron Merkezi';
require_once __DIR__ . '/header.php';
echo moni_admin_ui_styles();

$cronCommand = '* * * * * php ' . rtrim(SITE_PATH, '/') . '/cronmoni.php >/dev/null 2>&1';
?>
<style>
.cron-page{max-width:1500px;margin:0 auto}.cron-hero{position:relative;overflow:hidden;background:linear-gradient(135deg,var(--card-bg-color),color-mix(in srgb,var(--primary-color) 13%,var(--card-bg-color)));border:1px solid var(--border-color);border-radius:16px;padding:16px 18px;margin-bottom:16px}.cron-hero:after{content:"";position:absolute;right:-90px;top:-110px;width:190px;height:190px;border-radius:50%;background:color-mix(in srgb,var(--primary-color) 13%,transparent);pointer-events:none}.cron-hero-main{position:relative;z-index:1;display:flex;justify-content:space-between;gap:22px;align-items:flex-start}.cron-kicker{display:inline-flex;align-items:center;gap:8px;padding:6px 10px;border-radius:999px;background:color-mix(in srgb,var(--primary-color) 12%,transparent);color:var(--accent-text-color);font-size:.76rem;font-weight:800;letter-spacing:.03em;text-transform:uppercase}.cron-hero h2{font-size:1.28rem;margin:12px 0 7px}.cron-hero p{max-width:770px;margin:0;opacity:.72;line-height:1.6;font-size:.92rem}.cron-hero-actions{display:flex;gap:9px;position:relative;z-index:2;flex-wrap:wrap}.cron-command{margin-top:20px;display:flex;align-items:center;gap:12px;background:color-mix(in srgb,var(--background-color) 80%,transparent);border:1px solid var(--border-color);border-radius:14px;padding:11px 12px}.cron-command code{flex:1;min-width:0;overflow:auto;white-space:nowrap;font-size:.82rem;opacity:.88}.cron-copy{width:38px;height:36px;border:1px solid var(--border-color);border-radius:10px;background:var(--card-bg-color);color:var(--text-color);cursor:pointer;flex:0 0 auto}.cron-copy:hover{border-color:var(--accent-text-color);color:var(--accent-text-color)}
.cron-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin-bottom:16px}.cron-stat{background:var(--card-bg-color);border:1px solid var(--border-color);border-radius:12px;padding:14px;display:flex;gap:14px;align-items:center}.cron-stat-icon{width:44px;height:44px;border-radius:13px;display:grid;place-items:center;background:color-mix(in srgb,var(--primary-color) 12%,transparent);color:var(--accent-text-color);font-size:1rem}.cron-stat.danger .cron-stat-icon{background:rgba(239,68,68,.12);color:#ef4444}.cron-stat.success .cron-stat-icon{background:rgba(34,197,94,.12);color:#22c55e}.cron-stat b{display:block;font-size:1.28rem;line-height:1.15}.cron-stat span{font-size:.78rem;opacity:.65}.cron-section{background:var(--card-bg-color);border:1px solid var(--border-color);border-radius:14px;margin-bottom:16px;overflow:hidden}.cron-section-head{padding:16px 18px;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;gap:14px;align-items:center}.cron-section-head h3{font-size:1rem;margin:0}.cron-section-head p{font-size:.8rem;opacity:.62;margin:4px 0 0}.cron-task-list{padding:8px 18px 4px}.cron-task{display:grid;grid-template-columns:minmax(270px,1.8fr) minmax(145px,.65fr) minmax(145px,.65fr) 90px minmax(190px,.95fr) minmax(145px,.65fr) 56px;gap:14px;align-items:center;padding:16px 4px;border-bottom:1px solid var(--border-color)}.cron-task:last-child{border-bottom:0}.cron-task-name{display:flex;align-items:flex-start;gap:12px;min-width:0}.cron-task-icon{width:40px;height:40px;border-radius:12px;background:color-mix(in srgb,var(--primary-color) 10%,transparent);color:var(--accent-text-color);display:grid;place-items:center;flex:0 0 auto}.cron-task-title{font-size:.9rem;font-weight:700;margin:0 0 3px}.cron-task-key{font-size:.72rem;opacity:.5;font-family:ui-monospace,SFMono-Regular,Menlo,monospace}.cron-task-desc{font-size:.75rem;opacity:.62;margin-top:5px;line-height:1.4}.cron-field label{display:block;font-size:.69rem;font-weight:700;text-transform:uppercase;letter-spacing:.04em;opacity:.5;margin-bottom:6px}.cron-input-wrap{display:flex;align-items:center;background:var(--background-color);border:1px solid var(--border-color);border-radius:10px;overflow:hidden}.cron-input-wrap input{width:100%;min-width:0;border:0;background:transparent;color:var(--text-color);padding:9px 8px;font-weight:700;outline:none}.cron-input-wrap span{padding:0 9px;font-size:.69rem;opacity:.5;border-left:1px solid var(--border-color)}.cron-state{min-width:0}.cron-state .pill{display:inline-flex;align-items:center;gap:6px;border-radius:999px;padding:5px 9px;font-size:.72rem;font-weight:800}.pill.success{background:rgba(34,197,94,.12);color:#22c55e}.pill.danger{background:rgba(239,68,68,.12);color:#ef4444}.pill.info{background:rgba(14,165,233,.12);color:#0ea5e9}.pill.neutral{background:rgba(148,163,184,.12);color:#94a3b8}.cron-state small{display:block;opacity:.58;font-size:.69rem;line-height:1.35;margin-top:5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:260px}.cron-next b{display:block;font-size:.8rem}.cron-next span{display:block;font-size:.69rem;opacity:.55;margin-top:3px}.cron-run-btn{width:40px;height:40px;border-radius:11px;border:1px solid var(--border-color);background:var(--background-color);color:var(--text-color);cursor:pointer}.cron-run-btn:hover{background:var(--primary-color);border-color:var(--accent-text-color);color:var(--on-primary-color)}.cron-savebar{padding:16px 20px;border-top:1px solid var(--border-color);display:flex;align-items:center;justify-content:space-between;gap:15px;background:color-mix(in srgb,var(--background-color) 35%,transparent)}.cron-savebar span{font-size:.78rem;opacity:.6}.switch{position:relative;display:inline-block;width:46px;height:26px}.switch input{opacity:0;width:0;height:0}.slider{position:absolute;cursor:pointer;inset:0;background:rgba(148,163,184,.32);transition:.2s;border-radius:999px}.slider:before{content:"";position:absolute;width:20px;height:20px;left:3px;top:3px;background:#fff;border-radius:50%;transition:.2s;box-shadow:0 1px 4px rgba(0,0,0,.25)}.switch input:checked+.slider{background:var(--primary-color)}.switch input:checked+.slider:before{transform:translateX(20px)}.cron-table-wrap{overflow:auto}.cron-table{width:100%;border-collapse:collapse;min-width:850px}.cron-table th{padding:12px 18px;text-align:left;font-size:.7rem;text-transform:uppercase;letter-spacing:.04em;opacity:.5;background:color-mix(in srgb,var(--background-color) 34%,transparent)}.cron-table td{padding:13px 18px;border-top:1px solid var(--border-color);font-size:.8rem;vertical-align:middle}.cron-empty{padding:44px 20px;text-align:center;opacity:.65}.cron-empty i{display:block;font-size:2rem;margin-bottom:10px;color:var(--accent-text-color)}
.dispatch-focus{margin:16px 0;background:linear-gradient(135deg,color-mix(in srgb,var(--primary-color) 12%,var(--card-bg-color)),var(--card-bg-color));border:1px solid color-mix(in srgb,var(--primary-color) 35%,var(--border-color));border-radius:16px;padding:18px 20px;display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap}.dispatch-focus h3{margin:0 0 5px;font-size:1rem}.dispatch-focus p{margin:0;opacity:.65;font-size:.78rem}.dispatch-metrics{display:flex;gap:10px;flex-wrap:wrap}.dispatch-metric{min-width:110px;padding:10px 12px;border-radius:11px;background:var(--background-color);border:1px solid var(--border-color)}.dispatch-metric b{display:block;font-size:1rem}.dispatch-metric span{font-size:.69rem;opacity:.55}.dispatch-focus .btn{white-space:nowrap}
@media(max-width:1280px){.cron-task{grid-template-columns:minmax(250px,1.5fr) 125px 125px 75px minmax(160px,.9fr) 130px 50px}.cron-stats{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:980px){.cron-hero-main{flex-direction:column}.cron-task-list{padding:10px}.cron-task{grid-template-columns:1fr 1fr;gap:13px;padding:18px 8px}.cron-task-name{grid-column:1/-1}.cron-state{grid-column:1/-1}.cron-next{grid-column:1/2}.cron-run{grid-column:2/3;justify-self:end}.cron-enabled{justify-self:start}.cron-savebar{position:sticky;bottom:0;z-index:3}}@media(max-width:620px){.cron-stats{grid-template-columns:1fr}.cron-hero{padding:20px}.cron-command{align-items:flex-start}.cron-task{grid-template-columns:1fr}.cron-task-name,.cron-state,.cron-next,.cron-run,.cron-enabled{grid-column:1/-1}.cron-run{justify-self:start}.cron-savebar{align-items:flex-start;flex-direction:column}}
</style>

<div class="cron-page">
    <div class="cron-hero">
        <div class="cron-hero-main">
            <div>
                <span class="cron-kicker"><i class="fas fa-clock"></i> Otomasyon Altyapısı</span>
                <h2>Merkezi Cron Yönetimi</h2>
                <p>Sunucuda yalnız <strong>cronmoni.php</strong> çalışır. Her görevin çalışma aralığını, bir çalışmada işlenecek kayıt limitini ve aktiflik durumunu buradan bağımsız olarak yönetebilirsiniz.</p>
            </div>
            <div class="cron-hero-actions">
                <a class="btn btn-secondary btn-sm" href="/admin/moni-system.php"><i class="fas fa-layer-group"></i> Sistem Merkezi</a>
            </div>
        </div>
        <div class="cron-command">
            <i class="fas fa-terminal" style="color:var(--accent-text-color)"></i>
            <code id="cronCommand"><?=clean($cronCommand)?></code>
            <button class="cron-copy" type="button" onclick="copyCronCommand()" title="Komutu kopyala"><i class="far fa-copy"></i></button>
        </div>
    </div>

    <?=showAlert()?>

    <?php if (!$cronReady): ?>
        <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> Cron tabloları bulunamadı. Veritabanı güncellemesini uygulamadan bu sayfa kullanılamaz.</div>
    <?php else: ?>
        <div class="dispatch-focus" id="order-dispatch-settings">
            <div>
                <h3><i class="fas fa-paper-plane"></i> Siparişleri API’ye Gönder</h3>
                <p>Kullanıcı siparişleri web isteğinde provider API’ye gitmez; kuyruğa alınır ve bu cron görevi tarafından toplu gönderilir.</p>
            </div>
            <div class="dispatch-metrics">
                <div class="dispatch-metric"><b><?= $orderDispatchTask ? (int)$orderDispatchTask['interval_minutes'].' dk' : '1 dk' ?></b><span>Gönderim aralığı</span></div>
                <div class="dispatch-metric"><b><?= $orderDispatchTask ? (int)$orderDispatchTask['batch_size'] : 100 ?></b><span>Her çalışmada max.</span></div>
                <div class="dispatch-metric"><b><?= (int)$orderDispatchQueue['waiting'] ?></b><span>API’ye gönderilmeyi bekleyen</span></div>
                <div class="dispatch-metric"><b><?= (int)$orderDispatchQueue['manual'] ?></b><span>Manuel inceleme</span></div>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap"><a class="btn btn-secondary" href="/admin/cron-trends.php"><i class="fas fa-chart-line"></i> Süre Trendleri</a><a class="btn btn-primary" href="#task-order_dispatch"><i class="fas fa-sliders-h"></i> Ayarları Düzenle</a></div>
        </div>
        <div class="dispatch-focus" id="cron-watchdog-settings" style="border-color:<?= $watchdogMissed ? 'rgba(239,68,68,.38)' : 'color-mix(in srgb,var(--primary-color) 30%,var(--border-color))' ?>">
            <div>
                <h3><i class="fas fa-bell"></i> Cron Kaçırma Alarmı</h3>
                <p>Ana cron heartbeat'ini ve görevlerin beklenen çalışma aralığını izler. Cron tamamen durursa ilk web isteğinde de gecikme tespit edilir.</p>
            </div>
            <div class="dispatch-metrics">
                <div class="dispatch-metric"><b><?= $watchdogMissed ?></b><span>Geciken görev</span></div>
                <div class="dispatch-metric"><b><?= $cronHeartbeat ? clean(cron_dt($cronHeartbeat)) : 'Henüz yok' ?></b><span>Son ana heartbeat</span></div>
            </div>
            <details style="min-width:min(100%,520px)"><summary class="btn btn-secondary"><i class="fas fa-sliders-h"></i> Alarm Ayarları</summary>
                <form method="post" style="margin-top:12px;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px">
                    <input type="hidden" name="action" value="cron_watchdog_settings">
                    <label class="cron-field"><span>Ana cron gecikme eşiği</span><div class="cron-input-wrap"><input type="number" min="2" max="120" name="main_threshold" value="<?=intval(getSetting('cron_watchdog_main_threshold_minutes','3'))?>"><span>dk</span></div></label>
                    <label class="cron-field"><span>Görev toleransı</span><div class="cron-input-wrap"><input type="number" min="1" max="1440" name="task_grace" value="<?=intval(getSetting('cron_watchdog_task_grace_minutes','5'))?>"><span>dk</span></div></label>
                    <label class="cron-field"><span>Tekrar uyarı aralığı</span><div class="cron-input-wrap"><input type="number" min="5" max="10080" name="repeat_minutes" value="<?=intval(getSetting('cron_watchdog_repeat_minutes','60'))?>"><span>dk</span></div></label>
                    <div style="display:flex;flex-direction:column;gap:8px;justify-content:end"><label><input type="checkbox" name="enabled" value="1" <?=getSetting('cron_watchdog_enabled','1')==='1'?'checked':''?>> Alarm aktif</label><label><input type="checkbox" name="email_enabled" value="1" <?=getSetting('cron_watchdog_email_enabled','0')==='1'?'checked':''?>> Admin e-postalarına da gönder</label></div>
                    <div style="grid-column:1/-1"><button class="btn btn-primary"><i class="fas fa-save"></i> Alarm Ayarlarını Kaydet</button></div>
                </form>
            </details>
        </div>

        <div class="cron-stats">
            <div class="cron-stat success"><div class="cron-stat-icon"><i class="fas fa-toggle-on"></i></div><div><b><?=$activeCount?> / <?=count($cronTasks)?></b><span>Aktif görev</span></div></div>
            <div class="cron-stat"><div class="cron-stat-icon"><i class="fas fa-check-circle"></i></div><div><b><?=$success24h?></b><span>Son 24 saatte başarılı çalışma</span></div></div>
            <div class="cron-stat <?=$errors24h > 0 ? 'danger' : ''?>"><div class="cron-stat-icon"><i class="fas fa-exclamation-circle"></i></div><div><b><?=$errors24h?></b><span>Son 24 saatte hata</span></div></div>
            <div class="cron-stat"><div class="cron-stat-icon"><i class="fas fa-stream"></i></div><div><b><?=number_format($processed24h,0,',','.')?></b><span>Son 24 saatte işlenen kayıt</span></div></div>
        </div>

        <?php if ($errorTaskCount > 0): ?>
            <div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> <?=$errorTaskCount?> görev son çalışmasında hata verdi. Aşağıdaki durum mesajlarını kontrol edin.</div>
        <?php elseif ($lastTaskTime): ?>
            <div class="alert alert-info"><i class="fas fa-info-circle"></i> Son kayıtlı cron görevi çalışması: <strong><?=clean(cron_dt($lastTaskTime))?></strong>. Sunucu cron'unun <strong>her dakika</strong> cronmoni.php dosyasını tetiklemesi önerilir.</div>
        <?php endif; ?>

        <div class="cron-section">
            <div class="cron-section-head">
                <div><h3>Görev Planlayıcı</h3><p>Aralık ve işlem limitleri görev bazında bağımsızdır. Değişiklikler cronmoni.php dosyasını değiştirmez.</p></div>
                <span class="status-badge <?=$runningCount ? 'status-processing' : 'status-active'?>"><?=$runningCount ? $runningCount . ' görev çalışıyor' : 'Hazır'?></span>
            </div>
            <form method="post">
                <input type="hidden" name="action" value="cron_save">
                <div class="cron-task-list">
                    <?php foreach ($cronTasks as $t):
                        $meta = $taskMeta[$t['task_key']] ?? ['icon' => 'fa-cog', 'group' => 'Sistem', 'desc' => 'Merkezi cron görevi.'];
                        $status = (string)($t['last_status'] ?? 'never');
                    ?>
                        <div class="cron-task" id="task-<?=clean($t['task_key'])?>">
                            <div class="cron-task-name">
                                <div class="cron-task-icon"><i class="fas <?=clean($meta['icon'])?>"></i></div>
                                <div>
                                    <div class="cron-task-title"><?=clean($t['name'])?></div>
                                    <div class="cron-task-key"><?=clean($t['task_key'])?> · <?=clean($meta['group'])?></div>
                                    <div class="cron-task-desc"><?=clean($meta['desc'])?></div>
                                </div>
                            </div>
                            <div class="cron-field">
                                <label>Çalışma aralığı</label>
                                <div class="cron-input-wrap"><input type="number" min="1" max="10080" name="tasks[<?=$t['id']?>][interval]" value="<?= (int)$t['interval_minutes'] ?>"><span>dk</span></div>
                            </div>
                            <div class="cron-field">
                                <label>İşlem limiti</label>
                                <div class="cron-input-wrap"><input type="number" min="1" max="5000" name="tasks[<?=$t['id']?>][batch]" value="<?= (int)$t['batch_size'] ?>"><span>adet</span></div>
                            </div>
                            <div class="cron-enabled cron-field">
                                <label>Durum</label>
                                <label class="switch" title="Görevi aktif/pasif yap"><input type="checkbox" name="tasks[<?=$t['id']?>][enabled]" value="1" <?=$t['is_enabled']?'checked':''?>><span class="slider"></span></label>
                            </div>
                            <div class="cron-state">
                                <label style="display:block;font-size:.69rem;font-weight:700;text-transform:uppercase;letter-spacing:.04em;opacity:.5;margin-bottom:6px">Son durum</label>
                                <span class="pill <?=cron_status_class($status)?>"><i class="fas <?=$status==='success'?'fa-check':($status==='error'?'fa-times':($status==='running'?'fa-spinner fa-spin':'fa-minus'))?>"></i> <?=clean(cron_status_label($status))?></span>
                                <small title="<?=clean($t['last_message'] ?? '')?>"><?=clean($t['last_message'] ?: 'Henüz durum mesajı yok.')?></small>
                            </div>
                            <div class="cron-next">
                                <label style="display:block;font-size:.69rem;font-weight:700;text-transform:uppercase;letter-spacing:.04em;opacity:.5;margin-bottom:6px">Sonraki çalışma</label>
                                <b><?=clean(cron_dt($t['next_run_at']))?></b>
                                <span>Son: <?=clean(cron_dt($t['last_finished_at'] ?: $t['last_started_at']))?></span>
                            </div>
                            <div class="cron-run">
                                <button class="cron-run-btn" type="button" onclick="runCron('<?=clean($t['task_key'])?>','<?=clean(addslashes($t['name']))?>')" title="Şimdi çalıştır"><i class="fas fa-play"></i></button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="cron-savebar">
                    <span><i class="fas fa-shield-alt"></i> Değerler 1–10.080 dakika ve 1–5.000 işlem sınırları içinde doğrulanır.</span>
                    <button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Tüm Cron Ayarlarını Kaydet</button>
                </div>
            </form>
            <form id="cronRunForm" method="post" style="display:none"><input name="action" value="cron_run"><input id="cronRunKey" name="task_key"></form>
        </div>

        <div class="cron-section">
            <div class="cron-section-head"><div><h3>Son Çalışma Kayıtları</h3><p>En yeni 40 görev çalışması; süre, işlenen kayıt ve sonuç bilgileriyle gösterilir.</p></div></div>
            <?php if ($cronRuns): ?>
                <div class="cron-table-wrap">
                    <table class="cron-table">
                        <thead><tr><th>Görev</th><th>Başlangıç</th><th>Süre</th><th>Durum</th><th>İşlenen</th><th>Mesaj</th></tr></thead>
                        <tbody>
                        <?php foreach ($cronRuns as $r): $rs=(string)$r['status']; ?>
                            <tr>
                                <td><strong><?=clean($r['task_key'])?></strong></td>
                                <td><?=clean(cron_dt($r['started_at']))?></td>
                                <td><?=number_format(((int)($r['duration_ms'] ?? 0))/1000,2,',','.')?> sn</td>
                                <td><span class="pill <?=cron_status_class($rs)?>"><?=clean(cron_status_label($rs))?></span></td>
                                <td><strong><?=number_format((int)$r['processed_count'],0,',','.')?></strong></td>
                                <td style="max-width:460px;white-space:normal"><?=clean($r['message'] ?: '—')?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="cron-empty"><i class="far fa-clock"></i>Henüz cron çalışma kaydı bulunmuyor.</div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<script>
function runCron(key, name){
    if(confirm((name || key) + ' görevi şimdi çalıştırılsın mı?')){
        document.getElementById('cronRunKey').value=key;
        document.getElementById('cronRunForm').submit();
    }
}
function copyCronCommand(){
    var text=document.getElementById('cronCommand').innerText;
    if(navigator.clipboard && window.isSecureContext){
        navigator.clipboard.writeText(text).then(function(){ showCopyFeedback(); });
        return;
    }
    var ta=document.createElement('textarea');ta.value=text;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();
    try{document.execCommand('copy');showCopyFeedback();}catch(e){}
    document.body.removeChild(ta);
}
function showCopyFeedback(){
    var btn=document.querySelector('.cron-copy');if(!btn)return;
    var old=btn.innerHTML;btn.innerHTML='<i class="fas fa-check"></i>';setTimeout(function(){btn.innerHTML=old;},1200);
}
</script>
<?php require_once __DIR__ . '/footer.php'; ?>
