<?php
require_once __DIR__.'/../config.php';
require_once __DIR__.'/../includes/MoniV2Compat.php';
require_once __DIR__.'/../includes/MoniAdminUI.php';
if(!isLoggedIn()||!isAdmin()){header('Location: /login.php');exit;}

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        if(!validateCSRFToken($_POST['csrf_token']??''))throw new RuntimeException('Güvenlik doğrulaması başarısız.');
        $critical=max(0,min(100,(float)($_POST['critical_threshold']??10)));
        $healthy=max($critical,min(100,(float)($_POST['healthy_threshold']??25)));
        updateSetting('profit_heatmap_critical_threshold',(string)$critical);
        updateSetting('profit_heatmap_healthy_threshold',(string)$healthy);
        setAlert('Kâr marjı ısı haritası eşikleri kaydedildi.','success');
        header('Location: profit-heatmap.php');exit;
    }catch(Throwable $e){setAlert($e->getMessage(),'danger');}
}

$search=trim((string)($_GET['q']??''));$category=(int)($_GET['category_id']??0);$provider=(int)($_GET['provider_id']??0);$level=trim((string)($_GET['level']??''));
$where=['1=1'];$params=[];
if($search!==''){$where[]='(s.name LIKE ? OR CAST(s.id AS CHAR)=?)';$params[]='%'.$search.'%';$params[]=$search;}
if($category>0){$where[]='s.category_id=?';$params[]=$category;}
if($provider>0){$where[]='s.api_provider_id=?';$params[]=$provider;}
if(function_exists('moni_v2_compat_column_exists')&&moni_v2_compat_column_exists($db,'services','deleted_at'))$where[]='s.deleted_at IS NULL';
$sql="SELECT s.*,c.name category_name,p.name provider_name,p.alias_name provider_alias FROM services s LEFT JOIN categories c ON c.id=s.category_id LEFT JOIN api_providers p ON p.id=s.api_provider_id WHERE ".implode(' AND ',$where)." ORDER BY s.category_id,s.sort_order,s.id";
$q=$db->prepare($sql);$q->execute($params);$rows=$q->fetchAll(PDO::FETCH_ASSOC);
$filtered=[];$counts=['healthy'=>0,'watch'=>0,'critical'=>0,'loss'=>0];$sumProfit=0;$sumSale=0;
foreach($rows as $r){$m=moni_service_margin_metrics($r);$l=moni_profit_heat_level($r);$r['_margin']=$m;$r['_level']=$l;$counts[$l]++;$sumProfit+=$m['profit'];$sumSale+=$m['sale'];if($level===''||$level===$l)$filtered[]=$r;}
$avgMargin=$sumSale>0?($sumProfit/$sumSale*100):0;
$categories=$db->query("SELECT id,name FROM categories ORDER BY sort_order,name")->fetchAll(PDO::FETCH_ASSOC);
$providers=$db->query("SELECT id,name,alias_name FROM api_providers ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$critical=(float)getSetting('profit_heatmap_critical_threshold','10');$healthy=(float)getSetting('profit_heatmap_healthy_threshold','25');
$pageTitle='Kâr Marjı Isı Haritası';require_once __DIR__.'/header.php';echo moni_admin_ui_styles();
?>
<style>
.heat-cell{min-width:135px;border-radius:10px;padding:9px 11px;font-weight:800;display:inline-flex;align-items:center;gap:8px}.heat-dot{width:9px;height:9px;border-radius:50%}.heat-healthy{background:rgba(25,135,84,.12);color:#198754}.heat-watch{background:rgba(217,140,0,.13);color:#b06f00}.heat-critical{background:rgba(255,107,0,.12);color:#d85c00}.heat-loss{background:rgba(220,53,69,.12);color:#dc3545}.heat-bar{height:7px;border-radius:999px;background:var(--border-color);overflow:hidden;min-width:130px}.heat-bar>span{display:block;height:100%;border-radius:999px}.heat-legend{display:flex;gap:8px;flex-wrap:wrap}.heat-legend a{text-decoration:none}.heat-table .service-sub{display:block;color:var(--muted-text-color);font-size:.72rem;margin-top:3px}
</style>
<div class="moni-page">
  <div class="moni-hero"><div><span class="moni-kicker"><i class="fas fa-fire"></i> Fiyat & Kârlılık</span><h2>Kâr Marjı Isı Haritası</h2><p>Servislerin satış fiyatı ile gerçek maliyetini karşılaştırın; zarar eden veya marjı zayıflayan servisleri tek ekranda görün. Hesaplama kâr marjını <strong>(satış − maliyet) / satış</strong> formülüyle yapar.</p></div><div class="moni-hero-actions"><a class="moni-btn secondary" href="services.php"><i class="fas fa-list"></i> Servislere Dön</a></div></div>
  <?=showAlert()?>
  <div class="moni-grid">
    <div class="moni-card quarter compact"><div class="moni-kpi"><i class="fas fa-circle-check"></i><div><strong><?=$counts['healthy']?></strong><span class="moni-muted">Sağlıklı marj (≥ %<?=number_format($healthy,0)?>)</span></div></div></div>
    <div class="moni-card quarter compact"><div class="moni-kpi"><i class="fas fa-eye"></i><div><strong><?=$counts['watch']?></strong><span class="moni-muted">İzlenmeli servis</span></div></div></div>
    <div class="moni-card quarter compact"><div class="moni-kpi"><i class="fas fa-triangle-exclamation"></i><div><strong><?=$counts['critical']?></strong><span class="moni-muted">Kritik düşük marj</span></div></div></div>
    <div class="moni-card quarter compact"><div class="moni-kpi"><i class="fas fa-arrow-trend-down"></i><div><strong><?=$counts['loss']?></strong><span class="moni-muted">Zarar eden servis</span></div></div></div>

    <div class="moni-card two-third">
      <div class="moni-card-head"><div><h3>Servis kârlılık haritası</h3><p>Renkler servislerin güncel maliyet ve satış fiyatlarından anlık hesaplanır.</p></div><div class="moni-badge">Ortalama marj %<?=number_format($avgMargin,1,',','.')?></div></div>
      <form method="get" class="moni-toolbar">
        <div class="moni-actions" style="flex:1">
          <input name="q" value="<?=clean($search)?>" placeholder="Servis adı veya ID" style="min-width:210px">
          <select name="category_id"><option value="0">Tüm kategoriler</option><?php foreach($categories as $c):?><option value="<?=$c['id']?>" <?=$category===$c['id']?'selected':''?>><?=clean($c['name'])?></option><?php endforeach;?></select>
          <select name="provider_id"><option value="0">Tüm sağlayıcılar</option><?php foreach($providers as $p):?><option value="<?=$p['id']?>" <?=$provider===$p['id']?'selected':''?>><?=clean($p['alias_name']?:$p['name'])?></option><?php endforeach;?></select>
          <select name="level"><option value="">Tüm seviyeler</option><option value="healthy" <?=$level==='healthy'?'selected':''?>>Sağlıklı</option><option value="watch" <?=$level==='watch'?'selected':''?>>İzlenmeli</option><option value="critical" <?=$level==='critical'?'selected':''?>>Kritik</option><option value="loss" <?=$level==='loss'?'selected':''?>>Zarar</option></select>
          <button class="moni-btn secondary"><i class="fas fa-filter"></i> Filtrele</button>
        </div>
      </form>
      <div class="moni-table-wrap"><table class="moni-table heat-table"><thead><tr><th>Servis</th><th>Maliyet / 1000</th><th>Satış / 1000</th><th>Net Kâr</th><th>Kâr Marjı</th><th>Durum</th></tr></thead><tbody>
      <?php foreach($filtered as $r):$m=$r['_margin'];$l=$r['_level'];$label=['healthy'=>'Sağlıklı','watch'=>'İzlenmeli','critical'=>'Kritik','loss'=>'Zarar'][$l];$pct=max(0,min(100,(float)$m['margin_pct']));?>
        <tr><td><strong>#<?=$r['id']?> · <?=clean($r['name'])?></strong><span class="service-sub"><?=clean($r['category_name']??'-')?> · <?=clean($r['provider_alias']?:($r['provider_name']??'Manuel'))?></span></td><td><?=clean($siteSettings['currency_symbol'])?><?=number_format($m['cost'],4,',','.')?></td><td><?=clean($siteSettings['currency_symbol'])?><?=number_format($m['sale'],4,',','.')?></td><td><strong class="<?=$m['profit']<0?'text-danger':''?>"><?=clean($siteSettings['currency_symbol'])?><?=number_format($m['profit'],4,',','.')?></strong></td><td><strong>%<?=number_format($m['margin_pct'],2,',','.')?></strong><div class="heat-bar"><span class="heat-<?=$l?>" style="width:<?=$pct?>%"></span></div></td><td><span class="heat-cell heat-<?=$l?>"><span class="heat-dot" style="background:currentColor"></span><?=$label?></span></td></tr>
      <?php endforeach;?><?php if(!$filtered):?><tr><td colspan="6" class="moni-table-empty">Filtreye uygun servis bulunamadı.</td></tr><?php endif;?>
      </tbody></table></div>
    </div>
    <div class="moni-card third"><div class="moni-card-head"><div><h3>Isı haritası eşikleri</h3><p>Renk sınıflarını kendi kâr politikanıza göre ayarlayın.</p></div></div>
      <form method="post"><input type="hidden" name="csrf_token" value="<?=clean(generateCSRFToken())?>"><div class="moni-field"><label>Kritik eşik (%)</label><input type="number" name="critical_threshold" min="0" max="100" step="0.1" value="<?=clean($critical)?>"><small>Bu değerin altındaki pozitif marjlar kritik gösterilir.</small></div><br><div class="moni-field"><label>Sağlıklı eşik (%)</label><input type="number" name="healthy_threshold" min="0" max="100" step="0.1" value="<?=clean($healthy)?>"><small>Bu değerin üzeri yeşil gösterilir; aradaki değerler izleme seviyesidir.</small></div><br><button class="moni-btn"><i class="fas fa-save"></i> Eşikleri Kaydet</button></form>
      <div class="moni-divider"></div><div class="moni-help"><i class="fas fa-shield-halved"></i><div><strong>Minimum Kâr Koruma</strong><br>Bu ekran yalnız analiz eder. Otomatik fiyat yükseltme mevcut Minimum Kâr Koruma motoru tarafından ayrı yönetilir.</div></div>
    </div>
  </div>
</div>
<?php require_once __DIR__.'/footer.php'; ?>
