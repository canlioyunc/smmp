<?php
/**
 * Admin Panel - Kupon Ayarları
 */

// Header'dan önce config'i dahil et
require_once __DIR__ . '/../config.php';

// Admin kontrolü
if (!isLoggedIn() || !isAdmin()) {
    header('Location: /login.php');
    exit;
}

// Aktif sekme
$activeTab = $_GET['tab'] ?? 'coupons';

// ==================== KUPON İŞLEMLERİ ====================

// Kupon Ekleme
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_coupon') {
    $code = strtoupper(trim($_POST['code']));
    $amount = floatval($_POST['amount']);
    $usageLimit = !empty($_POST['usage_limit']) ? (int)$_POST['usage_limit'] : null;
    $usageLimitPerUser = !empty($_POST['usage_limit_per_user']) ? (int)$_POST['usage_limit_per_user'] : null;
    $minBalance = !empty($_POST['min_balance']) ? floatval($_POST['min_balance']) : null;
    $startDate = !empty($_POST['start_date']) ? $_POST['start_date'] : null;
    $endDate = !empty($_POST['end_date']) ? $_POST['end_date'] : null;
    $status = $_POST['status'] ?? 'active';
    $description = trim($_POST['description'] ?? '');
    
    if (empty($code)) {
        setAlert('Kupon kodu gereklidir.', 'danger');
    } elseif ($amount <= 0) {
        setAlert('Kupon tutarı 0\'dan büyük olmalıdır.', 'danger');
    } else {
        // Kod benzersiz mi kontrol et
        $checkStmt = $db->prepare("SELECT id FROM coupons WHERE code = ?");
        $checkStmt->execute([$code]);
        
        if ($checkStmt->fetch()) {
            setAlert('Bu kupon kodu zaten mevcut.', 'danger');
        } else {
            $stmt = $db->prepare("
                INSERT INTO coupons (code, amount, type, usage_limit, usage_limit_per_user, min_balance, start_date, end_date, status, description)
                VALUES (?, ?, 'fixed', ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $code,
                $amount,
                $usageLimit,
                $usageLimitPerUser,
                $minBalance,
                $startDate,
                $endDate,
                $status,
                $description
            ]);
            
            setAlert('Kupon başarıyla eklendi.', 'success');
        }
    }
    
    header('Location: coupons.php?tab=coupons');
    exit;
}

// Kupon Düzenleme
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit_coupon') {
    $couponId = (int)$_POST['coupon_id'];
    $code = strtoupper(trim($_POST['code']));
    $amount = floatval($_POST['amount']);
    $usageLimit = !empty($_POST['usage_limit']) ? (int)$_POST['usage_limit'] : null;
    $usageLimitPerUser = !empty($_POST['usage_limit_per_user']) ? (int)$_POST['usage_limit_per_user'] : null;
    $minBalance = !empty($_POST['min_balance']) ? floatval($_POST['min_balance']) : null;
    $startDate = !empty($_POST['start_date']) ? $_POST['start_date'] : null;
    $endDate = !empty($_POST['end_date']) ? $_POST['end_date'] : null;
    $status = $_POST['status'] ?? 'active';
    $description = trim($_POST['description'] ?? '');
    
    if (empty($code)) {
        setAlert('Kupon kodu gereklidir.', 'danger');
    } elseif ($amount <= 0) {
        setAlert('Kupon tutarı 0\'dan büyük olmalıdır.', 'danger');
    } else {
        // Kod benzersiz mi kontrol et (kendi ID'si hariç)
        $checkStmt = $db->prepare("SELECT id FROM coupons WHERE code = ? AND id != ?");
        $checkStmt->execute([$code, $couponId]);
        
        if ($checkStmt->fetch()) {
            setAlert('Bu kupon kodu zaten mevcut.', 'danger');
        } else {
            $stmt = $db->prepare("
                UPDATE coupons SET 
                    code = ?, amount = ?, usage_limit = ?, usage_limit_per_user = ?, 
                    min_balance = ?, start_date = ?, end_date = ?, status = ?, description = ?
                WHERE id = ?
            ");
            $stmt->execute([
                $code,
                $amount,
                $usageLimit,
                $usageLimitPerUser,
                $minBalance,
                $startDate,
                $endDate,
                $status,
                $description,
                $couponId
            ]);
            
            setAlert('Kupon başarıyla güncellendi.', 'success');
        }
    }
    
    header('Location: coupons.php?tab=coupons');
    exit;
}

// Kupon Silme
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_coupon') {
    $couponId = (int)$_POST['coupon_id'];
    
    // Önce kullanım kayıtlarını sil
    $db->prepare("DELETE FROM coupon_usages WHERE coupon_id = ?")->execute([$couponId]);
    
    // Sonra kuponu sil
    $db->prepare("DELETE FROM coupons WHERE id = ?")->execute([$couponId]);
    
    setAlert('Kupon başarıyla silindi.', 'success');
    header('Location: coupons.php?tab=coupons');
    exit;
}

// Kupon Durumu Değiştirme
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle_status') {
    $couponId = (int)$_POST['coupon_id'];
    $newStatus = $_POST['new_status'];
    
    $db->prepare("UPDATE coupons SET status = ? WHERE id = ?")->execute([$newStatus, $couponId]);
    
    setAlert('Kupon durumu güncellendi.', 'success');
    header('Location: coupons.php?tab=coupons');
    exit;
}

// ==================== VERİLERİ ÇEKME ====================

// Kuponları getir
$coupons = $db->query("
    SELECT c.*, 
           (SELECT COUNT(*) FROM coupon_usages WHERE coupon_id = c.id) as total_uses
    FROM coupons c
    ORDER BY c.created_at DESC
")->fetchAll();

// Kupon loglarını getir (sayfalama ile)
$logsPage = isset($_GET['logs_page']) ? max(1, (int)$_GET['logs_page']) : 1;
$logsPerPage = 20;
$logsOffset = ($logsPage - 1) * $logsPerPage;

$totalLogs = $db->query("SELECT COUNT(*) FROM coupon_usages")->fetchColumn();
$totalLogsPages = ceil($totalLogs / $logsPerPage);

$couponLogs = $db->prepare("
    SELECT cu.*, c.code as coupon_code, c.amount as coupon_amount, u.username, u.email
    FROM coupon_usages cu
    LEFT JOIN coupons c ON cu.coupon_id = c.id
    LEFT JOIN users u ON cu.user_id = u.id
    ORDER BY cu.used_at DESC
    LIMIT ? OFFSET ?
");
$couponLogs->execute([$logsPerPage, $logsOffset]);
$couponLogs = $couponLogs->fetchAll();

// Düzenleme için kupon bilgisi
$editCoupon = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $editStmt = $db->prepare("SELECT * FROM coupons WHERE id = ?");
    $editStmt->execute([(int)$_GET['edit']]);
    $editCoupon = $editStmt->fetch();
}

// Şimdi header'ı dahil et
$pageTitle = 'Kupon Ayarları';
require_once 'header.php';
?>

<style>
/* Tab Navigation */
.tab-navigation {
    display: flex;
    gap: 10px;
    margin-bottom: 25px;
    background: var(--card-bg-color);
    padding: 10px;
    border-radius: 14px;
    border: 1px solid var(--border-color);
    flex-wrap: wrap;
}

.tab-btn {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px 24px;
    background: transparent;
    border: none;
    border-radius: 10px;
    color: var(--text-color);
    font-size: 0.95rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    opacity: 0.7;
}

.tab-btn:hover {
    background: var(--background-color);
    opacity: 1;
}

.tab-btn.active {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--on-accent-color);
    opacity: 1;
}

.tab-btn i {
    font-size: 1rem;
}

.tab-btn .badge {
    background: rgba(255, 255, 255, 0.2);
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 0.75rem;
}

.tab-btn.active .badge {
    background: rgba(255, 255, 255, 0.3);
}

/* Stats Cards */
.coupon-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 25px;
}

.stat-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 14px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 15px;
}

.stat-card .icon {
    width: 50px;
    height: 50px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
}

.stat-card .icon.primary {
    background: var(--primary-alpha-015);
    color: var(--accent-text-color);
}

.stat-card .icon.success {
    background: rgba(40, 167, 69, 0.15);
    color: #28a745;
}

.stat-card .icon.warning {
    background: rgba(255, 193, 7, 0.15);
    color: #ffc107;
}

.stat-card .icon.info {
    background: rgba(23, 162, 184, 0.15);
    color: #17a2b8;
}

.stat-card .info h3 {
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 3px;
}

.stat-card .info p {
    font-size: 0.85rem;
    opacity: 0.7;
    margin: 0;
}

/* Coupon Form */
.coupon-form-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    margin-bottom: 25px;
}

.coupon-form-header {
    padding: 20px 25px;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 15px;
}

.coupon-form-header h3 {
    font-size: 1.1rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 0;
}

.coupon-form-header h3 i {
    color: var(--accent-text-color);
}

.coupon-form-body {
    padding: 25px;
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
}

.form-group {
    margin-bottom: 0;
}

.form-group.full-width {
    grid-column: 1 / -1;
}

.form-label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    font-size: 0.9rem;
}

.form-label .optional {
    font-weight: 400;
    opacity: 0.6;
    font-size: 0.8rem;
}

.form-control {
    width: 100%;
    padding: 12px 16px;
    border: 2px solid var(--border-color);
    border-radius: 10px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 0.95rem;
    transition: all 0.3s ease;
}

.form-control:focus {
    outline: none;
    border-color: var(--accent-text-color);
    box-shadow: 0 0 0 4px var(--primary-alpha-01);
}

.form-control.code-input {
    text-transform: uppercase;
    font-weight: 600;
    letter-spacing: 1px;
}

.form-hint {
    font-size: 0.8rem;
    opacity: 0.6;
    margin-top: 6px;
}

.form-actions {
    display: flex;
    gap: 10px;
    margin-top: 20px;
    flex-wrap: wrap;
}

/* Coupons Table */
.coupons-table-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    overflow: hidden;
}

.table-header {
    padding: 20px 25px;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 15px;
}

.table-header h3 {
    font-size: 1.1rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 0;
}

.table-header h3 i {
    color: var(--accent-text-color);
}

.table-responsive {
    overflow-x: auto;
}

.data-table {
    width: 100%;
    border-collapse: collapse;
    min-width: 900px;
}

.data-table th,
.data-table td {
    padding: 15px 20px;
    text-align: left;
    border-bottom: 1px solid var(--border-color);
}

.data-table th {
    background: var(--background-color);
    font-weight: 600;
    font-size: 0.85rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    opacity: 0.8;
}

.data-table tbody tr:hover {
    background: var(--background-color);
}

.data-table tbody tr:last-child td {
    border-bottom: none;
}

/* Coupon Code Badge */
.coupon-code {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 6px 12px;
    background: linear-gradient(135deg, rgba(255, 193, 7, 0.15), rgba(255, 152, 0, 0.1));
    border: 1px solid rgba(255, 193, 7, 0.3);
    border-radius: 8px;
    font-weight: 700;
    font-size: 0.9rem;
    color: #ffc107;
    letter-spacing: 1px;
}

.coupon-code i {
    font-size: 0.8rem;
}

/* Amount Badge */
.amount-badge {
    font-weight: 700;
    font-size: 1rem;
    color: var(--success-color);
}

/* Usage Info */
.usage-info {
    display: flex;
    flex-direction: column;
    gap: 3px;
}

.usage-info .current {
    font-weight: 600;
    font-size: 0.95rem;
}

.usage-info .limit {
    font-size: 0.8rem;
    opacity: 0.6;
}

/* Date Info */
.date-info {
    display: flex;
    flex-direction: column;
    gap: 3px;
    font-size: 0.85rem;
}

.date-info .label {
    opacity: 0.6;
    font-size: 0.75rem;
}

.date-info .expired {
    color: #dc3545;
}

.date-info .active {
    color: #28a745;
}

/* Status Badge */
.status-badge {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
}

.status-active {
    background: rgba(40, 167, 69, 0.15);
    color: #28a745;
}

.status-inactive {
    background: rgba(108, 117, 125, 0.15);
    color: var(--muted-text-color);
}

/* Action Buttons */
.action-buttons {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.btn-icon {
    width: 36px;
    height: 36px;
    border-radius: 8px;
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 0.9rem;
}

.btn-icon.edit {
    background: var(--primary-alpha-015);
    color: var(--accent-text-color);
}

.btn-icon.edit:hover {
    background: var(--primary-color);
    color: var(--on-primary-color);
}

.btn-icon.delete {
    background: rgba(220, 53, 69, 0.15);
    color: #dc3545;
}

.btn-icon.delete:hover {
    background: #dc3545;
    color: #fff;
}

.btn-icon.toggle {
    background: rgba(40, 167, 69, 0.15);
    color: #28a745;
}

.btn-icon.toggle:hover {
    background: #28a745;
    color: #fff;
}

.btn-icon.toggle.off {
    background: rgba(108, 117, 125, 0.15);
    color: var(--muted-text-color);
}

.btn-icon.toggle.off:hover {
    background: #6c757d;
    color: #fff;
}
/* Logs Table */
.logs-table {
    min-width: 800px;
}

.user-info {
    display: flex;
    align-items: center;
    gap: 12px;
}

.user-avatar {
    width: 38px;
    height: 38px;
    border-radius: 10px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--on-accent-color);
    font-weight: 600;
    font-size: 0.85rem;
}

.user-details h5 {
    font-size: 0.9rem;
    font-weight: 600;
    margin-bottom: 2px;
}

.user-details p {
    font-size: 0.8rem;
    opacity: 0.6;
    margin: 0;
}

.ip-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 5px 10px;
    background: var(--background-color);
    border-radius: 6px;
    font-size: 0.8rem;
    font-family: monospace;
}

.ip-badge i {
    opacity: 0.5;
}

.datetime-info {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.datetime-info .date {
    font-weight: 600;
    font-size: 0.9rem;
}

.datetime-info .time {
    font-size: 0.8rem;
    opacity: 0.6;
}

/* Pagination */
.pagination-wrapper {
    padding: 20px 25px;
    border-top: 1px solid var(--border-color);
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 15px;
}

.pagination-info {
    font-size: 0.9rem;
    opacity: 0.7;
}

.pagination {
    display: flex;
    gap: 5px;
    flex-wrap: wrap;
}

.pagination a,
.pagination span {
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 38px;
    height: 38px;
    padding: 0 12px;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 500;
    font-size: 0.9rem;
    transition: all 0.3s ease;
}

.pagination a {
    background: var(--background-color);
    color: var(--text-color);
    border: 1px solid var(--border-color);
}

.pagination a:hover {
    border-color: var(--accent-text-color);
    color: var(--accent-text-color);
}

.pagination span.current {
    background: var(--primary-color);
    color: var(--on-primary-color);
    border: 1px solid var(--primary-color);
}

.pagination span.dots {
    background: transparent;
    border: none;
    opacity: 0.5;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 60px 20px;
}

.empty-state .icon {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background: var(--background-color);
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    font-size: 2rem;
    opacity: 0.3;
}

.empty-state h4 {
    font-size: 1.1rem;
    font-weight: 600;
    margin-bottom: 8px;
    opacity: 0.8;
}

.empty-state p {
    font-size: 0.9rem;
    opacity: 0.6;
    margin: 0;
}

/* Delete Modal */
.modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    z-index: 10000;
    justify-content: center;
    align-items: center;
    padding: 20px;
}

.modal-overlay.active {
    display: flex;
}

.modal-content {
    background: var(--card-bg-color);
    border-radius: 16px;
    width: 100%;
    max-width: 450px;
    overflow: hidden;
    animation: modalSlide 0.3s ease;
}

@keyframes modalSlide {
    from {
        opacity: 0;
        transform: translateY(-20px) scale(0.95);
    }
    to {
        opacity: 1;
        transform: translateY(0) scale(1);
    }
}

.modal-header {
    padding: 20px 25px;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.modal-header h3 {
    font-size: 1.1rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 0;
}

.modal-header h3 i {
    color: #dc3545;
}

.modal-close {
    width: 36px;
    height: 36px;
    border-radius: 8px;
    border: none;
    background: var(--background-color);
    color: var(--text-color);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
}

.modal-close:hover {
    background: #dc3545;
    color: #fff;
}

.modal-body {
    padding: 25px;
}

.modal-body p {
    font-size: 0.95rem;
    margin-bottom: 15px;
    line-height: 1.6;
}

.modal-body .warning {
    background: rgba(220, 53, 69, 0.1);
    border: 1px solid rgba(220, 53, 69, 0.2);
    border-radius: 10px;
    padding: 12px 15px;
    font-size: 0.85rem;
    color: #dc3545;
    display: flex;
    align-items: center;
    gap: 10px;
}

.modal-footer {
    padding: 20px 25px;
    border-top: 1px solid var(--border-color);
    display: flex;
    justify-content: flex-end;
    gap: 10px;
}

/* Generate Code Button */
.generate-code-btn {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    padding: 6px 12px;
    background: var(--primary-color);
    border: none;
    border-radius: 6px;
    color: var(--on-primary-color);
    font-size: 0.75rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}

.generate-code-btn:hover {
    background: var(--secondary-color);
}

.input-with-button {
    position: relative;
}

.input-with-button .form-control {
    padding-right: 100px;
}

/* Responsive */
@media (max-width: 768px) {
    .tab-navigation {
        flex-direction: column;
    }
    
    .tab-btn {
        justify-content: center;
    }
    
    .coupon-stats {
        grid-template-columns: 1fr 1fr;
    }
    
    .form-grid {
        grid-template-columns: 1fr;
    }
    
    .form-actions {
        flex-direction: column;
    }
    
    .form-actions .btn {
        width: 100%;
        justify-content: center;
    }
    
    .table-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .pagination-wrapper {
        flex-direction: column;
        text-align: center;
    }
    
    .action-buttons {
        flex-direction: column;
    }
    
    .btn-icon {
        width: 100%;
    }
}

@media (max-width: 576px) {
    .coupon-stats {
        grid-template-columns: 1fr;
    }
    
    .stat-card {
        flex-direction: column;
        text-align: center;
    }
    
    .modal-footer {
        flex-direction: column;
    }
    
    .modal-footer .btn {
        width: 100%;
        justify-content: center;
    }
}
</style>

<!-- Tab Navigation -->
<div class="tab-navigation">
    <a href="?tab=coupons" class="tab-btn <?php echo $activeTab === 'coupons' ? 'active' : ''; ?>">
        <i class="fas fa-ticket-alt"></i>
        <span>Kupon Ayarları</span>
        <span class="badge"><?php echo count($coupons); ?></span>
    </a>
    <a href="?tab=logs" class="tab-btn <?php echo $activeTab === 'logs' ? 'active' : ''; ?>">
        <i class="fas fa-history"></i>
        <span>Kupon Logları</span>
        <span class="badge"><?php echo $totalLogs; ?></span>
    </a>
</div>

<?php if ($activeTab === 'coupons'): ?>

<!-- Stats Cards -->
<div class="coupon-stats">
    <div class="stat-card">
        <div class="icon primary">
            <i class="fas fa-ticket-alt"></i>
        </div>
        <div class="info">
            <h3><?php echo count($coupons); ?></h3>
            <p>Toplam Kupon</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="icon success">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="info">
            <h3><?php echo count(array_filter($coupons, fn($c) => $c['status'] === 'active')); ?></h3>
            <p>Aktif Kupon</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="icon warning">
            <i class="fas fa-users"></i>
        </div>
        <div class="info">
            <h3><?php echo $totalLogs; ?></h3>
            <p>Toplam Kullanım</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="icon info">
            <i class="fas fa-coins"></i>
        </div>
        <div class="info">
            <?php 
            $totalDistributedCoupons = $db->query("SELECT COALESCE(SUM(amount), 0) FROM coupon_usages")->fetchColumn();
            ?>
            <h3><?php echo $siteSettings['currency_symbol'] . number_format($totalDistributedCoupons, 2); ?></h3>
            <p>Dağıtılan Bakiye</p>
        </div>
    </div>
</div>

<!-- Coupon Form -->
<div class="coupon-form-card">
    <div class="coupon-form-header">
        <h3>
            <i class="fas <?php echo $editCoupon ? 'fa-edit' : 'fa-plus-circle'; ?>"></i>
            <?php echo $editCoupon ? 'Kupon Düzenle' : 'Yeni Kupon Ekle'; ?>
        </h3>
        <?php if ($editCoupon): ?>
            <a href="?tab=coupons" class="btn btn-secondary btn-sm">
                <i class="fas fa-times"></i> İptal
            </a>
        <?php endif; ?>
    </div>
    <div class="coupon-form-body">
        <form method="POST">
            <input type="hidden" name="action" value="<?php echo $editCoupon ? 'edit_coupon' : 'add_coupon'; ?>">
            <?php if ($editCoupon): ?>
                <input type="hidden" name="coupon_id" value="<?php echo $editCoupon['id']; ?>">
            <?php endif; ?>
            
            <div class="form-grid">
                <div class="form-group">
                    <label class="form-label">Kupon Kodu</label>
                    <div class="input-with-button">
                        <input type="text" name="code" class="form-control code-input" 
                               value="<?php echo $editCoupon ? clean($editCoupon['code']) : ''; ?>" 
                               placeholder="Örn: HOSGELDIN" required>
                        <button type="button" class="generate-code-btn" onclick="generateCode()">Oluştur</button>
                    </div>
                    <p class="form-hint">Büyük/küçük harf duyarsız</p>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Kupon Tutarı (<?php echo $siteSettings['currency_symbol']; ?>)</label>
                    <input type="number" name="amount" class="form-control" step="0.01" min="0.01"
                           value="<?php echo $editCoupon ? $editCoupon['amount'] : ''; ?>" 
                           placeholder="Örn: 10.00" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Toplam Kullanım Limiti <span class="optional">(Opsiyonel)</span></label>
                    <input type="number" name="usage_limit" class="form-control" min="1"
                           value="<?php echo $editCoupon && $editCoupon['usage_limit'] ? $editCoupon['usage_limit'] : ''; ?>" 
                           placeholder="Boş = Sınırsız">
                    <p class="form-hint">Kuponun toplamda kaç kez kullanılabileceği</p>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Kişi Başı Limit <span class="optional">(Opsiyonel)</span></label>
                    <input type="number" name="usage_limit_per_user" class="form-control" min="1"
                           value="<?php echo $editCoupon && $editCoupon['usage_limit_per_user'] ? $editCoupon['usage_limit_per_user'] : ''; ?>" 
                           placeholder="Boş = Sınırsız">
                    <p class="form-hint">Her kullanıcının kaç kez kullanabileceği</p>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Minimum Bakiye Şartı <span class="optional">(Opsiyonel)</span></label>
                    <input type="number" name="min_balance" class="form-control" step="0.01" min="0"
                           value="<?php echo $editCoupon && $editCoupon['min_balance'] ? $editCoupon['min_balance'] : ''; ?>" 
                           placeholder="Boş = Şart yok">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Durum</label>
                    <select name="status" class="form-control">
                        <option value="active" <?php echo ($editCoupon && $editCoupon['status'] === 'active') || !$editCoupon ? 'selected' : ''; ?>>Aktif</option>
                        <option value="inactive" <?php echo $editCoupon && $editCoupon['status'] === 'inactive' ? 'selected' : ''; ?>>Pasif</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Başlangıç Tarihi <span class="optional">(Opsiyonel)</span></label>
                    <input type="datetime-local" name="start_date" class="form-control"
                           value="<?php echo $editCoupon && $editCoupon['start_date'] ? date('Y-m-d\TH:i', strtotime($editCoupon['start_date'])) : ''; ?>">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Bitiş Tarihi <span class="optional">(Opsiyonel)</span></label>
                    <input type="datetime-local" name="end_date" class="form-control"
                           value="<?php echo $editCoupon && $editCoupon['end_date'] ? date('Y-m-d\TH:i', strtotime($editCoupon['end_date'])) : ''; ?>">
                </div>
                
                <div class="form-group full-width">
                    <label class="form-label">Açıklama / Not <span class="optional">(Opsiyonel)</span></label>
                    <textarea name="description" class="form-control" rows="2" placeholder="Kupon hakkında not..."><?php echo $editCoupon ? clean($editCoupon['description']) : ''; ?></textarea>
                </div>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <i class="fas <?php echo $editCoupon ? 'fa-save' : 'fa-plus'; ?>"></i>
                    <?php echo $editCoupon ? 'Güncelle' : 'Kupon Ekle'; ?>
                </button>
                <?php if ($editCoupon): ?>
                    <a href="?tab=coupons" class="btn btn-secondary">
                        <i class="fas fa-times"></i> İptal
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<!-- Coupons Table -->
<div class="coupons-table-card">
    <div class="table-header">
        <h3>
            <i class="fas fa-list"></i>
            Kupon Listesi
        </h3>
    </div>
    
    <?php if (empty($coupons)): ?>
        <div class="empty-state">
            <div class="icon">
                <i class="fas fa-ticket-alt"></i>
            </div>
            <h4>Henüz kupon eklenmemiş</h4>
            <p>Yukarıdaki formu kullanarak yeni kupon ekleyebilirsiniz.</p>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Kupon Kodu</th>
                        <th>Tutar</th>
                        <th>Kullanım</th>
                        <th>Kişi Başı</th>
                        <th>Tarih Aralığı</th>
                        <th>Durum</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($coupons as $coupon): 
                        $now = time();
                        $isExpired = $coupon['end_date'] && strtotime($coupon['end_date']) < $now;
                        $notStarted = $coupon['start_date'] && strtotime($coupon['start_date']) > $now;
                    ?>
                        <tr>
                            <td>
                                <span class="coupon-code">
                                    <i class="fas fa-ticket-alt"></i>
                                    <?php echo clean($coupon['code']); ?>
                                </span>
                            </td>
                            <td>
                                <span class="amount-badge">
                                    <?php echo $siteSettings['currency_symbol'] . number_format($coupon['amount'], 2); ?>
                                </span>
                            </td>
                            <td>
                                <div class="usage-info">
                                    <span class="current"><?php echo $coupon['used_count']; ?> kullanım</span>
                                    <span class="limit">
                                        <?php echo $coupon['usage_limit'] ? 'Limit: ' . $coupon['usage_limit'] : 'Sınırsız'; ?>
                                    </span>
                                </div>
                            </td>
                            <td>
                                <?php echo $coupon['usage_limit_per_user'] ? $coupon['usage_limit_per_user'] . ' kez' : 'Sınırsız'; ?>
                            </td>
                            <td>
                                <div class="date-info">
                                    <?php if ($coupon['start_date'] || $coupon['end_date']): ?>
                                        <?php if ($coupon['start_date']): ?>
                                            <span class="<?php echo $notStarted ? '' : 'active'; ?>">
                                                <span class="label">Başlangıç:</span>
                                                <?php echo date('d.m.Y H:i', strtotime($coupon['start_date'])); ?>
                                            </span>
                                        <?php endif; ?>
                                        <?php if ($coupon['end_date']): ?>
                                            <span class="<?php echo $isExpired ? 'expired' : 'active'; ?>">
                                                <span class="label">Bitiş:</span>
                                                <?php echo date('d.m.Y H:i', strtotime($coupon['end_date'])); ?>
                                            </span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span style="opacity:0.5">Süresiz</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <?php if ($isExpired): ?>
                                    <span class="status-badge status-cancelled">Süresi Doldu</span>
                                <?php elseif ($notStarted): ?>
                                    <span class="status-badge status-pending">Beklemede</span>
                                <?php else: ?>
                                    <span class="status-badge status-<?php echo $coupon['status']; ?>">
                                        <?php echo $coupon['status'] === 'active' ? 'Aktif' : 'Pasif'; ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <a href="?tab=coupons&edit=<?php echo $coupon['id']; ?>" class="btn-icon edit" title="Düzenle">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="action" value="toggle_status">
                                        <input type="hidden" name="coupon_id" value="<?php echo $coupon['id']; ?>">
                                        <input type="hidden" name="new_status" value="<?php echo $coupon['status'] === 'active' ? 'inactive' : 'active'; ?>">
                                        <button type="submit" class="btn-icon toggle <?php echo $coupon['status'] === 'inactive' ? 'off' : ''; ?>" title="<?php echo $coupon['status'] === 'active' ? 'Pasife Al' : 'Aktif Et'; ?>">
                                            <i class="fas fa-<?php echo $coupon['status'] === 'active' ? 'toggle-on' : 'toggle-off'; ?>"></i>
                                        </button>
                                    </form>
                                    <button type="button" class="btn-icon delete" title="Sil" onclick="openDeleteModal(<?php echo $coupon['id']; ?>, '<?php echo clean($coupon['code']); ?>')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
<?php else: ?>

<!-- Logs Section -->
<div class="coupon-stats">
    <div class="stat-card">
        <div class="icon primary">
            <i class="fas fa-history"></i>
        </div>
        <div class="info">
            <h3><?php echo $totalLogs; ?></h3>
            <p>Toplam Kullanım</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="icon success">
            <i class="fas fa-coins"></i>
        </div>
        <div class="info">
            <?php 
            $totalDistributed = $db->query("SELECT COALESCE(SUM(amount), 0) FROM coupon_usages")->fetchColumn();
            ?>
            <h3><?php echo $siteSettings['currency_symbol'] . number_format($totalDistributed, 2); ?></h3>
            <p>Dağıtılan Toplam</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="icon warning">
            <i class="fas fa-calendar-day"></i>
        </div>
        <div class="info">
            <?php 
            $todayUsages = $db->query("SELECT COUNT(*) FROM coupon_usages WHERE DATE(used_at) = CURDATE()")->fetchColumn();
            ?>
            <h3><?php echo $todayUsages; ?></h3>
            <p>Bugünkü Kullanım</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="icon info">
            <i class="fas fa-users"></i>
        </div>
        <div class="info">
            <?php 
            $uniqueUsers = $db->query("SELECT COUNT(DISTINCT user_id) FROM coupon_usages")->fetchColumn();
            ?>
            <h3><?php echo $uniqueUsers; ?></h3>
            <p>Farklı Kullanıcı</p>
        </div>
    </div>
</div>

<!-- Logs Table -->
<div class="coupons-table-card">
    <div class="table-header">
        <h3>
            <i class="fas fa-history"></i>
            Kupon Kullanım Geçmişi
        </h3>
        <span style="opacity:0.6; font-size:0.9rem;">
            Toplam <?php echo $totalLogs; ?> kayıt
        </span>
    </div>
    
    <?php if (empty($couponLogs)): ?>
        <div class="empty-state">
            <div class="icon">
                <i class="fas fa-history"></i>
            </div>
            <h4>Henüz kupon kullanımı yok</h4>
            <p>Kullanıcılar kupon kullandığında burada görüntülenecek.</p>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="data-table logs-table">
                <thead>
                    <tr>
                        <th>Kullanıcı</th>
                        <th>Kupon Kodu</th>
                        <th>Eklenen Bakiye</th>
                        <th>IP Adresi</th>
                        <th>Tarih / Saat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($couponLogs as $log): ?>
                        <tr>
                            <td>
                                <div class="user-info">
                                    <div class="user-avatar">
                                        <?php echo strtoupper(mb_substr($log['username'] ?? '?', 0, 1, 'UTF-8')); ?>
                                    </div>
                                    <div class="user-details">
                                        <h5><?php echo clean($log['username'] ?? 'Silinmiş Kullanıcı'); ?></h5>
                                        <p><?php echo clean($log['email'] ?? '-'); ?></p>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="coupon-code">
                                    <i class="fas fa-ticket-alt"></i>
                                    <?php echo clean($log['coupon_code'] ?? 'Silinmiş Kupon'); ?>
                                </span>
                            </td>
                            <td>
                                <span class="amount-badge">
                                    +<?php echo $siteSettings['currency_symbol'] . number_format($log['amount'], 2); ?>
                                </span>
                            </td>
                            <td>
                                <span class="ip-badge">
                                    <i class="fas fa-globe"></i>
                                    <?php echo clean($log['ip_address'] ?? '-'); ?>
                                </span>
                            </td>
                            <td>
                                <div class="datetime-info">
                                    <span class="date"><?php echo date('d.m.Y', strtotime($log['used_at'])); ?></span>
                                    <span class="time"><?php echo date('H:i:s', strtotime($log['used_at'])); ?></span>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <?php if ($totalLogsPages > 1): ?>
            <div class="pagination-wrapper">
                <div class="pagination-info">
                    Sayfa <?php echo $logsPage; ?> / <?php echo $totalLogsPages; ?>
                </div>
                <div class="pagination">
                    <?php if ($logsPage > 1): ?>
                        <a href="?tab=logs&logs_page=1"><i class="fas fa-angle-double-left"></i></a>
                        <a href="?tab=logs&logs_page=<?php echo $logsPage - 1; ?>"><i class="fas fa-angle-left"></i></a>
                    <?php endif; ?>
                    
                    <?php
                    $startPage = max(1, $logsPage - 2);
                    $endPage = min($totalLogsPages, $logsPage + 2);
                    
                    if ($startPage > 1): ?>
                        <a href="?tab=logs&logs_page=1">1</a>
                        <?php if ($startPage > 2): ?>
                            <span class="dots">...</span>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    <?php for ($i = $startPage; $i <= $endPage; $i++): ?>
                        <?php if ($i == $logsPage): ?>
                            <span class="current"><?php echo $i; ?></span>
                        <?php else: ?>
                            <a href="?tab=logs&logs_page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($endPage < $totalLogsPages): ?>
                        <?php if ($endPage < $totalLogsPages - 1): ?>
                            <span class="dots">...</span>
                        <?php endif; ?>
                        <a href="?tab=logs&logs_page=<?php echo $totalLogsPages; ?>"><?php echo $totalLogsPages; ?></a>
                    <?php endif; ?>
                    
                    <?php if ($logsPage < $totalLogsPages): ?>
                        <a href="?tab=logs&logs_page=<?php echo $logsPage + 1; ?>"><i class="fas fa-angle-right"></i></a>
                        <a href="?tab=logs&logs_page=<?php echo $totalLogsPages; ?>"><i class="fas fa-angle-double-right"></i></a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php endif; ?>

<!-- Delete Modal -->
<div class="modal-overlay" id="deleteModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-exclamation-triangle"></i> Kuponu Sil</h3>
            <button type="button" class="modal-close" onclick="closeDeleteModal()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="modal-body">
            <p><strong id="deleteCouponCode"></strong> kodlu kuponu silmek istediğinize emin misiniz?</p>
            <div class="warning">
                <i class="fas fa-exclamation-circle"></i>
                <span>Bu işlem geri alınamaz ve kuponun tüm kullanım geçmişi de silinecektir.</span>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeDeleteModal()">
                <i class="fas fa-times"></i> İptal
            </button>
            <form method="POST" id="deleteForm" style="display:inline;">
                <input type="hidden" name="action" value="delete_coupon">
                <input type="hidden" name="coupon_id" id="deleteCouponId" value="">
                <button type="submit" class="btn btn-danger">
                    <i class="fas fa-trash"></i> Sil
                </button>
            </form>
        </div>
    </div>
</div>

<script>
// Rastgele kupon kodu oluştur
function generateCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = '';
    for (let i = 0; i < 8; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    document.querySelector('input[name="code"]').value = code;
}

// Silme modalını aç
function openDeleteModal(couponId, couponCode) {
    document.getElementById('deleteCouponId').value = couponId;
    document.getElementById('deleteCouponCode').textContent = couponCode;
    document.getElementById('deleteModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

// Silme modalını kapat
function closeDeleteModal() {
    document.getElementById('deleteModal').classList.remove('active');
    document.body.style.overflow = '';
}

// Modal dışına tıklanınca kapat
document.getElementById('deleteModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeDeleteModal();
    }
});

// ESC tuşu ile kapat
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && document.getElementById('deleteModal').classList.contains('active')) {
        closeDeleteModal();
    }
});
</script>

<?php require_once 'footer.php'; ?>