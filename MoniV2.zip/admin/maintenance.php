<?php
/**
 * Admin Panel - Bakım Modu Ayarları
 */

require_once __DIR__ . '/../config.php';

// Admin kontrolü
if (!isLoggedIn() || !isAdmin()) {
    header('Location: /login.php');
    exit;
}

// Form gönderildi mi?
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Bakım modunu aç/kapat
    if (isset($_POST['toggle_maintenance'])) {
        $currentStatus = getSetting('maintenance_mode', '0');
        $newStatus = $currentStatus === '1' ? '0' : '1';
        
        updateSetting('maintenance_mode', $newStatus);
        
        if ($newStatus === '1') {
            setAlert('Bakım modu aktif edildi. Site ziyaretçileri bakım sayfasını görecek.', 'success');
        } else {
            setAlert('Bakım modu kapatıldı. Site normal şekilde erişilebilir.', 'success');
        }
        
        header('Location: maintenance.php');
        exit;
    }
    
    // Kısmi bakım modüllerini kaydet
    if (isset($_POST['save_partial_maintenance'])) {
        $mods=function_exists('moni_partial_maintenance_modules')?moni_partial_maintenance_modules():[];
        foreach($mods as $key=>$meta){
            updateSetting($meta['setting'],!empty($_POST['partial'][$key])?'1':'0');
            $msg=trim((string)($_POST['partial_message'][$key]??''));
            updateSetting('partial_maintenance_'.$key.'_message',mb_substr($msg,0,500,'UTF-8'));
        }
        if(function_exists('moni_audit_log'))moni_audit_log($db,'maintenance.partial.update','settings','partial_maintenance',['states'=>array_map(static fn($m)=>!empty($_POST['partial'][$m])?1:0,array_keys($mods))]);
        setAlert('Kısmi bakım modülleri güncellendi.','success');
        header('Location: maintenance.php#partial-maintenance');exit;
    }

    // Ayarları kaydet
    if (isset($_POST['save_settings'])) {
        $message = trim($_POST['maintenance_message'] ?? '');
        $endTime = trim($_POST['maintenance_end_time'] ?? '');
        $allowedIps = trim($_POST['maintenance_allowed_ips'] ?? '');
        
        updateSetting('maintenance_message', $message);
        updateSetting('maintenance_end_time', $endTime);
        updateSetting('maintenance_allowed_ips', $allowedIps);
        
        setAlert('Bakım modu ayarları kaydedildi.', 'success');
        
        header('Location: maintenance.php');
        exit;
    }
}

// Sayfa başlığı ve header
$pageTitle = 'Bakım Modu';
require_once 'header.php';

// Mevcut ayarları al
$maintenanceMode = getSetting('maintenance_mode', '0');
$maintenanceMessage = getSetting('maintenance_message', 'Sitemiz şu anda bakım çalışması nedeniyle geçici olarak kapalıdır. Kısa süre içinde tekrar hizmetinizdeyiz.');
$maintenanceEndTime = getSetting('maintenance_end_time', '');
$maintenanceAllowedIps = getSetting('maintenance_allowed_ips', '');
$partialMaintenance = function_exists('moni_partial_maintenance_status') ? moni_partial_maintenance_status($db) : [];
$partialActiveCount = count(array_filter($partialMaintenance, static fn($m)=>!empty($m['active'])));

// Kullanıcının IP adresi
$userIp = $_SERVER['REMOTE_ADDR'] ?? '';
?>

<style>
/* Status Card */
.status-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 20px;
    padding: 30px;
    margin-bottom: 25px;
    position: relative;
    overflow: hidden;
}

.status-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
}

.status-card.active::before {
    background: linear-gradient(90deg, #f39c12, #e67e22);
}

.status-card.inactive::before {
    background: linear-gradient(90deg, #28a745, #20c997);
}

.status-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 20px;
    margin-bottom: 25px;
}

.status-info {
    display: flex;
    align-items: center;
    gap: 20px;
}

.status-icon {
    width: 70px;
    height: 70px;
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.8rem;
}

.status-card.active .status-icon {
    background: rgba(243, 156, 18, 0.15);
    color: #f39c12;
}

.status-card.inactive .status-icon {
    background: rgba(40, 167, 69, 0.15);
    color: #28a745;
}

.status-text h2 {
    font-size: 1.4rem;
    font-weight: 700;
    margin-bottom: 5px;
}

.status-text p {
    font-size: 0.9rem;
    opacity: 0.7;
}

.status-badge {
    padding: 10px 25px;
    border-radius: 30px;
    font-size: 0.9rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.status-card.active .status-badge {
    background: rgba(243, 156, 18, 0.15);
    color: #f39c12;
    border: 2px solid rgba(243, 156, 18, 0.3);
}

.status-card.inactive .status-badge {
    background: rgba(40, 167, 69, 0.15);
    color: #28a745;
    border: 2px solid rgba(40, 167, 69, 0.3);
}

.toggle-btn {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 15px 30px;
    border: none;
    border-radius: 12px;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}

.toggle-btn.activate {
    background: linear-gradient(135deg, #f39c12, #e67e22);
    color: #fff;
}

.toggle-btn.activate:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(243, 156, 18, 0.3);
}

.toggle-btn.deactivate {
    background: linear-gradient(135deg, #28a745, #20c997);
    color: #fff;
}

.toggle-btn.deactivate:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(40, 167, 69, 0.3);
}

/* Info Boxes */
.info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 15px;
    margin-top: 20px;
}

.info-box {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 15px 20px;
    background: var(--background-color);
    border-radius: 12px;
}

.info-box i {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 10px;
    font-size: 1rem;
}

.info-box.ip i {
    background: var(--primary-alpha-015);
    color: var(--accent-text-color);
}

.info-box.time i {
    background: rgba(23, 162, 184, 0.15);
    color: #17a2b8;
}

.info-box.users i {
    background: rgba(40, 167, 69, 0.15);
    color: #28a745;
}

.info-box-content h4 {
    font-size: 0.8rem;
    opacity: 0.6;
    margin-bottom: 3px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.info-box-content p {
    font-size: 0.95rem;
    font-weight: 600;
}

/* Settings Card */
.settings-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 20px;
    overflow: hidden;
}

.settings-header {
    padding: 20px 25px;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    align-items: center;
    gap: 12px;
}

.settings-header i {
    color: var(--accent-text-color);
    font-size: 1.1rem;
}

.settings-header h3 {
    font-size: 1.1rem;
    font-weight: 600;
}

.settings-body {
    padding: 25px;
}

/* Form Styles */
.form-group {
    margin-bottom: 25px;
}

.form-group:last-child {
    margin-bottom: 0;
}

.form-label {
    display: block;
    margin-bottom: 10px;
    font-weight: 600;
    font-size: 0.95rem;
}

.form-label .required {
    color: #dc3545;
    margin-left: 3px;
}

.form-hint {
    display: block;
    margin-top: 8px;
    font-size: 0.8rem;
    opacity: 0.6;
    line-height: 1.5;
}

.form-control {
    width: 100%;
    padding: 14px 18px;
    border: 2px solid var(--border-color);
    border-radius: 12px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 0.95rem;
    transition: all 0.3s ease;
}

.form-control:focus {
    outline: none;
    border-color: var(--accent-text-color);
    box-shadow: 0 0 0 4px var(--primary-alpha-01);
}

textarea.form-control {
    min-height: 120px;
    resize: vertical;
    font-family: inherit;
}

/* IP Input Group */
.ip-input-group {
    position: relative;
}

.ip-input-group .form-control {
    padding-right: 140px;
}

.add-my-ip-btn {
    position: absolute;
    right: 8px;
    top: 50%;
    transform: translateY(-50%);
    padding: 8px 15px;
    background: var(--primary-color);
    color: var(--on-primary-color);
    border: none;
    border-radius: 8px;
    font-size: 0.8rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}

.add-my-ip-btn:hover {
    background: var(--secondary-color);
}

/* Save Button */
.save-btn {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 14px 30px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--on-accent-color);
    border: none;
    border-radius: 12px;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}

.save-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px var(--primary-alpha-03);
}

/* Warning Box */
.warning-box {
    display: flex;
    align-items: flex-start;
    gap: 15px;
    padding: 20px;
    background: rgba(243, 156, 18, 0.1);
    border: 1px solid rgba(243, 156, 18, 0.3);
    border-radius: 12px;
    margin-bottom: 25px;
}

.warning-box i {
    color: #f39c12;
    font-size: 1.3rem;
    margin-top: 2px;
}

.warning-box-content h4 {
    font-size: 0.95rem;
    font-weight: 600;
    margin-bottom: 5px;
    color: #f39c12;
}

.warning-box-content p {
    font-size: 0.85rem;
    opacity: 0.85;
    line-height: 1.6;
}

/* Preview Card */
.preview-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 20px;
    overflow: hidden;
    margin-top: 25px;
}

.preview-header {
    padding: 20px 25px;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.preview-header-left {
    display: flex;
    align-items: center;
    gap: 12px;
}

.preview-header i {
    color: var(--accent-text-color);
    font-size: 1.1rem;
}

.preview-header h3 {
    font-size: 1.1rem;
    font-weight: 600;
}

.preview-link {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 15px;
    background: var(--background-color);
    border: 1px solid var(--border-color);
    border-radius: 8px;
    color: var(--text-color);
    text-decoration: none;
    font-size: 0.85rem;
    font-weight: 500;
    transition: all 0.3s ease;
}

.preview-link:hover {
    border-color: var(--accent-text-color);
    color: var(--accent-text-color);
}

.preview-body {
    padding: 25px;
}

.preview-frame {
    background: var(--background-color);
    border: 1px solid var(--border-color);
    border-radius: 12px;
    overflow: hidden;
}

.preview-browser-bar {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 15px;
    background: var(--card-bg-color);
    border-bottom: 1px solid var(--border-color);
}

.browser-dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
}

.browser-dot.red { background: #ff5f56; }
.browser-dot.yellow { background: #ffbd2e; }
.browser-dot.green { background: #27ca40; }

.browser-url {
    flex: 1;
    margin-left: 10px;
    padding: 5px 12px;
    background: var(--background-color);
    border-radius: 5px;
    font-size: 0.75rem;
    opacity: 0.6;
}

.preview-content {
    padding: 30px;
    text-align: center;
    min-height: 200px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.preview-icon {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 15px;
}

.preview-icon i {
    font-size: 1.5rem;
    color: #fff;
}

.preview-title {
    font-size: 1.2rem;
    font-weight: 700;
    margin-bottom: 10px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.preview-message {
    font-size: 0.9rem;
    opacity: 0.7;
    max-width: 400px;
    line-height: 1.6;
}

/* Responsive */
@media (max-width: 768px) {
    .status-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .status-info {
        flex-direction: column;
        align-items: flex-start;
        text-align: left;
    }
    
    .info-grid {
        grid-template-columns: 1fr;
    }
    
    .ip-input-group .form-control {
        padding-right: 18px;
    }
    
    .add-my-ip-btn {
        position: static;
        transform: none;
        width: 100%;
        margin-top: 10px;
        padding: 12px;
    }
    
    .preview-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 15px;
    }
    
    .preview-link {
        width: 100%;
        justify-content: center;
    }
}

@media (max-width: 480px) {
    .status-card {
        padding: 20px;
    }
    
    .status-icon {
        width: 55px;
        height: 55px;
        font-size: 1.4rem;
    }
    
    .status-text h2 {
        font-size: 1.2rem;
    }
    
    .toggle-btn {
        width: 100%;
        justify-content: center;
        padding: 14px 20px;
    }
    
    .settings-body {
        padding: 20px;
    }
    
    .save-btn {
        width: 100%;
        justify-content: center;
    }
}

/* Partial maintenance */
.partial-maint-card{background:var(--card-bg-color);border:1px solid var(--border-color);border-radius:20px;margin-bottom:25px;overflow:hidden}.partial-maint-head{padding:22px 24px;border-bottom:1px solid var(--border-color);display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap}.partial-maint-head h3{margin:0 0 5px;font-size:1.15rem}.partial-maint-head p{margin:0;color:var(--muted-text-color);font-size:.88rem}.partial-summary{display:inline-flex;align-items:center;gap:8px;padding:8px 12px;border-radius:999px;background:var(--background-color);font-weight:700;font-size:.78rem}.partial-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;padding:20px}.partial-module{border:1px solid var(--border-color);border-radius:16px;padding:17px;background:var(--background-color);transition:.2s}.partial-module.on{border-color:rgba(245,158,11,.45);box-shadow:inset 0 0 0 1px rgba(245,158,11,.08)}.partial-module-top{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:13px}.partial-module-id{display:flex;gap:11px;align-items:center}.partial-module-icon{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;background:var(--primary-alpha-012);color:var(--primary-color)}.partial-module h4{margin:0 0 3px;font-size:.94rem}.partial-module small{color:var(--muted-text-color);line-height:1.4}.partial-switch{position:relative;width:48px;height:26px;flex:0 0 auto}.partial-switch input{opacity:0;width:0;height:0}.partial-slider{position:absolute;inset:0;border-radius:999px;background:var(--border-color);cursor:pointer;transition:.2s}.partial-slider:before{content:'';position:absolute;width:20px;height:20px;left:3px;top:3px;border-radius:50%;background:#fff;transition:.2s;box-shadow:0 2px 6px rgba(0,0,0,.2)}.partial-switch input:checked+.partial-slider{background:#f59e0b}.partial-switch input:checked+.partial-slider:before{transform:translateX(22px)}.partial-msg{width:100%;min-height:72px;resize:vertical;border:1px solid var(--border-color);border-radius:10px;background:var(--card-bg-color);color:var(--text-color);padding:10px;font:inherit;font-size:.82rem}.partial-footer{padding:0 20px 20px;display:flex;justify-content:flex-end}.partial-note{margin:0 20px 18px;padding:12px 14px;border:1px solid var(--border-color);border-radius:12px;color:var(--muted-text-color);font-size:.82rem;line-height:1.55;background:var(--background-color)}@media(max-width:760px){.partial-grid{grid-template-columns:1fr;padding:14px}.partial-maint-head{padding:18px}.partial-footer{padding:0 14px 14px}.partial-note{margin:0 14px 14px}}

</style>

<!-- Status Card -->
<div class="status-card <?php echo $maintenanceMode === '1' ? 'active' : 'inactive'; ?>">
    <div class="status-header">
        <div class="status-info">
            <div class="status-icon">
                <i class="fas <?php echo $maintenanceMode === '1' ? 'fa-tools' : 'fa-check-circle'; ?>"></i>
            </div>
            <div class="status-text">
                <h2><?php echo $maintenanceMode === '1' ? 'Bakım Modu Aktif' : 'Site Aktif'; ?></h2>
                <p><?php echo $maintenanceMode === '1' ? 'Ziyaretçiler bakım sayfasını görüyor' : 'Site normal şekilde çalışıyor'; ?></p>
            </div>
        </div>
        <span class="status-badge"><?php echo $maintenanceMode === '1' ? 'Aktif' : 'Kapalı'; ?></span>
    </div>
    
    <form method="POST" style="display: inline;">
        <button type="submit" name="toggle_maintenance" class="toggle-btn <?php echo $maintenanceMode === '1' ? 'deactivate' : 'activate'; ?>">
            <i class="fas <?php echo $maintenanceMode === '1' ? 'fa-power-off' : 'fa-tools'; ?>"></i>
            <?php echo $maintenanceMode === '1' ? 'Bakım Modunu Kapat' : 'Bakım Modunu Aç'; ?>
        </button>
    </form>
    
    <div class="info-grid">
        <div class="info-box ip">
            <i class="fas fa-globe"></i>
            <div class="info-box-content">
                <h4>IP Adresiniz</h4>
                <p><?php echo clean($userIp); ?></p>
            </div>
        </div>
        <div class="info-box time">
            <i class="fas fa-clock"></i>
            <div class="info-box-content">
                <h4>Tahmini Bitiş</h4>
                <p><?php echo !empty($maintenanceEndTime) ? date('d.m.Y H:i', strtotime($maintenanceEndTime)) : 'Belirlenmedi'; ?></p>
            </div>
        </div>
        <div class="info-box users">
            <i class="fas fa-user-shield"></i>
            <div class="info-box-content">
                <h4>İzinli IP Sayısı</h4>
                <p><?php echo !empty($maintenanceAllowedIps) ? count(array_filter(explode(',', $maintenanceAllowedIps))) : '0'; ?> IP</p>
            </div>
        </div>
    </div>
</div>

<!-- Warning Box -->
<?php if ($maintenanceMode === '1'): ?>
<div class="warning-box">
    <i class="fas fa-exclamation-triangle"></i>
    <div class="warning-box-content">
        <h4>Bakım Modu Aktif!</h4>
        <p>Site şu anda bakım modunda. Ziyaretçiler siteye erişemez ve bakım sayfasını görür. Admin paneli ve izin verilen IP adresleri normal şekilde erişebilir. Bakım işlemleriniz bittiğinde modu kapatmayı unutmayın.</p>
    </div>
</div>
<?php endif; ?>

<!-- Partial Maintenance -->
<div class="partial-maint-card" id="partial-maintenance">
  <div class="partial-maint-head"><div><h3><i class="fas fa-sliders"></i> Kısmi Bakım Modu</h3><p>Tüm siteyi kapatmadan yalnız problemli modülü kontrollü biçimde durdurun.</p></div><span class="partial-summary"><i class="fas fa-circle-exclamation"></i> <?=$partialActiveCount?> modül bakımda</span></div>
  <form method="post">
    <?=csrf_field()?>
    <div class="partial-grid">
      <?php $partialIcons=['orders'=>'fa-cart-shopping','payments'=>'fa-wallet','api'=>'fa-code','child_panels'=>'fa-diagram-project'];$partialDesc=['orders'=>'Yeni web/API/abonelik/dripfeed siparişi üretimini durdurur; mevcut dispatch kuyruğu çalışmaya devam eder.','payments'=>'Yeni havale bildirimi ve ödeme başlatmayı durdurur; daha önce başlamış gateway callback işlemleri kabul edilmeye devam eder.','api'=>'Müşteri/reseller API ve sandbox isteklerine 503 bakım yanıtı verir. Admin paneli etkilenmez.','child_panels'=>'Child Panel yönetim işlemlerini ve child domain erişimini geçici olarak durdurur.']; foreach($partialMaintenance as $key=>$mod): ?>
      <article class="partial-module <?=$mod['active']?'on':''?>">
        <div class="partial-module-top"><div class="partial-module-id"><span class="partial-module-icon"><i class="fas <?=clean($partialIcons[$key]??'fa-screwdriver-wrench')?>"></i></span><div><h4><?=clean($mod['label'])?></h4><small><?=clean($partialDesc[$key]??'Bu modülü geçici olarak durdurur.')?></small></div></div><label class="partial-switch"><input type="checkbox" name="partial[<?=clean($key)?>]" value="1" <?=$mod['active']?'checked':''?>><span class="partial-slider"></span></label></div>
        <textarea class="partial-msg" name="partial_message[<?=clean($key)?>]" maxlength="500" placeholder="Kullanıcıya gösterilecek bakım mesajı..."><?=clean($mod['message'])?></textarea>
      </article>
      <?php endforeach;?>
    </div>
    <div class="partial-note"><i class="fas fa-shield-halved"></i> Tam bakım modundaki izinli IP listesi kısmi bakımda da bypass olarak kullanılır. Admin oturumları test ve yönetim için kısmi bakımdan etkilenmez.</div>
    <div class="partial-footer"><button type="submit" name="save_partial_maintenance" value="1" class="save-btn"><i class="fas fa-floppy-disk"></i> Kısmi Bakımı Kaydet</button></div>
  </form>
</div>

<!-- Settings Card -->
<div class="settings-card">
    <div class="settings-header">
        <i class="fas fa-cog"></i>
        <h3>Bakım Modu Ayarları</h3>
    </div>
    <div class="settings-body">
        <form method="POST">
            <div class="form-group">
                <label class="form-label">
                    Bakım Mesajı
                </label>
                <textarea name="maintenance_message" class="form-control" rows="4" placeholder="Ziyaretçilere gösterilecek mesaj..."><?php echo clean($maintenanceMessage); ?></textarea>
                <span class="form-hint">Bu mesaj bakım sayfasında ziyaretçilere gösterilecektir.</span>
            </div>
            
            <div class="form-group">
                <label class="form-label">
                    Tahmini Bitiş Zamanı
                </label>
                <input type="datetime-local" name="maintenance_end_time" class="form-control" value="<?php echo !empty($maintenanceEndTime) ? date('Y-m-d\TH:i', strtotime($maintenanceEndTime)) : ''; ?>">
                <span class="form-hint">Bakım çalışmasının tahmini bitiş zamanı. Boş bırakılırsa geri sayım gösterilmez.</span>
            </div>
            
            <div class="form-group">
                <label class="form-label">
                    İzin Verilen IP Adresleri
                </label>
                <div class="ip-input-group">
                    <input type="text" name="maintenance_allowed_ips" id="allowedIps" class="form-control" value="<?php echo clean($maintenanceAllowedIps); ?>" placeholder="Örn: 192.168.1.1, 10.0.0.1">
                    <button type="button" class="add-my-ip-btn" onclick="addMyIp()">
                        <i class="fas fa-plus"></i> IP'mi Ekle
                    </button>
                </div>
                <span class="form-hint">Bakım modunda siteye erişebilecek IP adresleri. Virgülle ayırarak birden fazla IP girebilirsiniz. Admin kullanıcıları zaten erişebilir.</span>
            </div>
            
            <button type="submit" name="save_settings" class="save-btn">
                <i class="fas fa-save"></i>
                Ayarları Kaydet
            </button>
        </form>
    </div>
</div>

<!-- Preview Card -->
<div class="preview-card">
    <div class="preview-header">
        <div class="preview-header-left">
            <i class="fas fa-eye"></i>
            <h3>Bakım Sayfası Önizleme</h3>
        </div>
        <a href="/bakimmodu.php" target="_blank" class="preview-link">
            <i class="fas fa-external-link-alt"></i>
            Sayfayı Görüntüle
        </a>
    </div>
    <div class="preview-body">
        <div class="preview-frame">
            <div class="preview-browser-bar">
                <span class="browser-dot red"></span>
                <span class="browser-dot yellow"></span>
                <span class="browser-dot green"></span>
                <span class="browser-url"><?php echo SITE_URL; ?>/bakimmodu.php</span>
            </div>
            <div class="preview-content">
                <div class="preview-icon">
                    <i class="fas fa-tools"></i>
                </div>
                <h4 class="preview-title">Bakım Çalışması</h4>
                <p class="preview-message"><?php echo clean(mb_substr($maintenanceMessage, 0, 150, 'UTF-8')); ?><?php echo mb_strlen($maintenanceMessage, 'UTF-8') > 150 ? '...' : ''; ?></p>
            </div>
        </div>
    </div>
</div>

<script>
// IP adresini ekle
function addMyIp() {
    var input = document.getElementById('allowedIps');
    var currentValue = input.value.trim();
    var myIp = '<?php echo $userIp; ?>';
    
    if (currentValue === '') {
        input.value = myIp;
    } else {
        // IP zaten var mı kontrol et
        var ips = currentValue.split(',').map(function(ip) {
            return ip.trim();
        });
        
        if (ips.indexOf(myIp) === -1) {
            input.value = currentValue + ', ' + myIp;
        } else {
            alert('IP adresiniz zaten listede!');
        }
    }
}
</script>

<?php require_once 'footer.php'; ?>