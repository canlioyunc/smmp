<?php
/**
 * Admin Panel - Destek Talepleri Yönetimi
 */

require_once __DIR__ . '/../config.php';

if (!isLoggedIn() || !isAdmin()) {
    header('Location: /login.php');
    exit;
}

$success = '';
$error = '';

// Mesaj gönder
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_reply'])) {
    $ticketId = (int)$_POST['ticket_id'];
    $message = trim($_POST['message']);
    
    if (empty($message)) {
        $error = 'Mesaj alanı zorunludur!';
    } else {
        $ticket = $db->prepare("SELECT * FROM support_tickets WHERE id = ?");
        $ticket->execute([$ticketId]);
        $ticket = $ticket->fetch();
        
        if ($ticket) {
            $attachment = null;
            $uploadDir = __DIR__ . '/../uploads/support/';
            
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] !== UPLOAD_ERR_NO_FILE) {
                $upload = moni_safe_upload($_FILES['attachment'], 'support', ['image/jpeg','image/png','image/gif','image/webp'], 5 * 1024 * 1024);
                if (!$upload['ok']) { $error = $upload['error']; }
                else { $attachment = $upload['path']; }
            }
            
            if (!$error) {
                $stmt = $db->prepare("INSERT INTO support_messages (ticket_id, user_id, message, attachment, is_admin) VALUES (?, ?, ?, ?, 1)");
                $stmt->execute([$ticketId, $_SESSION['user_id'], $message, $attachment]);
                $stmt = $db->prepare("UPDATE support_tickets SET status = 'answered', updated_at = NOW() WHERE id = ?");
                $stmt->execute([$ticketId]);
                header('Location: support.php?ticket=' . $ticketId . '&success=sent');
                exit;
            }
        }
    }
}

// Ticket durumunu değiştir
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_status'])) {
    $ticketId = (int)$_POST['ticket_id'];
    $newStatus = $_POST['new_status'];
    
    $validStatuses = ['open', 'answered', 'closed'];
    if (in_array($newStatus, $validStatuses)) {
        $closedAt = $newStatus === 'closed' ? 'NOW()' : 'NULL';
        $stmt = $db->prepare("UPDATE support_tickets SET status = ?, closed_at = $closedAt, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$newStatus, $ticketId]);
        
        header('Location: support.php?ticket=' . $ticketId . '&success=status');
        exit;
    }
}

// Ticket sil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_ticket'])) {
    $ticketId = (int)$_POST['ticket_id'];
    
    // Çoklu ilişki tablosunu da temizle
    $db->prepare("DELETE FROM support_ticket_orders WHERE ticket_id = ?")->execute([$ticketId]);
    $db->prepare("DELETE FROM support_messages WHERE ticket_id = ?")->execute([$ticketId]);
    $db->prepare("DELETE FROM support_tickets WHERE id = ?")->execute([$ticketId]);
    
    header('Location: support.php?success=deleted');
    exit;
}

// Success mesajları
if (isset($_GET['success'])) {
    switch ($_GET['success']) {
        case 'sent': $success = 'Yanıtınız gönderildi!'; break;
        case 'status': $success = 'Talep durumu güncellendi!'; break;
        case 'deleted': $success = 'Talep silindi!'; break;
    }
}

// Görüntüleme modu
$viewTicket = null;
$ticketMessages = [];
$ticketOrders = [];

if (isset($_GET['ticket'])) {
    $ticketId = (int)$_GET['ticket'];
    
    $stmt = $db->prepare("
        SELECT t.*, u.username, u.email, u.balance, u.created_at as user_created,
               o.id as order_id, o.link as order_link, o.quantity as order_quantity, o.status as order_status,
               s.name as service_name
        FROM support_tickets t
        LEFT JOIN users u ON t.user_id = u.id
        LEFT JOIN orders o ON t.order_id = o.id
        LEFT JOIN services s ON o.service_id = s.id
        WHERE t.id = ?
    ");
    $stmt->execute([$ticketId]);
    $viewTicket = $stmt->fetch();
    
    if ($viewTicket) {
        $stmt = $db->prepare("
            SELECT m.*, u.username
            FROM support_messages m
            LEFT JOIN users u ON m.user_id = u.id
            WHERE m.ticket_id = ?
            ORDER BY m.created_at ASC
        ");
        $stmt->execute([$ticketId]);
        $ticketMessages = $stmt->fetchAll();
        
        // Çoklu siparişleri çek
        $stmt = $db->prepare("
            SELECT o.id, o.link, o.quantity, o.price, o.status, o.created_at,
                   o.start_count, o.remains, o.api_order_id, o.refund_amount,
                   s.name as service_name
            FROM support_ticket_orders sto
            JOIN orders o ON sto.order_id = o.id
            LEFT JOIN services s ON o.service_id = s.id
            WHERE sto.ticket_id = ?
            ORDER BY o.id DESC
        ");
        $stmt->execute([$ticketId]);
        $ticketOrders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Kullanıcı mesajlarını okunmuş işaretle
        $stmt = $db->prepare("UPDATE support_messages SET is_read = 1 WHERE ticket_id = ? AND is_admin = 0 AND is_read = 0");
        $stmt->execute([$ticketId]);
    }
}

// Filtreler
$statusFilter = $_GET['status'] ?? '';
$priorityFilter = $_GET['priority'] ?? '';
$search = $_GET['search'] ?? '';

$where = "WHERE 1=1";
$params = [];

if ($statusFilter) {
    $where .= " AND t.status = ?";
    $params[] = $statusFilter;
}

if ($priorityFilter) {
    $where .= " AND t.priority = ?";
    $params[] = $priorityFilter;
}

if ($search) {
    $where .= " AND (t.id = ? OR t.subject LIKE ? OR u.username LIKE ? OR u.email LIKE ?)";
    $params[] = $search;
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

// Sayfalama
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

$countStmt = $db->prepare("SELECT COUNT(*) FROM support_tickets t LEFT JOIN users u ON t.user_id = u.id $where");
$countStmt->execute($params);
$totalTickets = $countStmt->fetchColumn();
$totalPages = ceil($totalTickets / $perPage);

$stmt = $db->prepare("
    SELECT t.*, u.username, u.email,
           (SELECT COUNT(*) FROM support_messages WHERE ticket_id = t.id AND is_admin = 0 AND is_read = 0) as unread_count,
           (SELECT message FROM support_messages WHERE ticket_id = t.id ORDER BY created_at DESC LIMIT 1) as last_message
    FROM support_tickets t
    LEFT JOIN users u ON t.user_id = u.id
    $where
    ORDER BY 
        CASE WHEN t.status = 'open' THEN 0 WHEN t.status = 'answered' THEN 1 ELSE 2 END,
        t.updated_at DESC
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$tickets = $stmt->fetchAll();

// İstatistikler
$stats = $db->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END) as open_count,
        SUM(CASE WHEN status = 'answered' THEN 1 ELSE 0 END) as answered_count,
        SUM(CASE WHEN status = 'closed' THEN 1 ELSE 0 END) as closed_count,
        SUM(CASE WHEN priority = 'high' AND status != 'closed' THEN 1 ELSE 0 END) as high_priority_count
    FROM support_tickets
")->fetch();

$statusNames = [
    'open' => 'Açık',
    'answered' => 'Yanıtlandı',
    'closed' => 'Kapalı'
];

$priorityNames = [
    'low' => 'Düşük',
    'medium' => 'Normal',
    'high' => 'Yüksek'
];

$orderStatusNames = [
    'pending' => 'Beklemede',
    'processing' => 'İşleniyor',
    'in_progress' => 'Devam Ediyor',
    'completed' => 'Tamamlandı',
    'partial' => 'Kısmi',
    'cancelled' => 'İptal',
    'refunded' => 'İade Edildi',
    'error' => 'Hata'
];

$pageTitle = "Destek Talepleri";
require_once 'header.php';
?>

<style>
.support-layout {
    display: grid;
    grid-template-columns: 400px 1fr;
    gap: 25px;
    height: calc(100vh - 150px);
    min-height: 600px;
}

@media (max-width: 1200px) {
    .support-layout {
        grid-template-columns: 1fr;
        height: auto;
    }
    .tickets-panel { max-height: 500px; }
}

.stats-row {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 15px;
    margin-bottom: 25px;
}

@media (max-width: 992px) {
    .stats-row { grid-template-columns: repeat(3, 1fr); }
}

@media (max-width: 576px) {
    .stats-row { grid-template-columns: repeat(2, 1fr); }
}

.stat-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 12px;
    padding: 20px;
    text-align: center;
}

.stat-card .icon {
    width: 50px;
    height: 50px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 12px;
    font-size: 1.2rem;
}

.stat-card .icon.total { background: var(--primary-alpha-015); color: var(--accent-text-color); }
.stat-card .icon.open { background: rgba(243, 156, 18, 0.15); color: #f39c12; }
.stat-card .icon.answered { background: rgba(40, 167, 69, 0.15); color: #28a745; }
.stat-card .icon.closed { background: rgba(108, 117, 125, 0.15); color: var(--muted-text-color); }
.stat-card .icon.high { background: rgba(220, 53, 69, 0.15); color: #dc3545; }

.stat-card .value { font-size: 1.8rem; font-weight: 700; margin-bottom: 5px; }
.stat-card .label { font-size: 0.85rem; opacity: 0.6; }

.tickets-panel {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    display: flex;
    flex-direction: column;
    overflow: hidden;
}

.panel-header {
    padding: 20px;
    border-bottom: 1px solid var(--border-color);
}

.panel-header h3 {
    font-size: 1.1rem;
    font-weight: 600;
    margin-bottom: 15px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.panel-header h3 i { color: var(--accent-text-color); }

.filters-row {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.filters-row .form-control {
    padding: 10px 14px;
    font-size: 0.85rem;
    flex: 1;
    min-width: 100px;
}

.status-tabs {
    display: flex;
    padding: 15px;
    gap: 8px;
    border-bottom: 1px solid var(--border-color);
    overflow-x: auto;
}

.status-tab {
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 500;
    text-decoration: none;
    color: var(--text-color);
    background: var(--background-color);
    border: 1px solid var(--border-color);
    white-space: nowrap;
}

.status-tab:hover, .status-tab.active {
    background: var(--primary-color);
    border-color: var(--accent-text-color);
    color: var(--on-primary-color);
}

.tickets-list {
    flex: 1;
    overflow-y: auto;
    padding: 10px;
}

.ticket-item {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    padding: 15px;
    border-radius: 12px;
    cursor: pointer;
    text-decoration: none;
    color: var(--text-color);
    margin-bottom: 8px;
    border: 1px solid transparent;
    position: relative;
}

.ticket-item:hover { background: var(--background-color); }

.ticket-item.active {
    background: var(--primary-alpha-015);
    border-color: var(--accent-text-color);
}

.ticket-item.unread {
    background: rgba(243, 156, 18, 0.08);
    border-color: rgba(243, 156, 18, 0.3);
}

.ticket-icon {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.85rem;
    font-weight: 600;
    flex-shrink: 0;
}

.ticket-icon.open { background: rgba(243, 156, 18, 0.15); color: #f39c12; }
.ticket-icon.answered { background: rgba(40, 167, 69, 0.15); color: #28a745; }
.ticket-icon.closed { background: rgba(108, 117, 125, 0.15); color: var(--muted-text-color); }

.ticket-content { flex: 1; min-width: 0; }

.ticket-content h4 {
    font-size: 0.9rem;
    font-weight: 600;
    margin-bottom: 4px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.ticket-content .preview {
    font-size: 0.8rem;
    opacity: 0.6;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    margin-bottom: 5px;
}

.ticket-content .meta {
    display: flex;
    gap: 10px;
    font-size: 0.75rem;
    opacity: 0.5;
}

.ticket-badges {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 5px;
    flex-shrink: 0;
}

.priority-badge {
    padding: 3px 8px;
    border-radius: 6px;
    font-size: 0.7rem;
    font-weight: 600;
}

.priority-badge.low { background: rgba(108, 117, 125, 0.15); color: var(--muted-text-color); }
.priority-badge.medium { background: rgba(23, 162, 184, 0.15); color: #17a2b8; }
.priority-badge.high { background: rgba(220, 53, 69, 0.15); color: #dc3545; }

.unread-badge {
    background: var(--danger-color);
    color: var(--on-danger-color);
    font-size: 0.7rem;
    padding: 2px 8px;
    border-radius: 10px;
    font-weight: 600;
}

.empty-tickets {
    text-align: center;
    padding: 60px 20px;
    opacity: 0.6;
}

.empty-tickets i { font-size: 3rem; margin-bottom: 15px; opacity: 0.3; }

.main-panel {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    display: flex;
    flex-direction: column;
    overflow: hidden;
}

.ticket-header {
    padding: 20px 25px;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 15px;
    flex-wrap: wrap;
}

.ticket-header-left h2 {
    font-size: 1.1rem;
    font-weight: 600;
    margin-bottom: 8px;
}

.ticket-header-left h2 .id {
    color: var(--accent-text-color);
    font-size: 0.85rem;
    margin-left: 8px;
}

.ticket-meta-row {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
    font-size: 0.85rem;
    opacity: 0.7;
}

.ticket-meta-row i { color: var(--accent-text-color); margin-right: 5px; }

.ticket-header-right {
    display: flex;
    align-items: center;
    gap: 10px;
}

.status-dropdown { position: relative; }

.status-btn {
    padding: 10px 18px;
    border-radius: 10px;
    font-size: 0.85rem;
    font-weight: 600;
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
}

.status-btn.open { background: rgba(243, 156, 18, 0.15); color: #f39c12; }
.status-btn.answered { background: rgba(40, 167, 69, 0.15); color: #28a745; }
.status-btn.closed { background: rgba(108, 117, 125, 0.15); color: var(--muted-text-color); }

.status-dropdown-menu {
    position: absolute;
    top: 100%;
    right: 0;
    margin-top: 5px;
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 10px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
    z-index: 100;
    display: none;
    min-width: 150px;
    overflow: hidden;
}

.status-dropdown-menu.active { display: block; }

.status-dropdown-menu button {
    display: block;
    width: 100%;
    padding: 12px 20px;
    background: none;
    border: none;
    text-align: left;
    cursor: pointer;
    font-size: 0.85rem;
    color: var(--text-color);
}

.status-dropdown-menu button:hover { background: var(--background-color); }

.delete-btn {
    padding: 10px 14px;
    background: rgba(220, 53, 69, 0.15);
    color: #dc3545;
    border: none;
    border-radius: 10px;
    cursor: pointer;
}

.delete-btn:hover { background: #dc3545; color: #fff; }

.user-info-box {
    padding: 15px 25px;
    background: var(--background-color);
    border-bottom: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
}

.user-info-left {
    display: flex;
    align-items: center;
    gap: 12px;
}

.user-avatar {
    width: 42px;
    height: 42px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--on-accent-color);
    font-weight: 600;
}

.user-details h4 { font-size: 0.95rem; font-weight: 600; }
.user-details p { font-size: 0.8rem; opacity: 0.6; }

.user-info-right { display: flex; gap: 20px; }

.user-stat { text-align: center; }
.user-stat .value { font-size: 1rem; font-weight: 700; color: var(--accent-text-color); }
.user-stat .label { font-size: 0.75rem; opacity: 0.5; }

.order-info-box {
    padding: 15px 25px;
    background: rgba(23, 162, 184, 0.08);
    border-bottom: 1px solid var(--border-color);
    display: flex;
    align-items: center;
    gap: 15px;
}

.order-info-box i { color: #17a2b8; font-size: 1.2rem; }
.order-info-box .info { flex: 1; }
.order-info-box .info h5 { font-size: 0.9rem; font-weight: 600; }
.order-info-box .info p { font-size: 0.8rem; opacity: 0.6; }

.order-info-box a {
    padding: 8px 16px;
    background: #17a2b8;
    color: #fff;
    border-radius: 8px;
    text-decoration: none;
    font-size: 0.8rem;
}

/* Çoklu sipariş listesi için kutu */
.orders-info-box {
    padding: 20px 25px;
    background: var(--primary-alpha-005);
    border-bottom: 1px solid var(--border-color);
}
.orders-info-box .orders-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 15px;
    font-weight: 600;
    font-size: 0.95rem;
}
.orders-info-box .orders-header i { color: var(--accent-text-color); font-size: 1.1rem; }
.orders-info-box .orders-header .badge {
    background: var(--primary-color);
    color: var(--on-primary-color);
    font-size: 0.75rem;
    padding: 3px 10px;
    border-radius: 10px;
    margin-left: 5px;
}

.orders-table-wrapper { overflow-x: auto; margin: 0 -10px; padding: 0 10px; }

.orders-list-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.85rem;
    min-width: 700px;
}
.orders-list-table th {
    text-align: left;
    padding: 10px 12px;
    background: var(--background-color);
    font-weight: 600;
    font-size: 0.75rem;
    text-transform: uppercase;
    opacity: 0.7;
    white-space: nowrap;
}
.orders-list-table th:first-child { border-radius: 8px 0 0 8px; }
.orders-list-table th:last-child { border-radius: 0 8px 8px 0; }
.orders-list-table td {
    padding: 12px;
    border-bottom: 1px solid var(--border-color);
    vertical-align: middle;
}
.orders-list-table tr:last-child td { border-bottom: none; }
.orders-list-table tr:hover td { background: var(--primary-alpha-003); }

.orders-list-table .order-id { font-weight: 700; color: var(--accent-text-color); white-space: nowrap; }
.orders-list-table .order-id small { display: block; font-size: 0.7rem; opacity: 0.5; font-weight: 400; margin-top: 2px; }
.orders-list-table .service-name { max-width: 180px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-weight: 500; }
.orders-list-table .order-link { max-width: 150px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-size: 0.8rem; opacity: 0.7; }
.orders-list-table .order-link a { color: var(--accent-text-color); text-decoration: none; }
.orders-list-table .order-link a:hover { text-decoration: underline; }
.orders-list-table .quantity-info { text-align: center; }
.orders-list-table .quantity-info .qty { font-weight: 600; font-size: 0.9rem; }
.orders-list-table .quantity-info .progress-text { font-size: 0.7rem; opacity: 0.6; margin-top: 2px; }
.orders-list-table .price-info { text-align: right; white-space: nowrap; }
.orders-list-table .price-info .price { font-weight: 600; color: var(--accent-text-color); }
.orders-list-table .price-info .refund { font-size: 0.7rem; color: #28a745; margin-top: 2px; }
.orders-list-table .order-status { padding: 5px 12px; border-radius: 6px; font-size: 0.75rem; font-weight: 600; display: inline-block; white-space: nowrap; }
.orders-list-table .order-status.pending { background: rgba(243, 156, 18, 0.15); color: #f39c12; }
.orders-list-table .order-status.processing { background: rgba(23, 162, 184, 0.15); color: #17a2b8; }
.orders-list-table .order-status.in_progress { background: rgba(0, 123, 255, 0.15); color: #007bff; }
.orders-list-table .order-status.completed { background: rgba(40, 167, 69, 0.15); color: #28a745; }
.orders-list-table .order-status.partial { background: rgba(255, 193, 7, 0.15); color: #d39e00; }
.orders-list-table .order-status.cancelled { background: rgba(108, 117, 125, 0.15); color: var(--muted-text-color); }
.orders-list-table .order-status.refunded { background: rgba(111, 66, 193, 0.15); color: #6f42c1; }
.orders-list-table .order-status.error { background: rgba(220, 53, 69, 0.15); color: #dc3545; }
.orders-list-table .order-date { font-size: 0.8rem; opacity: 0.6; white-space: nowrap; }
.orders-list-table .order-actions a {
    padding: 6px 12px;
    background: var(--primary-color);
    color: var(--on-primary-color);
    border-radius: 6px;
    text-decoration: none;
    font-size: 0.75rem;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}
.orders-list-table .order-actions a:hover { background: var(--secondary-color); }

.messages-container {
    flex: 1;
    overflow-y: auto;
    padding: 25px;
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.message-item {
    display: flex;
    gap: 12px;
    max-width: 80%;
}

.message-item.user { align-self: flex-start; }

.message-item.admin {
    align-self: flex-end;
    flex-direction: row-reverse;
}

.message-avatar {
    width: 38px;
    height: 38px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    font-size: 0.85rem;
    flex-shrink: 0;
}

.message-item.user .message-avatar {
    background: var(--background-color);
    color: var(--text-color);
}

.message-item.admin .message-avatar {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--on-accent-color);
}

.message-content { flex: 1; min-width: 0; }

.message-bubble {
    padding: 14px 18px;
    border-radius: 14px;
    font-size: 0.9rem;
    line-height: 1.6;
    word-wrap: break-word;
}

.message-item.user .message-bubble {
    background: var(--background-color);
    border-top-left-radius: 4px;
}

.message-item.admin .message-bubble {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--on-accent-color);
    border-top-right-radius: 4px;
}

.message-attachment { margin-top: 10px; }

.message-attachment img {
    max-width: 250px;
    max-height: 180px;
    border-radius: 10px;
    cursor: pointer;
}

.message-time {
    font-size: 0.75rem;
    opacity: 0.5;
    margin-top: 6px;
}

.message-item.admin .message-time { text-align: right; }

.reply-form {
    padding: 20px 25px;
    border-top: 1px solid var(--border-color);
}

.reply-form.disabled {
    opacity: 0.6;
    pointer-events: none;
}

.quick-replies {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    margin-bottom: 15px;
}

.quick-reply-btn {
    padding: 6px 12px;
    background: var(--background-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    font-size: 0.75rem;
    cursor: pointer;
    color: var(--text-color);
}

.quick-reply-btn:hover {
    border-color: var(--accent-text-color);
    color: var(--accent-text-color);
}

.reply-form-inner {
    display: flex;
    gap: 12px;
    align-items: flex-end;
}

.reply-input-wrapper {
    flex: 1;
}

.reply-input-wrapper textarea {
    width: 100%;
    padding: 14px 16px;
    border: 2px solid var(--border-color);
    border-radius: 12px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 0.9rem;
    resize: none;
    min-height: 70px;
    max-height: 120px;
}

.reply-input-wrapper textarea:focus {
    outline: none;
    border-color: var(--accent-text-color);
}

.reply-buttons {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.attachment-btn {
    width: 44px;
    height: 44px;
    border: 2px solid var(--border-color);
    border-radius: 10px;
    background: var(--background-color);
    color: var(--text-color);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

.attachment-btn:hover {
    border-color: var(--accent-text-color);
    color: var(--accent-text-color);
}

.attachment-btn.has-file {
    background: var(--primary-color);
    border-color: var(--accent-text-color);
    color: var(--on-primary-color);
}

.attachment-btn input { display: none; }

.send-btn {
    padding: 12px 24px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border: none;
    border-radius: 10px;
    color: var(--on-accent-color);
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    white-space: nowrap;
}

.send-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 20px var(--primary-alpha-03);
}

.welcome-state {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 50px;
    text-align: center;
}

.welcome-state i {
    font-size: 4rem;
    color: var(--accent-text-color);
    opacity: 0.2;
    margin-bottom: 20px;
}

.welcome-state h3 { font-size: 1.2rem; margin-bottom: 10px; }
.welcome-state p { opacity: 0.6; }

.lightbox {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.9);
    z-index: 3000;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.lightbox.active { display: flex; }

.lightbox img {
    max-width: 90%;
    max-height: 90%;
    border-radius: 12px;
}

.lightbox-close {
    position: absolute;
    top: 20px;
    right: 20px;
    background: rgba(255, 255, 255, 0.1);
    border: none;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    color: #fff;
    font-size: 1.5rem;
    cursor: pointer;
}

.pagination {
    display: flex;
    justify-content: center;
    gap: 8px;
    padding: 15px;
    border-top: 1px solid var(--border-color);
}

.pagination a, .pagination span {
    padding: 8px 14px;
    border-radius: 8px;
    text-decoration: none;
    font-size: 0.85rem;
}

.pagination a {
    background: var(--background-color);
    color: var(--text-color);
    border: 1px solid var(--border-color);
}

.pagination a:hover {
    border-color: var(--accent-text-color);
    color: var(--accent-text-color);
}

.pagination .current {
    background: var(--primary-color);
    color: var(--on-primary-color);
}
</style>

<?php if ($success): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?php echo clean($success); ?>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?php echo clean($error); ?>
    </div>
<?php endif; ?>

<div class="stats-row">
    <div class="stat-card">
        <div class="icon total"><i class="fas fa-ticket-alt"></i></div>
        <div class="value"><?php echo $stats['total'] ?? 0; ?></div>
        <div class="label">Toplam</div>
    </div>
    <div class="stat-card">
        <div class="icon open"><i class="fas fa-clock"></i></div>
        <div class="value"><?php echo $stats['open_count'] ?? 0; ?></div>
        <div class="label">Açık</div>
    </div>
    <div class="stat-card">
        <div class="icon answered"><i class="fas fa-reply"></i></div>
        <div class="value"><?php echo $stats['answered_count'] ?? 0; ?></div>
        <div class="label">Yanıtlandı</div>
    </div>
    <div class="stat-card">
        <div class="icon closed"><i class="fas fa-check-circle"></i></div>
        <div class="value"><?php echo $stats['closed_count'] ?? 0; ?></div>
        <div class="label">Kapalı</div>
    </div>
    <div class="stat-card">
        <div class="icon high"><i class="fas fa-exclamation-triangle"></i></div>
        <div class="value"><?php echo $stats['high_priority_count'] ?? 0; ?></div>
        <div class="label">Acil</div>
    </div>
</div>

<div class="support-layout">
    <div class="tickets-panel">
        <div class="panel-header">
            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap"><h3><i class="fas fa-inbox"></i> Destek Talepleri</h3><a href="/admin/support-departments.php" class="btn btn-primary btn-sm"><i class="fas fa-sitemap"></i> Departmanlar</a></div>
            <form method="GET" class="filters-row">
                <input type="text" name="search" class="form-control" placeholder="Ara..." value="<?php echo clean($search); ?>">
                <select name="priority" class="form-control" onchange="this.form.submit()">
                    <option value="">Öncelik</option>
                    <option value="high" <?php echo $priorityFilter === 'high' ? 'selected' : ''; ?>>Yüksek</option>
                    <option value="medium" <?php echo $priorityFilter === 'medium' ? 'selected' : ''; ?>>Normal</option>
                    <option value="low" <?php echo $priorityFilter === 'low' ? 'selected' : ''; ?>>Düşük</option>
                </select>
                <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i></button>
            </form>
        </div>
        
        <div class="status-tabs">
            <a href="support.php" class="status-tab <?php echo !$statusFilter ? 'active' : ''; ?>">Tümü (<?php echo $stats['total'] ?? 0; ?>)</a>
            <a href="support.php?status=open" class="status-tab <?php echo $statusFilter === 'open' ? 'active' : ''; ?>">Açık</a>
            <a href="support.php?status=answered" class="status-tab <?php echo $statusFilter === 'answered' ? 'active' : ''; ?>">Yanıtlandı</a>
            <a href="support.php?status=closed" class="status-tab <?php echo $statusFilter === 'closed' ? 'active' : ''; ?>">Kapalı</a>
        </div>
        
        <div class="tickets-list">
            <?php if (empty($tickets)): ?>
                <div class="empty-tickets">
                    <i class="fas fa-inbox"></i>
                    <p>Destek talebi yok</p>
                </div>
            <?php else: ?>
                <?php foreach ($tickets as $ticket): ?>
                    <a href="support.php?ticket=<?php echo $ticket['id']; ?>" class="ticket-item <?php echo ($viewTicket && $viewTicket['id'] == $ticket['id']) ? 'active' : ''; ?> <?php echo $ticket['unread_count'] > 0 ? 'unread' : ''; ?>">
                        <div class="ticket-icon <?php echo $ticket['status']; ?>">
                            <?php echo strtoupper(mb_substr($ticket['username'], 0, 1, 'UTF-8')); ?>
                        </div>
                        <div class="ticket-content">
                            <h4><?php echo clean($ticket['subject']); ?></h4>
                            <p class="preview"><?php echo clean(mb_substr($ticket['last_message'] ?? '', 0, 40, 'UTF-8')); ?>...</p>
                            <div class="meta">
                                <span><?php echo clean($ticket['username']); ?></span>
                                <span><?php echo date('d.m H:i', strtotime($ticket['updated_at'])); ?></span>
                            </div>
                        </div>
                        <div class="ticket-badges">
                            <span class="priority-badge <?php echo $ticket['priority']; ?>"><?php echo $priorityNames[$ticket['priority']]; ?></span>
                            <?php if ($ticket['unread_count'] > 0): ?>
                                <span class="unread-badge"><?php echo $ticket['unread_count']; ?></span>
                            <?php endif; ?>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <?php if ($totalPages > 1): ?>
            <div class="pagination">
                <?php for ($i = 1; $i <= min($totalPages, 5); $i++): ?>
                    <?php if ($i == $page): ?>
                        <span class="current"><?php echo $i; ?></span>
                    <?php else: ?>
                        <a href="?page=<?php echo $i; ?>&status=<?php echo urlencode($statusFilter); ?>"><?php echo $i; ?></a>
                    <?php endif; ?>
                <?php endfor; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="main-panel">
        <?php if ($viewTicket): ?>
            <div class="ticket-header">
                <div class="ticket-header-left">
                    <h2><?php echo clean($viewTicket['subject']); ?><span class="id">#<?php echo $viewTicket['id']; ?></span></h2>
                    <div class="ticket-meta-row">
                        <span><i class="fas fa-calendar"></i><?php echo date('d.m.Y H:i', strtotime($viewTicket['created_at'])); ?></span>
                        <span><i class="fas fa-flag"></i><?php echo $priorityNames[$viewTicket['priority']]; ?></span>
                    </div>
                </div>
                <div class="ticket-header-right">
                    <div class="status-dropdown">
                        <button type="button" class="status-btn <?php echo $viewTicket['status']; ?>" onclick="toggleStatusMenu()">
                            <?php echo $statusNames[$viewTicket['status']]; ?> <i class="fas fa-chevron-down"></i>
                        </button>
                        <div class="status-dropdown-menu" id="statusMenu">
                            <form method="POST">
                                <input type="hidden" name="ticket_id" value="<?php echo $viewTicket['id']; ?>">
                                <input type="hidden" name="change_status" value="1">
                                <button type="submit" name="new_status" value="open">Açık</button>
                                <button type="submit" name="new_status" value="answered">Yanıtlandı</button>
                                <button type="submit" name="new_status" value="closed">Kapalı</button>
                            </form>
                        </div>
                    </div>
                    <form method="POST" onsubmit="return confirm('Silmek istediğinize emin misiniz?');">
                        <input type="hidden" name="ticket_id" value="<?php echo $viewTicket['id']; ?>">
                        <button type="submit" name="delete_ticket" class="delete-btn"><i class="fas fa-trash"></i></button>
                    </form>
                </div>
            </div>
            
            <div class="user-info-box">
                <div class="user-info-left">
                    <div class="user-avatar"><?php echo strtoupper(mb_substr($viewTicket['username'], 0, 1, 'UTF-8')); ?></div>
                    <div class="user-details">
                        <h4><?php echo clean($viewTicket['username']); ?></h4>
                        <p><?php echo clean($viewTicket['email']); ?></p>
                    </div>
                </div>
                <div class="user-info-right">
                    <div class="user-stat">
                        <div class="value"><?php echo $siteSettings['currency_symbol'] . number_format($viewTicket['balance'], 2); ?></div>
                        <div class="label">Bakiye</div>
                    </div>
                </div>
            </div>
            
            <?php if ($viewTicket['order_id'] && empty($ticketOrders)): ?>
                <div class="order-info-box">
                    <i class="fas fa-shopping-cart"></i>
                    <div class="info">
                        <h5>Sipariş #<?php echo $viewTicket['order_id']; ?></h5>
                        <p><?php echo clean($viewTicket['service_name']); ?></p>
                    </div>
                    <a href="/admin/orders.php?search=<?php echo $viewTicket['order_id']; ?>" target="_blank"><i class="fas fa-external-link-alt"></i></a>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($ticketOrders)): ?>
                <div class="orders-info-box">
                    <div class="orders-header">
                        <i class="fas fa-shopping-cart"></i>
                        İlgili Siparişler
                        <span class="badge"><?php echo count($ticketOrders); ?> sipariş</span>
                    </div>
                    <div class="orders-table-wrapper">
                        <table class="orders-list-table">
                            <thead>
                                <tr>
                                    <th>Sipariş</th>
                                    <th>Hizmet</th>
                                    <th>Link</th>
                                    <th>Miktar</th>
                                    <th>Fiyat</th>
                                    <th>Durum</th>
                                    <th>Tarih</th>
                                    <th>İşlem</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($ticketOrders as $order): ?>
                                    <tr>
                                        <td class="order-id">
                                            #<?php echo $order['id']; ?>
                                            <?php if ($order['api_order_id']): ?>
                                                <small>API: <?php echo clean($order['api_order_id']); ?></small>
                                            <?php endif; ?>
                                        </td>
                                        <td class="service-name" title="<?php echo clean($order['service_name'] ?? 'Hizmet'); ?>">
                                            <?php echo clean($order['service_name'] ?? 'Hizmet'); ?>
                                        </td>
                                        <td class="order-link" title="<?php echo clean($order['link']); ?>">
                                            <a href="<?php echo clean($order['link']); ?>" target="_blank">
                                                <?php echo clean($order['link']); ?>
                                            </a>
                                        </td>
                                        <td class="quantity-info">
                                            <div class="qty"><?php echo number_format($order['quantity']); ?></div>
                                            <?php if ($order['start_count'] !== null): ?>
                                                <div class="progress-text">
                                                    Başlangıç: <?php echo number_format($order['start_count']); ?>
                                                    <?php if ($order['remains'] !== null): ?>
                                                        | Kalan: <?php echo number_format($order['remains']); ?>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td class="price-info">
                                            <div class="price"><?php echo $siteSettings['currency_symbol'] . number_format($order['price'], 2); ?></div>
                                            <?php if ($order['refund_amount'] > 0): ?>
                                                <div class="refund">İade: <?php echo $siteSettings['currency_symbol'] . number_format($order['refund_amount'], 2); ?></div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="order-status <?php echo $order['status']; ?>">
                                                <?php echo $orderStatusNames[$order['status']] ?? $order['status']; ?>
                                            </span>
                                        </td>
                                        <td class="order-date"><?php echo date('d.m.Y H:i', strtotime($order['created_at'])); ?></td>
                                        <td class="order-actions">
                                            <a href="/admin/orders.php?search=<?php echo $order['id']; ?>" target="_blank">
                                                <i class="fas fa-eye"></i> Detay
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
            
            <div class="messages-container" id="messagesContainer">
                <?php foreach ($ticketMessages as $msg): ?>
                    <div class="message-item <?php echo $msg['is_admin'] ? 'admin' : 'user'; ?>">
                        <div class="message-avatar">
                            <?php if ($msg['is_admin']): ?>
                                <i class="fas fa-headset"></i>
                            <?php else: ?>
                                <?php echo strtoupper(mb_substr($msg['username'], 0, 1, 'UTF-8')); ?>
                            <?php endif; ?>
                        </div>
                        <div class="message-content">
                            <div class="message-bubble"><?php echo nl2br(clean($msg['message'])); ?></div>
                            <?php if ($msg['attachment']): ?>
                                <div class="message-attachment">
                                    <img src="/<?php echo clean($msg['attachment']); ?>" onclick="openLightbox(this.src)">
                                </div>
                            <?php endif; ?>
                            <div class="message-time"><?php echo date('d.m.Y H:i', strtotime($msg['created_at'])); ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="reply-form <?php echo $viewTicket['status'] === 'closed' ? 'disabled' : ''; ?>">
                <?php if ($viewTicket['status'] === 'closed'): ?>
                    <p style="text-align: center; opacity: 0.6;"><i class="fas fa-lock"></i> Talep kapalı</p>
                <?php else: ?>
                    <div class="quick-replies">
                        <button type="button" class="quick-reply-btn" onclick="insertQuickReply('Merhaba, destek talebiniz için teşekkürler.')">Merhaba</button>
                        <button type="button" class="quick-reply-btn" onclick="insertQuickReply('Sorununuz çözülmüştür.')">Çözüldü</button>
                        <button type="button" class="quick-reply-btn" onclick="insertQuickReply('Lütfen daha fazla bilgi verir misiniz?')">Bilgi İste</button>
                    </div>
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="ticket_id" value="<?php echo $viewTicket['id']; ?>">
                        <div class="reply-form-inner">
                            <div class="reply-input-wrapper">
                                <textarea name="message" id="replyMessage" placeholder="Yanıtınızı yazın..." required></textarea>
                            </div>
                            <div class="reply-buttons">
                                <label class="attachment-btn" id="attachmentBtn">
                                    <i class="fas fa-paperclip"></i>
                                    <input type="file" name="attachment" accept="image/*" onchange="handleAttachment(this)">
                                </label>
                                <button type="submit" name="send_reply" class="send-btn"><i class="fas fa-paper-plane"></i></button>
                            </div>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="welcome-state">
                <i class="fas fa-headset"></i>
                <h3>Destek Yönetimi</h3>
                <p>Sol taraftan bir talep seçin</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="lightbox" id="lightbox" onclick="closeLightbox()">
    <button class="lightbox-close">&times;</button>
    <img src="" id="lightboxImage">
</div>

<script>
function toggleStatusMenu() {
    document.getElementById('statusMenu').classList.toggle('active');
}

document.addEventListener('click', function(e) {
    if (!e.target.closest('.status-dropdown')) {
        document.getElementById('statusMenu')?.classList.remove('active');
    }
});

function insertQuickReply(text) {
    document.getElementById('replyMessage').value = text;
    document.getElementById('replyMessage').focus();
}

function handleAttachment(input) {
    const btn = document.getElementById('attachmentBtn');
    btn.classList.toggle('has-file', input.files.length > 0);
}

function openLightbox(src) {
    document.getElementById('lightboxImage').src = src;
    document.getElementById('lightbox').classList.add('active');
}

function closeLightbox() {
    document.getElementById('lightbox').classList.remove('active');
}

const mc = document.getElementById('messagesContainer');
if (mc) mc.scrollTop = mc.scrollHeight;

document.addEventListener('keydown', e => { if (e.key === 'Escape') closeLightbox(); });
</script>

<?php require_once 'footer.php'; ?>