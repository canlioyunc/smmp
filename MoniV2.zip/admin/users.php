<?php
/**
 * Admin - Kullanıcı Yönetimi (Gelişmiş)
 */

require_once __DIR__ . '/../config.php';

date_default_timezone_set('Europe/Istanbul');

if (!isLoggedIn() || !isAdmin()) {
    header('Location: index.php');
    exit;
}

// İşlemler
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Kullanıcı bilgilerini güncelle
    if (isset($_POST['update_user'])) {
        $userId = (int)$_POST['user_id'];
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $role = $_POST['role'];
        $status = $_POST['status'];
        $newBalance = (float)$_POST['balance'];
        $emailVerified = isset($_POST['email_verified']) ? 1 : 0;
        
        $check = $db->prepare("SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?");
        $check->execute([$username, $email, $userId]);
        
        if ($check->fetch()) {
            setAlert('<i class="fas fa-times-circle"></i> Bu kullanıcı adı veya e-posta başka bir kullanıcı tarafından kullanılıyor!', 'danger');
        } else {
            // Mevcut bakiyeyi al
            $stmt = $db->prepare("SELECT balance, role FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $currentUser = $stmt->fetch();
            $currentBalance = (float)$currentUser['balance'];
            
            // Kendi rolünü değiştiremez
            if ($userId == $_SESSION['user_id']) {
                $role = $currentUser['role'];
            }
            
            try {
                $db->beginTransaction();
                
                // Kullanıcıyı güncelle
                $stmt = $db->prepare("UPDATE users SET username = ?, email = ?, role = ?, status = ?, balance = ?, email_verified = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$username, $email, $role, $status, $newBalance, $emailVerified, $userId]);
                
                // Bakiye değiştiyse transaction kaydı oluştur
                $balanceDiff = $newBalance - $currentBalance;
                if (abs($balanceDiff) > 0.001) {
                    $type = $balanceDiff > 0 ? 'admin_add' : 'admin_remove';
                    $description = $balanceDiff > 0 
                        ? 'Admin tarafından bakiye eklendi (düzenleme)' 
                        : 'Admin tarafından bakiye düşüldü (düzenleme)';
                    
                    $stmt = $db->prepare("INSERT INTO transactions (user_id, type, amount, balance_after, description, status, created_at) VALUES (?, ?, ?, ?, ?, 'completed', NOW())");
                    $stmt->execute([$userId, $type, abs($balanceDiff), $newBalance, $description]);
                }
                
                $db->commit();
                setAlert('<i class="fas fa-check-circle"></i> Kullanıcı bilgileri güncellendi!', 'success');
            } catch (Exception $e) {
                $db->rollBack();
                setAlert('<i class="fas fa-times-circle"></i> Hata: ' . $e->getMessage(), 'danger');
            }
        }
        header('Location: users.php');
        exit;
    }
    
    // Bakiye ekle
    if (isset($_POST['add_balance'])) {
        $userId = (int)$_POST['user_id'];
        $amount = (float)$_POST['amount'];
        $description = trim($_POST['description'] ?? '');
        
        if ($amount > 0) {
            try {
                $db->beginTransaction();
                
                // Mevcut bakiyeyi al
                $stmt = $db->prepare("SELECT balance, username FROM users WHERE id = ? FOR UPDATE");
                $stmt->execute([$userId]);
                $user = $stmt->fetch();
                
                if (!$user) {
                    throw new Exception('Kullanıcı bulunamadı!');
                }
                
                $newBalance = $user['balance'] + $amount;
                
                // Bakiyeyi güncelle
                $stmt = $db->prepare("UPDATE users SET balance = ? WHERE id = ?");
                $stmt->execute([$newBalance, $userId]);
                
                // Transaction kaydı
                $desc = $description ?: 'Admin tarafından bakiye eklendi';
                $stmt = $db->prepare("INSERT INTO transactions (user_id, type, amount, balance_after, description, status, created_at) VALUES (?, 'admin_add', ?, ?, ?, 'completed', NOW())");
                $stmt->execute([$userId, $amount, $newBalance, $desc]);
                
                $db->commit();
                moni_sync_base_wallet($db, $userId);
                setAlert('<i class="fas fa-check-circle"></i> ' . $siteSettings['currency_symbol'] . number_format($amount, 2) . ' bakiye eklendi! Yeni bakiye: ' . $siteSettings['currency_symbol'] . number_format($newBalance, 2), 'success');
            } catch (Exception $e) {
                $db->rollBack();
                setAlert('<i class="fas fa-times-circle"></i> Hata: ' . $e->getMessage(), 'danger');
            }
        } else {
            setAlert('<i class="fas fa-times-circle"></i> Miktar 0\'dan büyük olmalı!', 'danger');
        }
        header('Location: users.php');
        exit;
    }
    
    // Bakiye çıkar
    if (isset($_POST['remove_balance'])) {
        $userId = (int)$_POST['user_id'];
        $amount = (float)$_POST['amount'];
        $description = trim($_POST['description'] ?? '');
        
        if ($amount > 0) {
            try {
                $db->beginTransaction();
                
                // Mevcut bakiyeyi al
                $stmt = $db->prepare("SELECT balance, username FROM users WHERE id = ? FOR UPDATE");
                $stmt->execute([$userId]);
                $user = $stmt->fetch();
                
                if (!$user) {
                    throw new Exception('Kullanıcı bulunamadı!');
                }
                
                $newBalance = max(0, $user['balance'] - $amount);
                $actualDeducted = $user['balance'] - $newBalance; // Gerçekte düşülen miktar
                
                // Bakiyeyi güncelle
                $stmt = $db->prepare("UPDATE users SET balance = ? WHERE id = ?");
                $stmt->execute([$newBalance, $userId]);
                
                // Transaction kaydı (negatif amount olarak kaydet)
                $desc = $description ?: 'Admin tarafından bakiye düşüldü';
                $stmt = $db->prepare("INSERT INTO transactions (user_id, type, amount, balance_after, description, status, created_at) VALUES (?, 'admin_remove', ?, ?, ?, 'completed', NOW())");
                $stmt->execute([$userId, -$actualDeducted, $newBalance, $desc]);
                
                $db->commit();
                moni_sync_base_wallet($db, $userId);
                
                if ($actualDeducted < $amount) {
                    setAlert('<i class="fas fa-exclamation-triangle"></i> Bakiye yetersiz! ' . $siteSettings['currency_symbol'] . number_format($actualDeducted, 2) . ' düşüldü. Yeni bakiye: ' . $siteSettings['currency_symbol'] . '0.00', 'warning');
                } else {
                    setAlert('<i class="fas fa-check-circle"></i> ' . $siteSettings['currency_symbol'] . number_format($amount, 2) . ' bakiye düşüldü! Yeni bakiye: ' . $siteSettings['currency_symbol'] . number_format($newBalance, 2), 'success');
                }
            } catch (Exception $e) {
                $db->rollBack();
                setAlert('<i class="fas fa-times-circle"></i> Hata: ' . $e->getMessage(), 'danger');
            }
        } else {
            setAlert('<i class="fas fa-times-circle"></i> Miktar 0\'dan büyük olmalı!', 'danger');
        }
        header('Location: users.php');
        exit;
    }
    
    // Kullanıcı silme: finansal/sipariş geçmişini korumak için hard-delete yerine anonimleştirilmiş soft-delete.
    if (isset($_POST['delete_user'])) {
        $userId = (int)$_POST['user_id'];
        if ($userId != $_SESSION['user_id']) {
            try {
                $db->beginTransaction();
                $q=$db->prepare("SELECT role FROM users WHERE id=? FOR UPDATE");$q->execute([$userId]);$targetRole=(string)$q->fetchColumn();
                if($targetRole==='') throw new Exception('Kullanıcı bulunamadı!');
                if($targetRole==='admin' && (!function_exists('moni_is_super_admin') || !moni_is_super_admin($db))) throw new Exception('Admin hesabını yalnız Süper Admin silebilir.');
                $anonUser='silinmis_'.$userId.'_'.bin2hex(random_bytes(4));
                $anonMail='deleted_'.$userId.'_'.bin2hex(random_bytes(4)).'@invalid.local';
                $deadPass=password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT);
                $stmt=$db->prepare("UPDATE users SET username=?,email=?,password=?,first_name=NULL,last_name=NULL,phone=NULL,role='user',status='inactive',api_key=NULL,two_factor_enabled=0,two_factor_secret=NULL,email_verified=0,staff_role_id=NULL,deleted_at=NOW(),deleted_by=?,updated_at=NOW() WHERE id=?");
                $stmt->execute([$anonUser,$anonMail,$deadPass,(int)$_SESSION['user_id'],$userId]);
                if(function_exists('moni_revoke_user_sessions'))moni_revoke_user_sessions($db,$userId);
                $db->commit();
                setAlert('<i class="fas fa-check-circle"></i> Kullanıcı anonimleştirilerek silindi; sipariş ve finans kayıtları korundu.', 'success');
            } catch (Throwable $e) {
                if($db->inTransaction())$db->rollBack();
                setAlert('<i class="fas fa-times-circle"></i> Hata: '.clean($e->getMessage()), 'danger');
            }
        } else {
            setAlert('<i class="fas fa-times-circle"></i> Kendinizi silemezsiniz!', 'danger');
        }
        header('Location: users.php');
        exit;
    }
    
    // Şifre sıfırla
    if (isset($_POST['reset_password'])) {
        $userId = (int)$_POST['user_id'];
        $newPassword = $_POST['new_password'];
        
        if (strlen($newPassword) >= 8) {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $db->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hashedPassword, $userId]);
            if(function_exists('moni_revoke_user_sessions'))moni_revoke_user_sessions($db,$userId);
            setAlert('<i class="fas fa-check-circle"></i> Şifre değiştirildi!', 'success');
        } else {
            setAlert('<i class="fas fa-times-circle"></i> Şifre en az 8 karakter olmalı!', 'danger');
        }
        header('Location: users.php');
        exit;
    }
    
    // Yeni kullanıcı ekle
    if (isset($_POST['add_user'])) {
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        $role = $_POST['role'];
        $balance = (float)$_POST['balance'];
        
        if (empty($username) || empty($email) || empty($password)) {
            setAlert('<i class="fas fa-times-circle"></i> Zorunlu alanları doldurun!', 'danger');
        } elseif (strlen($password) < 8) {
            setAlert('<i class="fas fa-times-circle"></i> Şifre en az 8 karakter olmalı!', 'danger');
        } else {
            $check = $db->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $check->execute([$username, $email]);
            
            if ($check->fetch()) {
                setAlert('<i class="fas fa-times-circle"></i> Bu kullanıcı adı veya e-posta zaten kullanılıyor!', 'danger');
            } else {
                try {
                    $db->beginTransaction();
                    
                    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $db->prepare("INSERT INTO users (username, email, password, role, balance, status, email_verified, created_at) VALUES (?, ?, ?, ?, ?, 'active', 1, NOW())");
                    $stmt->execute([$username, $email, $hashedPassword, $role, $balance]);
                    
                    $newUserId = $db->lastInsertId();
                    
                    // Başlangıç bakiyesi varsa transaction kaydı
                    if ($balance > 0) {
                        $stmt = $db->prepare("INSERT INTO transactions (user_id, type, amount, balance_after, description, status, created_at) VALUES (?, 'admin_add', ?, ?, ?, 'completed', NOW())");
                        $stmt->execute([$newUserId, $balance, $balance, 'Başlangıç bakiyesi (hesap oluşturma)']);
                    }
                    
                    $db->commit();
                    setAlert('<i class="fas fa-check-circle"></i> Kullanıcı başarıyla eklendi!', 'success');
                } catch (Exception $e) {
                    $db->rollBack();
                    setAlert('<i class="fas fa-times-circle"></i> Hata: ' . $e->getMessage(), 'danger');
                }
            }
        }
        header('Location: users.php');
        exit;
    }
}

// Arama ve filtreleme
$search = $_GET['search'] ?? '';
$roleFilter = $_GET['role'] ?? '';
$statusFilter = $_GET['status'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

$where = "WHERE u.deleted_at IS NULL";
$params = [];

if ($search) {
    $where .= " AND (u.username LIKE ? OR u.email LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($roleFilter) {
    $where .= " AND u.role = ?";
    $params[] = $roleFilter;
}

if ($statusFilter) {
    $where .= " AND u.status = ?";
    $params[] = $statusFilter;
}

$countStmt = $db->prepare("SELECT COUNT(*) FROM users u $where");
$countStmt->execute($params);
$totalUsers = $countStmt->fetchColumn();
$totalPages = ceil($totalUsers / $perPage);

$stmt = $db->prepare("
    SELECT u.*,
        (SELECT COUNT(*) FROM orders WHERE user_id = u.id) as order_count,
        (SELECT COALESCE(SUM(price), 0) FROM orders WHERE user_id = u.id AND status NOT IN ('cancelled', 'refunded', 'error')) as total_spent,
        (SELECT COALESCE(SUM(price), 0) FROM orders WHERE user_id = u.id AND status IN ('cancelled', 'refunded')) as cancelled_amount,
        (SELECT COUNT(*) FROM orders WHERE user_id = u.id AND status IN ('cancelled', 'refunded')) as cancelled_count
    FROM users u
    $where
    ORDER BY u.created_at DESC
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$users = $stmt->fetchAll();

$generalStats = $db->query("
    SELECT 
        COUNT(*) as total_users,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_users,
        SUM(CASE WHEN status = 'banned' THEN 1 ELSE 0 END) as banned_users,
        SUM(CASE WHEN role = 'reseller' THEN 1 ELSE 0 END) as reseller_count,
        SUM(balance) as total_balance
    FROM users WHERE deleted_at IS NULL
")->fetch();

$pageTitle = "Kullanıcı Yönetimi";
require_once 'header.php';
?>

<style>
.stats-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 15px;
    margin-bottom: 25px;
}

.stat-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 12px;
    padding: 20px;
    text-align: center;
}

.stat-card h3 {
    font-size: 1.6rem;
    font-weight: 700;
    margin-bottom: 5px;
}

.stat-card p {
    font-size: 0.85rem;
    opacity: 0.7;
}

.stat-card.users h3 { color: var(--accent-text-color); }
.stat-card.active h3 { color: #28a745; }
.stat-card.banned h3 { color: #dc3545; }
.stat-card.balance h3 { color: #f39c12; }

.user-filters {
    display: flex;
    gap: 12px;
    margin-bottom: 25px;
    flex-wrap: wrap;
    align-items: center;
}

.user-filters .form-control {
    min-width: 160px;
    padding: 10px 14px;
}

.user-filters .search-input {
    flex: 1;
    min-width: 220px;
}

.users-table {
    width: 100%;
    border-collapse: collapse;
}

.users-table th,
.users-table td {
    padding: 14px 12px;
    text-align: left;
    border-bottom: 1px solid var(--border-color);
    font-size: 0.9rem;
}

.users-table th {
    background: var(--background-color);
    font-weight: 600;
    font-size: 0.8rem;
    text-transform: uppercase;
    opacity: 0.7;
}

.users-table tbody tr:hover {
    background: var(--background-color);
}

.user-cell {
    display: flex;
    align-items: center;
    gap: 12px;
}

.user-avatar {
    width: 42px;
    height: 42px;
    border-radius: 10px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--on-accent-color);
    font-weight: 600;
    font-size: 1rem;
    flex-shrink: 0;
}

.user-details h4 {
    font-size: 0.95rem;
    font-weight: 600;
    color: var(--text-color);
    margin-bottom: 2px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.user-details span {
    font-size: 0.8rem;
    color: var(--text-color);
    opacity: 0.6;
}

.verified-icon {
    color: #28a745;
    font-size: 0.7rem;
}

.role-badge {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    display: inline-block;
}

.role-admin { background: rgba(220, 53, 69, 0.15); color: #dc3545; }
.role-reseller { background: rgba(255, 193, 7, 0.15); color: #f39c12; }
.role-user { background: rgba(23, 162, 184, 0.15); color: #17a2b8; }

.status-badge {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
    display: inline-block;
}

.status-active { background: rgba(40, 167, 69, 0.15); color: #28a745; }
.status-inactive { background: rgba(108, 117, 125, 0.15); color: var(--muted-text-color); }
.status-banned { background: rgba(220, 53, 69, 0.15); color: #dc3545; }

.balance-cell {
    font-weight: 600;
    color: var(--success-color);
    font-size: 0.95rem;
}

.spending-cell .spent {
    font-weight: 600;
    color: var(--success-color);
    display: block;
}

.spending-cell .cancelled {
    color: #dc3545;
    font-size: 0.75rem;
    margin-top: 3px;
    display: flex;
    align-items: center;
    gap: 4px;
}

.action-buttons {
    display: flex;
    gap: 6px;
}

.action-btn {
    width: 36px;
    height: 36px;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
    font-size: 0.9rem;
    text-decoration: none;
}

.action-btn:hover {
    transform: scale(1.1);
}

.action-btn.edit { background: rgba(23, 162, 184, 0.15); color: #17a2b8; }
.action-btn.money { background: rgba(40, 167, 69, 0.15); color: #28a745; }
.action-btn.password { background: rgba(255, 193, 7, 0.15); color: #f39c12; }
.action-btn.orders { background: var(--primary-alpha-015); color: var(--accent-text-color); }
.action-btn.delete { background: rgba(220, 53, 69, 0.15); color: #dc3545; }

.pagination {
    display: flex;
    gap: 6px;
    justify-content: center;
    margin-top: 25px;
    flex-wrap: wrap;
}

.pagination a, .pagination span {
    padding: 10px 15px;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 500;
    font-size: 0.9rem;
}

.pagination a {
    background: var(--card-bg-color);
    color: var(--text-color);
    border: 1px solid var(--border-color);
}

.pagination a:hover, .pagination .current {
    background: var(--primary-color);
    color: var(--on-primary-color);
    border-color: var(--accent-text-color);
}

/* Modal */
.modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.7);
    z-index: 2000;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.modal-overlay.active {
    display: flex;
}

.modal-box {
    background: var(--card-bg-color);
    border-radius: 16px;
    width: 100%;
    max-width: 500px;
    max-height: 90vh;
    overflow-y: auto;
    animation: modalIn 0.3s ease;
}

@keyframes modalIn {
    from { opacity: 0; transform: scale(0.9) translateY(-20px); }
    to { opacity: 1; transform: scale(1) translateY(0); }
}

.modal-header {
    padding: 20px 25px;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h3 {
    font-size: 1.1rem;
    color: var(--text-color);
    display: flex;
    align-items: center;
    gap: 10px;
}

.modal-header h3 i {
    color: var(--accent-text-color);
}

.modal-close {
    background: var(--background-color);
    border: none;
    width: 36px;
    height: 36px;
    border-radius: 8px;
    font-size: 1.2rem;
    color: var(--text-color);
    cursor: pointer;
    transition: all 0.2s ease;
}

.modal-close:hover {
    background: var(--danger-color);
    color: var(--on-danger-color);
}

.modal-body {
    padding: 25px;
}

.info-box {
    background: var(--background-color);
    border-radius: 10px;
    padding: 15px;
    margin-bottom: 20px;
}

.info-box p {
    margin: 6px 0;
    display: flex;
    justify-content: space-between;
    font-size: 0.9rem;
}

.info-box strong {
    color: var(--accent-text-color);
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
    margin-bottom: 20px;
}

.stats-grid .stat-item {
    text-align: center;
    padding: 12px;
    background: var(--background-color);
    border-radius: 10px;
}

.stats-grid .stat-item h4 {
    font-size: 1.1rem;
    margin-bottom: 3px;
}

.stats-grid .stat-item p {
    font-size: 0.75rem;
    opacity: 0.6;
    margin: 0;
}

.form-row {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
}

.checkbox-group {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px;
    background: var(--background-color);
    border-radius: 8px;
    margin-top: 5px;
}

.checkbox-group input[type="checkbox"] {
    width: 18px;
    height: 18px;
    accent-color: var(--accent-text-color);
}

.checkbox-group label {
    font-size: 0.9rem;
    cursor: pointer;
}

.btn-group {
    display: flex;
    gap: 10px;
    margin-top: 15px;
}

.btn-group .btn {
    flex: 1;
}

/* Mobil Kartlar */
.users-cards {
    display: none;
}

@media (max-width: 992px) {
    .table-responsive {
        display: none;
    }
    
    .users-cards {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }
    
    .user-card {
        background: var(--card-bg-color);
        border: 1px solid var(--border-color);
        border-radius: 12px;
        padding: 20px;
    }
    
    .user-card-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 15px;
    }
    
    .user-card-header .user-cell {
        flex: 1;
    }
    
    .user-card-body {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 12px;
        margin-bottom: 15px;
    }
    
    .user-card-body .item {
        font-size: 0.85rem;
    }
    
    .user-card-body .item .label {
        opacity: 0.6;
        display: block;
        margin-bottom: 3px;
        font-size: 0.75rem;
    }
    
    .user-card-body .item .value {
        font-weight: 500;
    }
    
    .user-card-footer {
        display: flex;
        gap: 8px;
        padding-top: 15px;
        border-top: 1px solid var(--border-color);
        flex-wrap: wrap;
    }
    
    .user-card-footer .action-btn {
        flex: 1;
        min-width: 40px;
        height: 40px;
    }
    
    .form-row {
        grid-template-columns: 1fr;
    }
}

.empty-state {
    text-align: center;
    padding: 60px 20px;
}

.empty-state i {
    font-size: 4rem;
    opacity: 0.15;
    margin-bottom: 15px;
}

.empty-state p {
    opacity: 0.6;
}
</style>

<!-- İstatistikler -->
<div class="stats-row">
    <div class="stat-card users">
        <h3><?php echo number_format($generalStats['total_users']); ?></h3>
        <p>Toplam Kullanıcı</p>
    </div>
    <div class="stat-card active">
        <h3><?php echo number_format($generalStats['active_users']); ?></h3>
        <p>Aktif</p>
    </div>
    <div class="stat-card banned">
        <h3><?php echo number_format($generalStats['banned_users']); ?></h3>
        <p>Yasaklı</p>
    </div>
    <div class="stat-card">
        <h3><?php echo number_format($generalStats['reseller_count']); ?></h3>
        <p>Bayi</p>
    </div>
    <div class="stat-card balance">
        <h3><?php echo $siteSettings['currency_symbol'] . number_format($generalStats['total_balance'], 0); ?></h3>
        <p>Toplam Bakiye</p>
    </div>
</div>

<!-- Ana Kart -->
<div class="admin-card">
    <div class="card-header">
        <h2><i class="fas fa-users"></i> Kullanıcılar (<?php echo number_format($totalUsers); ?>)</h2>
        <button type="button" class="btn btn-primary" onclick="openModal('addUserModal')">
            <i class="fas fa-plus"></i> Yeni Kullanıcı
        </button>
    </div>
    <div class="card-body">
        <!-- Filtreler -->
        <form method="GET" class="user-filters">
            <input type="text" name="search" class="form-control search-input" placeholder="Kullanıcı adı veya e-posta ara..." value="<?php echo clean($search); ?>">
            
            <select name="role" class="form-control">
                <option value="">Tüm Roller</option>
                <option value="admin" <?php echo $roleFilter === 'admin' ? 'selected' : ''; ?>>Admin</option>
                <option value="reseller" <?php echo $roleFilter === 'reseller' ? 'selected' : ''; ?>>Bayi</option>
                <option value="user" <?php echo $roleFilter === 'user' ? 'selected' : ''; ?>>Kullanıcı</option>
            </select>
            
            <select name="status" class="form-control">
                <option value="">Tüm Durumlar</option>
                <option value="active" <?php echo $statusFilter === 'active' ? 'selected' : ''; ?>>Aktif</option>
                <option value="inactive" <?php echo $statusFilter === 'inactive' ? 'selected' : ''; ?>>Pasif</option>
                <option value="banned" <?php echo $statusFilter === 'banned' ? 'selected' : ''; ?>>Yasaklı</option>
            </select>
            
            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
            
            <?php if ($search || $roleFilter || $statusFilter): ?>
                <a href="users.php" class="btn btn-secondary"><i class="fas fa-times"></i></a>
            <?php endif; ?>
        </form>
        
        <!-- Tablo (Desktop) -->
        <div class="table-responsive">
            <table class="users-table">
                <thead>
                    <tr>
                        <th>Kullanıcı</th>
                        <th>Rol</th>
                        <th>Bakiye</th>
                        <th>Harcama</th>
                        <th>Sipariş</th>
                        <th>Durum</th>
                        <th>Kayıt</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($users)): ?>
                        <tr>
                            <td colspan="8">
                                <div class="empty-state">
                                    <i class="fas fa-users"></i>
                                    <p>Kullanıcı bulunamadı</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td>
                                    <div class="user-cell">
                                        <div class="user-avatar">
                                            <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                                        </div>
                                        <div class="user-details">
                                            <h4>
                                                <?php echo clean($user['username']); ?>
                                                <?php if ($user['email_verified']): ?>
                                                    <i class="fas fa-check-circle verified-icon" title="E-posta Onaylı"></i>
                                                <?php endif; ?>
                                            </h4>
                                            <span><?php echo clean($user['email']); ?></span>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="role-badge role-<?php echo $user['role']; ?>">
                                        <?php 
                                        $roles = ['admin' => 'Admin', 'reseller' => 'Bayi', 'user' => 'Kullanıcı'];
                                        echo $roles[$user['role']] ?? $user['role'];
                                        ?>
                                    </span>
                                </td>
                                <td class="balance-cell">
                                    <?php echo $siteSettings['currency_symbol'] . number_format($user['balance'], 2); ?>
                                </td>
                                <td class="spending-cell">
                                    <span class="spent"><?php echo $siteSettings['currency_symbol'] . number_format($user['total_spent'], 2); ?></span>
                                    <?php if ($user['cancelled_amount'] > 0): ?>
                                        <span class="cancelled">
                                            <i class="fas fa-times-circle"></i>
                                            <?php echo $siteSettings['currency_symbol'] . number_format($user['cancelled_amount'], 2); ?>
                                            (<?php echo $user['cancelled_count']; ?>)
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong><?php echo number_format($user['order_count']); ?></strong>
                                </td>
                                <td>
                                    <span class="status-badge status-<?php echo $user['status']; ?>">
                                        <?php 
                                        $statuses = ['active' => 'Aktif', 'inactive' => 'Pasif', 'banned' => 'Yasaklı'];
                                        echo $statuses[$user['status']] ?? $user['status'];
                                        ?>
                                    </span>
                                </td>
                                <td>
                                    <small><?php echo date('d.m.Y', strtotime($user['created_at'])); ?></small>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <button type="button" class="action-btn edit" title="Düzenle" onclick='openEditModal(<?php echo json_encode($user, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'>
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button type="button" class="action-btn money" title="Bakiye" onclick="openBalanceModal(<?php echo $user['id']; ?>, '<?php echo clean($user['username']); ?>', <?php echo $user['balance']; ?>)">
                                            <i class="fas fa-wallet"></i>
                                        </button>
                                        <button type="button" class="action-btn password" title="Şifre" onclick="openPasswordModal(<?php echo $user['id']; ?>, '<?php echo clean($user['username']); ?>')">
                                            <i class="fas fa-key"></i>
                                        </button>
                                        <a href="orders.php?user=<?php echo $user['id']; ?>" class="action-btn orders" title="Siparişler">
                                            <i class="fas fa-shopping-cart"></i>
                                        </a>
                                        <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                            <button type="button" class="action-btn delete" title="Sil" onclick="deleteUser(<?php echo $user['id']; ?>, '<?php echo clean($user['username']); ?>')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Mobil Kartlar -->
        <div class="users-cards">
            <?php foreach ($users as $user): ?>
                <div class="user-card">
                    <div class="user-card-header">
                        <div class="user-cell">
                            <div class="user-avatar">
                                <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                            </div>
                            <div class="user-details">
                                <h4>
                                    <?php echo clean($user['username']); ?>
                                    <?php if ($user['email_verified']): ?>
                                        <i class="fas fa-check-circle verified-icon"></i>
                                    <?php endif; ?>
                                </h4>
                                <span><?php echo clean($user['email']); ?></span>
                            </div>
                        </div>
                        <span class="status-badge status-<?php echo $user['status']; ?>">
                            <?php 
                            $statuses = ['active' => 'Aktif', 'inactive' => 'Pasif', 'banned' => 'Yasaklı'];
                            echo $statuses[$user['status']] ?? $user['status'];
                            ?>
                        </span>
                    </div>
                    <div class="user-card-body">
                        <div class="item">
                            <span class="label">Rol</span>
                            <span class="role-badge role-<?php echo $user['role']; ?>">
                                <?php echo $roles[$user['role']] ?? $user['role']; ?>
                            </span>
                        </div>
                        <div class="item">
                            <span class="label">Bakiye</span>
                            <span class="value" style="color: var(--success-color);"><?php echo $siteSettings['currency_symbol'] . number_format($user['balance'], 2); ?></span>
                        </div>
                        <div class="item">
                            <span class="label">Harcama</span>
                            <span class="value"><?php echo $siteSettings['currency_symbol'] . number_format($user['total_spent'], 2); ?></span>
                        </div>
                        <div class="item">
                            <span class="label">Sipariş</span>
                            <span class="value"><?php echo number_format($user['order_count']); ?></span>
                        </div>
                        <?php if ($user['cancelled_amount'] > 0): ?>
                            <div class="item" style="grid-column: 1 / -1;">
                                <span class="label">İptal Edilen</span>
                                <span class="value" style="color: #dc3545;">
                                    <?php echo $siteSettings['currency_symbol'] . number_format($user['cancelled_amount'], 2); ?> 
                                    (<?php echo $user['cancelled_count']; ?> sipariş)
                                </span>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="user-card-footer">
                        <button type="button" class="action-btn edit" onclick='openEditModal(<?php echo json_encode($user, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'>
                            <i class="fas fa-edit"></i>
                        </button>
                        <button type="button" class="action-btn money" onclick="openBalanceModal(<?php echo $user['id']; ?>, '<?php echo clean($user['username']); ?>', <?php echo $user['balance']; ?>)">
                            <i class="fas fa-wallet"></i>
                        </button>
                        <button type="button" class="action-btn password" onclick="openPasswordModal(<?php echo $user['id']; ?>, '<?php echo clean($user['username']); ?>')">
                            <i class="fas fa-key"></i>
                        </button>
                        <a href="orders.php?user=<?php echo $user['id']; ?>" class="action-btn orders">
                            <i class="fas fa-shopping-cart"></i>
                        </a>
                        <?php if ($user['id'] != $_SESSION['user_id']): ?>
                            <button type="button" class="action-btn delete" onclick="deleteUser(<?php echo $user['id']; ?>, '<?php echo clean($user['username']); ?>')">
                                <i class="fas fa-trash"></i>
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Sayfalama -->
        <?php if ($totalPages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&role=<?php echo $roleFilter; ?>&status=<?php echo $statusFilter; ?>">
                        <i class="fas fa-chevron-left"></i>
                    </a>
                <?php endif; ?>
                
                <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                    <?php if ($i == $page): ?>
                        <span class="current"><?php echo $i; ?></span>
                    <?php else: ?>
                        <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&role=<?php echo $roleFilter; ?>&status=<?php echo $statusFilter; ?>"><?php echo $i; ?></a>
                    <?php endif; ?>
                <?php endfor; ?>
                
                <?php if ($page < $totalPages): ?>
                    <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&role=<?php echo $roleFilter; ?>&status=<?php echo $statusFilter; ?>">
                        <i class="fas fa-chevron-right"></i>
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- ==================== MODALS ==================== -->

<!-- Yeni Kullanıcı Modal -->
<div class="modal-overlay" id="addUserModal">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fas fa-user-plus"></i> Yeni Kullanıcı Ekle</h3>
            <button type="button" class="modal-close" onclick="closeModal('addUserModal')">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <div class="form-group">
                    <label class="form-label">Kullanıcı Adı *</label>
                    <input type="text" name="username" class="form-control" placeholder="kullanici_adi" required>
                </div>
                <div class="form-group">
                    <label class="form-label">E-posta *</label>
                    <input type="email" name="email" class="form-control" placeholder="ornek@email.com" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Şifre * (min 8 karakter)</label>
                    <input type="password" name="password" class="form-control" placeholder="******" required minlength="8" autocomplete="new-password">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Rol</label>
                        <select name="role" class="form-control">
                            <option value="user">Kullanıcı</option>
                            <option value="reseller">Bayi</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Başlangıç Bakiyesi</label>
                        <input type="number" name="balance" class="form-control" value="0" step="0.01" min="0">
                    </div>
                </div>
                <button type="submit" name="add_user" class="btn btn-primary" style="width: 100%; margin-top: 10px;">
                    <i class="fas fa-plus"></i> Kullanıcı Ekle
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Düzenle Modal -->
<div class="modal-overlay" id="editUserModal">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fas fa-user-edit"></i> <span id="edit_title">Kullanıcı Düzenle</span></h3>
            <button type="button" class="modal-close" onclick="closeModal('editUserModal')">&times;</button>
        </div>
        <div class="modal-body">
            <div class="stats-grid">
                <div class="stat-item">
                    <h4 id="edit_stat_orders" style="color: var(--accent-text-color);">0</h4>
                    <p>Sipariş</p>
                </div>
                <div class="stat-item">
                    <h4 id="edit_stat_spent" style="color: #28a745;">₺0</h4>
                    <p>Harcama</p>
                </div>
                <div class="stat-item">
                    <h4 id="edit_stat_cancelled" style="color: #dc3545;">₺0</h4>
                    <p>İptal Edilen</p>
                </div>
                <div class="stat-item">
                    <h4 id="edit_stat_balance" style="color: #f39c12;">₺0</h4>
                    <p>Bakiye</p>
                </div>
            </div>
            
            <form method="POST">
                <input type="hidden" name="user_id" id="edit_user_id">
                
                <div class="form-group">
                    <label class="form-label">Kullanıcı Adı *</label>
                    <input type="text" name="username" id="edit_username" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">E-posta *</label>
                    <input type="email" name="email" id="edit_email" class="form-control" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Rol</label>
                        <select name="role" id="edit_role" class="form-control">
                            <option value="user">Kullanıcı</option>
                            <option value="reseller">Bayi</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Durum</label>
                        <select name="status" id="edit_status" class="form-control">
                            <option value="active">Aktif</option>
                            <option value="inactive">Pasif</option>
                            <option value="banned">Yasaklı</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Bakiye (<?php echo $siteSettings['currency_symbol']; ?>)</label>
                    <input type="number" name="balance" id="edit_balance" class="form-control" step="0.01" min="0">
                </div>
                
                <div class="checkbox-group">
                    <input type="checkbox" name="email_verified" id="edit_email_verified" value="1">
                    <label for="edit_email_verified">E-posta Onaylı</label>
                </div>
                
                <button type="submit" name="update_user" class="btn btn-primary" style="width: 100%; margin-top: 15px;">
                    <i class="fas fa-save"></i> Değişiklikleri Kaydet
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Bakiye Modal -->
<div class="modal-overlay" id="balanceModal">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fas fa-wallet"></i> Bakiye İşlemi</h3>
            <button type="button" class="modal-close" onclick="closeModal('balanceModal')">&times;</button>
        </div>
        <div class="modal-body">
            <div class="info-box">
                <p>Kullanıcı: <strong id="balance_username"></strong></p>
                <p>Mevcut Bakiye: <strong id="balance_current" style="color: var(--success-color);"></strong></p>
            </div>
            
            <form method="POST">
                <input type="hidden" name="user_id" id="balance_user_id">
                
                <div class="form-group">
                    <label class="form-label">Miktar (<?php echo $siteSettings['currency_symbol']; ?>)</label>
                    <input type="number" name="amount" id="balance_amount" class="form-control" step="0.01" min="0.01" placeholder="0.00" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Açıklama (Opsiyonel)</label>
                    <input type="text" name="description" class="form-control" placeholder="İşlem açıklaması...">
                </div>
                
                <div class="btn-group">
                    <button type="submit" name="add_balance" class="btn btn-success">
                        <i class="fas fa-plus"></i> Ekle
                    </button>
                    <button type="submit" name="remove_balance" class="btn btn-danger">
                        <i class="fas fa-minus"></i> Düş
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Şifre Modal -->
<div class="modal-overlay" id="passwordModal">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fas fa-key"></i> Şifre Değiştir</h3>
            <button type="button" class="modal-close" onclick="closeModal('passwordModal')">&times;</button>
        </div>
        <div class="modal-body">
            <div class="info-box">
                <p>Kullanıcı: <strong id="password_username"></strong></p>
            </div>
            
            <form method="POST">
                <input type="hidden" name="user_id" id="password_user_id">
                
                <div class="form-group">
                    <label class="form-label">Yeni Şifre (min 8 karakter)</label>
                    <input type="password" name="new_password" class="form-control" placeholder="Yeni şifre girin..." required minlength="8" autocomplete="new-password">
                </div>
                
                <button type="submit" name="reset_password" class="btn btn-warning" style="width: 100%;">
                    <i class="fas fa-save"></i> Şifreyi Değiştir
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Silme Formu -->
<form method="POST" id="deleteForm" style="display: none;">
    <input type="hidden" name="user_id" id="delete_user_id">
    <input type="hidden" name="delete_user" value="1">
</form>

<script>
const currencySymbol = '<?php echo $siteSettings['currency_symbol']; ?>';

function openModal(modalId) {
    document.getElementById(modalId).classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
    document.body.style.overflow = '';
}

function openEditModal(user) {
    document.getElementById('edit_user_id').value = user.id;
    document.getElementById('edit_title').textContent = user.username + ' - Düzenle';
    document.getElementById('edit_username').value = user.username;
    document.getElementById('edit_email').value = user.email;
    document.getElementById('edit_balance').value = parseFloat(user.balance).toFixed(2);
    document.getElementById('edit_role').value = user.role;
    document.getElementById('edit_status').value = user.status;
    document.getElementById('edit_email_verified').checked = user.email_verified == 1;
    
    document.getElementById('edit_stat_orders').textContent = Number(user.order_count || 0).toLocaleString();
    document.getElementById('edit_stat_spent').textContent = currencySymbol + parseFloat(user.total_spent || 0).toFixed(2);
    document.getElementById('edit_stat_cancelled').textContent = currencySymbol + parseFloat(user.cancelled_amount || 0).toFixed(2);
    document.getElementById('edit_stat_balance').textContent = currencySymbol + parseFloat(user.balance || 0).toFixed(2);
    
    const currentUserId = <?php echo $_SESSION['user_id']; ?>;
    if (user.id == currentUserId) {
        document.getElementById('edit_role').disabled = true;
    } else {
        document.getElementById('edit_role').disabled = false;
    }
    
    openModal('editUserModal');
}

function openBalanceModal(id, username, balance) {
    document.getElementById('balance_user_id').value = id;
    document.getElementById('balance_username').textContent = username;
    document.getElementById('balance_current').textContent = currencySymbol + balance.toFixed(2);
    document.getElementById('balance_amount').value = '';
    openModal('balanceModal');
}

function openPasswordModal(id, username) {
    document.getElementById('password_user_id').value = id;
    document.getElementById('password_username').textContent = username;
    openModal('passwordModal');
}

function deleteUser(id, username) {
    if (confirm(username + ' kullanıcısını silmek istediğinize emin misiniz?\n\nBu işlem geri alınamaz!')) {
        document.getElementById('delete_user_id').value = id;
        document.getElementById('deleteForm').submit();
    }
}

document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) {
            this.classList.remove('active');
            document.body.style.overflow = '';
        }
    });
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(modal => {
            modal.classList.remove('active');
        });
        document.body.style.overflow = '';
    }
});
</script>

<?php require_once 'footer.php'; ?>