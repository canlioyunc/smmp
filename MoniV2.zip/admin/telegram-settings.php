<?php
require_once __DIR__.'/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';
require_once __DIR__.'/../includes/MoniAdminUI.php';
if(!isLoggedIn()||!isAdmin()){header('Location:/admin/');exit;}
$msg='';$err='';$discovered=[];
function moni_telegram_discover_chats(string $token): array {
    $token=trim($token);if($token===''||!function_exists('curl_init'))return [];
    $url='https://api.telegram.org/bot'.rawurlencode($token).'/getUpdates?limit=50&timeout=0';
    $ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>12,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_FOLLOWLOCATION=>false]);$raw=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
    if($http<200||$http>=300)return [];$data=json_decode((string)$raw,true);if(empty($data['ok'])||empty($data['result'])||!is_array($data['result']))return [];
    $out=[];foreach($data['result'] as $u){$m=$u['message']??$u['channel_post']??$u['edited_message']??null;$chat=$m['chat']??null;if(!$chat||!isset($chat['id']))continue;$id=(string)$chat['id'];$name=trim((string)($chat['title']??trim(($chat['first_name']??'').' '.($chat['last_name']??''))??''));if($name==='')$name=$chat['username']??'Telegram sohbeti';$out[$id]=['id'=>$id,'name'=>$name,'type'=>$chat['type']??'unknown'];}return array_values($out);
}
if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        $a=$_POST['action']??'save';
        if($a==='save'){
            updateSetting('telegram_ops_enabled',!empty($_POST['enabled'])?'1':'0');
            $token=trim((string)($_POST['bot_token']??''));if($token!=='')updateSetting('telegram_ops_bot_token',moni_encrypt_secret($token));
            updateSetting('telegram_ops_chat_ids',trim((string)($_POST['chat_ids']??'')));
            updateSetting('telegram_miniapp_bot_username',ltrim(trim((string)($_POST['miniapp_bot_username']??'')),'@'));
            $miniToken=trim((string)($_POST['miniapp_bot_token']??''));if($miniToken!=='')updateSetting('telegram_miniapp_bot_token',moni_encrypt_secret($miniToken));
            $msg='Telegram operasyon ve Mini App ayarları kaydedildi.';
        }elseif($a==='test'){
            $ok=moni_telegram_send($db,'🧪 <b>Sistem Testi</b>'."\n".'Telegram operasyon entegrasyonu çalışıyor.');$ok?$msg='Test mesajı başarıyla gönderildi.':$err='Test mesajı gönderilemedi. Bot token, Chat ID, bot izinleri ve sunucu cURL erişimini kontrol edin.';
        }elseif($a==='discover'){
            $token=trim((string)($_POST['bot_token']??''));if($token==='')$token=moni_decrypt_secret((string)getSetting('telegram_ops_bot_token',''));
            if($token==='')throw new RuntimeException('Önce Bot Token girin veya kaydedin.');
            $discovered=moni_telegram_discover_chats($token);if(!$discovered)$err='Henüz sohbet bulunamadı. Botunuza özelden /start gönderin veya botu gruba ekleyip grupta bir mesaj yazın; sonra tekrar “Chat ID Bul” düğmesine basın.';else $msg=count($discovered).' sohbet bulundu. Aşağıdaki Chat ID değerlerini kopyalayabilirsiniz.';
        }
    }catch(Throwable $e){$err=$e->getMessage();}
}
$enabled=getSetting('telegram_ops_enabled','0')==='1';$storedToken=(string)getSetting('telegram_ops_bot_token','')!=='';$chatIds=trim((string)getSetting('telegram_ops_chat_ids',''));
$pageTitle='Telegram Operasyon Entegrasyonu';require 'header.php';echo moni_admin_ui_styles();
?>
<div class="moni-page">
  <div class="moni-hero"><div><span class="moni-kicker"><i class="fab fa-telegram"></i> Operasyon kanalı</span><h2>Telegram Bot Operasyon Entegrasyonu</h2><p>Provider sorunları, kritik sistem olayları ve admin bildirimlerini seçtiğiniz Telegram kullanıcı, grup veya kanalına güvenli biçimde iletin.</p></div><span class="moni-badge <?=$enabled?'ok':'off'?>"><?=$enabled?'Aktif':'Pasif'?></span></div>
  <?php if($msg):?><div class="moni-alert success"><?=clean($msg)?></div><?php endif;?><?php if($err):?><div class="moni-alert danger"><?=clean($err)?></div><?php endif;?>
  <div class="moni-grid">
    <section class="moni-card two-third"><div class="moni-card-head"><div><h3>Bağlantı ayarları</h3><p>Bot token şifreli saklanır; kayıtlı token hiçbir zaman ekrana geri yazılmaz.</p></div><span class="moni-badge <?=$storedToken?'ok':'off'?>"><?=$storedToken?'Token kayıtlı':'Token yok'?></span></div>
      <form method="post" class="moni-form-grid"><?=csrf_field()?><input type="hidden" name="action" value="save"><label class="moni-check full"><input type="checkbox" name="enabled" value="1" <?=$enabled?'checked':''?>> Telegram operasyon bildirimlerini etkinleştir</label><div class="moni-field full"><label>Bot Token</label><input type="password" name="bot_token" autocomplete="new-password" placeholder="123456789:AA..."><small>Boş bırakırsanız mevcut token korunur. Token yalnız Telegram BotFather tarafından verilen değerdir.</small></div><div class="moni-field full"><label>Chat ID'ler</label><textarea name="chat_ids" rows="4" placeholder="123456789, -1001234567890"><?=clean($chatIds)?></textarea><small>Birden fazla hedefi virgül, boşluk veya yeni satırla ayırabilirsiniz. Grup/kanal ID'leri çoğunlukla negatif değerle başlar.</small></div><div class="moni-field full"><label>Telegram Mini App Bot Token</label><input type="password" name="miniapp_bot_token" autocomplete="new-password" placeholder="Boş bırakırsanız kayıtlı token korunur"><small>Mini App için ayrı veya aynı bot kullanılabilir. Token veritabanında şifreli saklanır.</small></div><div class="moni-field full"><label>Mini App Bot kullanıcı adı</label><input name="miniapp_bot_username" value="<?=clean(getSetting('telegram_miniapp_bot_username',''))?>" placeholder="PanelBot"><small>Eklenti varsayılan pasiftir. Plugins bölümünden telegram_miniapp etkinleştirilmeden kullanıcı erişimi açılmaz.</small></div><div class="moni-actions full"><button class="moni-btn"><i class="fas fa-save"></i> Kaydet</button></div></form>
      <div class="moni-actions" style="margin-top:12px"><form method="post"><?=csrf_field()?><input type="hidden" name="action" value="test"><button class="moni-btn secondary"><i class="fas fa-paper-plane"></i> Test Mesajı Gönder</button></form><form method="post"><?=csrf_field()?><input type="hidden" name="action" value="discover"><button class="moni-btn secondary"><i class="fas fa-magnifying-glass"></i> Chat ID Bul</button></form></div>
      <?php if($discovered):?><div class="moni-table-wrap" style="margin-top:16px"><table class="moni-table"><thead><tr><th>Chat</th><th>Tür</th><th>Chat ID</th></tr></thead><tbody><?php foreach($discovered as $c):?><tr><td><strong><?=clean($c['name'])?></strong></td><td><?=clean($c['type'])?></td><td><code><?=clean($c['id'])?></code></td></tr><?php endforeach;?></tbody></table></div><?php endif;?>
    </section>
    <aside class="moni-card third"><h3>Hızlı durum</h3><div class="moni-kpi"><i class="fab fa-telegram"></i><div><strong><?=$storedToken?'Hazır':'Eksik'?></strong><span class="moni-muted">Bot Token</span></div></div><br><div class="moni-kpi"><i class="fas fa-comments"></i><div><strong><?=$chatIds!==''?count(preg_split('/[\s,;]+/',$chatIds,-1,PREG_SPLIT_NO_EMPTY)):0?></strong><span class="moni-muted">Kayıtlı hedef</span></div></div><p class="moni-muted" style="margin-top:16px">Bildirimler yalnız entegrasyon aktifken gönderilir. Token değiştirmeniz gerekmedikçe alanı boş bırakabilirsiniz.</p></aside>
    <section class="moni-card full"><div class="moni-card-head"><div><h3>Kurulum nasıl yapılır?</h3><p>Bot Token ve Chat ID'yi aşağıdaki adımlarla alabilirsiniz.</p></div></div>
      <div class="moni-grid">
        <div class="moni-card third"><span class="moni-kicker">1. Bot oluştur</span><h3>BotFather'ı açın</h3><p class="moni-muted">Telegram'da resmi <b>@BotFather</b> hesabına girin. <code>/newbot</code> komutunu gönderin, bot adı ve kullanıcı adı belirleyin. BotFather size <b>HTTP API Token</b> verecek; bu değeri yukarıdaki Bot Token alanına girin.</p></div>
        <div class="moni-card third"><span class="moni-kicker">2. Hedefi hazırlayın</span><h3>Kullanıcı, grup veya kanal</h3><p class="moni-muted">Özel mesaj için oluşturduğunuz bota <code>/start</code> gönderin. Grup için botu gruba ekleyip en az bir mesaj gönderin. Kanal için botu kanala ekleyin ve mesaj gönderebilmesi gerekiyorsa yönetici yetkisi verin.</p></div>
        <div class="moni-card third"><span class="moni-kicker">3. Chat ID</span><h3>Chat ID'yi bulun</h3><p class="moni-muted">Token'ı kaydedin, Telegram'da bota/gruba mesaj gönderin ve <b>Chat ID Bul</b> düğmesine basın. Bulunan ID'yi Chat ID alanına yapıştırıp ayarları kaydedin. Ardından <b>Test Mesajı Gönder</b> ile doğrulayın.</p></div>
      </div>
      <div class="moni-alert warning" style="margin-top:16px"><b>Güvenlik:</b> Bot token'ını kimseyle paylaşmayın. Token sızarsa BotFather üzerinden iptal edip yenisini oluşturun. Bot token'ı veritabanında şifreli saklanır.</div>
    </section>
  </div>
</div>
<?php require 'footer.php';?>
