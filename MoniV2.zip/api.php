<?php
// Genel API dokümantasyon sayfası (herkes görebilir)
// Güvenlik: API anahtarları gösterilmez, sadece endpoint ve kullanım anlatılır.

$pageTitle = 'API';
require_once __DIR__ . '/includes/header.php';

// Base URL / endpoint
$defaultBase = (isset($_SERVER['HTTP_HOST']) ? ((isset($_SERVER['REQUEST_SCHEME']) ? $_SERVER['REQUEST_SCHEME'] : 'https') . '://' . $_SERVER['HTTP_HOST']) : '');
$apiBaseUrl  = rtrim($siteSettings['base_url'] ?? $defaultBase, '/');
$apiEndpoint = $apiBaseUrl . '/api/myservices.php';
?>
<style>
.api-hero {
    background: linear-gradient(135deg, var(--primary-alpha-012), rgba(34,197,94,.10));
    border: 1px solid var(--border-color);
    border-radius: 16px;
    padding: 26px;
    margin: 20px auto;
    max-width: 1100px;
}
.api-hero h1 { font-size: 1.6rem; margin-bottom: 8px; color: var(--text-color); }
.api-hero p  { color: var(--muted-text-color); line-height: 1.5; }

.api-container { max-width: 1100px; margin: 0 auto 40px; padding: 0 10px; }
.api-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 14px;
    padding: 18px 20px;
    margin-bottom: 16px;
}
.api-card h3 { margin-bottom: 10px; font-size: 1.05rem; }

.api-code {
    background: var(--background-color);
    border: 1px solid var(--border-color);
    border-radius: 10px;
    padding: 12px 14px;
    font-family: "SFMono-Regular", Consolas, monospace;
    font-size: 0.85rem;
    color: var(--text-color);
    overflow-x: auto;
    margin-top: 8px;
    white-space: pre-wrap;
    word-break: break-all;
}
.api-list { list-style: none; margin: 8px 0 0; padding: 0; }
.api-list li { padding: 6px 0; color: var(--muted-text-color); }
.api-list code {
    background: var(--primary-alpha-015);
    padding: 2px 6px;
    border-radius: 4px;
    font-size: 0.85rem;
}

.api-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px,1fr)); gap: 14px; }
.api-grid-item {
    background: var(--background-color);
    border: 1px solid var(--border-color);
    border-radius: 10px;
    padding: 14px;
}
.api-grid-item strong {
    display: block;
    margin-bottom: 8px;
    color: var(--accent-text-color);
    font-size: 0.95rem;
}

.api-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 14px;
    border-radius: 10px;
    text-decoration: none;
    font-weight: 600;
    font-size: 0.95rem;
    background: var(--button-color);
    color: var(--button-text-color);
    border: 1px solid transparent;
    transition: 0.2s;
}
.api-btn:hover { transform: translateY(-1px); box-shadow: 0 8px 24px rgba(0,0,0,0.18); }

.api-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 999px;
    font-size: 0.75rem;
    font-weight: 600;
    color: var(--on-accent-color);
    margin-right: 6px;
}
.api-badge.get { background: var(--success-color); }
.api-badge.post { background: var(--info-color); }
.api-badge.param { background: var(--primary-color); color: var(--on-primary-color); }

.api-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
    font-size: 0.9rem;
}
.api-table th, .api-table td {
    padding: 10px 12px;
    text-align: left;
    border-bottom: 1px solid var(--border-color);
}
.api-table th {
    background: var(--background-color);
    font-weight: 600;
    color: var(--text-color);
}
.api-table td { color: var(--muted-text-color); }
.api-table code {
    background: var(--primary-alpha-012);
    padding: 2px 6px;
    border-radius: 4px;
}

.api-status-list { margin: 10px 0; padding-left: 20px; }
.api-status-list li { padding: 4px 0; color: var(--muted-text-color); }
</style>

<section class="public-page-hero"><div class="public-container public-page-hero-grid"><div><span class="public-eyebrow"><i class="fas fa-code"></i> Geliştirici API</span><h1>Panelinizi API ile otomatikleştirin</h1><p>Servisleri listele, bakiyeni sorgula, sipariş oluştur ve durumları kendi sisteminden takip et. Sade HTTP istekleri ve JSON cevaplarıyla hızlı entegrasyon kur.</p><div class="hero-proof"><span><i class="fas fa-shield-halved"></i> API anahtarı</span><span><i class="fas fa-rotate"></i> Idempotency desteği</span><span><i class="fas fa-code"></i> JSON yanıtlar</span></div></div><div class="hero-summary"><div class="hero-summary-card"><i class="fas fa-route"></i><strong>4</strong><span>Temel işlem</span></div><div class="hero-summary-card"><i class="fas fa-terminal"></i><strong>GET / POST</strong><span>İstek desteği</span></div><div class="hero-summary-card wide"><i class="fas fa-link"></i><div><strong>Tek endpoint</strong><span>Bakiye, servis, sipariş ve durum işlemleri</span></div></div></div></div></section>
<div class="api-container">
    <div class="api-benefits"><div class="mini-benefit"><i class="fas fa-wallet"></i><strong>Bakiye sorgula</strong><span>Mevcut bakiyeyi uygulamandan kontrol et.</span></div><div class="mini-benefit"><i class="fas fa-list"></i><strong>Servisleri senkronla</strong><span>Aktif servis kataloğunu otomatik çek.</span></div><div class="mini-benefit"><i class="fas fa-cart-plus"></i><strong>Sipariş oluştur</strong><span>Idempotency anahtarıyla güvenli istek gönder.</span></div><div class="mini-benefit"><i class="fas fa-magnifying-glass"></i><strong>Durum takip et</strong><span>Siparişin güncel durumunu sorgula.</span></div></div>
    <div class="api-quick-grid"><div class="api-quick-card"><span class="num">1</span><strong>API anahtarını oluştur</strong><p>Hesabındaki profil alanından API anahtarını oluştur ve güvenli biçimde sakla.</p></div><div class="api-quick-card"><span class="num">2</span><strong>Servisleri senkronla</strong><p><code>action=services</code> ile servis ID, fiyat ve limit bilgilerini kendi sistemine aktar.</p></div><div class="api-quick-card"><span class="num">3</span><strong>Sipariş göndermeye başla</strong><p><code>action=add</code> isteğini benzersiz idempotency anahtarıyla gönder ve sonucu takip et.</p></div></div>
    <div class="api-anchor-nav"><a href="#api-base">Bağlantı</a><a href="#api-auth">Kimlik doğrulama</a><a href="#api-endpoints">Endpointler</a><a href="#api-examples">Örnekler</a><a href="#api-responses">Yanıtlar</a></div>

    <!-- Base URL -->
    <div class="api-card" id="api-base">
        <h3><i class="fas fa-link"></i> Base URL</h3>
        <div class="api-code"><?php echo clean($apiEndpoint); ?></div>
        <p style="margin-top:10px; color: var(--muted-text-color);">
            <span class="api-badge get">GET</span>
            <span class="api-badge post">POST</span>
            Her iki HTTP metodu da desteklenir.
        </p>
    </div>

    <!-- Kimlik Doğrulama -->
    <div class="api-card" id="api-auth">
        <h3><i class="fas fa-key"></i> Kimlik Doğrulama</h3>
        <p style="color: var(--muted-text-color); margin-bottom: 12px;">
            Tüm isteklerde <code>key</code> parametresi zorunludur.
        </p>
        <table class="api-table">
            <tr>
                <th>Parametre</th>
                <th>Tip</th>
                <th>Açıklama</th>
            </tr>
            <tr>
                <td><code>key</code></td>
                <td>string</td>
                <td>Profilinizden aldığınız API anahtarı (zorunlu)</td>
            </tr>
        </table>
        <p style="margin-top:14px;">
            <a class="api-btn" href="<?php echo SITE_URL; ?>/kullanici/profile.php">
                <i class="fas fa-user"></i> API Anahtarı Al
            </a>
        </p>
    </div>

    <!-- Endpoints -->
    <div class="api-card" id="api-endpoints">
        <h3><i class="fas fa-route"></i> Endpoints</h3>
        <div class="api-grid">
            
            <!-- Balance -->
            <div class="api-grid-item">
                <strong><i class="fas fa-wallet"></i> action=balance</strong>
                <p style="color: var(--muted-text-color); font-size: 0.9rem; margin-bottom: 8px;">Hesap bakiyesini sorgular.</p>
                <ul class="api-list">
                    <li><code>X-API-Key</code> HTTP başlığında API anahtarı</li>
                    <li><code>action</code> balance</li>
                </ul>
            </div>

            <!-- Services -->
            <div class="api-grid-item">
                <strong><i class="fas fa-list"></i> action=services</strong>
                <p style="color: var(--muted-text-color); font-size: 0.9rem; margin-bottom: 8px;">Tüm aktif servisleri listeler.</p>
                <ul class="api-list">
                    <li><code>X-API-Key</code> HTTP başlığında API anahtarı</li>
                    <li><code>action</code> services</li>
                </ul>
            </div>

            <!-- Add Order -->
            <div class="api-grid-item">
                <strong><i class="fas fa-cart-plus"></i> action=add</strong>
                <p style="color: var(--muted-text-color); font-size: 0.9rem; margin-bottom: 8px;">Yeni sipariş oluşturur.</p>
                <ul class="api-list">
                    <li><code>X-API-Key</code> HTTP başlığında API anahtarı</li>
                    <li><code>action</code> add</li>
                    <li><code>service</code> Servis ID</li>
                    <li><code>link</code> Hedef URL</li>
                    <li><code>quantity</code> Miktar</li>
                </ul>
            </div>

            <!-- Status -->
            <div class="api-grid-item">
                <strong><i class="fas fa-search"></i> action=status</strong>
                <p style="color: var(--muted-text-color); font-size: 0.9rem; margin-bottom: 8px;">Sipariş durumunu sorgular.</p>
                <ul class="api-list">
                    <li><code>X-API-Key</code> HTTP başlığında API anahtarı</li>
                    <li><code>action</code> status</li>
                    <li><code>order</code> Sipariş ID</li>
                </ul>
            </div>

        </div>
    </div>

    <!-- Örnek İstekler -->
    <div class="api-card" id="api-examples">
        <h3><i class="fas fa-terminal"></i> Örnek İstekler</h3>
        
        <p><strong>1. Bakiye Sorgulama:</strong></p>
        <div class="api-code">curl -H "X-API-Key: API_KEY" "<?php echo clean($apiEndpoint); ?>?action=balance"</div>

        <p style="margin-top:16px;"><strong>2. Servis Listesi:</strong></p>
        <div class="api-code">curl -H "X-API-Key: API_KEY" "<?php echo clean($apiEndpoint); ?>?action=services"</div>

        <p style="margin-top:16px;"><strong>3. Sipariş Oluşturma:</strong></p>
        <div class="api-code">curl -X POST "<?php echo clean($apiEndpoint); ?>" \
  -H "X-API-Key: API_KEY" \
  -H "X-Idempotency-Key: benzersiz-istek-123" \
  -d "action=add" \
  -d "service=1" \
  -d "link=https://instagram.com/kullanici" \
  -d "quantity=1000"</div>

        <p style="margin-top:16px;"><strong>4. Sipariş Durumu:</strong></p>
        <div class="api-code">curl -H "X-API-Key: API_KEY" "<?php echo clean($apiEndpoint); ?>?action=status&order=12345"</div>
    </div>

    <!-- PHP Örneği -->
    <div class="api-card">
        <h3><i class="fab fa-php"></i> PHP Örneği</h3>
        <div class="api-code"><?php
$phpExample = '<?php
$apiUrl = "' . clean($apiEndpoint) . '";
$apiKey = "API_KEY";

function apiRequest($url, $key, $params, $idempotencyKey = null) {
    $ch = curl_init($url);
    $headers = ["X-API-Key: " . $key];
    if ($idempotencyKey) {
        $headers[] = "X-Idempotency-Key: " . $idempotencyKey;
    }
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}

$balance = apiRequest($apiUrl, $apiKey, ["action" => "balance"]);
$services = apiRequest($apiUrl, $apiKey, ["action" => "services"]);
$order = apiRequest($apiUrl, $apiKey, [
    "action" => "add",
    "service" => 1,
    "link" => "https://instagram.com/kullanici",
    "quantity" => 1000
], bin2hex(random_bytes(16)));
print_r($balance);
print_r($services);
print_r($order);
?>';
echo htmlspecialchars($phpExample, ENT_QUOTES, 'UTF-8');
?></div>
    </div>

    <!-- Dönüş Yapıları -->
    <div class="api-card" id="api-responses">
        <h3><i class="fas fa-code"></i> Dönüş Yapıları</h3>
        
        <p><strong>action=balance</strong></p>
        <div class="api-code">{
    "balance": "125.50",
    "currency": "TRY"
}</div>

        <p style="margin-top:16px;"><strong>action=services</strong></p>
        <div class="api-code">[
    {
        "service": "1",
        "name": "Instagram Takipçi [TRY]",
        "type": "default",
        "category": "Instagram",
        "rate": "45.00",
        "min": "100",
        "max": "10000",
        "dripfeed": false,
        "refill": false,
        "cancel": true
    }
]</div>

        <p style="margin-top:16px;"><strong>action=add (Başarılı)</strong></p>
        <div class="api-code">{
    "order": 12345
}</div>

        <p style="margin-top:16px;"><strong>action=status</strong></p>
        <div class="api-code">{
    "status": "pending",
    "start_count": "0",
    "remains": "1000",
    "currency": "TRY"
}</div>
    </div>

    <!-- Sipariş Durumları -->
    <div class="api-card">
        <h3><i class="fas fa-info-circle"></i> Sipariş Durumları</h3>
        <table class="api-table">
            <tr>
                <th>Durum</th>
                <th>Açıklama</th>
            </tr>
            <tr>
                <td><code>pending</code></td>
                <td>Sipariş beklemede</td>
            </tr>
            <tr>
                <td><code>in_progress</code></td>
                <td>Sipariş işleniyor</td>
            </tr>
            <tr>
                <td><code>completed</code></td>
                <td>Sipariş tamamlandı</td>
            </tr>
            <tr>
                <td><code>partial</code></td>
                <td>Kısmi tamamlandı</td>
            </tr>
            <tr>
                <td><code>canceled</code></td>
                <td>Sipariş iptal edildi</td>
            </tr>
            <tr>
                <td><code>refunded</code></td>
                <td>İade edildi</td>
            </tr>
        </table>
    </div>

    <!-- Hata Mesajları -->
    <div class="api-card">
        <h3><i class="fas fa-exclamation-triangle"></i> Hata Mesajları</h3>
        <table class="api-table">
            <tr>
                <th>Hata</th>
                <th>Açıklama</th>
            </tr>
            <tr>
                <td><code>API Key is missing</code></td>
                <td>API anahtarı gönderilmedi</td>
            </tr>
            <tr>
                <td><code>Invalid API Key</code></td>
                <td>Geçersiz veya pasif API anahtarı</td>
            </tr>
            <tr>
                <td><code>Invalid action</code></td>
                <td>Geçersiz action parametresi</td>
            </tr>
            <tr>
                <td><code>Missing parameters</code></td>
                <td>Zorunlu parametreler eksik</td>
            </tr>
            <tr>
                <td><code>Service ID not found</code></td>
                <td>Servis bulunamadı veya pasif</td>
            </tr>
            <tr>
                <td><code>Quantity below minimum</code></td>
                <td>Miktar minimum limitin altında</td>
            </tr>
            <tr>
                <td><code>Quantity above maximum</code></td>
                <td>Miktar maksimum limitin üstünde</td>
            </tr>
            <tr>
                <td><code>Not enough funds</code></td>
                <td>Yetersiz bakiye</td>
            </tr>
            <tr>
                <td><code>Order not found</code></td>
                <td>Sipariş bulunamadı</td>
            </tr>
            <tr>
                <td><code>System error</code></td>
                <td>Sistem hatası oluştu</td>
            </tr>
        </table>
    </div>

    <!-- Hata Örneği -->
    <div class="api-card">
        <h3><i class="fas fa-times-circle"></i> Hata Dönüş Örneği</h3>
        <div class="api-code">{
    "error": "Not enough funds"
}</div>
        <p style="margin-top:10px; color: var(--muted-text-color);">
            Hata durumunda response içinde <code>error</code> anahtarı bulunur. Bu anahtarın varlığını kontrol ederek hata yönetimi yapabilirsiniz.
        </p>
    </div>

    <!-- Rate Limiting -->
    <div class="api-card">
        <h3><i class="fas fa-tachometer-alt"></i> Önemli Notlar</h3>
        <ul class="api-list">
            <li><i class="fas fa-check" style="color: var(--success-color); margin-right: 8px;"></i> Tüm fiyatlar <strong>TRY (Türk Lirası)</strong> cinsindendir.</li>
            <li><i class="fas fa-check" style="color: var(--success-color); margin-right: 8px;"></i> <code>rate</code> değeri 1000 adet için fiyatı gösterir.</li>
            <li><i class="fas fa-check" style="color: var(--success-color); margin-right: 8px;"></i> Sipariş ücreti: <code>(quantity / 1000) × rate</code> formülü ile hesaplanır.</li>
            <li><i class="fas fa-check" style="color: var(--success-color); margin-right: 8px;"></i> API anahtarınızı kimseyle paylaşmayın.</li>
            <li><i class="fas fa-check" style="color: var(--success-color); margin-right: 8px;"></i> Aşırı istek gönderimi hesabınızın askıya alınmasına neden olabilir.</li>
        </ul>
    </div>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>