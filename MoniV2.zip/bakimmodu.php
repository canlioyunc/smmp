<?php
/**
 * Bakım Modu Sayfası
 */

// Veritabanı bağlantısı ve ayarları al
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/MoniThemeCompat.php';

// Bakım modu kapalıysa ana sayfaya yönlendir
if ($siteSettings['maintenance_mode'] !== '1') {
    header('Location: /');
    exit;
}

// Admin kullanıcıları ana sayfaya yönlendir
if (isAdmin()) {
    header('Location: /');
    exit;
}

// IP kontrolü - izinli IP ise ana sayfaya yönlendir
$userIp = $_SERVER['REMOTE_ADDR'] ?? '';
$allowedIps = $siteSettings['maintenance_allowed_ips'] ?? '';

if (!empty($allowedIps)) {
    $ipList = array_map('trim', explode(',', $allowedIps));
    if (in_array($userIp, $ipList)) {
        header('Location: /');
        exit;
    }
}

// Dil değiştirme işlemi
if (isset($_GET['lang'])) {
    setLanguage($_GET['lang']);
    header('Location: /bakimmodu.php');
    exit;
}

// Dilleri al
$languages = getLanguages();
$currentLangData = null;
foreach ($languages as $lang) {
    if ($lang['code'] === $currentLang) {
        $currentLangData = $lang;
        break;
    }
}

// Bakım bilgileri
$maintenanceMessage = $siteSettings['maintenance_message'] ?: __('maintenance_default_message') ?: 'Sitemiz şu anda bakım çalışması nedeniyle geçici olarak kapalıdır. Kısa süre içinde tekrar hizmetinizdeyiz.';
$maintenanceEndTime = $siteSettings['maintenance_end_time'] ?? '';
$siteName = $siteSettings['name'] ?? 'Site';
$siteLogo = $siteSettings['logo'] ?? '';
$siteEmail = $siteSettings['email'] ?? '';
$sitePhone = $siteSettings['phone'] ?? '';

// Telefon numarasını WhatsApp formatına çevir
$whatsappNumber = preg_replace('/[^0-9]/', '', $sitePhone);

// HTTP 503 Service Unavailable
http_response_code(503);
header('Retry-After: 3600');
?>
<!DOCTYPE html>
<html lang="<?php echo $currentLang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="300">
    <meta name="robots" content="noindex, nofollow">
    <title><?php echo clean($siteName); ?> - <?php echo __('maintenance_title') ?: 'Bakım Çalışması'; ?></title>
    
    <?php if (!empty($siteSettings['favicon'])): ?>
        <link rel="icon" type="image/x-icon" href="<?php echo clean($siteSettings['favicon']); ?>">
    <?php endif; ?>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        <?php echo generateCSSVariables($activeTheme); ?>
        <?php echo moni_theme_compat_css($activeTheme); ?>
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--background-color);
            color: var(--text-color);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }
        
        /* Animated Background */
        .bg-animation {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            opacity: 0.5;
            pointer-events: none;
        }
        
        .bg-animation .circle {
            position: absolute;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            opacity: 0.1;
            animation: float 20s infinite ease-in-out;
        }
        
        .bg-animation .circle:nth-child(1) {
            width: 400px;
            height: 400px;
            top: -100px;
            left: -100px;
            animation-delay: 0s;
        }
        
        .bg-animation .circle:nth-child(2) {
            width: 300px;
            height: 300px;
            bottom: -50px;
            right: -50px;
            animation-delay: -5s;
        }
        
        .bg-animation .circle:nth-child(3) {
            width: 200px;
            height: 200px;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            animation-delay: -10s;
        }
        
        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            25% { transform: translate(30px, -30px) scale(1.1); }
            50% { transform: translate(-20px, 20px) scale(0.9); }
            75% { transform: translate(20px, 30px) scale(1.05); }
        }
        
        /* Language Selector - Top Right */
        .language-selector {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 100;
        }
        
        .lang-dropdown {
            position: relative;
        }
        
        .lang-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 16px;
            background: var(--card-bg-color);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            color: var(--text-color);
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .lang-btn:hover {
            border-color: var(--accent-text-color);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
        }
        
        .lang-flag {
            font-size: 1.3rem;
            line-height: 1;
        }
        
        .lang-code {
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
        }
        
        .lang-btn .fa-chevron-down {
            font-size: 0.7rem;
            opacity: 0.6;
            transition: transform 0.3s ease;
        }
        
        .lang-dropdown.open .lang-btn .fa-chevron-down {
            transform: rotate(180deg);
        }
        
        .lang-menu {
            position: absolute;
            top: calc(100% + 8px);
            right: 0;
            min-width: 180px;
            background: var(--card-bg-color);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 8px;
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.3);
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
            z-index: 101;
        }
        
        .lang-dropdown.open .lang-menu {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        
        .lang-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 14px;
            color: var(--text-color);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.2s ease;
        }
        
        .lang-item:hover {
            background: var(--background-color);
        }
        
        .lang-item.active {
            background: var(--primary-alpha-015);
            color: var(--accent-text-color);
        }
        
        .lang-item .lang-name {
            flex: 1;
            font-size: 0.9rem;
        }
        
        .lang-item .fa-check {
            font-size: 0.8rem;
            color: var(--accent-text-color);
        }
        
        /* Main Container */
        .maintenance-container {
            position: relative;
            z-index: 1;
            max-width: 600px;
            width: 100%;
            text-align: center;
        }
        
        /* Logo */
        .logo-wrapper {
            margin-bottom: 30px;
        }
        
        .logo-wrapper img {
            max-height: 60px;
            width: auto;
        }
        
        .logo-wrapper .logo-text {
            font-size: 2rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        /* Icon */
        .maintenance-icon {
            width: 120px;
            height: 120px;
            margin: 0 auto 30px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            animation: pulse 2s infinite ease-in-out;
            box-shadow: 0 20px 60px var(--primary-alpha-03);
        }
        
        .maintenance-icon i {
            font-size: 3rem;
            color: var(--on-accent-color);
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); box-shadow: 0 20px 60px var(--primary-alpha-03); }
            50% { transform: scale(1.05); box-shadow: 0 25px 70px var(--primary-alpha-04); }
        }
        
        /* Content Card */
        .maintenance-card {
            background: var(--card-bg-color);
            border: 1px solid var(--border-color);
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 25px 80px rgba(0, 0, 0, 0.3);
        }
        
        .maintenance-title {
            font-size: 2rem;
            font-weight: 800;
            margin-bottom: 10px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .maintenance-subtitle {
            font-size: 1.1rem;
            opacity: 0.7;
            margin-bottom: 25px;
        }
        
        .maintenance-message {
            font-size: 1rem;
            line-height: 1.7;
            opacity: 0.85;
            margin-bottom: 30px;
            padding: 20px;
            background: var(--background-color);
            border-radius: 12px;
            border-left: 4px solid var(--primary-color);
            text-align: left;
        }
        
        /* Countdown */
        .countdown-wrapper {
            margin-bottom: 30px;
        }
        
        .countdown-label {
            font-size: 0.85rem;
            opacity: 0.6;
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .countdown {
            display: flex;
            justify-content: center;
            gap: 15px;
            flex-wrap: wrap;
        }
        
        .countdown-item {
            background: var(--background-color);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 15px 20px;
            min-width: 80px;
        }
        
        .countdown-item .number {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--accent-text-color);
            display: block;
        }
        
        .countdown-item .label {
            font-size: 0.75rem;
            opacity: 0.6;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        /* Progress Bar */
        .progress-wrapper {
            margin-bottom: 30px;
        }
        
        .progress-bar {
            height: 6px;
            background: var(--background-color);
            border-radius: 3px;
            overflow: hidden;
        }
        
        .progress-bar .progress {
            height: 100%;
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
            border-radius: 3px;
            animation: progress-animation 2s infinite ease-in-out;
            width: 30%;
        }
        
        @keyframes progress-animation {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(400%); }
        }
        
        /* Contact Section */
        .contact-section {
            margin-top: 30px;
            padding-top: 25px;
            border-top: 1px solid var(--border-color);
        }
        
        .contact-title {
            font-size: 0.85rem;
            opacity: 0.6;
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .contact-info {
            display: flex;
            justify-content: center;
            gap: 15px;
            flex-wrap: wrap;
        }
        
        .contact-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 20px;
            background: var(--background-color);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            font-size: 0.9rem;
            color: var(--text-color);
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .contact-item:hover {
            border-color: var(--accent-text-color);
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }
        
        .contact-item i {
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
        }
        
        .contact-item.email i {
            color: #ea4335;
        }
        
        .contact-item.phone i {
            color: #25d366;
        }
        
        .contact-item.whatsapp {
            background: rgba(37, 211, 102, 0.1);
            border-color: rgba(37, 211, 102, 0.3);
        }
        
        .contact-item.whatsapp:hover {
            background: #25d366;
            border-color: #25d366;
            color: #fff;
        }
        
        .contact-item.whatsapp i {
            color: #25d366;
        }
        
        .contact-item.whatsapp:hover i {
            color: #fff;
        }
        
        /* Footer */
        .maintenance-footer {
            margin-top: 30px;
            font-size: 0.85rem;
            opacity: 0.5;
        }
        
        /* Gear Animation */
        .gear-wrapper {
            position: fixed;
            bottom: 20px;
            right: 20px;
            opacity: 0.1;
            z-index: 0;
        }
        
        .gear-wrapper i {
            font-size: 100px;
            color: var(--accent-text-color);
            animation: rotate 10s linear infinite;
        }
        
        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .maintenance-card {
                padding: 30px 20px;
            }
            
            .maintenance-title {
                font-size: 1.6rem;
            }
            
            .maintenance-icon {
                width: 100px;
                height: 100px;
            }
            
            .maintenance-icon i {
                font-size: 2.5rem;
            }
            
            .countdown-item {
                min-width: 70px;
                padding: 12px 15px;
            }
            
            .countdown-item .number {
                font-size: 1.5rem;
            }
            
            .gear-wrapper {
                display: none;
            }
            
            .language-selector {
                top: 15px;
                right: 15px;
            }
            
            .lang-btn {
                padding: 8px 12px;
            }
            
            .lang-code {
                display: none;
            }
        }
        
        @media (max-width: 480px) {
            body {
                padding: 15px;
                padding-top: 70px;
            }
            
            .maintenance-title {
                font-size: 1.4rem;
            }
            
            .maintenance-subtitle {
                font-size: 1rem;
            }
            
            .countdown {
                gap: 10px;
            }
            
            .countdown-item {
                min-width: 60px;
                padding: 10px 12px;
            }
            
            .countdown-item .number {
                font-size: 1.3rem;
            }
            
            .contact-info {
                flex-direction: column;
                align-items: stretch;
            }
            
            .contact-item {
                justify-content: center;
            }
        }
    </style>
<link rel="stylesheet" href="/assets/css/theme-compat.css?v=1.3.1">
</head>
<body>
    <!-- Animated Background -->
    <div class="bg-animation">
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
    </div>
    
    <!-- Gear Animation -->
    <div class="gear-wrapper">
        <i class="fas fa-cog"></i>
    </div>
    
    <!-- Language Selector -->
    <?php if (count($languages) > 1): ?>
    <div class="language-selector">
        <div class="lang-dropdown" id="langDropdown">
            <button type="button" class="lang-btn" onclick="toggleLangDropdown()">
                <span class="lang-flag"><?php echo $currentLangData['flag'] ?? '🌐'; ?></span>
                <span class="lang-code"><?php echo strtoupper($currentLang); ?></span>
                <i class="fas fa-chevron-down"></i>
            </button>
            <div class="lang-menu">
                <?php foreach ($languages as $lang): ?>
                    <a href="?lang=<?php echo $lang['code']; ?>" class="lang-item <?php echo $lang['code'] === $currentLang ? 'active' : ''; ?>">
                        <span class="lang-flag"><?php echo $lang['flag']; ?></span>
                        <span class="lang-name"><?php echo $lang['native_name']; ?></span>
                        <?php if ($lang['code'] === $currentLang): ?>
                            <i class="fas fa-check"></i>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Main Container -->
    <div class="maintenance-container">
        <!-- Logo -->
        <div class="logo-wrapper">
            <?php if (!empty($siteLogo)): ?>
                <img src="<?php echo clean($siteLogo); ?>" alt="<?php echo clean($siteName); ?>">
            <?php else: ?>
                <span class="logo-text"><?php echo clean($siteName); ?></span>
            <?php endif; ?>
        </div>
        
        <!-- Icon -->
        <div class="maintenance-icon">
            <i class="fas fa-tools"></i>
        </div>
        
        <!-- Card -->
        <div class="maintenance-card">
            <h1 class="maintenance-title"><?php echo __('maintenance_title') ?: 'Bakım Çalışması'; ?></h1>
            <p class="maintenance-subtitle"><?php echo __('maintenance_subtitle') ?: 'Kısa süre içinde döneceğiz'; ?></p>
            
            <div class="maintenance-message">
                <?php echo nl2br(clean($maintenanceMessage)); ?>
            </div>
            
            <!-- Progress Bar -->
            <div class="progress-wrapper">
                <div class="progress-bar">
                    <div class="progress"></div>
                </div>
            </div>
            
            <?php if (!empty($maintenanceEndTime)): ?>
                <!-- Countdown -->
                <div class="countdown-wrapper">
                    <div class="countdown-label"><?php echo __('maintenance_end_estimate') ?: 'Tahmini bitiş'; ?></div>
                    <div class="countdown" id="countdown" data-end="<?php echo clean($maintenanceEndTime); ?>">
                        <div class="countdown-item">
                            <span class="number" id="days">00</span>
                            <span class="label"><?php echo __('days') ?: 'Gün'; ?></span>
                        </div>
                        <div class="countdown-item">
                            <span class="number" id="hours">00</span>
                            <span class="label"><?php echo __('hours') ?: 'Saat'; ?></span>
                        </div>
                        <div class="countdown-item">
                            <span class="number" id="minutes">00</span>
                            <span class="label"><?php echo __('minutes') ?: 'Dakika'; ?></span>
                        </div>
                        <div class="countdown-item">
                            <span class="number" id="seconds">00</span>
                            <span class="label"><?php echo __('seconds') ?: 'Saniye'; ?></span>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($siteEmail) || !empty($sitePhone)): ?>
                <!-- Contact Section -->
                <div class="contact-section">
                    <div class="contact-title"><?php echo __('contact_us') ?: 'İletişim'; ?></div>
                    <div class="contact-info">
                        <?php if (!empty($siteEmail)): ?>
                            <a href="mailto:<?php echo clean($siteEmail); ?>" class="contact-item email">
                                <i class="fas fa-envelope"></i>
                                <span><?php echo clean($siteEmail); ?></span>
                            </a>
                        <?php endif; ?>
                        
                        <?php if (!empty($sitePhone)): ?>
                            <a href="https://wa.me/<?php echo $whatsappNumber; ?>" target="_blank" class="contact-item whatsapp">
                                <i class="fab fa-whatsapp"></i>
                                <span><?php echo clean($sitePhone); ?></span>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Footer -->
        <div class="maintenance-footer">
            &copy; <?php echo date('Y'); ?> <?php echo clean($siteName); ?>
        </div>
    </div>
    
    <script>
        // Language Dropdown Toggle
        function toggleLangDropdown() {
            document.getElementById('langDropdown').classList.toggle('open');
        }
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            var langDropdown = document.getElementById('langDropdown');
            if (langDropdown && !langDropdown.contains(e.target)) {
                langDropdown.classList.remove('open');
            }
        });
        
        <?php if (!empty($maintenanceEndTime)): ?>
        // Countdown Timer
        function updateCountdown() {
            var countdownEl = document.getElementById('countdown');
            if (!countdownEl) return;
            
            var endTime = countdownEl.getAttribute('data-end');
            if (!endTime) return;
            
            var end = new Date(endTime).getTime();
            var now = new Date().getTime();
            var diff = end - now;
            
            if (diff <= 0) {
                document.getElementById('days').textContent = '00';
                document.getElementById('hours').textContent = '00';
                document.getElementById('minutes').textContent = '00';
                document.getElementById('seconds').textContent = '00';
                
                setTimeout(function() {
                    location.reload();
                }, 3000);
                return;
            }
            
            var days = Math.floor(diff / (1000 * 60 * 60 * 24));
            var hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((diff % (1000 * 60)) / 1000);
            
            document.getElementById('days').textContent = days.toString().padStart(2, '0');
            document.getElementById('hours').textContent = hours.toString().padStart(2, '0');
            document.getElementById('minutes').textContent = minutes.toString().padStart(2, '0');
            document.getElementById('seconds').textContent = seconds.toString().padStart(2, '0');
        }
        
        updateCountdown();
        setInterval(updateCountdown, 1000);
        <?php endif; ?>
    </script>
</body>
</html>