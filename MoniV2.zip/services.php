<?php
/**
 * Hizmetler Sayfası
 * Tüm servisleri listeler (giriş yapmadan da görüntülenebilir)
 */

require_once __DIR__ . '/config.php';

// Kategorileri getir
$categories = $db->query("
    SELECT c.*, COUNT(s.id) as service_count 
    FROM categories c 
    LEFT JOIN services s ON c.id = s.category_id AND s.status = 'active'
    WHERE c.status = 'active' 
    GROUP BY c.id 
    HAVING service_count > 0
    ORDER BY c.sort_order ASC, c.name ASC
")->fetchAll();

// Tüm aktif servisleri getir
$services = $db->query("
    SELECT 
        s.id, 
        s.category_id, 
        s.name, 
        IFNULL(s.description, '') as description,
        s.price_per_1000, 
        s.min_quantity, 
        s.max_quantity, 
        s.refill,
        c.name as category_name, 
        c.icon as category_icon,
        c.icon_color as category_color
    FROM services s
    LEFT JOIN categories c ON s.category_id = c.id
    WHERE s.status = 'active' AND c.status = 'active'
    ORDER BY c.sort_order, s.sort_order, s.name
")->fetchAll();

$minServicePrice = !empty($services) ? min(array_map(static fn($row) => (float)$row['price_per_1000'], $services)) : 0;
$refillServiceCount = count(array_filter($services, static fn($row) => !empty($row['refill'])));

// Servisleri kategorilere göre grupla
$servicesByCategory = [];
foreach ($services as $service) {
    $servicesByCategory[$service['category_id']][] = $service;
}

$pageTitle = __('services_page_title');
require_once 'includes/header.php';
?>

<style>
.services-page {
    max-width: 1400px;
    margin: 0 auto;
    padding: 40px 20px;
}

.page-header {
    text-align: center;
    margin-bottom: 40px;
}

.page-header h1 {
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 15px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.page-header p {
    font-size: 1.1rem;
    opacity: 0.7;
    max-width: 600px;
    margin: 0 auto;
}

/* Search Box */
.search-container {
    max-width: 500px;
    margin: 0 auto 40px;
}

.search-box {
    position: relative;
}

.search-box input {
    width: 100%;
    padding: 15px 20px 15px 50px;
    border: 2px solid var(--border-color);
    border-radius: 12px;
    background: var(--card-bg-color);
    color: var(--text-color);
    font-size: 1rem;
    transition: all 0.3s ease;
}

.search-box input:focus {
    outline: none;
    border-color: var(--accent-text-color);
    box-shadow: 0 0 0 4px var(--primary-alpha-01);
}

.search-box i {
    position: absolute;
    left: 18px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--text-color);
    opacity: 0.5;
}

/* Stats */
.services-stats {
    display: flex;
    justify-content: center;
    gap: 40px;
    margin-bottom: 40px;
    flex-wrap: wrap;
}

.stat-item {
    text-align: center;
}

.stat-item .number {
    font-size: 2rem;
    font-weight: 700;
    color: var(--accent-text-color);
}

.stat-item .label {
    font-size: 0.9rem;
    opacity: 0.6;
}

/* Category Tabs */
.category-tabs {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    justify-content: center;
    margin-bottom: 30px;
}

.category-tab {
    padding: 10px 20px;
    border-radius: 25px;
    background: var(--card-bg-color);
    border: 2px solid var(--border-color);
    color: var(--text-color);
    font-weight: 500;
    font-size: 0.9rem;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 8px;
}

.category-tab:hover {
    border-color: var(--accent-text-color);
    color: var(--accent-text-color);
}

.category-tab.active {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-color: transparent;
    color: var(--on-accent-color);
}

.category-tab .count {
    background: rgba(255, 255, 255, 0.2);
    padding: 2px 8px;
    border-radius: 10px;
    font-size: 0.75rem;
}

.category-tab.active .count {
    background: rgba(255, 255, 255, 0.3);
}

/* Category Sections */
.category-section {
    margin-bottom: 40px;
}

.category-header {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 2px solid var(--border-color);
}

.category-icon {
    width: 50px;
    height: 50px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-size: 1.3rem;
}

.category-header h2 {
    font-size: 1.4rem;
    font-weight: 600;
}

.category-header .service-count {
    margin-left: auto;
    background: var(--background-color);
    padding: 5px 15px;
    border-radius: 20px;
    font-size: 0.85rem;
    opacity: 0.7;
}

/* Services Table */
.services-table-wrapper {
    background: var(--card-bg-color);
    border-radius: 16px;
    border: 1px solid var(--border-color);
    overflow: hidden;
}

.services-table {
    width: 100%;
    border-collapse: collapse;
}

.services-table th {
    background: var(--background-color);
    padding: 15px 20px;
    text-align: left;
    font-weight: 600;
    font-size: 0.8rem;
    text-transform: uppercase;
    color: var(--text-color);
    opacity: 0.7;
    border-bottom: 1px solid var(--border-color);
}

.services-table td {
    padding: 18px 20px;
    border-bottom: 1px solid var(--border-color);
    vertical-align: middle;
}

.services-table tbody tr:last-child td {
    border-bottom: none;
}

.services-table tbody tr {
    transition: all 0.2s ease;
}

.services-table tbody tr:hover {
    background: var(--background-color);
}

.service-id {
    font-weight: 600;
    color: var(--accent-text-color);
    font-size: 0.9rem;
}

.service-name {
    font-weight: 600;
    margin-bottom: 5px;
}

.service-desc {
    font-size: 0.85rem;
    opacity: 0.6;
    max-width: 400px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.service-price {
    font-weight: 700;
    color: var(--success-color);
    font-size: 1.1rem;
}

.service-quantity {
    font-size: 0.85rem;
}

.service-quantity span {
    display: block;
    opacity: 0.7;
}

.service-badges {
    display: flex;
    gap: 8px;
}

.service-badge {
    padding: 4px 10px;
    border-radius: 15px;
    font-size: 0.7rem;
    font-weight: 600;
}

.service-badge.refill {
    background: rgba(40, 167, 69, 0.15);
    color: #28a745;
}

/* Mobile Cards */
.services-cards {
    display: none;
}

.service-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 15px;
}

.service-card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 12px;
}

.service-card-header .id {
    font-weight: 600;
    color: var(--accent-text-color);
    font-size: 0.85rem;
}

.service-card-header .price {
    font-weight: 700;
    color: var(--success-color);
    font-size: 1.1rem;
}

.service-card-body h4 {
    font-size: 1rem;
    font-weight: 600;
    margin-bottom: 8px;
}

.service-card-body p {
    font-size: 0.85rem;
    opacity: 0.6;
    margin-bottom: 12px;
    line-height: 1.5;
}

.service-card-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-top: 12px;
    border-top: 1px solid var(--border-color);
    font-size: 0.85rem;
}

.service-card-footer .quantity {
    opacity: 0.7;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 60px 20px;
}

.empty-state i {
    font-size: 4rem;
    opacity: 0.2;
    margin-bottom: 20px;
}

.empty-state h3 {
    font-size: 1.3rem;
    margin-bottom: 10px;
    opacity: 0.8;
}

.empty-state p {
    opacity: 0.6;
}

/* CTA Section */
.cta-section {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 20px;
    padding: 50px;
    text-align: center;
    margin-top: 50px;
    color: var(--on-accent-color);
}

.cta-section h2 {
    font-size: 1.8rem;
    margin-bottom: 15px;
}

.cta-section p {
    font-size: 1.1rem;
    opacity: 0.9;
    margin-bottom: 25px;
    max-width: 500px;
    margin-left: auto;
    margin-right: auto;
}

.cta-section .btn {
    background: var(--accent-action-bg-color);
    color: var(--accent-action-text-color);
    padding: 15px 35px;
    font-size: 1rem;
}

.cta-section .btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
}

/* Responsive */
@media (max-width: 992px) {
    .services-table-wrapper {
        display: none;
    }
    
    .services-cards {
        display: block;
    }
    
    .page-header h1 {
        font-size: 2rem;
    }
    
    .services-stats {
        gap: 25px;
    }
    
    .stat-item .number {
        font-size: 1.5rem;
    }
}

@media (max-width: 576px) {
    .services-page {
        padding: 25px 15px;
    }
    
    .page-header h1 {
        font-size: 1.6rem;
    }
    
    .category-tabs {
        justify-content: flex-start;
        overflow-x: auto;
        flex-wrap: nowrap;
        padding-bottom: 10px;
        -webkit-overflow-scrolling: touch;
    }
    
    .category-tab {
        flex-shrink: 0;
    }
    
    .cta-section {
        padding: 30px 20px;
    }
    
    .cta-section h2 {
        font-size: 1.4rem;
    }
}
</style>

<section class="public-page-hero"><div class="public-container public-page-hero-grid"><div><span class="public-eyebrow"><i class="fas fa-layer-group"></i> Güncel servis kataloğu</span><h1>Sosyal medya servislerini tek ekranda karşılaştır</h1><p>Aktif servisleri kategori, fiyat ve sipariş limitleriyle birlikte incele. Arama ve kategori filtreleriyle ihtiyacın olan hizmete hızlıca ulaş.</p><div class="hero-proof"><span><i class="fas fa-arrows-left-right"></i> Min–maks limitler</span><span><i class="fas fa-tag"></i> Güncel fiyatlar</span><span><i class="fas fa-rotate"></i> Refill bilgisi</span></div></div><div class="hero-summary"><div class="hero-summary-card"><i class="fas fa-layer-group"></i><strong><?php echo count($categories); ?></strong><span>Aktif kategori</span></div><div class="hero-summary-card"><i class="fas fa-list-check"></i><strong><?php echo count($services); ?></strong><span>Aktif servis</span></div><div class="hero-summary-card wide"><i class="fas fa-coins"></i><div><strong><?php echo $siteSettings['currency_symbol']; ?><?php echo number_format($minServicePrice,2); ?></strong><span>1000 adet için en düşük listelenen fiyat</span></div></div></div></div></section>
<div class="services-page">
    
    <div class="service-benefits"><div class="mini-benefit"><i class="fas fa-magnifying-glass"></i><strong>Hızlı arama</strong><span>Servis adı veya açıklamasında anında filtrele.</span></div><div class="mini-benefit"><i class="fas fa-table-cells-large"></i><strong>Kategori filtreleri</strong><span>Yalnız ihtiyacın olan platform servislerini göster.</span></div><div class="mini-benefit"><i class="fas fa-arrow-down-short-wide"></i><strong>Net limitler</strong><span>Minimum ve maksimum sipariş miktarını karşılaştır.</span></div><div class="mini-benefit"><i class="fas fa-rotate"></i><strong><?php echo $refillServiceCount; ?> refill servisi</strong><span>Refill destekleyen servisleri etiketinden ayırt et.</span></div></div>

    <!-- Search -->
    <div class="search-container">
        <div class="search-box">
            <i class="fas fa-search"></i>
            <input type="text" id="serviceSearch" placeholder="<?php echo __('services_search_placeholder'); ?>">
        </div>
    </div>
    
    <!-- Category Tabs -->
    <div class="category-tabs">
        <button class="category-tab active" data-category="all">
            <i class="fas fa-th-large"></i> <?php echo __('services_all'); ?>
            <span class="count"><?php echo count($services); ?></span>
        </button>
        <?php foreach ($categories as $cat): ?>
            <button class="category-tab" data-category="<?php echo $cat['id']; ?>">
                <i class="<?php echo $cat['icon'] ?: 'fas fa-folder'; ?>"></i>
                <?php echo clean($cat['name']); ?>
                <span class="count"><?php echo $cat['service_count']; ?></span>
            </button>
        <?php endforeach; ?>
    </div>
    
    <?php if (empty($services)): ?>
        <div class="empty-state">
            <i class="fas fa-box-open"></i>
            <h3><?php echo __('services_empty_title'); ?></h3>
            <p><?php echo __('services_empty_desc'); ?></p>
        </div>
    <?php else: ?>
        <!-- Category Sections -->
        <?php foreach ($categories as $cat): ?>
            <?php if (isset($servicesByCategory[$cat['id']])): ?>
                <div class="category-section" id="category-<?php echo (int)$cat['id']; ?>" data-category-id="<?php echo $cat['id']; ?>">
                    <div class="category-header">
                        <div class="category-icon" style="background: <?php echo $cat['icon_color'] ?: '#667eea'; ?>">
                            <i class="<?php echo $cat['icon'] ?: 'fas fa-folder'; ?>"></i>
                        </div>
                        <h2><?php echo clean($cat['name']); ?></h2>
                        <span class="service-count"><?php echo count($servicesByCategory[$cat['id']]); ?> <?php echo __('services_service_count'); ?></span>
                    </div>
                    
                    <!-- Desktop Table -->
                    <div class="services-table-wrapper">
                        <table class="services-table">
                            <thead>
                                <tr>
                                    <th><?php echo __('services_table_id'); ?></th>
                                    <th><?php echo __('services_table_service'); ?></th>
                                    <th><?php echo __('services_table_price'); ?></th>
                                    <th><?php echo __('services_table_minmax'); ?></th>
                                    <th><?php echo __('services_table_feature'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($servicesByCategory[$cat['id']] as $service): ?>
                                    <tr class="service-row" data-name="<?php echo strtolower(clean($service['name'])); ?>">
                                        <td><span class="service-id">#<?php echo $service['id']; ?></span></td>
                                        <td>
                                            <div class="service-name"><?php echo clean($service['name']); ?></div>
                                            <?php if (!empty($service['description'])): ?>
                                                <div class="service-desc"><?php echo clean($service['description']); ?></div>
                                            <?php endif; ?>
                                        </td>
                                        <td><span class="service-price"><?php echo $siteSettings['currency_symbol']; ?><?php echo number_format($service['price_per_1000'], 2); ?></span></td>
                                        <td class="service-quantity">
                                            <span><?php echo __('services_min'); ?>: <?php echo number_format($service['min_quantity']); ?></span>
                                            <span><?php echo __('services_max'); ?>: <?php echo number_format($service['max_quantity']); ?></span>
                                        </td>
                                        <td>
                                            <div class="service-badges">
                                                <?php if ($service['refill']): ?>
                                                    <span class="service-badge refill"><i class="fas fa-sync-alt"></i> <?php echo __('services_refill'); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Mobile Cards -->
                    <div class="services-cards">
                        <?php foreach ($servicesByCategory[$cat['id']] as $service): ?>
                            <div class="service-card" data-name="<?php echo strtolower(clean($service['name'])); ?>">
                                <div class="service-card-header">
                                    <span class="id">#<?php echo $service['id']; ?></span>
                                    <span class="price"><?php echo $siteSettings['currency_symbol']; ?><?php echo number_format($service['price_per_1000'], 2); ?></span>
                                </div>
                                <div class="service-card-body">
                                    <h4><?php echo clean($service['name']); ?></h4>
                                    <?php if (!empty($service['description'])): ?>
                                        <p><?php echo clean($service['description']); ?></p>
                                    <?php endif; ?>
                                    <?php if ($service['refill']): ?>
                                        <span class="service-badge refill"><i class="fas fa-sync-alt"></i> <?php echo __('services_refill'); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="service-card-footer">
                                    <span class="quantity"><?php echo __('services_min'); ?>: <?php echo number_format($service['min_quantity']); ?> / <?php echo __('services_max'); ?>: <?php echo number_format($service['max_quantity']); ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>
    <?php endif; ?>
    
    <!-- CTA Section -->
    <?php if (!isset($_SESSION['user_id'])): ?>
        <div class="cta-section">
            <h2><?php echo __('services_cta_guest_title'); ?></h2>
            <p><?php echo __('services_cta_guest_desc'); ?></p>
            <a href="<?php echo SITE_URL; ?>/register.php" class="btn">
                <i class="fas fa-user-plus"></i> <?php echo __('services_cta_guest_btn'); ?>
            </a>
        </div>
    <?php else: ?>
        <div class="cta-section">
            <h2><?php echo __('services_cta_user_title'); ?></h2>
            <p><?php echo __('services_cta_user_desc'); ?></p>
            <a href="<?php echo SITE_URL; ?>/kullanici/new-order.php" class="btn">
                <i class="fas fa-shopping-cart"></i> <?php echo __('services_cta_user_btn'); ?>
            </a>
        </div>
    <?php endif; ?>
</div>

<script>
// Category Filter
const categoryTabs = document.querySelectorAll('.category-tab');
const categorySections = document.querySelectorAll('.category-section');

categoryTabs.forEach(tab => {
    tab.addEventListener('click', function() {
        const category = this.dataset.category;
        
        // Update active tab
        categoryTabs.forEach(t => t.classList.remove('active'));
        this.classList.add('active');
        
        // Filter sections
        categorySections.forEach(section => {
            if (category === 'all' || section.dataset.categoryId === category) {
                section.style.display = 'block';
            } else {
                section.style.display = 'none';
            }
        });
    });
});

// Search
const searchInput = document.getElementById('serviceSearch');

searchInput.addEventListener('input', function() {
    const searchTerm = this.value.toLowerCase().trim();
    
    // Reset category filter to all
    categoryTabs.forEach(t => t.classList.remove('active'));
    document.querySelector('.category-tab[data-category="all"]').classList.add('active');
    categorySections.forEach(s => s.style.display = 'block');
    
    // Filter services
    document.querySelectorAll('.service-row, .service-card').forEach(item => {
        const name = item.dataset.name || '';
        if (name.includes(searchTerm) || searchTerm === '') {
            item.style.display = '';
        } else {
            item.style.display = 'none';
        }
    });
    
    // Hide empty categories
    categorySections.forEach(section => {
        const visibleRows = section.querySelectorAll('.service-row:not([style*="display: none"]), .service-card:not([style*="display: none"])');
        if (visibleRows.length === 0 && searchTerm !== '') {
            section.style.display = 'none';
        }
    });
});
</script>

<?php require_once 'includes/footer.php'; ?>