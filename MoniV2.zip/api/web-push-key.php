<?php
error_reporting(0);header('Content-Type: application/json; charset=utf-8');require_once __DIR__.'/../config.php';require_once __DIR__.'/../includes/MoniV2Compat.php';
if(!isLoggedIn()){http_response_code(401);echo json_encode(['ok'=>false]);exit;}$k=function_exists('moni_webpush_ensure_keys')?moni_webpush_ensure_keys($db):['public'=>''];echo json_encode(['ok'=>$k['public']!=='','public_key'=>$k['public']??'']);
