<?php
/** Moni Reseller API - güvenli SMM v2 */
error_reporting(0);ini_set('display_errors','0');header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';
$GLOBALS['moni_api_request_started']=microtime(true);$GLOBALS['moni_api_log_user_id']=0;$GLOBALS['moni_api_log_client_id']=0;$GLOBALS['moni_api_log_action']='';
function api_out($v,int $code=200){
    if(function_exists('moni_api_request_log') && function_exists('moni_plugin_enabled') && moni_plugin_enabled('customer_api_history',$GLOBALS['db']??null)){
        moni_api_request_log($GLOBALS['db'],[
            'api_client_id'=>(int)($GLOBALS['moni_api_log_client_id']??0),'user_id'=>(int)($GLOBALS['moni_api_log_user_id']??0),
            'endpoint'=>'/api/myservices.php','action'=>(string)($GLOBALS['moni_api_log_action']??''),'http_method'=>(string)($_SERVER['REQUEST_METHOD']??'GET'),
            'http_status'=>$code,'duration_ms'=>(int)round((microtime(true)-(float)($GLOBALS['moni_api_request_started']??microtime(true)))*1000),
            'request'=>array_merge($_GET,$_POST),'response'=>$v
        ]);
    }
    http_response_code($code);echo json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;
}
function api_ip_allowed(string $ip,string $rules):bool{
    $rules=trim($rules);if($rules==='')return true;
    foreach(preg_split('/[\s,;]+/',$rules,-1,PREG_SPLIT_NO_EMPTY) as $rule){
        if($rule===$ip)return true;
        if(str_contains($rule,'/')){
            [$net,$bitsRaw]=array_pad(explode('/',$rule,2),2,'');if(!ctype_digit($bitsRaw))continue;$bits=(int)$bitsRaw;
            $a=@inet_pton($ip);$b=@inet_pton($net);if($a===false||$b===false||strlen($a)!==strlen($b))continue;$max=strlen($a)*8;if($bits<0||$bits>$max)continue;
            $bytes=intdiv($bits,8);$rem=$bits%8;if($bytes>0&&substr($a,0,$bytes)!==substr($b,0,$bytes))continue;if($rem===0)return true;$mask=(0xFF << (8-$rem)) & 0xFF;if((ord($a[$bytes])&$mask)===(ord($b[$bytes])&$mask))return true;
        }
    }return false;
}
if(function_exists('moni_partial_maintenance_active')&&moni_partial_maintenance_active($db,'api',false))api_out(['error'=>moni_partial_maintenance_message($db,'api'),'maintenance'=>true],503);
$req=$_POST; // API anahtarı URL/query-string loglarına yazılmasın. Action GET'ten uyumluluk için alınabilir.
$action=trim((string)($_POST['action']??$_GET['action']??''));$GLOBALS['moni_api_log_action']=$action;
$auth=$_SERVER['HTTP_AUTHORIZATION']??'';$apiKey=trim((string)($_SERVER['HTTP_X_API_KEY']??$_POST['key']??''));if($apiKey===''&&preg_match('/^Bearer\s+(.+)$/i',$auth,$m))$apiKey=trim($m[1]);
if($apiKey==='')api_out(['error'=>'API key must be sent in POST, X-API-Key or Authorization header'],401);
$client=moni_api_client_auth($db,$apiKey);$userId=0;$clientId=0;$rate=300;
if($client){$userId=(int)$client['user_id'];$clientId=(int)$client['id'];$GLOBALS['moni_api_log_user_id']=$userId;$GLOBALS['moni_api_log_client_id']=$clientId;$rate=max(1,(int)($client['rate_limit_per_min']??300));if(function_exists('moni_premium_api_rate_limit'))$rate=moni_premium_api_rate_limit($db,$userId,$rate);if(!api_ip_allowed(moni_client_ip(),(string)($client['allowed_ips']??'')))api_out(['error'=>'IP address is not allowed'],403);}
if(!$userId)api_out(['error'=>'Invalid API Key'],401);
if(moni_table_ready($db,'api_rate_buckets')){try{$minute=date('Y-m-d H:i:00');$db->prepare("INSERT INTO api_rate_buckets(api_client_id,bucket_minute,request_count) VALUES(?,?,1) ON DUPLICATE KEY UPDATE request_count=request_count+1")->execute([$clientId,$minute]);$c=$db->prepare("SELECT request_count FROM api_rate_buckets WHERE api_client_id=? AND bucket_minute=?");$c->execute([$clientId,$minute]);if((int)$c->fetchColumn()>$rate)api_out(['error'=>'Rate limit exceeded'],429);}catch(Throwable $e){}}
$u=$db->prepare("SELECT * FROM users WHERE id=? AND status='active'");$u->execute([$userId]);$user=$u->fetch(PDO::FETCH_ASSOC);if(!$user)api_out(['error'=>'Account unavailable'],403);
if(function_exists('moni_user_can')&&!moni_user_can($db,$userId,'api.use',true))api_out(['error'=>'API access disabled for this account'],403);
if($action==='balance')api_out(['balance'=>(string)$user['balance'],'currency'=>moni_base_currency($db)]);
if($action==='services'){
    $lang=trim((string)($_POST['language']??$_GET['language']??''));if($lang!==''){try{$lq=$db->prepare("SELECT code FROM languages WHERE code=? AND is_active=1 LIMIT 1");$lq->execute([$lang]);if(!$lq->fetchColumn())$lang='';}catch(Throwable $e){$lang='';}}
    $rows=$db->query("SELECT s.*,c.name category FROM services s LEFT JOIN categories c ON c.id=s.category_id WHERE s.status='active' AND s.deleted_at IS NULL ORDER BY s.id")->fetchAll(PDO::FETCH_ASSOC);if(function_exists('moni_service_capacity_attach'))moni_service_capacity_attach($db,$rows);$out=[];
    foreach($rows as $s){if(function_exists('moni_service_visible_to_user')&&!moni_service_visible_to_user($db,(int)$s['id'],$userId))continue;$item=['service'=>(string)$s['id'],'name'=>$s['name'],'description'=>function_exists('moni_service_description')?moni_service_description($db,(int)$s['id'],(string)($s['description']??''),$lang!==''?$lang:null):(string)($s['description']??''),'type'=>$s['type']?:'default','category'=>$s['category']?:'General','rate'=>(string)moni_effective_price_per_1000($s,$userId),'min'=>(string)$s['min_quantity'],'max'=>(string)$s['max_quantity'],'increment'=>(string)max(1,(int)($s['quantity_increment']??1)),'dripfeed'=>(bool)$s['dripfeed'],'refill'=>(bool)$s['refill'],'cancel'=>(bool)$s['cancel']];if(function_exists('moni_service_price_tiers')){$tiers=moni_service_price_tiers($db,(int)$s['id'],true);if($tiers)$item['quantity_tiers']=array_map(static fn($t)=>['min'=>(int)$t['min_quantity'],'max'=>$t['max_quantity']!==null?(int)$t['max_quantity']:null,'type'=>$t['pricing_type'],'value'=>(float)$t['pricing_value']],$tiers);}if(!empty($s['geo_supported'])){$item['geo_supported']=true;$item['geo_targets']=function_exists('moni_service_geo_targets')?moni_service_geo_targets($s):[];}if(!empty($s['capacity'])){$item['capacity_status']=$s['capacity']['status'];$item['capacity_label']=$s['capacity']['label'];if(!empty($s['capacity']['show_exact']))$item['capacity_utilization']=(float)$s['capacity']['utilization'];}$out[]=$item;}api_out($out);
}
if($action==='add'){
    $serviceId=(int)($_POST['service']??0);$link=trim((string)($_POST['link']??''));$qty=(int)($_POST['quantity']??0);$drip=!empty($_POST['dripfeed']);$runs=(int)($_POST['runs']??1);$interval=(int)($_POST['interval']??1);$idem=(string)($_SERVER['HTTP_IDEMPOTENCY_KEY']??$_POST['idempotency_key']??'');
    if(!$serviceId||$link===''||!$qty)api_out(['error'=>'Missing parameters'],400);
    $r=moni_place_order($db,$userId,$serviceId,$link,$qty,['dripfeed'=>$drip,'runs'=>$runs,'interval'=>$interval,'idempotency_key'=>$idem,'source'=>'reseller-api','geo_target'=>(string)($_POST['geo_target']??'')]);if(!$r['success'])api_out(['error'=>$r['error']],400);api_out(['order'=>(int)($r['order_id']?:$r['dripfeed_id']??0),'status'=>'pending','queued'=>!empty($r['queued']),'warning'=>$r['warning']??null]);
}
if($action==='status'){$id=(int)($_POST['order']??$_GET['order']??0);$s=$db->prepare("SELECT status,start_count,remains,quantity,refund_amount FROM orders WHERE id=? AND user_id=?");$s->execute([$id,$userId]);$o=$s->fetch(PDO::FETCH_ASSOC);if(!$o)api_out(['error'=>'Order not found'],404);api_out(['status'=>(string)$o['status'],'start_count'=>(string)($o['start_count']??0),'remains'=>(string)($o['remains']??0),'currency'=>moni_base_currency($db)]);}
if($action==='cancel'){
    $id=(int)($_POST['order']??0);
    $r=moni_cancel_user_order($db,$id,$userId,'API cancellation');
    if(!$r['success'])api_out(['error'=>$r['error']??'Cancellation failed'],409);
    if(!empty($r['queued'])){
        api_out(['cancel'=>'queued','queued'=>true,'status'=>'queued','refund_amount'=>0]);
    }
    api_out(['cancel'=>true,'queued'=>false,'status'=>'cancelled','refund_amount'=>$r['refund_amount']??0]);
}
if($action==='refill'){$id=(int)($_POST['order']??0);$s=$db->prepare("SELECT o.*,s.refill FROM orders o JOIN services s ON s.id=o.service_id WHERE o.id=? AND o.user_id=?");$s->execute([$id,$userId]);$o=$s->fetch(PDO::FETCH_ASSOC);if(!$o)api_out(['error'=>'Order not found'],404);if(!(int)$o['refill'])api_out(['error'=>'Refill is not supported'],400);$r=moni_provider_refill($db,$o);if(!$r['success'])api_out(['error'=>$r['error']??'Refill failed'],409);api_out(['refill'=>$r['data']['refill']??true]);}
api_out(['error'=>'Invalid action'],400);
