<?php
error_reporting(0);ini_set('display_errors','0');header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/../config.php';require_once __DIR__.'/../includes/MoniV2Compat.php';
if(!isLoggedIn()){http_response_code(401);echo json_encode(['ok'=>false,'error'=>'Oturum gerekli.']);exit;}
if(!function_exists('moni_plugin_enabled')||!moni_plugin_enabled('target_preview',$db)){http_response_code(404);echo json_encode(['ok'=>false,'error'=>'Hedef Canlı Önizleme eklentisi kapalı.'],JSON_UNESCAPED_UNICODE);exit;}
if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST'){http_response_code(405);echo json_encode(['ok'=>false,'error'=>'POST gerekli.']);exit;}
if(!validateCSRFToken((string)($_POST['csrf_token']??$_SERVER['HTTP_X_CSRF_TOKEN']??''))){http_response_code(419);echo json_encode(['ok'=>false,'error'=>'Güvenlik doğrulaması başarısız.']);exit;}
$url=trim((string)($_POST['url']??''));$sid=(int)($_POST['service_id']??0);
if(!preg_match('#^https?://#i',$url))$url='https://'.ltrim($url,'/');
$p=@parse_url($url);$scheme=strtolower((string)($p['scheme']??''));$host=(string)($p['host']??'');
if(!in_array($scheme,['http','https'],true)||$host===''||!empty($p['user'])||!empty($p['pass'])){http_response_code(422);echo json_encode(['ok'=>false,'error'=>'Geçerli bir HTTP/HTTPS hedef bağlantısı girin.'],JSON_UNESCAPED_UNICODE);exit;}
if($sid>0&&function_exists('moni_validate_service_target')){$v=moni_validate_service_target($db,$sid,$url,(int)$_SESSION['user_id'],'target-preview');if(empty($v['ok'])){http_response_code(422);echo json_encode(['ok'=>false,'error'=>$v['error']??'Hedef bu servis için kullanılamaz.'],JSON_UNESCAPED_UNICODE);exit;}}
echo json_encode(['ok'=>true,'url'=>$url,'host'=>$host,'mode'=>'browser_iframe'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
