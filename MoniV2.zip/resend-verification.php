<?php
/**
 * E-Posta Doğrulama Yeniden Gönder
 * - Aynı hesaba 30 saniyede 1 kez gönderim (cooldown)
 * - Türkiye saat dilimi (Europe/Istanbul)
 */

date_default_timezone_set('Europe/Istanbul');

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/MoniV2Compat.php';
require_once __DIR__ . '/includes/mail.php';

$pageTitle = 'E-Posta Doğrulama Yeniden Gönder';

$emailVerificationEnabled = true;
if (function_exists('getSetting')) {
    $emailVerificationEnabled = (bool) getSetting('email_verification_enabled', 1);
}
if (!$emailVerificationEnabled) {
    die('E-posta doğrulama devre dışı.');
}

$error = '';
$success = '';
$prefillEmail = trim($_GET['email'] ?? '');

function generateEmailToken(): string {
    return bin2hex(random_bytes(32)); // 64 hex
}

/**
 * sendTemplateEmail bool dönebileceği için sonucu array olarak sarmalıyoruz.
 */
function sendVerificationEmailAgain(string $email, string $token, string $username = 'Kullanıcı'): array {
    $siteUrl = rtrim((string)(defined('SITE_URL') ? SITE_URL : ''), '/');
    if (!filter_var($siteUrl, FILTER_VALIDATE_URL)) $siteUrl = rtrim((string)getSetting('site_url',''), '/');
    if (!filter_var($siteUrl, FILTER_VALIDATE_URL)) return ['success'=>false,'message'=>'SITE_URL yapılandırılmamış.'];
    $verifyUrl = $siteUrl . '/verify-email.php?token=' . urlencode($token);

    $res = sendTemplateEmail($email, 'email_verification', [
        'username'    => $username,
        'verify_link' => $verifyUrl,
        'site_url'    => $siteUrl,
        'site_name'   => $GLOBALS['siteSettings']['name'] ?? 'Site',
        'year'        => date('Y'),
    ]);

    if (is_bool($res)) {
        return $res ? ['success' => true, 'message' => 'OK'] : ['success' => false, 'message' => 'Gönderilemedi'];
    }
    return $res;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $prefillEmail = $email;

    $captchaError='';
    if (!moni_captcha_verify_request($db,$captchaError)) {
        $error = $captchaError;
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Geçerli bir e-posta girin.';
    } else {
        // Kullanıcıyı bul
        $stmt = $db->prepare("SELECT id, username, email_verified FROM users WHERE email = ? AND status = 'active' LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || (int)$user['email_verified'] === 1) {
            // Hesap varlığını dışarı sızdırma: aynı genel cevap.
            $success = 'Uygun bir hesap varsa doğrulama e-postası gönderildi.';
        } else {
            try {
                // Cooldown: 30 saniye içinde gönderim varsa engelle
                $coolStmt = $db->prepare("SELECT created_at FROM email_verification_tokens WHERE user_id = ? ORDER BY id DESC LIMIT 1");
                $coolStmt->execute([$user['id']]);
                $last = $coolStmt->fetch();
                if ($last && (time() - strtotime($last['created_at']) < 30)) {
                    throw new Exception('30 saniye içinde birden fazla doğrulama e-postası gönderilemez.');
                }

                $db->beginTransaction();

                // Eski açık tokenları kapat (opsiyonel ama önerilir)
                $db->prepare("UPDATE email_verification_tokens SET used = 1 WHERE user_id = ? AND used = 0")->execute([$user['id']]);

                $token   = generateEmailToken();
                $expires = (new DateTime('+1 day'))->format('Y-m-d H:i:s');

                $db->prepare("INSERT INTO email_verification_tokens (user_id, token, expires_at) VALUES (?, ?, ?)")
                   ->execute([$user['id'], hash('sha256',$token), $expires]);

                $db->commit();

                // Mail gönder (hata olsa bile token geçerli kalsın)
                $sendRes = sendVerificationEmailAgain($email, $token, $user['username']);
                if (empty($sendRes['success'])) {
                    $success = 'Uygun bir hesap varsa doğrulama e-postası gönderildi.';
                } else {
                    $success = 'Uygun bir hesap varsa doğrulama e-postası gönderildi.';
                }

            } catch (Exception $e) {
                if ($db->inTransaction()) $db->rollBack();
                $success = 'Uygun bir hesap varsa doğrulama e-postası gönderildi.';
            }
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>
<style>
    .verify-wrapper {
        min-height: calc(100vh - 140px);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 40px 16px;
        background: radial-gradient(circle at 20% 20%, rgba(255,255,255,0.04), transparent 35%),
                    radial-gradient(circle at 80% 0%, rgba(255,255,255,0.03), transparent 30%),
                    radial-gradient(circle at 50% 100%, rgba(255,255,255,0.05), transparent 35%),
                    var(--background-color);
    }
    .verify-card {
        width: 100%; max-width: 520px;
        background: var(--card-bg-color);
        border: 1px solid var(--border-color);
        border-radius: 18px;
        box-shadow: 0 25px 80px rgba(0,0,0,0.25);
        padding: 32px 28px;
    }
    .verify-title { font-size: 1.4rem; font-weight: 700; color: var(--text-color); margin-bottom: 8px; text-align: center; }
    .verify-sub   { text-align: center; color: var(--text-color); opacity: 0.75; margin-bottom: 22px; }
    .form-group { margin-bottom: 18px; }
    .form-label { display: block; margin-bottom: 8px; font-weight: 600; color: var(--text-color); }
    .input-control {
        width: 100%; padding: 14px 16px;
        border: 2px solid var(--border-color);
        border-radius: 12px;
        background: var(--background-color);
        color: var(--text-color);
        transition: all 0.25s ease;
    }
    .input-control:focus { outline: none; border-color: var(--accent-text-color); box-shadow: 0 0 0 4px var(--primary-alpha-01); }
    .btn-primary {
        width: 100%; padding: 14px; border: none; border-radius: 12px;
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        color: var(--on-accent-color); font-weight: 700; cursor: pointer; transition: all 0.25s ease;
        display: inline-flex; align-items: center; justify-content: center; gap: 8px;
    }
    .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 10px 25px var(--primary-alpha-035); }
    .alert {
        padding: 14px 16px; border-radius: 12px; margin-bottom: 16px;
        display: flex; align-items: center; gap: 10px; font-weight: 600;
    }
    .alert-success { background: rgba(40,167,69,0.12); border: 1px solid rgba(40,167,69,0.35); color: var(--success-color); }
    .alert-danger  { background: rgba(220,53,69,0.12); border: 1px solid rgba(220,53,69,0.35); color: var(--danger-color); }
</style>

<div class="verify-wrapper">
    <div class="verify-card">
        <div class="verify-title">E-Posta Doğrulama Yeniden Gönder</div>
        <div class="verify-sub">E-posta adresinizi girin; 30 saniyede bir yeni bağlantı gönderebilirsiniz.</div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i><?php echo clean($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i><?php echo clean($success); ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label class="form-label">Kayıtlı E-posta</label>
                <input type="email" name="email" class="input-control" required value="<?php echo clean($prefillEmail); ?>" placeholder="ornek@email.com">
            </div>
            <?=moni_captcha_render($db)?>
            <button type="submit" class="btn-primary">
                <i class="fas fa-envelope"></i> Doğrulama Maili Gönder
            </button>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>