<?php
require_once __DIR__.'/config.php';
require_once __DIR__ . '/includes/MoniV2Compat.php';
if (!function_exists('moni_openapi_document')) { require_once __DIR__ . '/includes/MoniV2Ops.php'; }
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: public, max-age=300');
if(!function_exists('moni_openapi_document')){http_response_code(503);echo json_encode(['error'=>'OpenAPI özelliği hazır değil.']);exit;}
echo json_encode(moni_openapi_document(),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
