<?php
return ['slug'=>'child_panels','name'=>'Child Panel / Alt Panel','description'=>'Bayiye özel domain, marka ve fiyat marjıyla alt panel oluşturma ve yönetme sistemi.','version'=>'1.0.0','default_enabled'=>false];
