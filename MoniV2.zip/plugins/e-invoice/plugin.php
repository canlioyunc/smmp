<?php
return [
 'slug'=>'e_invoice',
 'name'=>'e-Fatura / e-Arşiv',
 'description'=>'Başarılı ödemeler için harici e-belge sağlayıcısı entegrasyonu ve belge kuyruğu.',
 'version'=>'1.0.0',
 'default_enabled'=>false
];
