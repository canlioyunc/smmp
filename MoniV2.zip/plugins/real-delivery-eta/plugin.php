<?php
return ['slug'=>'real_delivery_eta','name'=>'Gerçek Teslim Süresi Tahmini','description'=>'Tamamlanan gerçek siparişlerden medyan teslim süresi tahmini üretir. Temiz kurulumda pasif, demo modunda aktiftir.','version'=>'2.0.0','default_enabled'=>false];
