<?php
return [
 'slug'=>'telegram_miniapp','name'=>'Telegram Mini App','description'=>'Telegram Mini App üzerinden güvenli kullanıcı paneli erişimi.',
 'version'=>'1.0.0','default_enabled'=>false
];
