<?php
return [
 'slug'=>'same_target_concurrency',
 'name'=>'Aynı Hedefte Eşzamanlı Sipariş Koruması',
 'description'=>'Aynı kullanıcı, servis ve hedef için önceki aktif sipariş tamamlanmadan yeni eşzamanlı sipariş açılmasını engeller.',
 'version'=>'1.0.0',
 'default_enabled'=>false
];
