<?php
return [
 'slug'=>'order_status_reasons','name'=>'Sipariş Durum Neden Kodları',
 'description'=>'Durum değişikliklerini standart neden kodları, provider eşleme kuralları, kullanıcı açıklamaları ve değişmez geçmiş ile açıklar.',
 'version'=>'1.0.0','default_enabled'=>false
];
