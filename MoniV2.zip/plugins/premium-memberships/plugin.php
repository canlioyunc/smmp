<?php
return [
    'slug'=>'premium_memberships',
    'name'=>'Premium Üyelik Sistemi',
    'description'=>'Paket bazlı sipariş önceliği, servis/kategori indirimi, özel servis erişimi, API hız avantajı, rozet, deneme, yükseltme/düşürme ve gelişmiş cashback motoru.',
    'version'=>'3.0.0',
    'default_enabled'=>true
];
