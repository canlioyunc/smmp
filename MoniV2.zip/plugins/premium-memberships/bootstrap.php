<?php
require_once dirname(__DIR__,2).'/includes/MoniPremium.php';
if(isset($db) && $db instanceof PDO) moni_premium_runtime_migrate($db);
