<?php
return [
 'slug'=>'duplicate_order_warning',
 'name'=>'Mükerrer Sipariş Uyarısı',
 'description'=>'Aynı servis ve link için aktif sipariş bulunduğunda kullanıcıyı uyarır; engellemez.',
 'version'=>'1.0.0',
 'default_enabled'=>true
];
