<?php
return ['slug'=>'customer_api_history','name'=>'Müşteri API İstek Geçmişi','description'=>'Müşteri API çağrılarını gizli alanları sansürleyerek durum, süre ve endpoint bilgisiyle kaydeder.','version'=>'2.0.0','default_enabled'=>false];
