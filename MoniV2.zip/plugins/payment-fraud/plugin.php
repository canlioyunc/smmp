<?php
return [
 'slug'=>'payment_fraud',
 'name'=>'Ödeme Hız / Fraud Limitleri',
 'description'=>'Ödeme deneme sıklığı ve günlük tutar kurallarıyla risk kontrolü.',
 'version'=>'1.0.0',
 'default_enabled'=>false
];
