<?php
return [
 'slug'=>'provider_failover',
 'name'=>'Otomatik Sağlayıcı Failover',
 'description'=>'Sağlayıcı hata verdiğinde tanımlı yedek rotalara otomatik geçer.',
 'version'=>'1.0.0',
 'default_enabled'=>false
];
