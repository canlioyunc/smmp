<?php
return ['slug'=>'real_count_completion','name'=>'Gerçek Sayıya Göre Otomatik Tamamlama','description'=>'Gerçek hedef sayısı sipariş hedefini karşıladığında siparişi otomatik tamamlar.','version'=>'1.0.0','default_enabled'=>true];
