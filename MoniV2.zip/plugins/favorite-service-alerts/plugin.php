<?php
return ['slug'=>'favorite_service_alerts','name'=>'Favori Servis Fiyat / Durum Alarmı','description'=>'Favoriye alınan servislerin fiyatı veya durumu değiştiğinde kullanıcıyı bilgilendirir.','version'=>'2.0.0','default_enabled'=>true];
