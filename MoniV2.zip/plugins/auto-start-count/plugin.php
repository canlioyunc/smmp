<?php
return ['slug'=>'auto_start_count','name'=>'Otomatik Başlangıç Sayısı Tespiti','description'=>'Sipariş oluşturulurken hedef bağlantının başlangıç metriğini güvenli şekilde tespit etmeyi dener.','version'=>'1.0.0','default_enabled'=>true];
