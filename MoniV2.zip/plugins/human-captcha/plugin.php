<?php
return ['slug'=>'human_captcha','name'=>'Turnstile / hCaptcha','description'=>'Giriş, kayıt ve hesap kurtarma formlarında Cloudflare Turnstile veya hCaptcha doğrulaması sağlar.','version'=>'2.0.0','default_enabled'=>false];
