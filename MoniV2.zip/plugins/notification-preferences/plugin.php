<?php
return ['slug'=>'notification_preferences','name'=>'Bildirim Tercih Merkezi','description'=>'Kullanıcıların sipariş, ödeme, destek, servis alarmı ve pazarlama bildirimlerini kategori bazında yönetmesini sağlar.','version'=>'2.0.0','default_enabled'=>true];
