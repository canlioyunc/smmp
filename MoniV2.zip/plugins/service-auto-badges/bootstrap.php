<?php
if(defined('MONI_SERVICE_AUTO_BADGES_PLUGIN'))return;define('MONI_SERVICE_AUTO_BADGES_PLUGIN',true);
function moni_service_auto_badges_for(PDO $db,int $serviceId):array{
    static $cache=[];if(isset($cache[$serviceId]))return $cache[$serviceId];
    if(!moni_table_ready($db,'service_auto_badges'))return $cache[$serviceId]=[];
    try{$s=$db->prepare("SELECT badge_key,label,icon,score,reason,calculated_at FROM service_auto_badges WHERE service_id=? ORDER BY score DESC,badge_key LIMIT 6");$s->execute([$serviceId]);return $cache[$serviceId]=$s->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){return $cache[$serviceId]=[];}
}
function moni_service_auto_badges_attach(PDO $db,array &$rows):void{foreach($rows as &$r)$r['auto_badges']=moni_service_auto_badges_for($db,(int)$r['id']);unset($r);}
function moni_service_auto_badges_settings(PDO $db):array{return [
 'min_sample'=>max(3,(int)moni_plugin_setting('service_auto_badges','auto_badge_min_sample',10)),
 'fast_seconds'=>max(60,(int)moni_plugin_setting('service_auto_badges','auto_badge_fast_seconds',3600)),
 'stable_score'=>max(0,min(100,(float)moni_plugin_setting('service_auto_badges','auto_badge_stable_score',90))),
 'low_drop'=>max(0,(float)moni_plugin_setting('service_auto_badges','auto_badge_low_drop_percent',2.5)),
 'popular_30d'=>max(1,(int)moni_plugin_setting('service_auto_badges','auto_badge_popular_30d_orders',50)),
 'best_price_percentile'=>max(1,min(50,(int)moni_plugin_setting('service_auto_badges','auto_badge_best_price_percentile',20))),
 'max_badges'=>max(1,min(6,(int)moni_plugin_setting('service_auto_badges','auto_badge_max_per_service',3)))
];}
function moni_recalculate_service_auto_badges(PDO $db,int $batch=300):array{
    if(!moni_table_ready($db,'service_auto_badges'))return ['processed'=>0,'badges'=>0];$cfg=moni_service_auto_badges_settings($db);$batch=max(1,min(5000,$batch));
    $sql="SELECT s.id,s.category_id,s.price_per_1000,q.quality_score,q.sample_size,q.avg_completion_seconds,d.sample_orders,d.average_drop_percent,(SELECT COUNT(*) FROM orders o WHERE o.service_id=s.id AND o.created_at>=DATE_SUB(NOW(),INTERVAL 30 DAY)) orders30,(SELECT MAX(b.calculated_at) FROM service_auto_badges b WHERE b.service_id=s.id) last_badged FROM services s LEFT JOIN service_quality_metrics q ON q.service_id=s.id LEFT JOIN service_drop_metrics d ON d.service_id=s.id WHERE s.status='active' AND s.deleted_at IS NULL ORDER BY COALESCE(last_badged,'1970-01-01') ASC,s.id ASC LIMIT {$batch}";
    $rows=$db->query($sql)->fetchAll(PDO::FETCH_ASSOC);$processed=0;$count=0;
    foreach($rows as $r){$badges=[];$sample=(int)($r['sample_size']??0);$price=(float)($r['price_per_1000']??0);
        if($sample>=$cfg['min_sample']&&(float)($r['quality_score']??0)>=$cfg['stable_score'])$badges[]=['stable','En Stabil','fa-shield-heart',(float)$r['quality_score'],'Kalite puanı '.number_format((float)$r['quality_score'],1).'/100'];
        if($sample>=$cfg['min_sample']&&(int)($r['avg_completion_seconds']??0)>0&&(int)$r['avg_completion_seconds']<=$cfg['fast_seconds']){$score=max(1,100-((int)$r['avg_completion_seconds']/$cfg['fast_seconds']*45));$badges[]=['fast','Hızlı','fa-bolt',$score,'Ortalama tamamlanma '.moni_human_duration((int)$r['avg_completion_seconds'])];}
        if((int)($r['sample_orders']??0)>=$cfg['min_sample']&&(float)($r['average_drop_percent']??999)<=$cfg['low_drop']){$score=max(1,100-(float)$r['average_drop_percent']*8);$badges[]=['low_drop','Düşük Drop','fa-arrow-trend-down',$score,'Ortalama drop %'.number_format((float)$r['average_drop_percent'],2)];}
        if((int)$r['orders30']>=$cfg['popular_30d']){$score=min(100,50+((int)$r['orders30']/$cfg['popular_30d'])*20);$badges[]=['popular','Popüler','fa-fire',$score,'Son 30 günde '.(int)$r['orders30'].' sipariş'];}
        if($price>0){try{$q=$db->prepare("SELECT price_per_1000 FROM services WHERE category_id=? AND status='active' AND deleted_at IS NULL AND price_per_1000>0 ORDER BY price_per_1000 ASC");$q->execute([(int)$r['category_id']]);$prices=array_map('floatval',$q->fetchAll(PDO::FETCH_COLUMN));if(count($prices)>=3){$idx=max(0,(int)ceil(count($prices)*($cfg['best_price_percentile']/100))-1);$threshold=$prices[min($idx,count($prices)-1)];if($price<=$threshold)$badges[]=['best_price','En İyi Fiyat','fa-tag',88,'Kategori içindeki en uygun %'.$cfg['best_price_percentile'].' fiyat diliminde'];}}catch(Throwable $ignore){}}
        usort($badges,fn($a,$b)=>$b[3]<=>$a[3]);$badges=array_slice($badges,0,$cfg['max_badges']);$db->beginTransaction();try{$db->prepare("DELETE FROM service_auto_badges WHERE service_id=?")->execute([(int)$r['id']]);$ins=$db->prepare("INSERT INTO service_auto_badges(service_id,badge_key,label,icon,score,reason,calculated_at) VALUES(?,?,?,?,?,?,NOW())");foreach($badges as $b){$ins->execute([(int)$r['id'],$b[0],$b[1],$b[2],round($b[3],2),$b[4]]);$count++;}$db->commit();}catch(Throwable $e){if($db->inTransaction())$db->rollBack();}$processed++;
    }
    return ['processed'=>$processed,'badges'=>$count];
}
