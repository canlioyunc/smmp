<?php
return [
 'slug'=>'service_auto_badges','name'=>'Otomatik Servis Rozet Motoru',
 'description'=>'Gerçek sipariş, kalite, hız, drop ve talep verilerinden Hızlı, Stabil, Düşük Drop ve Popüler rozetlerini otomatik üretir.',
 'version'=>'1.0.0','default_enabled'=>false
];
