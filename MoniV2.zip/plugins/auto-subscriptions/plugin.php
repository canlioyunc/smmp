<?php
return ['slug'=>'auto_subscriptions','name'=>'Otomatik Abonelik / Auto Subscription','description'=>'Profilde yeni içerik algılandığında belirlenen servisten otomatik sipariş üretir.','version'=>'1.0.0','default_enabled'=>true];
