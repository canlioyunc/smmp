<?php
return [
 'slug'=>'tax_vat',
 'name'=>'Vergi / KDV Profilleri',
 'description'=>'Vergi profilleri ve kullanıcı vergi bilgilerini etkinleştirir.',
 'version'=>'1.0.0',
 'default_enabled'=>false
];
