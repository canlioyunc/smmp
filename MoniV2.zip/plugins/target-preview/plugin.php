<?php
return [
 'slug'=>'target_preview',
 'name'=>'Hedef Canlı Önizleme',
 'description'=>"Girilen hedef URL'yi sunucudan veri çekmeden kullanıcı tarayıcısında küçük, güvenli bir tarayıcı önizlemesi olarak açar. Tüm HTTP/HTTPS platformlarında çalışır; platform iframe kullanımını engellerse yeni sekmede açma seçeneği sunar. Demo modunda otomatik aktiftir.",
 'version'=>'3.2.0',
 'default_enabled'=>false
];
