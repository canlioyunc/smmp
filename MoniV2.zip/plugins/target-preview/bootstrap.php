<?php
/** Hedef Canlı Önizleme v3.2: önizleme doğrudan kullanıcının tarayıcısında iframe ile açılır. */
if (!defined('MONI_TARGET_PREVIEW_LOADED')) define('MONI_TARGET_PREVIEW_LOADED', true);
