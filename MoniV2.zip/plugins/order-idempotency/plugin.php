<?php
return [
 'slug'=>'order_idempotency',
 'name'=>'Sipariş Idempotency',
 'description'=>'Aynı sipariş isteğinin tekrar işlenmesini engeller.',
 'version'=>'1.0.0',
 'default_enabled'=>true
];
