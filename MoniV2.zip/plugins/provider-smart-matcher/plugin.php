<?php
return ['slug'=>'provider_smart_matcher','name'=>'Akıllı Provider Servis Eşleştirme','description'=>'Sağlayıcı kataloğundaki servisleri yerel servislerle isim, limit ve benzerlik puanına göre eşleştirme önerileri üretir.','version'=>'2.0.0','default_enabled'=>true];
