<?php
/**
 * SMM Panel - Giriş Yap
 */

require_once 'config.php';
require_once __DIR__ . '/includes/MoniV2Compat.php';
require_once __DIR__ . '/includes/MoniThemeCompat.php';

/* ==========================================================================
   Google Authenticator Helper Class (Login içinde kullanım için)
   ========================================================================== */
if (!class_exists('GoogleAuthenticator')) {
    class GoogleAuthenticator {
        protected $_codeLength = 6;

        public function getCode($secret, $time = null) {
            if (!$time) {
                $time = floor(time() / 30);
            }
            $base32 = new FixedBitNotation(5, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567', TRUE, TRUE);
            $secret = $base32->decode($secret);
            $time = pack("N", $time);
            $time = str_pad($time, 8, chr(0), STR_PAD_LEFT);
            $hash = hash_hmac('sha1', $time, $secret, true);
            $offset = ord(substr($hash, -1));
            $offset = $offset & 0xF;
            $hash = substr($hash, $offset, 4);
            $value = unpack('N', $hash);
            $value = $value[1];
            $value = $value & 0x7FFFFFFF;
            $modulo = pow(10, $this->_codeLength);
            return str_pad($value % $modulo, $this->_codeLength, '0', STR_PAD_LEFT);
        }

        public function verifyCode($secret, $code, $discrepancy = 1, $currentTimeSlice = null) {
            if ($currentTimeSlice === null) {
                $currentTimeSlice = floor(time() / 30);
            }
            if (strlen($code) != 6) {
                return false;
            }
            for ($i = -$discrepancy; $i <= $discrepancy; ++$i) {
                $calculatedCode = $this->getCode($secret, $currentTimeSlice + $i);
                if ($this->timingSafeEquals($calculatedCode, $code)) {
                    return true;
                }
            }
            return false;
        }

        private function timingSafeEquals($safeString, $userString) {
            if (function_exists('hash_equals')) {
                return hash_equals($safeString, $userString);
            }
            $safeLen = strlen($safeString);
            $userLen = strlen($userString);
            if ($userLen != $safeLen) {
                return false;
            }
            $result = 0;
            for ($i = 0; $i < $userLen; ++$i) {
                $result |= (ord($safeString[$i]) ^ ord($userString[$i]));
            }
            return $result === 0;
        }
    }
}

if (!class_exists('FixedBitNotation')) {
    class FixedBitNotation {
        protected $_chars;
        protected $_rightPadFinalBits;
        protected $_padFinalGroup;
        protected $_padChar;

        public function __construct($bits, $chars = NULL, $rightPadFinalBits = FALSE, $padFinalGroup = FALSE, $padChar = '=') {
            $this->_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
            $this->_rightPadFinalBits = $rightPadFinalBits;
            $this->_padFinalGroup = $padFinalGroup;
            $this->_padChar = $padChar;
        }

        public function decode($string) {
            $string = strtoupper($string);
            $chars = $this->_chars;
            $charMap = array_flip(str_split($chars));
            $bin = "";
            $len = strlen($string);
            $padding = 0;
            for ($i = 0; $i < $len; $i++) {
                $char = $string[$i];
                if ($char == $this->_padChar) {
                    $padding++;
                    continue;
                }
                if (!isset($charMap[$char])) return false;
                $bin .= sprintf("%05b", $charMap[$char]);
            }
            $binLen = strlen($bin);
            $bytes = "";
            for ($i = 0; $i < $binLen; $i += 8) {
                if ($i + 8 > $binLen) break;
                $bytes .= chr(bindec(substr($bin, $i, 8)));
            }
            return $bytes;
        }
    }
}
/* ==========================================================================
   Bitiş: Helper Classes
   ========================================================================== */

// ===== SOSYAL LOGIN - SocialAuth Sınıfını Yükle =====
$googleEnabled = false;
$discordEnabled = false;

if (file_exists(__DIR__ . '/classes/SocialAuth.php')) {
    require_once __DIR__ . '/classes/SocialAuth.php';
    $socialAuth = new SocialAuth($db);
    $googleEnabled = $socialAuth->isEnabled('google');
    $discordEnabled = $socialAuth->isEnabled('discord');
}
// ===== SOSYAL LOGIN SON =====

// E-posta doğrulama ayarı (settings yoksa varsayılan açık)
$emailVerificationEnabled = true;
if (function_exists('getSetting')) {
    $emailVerificationEnabled = (bool) getSetting('email_verification_enabled', 1);
}

// Zaten giriş yapmışsa yönlendir
if (isLoggedIn()) {
    header('Location: ' . (isAdmin() ? '/admin/' : '/kullanici/'));
    exit;
}

$error = '';
$needVerificationLink = false;
$pendingEmail = '';
$showTwoFactorForm = false; // 2FA Formunu göstermek için bayrak

// ===== SOSYAL LOGIN - Hata mesajı kontrolü =====
if (isset($_GET['error'])) {
    $error = clean($_GET['error']);
}
// ===== SOSYAL LOGIN SON =====

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['send_email_2fa']) && isset($_SESSION['2fa_pending_user_id'])) {
        $uid=(int)$_SESSION['2fa_pending_user_id'];$st=$db->prepare("SELECT id,email,email_two_factor_enabled FROM users WHERE id=? AND status='active' LIMIT 1");$st->execute([$uid]);$eu=$st->fetch(PDO::FETCH_ASSOC);
        if($eu && !empty($eu['email_two_factor_enabled']) && moni_email_2fa_send($db,$eu)){$success2fa='E-posta doğrulama kodu gönderildi.';}else{$error='E-posta doğrulama kodu gönderilemedi.';}
        $showTwoFactorForm=true;
    } elseif (isset($_POST['verify_2fa_code']) && isset($_SESSION['2fa_pending_user_id'])) {
        $otpCode = trim((string)($_POST['otp_code'] ?? ''));
        $userId = (int)$_SESSION['2fa_pending_user_id'];
        $remember = !empty($_SESSION['2fa_remember']);
        $twoFactorKey='2fa:'.$userId;
        [$twoFactorBlocked]=moni_auth_blocked($db,$twoFactorKey,moni_client_ip());
        if($twoFactorBlocked){
            moni_security_event($userId,'two_factor_rate_limited','warning');
            $error='Çok fazla hatalı doğrulama kodu denendi. 15 dakika sonra tekrar deneyin.';
            $showTwoFactorForm=true;
            $user=null;
        } else {
        $stmt = $db->prepare("SELECT * FROM users WHERE id=? AND status='active' LIMIT 1");
        $stmt->execute([$userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$user || $otpCode === '') {
            $error = $otpCode === '' ? __('login_2fa_error_empty') : __('login_2fa_error_user_not_found');
            $showTwoFactorForm = (bool)$user;
        } else {
            $ga = new GoogleAuthenticator();
            $secret = moni_decrypt_secret((string)($user['two_factor_secret']??''));
            $totpOk = !empty($user['two_factor_enabled']) && $secret !== '' && $ga->verifyCode($secret, $otpCode);
            $emailOk = !empty($user['email_two_factor_enabled']) && moni_email_2fa_verify($db,$userId,$otpCode);
            if ($totpOk || $emailOk) {
                moni_auth_record($db,$twoFactorKey,moni_client_ip(),true);
                unset($_SESSION['2fa_pending_user_id'], $_SESSION['2fa_remember']);
                moni_complete_login($db, $user, $remember, $totpOk?'password+totp':'password+email2fa');
                header('Location: ' . ($user['role'] === 'admin' ? '/admin/' : '/kullanici/'));
                exit;
            }
            moni_auth_record($db,$twoFactorKey,moni_client_ip(),false);
            moni_security_event($userId, 'two_factor_failed', 'warning');
            $error = __('login_2fa_error_invalid');
            $showTwoFactorForm = true;
        }
        } // 2FA hız limiti
    } elseif (isset($_POST['login_attempt'])) {
        $username = trim((string)($_POST['username'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        $remember = isset($_POST['remember']);
        $captchaError='';
        if (!moni_captcha_verify_request($db,$captchaError)) {
            $error = $captchaError;
        } elseif ($username === '' || $password === '') {
            $error = __('login_error_empty');
        } else {
            [$blocked] = moni_auth_blocked($db, $username, moni_client_ip());
            if ($blocked) {
                $error = 'Çok fazla başarısız giriş denemesi yapıldı. 15 dakika sonra tekrar deneyin.';
                moni_security_event(null, 'login_rate_limited', 'warning', ['identifier_hash'=>hash('sha256', mb_strtolower($username, 'UTF-8'))]);
            } else {
                $stmt = $db->prepare("SELECT * FROM users WHERE (username=? OR email=?) LIMIT 1");
                $stmt->execute([$username, $username]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($user && $user['status'] === 'active' && password_verify($password, $user['password'])) {
                    moni_auth_record($db, $username, moni_client_ip(), true);
                    if ($emailVerificationEnabled && isset($user['email_verified']) && (int)$user['email_verified'] !== 1) {
                        $error = __('login_error_email_not_verified');
                        $needVerificationLink = true;
                        $pendingEmail = $user['email'];
                    } elseif (!empty($user['two_factor_enabled']) || !empty($user['email_two_factor_enabled'])) {
                        $_SESSION['2fa_pending_user_id']=(int)$user['id'];$_SESSION['2fa_remember']=$remember;$showTwoFactorForm=true;
                        if(empty($user['two_factor_enabled']) && !empty($user['email_two_factor_enabled'])) moni_email_2fa_send($db,$user);
                    } else {
                        moni_complete_login($db, $user, $remember, 'password');
                        header('Location: ' . ($user['role'] === 'admin' ? '/admin/' : '/kullanici/'));
                        exit;
                    }
                } else {
                    moni_auth_record($db, $username, moni_client_ip(), false);
                    moni_security_event($user ? (int)$user['id'] : null, 'login_failed', 'warning', ['identifier_hash'=>hash('sha256', mb_strtolower($username, 'UTF-8'))]);
                    $error = ($user && $user['status'] !== 'active') ? __('login_error_inactive') : __('login_error_invalid');
                }
            }
        }
    }
}

// Sayfa başlığı için çeviri
$pageTitle = __('login_page_title');
?>
<!DOCTYPE html>
<html lang="<?php echo getCurrentLanguage(); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> - <?php echo clean($siteSettings['name']); ?></title>
    <?php if(function_exists('moni_pwa_head_tags')) echo moni_pwa_head_tags($db); ?>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        <?php echo generateCSSVariables($activeTheme); ?>
        <?php echo moni_theme_compat_css($activeTheme); ?>
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--background-color);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }
        
        /* Animated Background */
        .bg-animation {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 0;
            overflow: hidden;
        }
        
        .bg-animation::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at 20% 80%, var(--primary-color) 0%, transparent 40%),
                        radial-gradient(circle at 80% 20%, var(--secondary-color) 0%, transparent 40%),
                        radial-gradient(circle at 50% 50%, var(--primary-color) 0%, transparent 30%);
            opacity: 0.08;
            animation: bgRotate 30s linear infinite;
        }
        
        @keyframes bgRotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .auth-container {
            width: 100%;
            max-width: 420px;
            position: relative;
            z-index: 1;
        }
        
        .auth-card {
            background: var(--card-bg-color);
            border-radius: 24px;
            padding: 50px 40px;
            box-shadow: 0 25px 80px rgba(0, 0, 0, 0.25);
            border: 1px solid var(--border-color);
        }
        
        .auth-header {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .auth-logo {
            width: 75px;
            height: 75px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 25px;
            font-size: 2rem;
            color: var(--on-accent-color);
            box-shadow: 0 10px 40px var(--primary-alpha-03);
        }
        
        .auth-header h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--text-color);
            margin-bottom: 8px;
        }
        
        .auth-header p {
            color: var(--text-color);
            opacity: 0.6;
            font-size: 0.95rem;
        }
        
        .alert {
            padding: 15px 18px;
            border-radius: 12px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 0.9rem;
            animation: shake 0.4s ease-in-out;
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }
        
        .alert-danger {
            background: rgba(220, 53, 69, 0.12);
            border: 1px solid rgba(220, 53, 69, 0.3);
            color: #dc3545;
        }
        
        .alert-success {
            background: rgba(40, 167, 69, 0.12);
            border: 1px solid rgba(40, 167, 69, 0.3);
            color: #28a745;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 10px;
            font-weight: 500;
            color: var(--text-color);
            font-size: 0.9rem;
        }
        
        .input-group {
            position: relative;
        }
        
        .input-group i.input-icon {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-color);
            opacity: 0.4;
            transition: all 0.3s ease;
            pointer-events: none;
        }
        
        .input-group input {
            width: 100%;
            padding: 16px 18px 16px 50px;
            border: 2px solid var(--border-color);
            border-radius: 12px;
            background: var(--background-color);
            color: var(--text-color);
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .input-group input:focus {
            outline: none;
            border-color: var(--accent-text-color);
            box-shadow: 0 0 0 4px var(--primary-alpha-01);
        }
        
        .input-group input:focus + i.input-icon {
            color: var(--accent-text-color);
            opacity: 1;
        }
        
        .input-group input::placeholder {
            color: var(--text-color);
            opacity: 0.4;
        }
        
        .password-toggle {
            position: absolute;
            right: 18px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--text-color);
            opacity: 0.4;
            cursor: pointer;
            padding: 5px;
            transition: opacity 0.3s ease;
        }
        
        .password-toggle:hover {
            opacity: 0.8;
        }
        
        .form-options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            font-size: 0.9rem;
        }
        
        .remember-me {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text-color);
            cursor: pointer;
        }
        
        .remember-me input {
            width: 18px;
            height: 18px;
            accent-color: var(--accent-text-color);
            cursor: pointer;
        }
        
        .forgot-password {
            color: var(--accent-text-color);
            text-decoration: none;
            font-weight: 500;
            transition: opacity 0.3s ease;
        }
        
        .forgot-password:hover {
            opacity: 0.8;
        }
        
        .btn-login {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            border-radius: 12px;
            color: var(--on-accent-color);
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .btn-login:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px var(--primary-alpha-04);
        }
        
        .btn-login:active {
            transform: translateY(-1px);
        }
        
        .btn-resend {
            width: 100%;
            padding: 14px;
            margin-top: 10px;
            background: transparent;
            border: 1px solid var(--primary-color);
            color: var(--accent-text-color);
            border-radius: 12px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.25s ease;
        }
        
        .btn-resend:hover {
            background: var(--primary-alpha-008);
        }
        
        /* ===== SOSYAL LOGIN STİLLERİ ===== */
        .social-divider {
            display: flex;
            align-items: center;
            margin: 25px 0;
            gap: 15px;
        }
        
        .social-divider::before,
        .social-divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: var(--border-color);
        }
        
        .social-divider span {
            color: var(--text-color);
            opacity: 0.5;
            font-size: 0.85rem;
            white-space: nowrap;
        }
        
        .social-buttons {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        
        .btn-social {
            width: 100%;
            padding: 14px 20px;
            border: 2px solid var(--border-color);
            border-radius: 12px;
            background: var(--background-color);
            color: var(--text-color);
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            text-decoration: none;
        }
        
        .btn-social:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
        }
        
        .btn-social.google {
            border-color: #DB4437;
            color: #DB4437;
        }
        
        .btn-social.google:hover {
            background: #DB4437;
            color: #fff;
        }
        
        .btn-social.discord {
            border-color: #5865F2;
            color: #5865F2;
        }
        
        .btn-social.discord:hover {
            background: #5865F2;
            color: #fff;
        }
        
        .btn-social i {
            font-size: 1.2rem;
        }
        /* ===== SOSYAL LOGIN STİLLERİ SON ===== */
        
        .auth-footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 25px;
            border-top: 1px solid var(--border-color);
        }
        
        .auth-footer p {
            color: var(--text-color);
            opacity: 0.7;
            font-size: 0.95rem;
        }
        
        .auth-footer a {
            color: var(--accent-text-color);
            text-decoration: none;
            font-weight: 600;
            transition: opacity 0.3s ease;
        }
        
        .auth-footer a:hover {
            opacity: 0.8;
        }
        
        .back-home {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--text-color);
            opacity: 0.6;
            text-decoration: none;
            font-size: 0.9rem;
            margin-top: 20px;
            transition: all 0.3s ease;
        }
        
        .back-home:hover {
            opacity: 1;
            color: var(--accent-text-color);
        }
        
        .security-note {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 14px;
            background: var(--background-color);
            border-radius: 10px;
            margin-top: 20px;
            font-size: 0.85rem;
            color: var(--text-color);
            opacity: 0.7;
        }
        
        .security-note i {
            color: var(--success-color);
        }
        
        @media (max-width: 480px) {
            .auth-card {
                padding: 35px 25px;
            }
            
            .auth-header h1 {
                font-size: 1.5rem;
            }
            
            .form-options {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }
        }
    </style>
<link rel="stylesheet" href="/assets/css/theme-compat.css?v=1.3.1">
</head>
<body>
    <div class="bg-animation"></div>
    
    <div class="auth-container">
        <div class="auth-card">
            
            <?php if ($showTwoFactorForm): ?>
            <!-- =========================== -->
            <!-- 2FA DOĞRULAMA FORMU -->
            <!-- =========================== -->
            <div class="auth-header">
                <div class="auth-logo">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <h1><?php echo __('login_2fa_heading'); ?></h1>
                <p><?php echo __('login_2fa_subheading'); ?></p>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i><?php echo clean($error); ?></div>
            <?php endif; ?>
            <?php if (!empty($success2fa)): ?><div class="alert alert-success"><i class="fas fa-envelope"></i><?php echo clean($success2fa); ?></div><?php endif; ?>

            <form method="POST">
                <input type="hidden" name="verify_2fa_code" value="1">
                
                <div class="form-group">
                    <label class="form-label"><?php echo __('login_2fa_label'); ?></label>
                    <div class="input-group">
                        <input type="text" name="otp_code" placeholder="<?php echo __('login_2fa_placeholder'); ?>" required autocomplete="off" autofocus maxlength="6" pattern="\d*">
                        <i class="fas fa-key input-icon"></i>
                    </div>
                </div>

                <button type="submit" class="btn-login">
                    <i class="fas fa-unlock"></i>
                    <?php echo __('login_2fa_btn_verify'); ?>
                </button>
            </form>
            <?php if(isset($_SESSION['2fa_pending_user_id'])): $es=$db->prepare("SELECT email_two_factor_enabled FROM users WHERE id=?");$es->execute([(int)$_SESSION['2fa_pending_user_id']]); if((int)$es->fetchColumn()===1): ?>
            <form method="POST" style="margin-top:12px"><button type="submit" name="send_email_2fa" class="btn-login" style="background:var(--card-bg-color);color:var(--text-color);border:1px solid var(--border-color)"><i class="fas fa-envelope"></i> E-posta ile kod gönder</button></form>
            <?php endif; endif; ?>

            <div class="auth-footer">
                <a href="/login.php" class="back-home">
                    <i class="fas fa-arrow-left"></i>
                    <?php echo __('login_2fa_back'); ?>
                </a>
            </div>

            <?php else: ?>
            <!-- =========================== -->
            <!-- NORMAL GİRİŞ FORMU -->
            <!-- =========================== -->
            <div class="auth-header">
                <div class="auth-logo">
                    <i class="fas fa-bolt"></i>
                </div>
                <h1><?php echo __('login_heading'); ?></h1>
                <p><?php echo __('login_subheading'); ?></p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo clean($error); ?>
                </div>
                <?php if ($needVerificationLink && $pendingEmail): ?>
                    <a class="btn-resend" href="/resend-verification.php?email=<?php echo urlencode($pendingEmail); ?>">
                        <i class="fas fa-envelope"></i> <?php echo __('login_resend_email'); ?>
                    </a>
                <?php endif; ?>
            <?php endif; ?>
            
            <?php if (isset($_GET['registered'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo __('login_success_registered'); ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['logout'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo __('login_success_logout'); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST">
                <input type="hidden" name="login_attempt" value="1">

                <div class="form-group">
                    <label class="form-label"><?php echo __('login_label_username'); ?></label>
                    <div class="input-group">
                        <input type="text" name="username" placeholder="<?php echo __('login_placeholder_username'); ?>" required 
                               value="<?php echo clean($_POST['username'] ?? ''); ?>">
                        <i class="fas fa-user input-icon"></i>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php echo __('login_label_password'); ?></label>
                    <div class="input-group">
                        <input type="password" name="password" id="password" placeholder="••••••••" required>
                        <i class="fas fa-lock input-icon"></i>
                        <button type="button" class="password-toggle" onclick="togglePassword()">
                            <i class="fas fa-eye" id="toggleIcon"></i>
                        </button>
                    </div>
                </div>
                
                <div class="form-options">
                    <label class="remember-me">
                        <input type="checkbox" name="remember">
                        <?php echo __('login_remember_me'); ?>
                    </label>
                    <a href="forgot-password.php" class="forgot-password"><?php echo __('login_forgot_password'); ?></a>
                </div>
                
                <?=moni_captcha_render($db)?>
                <button type="submit" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i>
                    <?php echo __('login_btn_submit'); ?>
                </button>
            </form>

            <div class="social-divider"><span>veya</span></div>
            <button type="button" class="btn-login" id="passkeyLoginBtn" style="background:var(--card-bg-color);color:var(--text-color);border:2px solid var(--border-color);box-shadow:none;">
                <i class="fas fa-fingerprint"></i> Passkey ile Giriş
            </button>
            
            <!-- ===== SOSYAL LOGIN BUTONLARI (GİRİŞ YAP ALTINDA) ===== -->
            <?php if ($googleEnabled || $discordEnabled): ?>
                <div class="social-divider">
                    <span><?php echo __('login_social_divider'); ?></span>
                </div>
                
                <div class="social-buttons">
                    <?php if ($googleEnabled): ?>
                        <a href="/auth/google/" class="btn-social google">
                            <i class="fab fa-google"></i>
                            <?php echo __('login_btn_google'); ?>
                        </a>
                    <?php endif; ?>
                    
                    <?php if ($discordEnabled): ?>
                        <a href="/auth/discord/" class="btn-social discord">
                            <i class="fab fa-discord"></i>
                            <?php echo __('login_btn_discord'); ?>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <!-- ===== SOSYAL LOGIN BUTONLARI SON ===== -->
            
            <div class="security-note">
                <i class="fas fa-shield-alt"></i>
                <span><?php echo __('login_security_note'); ?></span>
            </div>
            
            <div class="auth-footer">
                <p><?php echo __('login_no_account'); ?> <a href="register.php"><?php echo __('login_register_link'); ?></a></p>
                <a href="/" class="back-home">
                    <i class="fas fa-arrow-left"></i>
                    <?php echo __('login_back_home'); ?>
                </a>
            </div>
            <?php endif; ?> <!-- IF showTwoFactorForm Bitişi -->
        </div>
    </div>
    
    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const toggleIcon = document.getElementById('toggleIcon');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }
        
        // Enter tuşu ile form gönderimi
        document.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                document.querySelector('.btn-login')?.click();
            }
        });

        function b64uToBuf(v) {
            v = v.replace(/-/g,'+').replace(/_/g,'/');
            while (v.length % 4) v += '=';
            const bin = atob(v), out = new Uint8Array(bin.length);
            for (let i=0;i<bin.length;i++) out[i]=bin.charCodeAt(i);
            return out.buffer;
        }
        function bufToB64u(v) {
            const bytes = new Uint8Array(v); let s='';
            bytes.forEach(b => s += String.fromCharCode(b));
            return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
        }
        document.getElementById('passkeyLoginBtn')?.addEventListener('click', async function () {
            const identifier = document.querySelector('input[name="username"]')?.value.trim();
            if (!identifier) { alert('Önce kullanıcı adı veya e-posta adresinizi yazın.'); return; }
            if (!window.PublicKeyCredential) { alert('Bu tarayıcı Passkey/WebAuthn desteklemiyor.'); return; }
            try {
                const r = await fetch('/webauthn.php', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'auth_options',identifier})});
                const opt = await r.json(); if (!opt.success) throw new Error(opt.error || 'Passkey başlatılamadı.');
                opt.publicKey.challenge = b64uToBuf(opt.publicKey.challenge);
                opt.publicKey.allowCredentials = (opt.publicKey.allowCredentials||[]).map(x => ({...x,id:b64uToBuf(x.id)}));
                const cred = await navigator.credentials.get({publicKey:opt.publicKey});
                const finish = await fetch('/webauthn.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'auth_finish',credentialId:bufToB64u(cred.rawId),clientDataJSON:bufToB64u(cred.response.clientDataJSON),authenticatorData:bufToB64u(cred.response.authenticatorData),signature:bufToB64u(cred.response.signature)})});
                const done = await finish.json(); if (!done.success) throw new Error(done.error || 'Passkey doğrulanamadı.');
                location.href = done.redirect || '/kullanici/';
            } catch (e) { if (e.name !== 'NotAllowedError') alert(e.message || 'Passkey işlemi tamamlanamadı.'); }
        });

    </script>
</body>
</html>