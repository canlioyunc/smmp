<?php
require_once __DIR__.'/config.php';
require_once __DIR__.'/includes/MoniV2Compat.php';
$p=moni_pwa_config($db);
if(empty($p['enabled'])){http_response_code(404);exit;}
header('Content-Type: image/svg+xml; charset=utf-8');
header('Cache-Control: public, max-age=3600');
$bg=preg_match('/^#[0-9a-fA-F]{6}$/',(string)$p['theme_color'])?$p['theme_color']:'#6c5ce7';
$name=trim((string)$p['short_name']);$letter=mb_strtoupper(mb_substr($name!==''?$name:'M',0,1,'UTF-8'),'UTF-8');
$letter=htmlspecialchars($letter,ENT_QUOTES|ENT_XML1,'UTF-8');
echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" rx="112" fill="'.$bg.'"/><circle cx="256" cy="256" r="154" fill="rgba(255,255,255,.13)"/><text x="256" y="322" text-anchor="middle" font-family="Arial,sans-serif" font-size="250" font-weight="700" fill="#fff">'.$letter.'</text></svg>';
