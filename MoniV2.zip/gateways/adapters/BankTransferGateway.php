<?php
return new class implements MoniGatewayAdapter {
    public function slug():string{return 'bank_transfer';}
    public function title():string{return 'Banka Havalesi';}
    public function createPayment(PDO $db,int $userId,float $amount,array $context=[]):array{return ['success'=>true,'manual'=>true];}
    public function verifyCallback(PDO $db,array $payload,array $server=[]):array{return ['success'=>false,'error'=>'Manuel ödeme yöntemi callback kullanmaz.'];}
};
