<?php
return new class implements MoniGatewayAdapter {
    public function slug(): string { return 'iyzico'; }
    public function title(): string { return 'iyzico'; }

    private function bootstrap(): void {
        if (class_exists('Iyzipay\\Options')) return;
        $path = dirname(__DIR__, 2) . '/lib/iyzipay/';
        require_once $path . 'IyzipayBootstrap.php';
        \IyzipayBootstrap::init($path . 'src');
    }

    private function method(PDO $db, bool $requireActive=true, int $childPanelId=0): array {
        if($childPanelId>0 && function_exists('moni_child_panel_payment_config')){$cp=moni_child_panel_payment_config($db,'iyzico',$childPanelId,$requireActive);if($cp){$cfg=$cp['config']??[];if(($cfg['api_key']??'')===''||($cfg['secret_key']??'')==='')throw new RuntimeException('Child Panel iyzico API bilgileri yapılandırılmamış.');return [$cp,$cfg];}}
        $sql="SELECT * FROM payment_methods WHERE type='iyzico'".($requireActive?" AND status='active'":"")." ORDER BY id LIMIT 1";
        $st = $db->query($sql);
        $method = $st->fetch(PDO::FETCH_ASSOC);
        if (!$method) throw new RuntimeException('iyzico ödeme yöntemi aktif değil.');
        $cfg = json_decode($method['config'] ?? '{}', true) ?: [];
        $cfg['api_key'] = moni_decrypt_secret((string)($cfg['api_key'] ?? ''));
        $cfg['secret_key'] = moni_decrypt_secret((string)($cfg['secret_key'] ?? ''));
        // Yeni adaptör ayarları varsa eski payment_methods ayarlarını ezmeden üzerine bindir.
        // Boş adaptör alanları eski çalışan ayarları silmez.
        $adapterCfg = moni_gateway_config($db, 'iyzico');
        foreach ($adapterCfg as $key => $value) {
            if ($value !== '' && $value !== null) $cfg[$key] = $value;
        }
        if (($cfg['api_key'] ?? '') === '' || ($cfg['secret_key'] ?? '') === '') throw new RuntimeException('iyzico API bilgileri yapılandırılmamış.');
        return [$method, $cfg];
    }

    private function options(array $cfg): \Iyzipay\Options {
        $o = new \Iyzipay\Options();
        $o->setApiKey($cfg['api_key']);
        $o->setSecretKey($cfg['secret_key']);
        $o->setBaseUrl($cfg['base_url'] ?? 'https://api.iyzipay.com');
        return $o;
    }

    public function createPayment(PDO $db, int $userId, float $amount, array $context=[]): array {
        try {
            $this->bootstrap();
            $childPanelId=(int)($context['child_panel_id']??0);[$method, $cfg] = $this->method($db,true,$childPanelId);
            $user = $context['user'] ?? null;
            if (!$user) {
                $st=$db->prepare("SELECT * FROM users WHERE id=? AND status='active'");$st->execute([$userId]);$user=$st->fetch(PDO::FETCH_ASSOC);
            }
            if (!$user) throw new RuntimeException('Kullanıcı bulunamadı.');
            $credit=(float)($context['credit_amount'] ?? $amount);
            $packageId=(int)($context['package_id'] ?? 0);
            $packageName=(string)($context['package_name'] ?? 'Bakiye Yükleme');
            $callback=(string)($context['callback_url'] ?? '');
            if ($callback==='') throw new RuntimeException('Callback adresi eksik.');

            $conversation='FUND_'.$userId.'_'.bin2hex(random_bytes(8));
            $basket='B'.bin2hex(random_bytes(6));
            $parts=preg_split('/\s+/',trim((string)($user['username']??'')));
            $first=$parts[0]?:'Müşteri';$last=$parts[1]??'Kullanıcı';

            $request=new \Iyzipay\Request\CreateCheckoutFormInitializeRequest();
            $request->setLocale(\Iyzipay\Model\Locale::TR);
            $request->setConversationId($conversation);
            $request->setPrice(number_format($amount,2,'.',''));
            $request->setPaidPrice(number_format($amount,2,'.',''));
            $request->setCurrency(\Iyzipay\Model\Currency::TL);
            $request->setBasketId($basket);
            $request->setPaymentGroup(\Iyzipay\Model\PaymentGroup::PRODUCT);
            $request->setCallbackUrl($callback);
            $request->setEnabledInstallments([1]);

            $buyer=new \Iyzipay\Model\Buyer();
            $buyer->setId('BY'.$userId);$buyer->setName($first);$buyer->setSurname($last);
            $buyer->setGsmNumber(($user['phone']??'')?:'+905000000000');$buyer->setEmail((string)$user['email']);
            $buyer->setIdentityNumber('11111111111');$buyer->setLastLoginDate(date('Y-m-d H:i:s'));
            $buyer->setRegistrationDate(date('Y-m-d H:i:s',strtotime($user['created_at']??'now')));
            $buyer->setRegistrationAddress((string)($context['address']??'Türkiye'));
            $buyer->setIp(moni_client_ip()?:'127.0.0.1');$buyer->setCity((string)($context['city']??'İstanbul'));
            $buyer->setCountry((string)($context['country']??'Turkey'));$buyer->setZipCode((string)($context['zip']??'34000'));
            $request->setBuyer($buyer);

            $addr=new \Iyzipay\Model\Address();$addr->setContactName(trim($first.' '.$last));
            $addr->setCity((string)($context['city']??'İstanbul'));$addr->setCountry((string)($context['country']??'Turkey'));
            $addr->setAddress((string)($context['address']??'Türkiye'));$addr->setZipCode((string)($context['zip']??'34000'));
            $request->setBillingAddress($addr);$request->setShippingAddress($addr);

            $item=new \Iyzipay\Model\BasketItem();$item->setId($packageId?'PKG_'.$packageId:'BALANCE_'.$basket);
            $item->setName($packageName);$item->setCategory1('Dijital Hizmet');$item->setItemType(\Iyzipay\Model\BasketItemType::VIRTUAL);
            $item->setPrice(number_format($amount,2,'.',''));$request->setBasketItems([$item]);

            $init=\Iyzipay\Model\CheckoutFormInitialize::create($request,$this->options($cfg));
            if($init->getStatus()!=='success') throw new RuntimeException($init->getErrorMessage()?:'Ödeme formu oluşturulamadı.');
            $token=(string)$init->getToken();
            $txId=moni_gateway_transaction_start($db,$userId,'iyzico',$token,$amount,$credit,[
                'conversation_id'=>$conversation,'package_id'=>$packageId,'package_name'=>$context['package_name']??null,
                'payment_method_id'=>$childPanelId?null:$method['id'],'child_panel_id'=>$childPanelId?:null,'child_payment_method_id'=>$childPanelId?(int)$method['id']:null,
                'child_iyzico_snapshot'=>$childPanelId?['api_key'=>moni_encrypt_secret((string)$cfg['api_key']),'secret_key'=>moni_encrypt_secret((string)$cfg['secret_key']),'base_url'=>(string)($cfg['base_url']??'https://api.iyzipay.com')]:null,
                'payment_bonus_amount'=>(float)($context['payment_bonus_amount']??0)
            ]);
            return ['success'=>true,'token'=>$token,'tx_id'=>$txId,'checkout'=>$init,'method'=>$method];
        } catch(Throwable $e) { return ['success'=>false,'error'=>$e->getMessage()]; }
    }

    public function verifyCallback(PDO $db,array $payload,array $server=[]):array {
        try {
            $this->bootstrap();
            $token=trim((string)($payload['token']??''));if($token==='')throw new RuntimeException('Ödeme tokenı eksik.');
            $q=$db->prepare("SELECT * FROM gateway_transactions WHERE gateway_slug='iyzico' AND local_token=? LIMIT 1");$q->execute([$token]);$tx=$q->fetch(PDO::FETCH_ASSOC);
            if(!$tx)throw new RuntimeException('Ödeme oturumu bulunamadı.');
            $data=json_decode($tx['payload_json']??'{}',true)?:[];$conversation=(string)($data['conversation_id']??'');
            if(!empty($data['child_iyzico_snapshot'])&&is_array($data['child_iyzico_snapshot'])){$snap=$data['child_iyzico_snapshot'];$cfg=['api_key'=>moni_decrypt_secret((string)($snap['api_key']??'')),'secret_key'=>moni_decrypt_secret((string)($snap['secret_key']??'')),'base_url'=>(string)($snap['base_url']??'https://api.iyzipay.com')];$method=['id'=>(int)($data['child_payment_method_id']??0),'type'=>'iyzico'];}else{[$method,$cfg]=$this->method($db,false);}
            $request=new \Iyzipay\Request\RetrieveCheckoutFormRequest();$request->setLocale(\Iyzipay\Model\Locale::TR);$request->setConversationId($conversation);$request->setToken($token);
            $checkout=\Iyzipay\Model\CheckoutForm::retrieve($request,$this->options($cfg));
            if($checkout->getStatus()!=='success'||$checkout->getPaymentStatus()!=='SUCCESS')throw new RuntimeException($checkout->getErrorMessage()?:'Ödeme başarılı değil.');
            $paid=(float)$checkout->getPaidPrice();if(abs($paid-(float)$tx['amount'])>0.01)throw new RuntimeException('Ödenen tutar ile sunucu kaydı uyuşmuyor.');
            $paymentId=(string)$checkout->getPaymentId();if($paymentId==='')throw new RuntimeException('Gateway işlem numarası alınamadı.');
            return ['success'=>true,'transaction'=>$tx,'method'=>$method,'payload'=>$data,'gateway_transaction_id'=>$paymentId,'paid_amount'=>$paid,
                'verify_data'=>['paid_price'=>$paid,'payment_status'=>$checkout->getPaymentStatus(),'conversation_id'=>$conversation]];
        } catch(Throwable $e) { return ['success'=>false,'error'=>$e->getMessage()]; }
    }
};
