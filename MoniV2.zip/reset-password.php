<?php
/**
 * Şifre Sıfırlama Sayfası
 */

require_once __DIR__ . '/config.php';

// Zaten giriş yapmışsa yönlendir
if (isLoggedIn()) {
    header('Location: ' . (isAdmin() ? '/admin/' : '/kullanici/'));
    exit;
}

$error = '';
$success = '';
$validToken = false;
$token = $_GET['token'] ?? '';

// Token kontrolü - veritabanında yalnız token özeti tutulur.
$storedToken = $token !== '' ? moni_hash_secret_token($token) : '';
if ($storedToken !== '') {
    $stmt=$db->prepare("SELECT pr.*,u.username,u.email FROM password_resets pr JOIN users u ON pr.user_id=u.id WHERE pr.token=? AND pr.used=0 AND pr.expires_at>NOW() LIMIT 1");
    $stmt->execute([$storedToken]);$resetRequest=$stmt->fetch(PDO::FETCH_ASSOC);
    // Eski kurulumdan kalan düz metin tokenlar, güncelleme sırasında kullanıcıyı kilitlememek için bir kez kabul edilir.
    if (!$resetRequest) {$stmt->execute([$token]);$resetRequest=$stmt->fetch(PDO::FETCH_ASSOC);}
    if ($resetRequest) $validToken=true;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $validToken) {
    $password=$_POST['password']??'';$passwordConfirm=$_POST['password_confirm']??'';
    if ($password==='') $error='Lütfen yeni şifrenizi girin.';
    elseif (strlen($password)<8) $error='Şifre en az 8 karakter olmalıdır.';
    elseif ($password!==$passwordConfirm) $error='Şifreler eşleşmiyor.';
    else {
        try {
            $db->beginTransaction();
            $lock=$db->prepare("SELECT id,user_id FROM password_resets WHERE id=? AND used=0 AND expires_at>NOW() FOR UPDATE");$lock->execute([$resetRequest['id']]);$locked=$lock->fetch(PDO::FETCH_ASSOC);
            if(!$locked) throw new RuntimeException('Bağlantı daha önce kullanılmış veya süresi dolmuş.');
            $db->prepare("UPDATE users SET password=? WHERE id=?")->execute([password_hash($password,PASSWORD_DEFAULT),$locked['user_id']]);
            $db->prepare("UPDATE password_resets SET used=1 WHERE user_id=? AND used=0")->execute([$locked['user_id']]);
            moni_revoke_user_sessions($db,(int)$locked['user_id']);
            $db->commit();$success=true;$validToken=false;
        } catch(Throwable $e) {
            if($db->inTransaction())$db->rollBack();$error='Şifre sıfırlama işlemi tamamlanamadı. Lütfen yeni bir bağlantı talep edin.';
        }
    }
}

$pageTitle = "Şifre Sıfırla";
require_once 'includes/header.php';
?>

<style>
.reset-page {
    min-height: calc(100vh - 200px);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 40px 20px;
}

.reset-container {
    width: 100%;
    max-width: 450px;
}

.reset-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 20px;
    padding: 40px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
}

.reset-header {
    text-align: center;
    margin-bottom: 30px;
}

.reset-icon {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    font-size: 2rem;
    color: #fff;
}

.reset-icon.success {
    background: linear-gradient(135deg, #28a745, #20c997);
}

.reset-icon.error {
    background: linear-gradient(135deg, #dc3545, #fd7e14);
}

.reset-icon.default {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--on-accent-color);
}

.reset-header h1 {
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 10px;
}

.reset-header p {
    color: var(--text-color);
    opacity: 0.7;
    font-size: 0.95rem;
    line-height: 1.6;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    font-size: 0.9rem;
}

.form-control {
    width: 100%;
    padding: 14px 18px;
    border: 2px solid var(--border-color);
    border-radius: 12px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 1rem;
    transition: all 0.3s ease;
}

.form-control:focus {
    outline: none;
    border-color: var(--accent-text-color);
    box-shadow: 0 0 0 4px var(--primary-alpha-01);
}

.btn-reset {
    width: 100%;
    padding: 14px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border: none;
    border-radius: 12px;
    color: var(--on-accent-color);
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.btn-reset:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px var(--primary-alpha-03);
}

.btn-login {
    width: 100%;
    padding: 14px;
    background: linear-gradient(135deg, #28a745, #20c997);
    border: none;
    border-radius: 12px;
    color: #fff;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    text-decoration: none;
    margin-top: 15px;
}

.btn-login:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(40, 167, 69, 0.3);
    color: #fff;
}

.reset-footer {
    text-align: center;
    margin-top: 25px;
    padding-top: 25px;
    border-top: 1px solid var(--border-color);
}

.reset-footer a {
    color: var(--accent-text-color);
    text-decoration: none;
    font-weight: 500;
}

.reset-footer a:hover {
    text-decoration: underline;
}

.alert {
    padding: 15px 20px;
    border-radius: 12px;
    margin-bottom: 20px;
    display: flex;
    align-items: flex-start;
    gap: 12px;
    font-size: 0.9rem;
    line-height: 1.5;
}

.alert i {
    margin-top: 2px;
}

.alert-danger {
    background: rgba(220, 53, 69, 0.1);
    border: 1px solid rgba(220, 53, 69, 0.2);
    color: #dc3545;
}

.input-icon {
    position: relative;
}

.input-icon i {
    position: absolute;
    left: 16px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--text-color);
    opacity: 0.4;
}

.input-icon input {
    padding-left: 48px;
}

.password-toggle {
    position: absolute;
    right: 16px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    color: var(--text-color);
    opacity: 0.4;
    cursor: pointer;
    padding: 5px;
}

.password-toggle:hover {
    opacity: 0.7;
}

.password-strength {
    margin-top: 8px;
    height: 4px;
    background: var(--border-color);
    border-radius: 2px;
    overflow: hidden;
}

.password-strength-bar {
    height: 100%;
    width: 0;
    transition: all 0.3s ease;
    border-radius: 2px;
}

.password-strength-bar.weak { width: 33%; background: #dc3545; }
.password-strength-bar.medium { width: 66%; background: #ffc107; }
.password-strength-bar.strong { width: 100%; background: #28a745; }

.password-hint {
    font-size: 0.8rem;
    margin-top: 8px;
    opacity: 0.6;
}

.user-info {
    background: var(--background-color);
    border-radius: 10px;
    padding: 15px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 12px;
}

.user-avatar {
    width: 45px;
    height: 45px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--on-accent-color);
    font-weight: 600;
    font-size: 1.1rem;
}

.user-details h4 {
    font-size: 0.95rem;
    margin-bottom: 2px;
}

.user-details span {
    font-size: 0.8rem;
    opacity: 0.6;
}

@media (max-width: 576px) {
    .reset-card {
        padding: 30px 25px;
    }
    
    .reset-header h1 {
        font-size: 1.3rem;
    }
}
</style>

<div class="reset-page">
    <div class="reset-container">
        <div class="reset-card">
            <?php if ($success): ?>
                <!-- Başarılı -->
                <div class="reset-header">
                    <div class="reset-icon success">
                        <i class="fas fa-check"></i>
                    </div>
                    <h1>Şifreniz Değiştirildi!</h1>
                    <p>Şifreniz başarıyla güncellendi. Artık yeni şifrenizle giriş yapabilirsiniz.</p>
                </div>
                <a href="<?php echo SITE_URL; ?>/login.php" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i>
                    Giriş Yap
                </a>
                
            <?php elseif (!$validToken): ?>
                <!-- Geçersiz Token -->
                <div class="reset-header">
                    <div class="reset-icon error">
                        <i class="fas fa-times"></i>
                    </div>
                    <h1>Geçersiz veya Süresi Dolmuş Link</h1>
                    <p>Bu şifre sıfırlama linki geçersiz veya süresi dolmuş. Lütfen yeni bir şifre sıfırlama talebi oluşturun.</p>
                </div>
                <a href="<?php echo SITE_URL; ?>/forgot-password.php" class="btn-reset">
                    <i class="fas fa-redo"></i>
                    Yeni Talep Oluştur
                </a>
                
            <?php else: ?>
                <!-- Şifre Sıfırlama Formu -->
                <div class="reset-header">
                    <div class="reset-icon default">
                        <i class="fas fa-lock"></i>
                    </div>
                    <h1>Yeni Şifre Belirle</h1>
                    <p>Hesabınız için yeni bir şifre belirleyin.</p>
                </div>
                
                <div class="user-info">
                    <div class="user-avatar">
                        <?php echo strtoupper(mb_substr($resetRequest['username'], 0, 1, 'UTF-8')); ?>
                    </div>
                    <div class="user-details">
                        <h4><?php echo clean($resetRequest['username']); ?></h4>
                        <span><?php echo clean($resetRequest['email']); ?></span>
                    </div>
                </div>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><?php echo $error; ?></span>
                    </div>
                <?php endif; ?>
                
                <form method="POST">
                    <div class="form-group">
                        <label>Yeni Şifre</label>
                        <div class="input-icon">
                            <i class="fas fa-lock"></i>
                            <input type="password" name="password" id="password" class="form-control" placeholder="••••••••" required minlength="8">
                            <button type="button" class="password-toggle" onclick="togglePassword('password', this)">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="password-strength">
                            <div class="password-strength-bar" id="strengthBar"></div>
                        </div>
                        <p class="password-hint">En az 8 karakter olmalıdır</p>
                    </div>
                    
                    <div class="form-group">
                        <label>Yeni Şifre (Tekrar)</label>
                        <div class="input-icon">
                            <i class="fas fa-lock"></i>
                            <input type="password" name="password_confirm" id="password_confirm" class="form-control" placeholder="••••••••" required minlength="8">
                            <button type="button" class="password-toggle" onclick="togglePassword('password_confirm', this)">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn-reset">
                        <i class="fas fa-save"></i>
                        Şifremi Değiştir
                    </button>
                </form>
            <?php endif; ?>
            
            <div class="reset-footer">
                <a href="<?php echo SITE_URL; ?>/login.php"><i class="fas fa-arrow-left"></i> Giriş sayfasına dön</a>
            </div>
        </div>
    </div>
</div>

<script>
// Şifre göster/gizle
function togglePassword(inputId, btn) {
    var input = document.getElementById(inputId);
    var icon = btn.querySelector('i');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// Şifre güç kontrolü
var passwordInput = document.getElementById('password');
var strengthBar = document.getElementById('strengthBar');

if (passwordInput && strengthBar) {
    passwordInput.addEventListener('input', function() {
        var password = this.value;
        var strength = 0;
        
        if (password.length >= 8) strength++;
        if (password.length >= 10) strength++;
        if (/[A-Z]/.test(password)) strength++;
        if (/[0-9]/.test(password)) strength++;
        if (/[^A-Za-z0-9]/.test(password)) strength++;
        
        strengthBar.className = 'password-strength-bar';
        
        if (strength <= 2) {
            strengthBar.classList.add('weak');
        } else if (strength <= 4) {
            strengthBar.classList.add('medium');
        } else {
            strengthBar.classList.add('strong');
        }
    });
}
</script>

<?php require_once 'includes/footer.php'; ?>