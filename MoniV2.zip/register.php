<?php
/**
 * SMM Panel - Kayıt Ol (E-posta Doğrulama Destekli, FK'siz token tablo)
 */

require_once 'config.php';
require_once __DIR__ . '/includes/MoniV2Compat.php';
require_once __DIR__ . '/includes/MoniThemeCompat.php';
require_once __DIR__ . '/includes/mail.php'; // sendTemplateEmail / sendEmail için

// ===== SOSYAL LOGIN - SocialAuth Sınıfını Yükle =====
$googleEnabled = false;
$discordEnabled = false;

if (file_exists(__DIR__ . '/classes/SocialAuth.php')) {
    require_once __DIR__ . '/classes/SocialAuth.php';
    $socialAuth = new SocialAuth($db);
    $googleEnabled = $socialAuth->isEnabled('google');
    $discordEnabled = $socialAuth->isEnabled('discord');
}
// ===== SOSYAL LOGIN SON =====

// E-posta doğrulama ayarı (settings tablosu: setting_key/setting_value; yoksa varsayılan true)
$emailVerificationEnabled = true;
if (function_exists('getSetting')) {
    $emailVerificationEnabled = (bool) getSetting('email_verification_enabled', 1);
}

// Zaten giriş yapmışsa yönlendir
if (isLoggedIn()) {
    header('Location: ' . (isAdmin() ? '/admin/' : '/kullanici/'));
    exit;
}

// Referans kodu kontrolü
$refCode = '';
$refUser = null;

if (isset($_GET['ref']) && !empty($_GET['ref'])) {
    $refCode = trim($_GET['ref']);
    $refStmt = $db->prepare("SELECT id, username FROM users WHERE referral_code = ? AND status = 'active'");
    $refStmt->execute([$refCode]);
    $refUser = $refStmt->fetch();
    if ($refUser) {
        $_SESSION['ref_code'] = $refCode;
    }
} elseif (isset($_SESSION['ref_code']) && !empty($_SESSION['ref_code'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $refCode = $_SESSION['ref_code'];
        $refStmt = $db->prepare("SELECT id, username FROM users WHERE referral_code = ? AND status = 'active'");
        $refStmt->execute([$refCode]);
        $refUser = $refStmt->fetch();
    } else {
        unset($_SESSION['ref_code']);
    }
}

$error = '';
$success = '';
$registrationFields = function_exists('moni_registration_fields') ? moni_registration_fields($db, true) : [];
$registrationFieldValues = [];
$childPanelContext = function_exists('moni_child_panel_context') ? moni_child_panel_context($db) : null;

// ===== SOSYAL LOGIN - Hata mesajı kontrolü =====
if (isset($_GET['error'])) {
    $error = clean($_GET['error']);
}
// ===== SOSYAL LOGIN SON =====

/** Token üret */
function generateEmailToken(): string {
    return bin2hex(random_bytes(32)); // 64 hex
}

/** E-posta doğrulama gönderimi */
function sendVerificationEmail(string $email, string $token): bool {
    $siteUrl = rtrim((string)(defined('SITE_URL') ? SITE_URL : ''), '/');
    if (!filter_var($siteUrl, FILTER_VALIDATE_URL)) $siteUrl = rtrim((string)getSetting('site_url',''), '/');
    if (!filter_var($siteUrl, FILTER_VALIDATE_URL)) return false;
    $verifyUrl = $siteUrl . '/verify-email.php?token=' . urlencode($token);
    $username = $_POST['username'] ?? 'Kullanıcı';

    // Şablonlu gönderim (mail.php içindeki email_verification şablonu)
    $res = sendTemplateEmail($email, 'email_verification', [
        'username'    => $username,
        'verify_link' => $verifyUrl,
        'site_url'    => $siteUrl,
        'site_name'   => $GLOBALS['siteSettings']['name'] ?? 'Site',
        'year'        => date('Y'),
    ]);
    return !empty($res['success']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $passwordConfirm = $_POST['password_confirm'] ?? '';
    $rfValidation = function_exists('moni_registration_validate') ? moni_registration_validate($db, $_POST) : ['ok'=>true,'errors'=>[],'values'=>[]];
    $registrationFieldValues = $rfValidation['values'] ?? [];
    
    // Validasyonlar
    $captchaError='';
    if (!moni_captcha_verify_request($db,$captchaError)) {
        $error = $captchaError;
    } elseif (empty($username) || empty($email) || empty($password)) {
        $error = __('register_error_fill_all');
    } elseif (strlen($username) < 3 || strlen($username) > 30) {
        $error = __('register_error_username_length');
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $error = __('register_error_username_chars');
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = __('register_error_invalid_email');
    } elseif (function_exists('moni_disposable_email_is_blocked') && moni_disposable_email_is_blocked($db,$email,$blockedEmailRule)) {
        if (function_exists('moni_log_disposable_email_block')) moni_log_disposable_email_block($db,$email,'register');
        $error = 'Geçici / disposable e-posta adresleriyle kayıt kabul edilmiyor. Lütfen kalıcı bir e-posta adresi kullanın.';
    } elseif (strlen($password) < 8) {
        $error = __('register_error_password_length');
    } elseif ($password !== $passwordConfirm) {
        $error = __('register_error_password_mismatch');
    } elseif (empty($rfValidation['ok'])) {
        $error = implode(' ', $rfValidation['errors'] ?? ['Kayıt alanları geçersiz.']);
    } else {
        // Kullanıcı adı veya email kullanılıyor mu?
        $stmt = $db->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        
        if ($stmt->fetch()) {
            $error = __('register_error_user_exists');
        } else {
            try {
                $db->beginTransaction();
                
                // Referans kodu oluştur
                $newReferralCode = strtoupper(substr(md5($username . time() . rand(1000, 9999)), 0, 8));
                
                // Kullanıcıyı oluştur
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                
                $referredBy = $refUser ? $refUser['id'] : null;
                
                $childPanelId = !empty($childPanelContext['id']) ? (int)$childPanelContext['id'] : null;
                $stmt = $db->prepare("INSERT INTO users (username, email, password, role, status, balance, email_verified, referral_code, referred_by, child_panel_id, created_at) VALUES (?, ?, ?, 'user', 'active', 0, 0, ?, ?, ?, NOW())");
                
                if ($stmt->execute([$username, $email, $hashedPassword, $newReferralCode, $referredBy, $childPanelId])) {
                    $newUserId = (int)$db->lastInsertId();
                    if (function_exists('moni_registration_save_values')) moni_registration_save_values($db, $newUserId, $registrationFieldValues);
                    if (function_exists('moni_grant_starting_balance')) moni_grant_starting_balance($db, $newUserId);
                    
                    // Referans bonusu ver
                    if ($refUser) {
                        $bonusAmount = floatval(getSetting('referral_bonus_amount', '5'));
                        
                        if ($bonusAmount > 0) {
                            // Referans log kaydı oluştur
                            $refIp = function_exists('moni_client_ip') ? moni_client_ip() : ($_SERVER['REMOTE_ADDR'] ?? '');
                            $refUa = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
                            $logStmt = $db->prepare("INSERT INTO referral_logs (referrer_id, referred_id, bonus_amount, status, ip_address, user_agent, created_at) VALUES (?, ?, ?, 'pending', ?, ?, NOW())");
                            $logStmt->execute([
                                $refUser['id'],
                                $newUserId,
                                $bonusAmount,
                                $refIp,
                                $refUa
                            ]);
                            $referralLogId=(int)$db->lastInsertId();
                            if(function_exists('moni_referral_fraud_assess') && function_exists('moni_referral_fraud_record')){
                                $assessment=moni_referral_fraud_assess($db,(int)$refUser['id'],$newUserId,$email,$refIp,$refUa);
                                moni_referral_fraud_record($db,$referralLogId,(int)$refUser['id'],$newUserId,$assessment,$refIp,$refUa);
                                if(($assessment['decision']??'allow')!=='allow' && function_exists('moni_admin_notify')){
                                    moni_admin_notify($db,'referral_fraud','Şüpheli referral kaydı','Referral #'.$referralLogId.' risk puanı: '.(int)($assessment['score']??0),'/admin/referral-fraud.php','warning');
                                }
                            }
                        }
                    }
                    
                    if ($emailVerificationEnabled) {
                        // Token üret ve kaydet (FK yok)
                        $token = generateEmailToken();
                        $expires = (new DateTime('+1 day'))->format('Y-m-d H:i:s');
                        $db->prepare("INSERT INTO email_verification_tokens (user_id, token, expires_at) VALUES (?, ?, ?)")
                           ->execute([$newUserId, hash('sha256',$token), $expires]);
                        
                        sendVerificationEmail($email, $token);
                        $db->commit();
                        
                        unset($_SESSION['ref_code']);
                        $success = __('register_success_verify_email');
                        // Oturum açmadan bekletiyoruz; login ekranında doğrulanmamışsa girişi engelleyin.
                    } else {
                        // Doğrulama kapalıysa otomatik giriş
                        unset($_SESSION['ref_code']);
                        $db->commit();
                        
                        $newUserStmt = $db->prepare("SELECT * FROM users WHERE id=? AND status='active' LIMIT 1");
                        $newUserStmt->execute([$newUserId]);
                        $newUser = $newUserStmt->fetch(PDO::FETCH_ASSOC);
                        if (!$newUser) { throw new RuntimeException('Yeni kullanıcı oturumu oluşturulamadı.'); }
                        moni_complete_login($db, $newUser, false, 'registration');
                        
                        header('Location: /kullanici/');
                        exit;
                    }
                } else {
                    throw new Exception('Kayıt başarısız');
                }
            } catch (Exception $e) {
                $db->rollBack();
                $error = __('register_error_general');
            }
        }
    }
}

// Sayfa başlığı için çeviri
$pageTitle = __('register_page_title');
?>
<!DOCTYPE html>
<html lang="<?php echo getCurrentLanguage(); ?>" dir="<?php echo function_exists('moni_language_direction') ? moni_language_direction($db, getCurrentLanguage()) : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> - <?php echo clean($siteSettings['name']); ?></title>
    <?php if(function_exists('moni_pwa_head_tags')) echo moni_pwa_head_tags($db); ?>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        <?php echo generateCSSVariables($activeTheme); ?>
        <?php echo moni_theme_compat_css($activeTheme); ?>
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--background-color);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }
        
        .bg-animation {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 0;
            overflow: hidden;
        }
        
        .bg-animation::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at 20% 80%, var(--primary-color) 0%, transparent 40%),
                        radial-gradient(circle at 80% 20%, var(--secondary-color) 0%, transparent 40%),
                        radial-gradient(circle at 50% 50%, var(--primary-color) 0%, transparent 30%);
            opacity: 0.08;
            animation: bgRotate 30s linear infinite;
        }
        
        @keyframes bgRotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .auth-container {
            width: 100%;
            max-width: 450px;
            position: relative;
            z-index: 1;
        }
        
        .auth-card {
            background: var(--card-bg-color);
            border-radius: 24px;
            padding: 45px 40px;
            box-shadow: 0 25px 80px rgba(0, 0, 0, 0.25);
            border: 1px solid var(--border-color);
        }
        
        .auth-header {
            text-align: center;
            margin-bottom: 35px;
        }
        
        .auth-logo {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 1.8rem;
            color: var(--on-accent-color);
            box-shadow: 0 10px 40px var(--primary-alpha-03);
        }
        
        .auth-header h1 {
            font-size: 1.7rem;
            font-weight: 700;
            color: var(--text-color);
            margin-bottom: 8px;
        }
        
        .auth-header p {
            color: var(--text-color);
            opacity: 0.6;
            font-size: 0.95rem;
        }
        
        .referral-info {
            background: linear-gradient(135deg, rgba(243, 156, 18, 0.15), rgba(231, 76, 60, 0.15));
            border: 1px solid rgba(243, 156, 18, 0.3);
            border-radius: 12px;
            padding: 15px 18px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .referral-info i {
            font-size: 1.8rem;
            color: #f39c12;
        }
        
        .referral-info-text {
            flex: 1;
        }
        
        .referral-info-text strong {
            display: block;
            color: #f39c12;
            font-size: 0.95rem;
            margin-bottom: 3px;
        }
        
        .referral-info-text span {
            font-size: 0.85rem;
            color: var(--text-color);
            opacity: 0.8;
        }
        
        .referral-info-text .ref-username {
            color: #fff;
            font-weight: 600;
        }
        
        .alert {
            padding: 14px 18px;
            border-radius: 12px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 0.9rem;
            animation: shake 0.4s ease-in-out;
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }
        
        .alert-danger {
            background: rgba(220, 53, 69, 0.12);
            border: 1px solid rgba(220, 53, 69, 0.3);
            color: #dc3545;
        }
        
        .alert-success {
            background: rgba(40, 167, 69, 0.12);
            border: 1px solid rgba(40, 167, 69, 0.3);
            color: #28a745;
        }
        
        .form-group {
            margin-bottom: 22px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--text-color);
            font-size: 0.9rem;
        }
        
        .input-group {
            position: relative;
        }
        
        .input-group i.input-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-color);
            opacity: 0.4;
            transition: all 0.3s ease;
            pointer-events: none;
        }
        
        .input-group input {
            width: 100%;
            padding: 14px 16px 14px 48px;
            border: 2px solid var(--border-color);
            border-radius: 12px;
            background: var(--background-color);
            color: var(--text-color);
            font-size: 0.95rem;
            transition: all 0.3s ease;
        }
        
        .input-group input:focus {
            outline: none;
            border-color: var(--accent-text-color);
            box-shadow: 0 0 0 4px var(--primary-alpha-01);
        }
        
        .input-group input:focus + i.input-icon {
            color: var(--accent-text-color);
            opacity: 1;
        }
        
        .input-group input::placeholder {
            color: var(--text-color);
            opacity: 0.4;
        }
        
        .password-toggle {
            position: absolute;
            right: 16px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--text-color);
            opacity: 0.4;
            cursor: pointer;
            padding: 5px;
            transition: opacity 0.3s ease;
        }
        
        .password-toggle:hover {
            opacity: 0.8;
        }
        
        .password-strength {
            margin-top: 8px;
            height: 4px;
            background: var(--border-color);
            border-radius: 2px;
            overflow: hidden;
        }
        
        .password-strength-bar {
            height: 100%;
            width: 0%;
            border-radius: 2px;
            transition: all 0.3s ease;
        }
        
        .password-strength-bar.weak { width: 33%; background: #dc3545; }
        .password-strength-bar.medium { width: 66%; background: #ffc107; }
        .password-strength-bar.strong { width: 100%; background: #28a745; }
        
        .password-hint {
            font-size: 0.8rem;
            color: var(--text-color);
            opacity: 0.5;
            margin-top: 6px;
        }
        
        .btn-register {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            border-radius: 12px;
            color: var(--on-accent-color);
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 10px;
        }
        
        .btn-register:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px var(--primary-alpha-04);
        }
        
        .btn-register:active {
            transform: translateY(-1px);
        }
        
        .btn-register:disabled {
            opacity: 0.7;
            cursor: not-allowed;
            transform: none;
        }
        
        /* ===== SOSYAL LOGIN STİLLERİ ===== */
        .social-divider {
            display: flex;
            align-items: center;
            margin: 25px 0;
            gap: 15px;
        }
        
        .social-divider::before,
        .social-divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: var(--border-color);
        }
        
        .social-divider span {
            color: var(--text-color);
            opacity: 0.5;
            font-size: 0.85rem;
            white-space: nowrap;
        }
        
        .social-buttons {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        
        .btn-social {
            width: 100%;
            padding: 14px 20px;
            border: 2px solid var(--border-color);
            border-radius: 12px;
            background: var(--background-color);
            color: var(--text-color);
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            text-decoration: none;
        }
        
        .btn-social:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
        }
        
        .btn-social.google {
            border-color: #DB4437;
            color: #DB4437;
        }
        
        .btn-social.google:hover {
            background: #DB4437;
            color: #fff;
        }
        
        .btn-social.discord {
            border-color: #5865F2;
            color: #5865F2;
        }
        
        .btn-social.discord:hover {
            background: #5865F2;
            color: #fff;
        }
        
        .btn-social i {
            font-size: 1.2rem;
        }
        /* ===== SOSYAL LOGIN STİLLERİ SON ===== */
        
        .auth-footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 25px;
            border-top: 1px solid var(--border-color);
        }
        
        .auth-footer p {
            color: var(--text-color);
            opacity: 0.7;
            font-size: 0.95rem;
        }
        
        .auth-footer a {
            color: var(--accent-text-color);
            text-decoration: none;
            font-weight: 600;
            transition: opacity 0.3s ease;
        }
        
        .auth-footer a:hover {
            opacity: 0.8;
        }
        
        .back-home {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--text-color);
            opacity: 0.6;
            text-decoration: none;
            font-size: 0.9rem;
            margin-top: 20px;
            transition: all 0.3s ease;
        }
        
        .back-home:hover {
            opacity: 1;
            color: var(--accent-text-color);
        }
        
        .terms-check {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            margin-top: 20px;
            margin-bottom: 5px;
        }
        
        .terms-check input {
            width: 18px;
            height: 18px;
            accent-color: var(--accent-text-color);
            cursor: pointer;
            margin-top: 2px;
        }
        
        .terms-check label {
            font-size: 0.85rem;
            color: var(--text-color);
            opacity: 0.8;
            cursor: pointer;
        }
        
        .terms-check a {
            color: var(--accent-text-color);
            text-decoration: none;
        }
        
        @media (max-width: 480px) {
            .auth-card {
                padding: 35px 25px;
            }
            
            .auth-header h1 {
                font-size: 1.5rem;
            }
        }
    </style>
<link rel="stylesheet" href="/assets/css/theme-compat.css?v=1.3.1">
</head>
<body>
    <div class="bg-animation"></div>
    
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <div class="auth-logo">
                    <i class="fas fa-user-plus"></i>
                </div>
                <h1><?php echo __('register_heading'); ?></h1>
                <p><?php echo __('register_subheading'); ?></p>
            </div>
            
            <?php if ($refUser): ?>
                <div class="referral-info">
                    <i class="fas fa-gift"></i>
                    <div class="referral-info-text">
                        <strong><i class="fas fa-check-circle"></i> <?php echo __('register_referral_title'); ?></strong>
                        <span><span class="ref-username"><?php echo clean($refUser['username']); ?></span> <?php echo __('register_referral_invited'); ?></span>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo clean($error); ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo clean($success); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" id="registerForm">
                <div class="form-group">
                    <label class="form-label"><?php echo __('register_label_username'); ?></label>
                    <div class="input-group">
                        <input type="text" name="username" placeholder="<?php echo __('register_placeholder_username'); ?>" required 
                               value="<?php echo clean($_POST['username'] ?? ''); ?>"
                               pattern="[a-zA-Z0-9_]+" minlength="3" maxlength="30">
                        <i class="fas fa-user input-icon"></i>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php echo __('register_label_email'); ?></label>
                    <div class="input-group">
                        <input type="email" name="email" placeholder="<?php echo __('register_placeholder_email'); ?>" required
                               value="<?php echo clean($_POST['email'] ?? ''); ?>">
                        <i class="fas fa-envelope input-icon"></i>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php echo __('register_label_password'); ?></label>
                    <div class="input-group">
                        <input type="password" name="password" id="password" placeholder="••••••••" required minlength="8">
                        <i class="fas fa-lock input-icon"></i>
                        <button type="button" class="password-toggle" onclick="togglePassword('password', 'toggleIcon1')">
                            <i class="fas fa-eye" id="toggleIcon1"></i>
                        </button>
                    </div>
                    <div class="password-strength">
                        <div class="password-strength-bar" id="strengthBar"></div>
                    </div>
                    <div class="password-hint"><?php echo __('register_password_hint'); ?></div>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php echo __('register_label_password_confirm'); ?></label>
                    <div class="input-group">
                        <input type="password" name="password_confirm" id="password_confirm" placeholder="••••••••" required minlength="8">
                        <i class="fas fa-lock input-icon"></i>
                        <button type="button" class="password-toggle" onclick="togglePassword('password_confirm', 'toggleIcon2')">
                            <i class="fas fa-eye" id="toggleIcon2"></i>
                        </button>
                    </div>
                </div>
                
                <?php foreach ($registrationFields as $rf): $rfName='rf_'.(int)$rf['id']; $rfVal=$_POST[$rfName]??''; $opts=json_decode($rf['options_json']??'[]',true)?:[]; ?>
                <div class="form-group">
                    <label class="form-label"><?php echo clean($rf['label']); ?><?php if(!empty($rf['is_required'])): ?> <span style="color:#dc3545">*</span><?php endif; ?></label>
                    <div class="input-group">
                        <?php if($rf['field_type']==='textarea'): ?>
                            <textarea name="<?php echo $rfName; ?>" <?php echo !empty($rf['is_required'])?'required':''; ?> style="width:100%;min-height:90px;padding:14px 16px;border:2px solid var(--border-color);border-radius:12px;background:var(--background-color);color:var(--text-color)"><?php echo clean((string)$rfVal); ?></textarea>
                        <?php elseif($rf['field_type']==='select'): ?>
                            <select name="<?php echo $rfName; ?>" <?php echo !empty($rf['is_required'])?'required':''; ?> style="width:100%;padding:14px 16px;border:2px solid var(--border-color);border-radius:12px;background:var(--background-color);color:var(--text-color)">
                                <option value="">Seçiniz</option><?php foreach($opts as $op): $ov=is_array($op)?($op['value']??''):$op; $ol=is_array($op)?($op['label']??$ov):$op; ?><option value="<?php echo clean((string)$ov); ?>" <?php echo (string)$rfVal===(string)$ov?'selected':''; ?>><?php echo clean((string)$ol); ?></option><?php endforeach; ?>
                            </select>
                        <?php elseif($rf['field_type']==='checkbox'): ?>
                            <label style="display:flex;gap:10px;align-items:center"><input type="checkbox" name="<?php echo $rfName; ?>" value="1" <?php echo $rfVal?'checked':''; ?> <?php echo !empty($rf['is_required'])?'required':''; ?>> <?php echo clean($rf['placeholder']?:$rf['label']); ?></label>
                        <?php else: ?>
                            <input type="<?php echo in_array($rf['field_type'],['number','email','url'],true)?clean($rf['field_type']):'text'; ?>" name="<?php echo $rfName; ?>" value="<?php echo clean((string)$rfVal); ?>" placeholder="<?php echo clean((string)($rf['placeholder']??'')); ?>" <?php echo !empty($rf['is_required'])?'required':''; ?> style="padding-left:16px">
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>

                <div class="terms-check">
                    <input type="checkbox" id="terms" name="terms" required>
                    <label for="terms">
                        <a href="pages/kullanim-sartlari.php"><?php echo __('register_terms_link'); ?></a><?php echo __('register_terms_and'); ?><a href="pages/gizlilik-politikasi.php"><?php echo __('register_privacy_link'); ?></a><?php echo __('register_terms_accept'); ?>
                    </label>
                </div>
                
                <?=moni_captcha_render($db)?>
                <button type="submit" class="btn-register">
                    <i class="fas fa-user-plus"></i>
                    <?php echo __('register_btn_submit'); ?>
                </button>
            </form>
            
            <!-- ===== SOSYAL LOGIN BUTONLARI (KAYIT OL ALTINDA) ===== -->
            <?php if ($googleEnabled || $discordEnabled): ?>
                <div class="social-divider">
                    <span><?php echo __('register_social_divider'); ?></span>
                </div>
                
                <div class="social-buttons">
                    <?php if ($googleEnabled): ?>
                        <a href="/auth/google/" class="btn-social google">
                            <i class="fab fa-google"></i>
                            <?php echo __('register_btn_google'); ?>
                        </a>
                    <?php endif; ?>
                    
                    <?php if ($discordEnabled): ?>
                        <a href="/auth/discord/" class="btn-social discord">
                            <i class="fab fa-discord"></i>
                            <?php echo __('register_btn_discord'); ?>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <!-- ===== SOSYAL LOGIN BUTONLARI SON ===== -->
            
            <div class="auth-footer">
                <p><?php echo __('register_have_account'); ?> <a href="login.php"><?php echo __('register_login_link'); ?></a></p>
                <a href="/" class="back-home">
                    <i class="fas fa-arrow-left"></i>
                    <?php echo __('register_back_home'); ?>
                </a>
            </div>
        </div>
    </div>
    
    <script>
        function togglePassword(inputId, iconId) {
            const input = document.getElementById(inputId);
            const icon = document.getElementById(iconId);
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
        
        document.getElementById('password').addEventListener('input', function() {
            const password = this.value;
            const bar = document.getElementById('strengthBar');
            
            bar.className = 'password-strength-bar';
            
            if (password.length === 0) {
                bar.style.width = '0%';
            } else if (password.length < 8) {
                bar.classList.add('weak');
            } else if (password.length < 10 || !/[A-Z]/.test(password) || !/[0-9]/.test(password)) {
                bar.classList.add('medium');
            } else {
                bar.classList.add('strong');
            }
        });
        
        document.getElementById('password_confirm').addEventListener('input', function() {
            const password = document.getElementById('password').value;
            
            if (this.value !== password) {
                this.style.borderColor = '#dc3545';
            } else {
                this.style.borderColor = '#28a745';
            }
        });
    </script>
</body>
</html>