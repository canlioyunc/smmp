<?php
/**
 * Sosyal Medya Login Sınıfı
 * Google ve Discord ile giriş
 */

class SocialAuth {
    
    private $db;
    private $settings = [];
    
    public function __construct($db) {
        $this->db = $db;
        $this->loadSettings();
    }
    
    /**
     * Veritabanından ayarları yükle
     */
    private function loadSettings() {
        try {
            $stmt = $this->db->query("SELECT * FROM social_login_settings");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                if (!empty($row['client_secret']) && function_exists('moni_decrypt_secret')) $row['client_secret'] = moni_decrypt_secret($row['client_secret']);
                $this->settings[$row['provider']] = $row;
            }
        } catch (Exception $e) {
            $this->settings = [];
        }
    }
    
    /**
     * Provider aktif mi kontrol et
     */
    public function isEnabled($provider) {
        return isset($this->settings[$provider]) && 
               $this->settings[$provider]['is_enabled'] == 1 &&
               !empty($this->settings[$provider]['client_id']) &&
               !empty($this->settings[$provider]['client_secret']);
    }
    
    /**
     * Ayarları getir
     */
    public function getSettings($provider) {
        return $this->settings[$provider] ?? null;
    }
    
    // ==================== GOOGLE ====================
    
    public function getGoogleAuthUrl() {
        if (!$this->isEnabled('google')) {
            return null;
        }
        
        $config = $this->settings['google'];
        
        $params = [
            'client_id'     => $config['client_id'],
            'redirect_uri'  => $config['redirect_uri'],
            'response_type' => 'code',
            'scope'         => 'email profile',
            'access_type'   => 'online',
            'state'         => $this->generateState('google')
        ];
        
        return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query($params);
    }
    
    public function handleGoogleCallback($code) {
        if (!$this->isEnabled('google')) {
            return ['success' => false, 'error' => 'Google login aktif değil'];
        }
        
        $config = $this->settings['google'];
        
        // Token al
        $tokenData = $this->curlPost('https://oauth2.googleapis.com/token', [
            'code'          => $code,
            'client_id'     => $config['client_id'],
            'client_secret' => $config['client_secret'],
            'redirect_uri'  => $config['redirect_uri'],
            'grant_type'    => 'authorization_code'
        ]);
        
        if (!isset($tokenData['access_token'])) {
            return ['success' => false, 'error' => 'Token alınamadı'];
        }
        
        // Kullanıcı bilgisi al
        $userInfo = $this->curlGet(
            'https://www.googleapis.com/oauth2/v2/userinfo',
            $tokenData['access_token']
        );
        
        if (!isset($userInfo['id'])) {
            return ['success' => false, 'error' => 'Kullanıcı bilgisi alınamadı'];
        }
        
        return $this->processUser('google', [
            'id'     => $userInfo['id'],
            'email'  => $userInfo['email'] ?? null,
            'name'   => $userInfo['name'] ?? 'User',
            'avatar' => $userInfo['picture'] ?? null
        ]);
    }
    
    // ==================== DISCORD ====================
    
    public function getDiscordAuthUrl() {
        if (!$this->isEnabled('discord')) {
            return null;
        }
        
        $config = $this->settings['discord'];
        
        $params = [
            'client_id'     => $config['client_id'],
            'redirect_uri'  => $config['redirect_uri'],
            'response_type' => 'code',
            'scope'         => 'identify email',
            'state'         => $this->generateState('discord')
        ];
        
        return 'https://discord.com/api/oauth2/authorize?' . http_build_query($params);
    }
    
    public function handleDiscordCallback($code) {
        if (!$this->isEnabled('discord')) {
            return ['success' => false, 'error' => 'Discord login aktif değil'];
        }
        
        $config = $this->settings['discord'];
        
        // Token al
        $tokenData = $this->curlPost('https://discord.com/api/oauth2/token', [
            'code'          => $code,
            'client_id'     => $config['client_id'],
            'client_secret' => $config['client_secret'],
            'redirect_uri'  => $config['redirect_uri'],
            'grant_type'    => 'authorization_code'
        ]);
        
        if (!isset($tokenData['access_token'])) {
            return ['success' => false, 'error' => 'Token alınamadı'];
        }
        
        // Kullanıcı bilgisi al
        $userInfo = $this->curlGet(
            'https://discord.com/api/users/@me',
            $tokenData['access_token']
        );
        
        if (!isset($userInfo['id'])) {
            return ['success' => false, 'error' => 'Kullanıcı bilgisi alınamadı'];
        }
        
        // Avatar URL oluştur
        $avatar = null;
        if (!empty($userInfo['avatar'])) {
            $avatar = "https://cdn.discordapp.com/avatars/{$userInfo['id']}/{$userInfo['avatar']}.png";
        }
        
        return $this->processUser('discord', [
            'id'     => $userInfo['id'],
            'email'  => $userInfo['email'] ?? null,
            'name'   => $userInfo['username'] ?? 'User',
            'avatar' => $avatar
        ]);
    }
    
    // ==================== ORTAK FONKSİYONLAR ====================
    
    private function processUser($provider, $info) {
        // 1. Bu sosyal hesap daha önce bağlanmış mı?
        $stmt = $this->db->prepare("
            SELECT user_id FROM social_logins 
            WHERE provider = ? AND provider_id = ?
        ");
        $stmt->execute([$provider, $info['id']]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($existing) {
            // Mevcut kullanıcıya giriş yap
            return $this->loginUser($existing['user_id']);
        }
        
        // 2. Bu e-posta ile kayıtlı kullanıcı var mı?
        if (!empty($info['email'])) {
            $stmt = $this->db->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$info['email']]);
            $existingUser = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($existingUser) {
                // Sosyal hesabı mevcut kullanıcıya bağla
                $this->linkAccount($existingUser['id'], $provider, $info);
                return $this->loginUser($existingUser['id']);
            }
        }
        
        // 3. Yeni kullanıcı oluşturulmadan önce geçici/disposable e-posta politikasını uygula.
        if (!empty($info['email']) && function_exists('moni_disposable_email_is_blocked')) {
            $matchedRule = null;
            if (moni_disposable_email_is_blocked($this->db, (string)$info['email'], $matchedRule)) {
                if (function_exists('moni_log_disposable_email_block')) moni_log_disposable_email_block($this->db,(string)$info['email'],'social_'.$provider);
                return ['success'=>false,'error'=>'Geçici / disposable e-posta adresleriyle yeni hesap oluşturulamaz.'];
            }
        }
        return $this->createUser($provider, $info);
    }
    
    private function createUser($provider, $info) {
        // Benzersiz kullanıcı adı oluştur
        $username = $this->generateUniqueUsername($info['name']);
        $randomPassword = bin2hex(random_bytes(16));
        $childPanelId = null;
        if (function_exists('moni_child_panel_context')) {
            $ctx = moni_child_panel_context($this->db);
            if (!empty($ctx['id'])) $childPanelId = (int)$ctx['id'];
        }
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("
                INSERT INTO users (username, email, password, role, status, balance, email_verified, child_panel_id, created_at)
                VALUES (?, ?, ?, 'user', 'active', 0, 1, ?, NOW())
            ");
            $stmt->execute([
                $username,
                $info['email'],
                password_hash($randomPassword, PASSWORD_DEFAULT),
                $childPanelId
            ]);
            $userId = (int)$this->db->lastInsertId();
            $this->linkAccount($userId, $provider, $info);
            if (function_exists('moni_grant_starting_balance')) moni_grant_starting_balance($this->db, $userId);
            $this->db->commit();
            return $this->loginUser($userId);
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            throw $e;
        }
    }
    
    private function linkAccount($userId, $provider, $info) {
        $stmt = $this->db->prepare("
            INSERT INTO social_logins 
            (user_id, provider, provider_id, provider_email, provider_name, provider_avatar)
            VALUES (?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                provider_email = VALUES(provider_email),
                provider_name = VALUES(provider_name),
                provider_avatar = VALUES(provider_avatar),
                updated_at = NOW()
        ");
        
        $stmt->execute([
            $userId,
            $provider,
            $info['id'],
            $info['email'],
            $info['name'],
            $info['avatar']
        ]);
    }
    
    private function loginUser($userId) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE id = ? AND status = 'active'");
        $stmt->execute([$userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user) {
            return ['success' => false, 'error' => 'Hesap bulunamadı veya engellenmiş'];
        }
        
        // Tüm giriş türleri aynı güvenli oturum/cihaz/geçmiş katmanını kullanır.
        if (!function_exists('moni_complete_login')) {
            throw new RuntimeException('Güvenli oturum katmanı yüklenemedi.');
        }
        moni_complete_login($this->db, $user, false, 'social');
        
        return ['success' => true, 'user' => $user];
    }
    
    private function generateUniqueUsername($name) {
        // Türkçe karakterleri temizle ve sadece alfanumerik bırak
        $base = preg_replace('/[^a-zA-Z0-9]/', '', $this->turkishToEnglish($name));
        $base = strtolower($base);
        
        if (empty($base)) {
            $base = 'user';
        }
        
        $username = $base;
        $counter = 1;
        
        while ($this->usernameExists($username)) {
            $username = $base . $counter;
            $counter++;
        }
        
        return $username;
    }
    
    private function turkishToEnglish($str) {
        $tr = ['ç', 'ğ', 'ı', 'ö', 'ş', 'ü', 'Ç', 'Ğ', 'İ', 'Ö', 'Ş', 'Ü'];
        $en = ['c', 'g', 'i', 'o', 's', 'u', 'C', 'G', 'I', 'O', 'S', 'U'];
        return str_replace($tr, $en, $str);
    }
    
    private function usernameExists($username) {
        $stmt = $this->db->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        return $stmt->fetch() !== false;
    }
    
    private function generateState($provider) {
        $state = bin2hex(random_bytes(16));
        $_SESSION['oauth_state_' . $provider] = $state;
        return $state;
    }
    
    public function verifyState($provider, $state) {
        $sessionState = $_SESSION['oauth_state_' . $provider] ?? null;
        unset($_SESSION['oauth_state_' . $provider]);
        return $sessionState && $sessionState === $state;
    }
    
    // ==================== CURL HELPERS ====================
    
    private function curlPost($url, $data) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        return json_decode($response, true) ?: [];
    }
    
    private function curlGet($url, $accessToken) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $accessToken]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        return json_decode($response, true) ?: [];
    }
}