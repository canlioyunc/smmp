<?php
/**
 * Google Login - Yönlendirme
 */

require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../classes/SocialAuth.php';

$socialAuth = new SocialAuth($db);

$authUrl = $socialAuth->getGoogleAuthUrl();

if (!$authUrl) {
    header('Location: /login.php?error=' . urlencode('Google login aktif değil'));
    exit;
}

header('Location: ' . $authUrl);
exit;