<?php
/**
 * Discord Login - Yönlendirme
 */

require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../classes/SocialAuth.php';

$socialAuth = new SocialAuth($db);

$authUrl = $socialAuth->getDiscordAuthUrl();

if (!$authUrl) {
    header('Location: /login.php?error=' . urlencode('Discord login aktif değil'));
    exit;
}

header('Location: ' . $authUrl);
exit;