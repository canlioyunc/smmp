<?php
/**
 * Discord Login - Callback
 */

require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../classes/SocialAuth.php';

$socialAuth = new SocialAuth($db);

// Hata kontrolü
if (isset($_GET['error'])) {
    header('Location: /login.php?error=' . urlencode('Discord girişi iptal edildi'));
    exit;
}

// Code kontrolü
if (!isset($_GET['code'])) {
    header('Location: /login.php?error=' . urlencode('Geçersiz istek'));
    exit;
}

// State kontrolü (CSRF koruması)
if (!isset($_GET['state']) || !$socialAuth->verifyState('discord', $_GET['state'])) {
    header('Location: /login.php?error=' . urlencode('Güvenlik doğrulaması başarısız'));
    exit;
}

// Discord callback işle
$result = $socialAuth->handleDiscordCallback($_GET['code']);

if ($result['success']) {
    // Başarılı giriş
    setAlert('Discord ile giriş başarılı!', 'success');
    header('Location: /kullanici/');
    exit;
} else {
    // Hata
    header('Location: /login.php?error=' . urlencode($result['error']));
    exit;
}