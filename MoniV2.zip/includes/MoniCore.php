<?php
/**
 * v2 genişletilmiş çekirdek.
 * Mevcut tabloları koruyarak eklenti, güvenlik, cüzdan, fiyat, sağlayıcı ve finans katmanı ekler.
 */

if (defined('MONI_CORE_LOADED')) return;
define('MONI_CORE_LOADED', true);

function moni_table_ready(PDO $db, string $table): bool {
    static $cache = [];
    if (array_key_exists($table, $cache)) return $cache[$table];
    try {
        $db->query("SELECT 1 FROM `" . str_replace('`','',$table) . "` LIMIT 1");
        return $cache[$table] = true;
    } catch (Throwable $e) {
        return $cache[$table] = false;
    }
}

function moni_base_url_is_https(): bool {
    if (defined('SITE_URL') && SITE_URL !== '') return stripos(SITE_URL, 'https://') === 0;
    return false;
}

function moni_ip_matches_rule(string $ip,string $rule): bool {
    $rule=trim($rule);if($ip===''||$rule==='')return false;if($ip===$rule)return true;
    if(!str_contains($rule,'/'))return false;[$net,$bits]=array_pad(explode('/',$rule,2),2,'');
    if(!is_numeric($bits)||!filter_var($ip,FILTER_VALIDATE_IP)||!filter_var($net,FILTER_VALIDATE_IP))return false;$bits=(int)$bits;
    $ipBin=@inet_pton($ip);$netBin=@inet_pton($net);if($ipBin===false||$netBin===false||strlen($ipBin)!==strlen($netBin))return false;
    $max=strlen($ipBin)*8;if($bits<0||$bits>$max)return false;$bytes=intdiv($bits,8);$rem=$bits%8;
    if($bytes>0&&substr($ipBin,0,$bytes)!==substr($netBin,0,$bytes))return false;
    if($rem===0)return true;$mask=(0xff << (8-$rem)) & 0xff;return (ord($ipBin[$bytes])&$mask)===(ord($netBin[$bytes])&$mask);
}
function moni_remote_is_trusted_proxy(): bool {
    $remote=(string)($_SERVER['REMOTE_ADDR']??'');if($remote==='')return false;
    $rules=array_filter(array_map('trim',preg_split('/[\s,;]+/',(string)getSetting('trusted_proxy_ips',''))));
    foreach($rules as $rule)if(moni_ip_matches_rule($remote,$rule))return true;return false;
}
function moni_request_is_https(): bool {
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') return true;
    return moni_remote_is_trusted_proxy() && strtolower(trim(explode(',',(string)($_SERVER['HTTP_X_FORWARDED_PROTO']??''))[0]??''))==='https';
}

function moni_client_ip(): string {
    $remote=substr((string)($_SERVER['REMOTE_ADDR'] ?? ''),0,45);
    if(!moni_remote_is_trusted_proxy())return $remote;
    $candidates=[];
    if(!empty($_SERVER['HTTP_CF_CONNECTING_IP']))$candidates[]=(string)$_SERVER['HTTP_CF_CONNECTING_IP'];
    if(!empty($_SERVER['HTTP_X_FORWARDED_FOR']))foreach(explode(',',(string)$_SERVER['HTTP_X_FORWARDED_FOR']) as $x)$candidates[]=trim($x);
    if(!empty($_SERVER['HTTP_X_REAL_IP']))$candidates[]=(string)$_SERVER['HTTP_X_REAL_IP'];
    foreach($candidates as $ip){$ip=trim($ip);if(filter_var($ip,FILTER_VALIDATE_IP))return substr($ip,0,45);}return $remote;
}

function moni_device_id(): string {
    if (PHP_SAPI === 'cli') return 'cli';
    $raw = $_COOKIE['moni_device'] ?? '';
    if (!preg_match('/^[a-f0-9]{64}$/', $raw)) {
        $raw = bin2hex(random_bytes(32));
        setcookie('moni_device', $raw, [
            'expires' => time() + 86400 * 365 * 2,
            'path' => '/',
            'secure' => moni_request_is_https(),
            'httponly' => true,
            'samesite' => 'Lax'
        ]);
        $_COOKIE['moni_device'] = $raw;
    }
    return hash('sha256', $raw);
}

function moni_device_name(?string $ua = null): string {
    $ua = $ua ?? ($_SERVER['HTTP_USER_AGENT'] ?? '');
    $os = 'Bilinmeyen cihaz';
    if (stripos($ua, 'Windows') !== false) $os = 'Windows';
    elseif (stripos($ua, 'Macintosh') !== false || stripos($ua, 'Mac OS') !== false) $os = 'macOS';
    elseif (stripos($ua, 'Android') !== false) $os = 'Android';
    elseif (stripos($ua, 'iPhone') !== false || stripos($ua, 'iPad') !== false) $os = 'iOS/iPadOS';
    elseif (stripos($ua, 'Linux') !== false) $os = 'Linux';
    $browser = '';
    if (stripos($ua, 'Edg/') !== false) $browser = 'Edge';
    elseif (stripos($ua, 'Chrome/') !== false) $browser = 'Chrome';
    elseif (stripos($ua, 'Safari/') !== false) $browser = 'Safari';
    elseif (stripos($ua, 'Firefox/') !== false) $browser = 'Firefox';
    return trim($os . ($browser ? ' · ' . $browser : ''));
}

/* ------------------------- Plugins ------------------------- */
function moni_plugin_enabled(string $slug, ?PDO $db = null): bool {
    $db = $db ?: ($GLOBALS['db'] ?? null);
    if (!$db instanceof PDO || !moni_table_ready($db, 'plugins')) return false;
    static $cache = [];
    if (array_key_exists($slug, $cache)) return $cache[$slug];
    try {
        $st = $db->prepare("SELECT is_enabled FROM plugins WHERE slug=? LIMIT 1");
        $st->execute([$slug]);
        $enabled = (bool)$st->fetchColumn();
        // Gerçek teslim süresi tahmini temiz kurulumda pasiftir; demo sitelerde otomatik aktif gösterilir.
        if ($slug === 'real_delivery_eta' && !$enabled && (string)getSetting('demo_mode','0') === '1') $enabled = true;
        // Demo sitede hedef önizleme ve PWA kullanıcı tarafından ayrıca açılmadan görülebilir.
        if (in_array($slug, ['target_preview','pwa_app'], true) && !$enabled && (string)getSetting('demo_mode','0') === '1') $enabled = true;
        if ($slug === 'order_status_reasons' && !$enabled && (string)getSetting('demo_mode','0') === '1') $enabled = true;
        if (in_array($slug,['service_capacity_indicator','same_target_concurrency'],true) && !$enabled && (string)getSetting('demo_mode','0') === '1') $enabled = true;
        if ($slug === 'provider_failover' && $enabled) {
            $count = (int)$db->query("SELECT COUNT(*) FROM api_providers WHERE status='active'")->fetchColumn();
            if ($count < 2) $enabled = false;
        }
        return $cache[$slug] = $enabled;
    } catch (Throwable $e) { return false; }
}

function moni_plugin_setting(string $slug, string $key, $default = null) {
    $db = $GLOBALS['db'] ?? null;
    if (!$db instanceof PDO || !moni_table_ready($db, 'plugin_settings')) return $default;
    try {
        $st = $db->prepare("SELECT setting_value FROM plugin_settings WHERE plugin_slug=? AND setting_key=? LIMIT 1");
        $st->execute([$slug,$key]);
        $v = $st->fetchColumn();
        return $v === false ? $default : $v;
    } catch (Throwable $e) { return $default; }
}

function moni_set_plugin_setting(string $slug, string $key, $value): bool {
    $db = $GLOBALS['db'] ?? null;
    if (!$db instanceof PDO) return false;
    $st = $db->prepare("INSERT INTO plugin_settings(plugin_slug,setting_key,setting_value) VALUES(?,?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");
    return $st->execute([$slug,$key,(string)$value]);
}

/* ------------------------- Partial maintenance ------------------------- */
function moni_partial_maintenance_modules(): array {
    return [
        'orders'=>['label'=>'Sipariş Oluşturma','setting'=>'partial_maintenance_orders','message'=>'Sipariş oluşturma işlemleri kısa süreli bakım nedeniyle geçici olarak durduruldu. Mevcut siparişleriniz işlenmeye devam eder.'],
        'payments'=>['label'=>'Ödeme / Bakiye Yükleme','setting'=>'partial_maintenance_payments','message'=>'Bakiye yükleme ve yeni ödeme başlatma işlemleri geçici olarak bakımdadır. Daha sonra tekrar deneyin.'],
        'api'=>['label'=>'Müşteri API','setting'=>'partial_maintenance_api','message'=>'Müşteri API erişimi geçici olarak bakımdadır.'],
        'child_panels'=>['label'=>'Child Panel','setting'=>'partial_maintenance_child_panels','message'=>'Child Panel işlemleri geçici olarak bakımdadır.'],
    ];
}
function moni_partial_maintenance_bypass(PDO $db): bool {
    if(function_exists('isAdmin') && isAdmin()) return true;
    $ip=function_exists('moni_client_ip')?moni_client_ip():(string)($_SERVER['REMOTE_ADDR']??'');
    $allowed=(string)getSetting('maintenance_allowed_ips','');
    if($ip!==''&&$allowed!==''){
        foreach(preg_split('/[\s,;]+/',$allowed,-1,PREG_SPLIT_NO_EMPTY) as $rule){ if(hash_equals(trim($rule),$ip)) return true; }
    }
    return false;
}
function moni_partial_maintenance_active(PDO $db,string $module,bool $allowBypass=true): bool {
    $mods=moni_partial_maintenance_modules(); if(!isset($mods[$module])) return false;
    if((string)getSetting($mods[$module]['setting'],'0')!=='1') return false;
    if($allowBypass && moni_partial_maintenance_bypass($db)) return false;
    return true;
}
function moni_partial_maintenance_message(PDO $db,string $module): string {
    $mods=moni_partial_maintenance_modules(); if(!isset($mods[$module])) return 'Bu özellik geçici olarak bakımdadır.';
    $custom=trim((string)getSetting('partial_maintenance_'.$module.'_message',''));
    return $custom!==''?$custom:$mods[$module]['message'];
}
function moni_partial_maintenance_status(PDO $db): array {
    $out=[]; foreach(moni_partial_maintenance_modules() as $key=>$meta){
        $out[$key]=['active'=>(string)getSetting($meta['setting'],'0')==='1','label'=>$meta['label'],'message'=>moni_partial_maintenance_message($db,$key)];
    } return $out;
}
function moni_partial_maintenance_guard(PDO $db,string $module,bool $json=false,bool $allowBypass=true): void {
    if(!moni_partial_maintenance_active($db,$module,$allowBypass)) return;
    $message=moni_partial_maintenance_message($db,$module); http_response_code(503); header('Retry-After: 300');
    if($json){ header('Content-Type: application/json; charset=utf-8'); echo json_encode(['error'=>$message,'maintenance'=>true,'module'=>$module],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
    $safe=htmlspecialchars($message,ENT_QUOTES,'UTF-8');
    echo '<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Geçici Bakım</title><style>body{font-family:Inter,system-ui,sans-serif;background:#0f1220;color:#eef2ff;min-height:100vh;display:grid;place-items:center;margin:0;padding:24px}.m{max-width:620px;background:#171b2e;border:1px solid #2a3150;border-radius:22px;padding:32px;box-shadow:0 24px 70px rgba(0,0,0,.3)}.i{width:56px;height:56px;border-radius:16px;background:#f59e0b22;color:#fbbf24;display:grid;place-items:center;font-size:28px;margin-bottom:18px}h1{font-size:24px;margin:0 0 10px}p{color:#aeb7d3;line-height:1.65;margin:0}</style></head><body><main class="m"><div class="i">⚙</div><h1>Bu bölüm geçici olarak bakımdadır</h1><p>'.$safe.'</p></main></body></html>'; exit;
}

$GLOBALS['MONI_HOOKS'] = $GLOBALS['MONI_HOOKS'] ?? [];
function moni_add_hook(string $name, callable $callback, int $priority = 10): void {
    $GLOBALS['MONI_HOOKS'][$name][$priority][] = $callback;
}
function moni_do_hook(string $name, ...$args): void {
    if (empty($GLOBALS['MONI_HOOKS'][$name])) return;
    ksort($GLOBALS['MONI_HOOKS'][$name]);
    foreach ($GLOBALS['MONI_HOOKS'][$name] as $callbacks) foreach ($callbacks as $cb) $cb(...$args);
}
function moni_filter(string $name, $value, ...$args) {
    if (empty($GLOBALS['MONI_HOOKS'][$name])) return $value;
    ksort($GLOBALS['MONI_HOOKS'][$name]);
    foreach ($GLOBALS['MONI_HOOKS'][$name] as $callbacks) foreach ($callbacks as $cb) $value = $cb($value, ...$args);
    return $value;
}

function moni_discover_plugins(): array {
    static $found=null;if($found!==null)return $found;$found=[];
    $base=dirname(__DIR__).'/plugins';
    foreach(glob($base.'/*/plugin.php')?:[] as $file){
        $meta=require $file;if(!is_array($meta)||empty($meta['slug']))continue;$meta['path']=$file;$found[$meta['slug']]=$meta;
    }
    return $found;
}
function moni_load_plugins(PDO $db):void{
    foreach(moni_discover_plugins() as $slug=>$meta){
        try{$db->prepare("INSERT IGNORE INTO plugins(slug,name,description,version,is_enabled) VALUES(?,?,?,?,?)")->execute([$slug,$meta['name']??$slug,$meta['description']??'',$meta['version']??'1.0.0',!empty($meta['default_enabled'])?1:0]);$db->prepare("UPDATE plugins SET name=?,description=?,version=? WHERE slug=?")->execute([$meta['name']??$slug,$meta['description']??'',$meta['version']??'1.0.0',$slug]);}catch(Throwable $e){}
        $boot=dirname($meta['path']).'/bootstrap.php';if(moni_plugin_enabled($slug,$db)&&is_file($boot))require_once $boot;
    }
}

/* ------------------------- Secret storage ------------------------- */
function moni_canonical_site_url(): string {
    $candidates=[];
    if(defined('SITE_URL') && trim((string)SITE_URL)!=='')$candidates[]=(string)SITE_URL;
    if(function_exists('getSetting')){$v=(string)getSetting('site_url','');if($v!=='')$candidates[]=$v;}
    foreach($candidates as $url){
        $url=rtrim(trim($url),'/');$p=@parse_url($url);
        if(is_array($p)&&in_array(strtolower((string)($p['scheme']??'')),['http','https'],true)&&!empty($p['host'])&&empty($p['user'])&&empty($p['pass']))return $url;
    }
    return '';
}

function moni_secret_key_paths(): array {
    $root=dirname(__DIR__);
    return [dirname($root).'/.moni_secret_key',$root.'/storage/.moni_secret_key'];
}
function moni_secret_key(): string {
    [$outside,$legacy]=moni_secret_key_paths();
    try {
        // Var olan anahtar her zaman önceliklidir; aksi halde mevcut şifreli veriler okunamaz hale gelir.
        if (is_file($outside)) {$raw=trim((string)@file_get_contents($outside));if(preg_match('/^[A-Fa-f0-9]{64}$/',$raw))return hex2bin($raw);}
        if (is_file($legacy)) {
            $raw=trim((string)@file_get_contents($legacy));
            if(preg_match('/^[A-Fa-f0-9]{64}$/',$raw)){
                if(is_writable(dirname($outside)) && @file_put_contents($outside,$raw,LOCK_EX)!==false){@chmod($outside,0600);@unlink($legacy);}
                return hex2bin($raw);
            }
        }
        // Container/read-only dağıtımlarda açıkça verilen uygulama anahtarı kullanılabilir.
        $envKey=trim((string)getenv('MONI_APP_KEY'));
        if(preg_match('/^[A-Fa-f0-9]{64}$/',$envKey))return hex2bin($envKey);
        // İlk kurulumda kriptografik anahtar üret ve mümkünse web kökü dışında sakla.
        foreach ([$outside,$legacy] as $path) {
            $dir=dirname($path);
            if(!is_dir($dir) && !@mkdir($dir,0750,true))continue;
            if(!is_writable($dir))continue;
            $key=random_bytes(32);$tmp=$path.'.tmp-'.bin2hex(random_bytes(4));
            if(@file_put_contents($tmp,bin2hex($key),LOCK_EX)===false)continue;
            @chmod($tmp,0600);
            if(@rename($tmp,$path)){@chmod($path,0600);return $key;}
            @unlink($tmp);
        }
    } catch(Throwable $e){error_log('Secret key storage: '.$e->getMessage());}
    // Güvensiz, tahmin edilebilir deterministic fallback artık yok. Secret depolaması fail-closed çalışır.
    throw new RuntimeException('MONI şifreleme anahtarı oluşturulamadı. MONI_APP_KEY tanımlayın veya private storage dizinine yazma izni verin.');
}
function moni_secret_key_fingerprint(): string {
    return hash('sha256',moni_secret_key());
}
function moni_install_secret_key_hex(string $hex): array {
    $hex=strtolower(trim($hex));
    if(!preg_match('/^[a-f0-9]{64}$/',$hex))return ['ok'=>false,'error'=>'Kurtarma anahtarı tam 64 hexadecimal karakter olmalıdır.'];
    [$outside,$legacy]=moni_secret_key_paths();
    foreach([$outside,$legacy] as $path){
        $dir=dirname($path);
        if(!is_dir($dir)&&!@mkdir($dir,0750,true))continue;
        if(!is_writable($dir))continue;
        $tmp=$path.'.tmp-'.bin2hex(random_bytes(4));
        if(@file_put_contents($tmp,$hex,LOCK_EX)===false)continue;
        @chmod($tmp,0600);
        if(@rename($tmp,$path)){@chmod($path,0600);return ['ok'=>true,'path'=>$path,'fingerprint'=>hash('sha256',hex2bin($hex))];}
        @unlink($tmp);
    }
    return ['ok'=>false,'error'=>'Kurtarma anahtarı private storage alanına yazılamadı.'];
}

function moni_encrypt_secret(?string $plain): string {
    $plain = (string)$plain;
    if ($plain === '' || str_starts_with($plain, 'enc:v1:')) return $plain;
    if (!function_exists('openssl_encrypt')) throw new RuntimeException('Güvenli secret şifreleme kullanılamıyor: OpenSSL eksik.');
    $iv = random_bytes(12); $tag = '';
    $cipher = openssl_encrypt($plain, 'aes-256-gcm', moni_secret_key(), OPENSSL_RAW_DATA, $iv, $tag);
    if ($cipher === false) throw new RuntimeException('Secret şifrelenemedi; düz metin olarak kaydetme reddedildi.');
    return 'enc:v1:' . base64_encode(json_encode([
        'iv' => base64_encode($iv), 'tag' => base64_encode($tag), 'ct' => base64_encode($cipher)
    ], JSON_UNESCAPED_SLASHES));
}
function moni_decrypt_secret(?string $stored): string {
    $stored = (string)$stored;
    if (!str_starts_with($stored, 'enc:v1:')) return $stored;
    if (!function_exists('openssl_decrypt')) return '';
    $raw = base64_decode(substr($stored, 7), true);
    $data = $raw ? json_decode($raw, true) : null;
    if (!is_array($data)) return '';
    $plain = openssl_decrypt(base64_decode($data['ct'] ?? ''), 'aes-256-gcm', moni_secret_key(), OPENSSL_RAW_DATA,
        base64_decode($data['iv'] ?? ''), base64_decode($data['tag'] ?? ''));
    return $plain === false ? '' : $plain;
}

function moni_migrate_secrets_once(PDO $db): void {
    if (!moni_table_ready($db, 'settings')) return;
    try {
        $st = $db->prepare("SELECT setting_value FROM settings WHERE setting_key='moni_secret_storage_v1' LIMIT 1");
        $st->execute();
        if ((string)$st->fetchColumn() === '1') return;

        if (moni_table_ready($db, 'api_providers')) {
            foreach ($db->query("SELECT id,api_key FROM api_providers")->fetchAll(PDO::FETCH_ASSOC) as $r) {
                if (!empty($r['api_key']) && !str_starts_with($r['api_key'],'enc:v1:')) {
                    $db->prepare("UPDATE api_providers SET api_key=? WHERE id=?")->execute([moni_encrypt_secret($r['api_key']),$r['id']]);
                }
            }
        }
        foreach (['smtp_password','invoice_provider_api_key'] as $key) {
            $s=$db->prepare("SELECT setting_value FROM settings WHERE setting_key=?"); $s->execute([$key]); $v=$s->fetchColumn();
            if ($v !== false && $v !== '' && !str_starts_with((string)$v,'enc:v1:')) {
                $db->prepare("UPDATE settings SET setting_value=? WHERE setting_key=?")->execute([moni_encrypt_secret((string)$v),$key]);
            }
        }
        if (moni_table_ready($db,'social_login_settings')) {
            foreach ($db->query("SELECT id,client_secret FROM social_login_settings")->fetchAll(PDO::FETCH_ASSOC) as $r) {
                if (!empty($r['client_secret']) && !str_starts_with($r['client_secret'],'enc:v1:'))
                    $db->prepare("UPDATE social_login_settings SET client_secret=? WHERE id=?")->execute([moni_encrypt_secret($r['client_secret']),$r['id']]);
            }
        }
        if (moni_table_ready($db,'users')) {
            foreach ($db->query("SELECT id,two_factor_secret FROM users WHERE two_factor_secret IS NOT NULL AND two_factor_secret<>''")->fetchAll(PDO::FETCH_ASSOC) as $r) {
                if (!str_starts_with($r['two_factor_secret'],'enc:v1:'))
                    $db->prepare("UPDATE users SET two_factor_secret=? WHERE id=?")->execute([moni_encrypt_secret($r['two_factor_secret']),$r['id']]);
            }
        }
        if (moni_table_ready($db,'payment_methods')) {
            foreach ($db->query("SELECT id,config FROM payment_methods WHERE config IS NOT NULL AND config<>''")->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $cfg=json_decode($r['config'],true); if(!is_array($cfg)) continue; $changed=false;
                foreach(['api_key','secret_key','merchant_key','client_secret'] as $k) if(!empty($cfg[$k])&&!str_starts_with((string)$cfg[$k],'enc:v1:')){$cfg[$k]=moni_encrypt_secret((string)$cfg[$k]);$changed=true;}
                if($changed)$db->prepare("UPDATE payment_methods SET config=? WHERE id=?")->execute([json_encode($cfg,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),$r['id']]);
            }
        }
        $db->prepare("INSERT INTO settings(setting_key,setting_value) VALUES('moni_secret_storage_v1','1') ON DUPLICATE KEY UPDATE setting_value='1'")->execute();
    } catch (Throwable $e) {
        error_log('Secret storage migration: '.$e->getMessage());
    }
}

/* ------------------------- Security history / sessions ------------------------- */
function moni_security_event(?int $userId, string $event, string $severity='info', array $metadata=[]): void {
    $db=$GLOBALS['db']??null; if(!$db instanceof PDO||!moni_table_ready($db,'security_events')) return;
    try{$st=$db->prepare("INSERT INTO security_events(user_id,event_type,severity,ip_address,device_id,user_agent,metadata_json) VALUES(?,?,?,?,?,?,?)");
        $st->execute([$userId,$event,$severity,moni_client_ip(),moni_device_id(),substr($_SERVER['HTTP_USER_AGENT']??'',0,500),$metadata?json_encode($metadata,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):null]);
    }catch(Throwable $e){}
}

function moni_track_session(PDO $db, int $userId): bool {
    if (!moni_table_ready($db,'user_sessions') || PHP_SAPI==='cli') return true;
    $hash=hash('sha256',session_id()); $device=moni_device_id();
    try{
        // Önce mevcut session kimliğinin iptal edilip edilmediğini kontrol et; rotate bundan sonra yapılır.
        $st=$db->prepare("SELECT revoked_at FROM user_sessions WHERE session_hash=? LIMIT 1");$st->execute([$hash]);$rev=$st->fetchColumn();
        if($rev!==false&&$rev!==null){
            moni_security_event($userId,'revoked_session_blocked','warning');
            moni_forget_remember_token($db);$_SESSION=[]; session_destroy();
            if(!headers_sent()){header('Location: /login.php?error=session_revoked');exit;}
            return false;
        }
        $regenInterval=(int)($GLOBALS['SEC_SESSION_REGEN_INTERVAL']??300);
        if($regenInterval>0 && !empty($_SESSION['_sec_regen_ts']) && time()-(int)$_SESSION['_sec_regen_ts']>$regenInterval){
            $oldHash=$hash;
            session_regenerate_id(true);
            $_SESSION['_sec_regen_ts']=time();
            $hash=hash('sha256',session_id());
            // Eski kimliği aktif oturum listesinde bırakma.
            $db->prepare("UPDATE user_sessions SET revoked_at=COALESCE(revoked_at,NOW()) WHERE user_id=? AND session_hash=?")->execute([$userId,$oldHash]);
        }
        $st=$db->prepare("INSERT INTO user_sessions(user_id,session_hash,device_id,device_name,ip_address,user_agent,last_activity_at) VALUES(?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE user_id=VALUES(user_id),device_id=VALUES(device_id),device_name=VALUES(device_name),ip_address=VALUES(ip_address),user_agent=VALUES(user_agent),last_activity_at=NOW()");
        $st->execute([$userId,$hash,$device,moni_device_name(),moni_client_ip(),substr($_SERVER['HTTP_USER_AGENT']??'',0,500)]);
        return true;
    }catch(Throwable $e){return true;}
}

function moni_revoke_session(PDO $db, int $userId, int $sessionRowId): bool {
    $st=$db->prepare("UPDATE user_sessions SET revoked_at=NOW() WHERE id=? AND user_id=? AND revoked_at IS NULL");
    $ok=$st->execute([$sessionRowId,$userId]);
    if($st->rowCount())moni_security_event($userId,'session_revoked','info',['session_row_id'=>$sessionRowId]);
    return $ok;
}

function moni_issue_remember_token(PDO $db, int $userId, int $days=30): void {
    if(!moni_table_ready($db,'remember_tokens')) return;
    $selector=bin2hex(random_bytes(12)); $validator=bin2hex(random_bytes(32));
    $hash=hash('sha256',$validator); $exp=date('Y-m-d H:i:s',time()+86400*$days);
    $db->prepare("INSERT INTO remember_tokens(user_id,selector,validator_hash,expires_at,user_agent_hash,device_id) VALUES(?,?,?,?,?,?)")
       ->execute([$userId,$selector,$hash,$exp,hash('sha256',$_SERVER['HTTP_USER_AGENT']??''),moni_device_id()]);
    setcookie('moni_remember',$selector.'.'.$validator,[
        'expires'=>time()+86400*$days,'path'=>'/','secure'=>moni_request_is_https(),'httponly'=>true,'samesite'=>'Lax'
    ]);
}

function moni_forget_remember_token(PDO $db): void {
    $cookie=$_COOKIE['moni_remember']??'';
    if(str_contains($cookie,'.')&&moni_table_ready($db,'remember_tokens')){
        [$selector]=explode('.',$cookie,2); try{$db->prepare("DELETE FROM remember_tokens WHERE selector=?")->execute([$selector]);}catch(Throwable $e){}
    }
    setcookie('moni_remember','',['expires'=>time()-3600,'path'=>'/','secure'=>moni_request_is_https(),'httponly'=>true,'samesite'=>'Lax']);
}

function moni_complete_login(PDO $db, array $user, bool $remember=false, string $method='password'): void {
    session_regenerate_id(true);
    $_SESSION['user_id']=$user['id']; $_SESSION['username']=$user['username']; $_SESSION['email']=$user['email'];
    $_SESSION['role']=$user['role']; $_SESSION['balance']=$user['balance']; $_SESSION['_sec_regen_ts']=time();
    $db->prepare("UPDATE users SET last_login=NOW(),last_ip=? WHERE id=?")->execute([moni_client_ip(),$user['id']]);
    if($remember)moni_issue_remember_token($db,(int)$user['id']);
    moni_track_session($db,(int)$user['id']);
    moni_security_event((int)$user['id'],'login_success','info',['method'=>$method]);
}

function moni_attempt_remember_login(PDO $db): void {
    if(!empty($_SESSION['user_id'])||empty($_COOKIE['moni_remember'])||!moni_table_ready($db,'remember_tokens'))return;
    $parts=explode('.',$_COOKIE['moni_remember'],2); if(count($parts)!==2)return; [$selector,$validator]=$parts;
    if(!preg_match('/^[a-f0-9]{24}$/',$selector)||!preg_match('/^[a-f0-9]{64}$/',$validator))return;
    try{
        $st=$db->prepare("SELECT rt.*,u.* FROM remember_tokens rt JOIN users u ON u.id=rt.user_id WHERE rt.selector=? AND rt.expires_at>NOW() AND u.status='active' LIMIT 1");
        $st->execute([$selector]);$row=$st->fetch(PDO::FETCH_ASSOC);
        $uaHash=hash('sha256',$_SERVER['HTTP_USER_AGENT']??'');$deviceId=moni_device_id();
        $tokenValid=$row && hash_equals((string)$row['validator_hash'],hash('sha256',$validator));
        if($tokenValid && !empty($row['user_agent_hash']))$tokenValid=hash_equals((string)$row['user_agent_hash'],$uaHash);
        if($tokenValid && !empty($row['device_id']))$tokenValid=hash_equals((string)$row['device_id'],$deviceId);
        if(!$tokenValid){moni_forget_remember_token($db);return;}
        $uid=(int)$row['user_id']; $userSt=$db->prepare("SELECT * FROM users WHERE id=? LIMIT 1");$userSt->execute([$uid]);$user=$userSt->fetch(PDO::FETCH_ASSOC);
        if(!$user){moni_forget_remember_token($db);return;}
        $db->prepare("DELETE FROM remember_tokens WHERE selector=?")->execute([$selector]);
        moni_complete_login($db,$user,true,'remember_token');
    }catch(Throwable $e){}
}

function moni_auth_blocked(PDO $db, string $identifier, string $ip): array {
    if(!moni_table_ready($db,'auth_attempts'))return [false,0];
    $ih=hash('sha256',mb_strtolower(trim($identifier),'UTF-8'));
    try{
        $s=$db->prepare("SELECT COUNT(*) FROM auth_attempts WHERE was_successful=0 AND created_at>DATE_SUB(NOW(),INTERVAL 15 MINUTE) AND identifier_hash=?");$s->execute([$ih]);$byId=(int)$s->fetchColumn();
        $s=$db->prepare("SELECT COUNT(*) FROM auth_attempts WHERE was_successful=0 AND created_at>DATE_SUB(NOW(),INTERVAL 15 MINUTE) AND ip_address=?");$s->execute([$ip]);$byIp=(int)$s->fetchColumn();
        return [($byId>=8||$byIp>=30),max($byId,$byIp)];
    }catch(Throwable $e){return [false,0];}
}
function moni_auth_record(PDO $db,string $identifier,string $ip,bool $success):void{
    if(!moni_table_ready($db,'auth_attempts'))return;
    try{$db->prepare("INSERT INTO auth_attempts(identifier_hash,ip_address,was_successful) VALUES(?,?,?)")->execute([hash('sha256',mb_strtolower(trim($identifier),'UTF-8')),$ip,$success?1:0]);}catch(Throwable $e){}
}

/* ------------------------- Safe admin-authored HTML ------------------------- */
function moni_sanitize_admin_html(string $html): string {
    // Özel sayfalarda HTML'e izin verilir ancak çalıştırılabilir/aktif içerik temizlenir.
    $html = preg_replace('#<(script|iframe|object|embed|form|input|button|textarea|select|option|meta|link|base|svg|math)\\b[^>]*>.*?</\\1\\s*>#is', '', $html);
    $html = preg_replace('#<(script|iframe|object|embed|form|input|button|textarea|select|option|meta|link|base|svg|math)\\b[^>]*/?>#is', '', $html);
    $html = preg_replace('/<\\?(?:php|=)?|\\?>/i', '', $html);

    $allowedTags = ['p','br','strong','b','em','i','u','s','h2','h3','h4','h5','h6','ul','ol','li','a','img','blockquote','code','pre','hr','div','span','table','thead','tbody','tfoot','tr','th','td'];
    if (class_exists('DOMDocument')) {
        $previous = libxml_use_internal_errors(true);
        $dom = new DOMDocument('1.0', 'UTF-8');
        $wrapper = '<div id="moni-html-root">'.$html.'</div>';
        $loaded = $dom->loadHTML('<?xml encoding="utf-8" ?>'.$wrapper, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        if ($loaded) {
            $danger = ['script'=>1,'iframe'=>1,'object'=>1,'embed'=>1,'form'=>1,'input'=>1,'button'=>1,'textarea'=>1,'select'=>1,'option'=>1,'meta'=>1,'link'=>1,'base'=>1,'svg'=>1,'math'=>1];
            $globalAttrs = ['class'=>1,'title'=>1,'style'=>1];
            $tagAttrs = [
                'a'=>['href'=>1,'target'=>1,'rel'=>1],
                'img'=>['src'=>1,'alt'=>1,'width'=>1,'height'=>1,'loading'=>1],
                'th'=>['colspan'=>1,'rowspan'=>1], 'td'=>['colspan'=>1,'rowspan'=>1],
            ];
            $walk = function($node) use (&$walk,$allowedTags,$danger,$globalAttrs,$tagAttrs) {
                for ($child=$node->firstChild; $child;) {
                    $next=$child->nextSibling;
                    if ($child instanceof DOMElement) {
                        $tag=strtolower($child->tagName);
                        if (isset($danger[$tag])) {
                            if ($child->parentNode) $child->parentNode->removeChild($child);
                            $child=$next; continue;
                        }
                        if (!in_array($tag,$allowedTags,true) && $child->getAttribute('id')!=='moni-html-root') {
                            while($child->firstChild && $child->parentNode) $child->parentNode->insertBefore($child->firstChild,$child);
                            if ($child->parentNode) $child->parentNode->removeChild($child);
                            $child=$next; continue;
                        }
                        if ($child->hasAttributes()) {
                            $attrs=[]; foreach($child->attributes as $a)$attrs[]=$a->name;
                            foreach($attrs as $name) {
                                $ln=strtolower($name);$val=(string)$child->getAttribute($name);
                                $ok=isset($globalAttrs[$ln])||isset($tagAttrs[$tag][$ln]);
                                if(str_starts_with($ln,'on')||$ln==='srcdoc'||!$ok){$child->removeAttribute($name);continue;}
                                if(in_array($ln,['href','src'],true)){
                                    $v=trim(html_entity_decode($val,ENT_QUOTES|ENT_HTML5,'UTF-8'));
                                    $isImgData=$tag==='img'&&$ln==='src'&&preg_match('#^data:image/(?:png|jpeg|gif|webp);base64,#i',$v);
                                    if(!$isImgData&&!preg_match('#^(?:https?://|mailto:|tel:|/|\\./|\\../|#)#i',$v))$child->removeAttribute($name);
                                }
                                if($ln==='style'&&preg_match('/(?:expression\\s*\\(|javascript\\s*:|url\\s*\\()/i',$val))$child->removeAttribute($name);
                            }
                        }
                        if($tag==='a'&&strtolower($child->getAttribute('target'))==='_blank')$child->setAttribute('rel','noopener noreferrer');
                        if($tag==='img'&&!$child->hasAttribute('loading'))$child->setAttribute('loading','lazy');
                    }
                    $walk($child);$child=$next;
                }
            };
            $root=$dom->getElementById('moni-html-root');
            if($root){$walk($root);$out='';foreach($root->childNodes as $c)$out.=$dom->saveHTML($c);libxml_clear_errors();libxml_use_internal_errors($previous);return $out;}
        }
        libxml_clear_errors(); libxml_use_internal_errors($previous);
    }
    // DOM eklentisi olmayan hostingler için kısıtlı fallback.
    $html=strip_tags($html,'<p><br><strong><b><em><i><u><s><h2><h3><h4><h5><h6><ul><ol><li><a><img><blockquote><code><pre><hr><div><span><table><thead><tbody><tfoot><tr><th><td>');
    $html=preg_replace("/\\s(?:on[a-z]+|srcdoc)\\s*=\\s*(\"[^\"]*\"|'[^']*'|[^\\s>]+)/i",'', $html);
    $html=preg_replace("/(href|src)\\s*=\\s*([\"'])\\s*(?:javascript|vbscript|data:text\\/html)[^\"']*\\2/i",'$1="#"',$html);
    return $html;
}

/* ------------------------- Safe upload ------------------------- */
function moni_safe_upload(array $file,string $purpose,array $allowedMimes,int $maxBytes): array {
    if(($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)return ['ok'=>false,'error'=>'Yükleme başarısız.'];
    if(($file['size']??0)<=0||$file['size']>$maxBytes)return ['ok'=>false,'error'=>'Dosya boyutu izin verilen sınırı aşıyor.'];
    $tmp=$file['tmp_name']??''; if(!$tmp||!is_uploaded_file($tmp))return ['ok'=>false,'error'=>'Geçersiz yükleme.'];
    $finfo=new finfo(FILEINFO_MIME_TYPE);$mime=$finfo->file($tmp)?:'';
    if(!in_array($mime,$allowedMimes,true))return ['ok'=>false,'error'=>'Dosya türüne izin verilmiyor.'];
    $map=['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp','application/pdf'=>'pdf','text/plain'=>'txt','video/mp4'=>'mp4','video/webm'=>'webm','video/ogg'=>'ogv','image/x-icon'=>'ico','image/vnd.microsoft.icon'=>'ico'];
    if(empty($map[$mime]))return ['ok'=>false,'error'=>'Güvenli uzantı eşlemesi bulunamadı.'];
    $purpose=preg_replace('/[^a-z0-9_-]/i','',$purpose)?:'files';
    $dir=dirname(__DIR__).'/uploads/'.$purpose.'/'; if(!is_dir($dir)&&!mkdir($dir,0755,true))return ['ok'=>false,'error'=>'Yükleme klasörü oluşturulamadı.'];
    $name=$purpose.'_'.bin2hex(random_bytes(16)).'.'.$map[$mime];$path=$dir.$name;
    if(!move_uploaded_file($tmp,$path))return ['ok'=>false,'error'=>'Dosya kaydedilemedi.'];
    @chmod($path,0644);
    return ['ok'=>true,'path'=>'uploads/'.$purpose.'/'.$name,'mime'=>$mime,'size'=>(int)$file['size']];
}

/* ------------------------- Maintenance ------------------------- */
function moni_maintenance_reason(?int $serviceId=null,?int $providerId=null): ?string {
    $db=$GLOBALS['db']??null;if(!$db instanceof PDO||!moni_table_ready($db,'maintenance_windows'))return null;
    $clauses=[];$params=[];
    if($serviceId){$clauses[]="(scope_type='service' AND scope_id=?)";$params[]=$serviceId;}
    if($providerId){$clauses[]="(scope_type='provider' AND scope_id=?)";$params[]=$providerId;}
    if(!$clauses)return null;
    try{$st=$db->prepare("SELECT reason FROM maintenance_windows WHERE is_active=1 AND starts_at<=NOW() AND ends_at>=NOW() AND (".implode(' OR ',$clauses).") ORDER BY starts_at DESC LIMIT 1");$st->execute($params);$r=$st->fetchColumn();return $r===false?null:($r?:'Bu servis/sağlayıcı bakımda.');}catch(Throwable $e){return null;}
}

/* ------------------------- Pricing ------------------------- */
function moni_minimum_sale_price(array $service): float {
    $db=$GLOBALS['db']??null;$cost=(float)($service['cost_per_1000']??0);if(!$db instanceof PDO||!moni_table_ready($db,'profit_margin_policies'))return 0.0;
    try{
        $candidates=[];
        $st=$db->prepare("SELECT * FROM profit_margin_policies WHERE is_active=1 AND ((scope_type='service' AND scope_id=?) OR (scope_type='category' AND scope_id=?) OR scope_type='global') ORDER BY FIELD(scope_type,'service','category','global') LIMIT 1");
        $st->execute([(int)($service['id']??0),(int)($service['category_id']??0)]);$p=$st->fetch(PDO::FETCH_ASSOC);
        if(!$p)return 0.0;
        return $p['margin_type']==='fixed'?$cost+(float)$p['margin_value']:$cost*(1+((float)$p['margin_value']/100));
    }catch(Throwable $e){return 0.0;}
}

function moni_effective_price_per_1000(array $service,?int $userId=null): float {
    $db=$GLOBALS['db']??null;$price=(float)($service['price_per_1000']??0);
    if($userId&&$db instanceof PDO&&moni_table_ready($db,'user_price_rules')){
        try{
            $st=$db->prepare("SELECT role FROM users WHERE id=?");$st->execute([$userId]);$role=(string)$st->fetchColumn();
            $q=$db->prepare("SELECT * FROM user_price_rules WHERE is_active=1 AND (starts_at IS NULL OR starts_at<=NOW()) AND (ends_at IS NULL OR ends_at>=NOW()) AND ((target_type='user' AND target_value=?) OR (target_type='role' AND target_value=?)) AND (scope_type='all' OR (scope_type='service' AND scope_id=?) OR (scope_type='category' AND scope_id=?)) ORDER BY (target_type='user') DESC, FIELD(scope_type,'service','category','all') LIMIT 1");
            $q->execute([(string)$userId,$role,(int)($service['id']??0),(int)($service['category_id']??0)]);$r=$q->fetch(PDO::FETCH_ASSOC);
            if($r){$v=(float)$r['rule_value'];if($r['rule_type']==='discount_percent')$price*=(1-$v/100);elseif($r['rule_type']==='markup_percent')$price*=(1+$v/100);elseif($r['rule_type']==='fixed_per_1000')$price=$v;}
        }catch(Throwable $e){}
    }
    $price=max($price,moni_minimum_sale_price($service));
    if(function_exists('moni_child_panel_markup') && $db instanceof PDO){$markup=moni_child_panel_markup($db);if($markup>0)$price*=1+($markup/100);}
    if($userId && $db instanceof PDO && function_exists('moni_group_price'))$price=moni_group_price($db,$userId,$price);
    if($userId && $db instanceof PDO && function_exists('moni_premium_apply_price'))$price=moni_premium_apply_price($db,$userId,$service,$price);
    // Premium ve grup indirimleri minimum kâr tabanını aşamaz.
    $price=max($price,moni_minimum_sale_price($service));
    return round($price,4);
}

function moni_record_order_snapshot(PDO $db,int $orderId,array $service,float $salePer1000):void{
    if(!moni_table_ready($db,'order_financial_snapshots'))return;
    $qty=(int)($service['_order_quantity']??0);$providerQty=(int)($service['_provider_quantity']??$qty);$cost=(float)($service['cost_per_1000']??0);$expected=$providerQty>0?($providerQty/1000)*$cost:0;$revenue=$qty>0?($qty/1000)*$salePer1000:0;$profit=$revenue-$expected;
    try{$db->prepare("INSERT IGNORE INTO order_financial_snapshots(order_id,currency_code,sale_per_1000,cost_per_1000,expected_cost,expected_profit) VALUES(?,?,?,?,?,?)")
        ->execute([$orderId,($GLOBALS['siteSettings']['currency']??'TRY'),$salePer1000,$cost,$expected,$profit]);}catch(Throwable $e){}
}

/* ------------------------- Idempotency / duplicates ------------------------- */
function moni_order_idempotency_begin(PDO $db,int $userId,string $source,string $key,array $request):array{
    if(!moni_plugin_enabled('order_idempotency',$db)||!moni_table_ready($db,'order_idempotency'))return ['enabled'=>false,'duplicate'=>false,'row_id'=>null];
    $key=substr(trim($key),0,128);if($key==='')return ['enabled'=>true,'duplicate'=>false,'row_id'=>null];
    $hash=hash('sha256',json_encode($request,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
    try{
        // Aynı anahtarın süresi dolmuş eski satırı yeni siparişi gereksiz yere kilitlemesin.
        $db->prepare("DELETE FROM order_idempotency WHERE user_id=? AND source=? AND idempotency_key=? AND expires_at<=NOW()")->execute([$userId,$source,$key]);
        $st=$db->prepare("SELECT * FROM order_idempotency WHERE user_id=? AND source=? AND idempotency_key=? AND expires_at>NOW() LIMIT 1");$st->execute([$userId,$source,$key]);$row=$st->fetch(PDO::FETCH_ASSOC);
        if($row){if(!hash_equals($row['request_hash'],$hash))return ['enabled'=>true,'duplicate'=>true,'conflict'=>true,'order_id'=>$row['order_id']];return ['enabled'=>true,'duplicate'=>true,'conflict'=>false,'order_id'=>$row['order_id'],'response_json'=>$row['response_json']];}
        $db->prepare("INSERT INTO order_idempotency(user_id,source,idempotency_key,request_hash,expires_at) VALUES(?,?,?,?,DATE_ADD(NOW(),INTERVAL 24 HOUR))")->execute([$userId,$source,$key,$hash]);
        return ['enabled'=>true,'duplicate'=>false,'row_id'=>(int)$db->lastInsertId()];
    }catch(Throwable $e){
        try{$st=$db->prepare("SELECT * FROM order_idempotency WHERE user_id=? AND source=? AND idempotency_key=? AND expires_at>NOW() LIMIT 1");$st->execute([$userId,$source,$key]);$row=$st->fetch(PDO::FETCH_ASSOC);if($row)return ['enabled'=>true,'duplicate'=>true,'order_id'=>$row['order_id'],'response_json'=>$row['response_json'],'conflict'=>!hash_equals($row['request_hash'],$hash)];}catch(Throwable $ignore){}
        return ['enabled'=>true,'duplicate'=>false,'row_id'=>null];
    }
}
function moni_order_idempotency_finish(PDO $db,?int $rowId,int $orderId,array $response=[]):void{if(!$rowId)return;try{$db->prepare("UPDATE order_idempotency SET order_id=?,response_json=? WHERE id=?")->execute([$orderId,$response?json_encode($response,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):null,$rowId]);}catch(Throwable $e){}}
function moni_order_idempotency_abort(PDO $db,?int $rowId):void{if(!$rowId)return;try{$db->prepare("DELETE FROM order_idempotency WHERE id=? AND order_id IS NULL")->execute([$rowId]);}catch(Throwable $e){}}

function moni_duplicate_order(PDO $db,int $userId,int $serviceId,string $link):?array{
    if(!moni_plugin_enabled('duplicate_order_warning',$db))return null;
    try{
        $st=$db->prepare("SELECT id,status,created_at FROM orders WHERE user_id=? AND service_id=? AND link=? AND status IN('pending','processing','in_progress') ORDER BY id DESC LIMIT 1");$st->execute([$userId,$serviceId,$link]);$r=$st->fetch(PDO::FETCH_ASSOC);
        if($r && moni_table_ready($db,'duplicate_order_events')){
            $db->prepare("INSERT INTO duplicate_order_events(user_id,service_id,link_hash,existing_order_id) VALUES(?,?,?,?)")->execute([$userId,$serviceId,hash('sha256',$link),$r['id']]);$r['event_id']=(int)$db->lastInsertId();
        }
        return $r?:null;
    }catch(Throwable $e){return null;}
}

/* ------------------------- Refund atomics ------------------------- */
function moni_refund_order(PDO $db,int $orderId,?float $requestedAmount,string $reason,string $targetStatus='refunded'):array{
    $own=!$db->inTransaction(); if($own)$db->beginTransaction();
    try{
        $st=$db->prepare("SELECT * FROM orders WHERE id=? FOR UPDATE");$st->execute([$orderId]);$o=$st->fetch(PDO::FETCH_ASSOC);if(!$o)throw new RuntimeException('Sipariş bulunamadı.');
        $price=(float)$o['price'];$already=(float)$o['refund_amount'];$target=$requestedAmount===null?$price:min($price,max(0,$requestedAmount));$amount=max(0,$target-$already);
        if($amount>0){
            $db->prepare("UPDATE users SET balance=balance+?,spent=GREATEST(0,spent-?) WHERE id=?")->execute([$amount,$amount,$o['user_id']]);
            $db->prepare("UPDATE orders SET refund_amount=refund_amount+?,status=?,admin_note=CONCAT(IFNULL(admin_note,''),?),updated_at=NOW() WHERE id=?")
               ->execute([$amount,$targetStatus,"\n[İade ".date('d.m.Y H:i')."] ".$reason,$orderId]);
            $bal=$db->prepare("SELECT balance FROM users WHERE id=?");$bal->execute([$o['user_id']]);$after=(float)$bal->fetchColumn();
            $db->prepare("INSERT INTO transactions(user_id,type,amount,balance_after,description,status,created_at) VALUES(?,'refund',?,?,?,'completed',NOW())")
               ->execute([$o['user_id'],$amount,$after,'Sipariş #'.$orderId.' iadesi: '.$reason]);
        }else{
            $db->prepare("UPDATE orders SET status=?,updated_at=NOW() WHERE id=?")->execute([$targetStatus,$orderId]);
        }
        if($own)$db->commit();
        moni_sync_base_wallet($db,(int)$o['user_id']);
        if($own && function_exists('moni_order_reason_record')){ $src='system';$rc=moni_order_reason_default_for_status($targetStatus,'system');$low=mb_strtolower($reason,'UTF-8');if($targetStatus==='cancelled'&&str_contains($low,'kullanıcı')){$src='user';$rc='cancelled_user';}elseif($targetStatus==='cancelled'&&str_contains($low,'admin')){$src='admin';$rc='cancelled_admin';}elseif($targetStatus==='cancelled'&&(str_contains($low,'hedef')||str_contains($low,'target'))){$src='system';$rc='invalid_target';} moni_order_reason_record($db,$orderId,$targetStatus,$rc,$src,(int)($o['api_provider_id']??0),$targetStatus,$reason,null); }
        return ['ok'=>true,'amount'=>$amount,'already_refunded'=>$amount<=0];
    }catch(Throwable $e){if($own&&$db->inTransaction())$db->rollBack();return ['ok'=>false,'error'=>$e->getMessage(),'amount'=>0];}
}

function moni_refund_dripfeed_remaining(PDO $db,int $dripfeedId,string $reason='Dripfeed kalan çalıştırma iadesi'):array{
    if(!moni_table_ready($db,'dripfeed_refunds'))return ['ok'=>false,'error'=>'Dripfeed iade altyapısı hazır değil.'];
    $own=!$db->inTransaction();if($own)$db->beginTransaction();
    try{
        $st=$db->prepare("SELECT * FROM orders_dripfeed WHERE id=? FOR UPDATE");$st->execute([$dripfeedId]);$df=$st->fetch(PDO::FETCH_ASSOC);if(!$df)throw new RuntimeException('Dripfeed siparişi bulunamadı.');
        $runs=max(1,(int)$df['runs']);$done=max(0,min($runs,(int)$df['completed_runs']));
        $target=round((float)$df['total_price']*(($runs-$done)/$runs),4);
        $ins=$db->prepare("INSERT IGNORE INTO dripfeed_refunds(dripfeed_id,amount) VALUES(?,?)");$ins->execute([$dripfeedId,$target]);
        $amount=$ins->rowCount()?$target:0.0;
        if($amount>0){
            $db->prepare("UPDATE users SET balance=balance+?,spent=GREATEST(0,spent-?) WHERE id=?")->execute([$amount,$amount,$df['user_id']]);
            $bal=$db->prepare("SELECT balance FROM users WHERE id=?");$bal->execute([$df['user_id']]);$after=(float)$bal->fetchColumn();
            $db->prepare("INSERT INTO transactions(user_id,type,amount,balance_after,description,status,created_at) VALUES(?,'refund',?,?,?,'completed',NOW())")
               ->execute([$df['user_id'],$amount,$after,'Dripfeed #'.$dripfeedId.' kalan iadesi: '.$reason]);
        }
        $db->prepare("UPDATE orders_dripfeed SET status='partial',next_run_at=NULL,last_error=?,updated_at=NOW() WHERE id=?")->execute([$reason,$dripfeedId]);
        if($own)$db->commit();moni_sync_base_wallet($db,(int)$df['user_id']);
        if($amount>0 && function_exists('moni_user_notify')){
            moni_user_notify($db,(int)$df['user_id'],'dripfeed_refund','Dripfeed iadesi tamamlandı','Dripfeed #'.$dripfeedId.' için kullanılmayan kalan tutar bakiyenize iade edildi.','/kullanici/orders.php','success');
        }
        return ['ok'=>true,'amount'=>$amount,'already_refunded'=>$amount<=0];
    }catch(Throwable $e){if($own&&$db->inTransaction())$db->rollBack();return ['ok'=>false,'error'=>$e->getMessage(),'amount'=>0];}
}

function moni_refund_scheduled_order(PDO $db,int $scheduledId,string $reason='Süreli sipariş iptali'):array{
    if(!moni_table_ready($db,'scheduled_order_refunds'))return ['ok'=>false,'error'=>'İade altyapısı hazır değil.'];
    $own=!$db->inTransaction();if($own)$db->beginTransaction();
    try{$st=$db->prepare("SELECT * FROM scheduled_orders WHERE id=? FOR UPDATE");$st->execute([$scheduledId]);$o=$st->fetch(PDO::FETCH_ASSOC);if(!$o)throw new RuntimeException('Süreli sipariş bulunamadı.');
        $ins=$db->prepare("INSERT IGNORE INTO scheduled_order_refunds(scheduled_order_id,amount) VALUES(?,?)");$ins->execute([$scheduledId,$o['price']]);
        $amount=$ins->rowCount()? (float)$o['price']:0;
        if($amount>0){$db->prepare("UPDATE users SET balance=balance+?,spent=GREATEST(0,spent-?) WHERE id=?")->execute([$amount,$amount,$o['user_id']]);$bal=$db->prepare("SELECT balance FROM users WHERE id=?");$bal->execute([$o['user_id']]);$after=$bal->fetchColumn();$db->prepare("INSERT INTO transactions(user_id,type,amount,balance_after,description,status) VALUES(?,'refund',?,?,?,'completed')")->execute([$o['user_id'],$amount,$after,'Süreli Sipariş #'.$scheduledId.' iadesi: '.$reason]);}
        $db->prepare("UPDATE scheduled_orders SET status='cancelled',updated_at=NOW() WHERE id=?")->execute([$scheduledId]);if($own)$db->commit();moni_sync_base_wallet($db,(int)$o['user_id']);return ['ok'=>true,'amount'=>$amount];
    }catch(Throwable $e){if($own&&$db->inTransaction())$db->rollBack();return ['ok'=>false,'error'=>$e->getMessage(),'amount'=>0];}
}

/* ------------------------- Wallets ------------------------- */
function moni_base_currency(PDO $db):string{try{$st=$db->query("SELECT setting_value FROM settings WHERE setting_key='currency' LIMIT 1");$v=$st->fetchColumn();return strtoupper($v?:'TRY');}catch(Throwable $e){return 'TRY';}}
function moni_ensure_base_currency(PDO $db):void{
    if(!moni_table_ready($db,'currencies'))return;
    try{$base=moni_base_currency($db);$symbol=(string)getSetting('currency_symbol',$base);$db->prepare("UPDATE currencies SET is_base=0 WHERE code<>?")->execute([$base]);$db->prepare("INSERT INTO currencies(code,name,symbol,rate_to_base,is_base,is_active) VALUES(?,?,?,?,1,1) ON DUPLICATE KEY UPDATE rate_to_base=1,is_base=1,is_active=1,symbol=IF(symbol='',VALUES(symbol),symbol)")->execute([$base,$base,$symbol,1]);}catch(Throwable $e){}
}
function moni_sync_base_wallet(PDO $db,int $userId):void{
    if(!moni_table_ready($db,'user_wallets'))return;try{$s=$db->prepare("SELECT balance FROM users WHERE id=?");$s->execute([$userId]);$b=$s->fetchColumn();if($b===false)return;$c=moni_base_currency($db);$db->prepare("INSERT INTO user_wallets(user_id,currency_code,balance) VALUES(?,?,?) ON DUPLICATE KEY UPDATE balance=VALUES(balance)")->execute([$userId,$c,$b]);}catch(Throwable $e){}
}
function moni_wallet_preferred_currency(PDO $db,int $userId):string{
    $base=moni_base_currency($db);if(!moni_table_ready($db,'user_currency_preferences'))return $base;
    try{$s=$db->prepare("SELECT default_currency FROM user_currency_preferences WHERE user_id=?");$s->execute([$userId]);$c=strtoupper((string)$s->fetchColumn());return $c?:$base;}catch(Throwable $e){return $base;}
}
function moni_wallet_prepare_base_balance(PDO $db,int $userId,float $required):array{
    $required=max(0,$required);$base=moni_base_currency($db);moni_sync_base_wallet($db,$userId);
    try{$s=$db->prepare("SELECT balance FROM users WHERE id=?");$s->execute([$userId]);$have=(float)$s->fetchColumn();}catch(Throwable $e){return ['ok'=>false,'error'=>'Bakiye kontrol edilemedi.'];}
    if($have+0.0000001 >= $required)return ['ok'=>true,'converted'=>0];
    $preferred=moni_wallet_preferred_currency($db,$userId);if($preferred===$base)return ['ok'=>false,'error'=>'Yetersiz bakiye.'];
    try{$r=$db->prepare("SELECT rate_to_base,is_active FROM currencies WHERE code=?");$r->execute([$preferred]);$rate=$r->fetch(PDO::FETCH_ASSOC);if(!$rate||!(int)$rate['is_active']||(float)$rate['rate_to_base']<=0)return ['ok'=>false,'error'=>'Varsayılan cüzdan para birimi aktif değil.'];
        $short=max(0,$required-$have);$need=$short/(float)$rate['rate_to_base'];$need=ceil($need*100000000)/100000000;
        $w=$db->prepare("SELECT balance FROM user_wallets WHERE user_id=? AND currency_code=?");$w->execute([$userId,$preferred]);if((float)$w->fetchColumn()+0.00000001<$need)return ['ok'=>false,'error'=>'Yetersiz bakiye.'];
        $conv=moni_wallet_convert($db,$userId,$preferred,$base,$need);if(empty($conv['ok']))return ['ok'=>false,'error'=>$conv['error']??'Döviz dönüşümü yapılamadı.'];return ['ok'=>true,'converted'=>$need,'from'=>$preferred,'to'=>$base];
    }catch(Throwable $e){return ['ok'=>false,'error'=>'Cüzdan dönüşümü yapılamadı.'];}
}

function moni_wallet_convert(PDO $db,int $userId,string $from,string $to,float $amount):array{
    $from=strtoupper($from);$to=strtoupper($to);if($amount<=0||$from===$to)return ['ok'=>false,'error'=>'Geçersiz dönüşüm.'];
    $own=!$db->inTransaction();if($own)$db->beginTransaction();
    try{
        moni_sync_base_wallet($db,$userId);
        $rates=[];$st=$db->prepare("SELECT code,rate_to_base,is_active FROM currencies WHERE code IN(?,?)");$st->execute([$from,$to]);foreach($st->fetchAll(PDO::FETCH_ASSOC)as$r)$rates[$r['code']]=$r;
        if(empty($rates[$from]['is_active'])||empty($rates[$to]['is_active']))throw new RuntimeException('Para birimi aktif değil.');
        $db->prepare("INSERT IGNORE INTO user_wallets(user_id,currency_code,balance) VALUES(?,?,0),(?,?,0)")->execute([$userId,$from,$userId,$to]);
        $s=$db->prepare("SELECT id,currency_code,balance FROM user_wallets WHERE user_id=? AND currency_code IN(?,?) FOR UPDATE");$s->execute([$userId,$from,$to]);$w=[];foreach($s->fetchAll(PDO::FETCH_ASSOC)as$r)$w[$r['currency_code']]=$r;
        if((float)($w[$from]['balance']??0)<$amount)throw new RuntimeException('Yetersiz bakiye.');
        $base=$amount*(float)$rates[$from]['rate_to_base'];$converted=$base/(float)$rates[$to]['rate_to_base'];
        $db->prepare("UPDATE user_wallets SET balance=balance-? WHERE user_id=? AND currency_code=?")->execute([$amount,$userId,$from]);
        $db->prepare("UPDATE user_wallets SET balance=balance+? WHERE user_id=? AND currency_code=?")->execute([$converted,$userId,$to]);
        $b1=$db->prepare("SELECT balance FROM user_wallets WHERE user_id=? AND currency_code=?");$b1->execute([$userId,$from]);$afterFrom=$b1->fetchColumn();$b1->execute([$userId,$to]);$afterTo=$b1->fetchColumn();
        $key='fx:'.$userId.':'.bin2hex(random_bytes(8));
        $db->prepare("INSERT INTO wallet_ledger(user_id,currency_code,entry_type,amount,balance_after,reference_type,idempotency_key,description) VALUES(?,?,?,?,?,'currency_exchange',?,?)")
           ->execute([$userId,$from,'exchange_out',-$amount,$afterFrom,$key.':out',$from.' → '.$to.' dönüşümü']);
        $db->prepare("INSERT INTO wallet_ledger(user_id,currency_code,entry_type,amount,balance_after,reference_type,idempotency_key,description) VALUES(?,?,?,?,?,'currency_exchange',?,?)")
           ->execute([$userId,$to,'exchange_in',$converted,$afterTo,$key.':in',$from.' → '.$to.' dönüşümü']);
        // Ana para birimlerinden biri değiştiyse legacy users.balance ile eşleştir.
        $baseCode=moni_base_currency($db);if($from===$baseCode)$db->prepare("UPDATE users SET balance=? WHERE id=?")->execute([$afterFrom,$userId]);elseif($to===$baseCode)$db->prepare("UPDATE users SET balance=? WHERE id=?")->execute([$afterTo,$userId]);
        if($own)$db->commit();return ['ok'=>true,'received'=>$converted,'from'=>$from,'to'=>$to];
    }catch(Throwable $e){if($own&&$db->inTransaction())$db->rollBack();return ['ok'=>false,'error'=>$e->getMessage()];}
}

/* ------------------------- Tax / e-document ------------------------- */
function moni_user_tax_profile(PDO $db,int $userId):array{
    $fallback=['customer_type'=>'individual','country_code'=>'TR','vat_rate'=>0.0,'prices_include_tax'=>1];
    if(!moni_table_ready($db,'user_tax_profiles')) return $fallback;
    try{
        $u=$db->prepare("SELECT * FROM user_tax_profiles WHERE user_id=?");$u->execute([$userId]);$profile=$u->fetch(PDO::FETCH_ASSOC)?:[];
        if(moni_plugin_enabled('tax_vat',$db)&&moni_table_ready($db,'tax_profiles')){
            $country=strtoupper((string)($profile['country_code']??'TR'));$type=(string)($profile['customer_type']??'individual');
            $t=$db->prepare("SELECT * FROM tax_profiles WHERE is_active=1 AND (country_code IS NULL OR country_code='' OR country_code=?) AND (customer_type='all' OR customer_type=?) ORDER BY (country_code=? ) DESC,(customer_type=? ) DESC,id DESC LIMIT 1");
            $t->execute([$country,$type,$country,$type]);$rule=$t->fetch(PDO::FETCH_ASSOC);
            if($rule){$profile['vat_rate']=(float)$rule['vat_rate'];$profile['prices_include_tax']=(int)$rule['prices_include_tax'];$profile['tax_profile_id']=(int)$rule['id'];}
        }
        return $profile+$fallback;
    }catch(Throwable $e){return $fallback;}
}
function moni_tax_breakdown(PDO $db,int $userId,float $grossAmount):array{
    $p=moni_user_tax_profile($db,$userId);$rate=max(0,(float)($p['vat_rate']??0));$inclusive=(int)($p['prices_include_tax']??1)===1;
    if(!moni_plugin_enabled('tax_vat',$db)||$rate<=0)return ['gross'=>$grossAmount,'net'=>$grossAmount,'tax'=>0.0,'rate'=>0.0,'profile'=>$p];
    if($inclusive){$net=$grossAmount/(1+$rate/100);$tax=$grossAmount-$net;$gross=$grossAmount;}else{$net=$grossAmount;$tax=$net*$rate/100;$gross=$net+$tax;}
    return ['gross'=>round($gross,4),'net'=>round($net,4),'tax'=>round($tax,4),'rate'=>$rate,'profile'=>$p];
}
function moni_queue_invoice(PDO $db,int $userId,?int $gatewayTxId,float $amount,string $currency='TRY'):bool{
    if(!moni_plugin_enabled('e_invoice',$db)||getSetting('invoice_auto_issue','0')!=='1'||!moni_table_ready($db,'e_invoice_documents'))return false;
    try{
        // $amount burada müşterinin gerçekten ödediği brüt tutardır. KDV aktifse brütten geriye doğru ayrıştırılır;
        // exclusive vergi profilinde ikinci kez vergi eklenmez.
        $p=moni_user_tax_profile($db,$userId);
        $rate=moni_plugin_enabled('tax_vat',$db)?max(0,(float)($p['vat_rate']??0)):0.0;
        if($rate>0){$net=$amount/(1+$rate/100);$taxAmount=$amount-$net;}else{$net=$amount;$taxAmount=0.0;}
        $type=(($p['customer_type']??'individual')==='company')?'e_invoice':'e_archive';
        $st=$db->prepare("INSERT IGNORE INTO e_invoice_documents(user_id,gateway_transaction_id,document_type,amount,tax_amount,currency_code,status,payload_json) VALUES(?,?,?,?,?,?,'pending',?)");
        $st->execute([$userId,$gatewayTxId,$type,round($amount,4),round($taxAmount,4),strtoupper($currency),json_encode(['net'=>round($net,4),'vat_rate'=>$rate,'tax_profile_id'=>$p['tax_profile_id']??null],JSON_UNESCAPED_UNICODE)]);
        return $st->rowCount()>0;
    }catch(Throwable $e){error_log('Invoice queue: '.$e->getMessage());return false;}
}

/* ------------------------- Payment fraud ------------------------- */
function moni_payment_fraud_check(PDO $db,int $userId,float $amount,string $event='payment_attempt'):array{
    if(!moni_plugin_enabled('payment_fraud',$db)||!moni_table_ready($db,'payment_fraud_events'))return ['allow'=>true,'risk'=>0];
    $maxHour=(int)(getSetting('fraud_max_payments_hour','5'));
    $maxDay=(float)getSetting('fraud_max_amount_day','50000');
    $block=(int)getSetting('fraud_block_score','80');
    $risk=0;$reasons=[];$lockName='moni_fraud_'.substr(hash('sha256',(string)$userId),0,36);$locked=false;
    try{
        $lk=$db->prepare("SELECT GET_LOCK(?,3)");$lk->execute([$lockName]);$locked=(int)$lk->fetchColumn()===1;
        if(!$locked)return ['allow'=>false,'decision'=>'block','risk'=>100,'reasons'=>['Ödeme güvenlik kontrolü kilidi alınamadı; tekrar deneyin.']];

        $s=$db->prepare("SELECT COUNT(*) FROM payment_fraud_events WHERE user_id=? AND event_type='payment_attempt' AND created_at>DATE_SUB(NOW(),INTERVAL 1 HOUR)");
        $s->execute([$userId]);$cnt=(int)$s->fetchColumn();if($cnt>=$maxHour){$risk+=50;$reasons[]='Saatlik ödeme deneme limiti';}
        $s=$db->prepare("SELECT COALESCE(SUM(amount),0) FROM payment_fraud_events WHERE user_id=? AND event_type='payment_attempt' AND created_at>DATE_SUB(NOW(),INTERVAL 1 DAY)");
        $s->execute([$userId]);$sum=(float)$s->fetchColumn();if($sum+$amount>$maxDay){$risk+=50;$reasons[]='Günlük tutar limiti';}
        $device=moni_device_id();$ip=moni_client_ip();
        $s=$db->prepare("SELECT COUNT(DISTINCT user_id) FROM payment_fraud_events WHERE ip_address=? AND created_at>DATE_SUB(NOW(),INTERVAL 1 DAY)");
        $s->execute([$ip]);if((int)$s->fetchColumn()>=4){$risk+=20;$reasons[]='Aynı IP üzerinde çoklu hesap';}
        $decision=$risk>=$block?'block':($risk>=50?'review':'allow');
        $db->prepare("INSERT INTO payment_fraud_events(user_id,event_type,risk_score,decision,amount,ip_address,device_id,details_json) VALUES(?,?,?,?,?,?,?,?)")
           ->execute([$userId,$event,$risk,$decision,$amount,$ip,$device,json_encode(['reasons'=>$reasons],JSON_UNESCAPED_UNICODE)]);
        return ['allow'=>$decision!=='block','decision'=>$decision,'risk'=>$risk,'reasons'=>$reasons];
    }catch(Throwable $e){
        error_log('Payment fraud check: '.$e->getMessage());
        return ['allow'=>false,'decision'=>'block','risk'=>100,'reasons'=>['Ödeme güvenlik kontrolü tamamlanamadı.']];
    }finally{
        if($locked){try{$rl=$db->prepare("SELECT RELEASE_LOCK(?)");$rl->execute([$lockName]);}catch(Throwable $ignore){}}
    }
}

/* ------------------------- Financial closing ------------------------- */
function moni_prepare_financial_closing(PDO $db,string $date):array{
    if(!moni_table_ready($db,'financial_closings'))return ['ok'=>false,'error'=>'Finans kapanış tablosu yok.'];
    try{
        $d=(new DateTimeImmutable($date))->format('Y-m-d');$end=$d.' 23:59:59';
        if($d>=date('Y-m-d'))return ['ok'=>false,'error'=>'Yalnız tamamlanmış günler için finansal kapanış hazırlanabilir.'];
        $existing=$db->prepare("SELECT status,variance FROM financial_closings WHERE closing_date=? LIMIT 1");$existing->execute([$d]);$ex=$existing->fetch(PDO::FETCH_ASSOC);
        if($ex && $ex['status']==='closed') return ['ok'=>true,'locked'=>true,'date'=>$d,'variance'=>(float)$ex['variance']];
        $sum=function($sql,$params=[])use($db){$s=$db->prepare($sql);$s->execute($params);return (float)$s->fetchColumn();};
        $base=moni_base_currency($db);
        if(moni_table_ready($db,'user_wallets')){
            $db->prepare("INSERT INTO user_wallets(user_id,currency_code,balance) SELECT u.id,?,u.balance FROM users u WHERE 1=1 ON DUPLICATE KEY UPDATE balance=VALUES(balance)")->execute([$base]);
        }
        $deposit=$sum("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type IN('deposit','admin_add') AND status='completed' AND DATE(created_at)=?",[$d]);
        $refund=$sum("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='refund' AND status='completed' AND DATE(created_at)=?",[$d]);
        $bonus=$sum("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type IN('bonus','coupon') AND status='completed' AND DATE(created_at)=?",[$d]);
        $referral=$sum("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='referral_bonus' AND status='completed' AND DATE(created_at)=?",[$d]);
        $orders=abs($sum("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='order' AND status='completed' AND DATE(created_at)=?",[$d]));
        $net=$sum("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE status='completed' AND DATE(created_at)=?",[$d]);

        // Gün sonu cüzdan değerini bugünkü bakiyeden geriye yürüt. Böylece kapanış daha sonra hazırlanırsa
        // ertesi günün yükleme/siparişleri dünkü kapanış toplamını bozmaz.
        if(moni_table_ready($db,'user_wallets')&&moni_table_ready($db,'currencies')){
            $st=$db->query("SELECT currency_code,COALESCE(SUM(balance),0) balance FROM user_wallets GROUP BY currency_code");$balances=[];
            foreach($st->fetchAll(PDO::FETCH_ASSOC) as $r)$balances[strtoupper($r['currency_code'])]=(float)$r['balance'];
            if(moni_table_ready($db,'wallet_ledger')){
                $q=$db->prepare("SELECT currency_code,COALESCE(SUM(amount),0) amount FROM wallet_ledger WHERE created_at>? GROUP BY currency_code");$q->execute([$end]);
                foreach($q->fetchAll(PDO::FETCH_ASSOC) as $r){$c=strtoupper($r['currency_code']);$balances[$c]=($balances[$c]??0)-(float)$r['amount'];}
            }
            // Legacy/base hareketleri wallet_ledger'a yazılmadığından transaction defterini ayrıca geri al.
            $postBase=$sum("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE status='completed' AND created_at>?",[$end]);
            $balances[$base]=($balances[$base]??0)-$postBase;
            $closing=0.0;
            foreach($balances as $code=>$bal){
                $rate=false;
                if(moni_table_ready($db,'currency_rate_history')){$rq=$db->prepare("SELECT rate_to_base FROM currency_rate_history WHERE currency_code=? AND effective_at<=? ORDER BY effective_at DESC,id DESC LIMIT 1");$rq->execute([$code,$end]);$rate=$rq->fetchColumn();}
                if($rate===false){$rq=$db->prepare("SELECT rate_to_base FROM currencies WHERE code=?");$rq->execute([$code]);$rate=$rq->fetchColumn();}
                if($rate!==false)$closing+=(float)$bal*(float)$rate;
            }
        }else{
            $current=$sum("SELECT COALESCE(SUM(balance),0) FROM users");$post=$sum("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE status='completed' AND created_at>?",[$end]);$closing=$current-$post;
        }
        $ps=$db->prepare("SELECT closing_wallet_total FROM financial_closings WHERE closing_date<? AND status='closed' ORDER BY closing_date DESC LIMIT 1");$ps->execute([$d]);$prior=$ps->fetchColumn();
        $opening=$prior!==false?(float)$prior:$closing-$net;$expected=$opening+$net;$variance=$closing-$expected;
        $db->prepare("INSERT INTO financial_closings(closing_date,status,opening_wallet_total,deposit_total,order_total,refund_total,bonus_total,referral_total,closing_wallet_total,expected_wallet_total,variance,prepared_at) VALUES(?,'draft',?,?,?,?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE opening_wallet_total=IF(status='closed',opening_wallet_total,VALUES(opening_wallet_total)),deposit_total=IF(status='closed',deposit_total,VALUES(deposit_total)),order_total=IF(status='closed',order_total,VALUES(order_total)),refund_total=IF(status='closed',refund_total,VALUES(refund_total)),bonus_total=IF(status='closed',bonus_total,VALUES(bonus_total)),referral_total=IF(status='closed',referral_total,VALUES(referral_total)),closing_wallet_total=IF(status='closed',closing_wallet_total,VALUES(closing_wallet_total)),expected_wallet_total=IF(status='closed',expected_wallet_total,VALUES(expected_wallet_total)),variance=IF(status='closed',variance,VALUES(variance)),prepared_at=IF(status='closed',prepared_at,NOW())")
           ->execute([$d,$opening,$deposit,$orders,$refund,$bonus,$referral,$closing,$expected,$variance]);
        return ['ok'=>true,'locked'=>false,'date'=>$d,'variance'=>$variance];
    }catch(Throwable $e){return ['ok'=>false,'error'=>$e->getMessage()];}
}


function moni_sync_gateway_registry_state(PDO $db):void{
    if(!moni_table_ready($db,'payment_gateway_adapters')||!moni_table_ready($db,'payment_methods'))return;
    // Legacy ödeme yöntemlerini yalnız ilk geçişte adaptör durumuna taşı. Sonraki admin adaptör ayarlarını ezme.
    try{
        if(getSetting('moni_gateway_registry_synced_v1','0')==='1')return;
        $map=['bank_transfer'=>'bank','iyzico'=>'iyzico'];
        foreach($map as $slug=>$type){
            $st=$db->prepare("SELECT status FROM payment_methods WHERE type=? ORDER BY id LIMIT 1");$st->execute([$type]);$status=$st->fetchColumn();
            if($status!==false)$db->prepare("UPDATE payment_gateway_adapters SET is_enabled=? WHERE slug=?")->execute([$status==='active'?1:0,$slug]);
        }
        updateSetting('moni_gateway_registry_synced_v1','1');
    }catch(Throwable $e){}
}

/* ------------------------- Bootstrap ------------------------- */
function moni_bootstrap(PDO $db): void {
    static $done=false;if($done)return;$done=true;
    if(PHP_SAPI!=='cli'&&moni_base_url_is_https()&&!moni_request_is_https()){
        $host=(string)parse_url(defined('SITE_URL')?SITE_URL:'',PHP_URL_HOST);if($host&&preg_match('/^[a-z0-9.-]+$/i',$host)&&!headers_sent()){header('Location: https://'.$host.($_SERVER['REQUEST_URI']??'/'),true,302);exit;}
    }
    moni_migrate_secrets_once($db);
    moni_ensure_base_currency($db);
    moni_attempt_remember_login($db);
    if(!empty($_SESSION['user_id'])){
        moni_track_session($db,(int)$_SESSION['user_id']);
        moni_sync_base_wallet($db,(int)$_SESSION['user_id']);
    }
    moni_load_plugins($db);
    if(file_exists(__DIR__.'/MoniProviders.php'))require_once __DIR__.'/MoniProviders.php';
    if(file_exists(__DIR__.'/MoniOrders.php'))require_once __DIR__.'/MoniOrders.php';
    if(file_exists(__DIR__.'/MoniGateways.php')){require_once __DIR__.'/MoniGateways.php';moni_sync_gateway_registry_state($db);}
    if(file_exists(__DIR__.'/MoniWebAuthn.php'))require_once __DIR__.'/MoniWebAuthn.php';
    if(file_exists(__DIR__.'/MoniAdvanced.php'))require_once __DIR__.'/MoniAdvanced.php';
    if(file_exists(__DIR__.'/MoniV2Features.php'))require_once __DIR__.'/MoniV2Features.php';
    if(file_exists(__DIR__.'/MoniV2Ops.php'))require_once __DIR__.'/MoniV2Ops.php';
    if(file_exists(__DIR__.'/MoniCommercePro.php'))require_once __DIR__.'/MoniCommercePro.php';
    if(file_exists(__DIR__.'/MoniOpsPro.php'))require_once __DIR__.'/MoniOpsPro.php';
    if(file_exists(__DIR__.'/MoniSecurityPlus.php')){require_once __DIR__.'/MoniSecurityPlus.php';moni_migrate_customer_api_keys($db);}
    if(file_exists(__DIR__.'/MoniEnterprise.php')){require_once __DIR__.'/MoniEnterprise.php';moni_enterprise_boot($db);}
    if(function_exists('moni_cron_watchdog_request_tick'))moni_cron_watchdog_request_tick($db);
}
