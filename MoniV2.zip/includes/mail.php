<?php
/**
 * E-Posta Gönderme Fonksiyonları
 */

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// PHPMailer dosyalarını dahil et
require_once __DIR__ . '/PHPMailer.php';
require_once __DIR__ . '/SMTP.php';
require_once __DIR__ . '/Exception.php';

/**
 * E-posta gönder
 */
if (!function_exists('sendEmail')) {
    function sendEmail($to, $subject, $body, $altBody = '', $attachments = []) {
        global $db, $siteSettings;
        
        // SMTP ayarlarını al
        $smtpSettings = [];
        $stmt = $db->query("SELECT setting_key, setting_value FROM settings WHERE setting_key LIKE 'smtp_%'");
        while ($row = $stmt->fetch()) {
            $smtpSettings[$row['setting_key']] = $row['setting_value'];
        }
        
        // SMTP aktif değilse
        if (empty($smtpSettings['smtp_enabled']) || $smtpSettings['smtp_enabled'] !== '1') {
            if (function_exists('moni_email_event')) moni_email_event($db,'failed',(string)$to,'','smtp','SMTP devre dışı.');
            return ['success' => false, 'message' => 'SMTP devre dışı. Lütfen admin panelinden SMTP ayarlarını yapılandırın.'];
        }
        
        // Gerekli alanları kontrol et
        if (empty($smtpSettings['smtp_host']) || empty($smtpSettings['smtp_username']) || empty($smtpSettings['smtp_password'])) {
            if (function_exists('moni_email_event')) moni_email_event($db,'failed',(string)$to,'','smtp','SMTP ayarları eksik.');
            return ['success' => false, 'message' => 'SMTP ayarları eksik. Lütfen tüm alanları doldurun.'];
        }
        
        $mail = new PHPMailer(true);
        
        try {
            // Sunucu ayarları
            $mail->isSMTP();
            $mail->Host = $smtpSettings['smtp_host'];
            $mail->SMTPAuth = true;
            $mail->Username = $smtpSettings['smtp_username'];
            $mail->Password = moni_decrypt_secret($smtpSettings['smtp_password']);
            
            // Şifreleme türü
            $encryption = $smtpSettings['smtp_encryption'] ?? 'tls';
            if ($encryption === 'ssl') {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            } elseif ($encryption === 'tls') {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            } else {
                $mail->SMTPSecure = false;
                $mail->SMTPAutoTLS = false;
            }
            
            $mail->Port = (int)($smtpSettings['smtp_port'] ?? 587);
            
            // Karakter seti
            $mail->CharSet = 'UTF-8';
            $mail->Encoding = 'base64';
            
            // Gönderen
            $fromEmail = $smtpSettings['smtp_from_email'] ?: $smtpSettings['smtp_username'];
            $fromName = $smtpSettings['smtp_from_name'] ?: ($siteSettings['name'] ?? 'Site');
            $mail->setFrom($fromEmail, $fromName);

            // Opsiyonel DKIM imzalama. Private key ayarlarda şifreli saklanır.
            if ((string)getSetting('email_dkim_enabled','0') === '1') {
                $dkimDomain = trim((string)getSetting('email_dkim_domain',''));
                if ($dkimDomain === '' && str_contains($fromEmail,'@')) $dkimDomain = substr(strrchr($fromEmail,'@'),1);
                $dkimSelector = trim((string)getSetting('email_dkim_selector','default'));
                $dkimPrivate = moni_decrypt_secret((string)getSetting('email_dkim_private_key',''));
                if ($dkimDomain !== '' && $dkimSelector !== '' && $dkimPrivate !== '') {
                    $mail->DKIM_domain = $dkimDomain;
                    $mail->DKIM_selector = $dkimSelector;
                    $mail->DKIM_private_string = $dkimPrivate;
                    $mail->DKIM_identity = $fromEmail;
                    $mail->DKIM_copyHeaderFields = false;
                }
            }
            
            // Alıcı
            if (is_array($to)) {
                foreach ($to as $recipient) {
                    $mail->addAddress($recipient);
                }
            } else {
                $mail->addAddress($to);
            }
            
            // Ekler
            if (!empty($attachments)) {
                foreach ($attachments as $attachment) {
                    if (is_array($attachment)) {
                        $mail->addAttachment($attachment['path'], $attachment['name'] ?? '');
                    } else {
                        $mail->addAttachment($attachment);
                    }
                }
            }
            
            // İçerik
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $body;
            $mail->AltBody = $altBody ?: strip_tags($body);
            
            $mail->send();
            $recipientForLog = is_array($to) ? (string)($to[0] ?? '') : (string)$to;
            if (function_exists('moni_email_event')) moni_email_event($db,'sent',$recipientForLog,(string)$mail->getLastMessageID(),'smtp','SMTP sunucusu iletiyi kabul etti.');
            return ['success' => true, 'message' => 'E-posta başarıyla gönderildi.', 'message_id' => (string)$mail->getLastMessageID()];
            
        } catch (Exception $e) {
            $recipientForLog = is_array($to) ? (string)($to[0] ?? '') : (string)$to;
            if (function_exists('moni_email_event')) moni_email_event($db,'failed',$recipientForLog,'','smtp',(string)$mail->ErrorInfo);
            return ['success' => false, 'message' => 'E-posta gönderilemedi: ' . $mail->ErrorInfo];
        }
    }
}

/**
 * Şablonlu e-posta gönder
 */
if (!function_exists('sendTemplateEmail')) {
    function sendTemplateEmail($to, $template, $variables = []) {
        global $siteSettings, $db;
        $prefType = ['order_confirmation'=>'orders','balance_added'=>'payments'][$template] ?? null;
        if ($prefType && $db instanceof PDO && function_exists('moni_notification_allowed')) {
            try { $q=$db->prepare("SELECT id FROM users WHERE email=? LIMIT 1"); $q->execute([(string)$to]); $uid=(int)$q->fetchColumn(); if($uid && !moni_notification_allowed($db,$uid,$prefType,'email')) return ['success'=>true,'message'=>'Bildirim tercihi nedeniyle e-posta gönderilmedi.']; } catch(Throwable $ignore) {}
        }
        
        // Varsayılan değişkenler
        $canonicalSiteUrl=rtrim((string)(defined('SITE_URL')&&SITE_URL!==''?SITE_URL:getSetting('site_url','')),'/');
        if($canonicalSiteUrl!==''&&!filter_var($canonicalSiteUrl,FILTER_VALIDATE_URL))$canonicalSiteUrl='';
        $variables = array_merge([
            'site_name' => $siteSettings['name'] ?? 'Site',
            // E-posta bağlantıları asla Host header'dan üretilmez; Host-header poisoning önlenir.
            'site_url' => $canonicalSiteUrl,
            'year' => date('Y')
        ], $variables);
        // Child Panel şablonu varsa önce onu kullan; yoksa mevcut global/built-in şablona düş.
        if ($db instanceof PDO && function_exists('moni_child_panel_context') && function_exists('moni_child_email_template')) {
            $cp=moni_child_panel_context($db);$cpId=(int)($cp['id']??0);$ct=$cpId?moni_child_email_template($db,$cpId,(string)$template):null;
            if($ct){$subject=(string)$ct['subject'];$body=(string)$ct['body_html'];foreach($variables as $key=>$value){$subject=str_replace('{'.$key.'}',(string)$value,$subject);$body=str_replace('{'.$key.'}',(string)$value,$body);$subject=str_replace('{{'.$key.'}}',(string)$value,$subject);$body=str_replace('{{'.$key.'}}',(string)$value,$body);}return sendEmail($to,$subject,$body);}
        }
        
        // Şablonlar
        $templates = [
            'welcome' => [
                'subject' => '{site_name} - Hoş Geldiniz!',
                'body' => '
                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
                        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
                            <h1 style="color: #fff; margin: 0;">{site_name}</h1>
                        </div>
                        <div style="background: #fff; padding: 30px; border: 1px solid #e0e0e0; border-top: none;">
                            <h2 style="color: #333;">Hoş Geldiniz, {username}!</h2>
                            <p style="color: #666; line-height: 1.6;">
                                {site_name} ailesine katıldığınız için teşekkür ederiz. Hesabınız başarıyla oluşturuldu.
                            </p>
                            <p style="color: #666; line-height: 1.6;">
                                Hizmetlerimizi kullanmaya başlamak için hemen giriş yapabilirsiniz.
                            </p>
                            <div style="text-align: center; margin: 30px 0;">
                                <a href="{site_url}/login.php" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">Giriş Yap</a>
                            </div>
                        </div>
                        <div style="text-align: center; padding: 20px; color: #999; font-size: 12px;">
                            <p>&copy; {year} {site_name}. Tüm hakları saklıdır.</p>
                        </div>
                    </div>
                '
            ],
            'password_reset' => [
                'subject' => '{site_name} - Şifre Sıfırlama',
                'body' => '
                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
                        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
                            <h1 style="color: #fff; margin: 0;">{site_name}</h1>
                        </div>
                        <div style="background: #fff; padding: 30px; border: 1px solid #e0e0e0; border-top: none;">
                            <h2 style="color: #333;">Şifre Sıfırlama Talebi</h2>
                            <p style="color: #666; line-height: 1.6;">
                                Merhaba {username},
                            </p>
                            <p style="color: #666; line-height: 1.6;">
                                Hesabınız için şifre sıfırlama talebinde bulundunuz. Şifrenizi sıfırlamak için aşağıdaki butona tıklayın.
                            </p>
                            <div style="text-align: center; margin: 30px 0;">
                                <a href="{reset_link}" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">Şifremi Sıfırla</a>
                            </div>
                            <p style="color: #999; font-size: 12px;">
                                Bu talebi siz yapmadıysanız bu e-postayı görmezden gelebilirsiniz.
                            </p>
                        </div>
                        <div style="text-align: center; padding: 20px; color: #999; font-size: 12px;">
                            <p>&copy; {year} {site_name}. Tüm hakları saklıdır.</p>
                        </div>
                    </div>
                '
            ],
            'order_confirmation' => [
                'subject' => '{site_name} - Sipariş Onayı #{order_id}',
                'body' => '
                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
                        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
                            <h1 style="color: #fff; margin: 0;">{site_name}</h1>
                        </div>
                        <div style="background: #fff; padding: 30px; border: 1px solid #e0e0e0; border-top: none;">
                            <h2 style="color: #333;">Sipariş Onayı</h2>
                            <p style="color: #666; line-height: 1.6;">
                                Merhaba {username}, siparişiniz başarıyla alındı.
                            </p>
                            <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                                <p style="margin: 5px 0;"><strong>Sipariş No:</strong> #{order_id}</p>
                                <p style="margin: 5px 0;"><strong>Servis:</strong> {service_name}</p>
                                <p style="margin: 5px 0;"><strong>Miktar:</strong> {quantity}</p>
                                <p style="margin: 5px 0;"><strong>Tutar:</strong> {price}</p>
                            </div>
                            <div style="text-align: center; margin: 30px 0;">
                                <a href="{site_url}/kullanici/orders.php" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">Siparişlerimi Görüntüle</a>
                            </div>
                        </div>
                        <div style="text-align: center; padding: 20px; color: #999; font-size: 12px;">
                            <p>&copy; {year} {site_name}. Tüm hakları saklıdır.</p>
                        </div>
                    </div>
                '
            ],
            'balance_added' => [
                'subject' => '{site_name} - Bakiye Yüklendi',
                'body' => '
                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
                        <div style="background: linear-gradient(135deg, #28a745 0%, #20c997 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
                            <h1 style="color: #fff; margin: 0;">{site_name}</h1>
                        </div>
                        <div style="background: #fff; padding: 30px; border: 1px solid #e0e0e0; border-top: none;">
                            <h2 style="color: #333;">Bakiye Yüklendi!</h2>
                            <p style="color: #666; line-height: 1.6;">
                                Merhaba {username}, hesabınıza bakiye yüklendi.
                            </p>
                            <div style="background: #d4edda; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center;">
                                <p style="margin: 0; font-size: 24px; color: #28a745; font-weight: bold;">+{amount}</p>
                                <p style="margin: 5px 0 0; color: #666;">Yeni Bakiyeniz: {new_balance}</p>
                            </div>
                            <div style="text-align: center; margin: 30px 0;">
                                <a href="{site_url}/kullanici/" style="background: linear-gradient(135deg, #28a745 0%, #20c997 100%); color: #fff; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">Panele Git</a>
                            </div>
                        </div>
                        <div style="text-align: center; padding: 20px; color: #999; font-size: 12px;">
                            <p>&copy; {year} {site_name}. Tüm hakları saklıdır.</p>
                        </div>
                    </div>
                '
            ],
            // Yeni: E-posta doğrulama şablonu
            'email_verification' => [
                'subject' => '{site_name} - E-posta Doğrulama',
                'body' => '
                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
                        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
                            <h1 style="color: #fff; margin: 0;">{site_name}</h1>
                        </div>
                        <div style="background: #fff; padding: 30px; border: 1px solid #e0e0e0; border-top: none;">
                            <h2 style="color: #333;">E-posta Doğrulama</h2>
                            <p style="color: #666; line-height: 1.6;">Merhaba {username},</p>
                            <p style="color: #666; line-height: 1.6;">Hesabınızı doğrulamak için aşağıdaki butona tıklayın.</p>
                            <div style="text-align: center; margin: 30px 0;">
                                <a href="{verify_link}" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">E-postamı Doğrula</a>
                            </div>
                            <p style="color: #999; font-size: 12px;">Buton çalışmazsa şu adresi tarayıcınıza yapıştırın:<br>{verify_link}</p>
                        </div>
                        <div style="text-align: center; padding: 20px; color: #999; font-size: 12px;">
                            <p>&copy; {year} {site_name}. Tüm hakları saklıdır.</p>
                        </div>
                    </div>
                '
            ]
        ];
        
        if (!isset($templates[$template])) {
            return ['success' => false, 'message' => 'Şablon bulunamadı: ' . $template];
        }
        
        $tpl = $templates[$template];
        $subject = $tpl['subject'];
        $body = $tpl['body'];
        
        // Değişkenleri değiştir
        foreach ($variables as $key => $value) {
            $subject = str_replace('{' . $key . '}', $value, $subject);
            $body = str_replace('{' . $key . '}', $value, $body);
        }
        
        return sendEmail($to, $subject, $body);
    }
}