<?php
if (defined('MONI_SECURITY_PLUS_LOADED')) return;
define('MONI_SECURITY_PLUS_LOADED', true);

function moni_safe_site_host(): string {
    $host = '';
    if (defined('SITE_URL')) $host = (string)parse_url(SITE_URL, PHP_URL_HOST);
    if (!$host) $host = (string)($_SERVER['SERVER_NAME'] ?? '');
    return preg_match('/^[a-z0-9.-]+$/i', $host) ? $host : '';
}

function moni_hash_secret_token(string $token): string { return 'sha256:' . hash('sha256', $token); }
function moni_secret_token_matches(string $stored, string $plain): bool {
    if (str_starts_with($stored, 'sha256:')) return hash_equals(substr($stored, 7), hash('sha256', $plain));
    return hash_equals($stored, $plain);
}

function moni_api_client_auth(PDO $db, string $apiKey): ?array {
    $apiKey = trim($apiKey); if ($apiKey === '') return null;
    $hashed = moni_hash_secret_token($apiKey);
    try {
        $st = $db->prepare("SELECT * FROM api_clients WHERE api_key IN (?,?) AND status='active' LIMIT 1");
        $st->execute([$hashed, $apiKey]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            if (!str_starts_with((string)$row['api_key'], 'sha256:')) {
                $db->prepare("UPDATE api_clients SET api_key=? WHERE id=? AND api_key=?")->execute([$hashed, $row['id'], $row['api_key']]);
                $row['api_key'] = $hashed;
            }
            return $row;
        }
        // Eski users.api_key entegrasyonlarını kesmeden güvenli api_clients kaydına taşı.
        if (moni_table_ready($db, 'users')) {
            $u = $db->prepare("SELECT id,username,api_key FROM users WHERE api_key=? AND status='active' LIMIT 1");
            $u->execute([$apiKey]); $user = $u->fetch(PDO::FETCH_ASSOC);
            if ($user) {
                $db->beginTransaction();
                try {
                    $exists = $db->prepare("SELECT id FROM api_clients WHERE user_id=? LIMIT 1"); $exists->execute([$user['id']]);
                    $cid = (int)$exists->fetchColumn();
                    if ($cid) $db->prepare("UPDATE api_clients SET api_key=?,status='active' WHERE id=?")->execute([$hashed,$cid]);
                    else {
                        $apiDefaultRate=max(1,min(100000,(int)getSetting('api_default_rate_limit_per_min','300')));
                        $db->prepare("INSERT INTO api_clients(user_id,name,api_key,status,rate_limit_per_min,created_at) VALUES(?,?,?,'active',?,NOW())")
                           ->execute([$user['id'], 'Varsayılan API', $hashed,$apiDefaultRate]);
                        $cid = (int)$db->lastInsertId();
                    }
                    $db->prepare("UPDATE users SET api_key=NULL WHERE id=?")->execute([$user['id']]);
                    $db->commit();
                    $s=$db->prepare("SELECT * FROM api_clients WHERE id=?");$s->execute([$cid]);return $s->fetch(PDO::FETCH_ASSOC) ?: null;
                } catch (Throwable $e) { if ($db->inTransaction()) $db->rollBack(); }
            }
        }
    } catch (Throwable $e) {}
    return null;
}


function moni_migrate_customer_api_keys(PDO $db): void {
    static $done=false;if($done)return;$done=true;
    try{
        if(moni_table_ready($db,'api_clients')){
            $rows=$db->query("SELECT id,api_key FROM api_clients WHERE api_key<>'' AND api_key NOT LIKE 'sha256:%'")->fetchAll(PDO::FETCH_ASSOC);
            $up=$db->prepare("UPDATE api_clients SET api_key=? WHERE id=? AND api_key=?");
            foreach($rows as $r){$plain=(string)$r['api_key'];$up->execute([moni_hash_secret_token($plain),$r['id'],$plain]);}
        }
        if(moni_table_ready($db,'users')){
            $rows=$db->query("SELECT id,username,api_key FROM users WHERE api_key IS NOT NULL AND api_key<>''")->fetchAll(PDO::FETCH_ASSOC);
            foreach($rows as $u){$plain=(string)$u['api_key'];$hash=moni_hash_secret_token($plain);$c=$db->prepare("SELECT id FROM api_clients WHERE user_id=? LIMIT 1");$c->execute([$u['id']]);$cid=(int)$c->fetchColumn();if($cid){$db->prepare("UPDATE api_clients SET api_key=?,status='active' WHERE id=?")->execute([$hash,$cid]);}else{$apiDefaultRate=max(1,min(100000,(int)getSetting('api_default_rate_limit_per_min','300')));$db->prepare("INSERT INTO api_clients(user_id,name,api_key,status,rate_limit_per_min,created_at) VALUES(?,?,?,'active',?,NOW())")->execute([$u['id'],$u['username'].' API',$hash,$apiDefaultRate]);}$db->prepare("UPDATE users SET api_key=NULL WHERE id=?")->execute([$u['id']]);}
        }
    }catch(Throwable $e){error_log('API key migration failed: '.$e->getMessage());}
}

function moni_revoke_user_sessions(PDO $db, int $userId): void {
    try { if (moni_table_ready($db,'remember_tokens')) $db->prepare("DELETE FROM remember_tokens WHERE user_id=?")->execute([$userId]); } catch(Throwable $e){}
    try { if (moni_table_ready($db,'user_sessions')) $db->prepare("UPDATE user_sessions SET revoked_at=COALESCE(revoked_at,NOW()) WHERE user_id=?")->execute([$userId]); } catch(Throwable $e){ error_log('Session revoke failed: '.$e->getMessage()); }
}

function moni_password_ok_for_user(PDO $db, int $userId, string $password): bool {
    if ($password === '') return false;
    try { $s=$db->prepare("SELECT password FROM users WHERE id=? LIMIT 1");$s->execute([$userId]);$h=(string)$s->fetchColumn();return $h!==''&&password_verify($password,$h); } catch(Throwable $e){ return false; }
}

function moni_email_2fa_send(PDO $db, array $user): bool {
    if (empty($user['id']) || empty($user['email']) || !moni_table_ready($db,'email_two_factor_codes')) return false;
    $code=(string)random_int(100000,999999);$hash=hash('sha256',$code);
    try {
        $db->prepare("UPDATE email_two_factor_codes SET used=1 WHERE user_id=? AND used=0")->execute([$user['id']]);
        $db->prepare("INSERT INTO email_two_factor_codes(user_id,code_hash,expires_at,used,ip_address,created_at) VALUES(?,?,DATE_ADD(NOW(),INTERVAL 10 MINUTE),0,?,NOW())")
           ->execute([$user['id'],$hash,moni_client_ip()]);
        $site=(string)getSetting('site_name', getSetting('name','SMM Panel'));
        $body='<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:24px"><h2>'.htmlspecialchars($site).' giriş doğrulaması</h2><p>Giriş doğrulama kodunuz:</p><div style="font-size:32px;font-weight:800;letter-spacing:8px">'.$code.'</div><p>Bu kod 10 dakika geçerlidir. Bu işlemi siz yapmadıysanız kodu paylaşmayın.</p></div>';
        return (bool)sendEmail((string)$user['email'], $site.' - Giriş doğrulama kodu', $body);
    } catch(Throwable $e){ return false; }
}
function moni_email_2fa_verify(PDO $db,int $userId,string $code): bool {
    if(!preg_match('/^\d{6}$/',$code)||!moni_table_ready($db,'email_two_factor_codes'))return false;
    try{$db->beginTransaction();$s=$db->prepare("SELECT id,code_hash FROM email_two_factor_codes WHERE user_id=? AND used=0 AND expires_at>NOW() ORDER BY id DESC LIMIT 1 FOR UPDATE");$s->execute([$userId]);$r=$s->fetch(PDO::FETCH_ASSOC);if(!$r||!hash_equals((string)$r['code_hash'],hash('sha256',$code))){$db->rollBack();return false;}$db->prepare("UPDATE email_two_factor_codes SET used=1 WHERE id=?")->execute([$r['id']]);$db->commit();return true;}catch(Throwable $e){if($db->inTransaction())$db->rollBack();return false;}
}

function moni_service_rating(PDO $db,int $serviceId): array {
    if(!moni_table_ready($db,'service_reviews'))return ['avg'=>0.0,'count'=>0];
    try{$s=$db->prepare("SELECT COALESCE(AVG(rating),0),COUNT(*) FROM service_reviews WHERE service_id=? AND status='approved'");$s->execute([$serviceId]);$r=$s->fetch(PDO::FETCH_NUM);return ['avg'=>round((float)($r[0]??0),1),'count'=>(int)($r[1]??0)];}catch(Throwable $e){return ['avg'=>0.0,'count'=>0];}
}

function moni_service_ratings(PDO $db,array $serviceIds): array {
    $ids=array_values(array_unique(array_filter(array_map('intval',$serviceIds),static fn($id)=>$id>0)));
    if(!$ids||!moni_table_ready($db,'service_reviews'))return [];
    try{
        $ph=implode(',',array_fill(0,count($ids),'?'));
        $st=$db->prepare("SELECT service_id,COALESCE(AVG(rating),0) AS rating_avg,COUNT(*) AS rating_count FROM service_reviews WHERE status='approved' AND service_id IN ($ph) GROUP BY service_id");
        $st->execute($ids);$out=[];
        foreach($st->fetchAll(PDO::FETCH_ASSOC) as $r){$out[(int)$r['service_id']]=['avg'=>round((float)$r['rating_avg'],1),'count'=>(int)$r['rating_count']];}
        return $out;
    }catch(Throwable $e){return [];}
}

function moni_child_domain_normalize(string $domain): string {
    $domain=strtolower(trim($domain));$domain=preg_replace('#^https?://#','',$domain);$domain=trim(explode('/',$domain)[0],'.');
    return preg_match('/^(?=.{4,190}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i',$domain)?$domain:'';
}
function moni_child_dns_check(PDO $db,int $panelId): array {
    $s=$db->prepare("SELECT id,domain FROM child_panels WHERE id=? LIMIT 1");$s->execute([$panelId]);$p=$s->fetch(PDO::FETCH_ASSOC);if(!$p)return ['ok'=>false,'message'=>'Panel bulunamadı.'];
    $domain=moni_child_domain_normalize((string)$p['domain']);if(!$domain)return ['ok'=>false,'message'=>'Geçersiz alan adı.'];
    $expectedCname=strtolower(trim((string)getSetting('child_panel_dns_cname_target','')));$expectedIp=trim((string)getSetting('child_panel_dns_a_target',''));
    $records=@dns_get_record($domain,DNS_A|DNS_CNAME);$ok=false;$detail=[];
    foreach($records?:[] as $r){if(($r['type']??'')==='A'){$detail[]='A '.($r['ip']??'');if($expectedIp!==''&&($r['ip']??'')===$expectedIp)$ok=true;}if(($r['type']??'')==='CNAME'){$t=strtolower(rtrim((string)($r['target']??''),'.'));$detail[]='CNAME '.$t;if($expectedCname!==''&&$t===rtrim($expectedCname,'.'))$ok=true;}}
    if($expectedCname===''&&$expectedIp===''){$siteHost=moni_safe_site_host();if($siteHost){$siteIps=@gethostbynamel($siteHost)?:[];foreach($records?:[] as $r){if(($r['type']??'')==='A'&&in_array($r['ip']??'', $siteIps,true))$ok=true;if(($r['type']??'')==='CNAME'&&strtolower(rtrim((string)($r['target']??''),'.'))===strtolower($siteHost))$ok=true;}}}
    $status=$ok?'verified':'failed';
    try{$db->prepare("UPDATE child_panels SET dns_status=?,dns_last_checked_at=NOW() WHERE id=?")->execute([$status,$panelId]);if(moni_table_ready($db,'child_panel_domain_logs'))$db->prepare("INSERT INTO child_panel_domain_logs(child_panel_id,event_type,status,message,created_at) VALUES(?,?,?,?,NOW())")->execute([$panelId,'dns_check',$status,implode(' | ',$detail)]);}catch(Throwable $e){}
    return ['ok'=>$ok,'message'=>$ok?'DNS doğrulandı.':'DNS hedefi doğrulanamadı.','detail'=>implode(' | ',$detail)];
}
function moni_child_ssl_issue(PDO $db,int $panelId): array {
    if(getSetting('child_panel_ssl_automation','0')!=='1')return ['ok'=>false,'message'=>'SSL otomasyonu yönetici tarafından etkinleştirilmemiş.'];
    $dns=moni_child_dns_check($db,$panelId);if(!$dns['ok'])return ['ok'=>false,'message'=>'SSL öncesi DNS doğrulaması başarısız.'];
    $s=$db->prepare("SELECT domain FROM child_panels WHERE id=?");$s->execute([$panelId]);$domain=moni_child_domain_normalize((string)$s->fetchColumn());if(!$domain)return ['ok'=>false,'message'=>'Geçersiz alan adı.'];
    $bin=(string)getSetting('child_panel_certbot_path','/usr/bin/certbot');if(!in_array($bin,['/usr/bin/certbot','/usr/local/bin/certbot'],true)||!is_executable($bin))return ['ok'=>false,'message'=>'Certbot bulunamadı veya izinli konumda değil.'];
    $email=trim((string)getSetting('child_panel_ssl_email',''));if(!filter_var($email,FILTER_VALIDATE_EMAIL))return ['ok'=>false,'message'=>'Geçerli SSL yönetici e-postası ayarlayın.'];
    $webroot=realpath(dirname(__DIR__))?:dirname(__DIR__);
    $cmd=escapeshellcmd($bin).' certonly --webroot --non-interactive --agree-tos --keep-until-expiring --email '.escapeshellarg($email).' -w '.escapeshellarg($webroot).' -d '.escapeshellarg($domain).' 2>&1';
    $out=[];$code=1;@exec($cmd,$out,$code);$msg=substr(implode("\n",$out),0,3000);$ok=$code===0;
    $expiry=null;if($ok){$cert='/etc/letsencrypt/live/'.$domain.'/cert.pem';if(is_readable($cert)){$x=@openssl_x509_parse(file_get_contents($cert));if(!empty($x['validTo_time_t']))$expiry=date('Y-m-d H:i:s',(int)$x['validTo_time_t']);}}
    try{$db->prepare("UPDATE child_panels SET ssl_status=?,ssl_expires_at=?,ssl_last_checked_at=NOW(),ssl_last_error=? WHERE id=?")->execute([$ok?'active':'failed',$expiry,$ok?null:$msg,$panelId]);if(moni_table_ready($db,'child_panel_domain_logs'))$db->prepare("INSERT INTO child_panel_domain_logs(child_panel_id,event_type,status,message,created_at) VALUES(?,?,?,?,NOW())")->execute([$panelId,'ssl_issue',$ok?'success':'failed',$msg]);}catch(Throwable $e){}
    return ['ok'=>$ok,'message'=>$ok?'SSL sertifikası oluşturuldu/yenilendi.':'SSL işlemi başarısız: '.$msg];
}
