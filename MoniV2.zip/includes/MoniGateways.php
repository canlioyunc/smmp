<?php
if (defined('MONI_GATEWAYS_LOADED')) return;
define('MONI_GATEWAYS_LOADED', true);

interface MoniGatewayAdapter {
    public function slug(): string;
    public function title(): string;
    public function createPayment(PDO $db,int $userId,float $amount,array $context=[]): array;
    public function verifyCallback(PDO $db,array $payload,array $server=[]): array;
}

function moni_gateway_registry():array{
    static $r=null;if($r!==null)return $r;$r=[];
    $dir=dirname(__DIR__).'/gateways/adapters';
    if(is_dir($dir))foreach(glob($dir.'/*.php')?:[] as $f){$a=require $f;if($a instanceof MoniGatewayAdapter)$r[$a->slug()]=$a;}
    return $r;
}
function moni_gateway(string $slug,?PDO $db=null,bool $requireEnabled=true):?MoniGatewayAdapter{
    $r=moni_gateway_registry();$g=$r[$slug]??null;if(!$g)return null;
    if($requireEnabled&&$db&&moni_table_ready($db,'payment_gateway_adapters')){
        $st=$db->prepare("SELECT is_enabled FROM payment_gateway_adapters WHERE slug=? LIMIT 1");$st->execute([$slug]);$enabled=$st->fetchColumn();
        if($enabled!==false && (int)$enabled!==1)return null;
    }
    return $g;
}
function moni_gateway_config(PDO $db,string $slug):array{
    if(!moni_table_ready($db,'payment_gateway_adapters'))return [];
    $st=$db->prepare("SELECT config_json FROM payment_gateway_adapters WHERE slug=? LIMIT 1");$st->execute([$slug]);
    $cfg=json_decode((string)($st->fetchColumn()?:'{}'),true);if(!is_array($cfg))$cfg=[];
    foreach(['api_key','secret_key','merchant_key','client_secret'] as $k){
        if(array_key_exists($k,$cfg))$cfg[$k]=moni_decrypt_secret((string)$cfg[$k]);
    }
    return $cfg;
}
function moni_gateway_transaction_start(PDO $db,int $userId,string $slug,string $localToken,float $paid,float $credit,array $payload=[]):int{
    $currency=moni_base_currency($db);$json=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);$childId=(int)($payload['child_panel_id']??0);
    if($childId>0){try{$db->prepare("INSERT INTO gateway_transactions(user_id,gateway_slug,local_token,status,amount,credit_amount,currency_code,payload_json,child_panel_id,created_at) VALUES(?,?,?,'pending',?,?,?,?,?,NOW())")->execute([$userId,$slug,$localToken,$paid,$credit,$currency,$json,$childId]);return (int)$db->lastInsertId();}catch(Throwable $ignore){}}
    $db->prepare("INSERT INTO gateway_transactions(user_id,gateway_slug,local_token,status,amount,credit_amount,currency_code,payload_json,created_at) VALUES(?,?,?,'pending',?,?,?,?,NOW())")
       ->execute([$userId,$slug,$localToken,$paid,$credit,$currency,$json]);
    return (int)$db->lastInsertId();
}
function moni_gateway_credit_once(PDO $db,int $txId,string $gatewayTransactionId,array $verifyData=[]):array{
    $own=!$db->inTransaction();if($own)$db->beginTransaction();
    try{
        $st=$db->prepare("SELECT * FROM gateway_transactions WHERE id=? FOR UPDATE");$st->execute([$txId]);$tx=$st->fetch(PDO::FETCH_ASSOC);if(!$tx)throw new RuntimeException('Ödeme kaydı bulunamadı.');
        if($tx['status']==='paid'){if($own)$db->commit();return ['ok'=>true,'already'=>true,'user_id'=>(int)$tx['user_id'],'amount'=>(float)$tx['credit_amount']];}
        $existing=$db->prepare("SELECT id FROM gateway_transactions WHERE gateway_slug=? AND gateway_transaction_id=? AND id<>? LIMIT 1");$existing->execute([$tx['gateway_slug'],$gatewayTransactionId,$txId]);if($existing->fetchColumn())throw new RuntimeException('Bu gateway işlemi daha önce kullanılmış.');
        $user=$db->prepare("SELECT balance FROM users WHERE id=? FOR UPDATE");$user->execute([$tx['user_id']]);$before=$user->fetchColumn();if($before===false)throw new RuntimeException('Kullanıcı bulunamadı.');
        $credit=(float)$tx['credit_amount'];
        $db->prepare("UPDATE users SET balance=balance+? WHERE id=?")->execute([$credit,$tx['user_id']]);
        $after=(float)$before+$credit;
        $db->prepare("INSERT INTO transactions(user_id,type,amount,balance_after,description,status,created_at) VALUES(?,'deposit',?,?,?,'completed',NOW())")
           ->execute([$tx['user_id'],$credit,$after,ucfirst($tx['gateway_slug']).' bakiye yükleme']);
        $db->prepare("UPDATE gateway_transactions SET gateway_transaction_id=?,status='paid',verified_json=?,completed_at=NOW() WHERE id=?")
           ->execute([$gatewayTransactionId,json_encode($verifyData,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$txId]);
        if($own)$db->commit();moni_sync_base_wallet($db,(int)$tx['user_id']);
        return ['ok'=>true,'already'=>false,'user_id'=>(int)$tx['user_id'],'amount'=>$credit];
    }catch(Throwable $e){if($own&&$db->inTransaction())$db->rollBack();return ['ok'=>false,'error'=>$e->getMessage()];}
}
