<?php
/**
 * Moni v2 - Destek Çalışma Saatleri + Servis Hedef Kara/Beyaz Liste
 * Mevcut ayarları değiştirmeden ayrı, idempotent bir şema revizyonu kullanır.
 */
if (defined('MONI_SUPPORT_TARGET_LOADED')) return;
define('MONI_SUPPORT_TARGET_LOADED', true);

function moni_support_target_runtime_migrate(PDO $db): void {
    static $done=false; if($done)return; $done=true;
    $revision='2026-09-29.1';
    try {
        $ready = function_exists('moni_v2_compat_setting')
            && moni_v2_compat_setting($db,'moni_support_target_schema_revision','')===$revision
            && function_exists('moni_table_ready')
            && moni_table_ready($db,'support_department_hours')
            && moni_table_ready($db,'service_target_policies')
            && moni_table_ready($db,'service_target_rules')
            && moni_table_ready($db,'service_target_block_logs')
            && function_exists('moni_v2_compat_column_exists')
            && moni_v2_compat_column_exists($db,'support_departments','working_hours_enabled')
            && moni_v2_compat_column_exists($db,'support_departments','timezone')
            && moni_v2_compat_column_exists($db,'support_departments','accept_after_hours')
            && moni_v2_compat_column_exists($db,'support_departments','after_hours_message');
        if($ready)return;

        if(function_exists('moni_v2_compat_add_column')){
            moni_v2_compat_add_column($db,'support_departments','working_hours_enabled',"tinyint(1) NOT NULL DEFAULT 0");
            moni_v2_compat_add_column($db,'support_departments','timezone',"varchar(64) NOT NULL DEFAULT 'Europe/Istanbul'");
            moni_v2_compat_add_column($db,'support_departments','accept_after_hours',"tinyint(1) NOT NULL DEFAULT 1");
            moni_v2_compat_add_column($db,'support_departments','after_hours_message',"varchar(500) NULL");
        }

        $ddl=[];
        $ddl[]="CREATE TABLE IF NOT EXISTS support_department_hours (
            id bigint NOT NULL AUTO_INCREMENT,
            department_id int NOT NULL,
            day_of_week tinyint NOT NULL,
            open_time time NOT NULL DEFAULT '09:00:00',
            close_time time NOT NULL DEFAULT '18:00:00',
            is_closed tinyint(1) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY(id),
            UNIQUE KEY uq_support_department_day(department_id,day_of_week),
            KEY idx_support_hours_department(department_id,day_of_week)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS service_target_policies (
            service_id int NOT NULL,
            mode enum('off','blacklist','whitelist') NOT NULL DEFAULT 'off',
            block_message varchar(500) NULL,
            updated_by int NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY(service_id),
            KEY idx_target_policy_mode(mode)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS service_target_rules (
            id bigint NOT NULL AUTO_INCREMENT,
            service_id int NOT NULL,
            rule_type enum('exact','domain','contains','prefix','username') NOT NULL DEFAULT 'exact',
            rule_value varchar(1000) NOT NULL,
            note varchar(255) NULL,
            is_active tinyint(1) NOT NULL DEFAULT 1,
            created_by int NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY(id),
            KEY idx_target_rule_service(service_id,is_active,id),
            KEY idx_target_rule_type(service_id,rule_type,is_active)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS service_target_block_logs (
            id bigint NOT NULL AUTO_INCREMENT,
            service_id int NOT NULL,
            user_id int NULL,
            policy_mode varchar(20) NOT NULL,
            rule_id bigint NULL,
            target varchar(1000) NOT NULL,
            source varchar(50) NOT NULL DEFAULT 'web',
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(id),
            KEY idx_target_block_service(service_id,created_at),
            KEY idx_target_block_user(user_id,created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        foreach($ddl as $sql)$db->exec($sql);
        if(function_exists('moni_v2_compat_set_setting'))moni_v2_compat_set_setting($db,'moni_support_target_schema_revision',$revision);
        else updateSetting('moni_support_target_schema_revision',$revision);
    } catch(Throwable $e) {
        error_log('Moni Support/Target migration failed: '.$e->getMessage());
        $GLOBALS['moni_support_target_migration_error']=$e->getMessage();
    }
}

function moni_support_weekdays(): array {
    return [1=>'Pazartesi',2=>'Salı',3=>'Çarşamba',4=>'Perşembe',5=>'Cuma',6=>'Cumartesi',7=>'Pazar'];
}

function moni_support_safe_timezone(string $timezone): string {
    static $valid=null;
    if($valid===null)$valid=array_flip(DateTimeZone::listIdentifiers());
    return isset($valid[$timezone])?$timezone:'Europe/Istanbul';
}

function moni_support_department_status(PDO $db,int $departmentId,?DateTimeImmutable $moment=null): array {
    if($departmentId<=0||!function_exists('moni_table_ready')||!moni_table_ready($db,'support_departments'))return ['open'=>true,'enabled'=>false,'accept_after_hours'=>true,'label'=>'Açık'];
    try{
        $q=$db->prepare("SELECT id,name,working_hours_enabled,timezone,accept_after_hours,after_hours_message FROM support_departments WHERE id=? LIMIT 1");$q->execute([$departmentId]);$d=$q->fetch(PDO::FETCH_ASSOC);
        if(!$d)return ['open'=>true,'enabled'=>false,'accept_after_hours'=>true,'label'=>'Açık'];
        $enabled=!empty($d['working_hours_enabled']);$accept=!isset($d['accept_after_hours'])||!empty($d['accept_after_hours']);
        $message=trim((string)($d['after_hours_message']??''));
        if(!$enabled||!moni_table_ready($db,'support_department_hours'))return ['open'=>true,'enabled'=>false,'accept_after_hours'=>$accept,'label'=>'7/24 Açık','message'=>$message,'timezone'=>(string)($d['timezone']??'Europe/Istanbul')];
        $tzName=moni_support_safe_timezone((string)($d['timezone']??'Europe/Istanbul'));$tz=new DateTimeZone($tzName);
        $now=$moment?$moment->setTimezone($tz):new DateTimeImmutable('now',$tz);$day=(int)$now->format('N');$time=$now->format('H:i:s');
        $s=$db->prepare("SELECT day_of_week,open_time,close_time,is_closed FROM support_department_hours WHERE department_id=? ORDER BY day_of_week");$s->execute([$departmentId]);$rows=[];foreach($s->fetchAll(PDO::FETCH_ASSOC) as $r)$rows[(int)$r['day_of_week']]=$r;
        if(!$rows)return ['open'=>true,'enabled'=>false,'accept_after_hours'=>$accept,'label'=>'7/24 Açık','message'=>$message,'timezone'=>$tzName];
        $open=false;$closesAt=null;
        $today=$rows[$day]??null;
        if($today&&!$today['is_closed']){
            $start=(string)$today['open_time'];$end=(string)$today['close_time'];
            if($start<=$end){if($time>=$start&&$time<$end){$open=true;$closesAt=$end;}}
            else {if($time>=$start){$open=true;$closesAt=$end.' (+1 gün)';}}
        }
        if(!$open){$prev=$day===1?7:$day-1;$pr=$rows[$prev]??null;if($pr&&!$pr['is_closed']&&(string)$pr['open_time']>(string)$pr['close_time']&&$time<(string)$pr['close_time']){$open=true;$closesAt=(string)$pr['close_time'];}}
        $nextOpen=null;
        if(!$open){
            for($offset=0;$offset<=7;$offset++){
                $candidate=$now->modify('+'.$offset.' day');$dow=(int)$candidate->format('N');$r=$rows[$dow]??null;if(!$r||$r['is_closed'])continue;
                $start=(string)$r['open_time'];$candidateOpen=new DateTimeImmutable($candidate->format('Y-m-d').' '.$start,$tz);
                if($candidateOpen>$now){$nextOpen=$candidateOpen->format('d.m.Y H:i');break;}
            }
        }
        if($message==='')$message=$open?'Destek departmanı şu anda hizmet veriyor.':'Bu departman şu anda çalışma saatleri dışında.';
        return ['open'=>$open,'enabled'=>true,'accept_after_hours'=>$accept,'label'=>$open?'Açık':'Kapalı','message'=>$message,'timezone'=>$tzName,'closes_at'=>$closesAt,'next_open'=>$nextOpen];
    }catch(Throwable $e){return ['open'=>true,'enabled'=>false,'accept_after_hours'=>true,'label'=>'Açık'];}
}


function moni_target_lower(string $value): string {
    return function_exists('mb_strtolower') ? mb_strtolower($value,'UTF-8') : strtolower($value);
}

function moni_target_normalize(string $target): string {
    $target=trim(html_entity_decode($target,ENT_QUOTES|ENT_HTML5,'UTF-8'));
    if($target==='')return '';
    $candidate=$target;
    if(!preg_match('#^[a-z][a-z0-9+.-]*://#i',$candidate)&&preg_match('/^[a-z0-9.-]+\.[a-z]{2,}(?:\/|$)/i',$candidate))$candidate='https://'.$candidate;
    $p=@parse_url($candidate);
    if(is_array($p)&&!empty($p['host'])){
        $scheme=strtolower((string)($p['scheme']??'https'));$host=strtolower(rtrim((string)$p['host'],'.'));if(str_starts_with($host,'www.'))$host=substr($host,4);
        $port=isset($p['port'])?':'.(int)$p['port']:'';$path=(string)($p['path']??'');$path=$path==='/'?'':rtrim($path,'/');$query=isset($p['query'])?'?'.$p['query']:'';
        return $scheme.'://'.$host.$port.$path.$query;
    }
    return moni_target_lower(rtrim($target,'/'));
}

function moni_target_domain(string $target): string {
    $candidate=trim($target);if(!preg_match('#^[a-z][a-z0-9+.-]*://#i',$candidate))$candidate='https://'.ltrim($candidate,'/');$host=(string)(parse_url($candidate,PHP_URL_HOST)?:'');$host=strtolower(rtrim($host,'.'));return str_starts_with($host,'www.')?substr($host,4):$host;
}

function moni_target_username_candidates(string $target): array {
    $out=[];$raw=trim($target);if($raw!=='')$out[]=moni_target_lower(ltrim($raw,'@'));
    $candidate=$raw;if(!preg_match('#^[a-z][a-z0-9+.-]*://#i',$candidate))$candidate='https://'.ltrim($candidate,'/');$path=(string)(parse_url($candidate,PHP_URL_PATH)?:'');
    foreach(array_filter(explode('/',trim($path,'/'))) as $seg){$seg=urldecode($seg);$seg=moni_target_lower(ltrim($seg,'@'));if($seg!=='')$out[]=$seg;}
    return array_values(array_unique($out));
}

function moni_target_rule_matches(string $target,array $rule): bool {
    $type=(string)($rule['rule_type']??'exact');$value=trim((string)($rule['rule_value']??''));if($value==='')return false;
    if($type==='domain'){$ruleDomain=moni_target_domain($value);$targetDomain=moni_target_domain($target);return $ruleDomain!==''&&$targetDomain!==''&&($targetDomain===$ruleDomain||str_ends_with($targetDomain,'.'.$ruleDomain));}
    if($type==='username'){$needle=moni_target_lower(ltrim($value,'@'));return $needle!==''&&in_array($needle,moni_target_username_candidates($target),true);}
    $normalized=moni_target_normalize($target);$needle=moni_target_normalize($value);
    if($type==='contains')return $needle!==''&&str_contains($normalized,$needle);
    if($type==='prefix')return $needle!==''&&str_starts_with($normalized,$needle);
    return hash_equals($needle,$normalized);
}

function moni_service_target_policy(PDO $db,int $serviceId): array {
    if($serviceId<=0||!function_exists('moni_table_ready')||!moni_table_ready($db,'service_target_policies'))return ['mode'=>'off','block_message'=>''];
    try{$s=$db->prepare("SELECT * FROM service_target_policies WHERE service_id=? LIMIT 1");$s->execute([$serviceId]);$r=$s->fetch(PDO::FETCH_ASSOC);return $r?:['service_id'=>$serviceId,'mode'=>'off','block_message'=>''];}catch(Throwable $e){return ['mode'=>'off','block_message'=>''];}
}

function moni_validate_service_target(PDO $db,int $serviceId,string $target,int $userId=0,string $source='web'): array {
    $policy=moni_service_target_policy($db,$serviceId);$mode=(string)($policy['mode']??'off');if($mode==='off')return ['ok'=>true,'mode'=>'off'];
    if(!in_array($mode,['blacklist','whitelist'],true))return ['ok'=>true,'mode'=>'off'];
    try{$q=$db->prepare("SELECT * FROM service_target_rules WHERE service_id=? AND is_active=1 ORDER BY id");$q->execute([$serviceId]);$rules=$q->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){$rules=[];}
    $matched=null;foreach($rules as $r){if(moni_target_rule_matches($target,$r)){$matched=$r;break;}}
    $ok=$mode==='blacklist'?$matched===null:$matched!==null;
    if($ok)return ['ok'=>true,'mode'=>$mode,'matched_rule_id'=>(int)($matched['id']??0)];
    $message=trim((string)($policy['block_message']??''));
    if($message==='')$message=$mode==='blacklist'?'Bu hedef bu servis için engellenmiştir.':'Bu servis yalnız izin verilen hedeflerde kullanılabilir.';
    if(moni_table_ready($db,'service_target_block_logs')){try{$db->prepare("INSERT INTO service_target_block_logs(service_id,user_id,policy_mode,rule_id,target,source) VALUES(?,?,?,?,?,?)")->execute([$serviceId,$userId>0?$userId:null,$mode,$matched['id']??null,mb_substr($target,0,1000,'UTF-8'),mb_substr($source,0,50,'UTF-8')]);}catch(Throwable $ignore){}}
    return ['ok'=>false,'mode'=>$mode,'error'=>$message,'matched_rule_id'=>(int)($matched['id']??0)];
}
