<?php
/**
 * Moni v2 Growth Pro
 * Hedef önizleme, kişiselleştirilmiş servis sıralaması, drop-rate analizi,
 * çok dilli servis açıklamaları, PWA, Web Push ve e-posta teslim edilebilirlik merkezi.
 */
if (defined('MONI_GROWTH_PRO_LOADED')) return;
define('MONI_GROWTH_PRO_LOADED', true);

function moni_growth_runtime_migrate(PDO $db): void {
    static $done=false; if($done)return; $done=true;
    $revision='2026-09-29.1';
    try {
        $ready=function_exists('moni_v2_compat_setting')
            && moni_v2_compat_setting($db,'moni_growth_pro_schema_revision','')===$revision
            && function_exists('moni_table_ready')
            && moni_table_ready($db,'service_translations')
            && moni_table_ready($db,'user_service_affinity')
            && moni_table_ready($db,'order_drop_observations')
            && moni_table_ready($db,'service_drop_metrics')
            && moni_table_ready($db,'web_push_subscriptions')
            && moni_table_ready($db,'web_push_queue')
            && moni_table_ready($db,'email_delivery_events')
            && function_exists('moni_v2_compat_column_exists')
            && moni_v2_compat_column_exists($db,'notification_preferences','push_enabled');
        if($ready){
            try{$q=$db->query("SELECT COUNT(*) FROM cron_tasks WHERE task_key IN('service_drop_analysis','web_push_delivery')");$ready=(int)$q->fetchColumn()===2;}catch(Throwable $e){$ready=false;}
        }
        if($ready){
            try{if((string)getSetting('email_bounce_webhook_token','')==='')updateSetting('email_bounce_webhook_token',bin2hex(random_bytes(24)));}catch(Throwable $ignore){}
            try{moni_webpush_ensure_keys($db);}catch(Throwable $ignore){}
            return;
        }

        if(function_exists('moni_v2_compat_add_column')){
            moni_v2_compat_add_column($db,'notification_preferences','push_enabled','tinyint(1) NOT NULL DEFAULT 1');
        }
        $ddl=[];
        $ddl[]="CREATE TABLE IF NOT EXISTS service_translations (
            id bigint NOT NULL AUTO_INCREMENT,
            service_id int NOT NULL,
            language_code varchar(12) NOT NULL,
            description text NULL,
            updated_by int NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY(id), UNIQUE KEY uq_service_language(service_id,language_code), KEY idx_service_translation_lang(language_code,service_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS user_service_affinity (
            user_id int NOT NULL,
            service_id int NOT NULL,
            order_count bigint NOT NULL DEFAULT 0,
            total_quantity bigint NOT NULL DEFAULT 0,
            last_order_at datetime NULL,
            score decimal(16,4) NOT NULL DEFAULT 0,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY(user_id,service_id), KEY idx_affinity_user_score(user_id,score,last_order_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS order_drop_observations (
            id bigint NOT NULL AUTO_INCREMENT,
            order_id int NOT NULL,
            service_id int NOT NULL,
            start_count bigint NOT NULL,
            ordered_quantity bigint NOT NULL,
            expected_count bigint NOT NULL,
            observed_count bigint NOT NULL,
            drop_amount bigint NOT NULL DEFAULT 0,
            drop_percent decimal(7,3) NOT NULL DEFAULT 0,
            observed_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_checked_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(id), UNIQUE KEY uq_drop_order(order_id), KEY idx_drop_service_time(service_id,last_checked_at), KEY idx_drop_percent(service_id,drop_percent)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS service_drop_metrics (
            service_id int NOT NULL,
            sample_orders int NOT NULL DEFAULT 0,
            dropped_orders int NOT NULL DEFAULT 0,
            average_drop_percent decimal(7,3) NOT NULL DEFAULT 0,
            max_drop_percent decimal(7,3) NOT NULL DEFAULT 0,
            last_observed_at datetime NULL,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY(service_id), KEY idx_drop_metric_average(average_drop_percent,sample_orders)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS web_push_subscriptions (
            id bigint NOT NULL AUTO_INCREMENT,
            user_id int NOT NULL,
            endpoint text NOT NULL,
            endpoint_hash char(64) NOT NULL,
            p256dh varchar(255) NULL,
            auth_secret varchar(255) NULL,
            user_agent varchar(500) NULL,
            is_active tinyint(1) NOT NULL DEFAULT 1,
            last_seen_at datetime NULL,
            last_push_at datetime NULL,
            last_error varchar(1000) NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY(id), UNIQUE KEY uq_push_endpoint(endpoint_hash), KEY idx_push_user(user_id,is_active), KEY idx_push_active(is_active,last_push_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS web_push_queue (
            id bigint NOT NULL AUTO_INCREMENT,
            user_id int NOT NULL,
            notification_type varchar(80) NOT NULL DEFAULT 'general',
            title varchar(190) NOT NULL,
            body varchar(1000) NULL,
            url varchar(500) NULL,
            icon varchar(500) NULL,
            status enum('pending','sent','failed') NOT NULL DEFAULT 'pending',
            attempts int NOT NULL DEFAULT 0,
            next_attempt_at datetime NULL,
            last_error varchar(1000) NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            sent_at datetime NULL,
            PRIMARY KEY(id), KEY idx_push_queue(status,next_attempt_at,id), KEY idx_push_queue_user(user_id,created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS email_delivery_events (
            id bigint NOT NULL AUTO_INCREMENT,
            event_type enum('sent','failed','delivered','bounce','complaint','deferred','opened','clicked') NOT NULL,
            recipient varchar(320) NULL,
            message_id varchar(255) NULL,
            provider varchar(80) NULL,
            detail varchar(1000) NULL,
            payload_json mediumtext NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(id), KEY idx_email_event_type(event_type,created_at), KEY idx_email_event_recipient(recipient,created_at), KEY idx_email_message(message_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        foreach($ddl as $sql)$db->exec($sql);

        $pl=$db->prepare("INSERT IGNORE INTO plugins(slug,name,description,version,is_enabled,is_core) VALUES(?,?,?,?,?,0)");
        $pl->execute(['target_preview','Hedef Canlı Önizleme','Girilen hedef URL adresini sunucudan veri çekmeden kullanıcının tarayıcısında küçük, güvenli bir tarayıcı önizlemesi olarak açar.','3.2.0',0]);
        $pl->execute(['pwa_app','PWA / Telefona Uygulama Gibi Kurulum','Kullanıcı panelini yönetilebilir Progressive Web App olarak kurulabilir hale getirir.','2.0.0',0]);

        $cs=$db->prepare("INSERT IGNORE INTO cron_tasks(task_key,name,interval_minutes,batch_size,is_enabled) VALUES(?,?,?,?,?)");
        $cs->execute(['service_drop_analysis','Servis Drop Rate Analizi',60,50,1]);
        $cs->execute(['web_push_delivery','Web Push Bildirim Kuyruğu',1,100,1]);

        $settings=[
            'personalized_service_sorting_enabled'=>'1',
            'drop_analysis_min_age_minutes'=>'60',
            'drop_analysis_recheck_hours'=>'24',
            'web_push_enabled'=>'1',
            'web_push_ttl'=>'120',
            'pwa_app_name'=>(string)getSetting('site_name','Moni'),
            'pwa_short_name'=>'Moni',
            'pwa_description'=>(string)getSetting('site_description','SMM Panel'),
            'pwa_theme_color'=>'#6c5ce7',
            'pwa_background_color'=>'#111327',
            'pwa_display'=>'standalone',
            'pwa_start_url'=>'/kullanici/',
            'pwa_scope'=>'/',
            'pwa_icon_192'=>'',
            'pwa_icon_512'=>'',
            'pwa_offline_title'=>'Bağlantı yok',
            'pwa_offline_message'=>'İnternet bağlantınızı kontrol edip tekrar deneyin.',
            'pwa_install_prompt'=>'1',
            'email_dkim_enabled'=>'0',
            'email_dkim_domain'=>'',
            'email_dkim_selector'=>'default',
            'email_dkim_private_key'=>'',
            'email_bounce_webhook_token'=>'',
        ];
        $st=$db->prepare("INSERT IGNORE INTO settings(setting_key,setting_value) VALUES(?,?)");
        foreach($settings as $k=>$v)$st->execute([$k,$v]);
        if((string)getSetting('email_bounce_webhook_token','')==='') updateSetting('email_bounce_webhook_token',bin2hex(random_bytes(24)));
        moni_webpush_ensure_keys($db);
        if(function_exists('moni_v2_compat_set_setting'))moni_v2_compat_set_setting($db,'moni_growth_pro_schema_revision',$revision);else updateSetting('moni_growth_pro_schema_revision',$revision);
    }catch(Throwable $e){
        error_log('Moni Growth Pro migration failed: '.$e->getMessage());
        $GLOBALS['moni_growth_pro_migration_error']=$e->getMessage();
    }
}

/* ------------------------- General helpers ------------------------- */
function moni_b64url(string $data): string { return rtrim(strtr(base64_encode($data),'+/','-_'),'='); }
function moni_b64url_decode(string $data): string { $pad=strlen($data)%4;if($pad)$data.=str_repeat('=',4-$pad);return (string)base64_decode(strtr($data,'-_','+/'),true); }
function moni_growth_plugin_enabled(PDO $db,string $slug): bool {
    $enabled=function_exists('moni_plugin_enabled')?moni_plugin_enabled($slug,$db):false;
    if(!$enabled && in_array($slug,['target_preview','pwa_app'],true) && (string)getSetting('demo_mode','0')==='1') return true;
    return $enabled;
}

/* ------------------------- Personalized service sorting ------------------------- */
function moni_record_service_affinity(PDO $db,int $userId,int $serviceId,int $quantity=0): void {
    if($userId<=0||$serviceId<=0||!function_exists('moni_table_ready')||!moni_table_ready($db,'user_service_affinity'))return;
    try{$score=1+log(1+max(0,$quantity),10);$db->prepare("INSERT INTO user_service_affinity(user_id,service_id,order_count,total_quantity,last_order_at,score) VALUES(?,?,1,?,NOW(),?) ON DUPLICATE KEY UPDATE order_count=order_count+1,total_quantity=total_quantity+VALUES(total_quantity),last_order_at=NOW(),score=(score*0.92)+VALUES(score),updated_at=NOW()")->execute([$userId,$serviceId,max(0,$quantity),$score]);}catch(Throwable $e){}
}
function moni_affinity_backfill_user(PDO $db,int $userId): void {
    if($userId<=0||!moni_table_ready($db,'user_service_affinity'))return;
    try{$c=$db->prepare("SELECT COUNT(*) FROM user_service_affinity WHERE user_id=?");$c->execute([$userId]);if((int)$c->fetchColumn()>0)return;$q=$db->prepare("SELECT service_id,COUNT(*) cnt,COALESCE(SUM(quantity),0) qty,MAX(created_at) last_at FROM orders WHERE user_id=? GROUP BY service_id ORDER BY cnt DESC LIMIT 100");$q->execute([$userId]);$ins=$db->prepare("INSERT IGNORE INTO user_service_affinity(user_id,service_id,order_count,total_quantity,last_order_at,score) VALUES(?,?,?,?,?,?)");foreach($q->fetchAll(PDO::FETCH_ASSOC) as $r){$cnt=(int)$r['cnt'];$days=max(0,(time()-strtotime((string)$r['last_at']))/86400);$recency=max(0,30-$days)/30;$score=$cnt+(3*$recency);$ins->execute([$userId,(int)$r['service_id'],$cnt,(int)$r['qty'],$r['last_at'],$score]);}}catch(Throwable $e){}
}
function moni_personalize_service_rows(PDO $db,int $userId,array $rows): array {
    if((string)getSetting('personalized_service_sorting_enabled','1')!=='1'||$userId<=0||!$rows)return $rows;
    moni_affinity_backfill_user($db,$userId);try{$q=$db->prepare("SELECT service_id,score,last_order_at FROM user_service_affinity WHERE user_id=? ORDER BY score DESC LIMIT 500");$q->execute([$userId]);$map=[];foreach($q->fetchAll(PDO::FETCH_ASSOC) as $r)$map[(int)$r['service_id']]=(float)$r['score'];}catch(Throwable $e){return $rows;}
    foreach($rows as $i=>&$r){$r['_personal_score']=$map[(int)($r['id']??0)]??0;$r['_original_order']=$i;}unset($r);
    usort($rows,static function($a,$b){$d=($b['_personal_score']??0)<=>($a['_personal_score']??0);return $d!==0?$d:(($a['_original_order']??0)<=>($b['_original_order']??0));});return $rows;
}

/* ------------------------- Multi-language service descriptions ------------------------- */
function moni_service_description(PDO $db,int $serviceId,string $fallback='',?string $language=null): string {
    $language=$language?:((function_exists('getCurrentLanguage'))?getCurrentLanguage():'tr');
    if($serviceId<=0||$language===''||!moni_table_ready($db,'service_translations'))return $fallback;
    try{$q=$db->prepare("SELECT description FROM service_translations WHERE service_id=? AND language_code=? LIMIT 1");$q->execute([$serviceId,$language]);$v=$q->fetchColumn();return $v!==false&&trim((string)$v)!==''?(string)$v:$fallback;}catch(Throwable $e){return $fallback;}
}
function moni_localize_service_rows(PDO $db,array $rows,?string $language=null): array {foreach($rows as &$r){if(isset($r['id']))$r['description']=moni_service_description($db,(int)$r['id'],(string)($r['description']??''),$language);}unset($r);return $rows;}

/* ------------------------- Drop-rate analysis ------------------------- */
function moni_refresh_service_drop_metric(PDO $db,int $serviceId): void {
    if($serviceId<=0||!moni_table_ready($db,'order_drop_observations')||!moni_table_ready($db,'service_drop_metrics'))return;
    try{$q=$db->prepare("SELECT COUNT(*) sample_orders,SUM(drop_amount>0) dropped_orders,COALESCE(AVG(drop_percent),0) avg_drop,COALESCE(MAX(drop_percent),0) max_drop,MAX(last_checked_at) last_at FROM order_drop_observations WHERE service_id=? AND last_checked_at>=DATE_SUB(NOW(),INTERVAL 30 DAY)");$q->execute([$serviceId]);$r=$q->fetch(PDO::FETCH_ASSOC);$db->prepare("INSERT INTO service_drop_metrics(service_id,sample_orders,dropped_orders,average_drop_percent,max_drop_percent,last_observed_at) VALUES(?,?,?,?,?,?) ON DUPLICATE KEY UPDATE sample_orders=VALUES(sample_orders),dropped_orders=VALUES(dropped_orders),average_drop_percent=VALUES(average_drop_percent),max_drop_percent=VALUES(max_drop_percent),last_observed_at=VALUES(last_observed_at),updated_at=NOW()")->execute([$serviceId,(int)$r['sample_orders'],(int)$r['dropped_orders'],(float)$r['avg_drop'],(float)$r['max_drop'],$r['last_at']]);}catch(Throwable $e){}
}
function moni_process_service_drop_analysis(PDO $db,int $batch=50): array {
    if(!function_exists('moni_detect_social_metric')||!moni_table_ready($db,'order_drop_observations'))return ['processed'=>0,'message'=>'Drop analizi için gerçek sayaç motoru veya tablolar hazır değil.'];
    $batch=max(1,min(500,$batch));$minAge=max(15,(int)getSetting('drop_analysis_min_age_minutes','60'));$hours=max(1,(int)getSetting('drop_analysis_recheck_hours','24'));
    $sql="SELECT o.id,o.service_id,o.link,o.quantity,o.start_count FROM orders o LEFT JOIN order_drop_observations d ON d.order_id=o.id WHERE o.status='completed' AND o.start_count IS NOT NULL AND o.updated_at<DATE_SUB(NOW(),INTERVAL {$minAge} MINUTE) AND (d.id IS NULL OR d.last_checked_at<DATE_SUB(NOW(),INTERVAL {$hours} HOUR)) ORDER BY COALESCE(d.last_checked_at,o.updated_at) ASC LIMIT {$batch}";
    $rows=$db->query($sql)->fetchAll(PDO::FETCH_ASSOC);$processed=0;$measured=0;$services=[];
    foreach($rows as $o){$r=moni_detect_social_metric($db,(string)$o['link']);$processed++;if(empty($r['ok']))continue;$current=(int)$r['count'];$expected=(int)$o['start_count']+(int)$o['quantity'];$drop=max(0,$expected-$current);$pct=(int)$o['quantity']>0?min(100,round(($drop/(int)$o['quantity'])*100,3)):0;
        $db->prepare("INSERT INTO order_drop_observations(order_id,service_id,start_count,ordered_quantity,expected_count,observed_count,drop_amount,drop_percent,observed_at,last_checked_at) VALUES(?,?,?,?,?,?,?,?,NOW(),NOW()) ON DUPLICATE KEY UPDATE observed_count=VALUES(observed_count),drop_amount=VALUES(drop_amount),drop_percent=VALUES(drop_percent),last_checked_at=NOW()")->execute([(int)$o['id'],(int)$o['service_id'],(int)$o['start_count'],(int)$o['quantity'],$expected,$current,$drop,$pct]);$services[(int)$o['service_id']]=true;$measured++;}
    foreach(array_keys($services) as $sid)moni_refresh_service_drop_metric($db,$sid);
    return ['processed'=>$processed,'message'=>"$processed tamamlanmış sipariş kontrol edildi; $measured gerçek drop ölçümü güncellendi."];
}

/* ------------------------- PWA ------------------------- */
function moni_pwa_config(PDO $db): array {
    return ['enabled'=>moni_growth_plugin_enabled($db,'pwa_app'),'name'=>(string)getSetting('pwa_app_name',getSetting('site_name','Moni')),'short_name'=>(string)getSetting('pwa_short_name','Moni'),'description'=>(string)getSetting('pwa_description',getSetting('site_description','SMM Panel')),'theme_color'=>(string)getSetting('pwa_theme_color','#6c5ce7'),'background_color'=>(string)getSetting('pwa_background_color','#111327'),'display'=>(string)getSetting('pwa_display','standalone'),'start_url'=>(string)getSetting('pwa_start_url','/kullanici/'),'scope'=>(string)getSetting('pwa_scope','/'),'icon_192'=>(string)getSetting('pwa_icon_192',''),'icon_512'=>(string)getSetting('pwa_icon_512',''),'offline_title'=>(string)getSetting('pwa_offline_title','Bağlantı yok'),'offline_message'=>(string)getSetting('pwa_offline_message','İnternet bağlantınızı kontrol edip tekrar deneyin.'),'install_prompt'=>(string)getSetting('pwa_install_prompt','1')==='1'];
}
function moni_pwa_head_tags(PDO $db): string {
    $p=moni_pwa_config($db);$push=(string)getSetting('web_push_enabled','1')==='1';if(empty($p['enabled'])&&!$push)return '';
    $base=rtrim(SITE_URL,'/');
    $out='<meta name="moni-csrf" content="'.htmlspecialchars(generateCSRFToken(),ENT_QUOTES,'UTF-8').'"><meta name="moni-base-url" content="'.htmlspecialchars($base,ENT_QUOTES,'UTF-8').'">';
    if(!empty($p['enabled'])){$out.='<link rel="manifest" href="'.htmlspecialchars($base.'/manifest.php',ENT_QUOTES,'UTF-8').'"><meta name="theme-color" content="'.htmlspecialchars($p['theme_color'],ENT_QUOTES,'UTF-8').'"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes">';}
    $out.='<script defer src="'.htmlspecialchars($base.'/assets/js/pwa-client.js?v=3',ENT_QUOTES,'UTF-8').'" data-pwa="'.(!empty($p['enabled'])?'1':'0').'" data-push="'.($push?'1':'0').'"></script>';
    return $out;
}

/* ------------------------- Web Push ------------------------- */
function moni_ecdsa_der_to_raw(string $der,int $partLen=32): string {
    $ofs=0;if(ord($der[$ofs++] ?? "\0")!==0x30)return '';$len=ord($der[$ofs++]??"\0");if($len&0x80){$n=$len&0x7f;$len=0;for($i=0;$i<$n;$i++)$len=($len<<8)|ord($der[$ofs++]??"\0");}
    $parts=[];for($j=0;$j<2;$j++){if(ord($der[$ofs++]??"\0")!==0x02)return '';$l=ord($der[$ofs++]??"\0");$v=substr($der,$ofs,$l);$ofs+=$l;$v=ltrim($v,"\0");$parts[]=str_pad(substr($v,-$partLen),$partLen,"\0",STR_PAD_LEFT);}return implode('',$parts);
}
function moni_webpush_ensure_keys(PDO $db): array {
    $pub=(string)getSetting('web_push_vapid_public','');$enc=(string)getSetting('web_push_vapid_private','');if($pub!==''&&$enc!=='')return ['public'=>$pub,'private'=>function_exists('moni_decrypt_secret')?moni_decrypt_secret($enc):$enc];
    if(!function_exists('openssl_pkey_new')||!defined('OPENSSL_KEYTYPE_EC'))return ['public'=>'','private'=>''];
    try{$res=openssl_pkey_new(['private_key_type'=>OPENSSL_KEYTYPE_EC,'curve_name'=>'prime256v1']);if(!$res)return ['public'=>'','private'=>''];openssl_pkey_export($res,$pem);$det=openssl_pkey_get_details($res);$x=$det['ec']['x']??'';$y=$det['ec']['y']??'';if($x===''||$y==='')return ['public'=>'','private'=>''];$pub=moni_b64url("\x04".$x.$y);updateSetting('web_push_vapid_public',$pub);updateSetting('web_push_vapid_private',function_exists('moni_encrypt_secret')?moni_encrypt_secret($pem):$pem);return ['public'=>$pub,'private'=>$pem];}catch(Throwable $e){return ['public'=>'','private'=>''];}
}
function moni_web_push_enqueue(PDO $db,int $userId,string $type,string $title,string $body='',?string $url=null,string $icon=''): int {
    if($userId<=0||(string)getSetting('web_push_enabled','1')!=='1'||!moni_table_ready($db,'web_push_queue'))return 0;
    if(function_exists('moni_notification_allowed')&&!moni_notification_allowed($db,$userId,$type,'push'))return 0;
    try{$s=$db->prepare("INSERT INTO web_push_queue(user_id,notification_type,title,body,url,icon,status,next_attempt_at) VALUES(?,?,?,?,?,?,'pending',NOW())");$s->execute([$userId,mb_substr($type,0,80),mb_substr($title,0,190),mb_substr($body,0,1000),$url?mb_substr($url,0,500):null,$icon?mb_substr($icon,0,500):null]);return (int)$db->lastInsertId();}catch(Throwable $e){return 0;}
}
function moni_webpush_vapid_jwt(string $aud,string $privatePem,string $publicKey): array {
    $subject=(string)getSetting('contact_email','');$sub=$subject!==''?'mailto:'.$subject:rtrim(SITE_URL,'/');$header=moni_b64url(json_encode(['typ'=>'JWT','alg'=>'ES256'],JSON_UNESCAPED_SLASHES));$payload=moni_b64url(json_encode(['aud'=>$aud,'exp'=>time()+43200,'sub'=>$sub],JSON_UNESCAPED_SLASHES));$data=$header.'.'.$payload;$sig='';if(!openssl_sign($data,$sig,$privatePem,OPENSSL_ALGO_SHA256))return [];$raw=moni_ecdsa_der_to_raw($sig);if($raw==='')return [];return ['jwt'=>$data.'.'.moni_b64url($raw),'public'=>$publicKey];
}
function moni_webpush_send_empty(PDO $db,array $sub): array {
    $endpoint=trim((string)($sub['endpoint']??''));$p=@parse_url($endpoint);$host=(string)($p['host']??'');$scheme=strtolower((string)($p['scheme']??''));$port=(int)($p['port']??443);
    if($endpoint===''||strlen($endpoint)>2048||$scheme!=='https'||$host===''||!empty($p['user'])||!empty($p['pass'])||!function_exists('moni_safe_public_url')||!moni_safe_public_url($endpoint))return ['ok'=>false,'permanent'=>true,'error'=>'Geçersiz veya güvenli olmayan push endpoint'];
    $resolved=function_exists('moni_resolve_public_host')?moni_resolve_public_host($host):null;if($resolved===null)return ['ok'=>false,'permanent'=>true,'error'=>'Push endpoint genel IP adresine çözümlenemedi'];
    $keys=moni_webpush_ensure_keys($db);if($keys['public']===''||$keys['private']==='')return ['ok'=>false,'error'=>'VAPID anahtarı üretilemedi'];$aud='https://'.$host.(isset($p['port'])?':'.$port:'');$v=moni_webpush_vapid_jwt($aud,$keys['private'],$keys['public']);if(!$v)return ['ok'=>false,'error'=>'VAPID imzası üretilemedi'];
    $ttl=max(30,min(86400,(int)getSetting('web_push_ttl','120')));$ch=curl_init($endpoint);curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>'',CURLOPT_RETURNTRANSFER=>true,CURLOPT_HEADER=>false,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>12,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_RESOLVE=>[$host.':'.$port.':'.$resolved],CURLOPT_HTTPHEADER=>['TTL: '.$ttl,'Authorization: vapid t='.$v['jwt'].', k='.$v['public'],'Content-Length: 0']]);$raw=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);$ok=$http>=200&&$http<300;return ['ok'=>$ok,'http'=>$http,'permanent'=>in_array($http,[404,410],true),'error'=>$ok?'':($err?:('HTTP '.$http)),'response'=>$raw];
}
function moni_process_web_push_queue(PDO $db,int $batch=100): array {
    if((string)getSetting('web_push_enabled','1')!=='1'||!moni_table_ready($db,'web_push_queue')||!moni_table_ready($db,'web_push_subscriptions'))return ['processed'=>0,'message'=>'Web Push kapalı veya tablolar hazır değil.'];$batch=max(1,min(1000,$batch));$q=$db->query("SELECT * FROM web_push_queue WHERE status='pending' AND (next_attempt_at IS NULL OR next_attempt_at<=NOW()) ORDER BY id LIMIT {$batch}");$rows=$q->fetchAll(PDO::FETCH_ASSOC);$processed=0;$sent=0;
    foreach($rows as $row){$s=$db->prepare("SELECT * FROM web_push_subscriptions WHERE user_id=? AND is_active=1");$s->execute([(int)$row['user_id']]);$subs=$s->fetchAll(PDO::FETCH_ASSOC);if(!$subs){$db->prepare("UPDATE web_push_queue SET status='failed',last_error='Aktif abonelik yok',attempts=attempts+1 WHERE id=?")->execute([(int)$row['id']]);$processed++;continue;}$okAny=false;$errors=[];foreach($subs as $sub){$r=moni_webpush_send_empty($db,$sub);if(!empty($r['ok'])){$okAny=true;$db->prepare("UPDATE web_push_subscriptions SET last_push_at=NOW(),last_error=NULL WHERE id=?")->execute([(int)$sub['id']]);}else{$errors[]=$r['error']??'hata';$db->prepare("UPDATE web_push_subscriptions SET last_error=?,is_active=IF(?,0,is_active) WHERE id=?")->execute([mb_substr((string)($r['error']??'hata'),0,1000),!empty($r['permanent'])?1:0,(int)$sub['id']]);}}
        if($okAny){$db->prepare("UPDATE web_push_queue SET status='sent',sent_at=NOW(),attempts=attempts+1,last_error=NULL WHERE id=?")->execute([(int)$row['id']]);$sent++;}else{$attempts=(int)$row['attempts']+1;$status=$attempts>=5?'failed':'pending';$delay=min(60,2**min(5,$attempts));$db->prepare("UPDATE web_push_queue SET status=?,attempts=?,next_attempt_at=DATE_ADD(NOW(),INTERVAL ? MINUTE),last_error=? WHERE id=?")->execute([$status,$attempts,$delay,mb_substr(implode(' | ',array_slice($errors,0,3)),0,1000),(int)$row['id']]);}$processed++;}
    return ['processed'=>$processed,'message'=>"$processed push kuyruğu işlendi; $sent bildirim push servisine teslim edildi."];
}

/* ------------------------- Email deliverability ------------------------- */
function moni_email_domain(): string {$email=(string)getSetting('smtp_from_email',getSetting('contact_email',''));$p=strrpos($email,'@');if($p!==false)return strtolower(substr($email,$p+1));$host=(string)(parse_url(SITE_URL,PHP_URL_HOST)?:'');return strtolower($host);}
function moni_dns_txt(string $host): array {$out=[];foreach((array)@dns_get_record($host,DNS_TXT) as $r){$v=(string)($r['txt']??'');if($v!=='')$out[]=$v;}return $out;}
function moni_email_dns_domain_eligible(string $domain): array {
    $domain=strtolower(rtrim(trim($domain),'.'));
    if($domain==='')return [false,'Gönderen alan adı tanımlı değil.'];
    if(filter_var($domain,FILTER_VALIDATE_IP))return [false,'IP adreslerinde SPF/DKIM/DMARC alan adı kontrolü yapılmaz.'];
    if(!str_contains($domain,'.')||!filter_var($domain,FILTER_VALIDATE_DOMAIN,FILTER_FLAG_HOSTNAME))return [false,'Geçerli bir genel alan adı olmadığı için DNS kontrolü atlandı.'];
    foreach(['localhost','local','test','invalid','example','internal','lan','localdomain','home','home.arpa','onion'] as $suffix){
        if($domain===$suffix||str_ends_with($domain,'.'.$suffix))return [false,'Yerel/ayrılmış alan adlarında DNS kontrolü atlandı.'];
    }
    return [true,''];
}
function moni_email_deliverability_check(PDO $db): array {
    $domain=moni_email_domain();$selector=trim((string)getSetting('email_dkim_selector','default'));$spf=[];$dmarc=[];$dkim=[];
    [$dnsEligible,$dnsMessage]=moni_email_dns_domain_eligible($domain);
    if($dnsEligible){
        $spf=array_values(array_filter(moni_dns_txt($domain),static fn($v)=>str_starts_with(strtolower($v),'v=spf1')));
        $dmarc=array_values(array_filter(moni_dns_txt('_dmarc.'.$domain),static fn($v)=>str_starts_with(strtolower($v),'v=dmarc1')));
        if($selector!=='')$dkim=moni_dns_txt($selector.'._domainkey.'.$domain);
    }
    return ['domain'=>$domain,'spf'=>$spf,'dmarc'=>$dmarc,'dkim'=>$dkim,'dns_skipped'=>!$dnsEligible,'dns_message'=>$dnsMessage,'smtp_enabled'=>(string)getSetting('smtp_enabled','0')==='1','from_email'=>(string)getSetting('smtp_from_email',''),'dkim_signing'=>(string)getSetting('email_dkim_enabled','0')==='1'];
}
function moni_email_event(PDO $db,string $type,string $recipient='',string $messageId='',string $provider='',string $detail='',array $payload=[]): void {if(!moni_table_ready($db,'email_delivery_events'))return;$allowed=['sent','failed','delivered','bounce','complaint','deferred','opened','clicked'];if(!in_array($type,$allowed,true))$type='failed';try{$db->prepare("INSERT INTO email_delivery_events(event_type,recipient,message_id,provider,detail,payload_json) VALUES(?,?,?,?,?,?)")->execute([$type,mb_substr($recipient,0,320),mb_substr($messageId,0,255),mb_substr($provider,0,80),mb_substr($detail,0,1000),$payload?json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):null]);}catch(Throwable $e){}}
