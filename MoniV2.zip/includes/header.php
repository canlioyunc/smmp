<?php
require_once __DIR__ . '/MoniThemeCompat.php';
/**
 * SMM Panel - Header Dosyası
 * Çeviri sistemi ve dil seçici eklenmiş
 */

if (!isset($db)) {
    require_once __DIR__ . '/../config.php';
}
require_once __DIR__ . '/MoniV2Compat.php';

// Aktif dilleri al
$activeLanguages = getLanguages();
$currentLangCode = getCurrentLanguage();

// Mevcut dil bilgisini al
$currentLangInfo = null;
foreach ($activeLanguages as $lang) {
    if ($lang['code'] === $currentLangCode) {
        $currentLangInfo = $lang;
        break;
    }
}

// Sayfa başlığı tanımlı değilse varsayılan kullan
$pageTitle = isset($pageTitle) ? $pageTitle . ' - ' . $siteSettings['name'] : $siteSettings['name'];
?>
<!DOCTYPE html>
<html lang="<?php echo $currentLangCode; ?>" dir="<?php echo function_exists('moni_language_direction') ? moni_language_direction($db, $currentLangCode) : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo clean($siteSettings['description']); ?>">
    <title><?php echo clean($pageTitle); ?></title>
    <?php if(function_exists('moni_pwa_head_tags')) echo moni_pwa_head_tags($db); ?>
    
    <!-- Favicon -->
    <?php if (!empty($siteSettings['favicon'])): ?>
        <link rel="icon" type="image/x-icon" href="<?php echo clean($siteSettings['favicon']); ?>">
        <link rel="shortcut icon" href="<?php echo clean($siteSettings['favicon']); ?>">
        <link rel="apple-touch-icon" href="<?php echo clean($siteSettings['favicon']); ?>">
    <?php else: ?>
        <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>📊</text></svg>">
    <?php endif; ?>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <?php if (!empty($GLOBALS['homepageInterface']) && function_exists('moni_home_head_css')): ?>
    <link rel="stylesheet" href="<?php echo rtrim(SITE_URL,'/'); ?>/assets/css/homepage-interfaces.css?v=<?php echo urlencode(defined('MONI_VERSION') ? MONI_VERSION : 'v2'); ?>">
    <style id="moni-home-interface-vars"><?php echo moni_home_head_css($GLOBALS['homepageInterface']); ?></style>
    <?php endif; ?>

    <!-- Tema CSS Değişkenleri -->
    <style>
        <?php echo generateCSSVariables($activeTheme); ?>
        <?php echo moni_theme_compat_css($activeTheme); ?>
        <?php if (!empty($siteSettings['child_primary_color'])): ?>
        :root{--primary-color:<?php echo clean($siteSettings['child_primary_color']); ?>;--on-primary-color:<?php echo clean($siteSettings['child_on_primary'] ?? '#fff'); ?>;}
        <?php endif; ?>
        
        /* ==================== GENEL STILLER ==================== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--background-color);
            color: var(--text-color);
            line-height: 1.6;
            min-height: 100vh;
        }
        
        a {
            color: var(--accent-text-color);
            text-decoration: none;
            transition: color 0.3s ease;
        }
        
        a:hover {
            color: var(--secondary-text-color);
        }
        
        select option {
            background: var(--card-bg-color);
            color: var(--card-text-color);
        }

        
        html[dir="rtl"] body { direction: rtl; }
        html[dir="rtl"] .header-container, html[dir="rtl"] .nav-menu, html[dir="rtl"] .header-actions { direction: rtl; }
        html[dir="rtl"] .header-container { flex-direction: row-reverse; }
        html[dir="rtl"] .nav-menu { flex-direction: row-reverse; }
        html[dir="rtl"] .dropdown-menu { left: auto; right: 0; text-align: right; }
        html[dir="rtl"] .language-dropdown { left: 0; right: auto; }

        /* ==================== HEADER STILLER ==================== */
        .header {
            background: var(--header-bg-color);
            padding: 0;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
        }
        
        .header-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 70px;
        }
        
        /* Logo Alanı */
        .logo-area {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-shrink: 0;
        }
        
        .logo-area img {
            max-height: 45px;
            width: auto;
            object-fit: contain;
        }
        
        .logo-icon {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--on-accent-color);
            font-size: 20px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        
        .logo-text {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--header-text-color);
            letter-spacing: -0.5px;
        }
        
        .logo-text span {
            color: var(--header-accent-color);
        }
        
        /* Navigasyon */
        .nav-menu {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .nav-link {
            color: var(--header-muted-text-color);
            padding: 10px 18px;
            border-radius: 8px;
            font-weight: 500;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            white-space: nowrap;
        }
        
        .nav-link:hover,
        .nav-link.active {
            background: var(--header-hover-bg);
            color: var(--header-text-color);
        }
        
        .nav-link i {
            font-size: 1rem;
        }
        
        /* Header Butonları */
        .header-actions {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-shrink: 0;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
            text-decoration: none;
            white-space: nowrap;
        }
        
        .btn-primary {
            background: var(--button-color);
            color: var(--button-text-color);
        }
        
        .btn-primary:hover {
            background: var(--button-hover-color);
            color: var(--button-text-color);
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
        }

        /* Public header authentication buttons are intentionally isolated from page-level .btn-* styles. */
        .header-login-btn {
            background: var(--header-hover-bg);
            color: var(--header-text-color);
            border: 1px solid var(--header-border-color);
        }
        .header-login-btn:hover {
            background: var(--header-text-color);
            color: var(--header-bg-color);
            border-color: var(--header-text-color);
            transform: translateY(-1px);
        }
        .header-register-btn {
            background: var(--button-color);
            color: var(--button-text-color);
            border: 1px solid transparent;
        }
        .header-register-btn:hover {
            background: var(--button-hover-color);
            color: var(--button-text-color);
            transform: translateY(-1px);
        }
        
        .btn-outline {
            background: transparent;
            color: var(--header-text-color);
            border: 2px solid var(--header-border-color);
        }
        
        .btn-outline:hover {
            background: var(--header-hover-bg);
            border-color: var(--header-text-color);
            color: var(--header-text-color);
        }
        
        /* ==================== DİL SEÇİCİ ==================== */
        .language-dropdown {
            position: relative;
        }
        
        .language-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 14px;
            background: var(--header-hover-bg);
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
            color: var(--header-text-color);
            font-size: 0.9rem;
            font-weight: 500;
        }
        
        .language-btn:hover {
            background: var(--header-hover-bg);
        }
        
        .language-flag {
            font-size: 1.2rem;
            line-height: 1;
        }
        
        .language-name {
            font-weight: 500;
            font-size: 0.9rem;
        }
        
        .language-dropdown-menu {
            position: absolute;
            top: calc(100% + 8px);
            right: 0;
            background: var(--card-bg-color);
            border-radius: 12px;
            min-width: 160px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.25);
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
            border: 1px solid var(--border-color);
            overflow: hidden;
            z-index: 1001;
        }
        
        .language-dropdown:hover .language-dropdown-menu,
        .language-dropdown.open .language-dropdown-menu {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        
        .language-dropdown-header {
            padding: 12px 15px;
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--text-color);
            opacity: 0.6;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .language-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 15px;
            color: var(--text-color);
            transition: all 0.3s ease;
            cursor: pointer;
            text-decoration: none;
        }
        
        .language-item:hover {
            background: var(--primary-alpha-01);
            color: var(--accent-text-color);
        }
        
        .language-item.active {
            background: var(--primary-color);
            color: var(--on-primary-color);
        }
        
        .language-item.active:hover {
            background: var(--primary-color);
            color: var(--on-primary-color);
        }
        
        .language-item-flag {
            font-size: 1.3rem;
            line-height: 1;
        }
        
        .language-item-name {
            font-weight: 500;
            font-size: 0.9rem;
            flex: 1;
        }
        
        .language-item-check {
            font-size: 0.85rem;
        }
        
        /* Kullanıcı Dropdown */
        .user-dropdown {
            position: relative;
        }
        
        .user-btn {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 15px;
            background: var(--header-hover-bg);
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
            color: var(--header-text-color);
        }
        
        .user-btn:hover {
            background: var(--header-hover-bg);
        }
        
        .user-avatar {
            width: 35px;
            height: 35px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        .dropdown-menu {
            position: absolute;
            top: calc(100% + 10px);
            right: 0;
            background: var(--card-bg-color);
            border-radius: 12px;
            min-width: 200px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
            border: 1px solid var(--border-color);
            overflow: hidden;
        }
        
        .user-dropdown:hover .dropdown-menu {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        
        .dropdown-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 18px;
            color: var(--text-color);
            transition: all 0.3s ease;
        }
        
        .dropdown-item:hover {
            background: var(--primary-color);
            color: var(--on-primary-color);
        }
        
        .dropdown-divider {
            height: 1px;
            background: var(--border-color);
            margin: 5px 0;
        }
        
        /* Mobil Menü Butonu */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: var(--header-text-color);
            font-size: 1.5rem;
            cursor: pointer;
            padding: 10px;
        }
        
        /* Bakiye Göstergesi */
        .balance-display {
            background: var(--header-hover-bg);
            padding: 8px 15px;
            border-radius: 8px;
            font-weight: 600;
            color: var(--header-text-color);
            white-space: nowrap;
        }
        
        .balance-display i {
            color: var(--success-color);
            margin-right: 5px;
        }
        
        /* Alert Stilleri */
        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin: 15px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            animation: slideDown 0.3s ease;
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .alert-success {
            background: rgba(40, 167, 69, 0.15);
            border: 1px solid var(--success-color);
            color: var(--success-color);
        }
        
        .alert-danger {
            background: rgba(220, 53, 69, 0.15);
            border: 1px solid var(--danger-color);
            color: var(--danger-color);
        }
        
        .alert-warning {
            background: rgba(255, 193, 7, 0.15);
            border: 1px solid var(--warning-color);
            color: var(--warning-color);
        }
        
        .alert-info {
            background: rgba(23, 162, 184, 0.15);
            border: 1px solid var(--info-color);
            color: var(--info-color);
        }
        
        .close-alert {
            background: none;
            border: none;
            font-size: 1.2rem;
            cursor: pointer;
            color: inherit;
            opacity: 0.7;
        }
        
        .close-alert:hover {
            opacity: 1;
        }
        
        /* ==================== RESPONSIVE ==================== */
        @media (max-width: 992px) {
            .nav-menu {
                display: none;
                position: absolute;
                top: 70px;
                left: 0;
                right: 0;
                background: var(--header-bg-color);
                flex-direction: column;
                padding: 20px;
                gap: 10px;
                border-top: 1px solid var(--border-color);
                z-index: 999;
            }
            
            .nav-menu.active {
                display: flex;
            }
            
            .mobile-menu-btn {
                display: block;
            }
            
            .header-actions {
                gap: 8px;
            }
            
            .balance-display .balance-text {
                display: none;
            }
            
            .language-name {
                display: none;
            }
            
            .language-btn {
                padding: 8px 10px;
            }
        }
        
        @media (max-width: 768px) {
            .header-container {
                padding: 0 15px;
                height: 65px;
            }
            
            .logo-area img {
                max-height: 38px;
            }
            
            .logo-icon {
                width: 38px;
                height: 38px;
                font-size: 16px;
            }
            
            .logo-text {
                font-size: 1.2rem;
            }
            
            .btn {
                padding: 8px 14px;
                font-size: 0.85rem;
                gap: 6px;
            }
            
            .header-actions {
                gap: 6px;
            }
            
            .user-btn {
                padding: 6px 10px;
            }
            
            .user-avatar {
                width: 32px;
                height: 32px;
                font-size: 0.8rem;
            }
            
            .balance-display {
                padding: 6px 10px;
                font-size: 0.85rem;
            }
        }
        
        @media (max-width: 576px) {
            .header-container {
                padding: 0 10px;
                height: 60px;
            }
            
            .logo-text {
                display: none;
            }
            
            .logo-area img {
                max-height: 35px;
            }
            
            .logo-icon {
                width: 35px;
                height: 35px;
                font-size: 14px;
                border-radius: 10px;
            }
            
            .btn {
                padding: 7px 12px;
                font-size: 0.8rem;
                gap: 5px;
                border-radius: 6px;
            }
            
            .btn i {
                font-size: 0.85rem;
            }
            
            .header-actions {
                gap: 5px;
            }
            
            .language-btn {
                padding: 7px 8px;
            }
            
            .language-flag {
                font-size: 1.1rem;
            }
            
            .language-dropdown-menu {
                right: -20px;
                min-width: 150px;
            }
            
            .mobile-menu-btn {
                padding: 8px;
                font-size: 1.3rem;
            }
            
            .nav-menu {
                top: 60px;
            }
            
            .balance-display {
                padding: 5px 8px;
                font-size: 0.8rem;
            }
            
            .user-btn {
                padding: 5px 8px;
                gap: 6px;
            }
            
            .user-avatar {
                width: 28px;
                height: 28px;
                font-size: 0.75rem;
            }
            
            .user-btn .fa-chevron-down {
                font-size: 0.6rem;
            }
        }
        
        @media (max-width: 400px) {
            .header-container {
                padding: 0 8px;
            }
            
            .btn {
                padding: 6px 10px;
                font-size: 0.75rem;
                gap: 4px;
            }
            
            .btn i {
                font-size: 0.8rem;
            }
            
            .header-actions {
                gap: 4px;
            }
            
            .language-btn {
                padding: 6px;
            }
            
            .language-flag {
                font-size: 1rem;
            }
            
            .language-dropdown-menu {
                right: -30px;
            }
            
            .balance-display {
                display: none;
            }
        }
    </style>
    <link rel="stylesheet" href="/assets/css/theme-compat.css?v=1.3.1">
    <link rel="stylesheet" href="/assets/css/public-pro.css?v=1.3">
</head>
<body<?php echo (!empty($GLOBALS['homepageInterface']) && function_exists('moni_home_body_attrs')) ? moni_home_body_attrs($GLOBALS['homepageInterface']) : ''; ?>>
    <!-- Header -->
    <header class="header">
        <div class="header-container">
            <!-- Logo -->
            <a href="<?php echo SITE_URL; ?>" class="logo-area">
                <?php if (!empty($siteSettings['logo'])): ?>
                    <img src="<?php echo clean($siteSettings['logo']); ?>" alt="<?php echo clean($siteSettings['name']); ?>">
                <?php else: ?>
                    <div class="logo-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="logo-text"><?php echo clean($siteSettings['name']); ?></div>
                <?php endif; ?>
            </a>
            
            <!-- Mobil Menü Butonu -->
            <button class="mobile-menu-btn" onclick="toggleMobileMenu()" aria-label="Menü">
                <i class="fas fa-bars"></i>
            </button>
            
            <!-- Navigasyon -->
            <nav class="nav-menu" id="navMenu">
                <a href="<?php echo SITE_URL; ?>" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' && strpos($_SERVER['REQUEST_URI'], '/kullanici/') === false ? 'active' : ''; ?>">
                    <i class="fas fa-home"></i> <?php echo __('home'); ?>
                </a>
                <a href="<?php echo SITE_URL; ?>/services.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'services.php' ? 'active' : ''; ?>">
                    <i class="fas fa-list"></i> <?php echo __('services'); ?>
                </a>
                <a href="<?php echo SITE_URL; ?>/api.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'api.php' ? 'active' : ''; ?>">
                    <i class="fas fa-plug"></i> API
                </a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="<?php echo SITE_URL; ?>/kullanici/support.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'support.php' ? 'active' : ''; ?>">
                        <i class="fas fa-headset"></i> <?php echo __('contact'); ?>
                    </a>
                <?php endif; ?>
            </nav>
            
            <!-- Header Aksiyonları -->
            <div class="header-actions">
                
                <!-- Dil Seçici -->
                <?php if (count($activeLanguages) > 1): ?>
                <div class="language-dropdown">
                    <button class="language-btn" type="button" aria-label="Dil Seçin">
                        <span class="language-flag"><?php echo $currentLangInfo['flag'] ?? '🌐'; ?></span>
                        <span class="language-name"><?php echo clean($currentLangInfo['name'] ?? 'Dil'); ?></span>
                        <i class="fas fa-chevron-down" style="font-size: 0.7rem; opacity: 0.7;"></i>
                    </button>
                    <div class="language-dropdown-menu">
                        <div class="language-dropdown-header">
                            <i class="fas fa-globe"></i> <?php echo __('select_language'); ?>
                        </div>
                        <?php foreach ($activeLanguages as $lang): ?>
                            <a href="?lang=<?php echo $lang['code']; ?>" class="language-item <?php echo $lang['code'] === $currentLangCode ? 'active' : ''; ?>">
                                <span class="language-item-flag"><?php echo $lang['flag'] ?? '🌐'; ?></span>
                                <span class="language-item-name"><?php echo clean($lang['name']); ?></span>
                                <?php if ($lang['code'] === $currentLangCode): ?>
                                    <span class="language-item-check"><i class="fas fa-check"></i></span>
                                <?php endif; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['user_id'])): ?>
                    <!-- Giriş Yapmış Kullanıcı -->
                    <div class="balance-display">
                        <i class="fas fa-wallet"></i>
                        <span class="balance-text"><?php echo $siteSettings['currency_symbol']; ?><?php echo number_format($_SESSION['balance'] ?? 0, 2); ?></span>
                    </div>
                    
                    <div class="user-dropdown">
                        <button class="user-btn" type="button">
                            <div class="user-avatar">
                                <?php echo strtoupper(substr($_SESSION['username'] ?? 'U', 0, 1)); ?>
                            </div>
                            <i class="fas fa-chevron-down"></i>
                        </button>
                        <div class="dropdown-menu">
                            <a href="<?php echo SITE_URL; ?>/kullanici/" class="dropdown-item">
                                <i class="fas fa-tachometer-alt"></i> <?php echo __('dashboard'); ?>
                            </a>
                            <a href="<?php echo SITE_URL; ?>/kullanici/profile.php" class="dropdown-item">
                                <i class="fas fa-user"></i> <?php echo __('profile'); ?>
                            </a>
                            <a href="<?php echo SITE_URL; ?>/kullanici/add-funds.php" class="dropdown-item">
                                <i class="fas fa-plus-circle"></i> <?php echo __('add_funds'); ?>
                            </a>
                            <?php if(function_exists('moni_plugin_enabled') && moni_plugin_enabled('premium_memberships',$db)): ?>
                            <a href="<?php echo SITE_URL; ?>/kullanici/premium.php" class="dropdown-item">
                                <i class="fas fa-crown"></i> Premium Paketler
                            </a>
                            <?php endif; ?>
                            <a href="<?php echo SITE_URL; ?>/kullanici/support.php" class="dropdown-item">
                                <i class="fas fa-headset"></i> <?php echo __('contact'); ?>
                            </a>
                            <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?>
                                <div class="dropdown-divider"></div>
                                <a href="<?php echo SITE_URL; ?>/admin/" class="dropdown-item">
                                    <i class="fas fa-cog"></i> <?php echo __('admin_panel'); ?>
                                </a>
                            <?php endif; ?>
                            <div class="dropdown-divider"></div>
                            <a href="<?php echo SITE_URL; ?>/logout.php" class="dropdown-item">
                                <i class="fas fa-sign-out-alt"></i> <?php echo __('logout'); ?>
                            </a>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Giriş Yapmamış Kullanıcı -->
                    <a href="<?php echo SITE_URL; ?>/login.php" class="btn header-login-btn">
                        <i class="fas fa-sign-in-alt"></i> <?php echo __('login'); ?>
                    </a>
                    <a href="<?php echo SITE_URL; ?>/register.php" class="btn header-register-btn">
                        <i class="fas fa-user-plus"></i> <?php echo __('register'); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </header>
    
    <!-- Alert Mesajları -->
    <?php echo showAlert(); ?>
    
    <!-- Ana İçerik Başlangıcı -->
    <main class="main-content">
    
    <script>
        // Mobil Menü Toggle
        function toggleMobileMenu() {
            const navMenu = document.getElementById('navMenu');
            const menuBtn = document.querySelector('.mobile-menu-btn i');
            navMenu.classList.toggle('active');
            
            // İkon değiştir
            if (navMenu.classList.contains('active')) {
                menuBtn.classList.remove('fa-bars');
                menuBtn.classList.add('fa-times');
            } else {
                menuBtn.classList.remove('fa-times');
                menuBtn.classList.add('fa-bars');
            }
        }
        
        // Alert Kapatma
        document.querySelectorAll('.close-alert').forEach(btn => {
            btn.addEventListener('click', function() {
                this.parentElement.remove();
            });
        });
        
        // Dil seçici - tıklama ile açılsın (mobil için)
        document.querySelectorAll('.language-dropdown .language-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                this.closest('.language-dropdown').classList.toggle('open');
            });
        });
        
        // Sayfa dışına tıklandığında dropdown kapat
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.language-dropdown')) {
                document.querySelectorAll('.language-dropdown').forEach(d => d.classList.remove('open'));
            }
            
            // Mobil menüyü de kapat
            if (!e.target.closest('.nav-menu') && !e.target.closest('.mobile-menu-btn')) {
                const navMenu = document.getElementById('navMenu');
                const menuBtn = document.querySelector('.mobile-menu-btn i');
                if (navMenu && navMenu.classList.contains('active')) {
                    navMenu.classList.remove('active');
                    if (menuBtn) {
                        menuBtn.classList.remove('fa-times');
                        menuBtn.classList.add('fa-bars');
                    }
                }
            }
        });
    </script>
