<?php
/**
 * Moni Enterprise operations layer.
 * Mass order, customer groups, notifications, audit, provider operations,
 * admin API, payment bonuses, postpaid credit and backup helpers.
 */
if (defined('MONI_ENTERPRISE_LOADED')) return;
define('MONI_ENTERPRISE_LOADED', true);

function moni_json(array $data): string {
    return json_encode($data, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE) ?: '{}';
}
function moni_sql_in(array $ids): array { $ids=array_values(array_unique(array_filter(array_map('intval',$ids),static fn($x)=>$x>0))); if(!$ids)return ['NULL',[]]; return [implode(',',array_fill(0,count($ids),'?')),$ids]; }
function moni_safe_request_meta(array $src): array {
    $out=[];
    foreach($src as $k=>$v){
        $key=strtolower((string)$k);
        if(preg_match('/pass|secret|token|key|csrf|authorization|card|cvv|iban/i',$key)){$out[$k]='***';continue;}
        if(is_array($v)){$out[$k]=array_slice(array_map(static fn($x)=>is_scalar($x)?mb_substr((string)$x,0,500,'UTF-8'):'[...]',$v),0,50);}
        elseif(is_scalar($v))$out[$k]=mb_substr((string)$v,0,2000,'UTF-8');
    }
    return $out;
}

/* ------------------------- Immutable audit chain ------------------------- */
function moni_audit_hmac_key(): string {return hash_hmac('sha256','moni-admin-audit-v2',moni_secret_key(),true);}
function moni_audit_anchor_path(): string {return dirname(dirname(__DIR__)).'/.moni_audit_anchor';}
function moni_audit_anchor_write(int $id,string $rowHash): bool {
    try{
        $data=['id'=>$id,'row_hash'=>$rowHash,'updated_at'=>date(DATE_ATOM)];
        $payload=moni_json($data);$data['mac']=hash_hmac('sha256',$payload,moni_audit_hmac_key());$raw=moni_json($data);
        $path=moni_audit_anchor_path();$dir=dirname($path);if(!is_dir($dir)||!is_writable($dir))return false;
        $tmp=$path.'.tmp-'.bin2hex(random_bytes(4));if(@file_put_contents($tmp,$raw,LOCK_EX)===false)return false;@chmod($tmp,0600);
        if(!@rename($tmp,$path)){@unlink($tmp);return false;}@chmod($path,0600);return true;
    }catch(Throwable $e){error_log('Audit anchor: '.$e->getMessage());return false;}
}
function moni_audit_anchor_read(): ?array {
    try{
        $path=moni_audit_anchor_path();if(!is_file($path))return null;$raw=(string)@file_get_contents($path);$d=json_decode($raw,true);if(!is_array($d)||empty($d['mac']))return null;
        $mac=(string)$d['mac'];unset($d['mac']);$payload=moni_json($d);if(!hash_equals($mac,hash_hmac('sha256',$payload,moni_audit_hmac_key())))return ['invalid'=>true];return $d;
    }catch(Throwable $e){return ['invalid'=>true];}
}
function moni_audit_log(PDO $db,string $action,string $entityType='system',?string $entityId=null,array $metadata=[]): void {
    if(!moni_table_ready($db,'admin_audit_log')||empty($_SESSION['user_id'])||!isAdmin())return;
    try{
        $prev=(string)($db->query("SELECT row_hash FROM admin_audit_log ORDER BY id DESC LIMIT 1")->fetchColumn()?:str_repeat('0',64));
        $created=date('Y-m-d H:i:s');$payload=moni_json($metadata);
        $canonical=implode('|',[$prev,(int)$_SESSION['user_id'],$action,$entityType,(string)$entityId,$payload,moni_client_ip(),$created]);
        $hash=hash_hmac('sha256',$canonical,moni_audit_hmac_key());
        $hasVersion=false;try{$hasVersion=(bool)$db->query("SHOW COLUMNS FROM admin_audit_log LIKE 'hash_version'")->fetch(PDO::FETCH_ASSOC);}catch(Throwable $ignore){}
        if($hasVersion){
            $s=$db->prepare("INSERT INTO admin_audit_log(admin_user_id,action,entity_type,entity_id,metadata_json,ip_address,user_agent,prev_hash,row_hash,hash_version,created_at) VALUES(?,?,?,?,?,?,?,?,?,2,?)");
            $s->execute([(int)$_SESSION['user_id'],$action,$entityType,$entityId,$payload,moni_client_ip(),mb_substr((string)($_SERVER['HTTP_USER_AGENT']??''),0,500,'UTF-8'),$prev,$hash,$created]);
        }else{
            // Şema migration edilemediyse kayıt kaybı yaşatma; legacy hash ile devam et.
            $hash=hash('sha256',$canonical);
            $s=$db->prepare("INSERT INTO admin_audit_log(admin_user_id,action,entity_type,entity_id,metadata_json,ip_address,user_agent,prev_hash,row_hash,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)");
            $s->execute([(int)$_SESSION['user_id'],$action,$entityType,$entityId,$payload,moni_client_ip(),mb_substr((string)($_SERVER['HTTP_USER_AGENT']??''),0,500,'UTF-8'),$prev,$hash,$created]);
        }
        $id=(int)$db->lastInsertId();if($hasVersion&&!moni_audit_anchor_write($id,$hash))error_log('Audit anchor could not be persisted; configure writable private parent directory.');
    }catch(Throwable $e){error_log('Audit log: '.$e->getMessage());}
}
function moni_audit_verify(PDO $db,int $limit=10000): array {
    if(!moni_table_ready($db,'admin_audit_log'))return ['ok'=>false,'checked'=>0,'error'=>'Audit tablosu yok.'];
    try{
        $limit=max(1,min(50000,$limit));$maxId=(int)$db->query("SELECT COALESCE(MAX(id),0) FROM admin_audit_log")->fetchColumn();
        $rows=$db->query("SELECT * FROM admin_audit_log ORDER BY id ASC LIMIT $limit")->fetchAll(PDO::FETCH_ASSOC);
        $prev=str_repeat('0',64);$checked=0;$lastV2=null;$lastCheckedId=0;
        foreach($rows as $r){
            $canonical=implode('|',[$prev,(int)$r['admin_user_id'],$r['action'],$r['entity_type'],(string)$r['entity_id'],$r['metadata_json'],$r['ip_address'],$r['created_at']]);
            $v=(int)($r['hash_version']??1);
            $expected=$v>=2?hash_hmac('sha256',$canonical,moni_audit_hmac_key()):hash('sha256',$canonical);
            if(!hash_equals((string)$r['prev_hash'],$prev)||!hash_equals((string)$r['row_hash'],$expected))return ['ok'=>false,'checked'=>$checked,'broken_id'=>(int)$r['id'],'error'=>'Audit zinciri doğrulanamadı.'];
            if($v>=2)$lastV2=['id'=>(int)$r['id'],'row_hash'=>(string)$r['row_hash']];$lastCheckedId=(int)$r['id'];$prev=(string)$r['row_hash'];$checked++;
        }
        // Harici anchor yalnız zincirin gerçek son satırına kadar doğrulama yapıldıysa karşılaştırılır.
        // Limit nedeniyle kısmi tarama, yanlış "anchor uyuşmuyor" alarmı üretmez.
        if($lastV2 && $lastCheckedId===$maxId){
            $anchor=moni_audit_anchor_read();
            if(!$anchor||!empty($anchor['invalid']))return ['ok'=>false,'checked'=>$checked,'error'=>'Harici audit anchor bulunamadı veya imzası geçersiz.'];
            if((int)($anchor['id']??0)!==$lastV2['id']||!hash_equals((string)($anchor['row_hash']??''),$lastV2['row_hash']))return ['ok'=>false,'checked'=>$checked,'error'=>'Audit günlüğü ile harici anchor uyuşmuyor; silme/değiştirme ihtimali var.'];
        }
        return ['ok'=>true,'checked'=>$checked,'hmac_anchor'=>(bool)($lastV2&&$lastCheckedId===$maxId),'truncated'=>$lastCheckedId<$maxId];
    }catch(Throwable $e){return ['ok'=>false,'checked'=>0,'error'=>$e->getMessage()];}
}
function moni_register_admin_audit_request(PDO $db): void {
    static $registered=false;if($registered||PHP_SAPI==='cli'||empty($_SESSION['user_id'])||!isAdmin()||($_SERVER['REQUEST_METHOD']??'GET')!=='POST')return;$registered=true;
    $route=basename((string)($_SERVER['SCRIPT_NAME']??'admin'));$action=(string)($_POST['action']??$_POST['submit']??$_POST['save']??'post');
    $meta=['route'=>$route,'action'=>$action,'fields'=>moni_safe_request_meta($_POST)];
    register_shutdown_function(static function() use($db,$route,$action,$meta){$meta['http_status']=http_response_code();moni_audit_log($db,'admin.post.'.$action,'route',$route,$meta);});
}

/* ------------------------- User and admin notifications ------------------------- */
function moni_user_notify(PDO $db,int $userId,string $type,string $title,string $message='',?string $url=null,string $severity='info'): int {
    if($userId<=0)return 0;$id=0;
    $inAppAllowed=!function_exists('moni_notification_allowed')||moni_notification_allowed($db,$userId,$type,'in_app');
    if($inAppAllowed&&moni_table_ready($db,'user_notifications')){try{$s=$db->prepare("INSERT INTO user_notifications(user_id,type,title,message,url,severity,created_at) VALUES(?,?,?,?,?,?,NOW())");$s->execute([$userId,mb_substr($type,0,80),mb_substr($title,0,190),mb_substr($message,0,2000),$url?mb_substr($url,0,500):null,in_array($severity,['info','success','warning','danger'],true)?$severity:'info']);$id=(int)$db->lastInsertId();}catch(Throwable $e){$id=0;}}
    if(function_exists('moni_web_push_enqueue')){try{moni_web_push_enqueue($db,$userId,$type,$title,$message,$url);}catch(Throwable $ignore){}}
    return $id;
}
function moni_user_unread_notifications(PDO $db,int $userId): int {if(!moni_table_ready($db,'user_notifications'))return 0;try{$s=$db->prepare("SELECT COUNT(*) FROM user_notifications WHERE user_id=? AND read_at IS NULL");$s->execute([$userId]);return (int)$s->fetchColumn();}catch(Throwable $e){return 0;}}
function moni_user_unread_count(PDO $db,int $userId): int {if(!moni_table_ready($db,'user_notifications'))return 0;try{$s=$db->prepare("SELECT COUNT(*) FROM user_notifications WHERE user_id=? AND read_at IS NULL");$s->execute([$userId]);return (int)$s->fetchColumn();}catch(Throwable $e){return 0;}}
function moni_admin_unread_count(PDO $db,int $adminId): int {
    if(!moni_table_ready($db,'admin_notifications'))return 0;
    try{$s=$db->prepare("SELECT COUNT(*) FROM admin_notifications n LEFT JOIN admin_notification_reads r ON r.notification_id=n.id AND r.admin_user_id=? WHERE r.notification_id IS NULL");$s->execute([$adminId]);return (int)$s->fetchColumn();}catch(Throwable $e){return 0;}
}
function moni_admin_notify(PDO $db,string $type,string $title,string $message='',?string $url=null,string $severity='info',bool $telegram=true): int {
    if(!moni_table_ready($db,'admin_notifications'))return 0;
    try{$s=$db->prepare("INSERT INTO admin_notifications(type,title,message,url,severity,created_at) VALUES(?,?,?,?,?,NOW())");$s->execute([mb_substr($type,0,80),mb_substr($title,0,190),mb_substr($message,0,2500),$url?mb_substr($url,0,500):null,in_array($severity,['info','success','warning','danger'],true)?$severity:'info']);$id=(int)$db->lastInsertId();if($telegram)moni_telegram_send($db,"🔔 <b>".htmlspecialchars($title,ENT_QUOTES,'UTF-8')."</b>\n".htmlspecialchars($message,ENT_QUOTES,'UTF-8'));return $id;}catch(Throwable $e){return 0;}
}

/* ------------------------- Telegram operations ------------------------- */
function moni_telegram_send(PDO $db,string $html): bool {
    if((string)getSetting('telegram_ops_enabled','0')!=='1'||!function_exists('curl_init'))return false;
    $token=moni_decrypt_secret((string)getSetting('telegram_ops_bot_token',''));$chatIds=preg_split('/[\s,;]+/',trim((string)getSetting('telegram_ops_chat_ids','')), -1, PREG_SPLIT_NO_EMPTY);
    if($token===''||!$chatIds)return false;$ok=false;
    foreach(array_slice($chatIds,0,20) as $chat){
        $url='https://api.telegram.org/bot'.rawurlencode($token).'/sendMessage';
        $ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>['chat_id'=>$chat,'text'=>$html,'parse_mode'=>'HTML','disable_web_page_preview'=>'true'],CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>12,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_FOLLOWLOCATION=>false]);$raw=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);if($http>=200&&$http<300&&strpos((string)$raw,'"ok":true')!==false)$ok=true;
    }
    return $ok;
}

/* ------------------------- Email templates ------------------------- */
function moni_email_template(PDO $db,string $slug,array $vars=[]): ?array {
    if(!moni_table_ready($db,'email_templates'))return null;
    try{$s=$db->prepare("SELECT * FROM email_templates WHERE slug=? AND is_active=1 LIMIT 1");$s->execute([$slug]);$t=$s->fetch(PDO::FETCH_ASSOC);if(!$t)return null;$replace=[];foreach($vars as $k=>$v)$replace['{{'.$k.'}}']=(string)$v;$replace['{{site_name}}']=$GLOBALS['siteSettings']['name']??getSetting('site_name','SMM Panel');$replace['{{site_url}}']=defined('SITE_URL')?SITE_URL:'';$t['subject']=strtr((string)$t['subject'],$replace);$t['body_html']=strtr((string)$t['body_html'],$replace);return $t;}catch(Throwable $e){return null;}
}
function moni_send_template_email(PDO $db,string $slug,string $to,array $vars=[]): bool {
    // Bildirim tercihi yalnız gerçek bildirim e-postalarına uygulanır; parola sıfırlama/doğrulama gibi kullanıcı tarafından istenen güvenlik e-postaları engellenmez.
    $prefType=['order_status'=>'orders','order_confirmation'=>'orders','payment_approved'=>'payments','balance_added'=>'payments','support_reply'=>'support','support_update'=>'support'][$slug]??null;
    if($prefType&&function_exists('moni_notification_allowed')){try{$uq=$db->prepare("SELECT id FROM users WHERE email=? LIMIT 1");$uq->execute([$to]);$uid=(int)$uq->fetchColumn();if($uid&&!moni_notification_allowed($db,$uid,$prefType,'email'))return true;}catch(Throwable $ignore){}}
    $t=moni_email_template($db,$slug,$vars);if(!$t)return false;$mail=__DIR__.'/mail.php';if(!function_exists('sendEmail')&&is_file($mail))require_once $mail;if(!function_exists('sendEmail'))return false;$r=sendEmail($to,$t['subject'],$t['body_html']);return $r===true||(is_array($r)&&!empty($r['success']));
}

/* ------------------------- Customer groups / levels ------------------------- */
function moni_customer_group(PDO $db,int $userId): ?array {
    if(!moni_table_ready($db,'customer_groups'))return null;
    try{$s=$db->prepare("SELECT g.* FROM users u LEFT JOIN customer_groups g ON g.id=u.customer_group_id AND g.is_active=1 WHERE u.id=? LIMIT 1");$s->execute([$userId]);$r=$s->fetch(PDO::FETCH_ASSOC);return $r&&$r['id']?$r:null;}catch(Throwable $e){return null;}
}
function moni_recalculate_customer_group(PDO $db,int $userId): ?int {
    if(!moni_table_ready($db,'customer_groups'))return null;
    try{$u=$db->prepare("SELECT spent,customer_group_id FROM users WHERE id=?");$u->execute([$userId]);$row=$u->fetch(PDO::FETCH_ASSOC);if(!$row)return null;$spent=(float)$row['spent'];$s=$db->prepare("SELECT id FROM customer_groups WHERE is_active=1 AND auto_upgrade=1 AND min_spent<=? ORDER BY priority DESC,min_spent DESC,id DESC LIMIT 1");$s->execute([$spent]);$gid=$s->fetchColumn();$gid=$gid!==false?(int)$gid:null;if((int)($row['customer_group_id']??0)!==(int)($gid??0)){$db->prepare("UPDATE users SET customer_group_id=? WHERE id=?")->execute([$gid,$userId]);moni_user_notify($db,$userId,'level','Müşteri seviyeniz güncellendi',$gid?'Yeni müşteri grubunuz hesabınıza uygulandı.':'Varsayılan müşteri seviyesine geçtiniz.','/kullanici/profile.php','success');}return $gid;}catch(Throwable $e){return null;}
}
function moni_group_price(PDO $db,int $userId,float $price): float {$g=moni_customer_group($db,$userId);if(!$g)return $price;$discount=max(0,min(95,(float)($g['discount_percent']??0)));return round($price*(1-$discount/100),4);}
function moni_service_visible_to_user(PDO $db,int $serviceId,int $userId): bool {
    if(function_exists('moni_premium_service_visible_to_user') && !moni_premium_service_visible_to_user($db,$serviceId,$userId))return false;
    if(!moni_table_ready($db,'group_service_visibility'))return true;
    $g=moni_customer_group($db,$userId);$gid=(int)($g['id']??0);
    try{
        $has=(int)$db->query("SELECT COUNT(*) FROM group_service_visibility WHERE service_id=".(int)$serviceId)->fetchColumn();if(!$has)return true;
        if($gid<=0)return false;
        $s=$db->prepare("SELECT is_visible FROM group_service_visibility WHERE service_id=? AND customer_group_id=? LIMIT 1");$s->execute([$serviceId,$gid]);$v=$s->fetchColumn();return $v!==false&&(int)$v===1;
    }catch(Throwable $e){return true;}
}

/* ------------------------- Postpaid credit ------------------------- */
function moni_user_credit_limit(PDO $db,int $userId): float {try{$s=$db->prepare("SELECT credit_limit FROM users WHERE id=?");$s->execute([$userId]);return max(0,(float)$s->fetchColumn());}catch(Throwable $e){return 0;}}
function moni_user_available_funds(PDO $db,int $userId): float {try{$s=$db->prepare("SELECT balance,credit_limit FROM users WHERE id=?");$s->execute([$userId]);$u=$s->fetch(PDO::FETCH_ASSOC);return $u?((float)$u['balance']+max(0,(float)($u['credit_limit']??0))):0;}catch(Throwable $e){return 0;}}
function moni_debit_user(PDO $db,int $userId,float $amount,bool $increaseSpent=true): bool {
    $amount=round(max(0,$amount),4);if($amount<=0)return true;
    $sql="UPDATE users SET balance=balance-?".($increaseSpent?',spent=spent+?':'')." WHERE id=? AND status='active' AND (balance + COALESCE(credit_limit,0))>=?";
    $args=$increaseSpent?[$amount,$amount,$userId,$amount]:[$amount,$userId,$amount];$s=$db->prepare($sql);$s->execute($args);$ok=$s->rowCount()>0;if($ok&&function_exists('moni_postpaid_after_debit'))moni_postpaid_after_debit($db,$userId);return $ok;
}

/* ------------------------- Payment method bonuses ------------------------- */
function moni_payment_bonus_quote(PDO $db,int $paymentMethodId,float $baseAmount): array {
    $bonus=0.0;$label='Ödeme yöntemi bonusu';
    if(moni_table_ready($db,'payment_method_bonuses')){try{$s=$db->prepare("SELECT * FROM payment_method_bonuses WHERE payment_method_id=? AND is_active=1 AND (starts_at IS NULL OR starts_at<=NOW()) AND (ends_at IS NULL OR ends_at>=NOW()) LIMIT 1");$s->execute([$paymentMethodId]);$r=$s->fetch(PDO::FETCH_ASSOC);if($r){$bonus=$r['bonus_type']==='fixed'?(float)$r['bonus_value']:$baseAmount*(float)$r['bonus_value']/100;$bonus=max(0,$bonus);if((float)$r['max_bonus']>0)$bonus=min($bonus,(float)$r['max_bonus']);$label=$r['label']?:$label;}}catch(Throwable $e){}}
    return ['base'=>round($baseAmount,4),'bonus'=>round($bonus,4),'credit'=>round($baseAmount+$bonus,4),'label'=>$label];
}

/* ------------------------- Mass order ------------------------- */
function moni_parse_mass_order_lines(string $raw): array {
    $rows=[];$errors=[];$lineNo=0;
    foreach(preg_split('/\R/u',$raw) as $line){$lineNo++;$line=trim($line);if($line==='')continue;$parts=preg_split('/\s*[|;]\s*/',$line,3);if(count($parts)<3)$parts=preg_split('/\s+/', $line,3);if(count($parts)<3){$errors[]="$lineNo. satır: servis | link | miktar formatı bekleniyor.";continue;}$sid=(int)$parts[0];$link=trim($parts[1]);$qty=(int)$parts[2];if($sid<=0||$link===''||$qty<=0){$errors[]="$lineNo. satır geçersiz.";continue;}$rows[]=['line'=>$lineNo,'service_id'=>$sid,'link'=>$link,'quantity'=>$qty];}
    if(count($rows)>250)$errors[]='Tek işlemde en fazla 250 sipariş verilebilir.';return ['rows'=>array_slice($rows,0,250),'errors'=>$errors];
}
function moni_mass_order_validate(PDO $db,int $userId,array $rows): array {
    $errors=[];$total=0.0;$prepared=[];
    foreach($rows as $r){$s=$db->prepare("SELECT * FROM services WHERE id=? AND status='active' AND deleted_at IS NULL LIMIT 1");$s->execute([$r['service_id']]);$srv=$s->fetch(PDO::FETCH_ASSOC);if(!$srv){$errors[]=$r['line'].'. satır: servis bulunamadı.';continue;}if(!moni_service_visible_to_user($db,(int)$srv['id'],$userId)){$errors[]=$r['line'].'. satır: servis hesabınıza açık değil.';continue;}$inc=max(1,(int)($srv['quantity_increment']??1));if($r['quantity']<(int)$srv['min_quantity']||$r['quantity']>(int)$srv['max_quantity']){$errors[]=$r['line'].'. satır: miktar min/max dışında.';continue;}if($r['quantity']%$inc!==0){$errors[]=$r['line'].'. satır: miktar '.$inc.' katı olmalı.';continue;}if(!filter_var($r['link'],FILTER_VALIDATE_URL)){$errors[]=$r['line'].'. satır: bağlantı geçersiz.';continue;}$rate=function_exists('moni_effective_price_for_quantity')?moni_effective_price_for_quantity($srv,$userId,(int)$r['quantity']):moni_effective_price_per_1000($srv,$userId);$price=round($r['quantity']/1000*$rate,4);$total+=$price;$prepared[]=$r+['price'=>$price,'service_name'=>$srv['name']];}
    if($total>moni_user_available_funds($db,$userId)+0.00001)$errors[]='Toplu sipariş toplamı kullanılabilir bakiye/kredi limitinizi aşıyor.';return ['ok'=>!$errors,'errors'=>$errors,'rows'=>$prepared,'total'=>round($total,4)];
}
function moni_execute_mass_order(PDO $db,int $userId,array $rows): array {
    $v=moni_mass_order_validate($db,$userId,$rows);if(empty($v['ok']))return ['success'=>false,'errors'=>$v['errors']];
    if(!moni_table_ready($db,'mass_orders'))return ['success'=>false,'errors'=>['Mass order veritabanı hazırlanmadı.']];
    $db->prepare("INSERT INTO mass_orders(user_id,line_count,total_price,status,created_at) VALUES(?,?,?,'processing',NOW())")->execute([$userId,count($v['rows']),$v['total']]);$mid=(int)$db->lastInsertId();$ok=0;$fail=0;$ids=[];
    foreach($v['rows'] as $r){$res=moni_place_order($db,$userId,(int)$r['service_id'],$r['link'],(int)$r['quantity'],['source'=>'mass_order','idempotency_key'=>'mass:'.$mid.':'.$r['line']]);$status=!empty($res['success'])?'ordered':'error';if($status==='ordered'){$ok++;$ids[]=(int)($res['order_id']??0);}else$fail++;$db->prepare("INSERT INTO mass_order_items(mass_order_id,line_no,service_id,link,quantity,price,order_id,status,error_message) VALUES(?,?,?,?,?,?,?,?,?)")->execute([$mid,$r['line'],$r['service_id'],$r['link'],$r['quantity'],$r['price'],$res['order_id']??null,$status,$res['error']??null]);}
    $status=$fail===0?'completed':($ok>0?'partial':'error');$db->prepare("UPDATE mass_orders SET status=?,success_count=?,failure_count=?,updated_at=NOW() WHERE id=?")->execute([$status,$ok,$fail,$mid]);moni_user_notify($db,$userId,'mass_order','Toplu sipariş işlendi',"$ok sipariş oluşturuldu, $fail satır başarısız.",'/kullanici/orders.php',$fail?'warning':'success');return ['success'=>$ok>0,'mass_order_id'=>$mid,'success_count'=>$ok,'failure_count'=>$fail,'order_ids'=>$ids,'total'=>$v['total']];
}

/* ------------------------- Service trash ------------------------- */
function moni_soft_delete_service(PDO $db,int $serviceId,int $adminId): bool {
    $s=$db->prepare("SELECT * FROM services WHERE id=? LIMIT 1");$s->execute([$serviceId]);$row=$s->fetch(PDO::FETCH_ASSOC);if(!$row)return false;
    if(moni_table_ready($db,'service_trash'))$db->prepare("INSERT INTO service_trash(service_id,snapshot_json,deleted_by,deleted_at) VALUES(?,?,?,NOW()) ON DUPLICATE KEY UPDATE snapshot_json=VALUES(snapshot_json),deleted_by=VALUES(deleted_by),deleted_at=NOW(),restored_at=NULL")->execute([$serviceId,moni_json($row),$adminId]);
    $u=$db->prepare("UPDATE services SET status='inactive',deleted_at=NOW(),deleted_by=? WHERE id=?");$u->execute([$adminId,$serviceId]);return $u->rowCount()>0;
}
function moni_restore_service(PDO $db,int $serviceId): bool {$s=$db->prepare("UPDATE services SET deleted_at=NULL,deleted_by=NULL,status='active' WHERE id=? AND deleted_at IS NOT NULL");$s->execute([$serviceId]);if($s->rowCount()&&moni_table_ready($db,'service_trash'))$db->prepare("UPDATE service_trash SET restored_at=NOW() WHERE service_id=?")->execute([$serviceId]);return $s->rowCount()>0;}

/* ------------------------- Service bundles ------------------------- */
function moni_bundle_quote(PDO $db,int $bundleId,int $userId): array {
    if(!moni_table_ready($db,'service_bundles'))return ['ok'=>false,'error'=>'Paket sistemi hazır değil.'];
    $s=$db->prepare("SELECT * FROM service_bundles WHERE id=? AND is_active=1");$s->execute([$bundleId]);$b=$s->fetch(PDO::FETCH_ASSOC);if(!$b)return ['ok'=>false,'error'=>'Paket bulunamadı.'];$q=$db->prepare("SELECT bi.*,s.name,s.price_per_1000,s.category_id,s.cost_per_1000,s.min_quantity,s.max_quantity,s.status,s.deleted_at FROM service_bundle_items bi JOIN services s ON s.id=bi.service_id WHERE bi.bundle_id=? ORDER BY bi.sort_order,bi.id");$q->execute([$bundleId]);$items=[];$sum=0;foreach($q->fetchAll(PDO::FETCH_ASSOC) as $i){if($i['status']!=='active'||$i['deleted_at']!==null||!moni_service_visible_to_user($db,(int)$i['service_id'],$userId))continue;$tierRate=function_exists('moni_effective_price_for_quantity')?moni_effective_price_for_quantity($i,$userId,(int)$i['quantity']):moni_effective_price_per_1000($i,$userId);$p=$tierRate*(int)$i['quantity']/1000;$sum+=$p;$i['line_price']=round($p,4);$items[]=$i;}$discount=max(0,min(95,(float)$b['discount_percent']));$total=round($sum*(1-$discount/100),4);return ['ok'=>true,'bundle'=>$b,'items'=>$items,'subtotal'=>round($sum,4),'total'=>$total];
}
function moni_place_bundle(PDO $db,int $bundleId,int $userId,array $links): array {
    $q=moni_bundle_quote($db,$bundleId,$userId);if(empty($q['ok'])||!$q['items'])return ['success'=>false,'error'=>$q['error']??'Pakette aktif servis bulunamadı.'];
    if(moni_user_available_funds($db,$userId)+0.00001<$q['total'])return ['success'=>false,'error'=>'Yetersiz bakiye / kredi limiti.'];
    $db->prepare("INSERT INTO bundle_orders(bundle_id,user_id,total_price,status,created_at) VALUES(?,?,?,'processing',NOW())")->execute([$bundleId,$userId,0]);$bid=(int)$db->lastInsertId();
    $success=0;$failure=0;$charged=0.0;$discount=max(0,min(95,(float)($q['bundle']['discount_percent']??0)));$grossSuccess=0.0;
    foreach($q['items'] as $i){
        $link=trim((string)($links[(int)$i['id']]??''));
        if($link===''){$failure++;$db->prepare("INSERT INTO bundle_order_items(bundle_order_id,bundle_item_id,status,error_message) VALUES(?,?,'error','Bağlantı eksik')")->execute([$bid,$i['id']]);continue;}
        $gross=round((float)($i['line_price']??0),4);$lineNet=round($gross*(1-$discount/100),4);
        $res=moni_place_order($db,$userId,(int)$i['service_id'],$link,(int)$i['quantity'],['source'=>'bundle','bundle_price'=>$lineNet,'idempotency_key'=>'bundle:'.$bid.':'.$i['id']]);
        if(!empty($res['success'])){$success++;$charged+=(float)($res['price']??$lineNet);$grossSuccess+=$gross;$db->prepare("INSERT INTO bundle_order_items(bundle_order_id,bundle_item_id,order_id,status) VALUES(?,?,?,'ordered')")->execute([$bid,$i['id'],$res['order_id']??null]);}
        else{$failure++;$db->prepare("INSERT INTO bundle_order_items(bundle_order_id,bundle_item_id,status,error_message) VALUES(?,?,'error',?)")->execute([$bid,$i['id'],mb_substr((string)($res['error']??'Sipariş başarısız'),0,1000)]);}
    }
    $discountAmount=round(max(0,$grossSuccess-$charged),4);$net=round($charged,4);
    $status=$failure===0?'completed':($success?'partial':'error');
    $db->prepare("UPDATE bundle_orders SET total_price=?,status=?,success_count=?,failure_count=?,updated_at=NOW() WHERE id=?")->execute([$net,$status,$success,$failure,$bid]);
    if($success)moni_user_notify($db,$userId,'bundle','Servis paketiniz işlendi',$success.' servis siparişi oluşturuldu'.($discountAmount>0?', indirim sipariş anında uygulandı.':'.'),'/kullanici/orders.php',$failure?'warning':'success');
    return ['success'=>$success>0,'bundle_order_id'=>$bid,'success_count'=>$success,'failure_count'=>$failure,'charged'=>$grossSuccess,'discount'=>$discountAmount,'total'=>$net];
}

/* ------------------------- Cancel queue ------------------------- */
function moni_queue_cancel(PDO $db,int $orderId,int $requestedBy,?int $userId=null,string $reason='Sipariş iptal talebi'): array {
    if(!moni_table_ready($db,'cancel_jobs'))return ['success'=>false,'error'=>'İptal kuyruğu hazır değil.'];
    try{$s=$db->prepare("INSERT INTO cancel_jobs(order_id,user_id,requested_by,reason,status,next_attempt_at,created_at) VALUES(?,?,?,?, 'queued',NOW(),NOW()) ON DUPLICATE KEY UPDATE reason=VALUES(reason),status=IF(status IN('completed','processing'),status,'queued'),next_attempt_at=IF(status IN('completed','processing'),next_attempt_at,NOW()),updated_at=NOW()");$s->execute([$orderId,$userId,$requestedBy,mb_substr($reason,0,500)]);return ['success'=>true,'queued'=>true];}catch(Throwable $e){return ['success'=>false,'error'=>$e->getMessage()];}
}
function moni_process_cancel_queue(PDO $db,int $batch=50): array {
    if(!moni_table_ready($db,'cancel_jobs'))return ['processed'=>0,'message'=>'Cancel kuyruğu yok.'];
    $rows=$db->query("SELECT * FROM cancel_jobs WHERE status IN('queued','retry') AND (next_attempt_at IS NULL OR next_attempt_at<=NOW()) ORDER BY id LIMIT ".max(1,min(500,$batch)))->fetchAll(PDO::FETCH_ASSOC);
    $n=0;$ok=0;
    foreach($rows as $j){
        $claim=$db->prepare("UPDATE cancel_jobs SET status='processing',attempts=attempts+1,updated_at=NOW() WHERE id=? AND status IN('queued','retry')");
        $claim->execute([$j['id']]);
        if(!$claim->rowCount())continue;
        try{
            $o=$db->prepare("SELECT o.*,s.cancel service_cancel FROM orders o LEFT JOIN services s ON s.id=o.service_id WHERE o.id=?");
            $o->execute([$j['order_id']]);
            $order=$o->fetch(PDO::FETCH_ASSOC);
            if(!$order)throw new RuntimeException('Sipariş bulunamadı.');

            if(in_array($order['status'],['cancelled','refunded'],true)){
                $result=['success'=>true,'already'=>true];
            }else{
                if(!(int)$order['service_cancel'])throw new RuntimeException('Servis iptal desteklemiyor.');

                if(!empty($order['api_order_id'])&&!empty($order['api_provider_id'])){
                    $providerConfirmed=false;
                    $cancelAlreadyRequested=str_starts_with((string)($j['last_error']??''),'CANCEL_PENDING_CONFIRMATION:');
                    $before=moni_provider_status($db,$order);
                    if(!empty($before['success'])&&in_array($before['status']??'',['cancelled','refunded'],true)){
                        $providerConfirmed=true;
                    }
                    if(!$providerConfirmed&&!$cancelAlreadyRequested){
                        $c=moni_provider_cancel($db,$order);
                        if(empty($c['success']))throw new RuntimeException($c['error']??'Sağlayıcı iptali reddetti.');
                        $providerConfirmed=!empty($c['confirmed']);
                        if(!$providerConfirmed){
                            $after=moni_provider_status($db,$order);
                            if(!empty($after['success'])&&in_array($after['status']??'',['cancelled','refunded'],true)){
                                $providerConfirmed=true;
                            }
                        }
                    }
                    if(!$providerConfirmed){
                        throw new RuntimeException('CANCEL_PENDING_CONFIRMATION: Sağlayıcı iptal talebini aldı; kesin iptal durumu doğrulanana kadar iade bekletiliyor.');
                    }
                }

                $rr=moni_refund_order($db,(int)$order['id'],(float)$order['price'],$j['reason'],'cancelled');
                if(empty($rr['ok']))throw new RuntimeException($rr['error']??'İade uygulanamadı.');
                $result=['success'=>true];
            }

            $db->prepare("UPDATE cancel_jobs SET status='completed',completed_at=NOW(),last_error=NULL,updated_at=NOW() WHERE id=?")->execute([$j['id']]);
            if(!empty($j['user_id']))moni_user_notify($db,(int)$j['user_id'],'order_cancel','Sipariş iptal edildi','#'.$j['order_id'].' numaralı sipariş iptal edilerek iade işlendi.','/kullanici/orders.php','success');
            $ok++;
        }catch(Throwable $e){
            $attempt=(int)$j['attempts']+1;
            $status=$attempt>=5?'failed':'retry';
            $minutes=min(120,(int)pow(2,min(6,$attempt))*2);
            $db->prepare("UPDATE cancel_jobs SET status=?,last_error=?,next_attempt_at=DATE_ADD(NOW(),INTERVAL ? MINUTE),updated_at=NOW() WHERE id=?")
               ->execute([$status,mb_substr($e->getMessage(),0,1000),$minutes,$j['id']]);
            if($status==='failed')moni_admin_notify($db,'cancel_failed','Sipariş iptali başarısız','#'.$j['order_id'].' iptal kuyruğu 5 denemede tamamlanamadı.','/admin/orders.php?search='.$j['order_id'],'danger');
        }
        $n++;
    }
    return ['processed'=>$n,'message'=>"$n iptal işi işlendi; $ok başarılı."];
}

/* ------------------------- Provider request/sync logging ------------------------- */
function moni_log_provider_request(PDO $db,int $providerId,string $operation,array $request,$response,int $http,int $latency,bool $success,?string $error=null): void {
    if(!moni_table_ready($db,'provider_request_logs'))return;$request=moni_safe_request_meta($request);$resp=is_string($response)?$response:moni_json((array)$response);$resp=mb_substr($resp,0,30000,'UTF-8');try{$db->prepare("INSERT INTO provider_request_logs(provider_id,operation,request_json,response_body,http_code,latency_ms,is_success,error_message,created_at) VALUES(?,?,?,?,?,?,?,?,NOW())")->execute([$providerId,$operation,moni_json($request),$resp,$http,$latency,$success?1:0,$error?mb_substr($error,0,1000):null]);}catch(Throwable $e){}
}
function moni_log_provider_sync(PDO $db,int $providerId,array $before,array $after,string $remoteId): void {
    if(!moni_table_ready($db,'provider_sync_log_items'))return;$changes=[];foreach(['cost_per_1000','min_quantity','max_quantity','status','description'] as $f){$a=(string)($before[$f]??'');$b=(string)($after[$f]??'');if($a!==$b)$changes[$f]=['old'=>$a,'new'=>$b];}if(!$changes)return;try{$runId=(int)($GLOBALS['MONI_PROVIDER_SYNC_RUN_ID']??0);if($runId<=0){$db->prepare("INSERT INTO provider_sync_logs(provider_id,status,started_at,created_at) VALUES(?,'running',NOW(),NOW())")->execute([$providerId]);$runId=(int)$db->lastInsertId();$GLOBALS['MONI_PROVIDER_SYNC_RUN_ID']=$runId;}$db->prepare("INSERT INTO provider_sync_log_items(sync_log_id,service_id,remote_service_id,changes_json,created_at) VALUES(?,?,?,?,NOW())")->execute([$runId,$before['id']??null,$remoteId,moni_json($changes)]);}catch(Throwable $e){}
}
function moni_finish_provider_sync_log(PDO $db,int $providerId,int $processed,string $status='success',?string $message=null): void {try{$id=(int)($GLOBALS['MONI_PROVIDER_SYNC_RUN_ID']??0);if($id>0)$db->prepare("UPDATE provider_sync_logs SET status=?,processed_count=?,message=?,finished_at=NOW() WHERE id=?")->execute([$status,$processed,$message,$id]);unset($GLOBALS['MONI_PROVIDER_SYNC_RUN_ID']);}catch(Throwable $e){}}

/* ------------------------- Provider reconciliation ------------------------- */
function moni_snapshot_provider_balance(PDO $db,int $providerId,float $balance,string $currency): void {if(!moni_table_ready($db,'provider_balance_snapshots'))return;try{$db->prepare("INSERT INTO provider_balance_snapshots(provider_id,balance,currency_code,captured_at) VALUES(?,?,?,NOW())")->execute([$providerId,$balance,strtoupper($currency)]);}catch(Throwable $e){}}
function moni_provider_reconcile(PDO $db,int $providerId,string $date): array {
    $d=DateTime::createFromFormat('Y-m-d',$date);if(!$d)return ['ok'=>false,'error'=>'Tarih geçersiz.'];$start=$d->format('Y-m-d 00:00:00');$end=$d->modify('+1 day')->format('Y-m-d 00:00:00');
    try{$p=$db->prepare("SELECT * FROM api_providers WHERE id=?");$p->execute([$providerId]);$provider=$p->fetch(PDO::FETCH_ASSOC);if(!$provider)return ['ok'=>false,'error'=>'Sağlayıcı bulunamadı.'];$c=$db->prepare("SELECT COALESCE(SUM(fs.expected_cost),0) FROM order_financial_snapshots fs JOIN orders o ON o.id=fs.order_id WHERE o.api_provider_id=? AND o.created_at>=? AND o.created_at<?");$c->execute([$providerId,$start,$end]);$expected=(float)$c->fetchColumn();$open=$db->prepare("SELECT balance FROM provider_balance_snapshots WHERE provider_id=? AND captured_at>=? ORDER BY captured_at ASC LIMIT 1");$open->execute([$providerId,$start]);$opening=$open->fetchColumn();$close=$db->prepare("SELECT balance FROM provider_balance_snapshots WHERE provider_id=? AND captured_at<? ORDER BY captured_at DESC LIMIT 1");$close->execute([$providerId,$end]);$closing=$close->fetchColumn();$actual=($opening!==false&&$closing!==false)?max(0,(float)$opening-(float)$closing):null;$variance=$actual===null?null:$actual-$expected;$db->prepare("INSERT INTO provider_reconciliations(provider_id,reconcile_date,currency_code,opening_balance,closing_balance,expected_cost,actual_spend,variance,status,created_at) VALUES(?,?,?,?,?,?,?,?,'draft',NOW()) ON DUPLICATE KEY UPDATE opening_balance=VALUES(opening_balance),closing_balance=VALUES(closing_balance),expected_cost=VALUES(expected_cost),actual_spend=VALUES(actual_spend),variance=VALUES(variance),updated_at=NOW()")->execute([$providerId,$date,$provider['currency']??'USD',$opening===false?null:$opening,$closing===false?null:$closing,$expected,$actual,$variance]);return ['ok'=>true,'expected'=>$expected,'actual'=>$actual,'variance'=>$variance];}catch(Throwable $e){return ['ok'=>false,'error'=>$e->getMessage()];}
}

/* ------------------------- Admin API ------------------------- */
function moni_admin_api_auth(PDO $db): ?array {
    if(!moni_table_ready($db,'admin_api_tokens'))return null;$header=$_SERVER['HTTP_AUTHORIZATION']??$_SERVER['REDIRECT_HTTP_AUTHORIZATION']??'';if(!preg_match('/^Bearer\s+(.+)$/i',$header,$m))return null;$plain=trim($m[1]);$hash=hash('sha256',$plain);try{$s=$db->prepare("SELECT * FROM admin_api_tokens WHERE token_hash=? AND is_active=1 AND (expires_at IS NULL OR expires_at>NOW()) LIMIT 1");$s->execute([$hash]);$t=$s->fetch(PDO::FETCH_ASSOC);if(!$t)return null;$ips=array_filter(array_map('trim',preg_split('/[\r\n,]+/',(string)($t['allowed_ips']??''))));if($ips&&!in_array(moni_client_ip(),$ips,true))return null;$db->prepare("UPDATE admin_api_tokens SET last_used_at=NOW(),last_ip=? WHERE id=?")->execute([moni_client_ip(),$t['id']]);return $t;}catch(Throwable $e){return null;}
}
function moni_admin_api_scope(array $token,string $scope): bool {$scopes=array_filter(array_map('trim',explode(',',(string)($token['scopes']??''))));return in_array('*',$scopes,true)||in_array($scope,$scopes,true);}

/* ------------------------- Time zone ------------------------- */
function moni_valid_timezone(string $tz): bool {return in_array($tz,timezone_identifiers_list(),true);}
function moni_user_timezone(PDO $db,int $userId): string {try{$s=$db->prepare("SELECT timezone FROM users WHERE id=?");$s->execute([$userId]);$tz=(string)$s->fetchColumn();return moni_valid_timezone($tz)?$tz:(string)getSetting('timezone','Europe/Istanbul');}catch(Throwable $e){return 'Europe/Istanbul';}}
function moni_format_user_time(PDO $db,int $userId,?string $datetime,string $format='d.m.Y H:i'): string {if(!$datetime)return '-';try{$d=new DateTime($datetime,new DateTimeZone((string)getSetting('timezone','Europe/Istanbul')));$d->setTimezone(new DateTimeZone(moni_user_timezone($db,$userId)));return $d->format($format);}catch(Throwable $e){return (string)$datetime;}}

/* ------------------------- Backup / restore ------------------------- */
function moni_backup_dir(): string {
    $root=dirname(dirname(__DIR__));
    $configured=trim((string)getenv('MONI_PRIVATE_DIR'));
    $base=$configured!==''?$configured:($root.'/moni-private');
    $private=rtrim($base, "/\\").'/backups';
    if(!is_dir($private)&&!@mkdir($private,0700,true)) throw new RuntimeException('Web kökü dışında güvenli backup dizini oluşturulamadı. MONI_PRIVATE_DIR ayarlayın.');
    if(!is_writable($private)) throw new RuntimeException('Güvenli backup dizini yazılabilir değil.');
    @chmod($private,0700);return $private;
}
function moni_backup_create(PDO $db,int $createdBy=0,bool $includeUploads=true): array {
    if(!moni_table_ready($db,'backup_records'))return ['ok'=>false,'error'=>'Backup tablosu hazır değil.'];
    $id=null;$fh=null;$dir=moni_backup_dir();$stamp=date('Ymd_His');$base='moni_backup_'.$stamp.'_'.bin2hex(random_bytes(4));
    $dbFile=$dir.'/'.$base.'.jsonl';$zipFile=$dir.'/'.$base.'.zip';
    try{
        // Yedek şifrelenmiş secret içerdiği için hangi uygulama anahtarıyla çözülebileceğini fingerprint ile kaydet.
        // Anahtarın kendisi ZIP'e ASLA konmaz.
        $keyFingerprint=moni_secret_key_fingerprint();
        $db->prepare("INSERT INTO backup_records(file_name,status,created_by,started_at,created_at) VALUES(?,'running',?,NOW(),NOW())")
           ->execute([basename($zipFile),$createdBy?:null]);
        $id=(int)$db->lastInsertId();
        $fh=fopen($dbFile,'wb');if(!$fh)throw new RuntimeException('Backup dosyası açılamadı.');@chmod($dbFile,0600);
        $tables=$db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        foreach($tables as $table){
            $safe=str_replace('`','',$table);if(!preg_match('/^[A-Za-z0-9_]+$/',$safe))continue;
            $create=$db->query("SHOW CREATE TABLE `$safe`")->fetch(PDO::FETCH_NUM);
            fwrite($fh,moni_json(['kind'=>'schema','table'=>$safe,'sql'=>$create[1]??''])."\n");
            $q=$db->query("SELECT * FROM `$safe`");
            while($row=$q->fetch(PDO::FETCH_ASSOC))fwrite($fh,moni_json(['kind'=>'row','table'=>$safe,'data'=>$row])."\n");
        }
        fclose($fh);$fh=null;
        if(!class_exists('ZipArchive'))throw new RuntimeException('ZipArchive eklentisi gerekli.');
        $zip=new ZipArchive();if($zip->open($zipFile,ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true)throw new RuntimeException('ZIP backup oluşturulamadı.');
        $zip->addFile($dbFile,'database.jsonl');
        $manifest=moni_json([
            'format'=>'moni-backup-v2','created_at'=>date(DATE_ATOM),'app_key_fingerprint'=>$keyFingerprint,
            'includes_uploads'=>$includeUploads,'note'=>'Şifreleme anahtarı bu arşivde bulunmaz; ayrı kurtarma anahtarını saklayın.'
        ]);
        $zip->addFromString('manifest.json',$manifest);
        /* config.php ve gerçek MONI secret key özellikle yedeğe eklenmez. */
        if($includeUploads){
            $root=dirname(__DIR__).'/uploads';
            if(is_dir($root))foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS)) as $f){
                if($f->isFile()){$rel='uploads/'.str_replace('\\','/',substr($f->getPathname(),strlen($root)+1));$zip->addFile($f->getPathname(),$rel);}
            }
        }
        $zip->close();@chmod($zipFile,0600);@unlink($dbFile);
        $sha=hash_file('sha256',$zipFile);$size=filesize($zipFile);
        $db->prepare("UPDATE backup_records SET status='completed',file_size=?,sha256=?,finished_at=NOW() WHERE id=?")->execute([$size,$sha,$id]);
        return ['ok'=>true,'id'=>$id,'file'=>$zipFile,'sha256'=>$sha,'size'=>$size,'app_key_fingerprint'=>$keyFingerprint];
    }catch(Throwable $e){
        if(is_resource($fh))fclose($fh);@unlink($dbFile);@unlink($zipFile);
        if($id)$db->prepare("UPDATE backup_records SET status='failed',error_message=?,finished_at=NOW() WHERE id=?")->execute([mb_substr($e->getMessage(),0,1000),$id]);
        return ['ok'=>false,'error'=>$e->getMessage()];
    }
}
function moni_backup_restore(PDO $db,int $backupId): array {
    if(!moni_table_ready($db,'backup_records'))return ['ok'=>false,'error'=>'Backup tablosu yok.'];
    try{
        $s=$db->prepare("SELECT * FROM backup_records WHERE id=? AND status='completed'");$s->execute([$backupId]);$r=$s->fetch(PDO::FETCH_ASSOC);
        if(!$r)return ['ok'=>false,'error'=>'Yedek bulunamadı.'];
        $zipPath=moni_backup_dir().'/'.basename($r['file_name']);
        if(!is_file($zipPath)||!hash_equals((string)$r['sha256'],hash_file('sha256',$zipPath)))return ['ok'=>false,'error'=>'Yedek bütünlük doğrulaması başarısız.'];
        $zip=new ZipArchive();if($zip->open($zipPath)!==true)return ['ok'=>false,'error'=>'Yedek açılamadı.'];

        $manifestRaw=$zip->getFromName('manifest.json');$manifest=$manifestRaw!==false?json_decode((string)$manifestRaw,true):null;
        if(is_array($manifest)&&!empty($manifest['app_key_fingerprint'])){
            $current=moni_secret_key_fingerprint();
            if(!hash_equals((string)$manifest['app_key_fingerprint'],$current)){
                $zip->close();
                return ['ok'=>false,'error'=>'Bu yedek farklı bir MONI şifreleme anahtarıyla oluşturulmuş. Önce Yedekleme Merkezi üzerinden o kurulumun Kurtarma Anahtarını içe aktarın.'];
            }
        }else{
            // Eski backup formatında fingerprint yok. İçinde encrypted secret varsa yanlış anahtarla restore etmeyi engelle.
            $legacyStream=$zip->getStream('database.jsonl');$hasEncrypted=false;
            if($legacyStream){while(($line=fgets($legacyStream))!==false){if(str_contains($line,'enc:v1:')){$hasEncrypted=true;break;}}fclose($legacyStream);}
            if($hasEncrypted){$zip->close();return ['ok'=>false,'error'=>'Eski yedek şifreli credential içeriyor ancak anahtar fingerprint bilgisi yok. Güvenli otomatik restore durduruldu.'];}
        }

        $stream=$zip->getStream('database.jsonl');if(!$stream){$zip->close();return ['ok'=>false,'error'=>'Veritabanı yedeği bulunamadı.'];}
        $schemas=[];
        while(($line=fgets($stream))!==false){
            $j=json_decode($line,true);if(!is_array($j)||($j['kind']??'')!=='schema')continue;
            $table=(string)($j['table']??'');$sql=(string)($j['sql']??'');
            if(!preg_match('/^[A-Za-z0-9_]+$/',$table)||stripos(ltrim($sql),'CREATE TABLE')!==0)throw new RuntimeException('Yedek şeması geçersiz.');
            $schemas[$table]=$sql;
        }
        fclose($stream);if(!$schemas)throw new RuntimeException('Yedekte geçerli tablo şeması yok.');

        $safety=moni_backup_create($db,(int)($_SESSION['user_id']??0),false);
        if(empty($safety['ok'])){$zip->close();return ['ok'=>false,'error'=>'Restore öncesi güvenlik yedeği oluşturulamadı: '.($safety['error']??'')];}

        $db->exec('SET FOREIGN_KEY_CHECKS=0');
        foreach($schemas as $table=>$sql){$db->exec("DROP TABLE IF EXISTS `$table`");$db->exec($sql);}
        $stream=$zip->getStream('database.jsonl');if(!$stream)throw new RuntimeException('Yedek ikinci kez açılamadı.');
        $prepared=[];$count=0;
        while(($line=fgets($stream))!==false){
            $j=json_decode($line,true);if(!is_array($j)||($j['kind']??'')!=='row'||empty($j['table'])||!is_array($j['data']??null))continue;
            $table=(string)$j['table'];if(!isset($schemas[$table]))continue;$row=$j['data'];$cols=array_keys($row);
            foreach($cols as $c)if(!preg_match('/^[A-Za-z0-9_]+$/',(string)$c))throw new RuntimeException('Geçersiz kolon adı.');
            $sig=$table.'|'.implode(',',$cols);
            if(!isset($prepared[$sig])){$ph='('.implode(',',array_fill(0,count($cols),'?')).')';$prepared[$sig]=$db->prepare("INSERT INTO `$table` (`".implode('`,`',$cols)."`) VALUES $ph");}
            $prepared[$sig]->execute(array_values($row));$count++;
        }
        fclose($stream);$zip->close();$db->exec('SET FOREIGN_KEY_CHECKS=1');
        return ['ok'=>true,'tables'=>count($schemas),'rows'=>$count,'safety_backup_id'=>$safety['id']??null];
    }catch(Throwable $e){
        try{$db->exec('SET FOREIGN_KEY_CHECKS=1');}catch(Throwable $ignore){}
        return ['ok'=>false,'error'=>$e->getMessage()];
    }
}
function moni_backup_retention(PDO $db): int {$keep=max(1,min(90,(int)getSetting('backup_retention_count','10')));if(!moni_table_ready($db,'backup_records'))return 0;try{$rows=$db->query("SELECT id,file_name FROM backup_records WHERE status='completed' ORDER BY id DESC LIMIT 1000 OFFSET $keep")->fetchAll(PDO::FETCH_ASSOC);$n=0;foreach($rows as $r){@unlink(moni_backup_dir().'/'.basename($r['file_name']));$db->prepare("UPDATE backup_records SET status='deleted',deleted_at=NOW() WHERE id=?")->execute([$r['id']]);$n++;}return $n;}catch(Throwable $e){return 0;}}

/* ------------------------- Bootstrap additions ------------------------- */
function moni_enterprise_boot(PDO $db): void {
    // Audit HMAC sürümü için geriye uyumlu kolon. DDL izni yoksa kayıtlar legacy modda kalır ve sistem çalışmaya devam eder.
    if(moni_table_ready($db,'admin_audit_log')){try{$c=$db->query("SHOW COLUMNS FROM admin_audit_log LIKE 'hash_version'")->fetch(PDO::FETCH_ASSOC);if(!$c)$db->exec("ALTER TABLE admin_audit_log ADD COLUMN hash_version tinyint NOT NULL DEFAULT 1 AFTER row_hash");}catch(Throwable $e){error_log('Audit schema migration: '.$e->getMessage());}}
    moni_register_admin_audit_request($db);
    // Site genelinde eski admin oturumları dahil varsayılan timezone geçerli kalsın; kullanıcı paneli kendi timezone'una geçer.
}
