<?php
if (defined('MONI_ADVANCED_LOADED')) return;
define('MONI_ADVANCED_LOADED', true);

function moni_setting_bool(string $key, bool $default=false): bool {
    $v=(string)getSetting($key,$default?'1':'0');
    return in_array(strtolower($v),['1','true','yes','on'],true);
}

/* ------------------------- Staff / permissions ------------------------- */
function moni_current_admin_row(PDO $db): ?array {
    if (empty($_SESSION['user_id']) || !isAdmin()) return null;
    static $cache=[];$id=(int)$_SESSION['user_id'];if(isset($cache[$id]))return $cache[$id];
    try{$s=$db->prepare("SELECT * FROM users WHERE id=? LIMIT 1");$s->execute([$id]);return $cache[$id]=($s->fetch(PDO::FETCH_ASSOC)?:null);}catch(Throwable $e){return null;}
}
function moni_is_super_admin(PDO $db): bool {
    if(!isAdmin()) return false;
    $u=moni_current_admin_row($db); if(!$u) return false;
    return empty($u['staff_role_id']);
}
function moni_staff_can(PDO $db,string $permission): bool {
    if (!isAdmin()) return false;
    $u=moni_current_admin_row($db); if(!$u) return false;
    $roleId=(int)($u['staff_role_id']??0); if($roleId<=0) return true; // rolü olmayan admin = süper admin
    if(!moni_table_ready($db,'staff_role_permissions')||!moni_table_ready($db,'staff_roles'))return false;
    try{
        $active=$db->prepare("SELECT is_active FROM staff_roles WHERE id=? LIMIT 1");$active->execute([$roleId]);
        if((int)$active->fetchColumn()!==1)return false;
        $s=$db->prepare("SELECT 1 FROM staff_role_permissions rp JOIN staff_permissions p ON p.id=rp.permission_id WHERE rp.role_id=? AND p.permission_key=? LIMIT 1");$s->execute([$roleId,$permission]);return (bool)$s->fetchColumn();
    }catch(Throwable $e){return false;}
}
function moni_require_staff_permission(PDO $db,string $permission): void {
    if(moni_staff_can($db,$permission))return;
    http_response_code(403);exit('Bu işlem için yetkiniz yok.');
}
function moni_staff_role_name(PDO $db,?int $roleId): string {
    if(!$roleId)return 'Süper Admin';try{$s=$db->prepare("SELECT name FROM staff_roles WHERE id=?");$s->execute([$roleId]);return (string)($s->fetchColumn()?:'Personel');}catch(Throwable $e){return 'Personel';}
}


function moni_admin_page_permission(string $page): ?string {
    static $map=[
        'orders.php'=>'orders.manage','order-reason-codes.php'=>'orders.manage','refill-requests.php'=>'orders.manage','users.php'=>'users.manage',
        'payments.php'=>'payments.manage','transactions.php'=>'payments.manage','bank-accounts.php'=>'payments.manage','bank-reconciliation.php'=>'payments.manage','accounting-integrations.php'=>'payments.manage','iyzico-settings.php'=>'payments.manage','credit-packages.php'=>'payments.manage','coupons.php'=>'payments.manage','payment-bonuses.php'=>'payments.manage',
        'services.php'=>'services.manage','service-auto-badges.php'=>'services.manage','service-pricing.php'=>'services.manage','profit-heatmap.php'=>'services.manage','service-description-templates.php'=>'services.manage','service-translations.php'=>'services.manage','service-personalization.php'=>'services.manage','service-drop-analysis.php'=>'services.manage','service-target-rules.php'=>'services.manage','categories.php'=>'services.manage','service-trash.php'=>'services.manage','service-bundles.php'=>'bundles.manage',
        'api-providers.php'=>'providers.manage','provider-operations.php'=>'provider.logs','provider-sla.php'=>'provider.logs','provider-matcher.php'=>'providers.manage',
        'support.php'=>'support.manage','support-departments.php'=>'support.manage','support-hours.php'=>'support.manage',
        'settings.php'=>'settings.manage','maintenance.php'=>'settings.manage','theme-settings.php'=>'settings.manage','homepage-interfaces.php'=>'settings.manage','language-settings.php'=>'settings.manage','pwa-settings.php'=>'settings.manage','web-push.php'=>'settings.manage','email-deliverability.php'=>'settings.manage','plugins.php'=>'settings.manage','moni-system.php'=>'settings.manage','cron-center.php'=>'settings.manage','cron-trends.php'=>'settings.manage','queue-health.php'=>'settings.manage','automation-center.php'=>'settings.manage','registration-fields.php'=>'settings.manage','captcha-settings.php'=>'settings.manage','customer-api-logs.php'=>'settings.manage',
        'access-policies.php'=>'users.manage','customer-groups.php'=>'customer_groups.manage','premium-packages.php'=>'premium.manage',
        'exports.php'=>'exports.use','file-manager.php'=>'files.manage','page-builder.php'=>'pages.manage','seo-settings.php'=>'seo.manage','pages.php'=>'pages.manage','blog.php'=>'pages.manage','child-panels.php'=>'child_panels.manage',
        'bulk-operations.php'=>'bulk.manage','admin-api.php'=>'admin_api.manage','notifications.php'=>'notifications.manage','email-templates.php'=>'email_templates.manage','telegram-settings.php'=>'telegram.manage','audit-log.php'=>'audit.view','backup-center.php'=>'backups.manage',
        'announcements.php'=>'notifications.manage','popups.php'=>'notifications.manage','send-email.php'=>'notifications.manage',
        'api-settings.php'=>'settings.manage','daily-bonus.php'=>'settings.manage','daily-bonus-logs.php'=>'settings.manage','daily-bonus-settings.php'=>'settings.manage','email-domain-security.php'=>'settings.manage','footer-settings.php'=>'settings.manage','homepage-preview.php'=>'settings.manage','referral-settings.php'=>'settings.manage','smtp-settings.php'=>'settings.manage','translations.php'=>'settings.manage','staff-roles.php'=>'settings.manage',
        'homepage-services.php'=>'services.manage','service-capacity.php'=>'services.manage','service-hours.php'=>'services.manage','service-quality.php'=>'services.manage',
        'order-settings.php'=>'orders.manage','referral-fraud.php'=>'users.manage'
    ];
    return $map[$page]??null;
}
function moni_admin_request_guard(PDO $db): void {
    if(PHP_SAPI==='cli')return;
    $uri=(string)($_SERVER['REQUEST_URI']??'');
    if(!preg_match('#/admin(?:/|$)#',$uri))return;
    $page=basename((string)($_SERVER['SCRIPT_NAME']??$_SERVER['SCRIPT_FILENAME']??''));
    if($page===''||in_array($page,['index.php','login.php'],true))return;
    if(!isLoggedIn()||!isAdmin()){http_response_code(403);exit('Yönetici oturumu gerekli.');}
    $permission=moni_admin_page_permission($page);
    if($permission!==null)moni_require_staff_permission($db,$permission);
    // Yetki haritasına eklenmemiş yeni bir admin POST endpointi güvenli tarafta kalsın:
    // Süper Admin dışında sınıflandırılmamış veri değişikliğine izin verme.
    elseif(($_SERVER['REQUEST_METHOD']??'GET')==='POST' && !moni_is_super_admin($db)){
        http_response_code(403);exit('Bu yönetim işlemi için henüz açık bir personel yetkisi tanımlanmamış.');
    }
    // Personel rolü/yetki matrisini değiştirmek yalnız Süper Admin'e aittir.
    if($page==='staff-roles.php' && !moni_is_super_admin($db)){
        http_response_code(403);exit('Personel rol yönetimi yalnız Süper Admin tarafından kullanılabilir.');
    }

    // Admin hesabı oluşturma/değiştirme/silme/şifre sıfırlama yalnız Süper Admin'e aittir.
    if($_SERVER['REQUEST_METHOD']==='POST' && $page==='users.php' && !moni_is_super_admin($db)){
        $targetId=(int)($_POST['user_id']??0);$targetRole='';
        if($targetId>0){try{$q=$db->prepare("SELECT role FROM users WHERE id=? LIMIT 1");$q->execute([$targetId]);$targetRole=(string)$q->fetchColumn();}catch(Throwable $e){}}
        $submittedRole=(string)($_POST['role']??'');
        $critical=isset($_POST['add_user'])&&$submittedRole==='admin';
        $critical=$critical||($targetRole==='admin'&&(isset($_POST['update_user'])||isset($_POST['delete_user'])||isset($_POST['reset_password'])));
        $critical=$critical||(isset($_POST['update_user'])&&$submittedRole==='admin');
        if($critical){http_response_code(403);exit('Admin hesaplarıyla ilgili bu kritik işlem yalnız Süper Admin tarafından yapılabilir.');}
    }
}

/* ------------------------- User access policies ------------------------- */
function moni_user_can(PDO $db,int $userId,string $capability,bool $default=true): bool {
    if($userId<=0)return false;
    if(!moni_table_ready($db,'user_access_policies'))return $default;
    try{
        $s=$db->prepare("SELECT decision FROM user_access_policies WHERE user_id=? AND capability=? AND (expires_at IS NULL OR expires_at>NOW()) ORDER BY id DESC LIMIT 1");
        $s->execute([$userId,$capability]);$v=$s->fetchColumn();
        if($v===false)return $default;return $v==='allow';
    }catch(Throwable $e){return $default;}
}
function moni_require_user_capability(PDO $db,int $userId,string $capability,string $message='Bu işlem hesabınız için kapalı.'): void {
    if(moni_user_can($db,$userId,$capability,true))return;throw new RuntimeException($message);
}

/* ------------------------- Registration form ------------------------- */
function moni_registration_fields(PDO $db,bool $activeOnly=true): array {
    if(!moni_table_ready($db,'registration_fields'))return [];
    try{$sql="SELECT * FROM registration_fields".($activeOnly?" WHERE is_active=1":"")." ORDER BY sort_order,id";return $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){return [];}
}
function moni_registration_validate(PDO $db,array $post): array {
    $values=[];$errors=[];
    foreach(moni_registration_fields($db,true) as $f){$key='rf_'.$f['id'];$raw=$post[$key]??'';$v=is_array($raw)?implode(',',array_map('trim',$raw)):trim((string)$raw);
        if(!empty($f['is_required'])&&$v===''){$errors[]=$f['label'].' alanı zorunludur.';continue;}
        if($v===''){continue;}
        if($f['field_type']==='number'&&!is_numeric($v))$errors[]=$f['label'].' sayısal olmalıdır.';
        if($f['field_type']==='email'&&!filter_var($v,FILTER_VALIDATE_EMAIL))$errors[]=$f['label'].' geçerli e-posta olmalıdır.';
        if($f['field_type']==='url'&&!filter_var($v,FILTER_VALIDATE_URL))$errors[]=$f['label'].' geçerli URL olmalıdır.';
        if(!empty($f['validation_regex'])){set_error_handler(static fn()=>true);$ok=@preg_match($f['validation_regex'],$v);restore_error_handler();if($ok===0)$errors[]=$f['label'].' formatı geçersiz.';}
        $values[(int)$f['id']]=mb_substr($v,0,5000,'UTF-8');
    }
    return ['ok'=>!$errors,'errors'=>$errors,'values'=>$values];
}
function moni_registration_save_values(PDO $db,int $userId,array $values): void {
    if(!moni_table_ready($db,'registration_field_values'))return;$s=$db->prepare("INSERT INTO registration_field_values(user_id,field_id,field_value) VALUES(?,?,?) ON DUPLICATE KEY UPDATE field_value=VALUES(field_value),updated_at=NOW()");foreach($values as $fid=>$v)$s->execute([$userId,(int)$fid,(string)$v]);
}
function moni_grant_starting_balance(PDO $db,int $userId): float {
    $amount=max(0,(float)getSetting('registration_start_balance','0'));
    if($amount<=0||!moni_table_ready($db,'starting_balance_grants'))return 0.0;
    $own=!$db->inTransaction();
    if($own)$db->beginTransaction();
    try{
        $ins=$db->prepare("INSERT IGNORE INTO starting_balance_grants(user_id,amount,created_at) VALUES(?,?,NOW())");
        $ins->execute([$userId,$amount]);
        if(!$ins->rowCount()){if($own)$db->commit();return 0.0;}
        $u=$db->prepare("UPDATE users SET balance=balance+? WHERE id=? AND status='active'");$u->execute([$amount,$userId]);
        if(!$u->rowCount())throw new RuntimeException('Başlangıç bakiyesi kullanıcıya uygulanamadı.');
        $s=$db->prepare("SELECT balance FROM users WHERE id=?");$s->execute([$userId]);$bal=(float)$s->fetchColumn();
        $db->prepare("INSERT INTO transactions(user_id,type,amount,balance_after,description,status,created_at) VALUES(?,'bonus',?,?,?,'completed',NOW())")->execute([$userId,$amount,$bal,'Yeni üye başlangıç bakiyesi']);
        moni_sync_base_wallet($db,$userId);
        if($own)$db->commit();
        return $amount;
    }catch(Throwable $e){if($own&&$db->inTransaction())$db->rollBack();throw $e;}
}

/* ------------------------- Provider aliases ------------------------- */
function moni_provider_display_name(PDO $db,array $provider): string {
    $real=(string)($provider['name']??'Sağlayıcı');$alias=trim((string)($provider['alias_name']??''));
    if(isAdmin() && moni_staff_can($db,'providers.view_real_name'))return $real;
    return $alias!==''?$alias:$real;
}
function moni_provider_label(PDO $db,?string $real,?string $alias=null): string {
    $real=trim((string)$real);$alias=trim((string)$alias);
    if(!isAdmin() || moni_staff_can($db,'providers.view_real_name'))return $real!==''?$real:'Sağlayıcı';
    return $alias!==''?$alias:'Sağlayıcı';
}

/* ------------------------- Payment fees ------------------------- */
function moni_payment_fee_quote(PDO $db,int $paymentMethodId,float $baseAmount): array {
    $fee=0.0;$label='';if($baseAmount<0)$baseAmount=0;
    if(moni_table_ready($db,'payment_method_fees')){try{$s=$db->prepare("SELECT * FROM payment_method_fees WHERE payment_method_id=? AND is_active=1 LIMIT 1");$s->execute([$paymentMethodId]);$r=$s->fetch(PDO::FETCH_ASSOC);if($r){$fee=$r['fee_type']==='percent'?($baseAmount*(float)$r['fee_value']/100):(float)$r['fee_value'];$fee=max((float)($r['min_fee']??0),$fee);if((float)($r['max_fee']??0)>0)$fee=min((float)$r['max_fee'],$fee);$label=(string)($r['label']??'İşlem ücreti');}}catch(Throwable $e){}}
    $fee=round(max(0,$fee),4);return ['base'=>$baseAmount,'fee'=>$fee,'payable'=>round($baseAmount+$fee,4),'label'=>$label?:'İşlem ücreti'];
}

/* ------------------------- Safe remote social metric/parser ------------------------- */
function moni_resolve_public_host(string $host): ?string {
    $host=strtolower(trim($host));
    if($host===''||$host==='localhost'||str_ends_with($host,'.local'))return null;
    $ips=@gethostbynamel($host)?:[];
    foreach($ips as $ip){
        if(filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)!==false)return $ip;
    }
    return null;
}
function moni_host_is_public(string $host): bool {return moni_resolve_public_host($host)!==null;}
function moni_safe_public_url(string $url): bool {
    if(!filter_var($url,FILTER_VALIDATE_URL))return false;
    $p=parse_url($url);$scheme=strtolower((string)($p['scheme']??''));
    if(!in_array($scheme,['http','https'],true)||!empty($p['user'])||!empty($p['pass']))return false;
    $port=(int)($p['port']??($scheme==='https'?443:80));if($port<1||$port>65535)return false;
    return moni_resolve_public_host((string)($p['host']??''))!==null;
}
function moni_fetch_url(string $url,int $timeout=10): array {
    if(!filter_var($url,FILTER_VALIDATE_URL))return ['ok'=>false,'error'=>'Geçersiz URL.'];
    $p=parse_url($url);$scheme=strtolower((string)($p['scheme']??''));$host=(string)($p['host']??'');
    if(!in_array($scheme,['http','https'],true)||!empty($p['user'])||!empty($p['pass']))return ['ok'=>false,'error'=>'Güvensiz URL reddedildi.'];
    $port=(int)($p['port']??($scheme==='https'?443:80));if($port<1||$port>65535)return ['ok'=>false,'error'=>'Geçersiz port.'];
    $ip=moni_resolve_public_host($host);if($ip===null)return ['ok'=>false,'error'=>'Güvensiz veya yerel URL reddedildi.'];
    if(!function_exists('curl_init'))return ['ok'=>false,'error'=>'cURL kullanılamıyor.'];
    $ch=curl_init($url);$raw='';$tooLarge=false;
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>false,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_TIMEOUT=>$timeout,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_USERAGENT=>'SMMPanelBot/2.0 (+social-metric-check)',CURLOPT_HTTPHEADER=>['Accept: text/html,application/json;q=0.9,*/*;q=0.8'],CURLOPT_RESOLVE=>[$host.':'.$port.':'.$ip],CURLOPT_WRITEFUNCTION=>static function($ch,$chunk) use (&$raw,&$tooLarge){if(strlen($raw)+strlen($chunk)>3_000_000){$tooLarge=true;return 0;}$raw.=$chunk;return strlen($chunk);}]);
    $ok=curl_exec($ch);$err=curl_error($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$ct=(string)curl_getinfo($ch,CURLINFO_CONTENT_TYPE);curl_close($ch);
    if($tooLarge)return ['ok'=>false,'error'=>'Yanıt çok büyük.'];
    if($ok===false||$err||$http<200||$http>=300)return ['ok'=>false,'error'=>$err?:('HTTP '.$http)];
    return ['ok'=>true,'raw'=>$raw,'content_type'=>$ct,'http'=>$http];
}
function moni_detect_social_metric(PDO $db,string $url): array {
    $endpoint=trim((string)getSetting('social_metric_endpoint',''));
    if($endpoint!==''&&moni_safe_public_url($endpoint)){
        $sep=str_contains($endpoint,'?')?'&':'?';$r=moni_fetch_url($endpoint.$sep.'url='.rawurlencode($url),12);if(!empty($r['ok'])){$j=json_decode($r['raw'],true);$c=$j['count']??$j['value']??null;if(is_numeric($c))return ['ok'=>true,'count'=>(int)$c,'source'=>'endpoint'];}
    }
    $r=moni_fetch_url($url,10);if(empty($r['ok']))return ['ok'=>false,'error'=>$r['error']??'İçerik alınamadı'];$raw=$r['raw'];
    $patterns=[
        '/"userInteractionCount"\s*:\s*"?([0-9][0-9,\.]*[KMB]?)"?/i',
        '/"interactionCount"\s*:\s*"?([0-9][0-9,\.]*[KMB]?)"?/i',
        '/"follower_count"\s*:\s*([0-9]+)/i','/"followers_count"\s*:\s*([0-9]+)/i','/"like_count"\s*:\s*([0-9]+)/i','/"view_count"\s*:\s*([0-9]+)/i'
    ];
    foreach($patterns as $p){if(preg_match($p,$raw,$m)){return ['ok'=>true,'count'=>moni_metric_number($m[1]),'source'=>'page'];}}
    return ['ok'=>false,'error'=>'Sayısal metrik otomatik okunamadı.'];
}
function moni_metric_number(string $v): int {$v=strtoupper(str_replace([' ', ','],['',''],$v));$mul=1;if(str_ends_with($v,'K')){$mul=1000;$v=substr($v,0,-1);}elseif(str_ends_with($v,'M')){$mul=1000000;$v=substr($v,0,-1);}elseif(str_ends_with($v,'B')){$mul=1000000000;$v=substr($v,0,-1);}return (int)round((float)$v*$mul);}
function moni_capture_start_count(PDO $db,int $orderId,string $url): ?int {
    if(!moni_plugin_enabled('auto_start_count',$db))return null;$r=moni_detect_social_metric($db,$url);if(empty($r['ok']))return null;$count=(int)$r['count'];$db->prepare("UPDATE orders SET start_count=?,last_metric_count=?,last_metric_at=NOW() WHERE id=? AND start_count IS NULL")->execute([$count,$count,$orderId]);return $count;
}

/* ------------------------- Auto subscriptions ------------------------- */
function moni_discover_profile_items(PDO $db,string $profileUrl,int $limit=10): array {
    $r=moni_fetch_url($profileUrl,12);if(empty($r['ok']))return [];$host=parse_url($profileUrl,PHP_URL_HOST);$out=[];
    if(preg_match_all('~href=["\']([^"\']+)["\']~i',$r['raw'],$m))foreach($m[1] as $href){$u=html_entity_decode($href,ENT_QUOTES|ENT_HTML5,'UTF-8');if(str_starts_with($u,'/')){$scheme=parse_url($profileUrl,PHP_URL_SCHEME)?:'https';$u=$scheme.'://'.$host.$u;}if(!filter_var($u,FILTER_VALIDATE_URL))continue;$h=parse_url($u,PHP_URL_HOST);if(strtolower((string)$h)!==strtolower((string)$host))continue;if(!preg_match('~/(p|reel|reels|video|videos|watch|status|shorts)/|/status/|/posts?/|/photo/~i',$u))continue;$u=preg_replace('/[?#].*$/','',$u);$out[$u]=true;if(count($out)>=$limit)break;}
    return array_keys($out);
}
function moni_process_auto_subscriptions(PDO $db,int $batch): array {
    if(function_exists('moni_partial_maintenance_active')&&moni_partial_maintenance_active($db,'orders',false))return ['processed'=>0,'message'=>'Kısmi bakım: otomatik aboneliklerden yeni sipariş üretimi duraklatıldı.'];
    if(!moni_plugin_enabled('auto_subscriptions',$db)||!moni_table_ready($db,'auto_subscriptions'))return ['processed'=>0,'message'=>'Auto Subscription eklentisi kapalı.'];
    $s=$db->prepare("SELECT a.*,s.status service_status FROM auto_subscriptions a JOIN services s ON s.id=a.service_id WHERE a.status='active' AND s.status='active' AND (a.expires_at IS NULL OR a.expires_at>NOW()) AND (a.next_check_at IS NULL OR a.next_check_at<=NOW()) ORDER BY COALESCE(a.next_check_at,a.created_at) LIMIT $batch");$s->execute();$processed=0;$orders=0;
    foreach($s->fetchAll(PDO::FETCH_ASSOC) as $a){if(!moni_user_can($db,(int)$a['user_id'],'subscriptions.use',true)||!moni_user_can($db,(int)$a['user_id'],'orders.create',true)){$db->prepare("UPDATE auto_subscriptions SET last_checked_at=NOW(),next_check_at=DATE_ADD(NOW(),INTERVAL check_interval_minutes MINUTE),last_error='Kullanıcı erişim politikası otomatik siparişi engelliyor.',updated_at=NOW() WHERE id=?")->execute([$a['id']]);$processed++;continue;}$items=moni_discover_profile_items($db,$a['profile_url'],max(5,(int)$a['max_new_items_per_run']*3));$new=[];foreach($items as $u){$c=$db->prepare("SELECT 1 FROM auto_subscription_items WHERE subscription_id=? AND item_url=? LIMIT 1");$c->execute([$a['id'],$u]);if(!$c->fetchColumn())$new[]=$u;} $new=array_slice(array_reverse($new),0,max(1,(int)$a['max_new_items_per_run']));
        foreach($new as $url){$idem='sub:'.$a['id'].':'.hash('sha256',$url);$res=moni_place_order($db,(int)$a['user_id'],(int)$a['service_id'],$url,(int)$a['quantity'],['source'=>'subscription','idempotency_key'=>$idem]);$db->prepare("INSERT IGNORE INTO auto_subscription_items(subscription_id,item_url,order_id,status,created_at) VALUES(?,?,?,?,NOW())")->execute([$a['id'],$url,(int)($res['order_id']??0),!empty($res['success'])?'ordered':'error']);if(!empty($res['success']))$orders++;}
        $db->prepare("UPDATE auto_subscriptions SET last_checked_at=NOW(),next_check_at=DATE_ADD(NOW(),INTERVAL check_interval_minutes MINUTE),last_error=NULL,updated_at=NOW() WHERE id=?")->execute([$a['id']]);$processed++;
    }
    return ['processed'=>$processed,'message'=>"$processed abonelik kontrol edildi; $orders yeni sipariş üretildi."];
}

/* ------------------------- Likes spread ------------------------- */
function moni_create_spread(PDO $db,int $userId,int $serviceId,array $links,int $totalQty): array {
    moni_require_user_capability($db,$userId,'spread.use','Likes Spread kullanım yetkiniz kapalı.');
    moni_require_user_capability($db,$userId,'orders.create','Sipariş verme yetkiniz kapalı.');
    $links=array_values(array_unique(array_filter(array_map('trim',$links))));
    if(count($links)<2)return ['success'=>false,'error'=>'En az 2 bağlantı gerekli.'];
    if($totalQty<1)return ['success'=>false,'error'=>'Toplam miktar 1 veya daha büyük olmalıdır.'];
    $srv=$db->prepare("SELECT min_quantity,max_quantity,status FROM services WHERE id=? LIMIT 1");$srv->execute([$serviceId]);$service=$srv->fetch(PDO::FETCH_ASSOC);
    if(!$service||$service['status']!=='active')return ['success'=>false,'error'=>'Servis bulunamadı veya pasif.'];
    if(function_exists('moni_service_visible_to_user')&&!moni_service_visible_to_user($db,$serviceId,$userId))return ['success'=>false,'error'=>'Bu servis premium paketiniz için kullanılamıyor.'];
    $base=intdiv($totalQty,count($links));$rem=$totalQty%count($links);if($base<1)return ['success'=>false,'error'=>'Toplam miktar bağlantı sayısından küçük olamaz.'];
    $minPart=$base;$maxPart=$base+($rem>0?1:0);
    if($minPart<(int)$service['min_quantity']||$maxPart>(int)$service['max_quantity'])return ['success'=>false,'error'=>'Dağıtım sonrası bağlantı başına miktar servis min/max aralığına uymuyor. Toplam miktarı veya bağlantı sayısını değiştirin.'];
    foreach($links as $link)if(!moni_safe_public_url($link))return ['success'=>false,'error'=>'Tüm bağlantılar geçerli ve herkese açık http/https URL olmalıdır.'];
    $db->prepare("INSERT INTO likes_spreads(user_id,service_id,total_quantity,item_count,status,created_at) VALUES(?,?,?,?,'processing',NOW())")->execute([$userId,$serviceId,$totalQty,count($links)]);$sid=(int)$db->lastInsertId();$ok=0;$errors=[];
    foreach($links as $i=>$link){$q=$base+($i<$rem?1:0);$r=moni_place_order($db,$userId,$serviceId,$link,$q,['source'=>'likes_spread','idempotency_key'=>'spread:'.$sid.':'.$i]);$db->prepare("INSERT INTO likes_spread_items(spread_id,item_url,quantity,order_id,status,error_message) VALUES(?,?,?,?,?,?)")->execute([$sid,$link,$q,(int)($r['order_id']??0),!empty($r['success'])?'ordered':'error',$r['error']??null]);if(!empty($r['success']))$ok++;else$errors[]=$r['error']??'Hata';}
    $status=$ok===count($links)?'completed':($ok?'partial':'error');$db->prepare("UPDATE likes_spreads SET status=?,completed_items=?,updated_at=NOW() WHERE id=?")->execute([$status,$ok,$sid]);return ['success'=>$ok>0,'spread_id'=>$sid,'completed'=>$ok,'total'=>count($links),'errors'=>$errors];
}

/* ------------------------- Auto refill / real completion ------------------------- */
function moni_process_real_completion(PDO $db,int $batch): array {
    if(!moni_plugin_enabled('real_count_completion',$db))return ['processed'=>0,'message'=>'Gerçek sayıya göre tamamlama eklentisi kapalı.'];
    $s=$db->prepare("SELECT id,link,quantity,start_count,status FROM orders WHERE status IN('pending','processing','in_progress') AND start_count IS NOT NULL AND (last_metric_at IS NULL OR last_metric_at<DATE_SUB(NOW(),INTERVAL 10 MINUTE)) ORDER BY COALESCE(last_metric_at,created_at) LIMIT $batch");$s->execute();$n=0;$done=0;
    foreach($s->fetchAll(PDO::FETCH_ASSOC) as $o){$r=moni_detect_social_metric($db,$o['link']);if(!empty($r['ok'])){$c=(int)$r['count'];$target=(int)$o['start_count']+(int)$o['quantity'];$status=$c>=$target?'completed':$o['status'];$db->prepare("UPDATE orders SET last_metric_count=?,last_metric_at=NOW(),status=?,auto_completed_by_metric=? WHERE id=?")->execute([$c,$status,$c>=$target?1:0,$o['id']]);if($c>=$target)$done++;}$n++;}
    return ['processed'=>$n,'message'=>"$n sipariş kontrol edildi; $done sipariş gerçek sayıya göre tamamlandı."];
}
function moni_process_auto_refill(PDO $db,int $batch): array {
    if(!moni_setting_bool('auto_refill_enabled',true))return ['processed'=>0,'message'=>'Otomatik refill kapalı.'];
    $s=$db->prepare("SELECT o.* FROM orders o WHERE o.status='completed' AND o.refill_enabled=1 AND (o.refill_until IS NULL OR o.refill_until>=CURDATE()) AND o.start_count IS NOT NULL AND (o.auto_refill_last_at IS NULL OR o.auto_refill_last_at<DATE_SUB(NOW(),INTERVAL 12 HOUR)) ORDER BY COALESCE(o.auto_refill_last_at,o.updated_at) LIMIT $batch");$s->execute();$n=0;$sent=0;
    foreach($s->fetchAll(PDO::FETCH_ASSOC) as $o){$r=moni_detect_social_metric($db,$o['link']);$db->prepare("UPDATE orders SET auto_refill_last_at=NOW() WHERE id=?")->execute([$o['id']]);if(empty($r['ok'])){$n++;continue;}$current=(int)$r['count'];$target=(int)$o['start_count']+(int)$o['quantity'];$threshold=max(1,(int)round((int)$o['quantity']*((float)getSetting('auto_refill_drop_percent','5')/100)));$drop=max(0,$target-$current);$db->prepare("INSERT INTO auto_refill_checks(order_id,current_count,target_count,drop_count,action,created_at) VALUES(?,?,?,?,?,NOW())")->execute([$o['id'],$current,$target,$drop,$drop>=$threshold?'refill':'none']);if($drop>=$threshold){$exists=$db->prepare("SELECT 1 FROM refill_requests WHERE order_id=? AND status IN('pending','processing') LIMIT 1");$exists->execute([$o['id']]);if(!$exists->fetchColumn()){$rr=moni_provider_refill($db,$o);$db->prepare("INSERT INTO refill_requests(order_id,user_id,api_order_id,api_refill_id,quantity,status,admin_note,created_at) VALUES(?,?,?,?,? ,?,?,NOW())")->execute([$o['id'],$o['user_id'],$o['api_order_id'],is_array($rr['data']??null)?($rr['data']['refill']??null):null,$o['quantity'],!empty($rr['success'])?'processing':'error',!empty($rr['success'])?'Otomatik refill başlatıldı.':($rr['error']??'Refill hatası')]);if(!empty($rr['success']))$sent++;}}$n++;}
    return ['processed'=>$n,'message'=>"$n refill hakkı kontrol edildi; $sent refill başlatıldı."];
}

/* ------------------------- Provider catalog sync ------------------------- */
function moni_provider_catalog(PDO $db,array $provider): array {
    $r=moni_provider_request($provider,['action'=>'services'],'services',45);if(empty($r['success'])||!is_array($r['data']))return ['ok'=>false,'error'=>$r['error']??'Servis listesi alınamadı','services'=>[]];$rows=array_is_list($r['data'])?$r['data']:($r['data']['services']??[]);return ['ok'=>true,'services'=>is_array($rows)?$rows:[]];
}
function moni_sync_provider_catalog(PDO $db,int $providerId,int $limit=1000,bool $copyDescription=true): array {
    $s=$db->prepare("SELECT * FROM api_providers WHERE id=? AND status='active'");$s->execute([$providerId]);$p=$s->fetch(PDO::FETCH_ASSOC);if(!$p)return ['ok'=>false,'error'=>'Sağlayıcı bulunamadı.'];
    if(function_exists('moni_table_ready')&&moni_table_ready($db,'provider_sync_logs')){try{$db->prepare("INSERT INTO provider_sync_logs(provider_id,status,started_at,created_at) VALUES(?,'running',NOW(),NOW())")->execute([$providerId]);$GLOBALS['MONI_PROVIDER_SYNC_RUN_ID']=(int)$db->lastInsertId();}catch(Throwable $e){}}
    $cat=moni_provider_catalog($db,$p);if(empty($cat['ok'])){if(function_exists('moni_finish_provider_sync_log'))moni_finish_provider_sync_log($db,$providerId,0,'error',$cat['error']??'Servis listesi alınamadı');return $cat;}
    $map=[];foreach($cat['services'] as $x){$id=(string)($x['service']??$x['id']??'');if($id!=='')$map[$id]=$x;}$q=$db->prepare("SELECT * FROM services WHERE api_provider_id=? AND api_service_id IS NOT NULL AND deleted_at IS NULL LIMIT ".max(1,min(5000,$limit)));$q->execute([$providerId]);$n=0;
    foreach($q->fetchAll(PDO::FETCH_ASSOC) as $srv){$x=$map[(string)$srv['api_service_id']]??null;if(!$x)continue;$min=!empty($srv['sync_min_max'])?(int)($x['min']??$srv['min_quantity']):(int)$srv['min_quantity'];$max=!empty($srv['sync_min_max'])?(int)($x['max']??$srv['max_quantity']):(int)$srv['max_quantity'];$remoteActive=!isset($x['status'])||in_array(strtolower((string)$x['status']),['active','enabled','1','true'],true);$status=!empty($srv['sync_status'])?($remoteActive?'active':'inactive'):$srv['status'];$doDesc=$copyDescription&&!empty($srv['sync_description']);$desc=$doDesc?(string)($x['description']??$x['desc']??$x['note']??$srv['description']):$srv['description'];$rawCost=(float)($x['rate']??$x['price']??$srv['cost_per_1000']);$rate=1.0;if(function_exists('moni_cron_rate_to_base'))$rate=moni_cron_rate_to_base($db,(string)($p['currency']??'USD'));elseif(moni_table_ready($db,'currencies')){try{$rr=$db->prepare("SELECT rate_to_base FROM currencies WHERE code=? AND is_active=1");$rr->execute([strtoupper((string)($p['currency']??'USD'))]);$rv=$rr->fetchColumn();if($rv!==false&&(float)$rv>0)$rate=(float)$rv;}catch(Throwable $e){}}$cost=$rawCost*$rate;$after=$srv;$after['min_quantity']=$min;$after['max_quantity']=$max;$after['status']=$status;$after['description']=$desc;$after['cost_per_1000']=$cost;if(function_exists('moni_log_provider_sync'))moni_log_provider_sync($db,$providerId,$srv,$after,(string)$srv['api_service_id']);$db->prepare("UPDATE services SET min_quantity=?,max_quantity=?,status=?,description=?,cost_per_1000=?,updated_at=NOW() WHERE id=?")->execute([$min,$max,$status,$desc,$cost,$srv['id']]);$n++;}
    if(function_exists('moni_finish_provider_sync_log'))moni_finish_provider_sync_log($db,$providerId,$n,'success',"$n servis güncellendi");
    return ['ok'=>true,'processed'=>$n];
}

/* ------------------------- Child panels ------------------------- */
function moni_child_panel_context(PDO $db): ?array {
    if(!moni_plugin_enabled('child_panels',$db)||!moni_table_ready($db,'child_panels'))return null;static $loaded=false,$ctx=null;if($loaded)return $ctx;$loaded=true;$host=strtolower(preg_replace('/:\d+$/','',$_SERVER['HTTP_HOST']??''));if($host==='')return null;try{$s=$db->prepare("SELECT cp.*,u.username owner_username FROM child_panels cp JOIN users u ON u.id=cp.owner_user_id WHERE LOWER(cp.domain)=? AND cp.status='active' AND (cp.expires_at IS NULL OR cp.expires_at>NOW()) LIMIT 1");$s->execute([$host]);$ctx=$s->fetch(PDO::FETCH_ASSOC)?:null;}catch(Throwable $e){}return $ctx;
}
function moni_hex_contrast(string $hex): string {
    $hex=ltrim(trim($hex),'#');if(strlen($hex)===3)$hex=$hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    if(!preg_match('/^[0-9a-fA-F]{6}$/',$hex))return '#ffffff';
    $r=hexdec(substr($hex,0,2));$g=hexdec(substr($hex,2,2));$b=hexdec(substr($hex,4,2));
    $lum=(0.299*$r+0.587*$g+0.114*$b);return $lum>160?'#111827':'#ffffff';
}
function moni_apply_child_panel_branding(PDO $db,array &$siteSettings): void {
    $c=moni_child_panel_context($db);if(!$c)return;
    $siteSettings['name']=$c['panel_name']?:$siteSettings['name'];
    if(!empty($c['logo_url']))$siteSettings['logo']=$c['logo_url'];
    $color=trim((string)($c['primary_color']??''));
    if(preg_match('/^#[0-9a-fA-F]{6}$/',$color)){$siteSettings['child_primary_color']=$color;$siteSettings['child_on_primary']=moni_hex_contrast($color);}
    $siteSettings['child_panel_id']=(int)$c['id'];$siteSettings['child_panel_domain']=$c['domain'];
    $GLOBALS['moniChildPanel']=$c;
}
function moni_child_panel_markup(PDO $db): float {$c=$GLOBALS['moniChildPanel']??moni_child_panel_context($db);return $c?max(0,(float)$c['markup_percent']):0.0;}
function moni_child_panel_maintenance(PDO $db,int $batch=200): array {
    if(!moni_plugin_enabled('child_panels',$db)||!moni_table_ready($db,'child_panels'))return ['processed'=>0,'message'=>'Child Panel eklentisi kapalı.'];
    $batch=max(1,min(5000,$batch));$n=0;
    try{$st=$db->prepare("UPDATE child_panels SET status='expired',updated_at=NOW() WHERE status='active' AND expires_at IS NOT NULL AND expires_at<NOW() LIMIT $batch");$st->execute();$n=$st->rowCount();}catch(Throwable $e){return ['processed'=>0,'message'=>'Child Panel süre kontrolü başarısız: '.$e->getMessage()];}
    return ['processed'=>$n,'message'=>"$n süresi dolmuş Child Panel pasifleştirildi."];
}

/* ------------------------- RTL ------------------------- */
function moni_language_direction(PDO $db,string $code): string {if(!moni_table_ready($db,'languages'))return 'ltr';try{$s=$db->prepare("SELECT direction FROM languages WHERE code=? LIMIT 1");$s->execute([$code]);$v=$s->fetchColumn();return $v==='rtl'?'rtl':'ltr';}catch(Throwable $e){return 'ltr';}}

/* ------------------------- SEO ------------------------- */
function moni_write_robots(PDO $db): bool {
    $base=rtrim((defined('SITE_URL')?SITE_URL:''),'/');
    $default="User-agent: *\nDisallow: /admin/\nDisallow: /kullanici/\nSitemap: ".($base!==''?$base.'/sitemap.xml':'/sitemap.xml')."\n";
    $content=(string)getSetting('robots_txt',$default);
    // Eski varsayılan göreli Sitemap satırını, kullanıcı özel bir robots içeriği yazmadıysa mutlak URL'ye yükselt.
    if($base!=='' && trim($content)==="User-agent: *\nDisallow: /admin/\nDisallow: /kullanici/\nSitemap: /sitemap.xml")$content=$default;
    return @file_put_contents(dirname(__DIR__).'/robots.txt',$content,LOCK_EX)!==false;
}
function moni_generate_sitemap(PDO $db): array {$base=rtrim((defined('SITE_URL')?SITE_URL:''),'/');if($base==='')return ['ok'=>false,'error'=>'SITE_URL tanımlı değil.'];$urls=[$base.'/',$base.'/services.php',$base.'/blog.php'];try{foreach($db->query("SELECT slug,updated_at FROM custom_pages WHERE is_active=1")->fetchAll(PDO::FETCH_ASSOC) as $p)$urls[]=$base.'/page.php?slug='.rawurlencode($p['slug']);foreach($db->query("SELECT slug,updated_at FROM blog_posts WHERE is_active=1")->fetchAll(PDO::FETCH_ASSOC) as $p)$urls[]=$base.'/blog-detail.php?slug='.rawurlencode($p['slug']);if(moni_table_ready($db,'page_builder_pages'))foreach($db->query("SELECT slug FROM page_builder_pages WHERE is_active=1")->fetchAll(PDO::FETCH_COLUMN) as $slug)$urls[]=$base.'/page.php?slug='.rawurlencode($slug);}catch(Throwable $e){}$xml="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";foreach(array_unique($urls) as $u)$xml.='  <url><loc>'.htmlspecialchars($u,ENT_XML1|ENT_QUOTES,'UTF-8')."</loc></url>\n";$xml.="</urlset>\n";$ok=@file_put_contents(dirname(__DIR__).'/sitemap.xml',$xml,LOCK_EX)!==false;return ['ok'=>$ok,'count'=>count(array_unique($urls)),'error'=>$ok?null:'sitemap.xml yazılamadı'];}

/* ------------------------- Page builder renderer ------------------------- */
function moni_builder_page(PDO $db,string $slug): ?array {if(!moni_table_ready($db,'page_builder_pages'))return null;try{$s=$db->prepare("SELECT * FROM page_builder_pages WHERE slug=? AND is_active=1 LIMIT 1");$s->execute([$slug]);$p=$s->fetch(PDO::FETCH_ASSOC);if(!$p)return null;$b=$db->prepare("SELECT * FROM page_builder_blocks WHERE page_id=? AND is_active=1 ORDER BY sort_order,id");$b->execute([$p['id']]);$p['blocks']=$b->fetchAll(PDO::FETCH_ASSOC);return $p;}catch(Throwable $e){return null;}}
function moni_render_builder_blocks(array $blocks): string {$html='';foreach($blocks as $b){$d=json_decode((string)$b['config_json'],true)?:[];$type=$b['block_type'];if($type==='hero'){$html.='<section class="pb-hero"><h1>'.clean($d['title']??'').'</h1><p>'.clean($d['text']??'').'</p>'.(!empty($d['button_text'])?'<a class="pb-btn" href="'.clean($d['button_url']??'#').'">'.clean($d['button_text']).'</a>':'').'</section>';}elseif($type==='text'){$html.='<section class="pb-card"><h2>'.clean($d['title']??'').'</h2><div>'.moni_sanitize_admin_html($d['html']??'').'</div></section>';}elseif($type==='image'){$html.='<section class="pb-card pb-image"><img src="'.clean($d['url']??'').'" alt="'.clean($d['alt']??'').'"></section>';}elseif($type==='cta'){$html.='<section class="pb-card pb-cta"><h2>'.clean($d['title']??'').'</h2><p>'.clean($d['text']??'').'</p><a class="pb-btn" href="'.clean($d['button_url']??'#').'">'.clean($d['button_text']??'Devam Et').'</a></section>';}}return $html;}

/* ------------------------- File manager ------------------------- */
function moni_managed_file_scan(PDO $db,int $limit=1000): int {
    $root=dirname(__DIR__).'/uploads';
    if(!is_dir($root)||!moni_table_ready($db,'managed_files'))return 0;
    $limit=max(1,min(20000,$limit));
    $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));
    $n=0;
    foreach($it as $f){
        if($n>=$limit)break;
        if(!$f->isFile())continue;
        $rel=str_replace('\\','/',substr($f->getPathname(),strlen(dirname(__DIR__))+1));
        if(str_contains($rel,'/.'))continue;
        $mime=function_exists('mime_content_type')?@mime_content_type($f->getPathname()):'application/octet-stream';
        $hash=hash_file('sha256',$f->getPathname());
        $db->prepare("INSERT INTO managed_files(path,file_name,mime_type,size_bytes,sha256,updated_at) VALUES(?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE file_name=VALUES(file_name),mime_type=VALUES(mime_type),size_bytes=VALUES(size_bytes),sha256=VALUES(sha256),updated_at=NOW()")
           ->execute([$rel,$f->getFilename(),$mime,$f->getSize(),$hash]);
        $n++;
    }
    return $n;
}
