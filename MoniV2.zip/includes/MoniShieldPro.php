<?php
if (defined('MONI_SHIELD_PRO_LOADED')) return;
define('MONI_SHIELD_PRO_LOADED', true);

function moni_shield_setting(PDO $db,string $key,string $default=''): string {
    try{$s=$db->prepare("SELECT setting_value FROM settings WHERE setting_key=? LIMIT 1");$s->execute([$key]);$v=$s->fetchColumn();return $v===false?$default:(string)$v;}catch(Throwable $e){return $default;}
}
function moni_shield_set_setting(PDO $db,string $key,string $value): void {
    $s=$db->prepare("INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");$s->execute([$key,$value]);
}
function moni_shield_plugin_enabled(PDO $db,string $slug): bool {
    if(function_exists('moni_plugin_enabled')) return moni_plugin_enabled($slug,$db);
    try{$s=$db->prepare("SELECT is_enabled FROM plugins WHERE slug=? LIMIT 1");$s->execute([$slug]);return (int)$s->fetchColumn()===1;}catch(Throwable $e){return false;}
}
function moni_shield_table(PDO $db,string $table): bool {
    if(function_exists('moni_table_ready')) return moni_table_ready($db,$table);
    try{$db->query("SELECT 1 FROM `{$table}` LIMIT 1");return true;}catch(Throwable $e){return false;}
}

function moni_shield_runtime_migrate(PDO $db): void {
    static $done=false;if($done)return;$done=true;
    $revision='2026-09-29.1';
    try{
        if(moni_shield_setting($db,'moni_shield_pro_schema_revision','')===$revision && moni_shield_table($db,'service_capacity_metrics') && moni_shield_table($db,'referral_fraud_events') && moni_shield_table($db,'email_domain_rules')) return;
        $ddl=[];
        $ddl[]="CREATE TABLE IF NOT EXISTS service_capacity_settings (
          service_id int NOT NULL,
          capacity_mode enum('auto','manual') NOT NULL DEFAULT 'auto',
          hourly_capacity bigint NOT NULL DEFAULT 0,
          warning_percent decimal(6,2) NOT NULL DEFAULT 70.00,
          critical_percent decimal(6,2) NOT NULL DEFAULT 100.00,
          manual_status enum('available','busy','critical','paused') NOT NULL DEFAULT 'available',
          show_exact_percent tinyint(1) NOT NULL DEFAULT 0,
          updated_by int NULL,
          created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
          updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY(service_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS service_capacity_metrics (
          service_id int NOT NULL,
          effective_capacity bigint NOT NULL DEFAULT 0,
          last_hour_quantity bigint NOT NULL DEFAULT 0,
          active_quantity bigint NOT NULL DEFAULT 0,
          pending_orders int NOT NULL DEFAULT 0,
          utilization_percent decimal(8,2) NOT NULL DEFAULT 0.00,
          capacity_status enum('unknown','available','busy','critical','paused') NOT NULL DEFAULT 'unknown',
          calculated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY(service_id), KEY idx_capacity_status(capacity_status,calculated_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS referral_fraud_events (
          id bigint NOT NULL AUTO_INCREMENT,
          referral_log_id int NULL,
          referrer_id int NOT NULL,
          referred_id int NOT NULL,
          risk_score smallint NOT NULL DEFAULT 0,
          decision enum('allow','review','blocked') NOT NULL DEFAULT 'allow',
          ip_address varchar(45) NULL,
          device_id char(64) NULL,
          user_agent_hash char(64) NULL,
          reasons_json text NULL,
          reviewed_by int NULL,
          reviewed_at datetime NULL,
          review_note varchar(1000) NULL,
          created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY(id), KEY idx_ref_fraud_decision(decision,created_at), KEY idx_ref_fraud_referrer(referrer_id,created_at), KEY idx_ref_fraud_referred(referred_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS email_domain_rules (
          id bigint NOT NULL AUTO_INCREMENT,
          domain varchar(255) NOT NULL,
          rule_type enum('allow','block') NOT NULL DEFAULT 'block',
          source enum('builtin','custom') NOT NULL DEFAULT 'custom',
          is_active tinyint(1) NOT NULL DEFAULT 1,
          note varchar(500) NULL,
          created_by int NULL,
          created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
          updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY(id), UNIQUE KEY uq_email_domain_rule(domain,rule_type), KEY idx_email_domain_active(rule_type,is_active,domain)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS email_domain_block_logs (
          id bigint NOT NULL AUTO_INCREMENT,
          email_hash char(64) NOT NULL,
          domain varchar(255) NOT NULL,
          source varchar(40) NOT NULL DEFAULT 'register',
          ip_address varchar(45) NULL,
          device_id char(64) NULL,
          created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY(id), KEY idx_email_block_domain(domain,created_at), KEY idx_email_block_time(created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        foreach($ddl as $sql)$db->exec($sql);
        try{if(function_exists('moni_v2_compat_add_column')){
            moni_v2_compat_add_column($db,'referral_logs','fraud_status',"enum('clear','review','blocked') NOT NULL DEFAULT 'clear'");
            moni_v2_compat_add_column($db,'referral_logs','fraud_score','smallint NOT NULL DEFAULT 0');
            moni_v2_compat_add_column($db,'referral_logs','fraud_event_id','bigint NULL');
        }}catch(Throwable $ignore){}

        $p=$db->prepare("INSERT IGNORE INTO plugins(slug,name,description,version,is_enabled,is_core) VALUES(?,?,?,?,?,0)");
        $p->execute(['service_capacity_indicator','Servis Kapasite Göstergesi','Servislerin mevcut yükünü ve kapasite durumunu kullanıcı kataloğunda gösterir.','2.0.0',0]);
        $c=$db->prepare("INSERT IGNORE INTO cron_tasks(task_key,name,interval_minutes,batch_size,is_enabled) VALUES(?,?,?,?,?)");
        $c->execute(['service_capacity_refresh','Servis Kapasite Göstergesi Yenileme',5,250,1]);
        $s=$db->prepare("INSERT IGNORE INTO settings(setting_key,setting_value) VALUES(?,?)");
        foreach([
            'service_capacity_default_warning'=>'70',
            'service_capacity_default_critical'=>'100',
            'service_capacity_show_user'=>'1',
            'referral_fraud_enabled'=>'1',
            'referral_fraud_review_threshold'=>'60',
            'referral_fraud_block_threshold'=>'90',
            'referral_fraud_hold_suspicious_bonus'=>'1',
            'disposable_email_block_enabled'=>'1',
        ] as $k=>$v)$s->execute([$k,$v]);

        $builtins=['10minutemail.com','10minutemail.net','20minutemail.com','dispostable.com','emailondeck.com','fakeinbox.com','getairmail.com','getnada.com','guerrillamail.com','guerrillamail.net','guerrillamail.org','guerrillamailblock.com','inboxkitten.com','maildrop.cc','mailinator.com','mailinator.net','mailnesia.com','mintemail.com','mohmal.com','mytemp.email','sharklasers.com','spam4.me','temp-mail.org','temp-mail.io','tempmail.com','tempmail.net','tempmailaddress.com','throwawaymail.com','trashmail.com','trashmail.net','yopmail.com','yopmail.fr','yopmail.net'];
        $q=$db->prepare("INSERT IGNORE INTO email_domain_rules(domain,rule_type,source,is_active,note) VALUES(?,'block','builtin',1,'Yerleşik geçici e-posta alan adı')");
        foreach($builtins as $d)$q->execute([$d]);
        moni_shield_set_setting($db,'moni_shield_pro_schema_revision',$revision);
    }catch(Throwable $e){error_log('Moni Shield Pro migration: '.$e->getMessage());$GLOBALS['moni_shield_migration_error']=$e->getMessage();}
}

function moni_service_capacity_status_label(string $status): array {
    switch ($status) {
        case 'available': return ['Müsait','ok','fa-circle-check'];
        case 'busy': return ['Yoğun','warn','fa-gauge-high'];
        case 'critical': return ['Çok Yoğun','danger','fa-triangle-exclamation'];
        case 'paused': return ['Durduruldu','off','fa-circle-pause'];
        default: return ['Kapasite Belirsiz','off','fa-circle-question'];
    }
}
function moni_service_capacity_map(PDO $db,array $serviceIds): array {
    if(!moni_shield_plugin_enabled($db,'service_capacity_indicator') || (string)moni_shield_setting($db,'service_capacity_show_user','1')!=='1' || !$serviceIds || !moni_shield_table($db,'service_capacity_metrics')) return [];
    $ids=array_values(array_unique(array_filter(array_map('intval',$serviceIds),fn($x)=>$x>0)));if(!$ids)return [];
    $ph=implode(',',array_fill(0,count($ids),'?'));$st=$db->prepare("SELECT m.*,COALESCE(scs.show_exact_percent,0) show_exact_percent FROM service_capacity_metrics m LEFT JOIN service_capacity_settings scs ON scs.service_id=m.service_id WHERE m.service_id IN ($ph)");$st->execute($ids);$out=[];
    foreach($st->fetchAll(PDO::FETCH_ASSOC) as $r){$meta=moni_service_capacity_status_label((string)$r['capacity_status']);$out[(int)$r['service_id']]=['status'=>(string)$r['capacity_status'],'label'=>$meta[0],'badge'=>$meta[1],'icon'=>$meta[2],'utilization'=>(float)$r['utilization_percent'],'show_exact'=>(bool)$r['show_exact_percent'],'updated_at'=>$r['calculated_at']];}
    return $out;
}
function moni_service_capacity_attach(PDO $db,array &$rows): void {
    if(!$rows)return;$map=moni_service_capacity_map($db,array_column($rows,'id'));foreach($rows as &$r){$r['capacity']=$map[(int)$r['id']]??null;}unset($r);
}
function moni_refresh_service_capacity(PDO $db,int $batch=250): array {
    if(!moni_shield_plugin_enabled($db,'service_capacity_indicator')) return ['processed'=>0,'message'=>'Servis Kapasite Göstergesi eklentisi pasif.'];
    $batch=max(1,min(5000,$batch));$rows=$db->query("SELECT s.id,s.speed_per_hour,scs.capacity_mode,scs.hourly_capacity,scs.warning_percent,scs.critical_percent,scs.manual_status FROM services s LEFT JOIN service_capacity_settings scs ON scs.service_id=s.id WHERE s.status='active' ORDER BY s.id LIMIT ".(int)$batch)->fetchAll(PDO::FETCH_ASSOC);$n=0;
    $qHour=$db->prepare("SELECT COALESCE(SUM(quantity),0) FROM orders WHERE service_id=? AND created_at>=DATE_SUB(NOW(),INTERVAL 1 HOUR) AND status NOT IN('cancelled','refunded','error')");
    $qActive=$db->prepare("SELECT COUNT(*),COALESCE(SUM(quantity),0) FROM orders WHERE service_id=? AND status IN('pending','processing','in_progress')");
    $up=$db->prepare("INSERT INTO service_capacity_metrics(service_id,effective_capacity,last_hour_quantity,active_quantity,pending_orders,utilization_percent,capacity_status,calculated_at) VALUES(?,?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE effective_capacity=VALUES(effective_capacity),last_hour_quantity=VALUES(last_hour_quantity),active_quantity=VALUES(active_quantity),pending_orders=VALUES(pending_orders),utilization_percent=VALUES(utilization_percent),capacity_status=VALUES(capacity_status),calculated_at=NOW()");
    foreach($rows as $r){$sid=(int)$r['id'];$mode=(string)($r['capacity_mode']??'auto');$warn=(float)($r['warning_percent']??moni_shield_setting($db,'service_capacity_default_warning','70'));$crit=(float)($r['critical_percent']??moni_shield_setting($db,'service_capacity_default_critical','100'));$capacity=(int)($r['hourly_capacity']??0);if($mode==='auto'&&$capacity<=0)$capacity=(int)($r['speed_per_hour']??0);
        $qHour->execute([$sid]);$hour=(int)$qHour->fetchColumn();$qActive->execute([$sid]);$a=$qActive->fetch(PDO::FETCH_NUM);$pending=(int)($a[0]??0);$activeQty=(int)($a[1]??0);$load=max($hour,$activeQty);$util=$capacity>0?round(($load/$capacity)*100,2):0;
        if($mode==='manual')$status=(string)($r['manual_status']??'available');elseif($capacity<=0)$status='unknown';elseif($util>=$crit)$status='critical';elseif($util>=$warn)$status='busy';else$status='available';
        $up->execute([$sid,$capacity,$hour,$activeQty,$pending,$util,$status]);$n++;}
    return ['processed'=>$n,'message'=>$n.' servis kapasitesi güncellendi.'];
}
function moni_cron_task_service_capacity_refresh(PDO $db,int $batch): array {return moni_refresh_service_capacity($db,$batch);}

function moni_email_domain_normalize(string $emailOrDomain): string {
    $v=strtolower(trim($emailOrDomain));if(str_contains($v,'@'))$v=substr(strrchr($v,'@'),1);$v=trim($v,". \t\n\r\0\x0B");
    if(function_exists('idn_to_ascii')&&defined('INTL_IDNA_VARIANT_UTS46')){$x=@idn_to_ascii($v,IDNA_DEFAULT,INTL_IDNA_VARIANT_UTS46);if($x)$v=strtolower($x);}return $v;
}
function moni_email_domain_match_rule(string $domain,string $rule): bool {
    $rule=strtolower(trim($rule));if(str_starts_with($rule,'*.')){$suffix=substr($rule,2);return $domain===$suffix||str_ends_with($domain,'.'.$suffix);}return $domain===$rule;
}
function moni_disposable_email_is_blocked(PDO $db,string $email,?string &$matchedRule=null): bool {
    $matchedRule=null;if((string)moni_shield_setting($db,'disposable_email_block_enabled','1')!=='1'||!filter_var($email,FILTER_VALIDATE_EMAIL)||!moni_shield_table($db,'email_domain_rules'))return false;$domain=moni_email_domain_normalize($email);if($domain==='')return false;
    $rows=$db->query("SELECT domain,rule_type FROM email_domain_rules WHERE is_active=1 ORDER BY CASE rule_type WHEN 'allow' THEN 0 ELSE 1 END,id")->fetchAll(PDO::FETCH_ASSOC);
    foreach($rows as $r)if($r['rule_type']==='allow'&&moni_email_domain_match_rule($domain,(string)$r['domain']))return false;
    foreach($rows as $r)if($r['rule_type']==='block'&&moni_email_domain_match_rule($domain,(string)$r['domain'])){$matchedRule=(string)$r['domain'];return true;}return false;
}
function moni_log_disposable_email_block(PDO $db,string $email,string $source='register'): void {
    if(!moni_shield_table($db,'email_domain_block_logs'))return;$domain=moni_email_domain_normalize($email);try{$st=$db->prepare("INSERT INTO email_domain_block_logs(email_hash,domain,source,ip_address,device_id) VALUES(?,?,?,?,?)");$st->execute([hash('sha256',strtolower(trim($email))),$domain,substr($source,0,40),function_exists('moni_client_ip')?moni_client_ip():($_SERVER['REMOTE_ADDR']??''),function_exists('moni_device_id')?moni_device_id():null]);}catch(Throwable $ignore){}
}

function moni_referral_fraud_assess(PDO $db,int $referrerId,int $referredId,string $email,string $ip,string $ua): array {
    if((string)moni_shield_setting($db,'referral_fraud_enabled','1')!=='1')return ['score'=>0,'decision'=>'allow','reasons'=>[],'device_id'=>function_exists('moni_device_id')?moni_device_id():null];
    $score=0;$reasons=[];$device=function_exists('moni_device_id')?moni_device_id():null;$uaHash=hash('sha256',$ua);
    try{$s=$db->prepare("SELECT last_ip FROM users WHERE id=? LIMIT 1");$s->execute([$referrerId]);$rip=(string)$s->fetchColumn();if($ip!==''&&$rip!==''&&hash_equals($rip,$ip)){$score+=45;$reasons[]='Referans veren ve yeni hesap aynı IP adresini kullanıyor.';}}catch(Throwable $ignore){}
    if($device&&$device!=='cli'&&moni_shield_table($db,'security_events')){try{$s=$db->prepare("SELECT COUNT(*) FROM security_events WHERE user_id=? AND device_id=? AND created_at>=DATE_SUB(NOW(),INTERVAL 90 DAY)");$s->execute([$referrerId,$device]);if((int)$s->fetchColumn()>0){$score+=50;$reasons[]='Aynı cihaz daha önce referans veren hesapta kullanılmış.';}}catch(Throwable $ignore){}}
    try{$s=$db->prepare("SELECT COUNT(*) FROM referral_logs WHERE referrer_id=? AND ip_address=? AND created_at>=DATE_SUB(NOW(),INTERVAL 30 DAY)");$s->execute([$referrerId,$ip]);$same=(int)$s->fetchColumn();if($same>0){$score+=min(35+max(0,$same-1)*10,55);$reasons[]='Aynı IP adresinden aynı referans sahibine birden fazla kayıt var.';}}catch(Throwable $ignore){}
    if(moni_shield_table($db,'referral_fraud_events')&&$device&&$device!=='cli'){try{$s=$db->prepare("SELECT COUNT(*) FROM referral_fraud_events WHERE referrer_id=? AND device_id=? AND created_at>=DATE_SUB(NOW(),INTERVAL 30 DAY)");$s->execute([$referrerId,$device]);if((int)$s->fetchColumn()>0){$score+=45;$reasons[]='Aynı cihaz bu referans sahibinde daha önce kayıt üretmiş.';}}catch(Throwable $ignore){}}
    try{$s=$db->prepare("SELECT COUNT(*) FROM referral_logs WHERE referrer_id=? AND created_at>=DATE_SUB(NOW(),INTERVAL 10 MINUTE)");$s->execute([$referrerId]);$burst=(int)$s->fetchColumn();if($burst>=3){$score+=25;$reasons[]='Kısa sürede olağandışı referans kayıt yoğunluğu tespit edildi.';}}catch(Throwable $ignore){}
    try{$s=$db->prepare("SELECT COUNT(*) FROM referral_logs WHERE referrer_id=? AND user_agent=? AND created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY)");$s->execute([$referrerId,$ua]);if((int)$s->fetchColumn()>=2){$score+=10;$reasons[]='Aynı tarayıcı imzası birden fazla referans kaydında tekrarlandı.';}}catch(Throwable $ignore){}
    $score=min(100,$score);$review=max(1,min(100,(int)moni_shield_setting($db,'referral_fraud_review_threshold','60')));$block=max($review,min(100,(int)moni_shield_setting($db,'referral_fraud_block_threshold','90')));$decision=$score>=$block?'blocked':($score>=$review?'review':'allow');
    return ['score'=>$score,'decision'=>$decision,'reasons'=>$reasons,'device_id'=>$device,'ua_hash'=>$uaHash];
}
function moni_referral_fraud_record(PDO $db,int $referralLogId,int $referrerId,int $referredId,array $assessment,string $ip,string $ua): ?int {
    if(!moni_shield_table($db,'referral_fraud_events'))return null;try{$st=$db->prepare("INSERT INTO referral_fraud_events(referral_log_id,referrer_id,referred_id,risk_score,decision,ip_address,device_id,user_agent_hash,reasons_json) VALUES(?,?,?,?,?,?,?,?,?)");$st->execute([$referralLogId,$referrerId,$referredId,(int)$assessment['score'],(string)$assessment['decision'],$ip,$assessment['device_id']??null,$assessment['ua_hash']??hash('sha256',$ua),json_encode($assessment['reasons']??[],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);$id=(int)$db->lastInsertId();$hold=(string)moni_shield_setting($db,'referral_fraud_hold_suspicious_bonus','1')==='1';$fraudStatus=$assessment['decision']==='allow'?'clear':($assessment['decision']==='blocked'?'blocked':($hold?'review':'clear'));$db->prepare("UPDATE referral_logs SET fraud_status=?,fraud_score=?,fraud_event_id=? WHERE id=?")->execute([$fraudStatus,(int)$assessment['score'],$id,$referralLogId]);return $id;}catch(Throwable $e){error_log('Referral fraud record: '.$e->getMessage());return null;}
}

if(isset($db) && $db instanceof PDO) moni_shield_runtime_migrate($db);
