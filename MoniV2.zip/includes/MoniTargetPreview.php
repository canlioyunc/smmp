<?php
/** Hedef Canlı Önizleme eklenti motoru. Yalnız eklenti etkinken yüklenir. */
if (defined('MONI_TARGET_PREVIEW_LOADED')) return;
define('MONI_TARGET_PREVIEW_LOADED', true);

function moni_preview_public_host(string $host): bool {
    $host = strtolower(trim($host, '.[]'));
    if ($host === '' || $host === 'localhost') return false;
    if (function_exists('moni_resolve_public_host')) return moni_resolve_public_host($host) !== null;
    $ips = [];
    if (filter_var($host, FILTER_VALIDATE_IP)) $ips[] = $host;
    else {
        foreach ((array)@dns_get_record($host, DNS_A | DNS_AAAA) as $r) {
            if (!empty($r['ip'])) $ips[] = $r['ip'];
            if (!empty($r['ipv6'])) $ips[] = $r['ipv6'];
        }
    }
    if (!$ips) return false;
    foreach ($ips as $ip) {
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return false;
    }
    return true;
}

function moni_preview_absolute_url(string $base, string $candidate): string {
    $candidate = trim(html_entity_decode($candidate, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    if ($candidate === '') return '';
    if (preg_match('#^https?://#i', $candidate)) return $candidate;
    $bp = @parse_url($base);
    if (!$bp || empty($bp['host'])) return '';
    $scheme = strtolower((string)($bp['scheme'] ?? 'https'));
    $authority = $scheme . '://' . $bp['host'] . (!empty($bp['port']) ? ':' . (int)$bp['port'] : '');
    if (str_starts_with($candidate, '//')) return $scheme . ':' . $candidate;
    if (str_starts_with($candidate, '/')) return $authority . $candidate;
    $path = (string)($bp['path'] ?? '/');
    $dir = preg_replace('#/[^/]*$#', '/', $path) ?: '/';
    return $authority . $dir . $candidate;
}

function moni_preview_safe_image(string $image, string $base): string {
    $image = moni_preview_absolute_url($base, $image);
    if ($image === '' || !filter_var($image, FILTER_VALIDATE_URL)) return '';
    $p = @parse_url($image);
    if (!in_array(strtolower((string)($p['scheme'] ?? '')), ['http', 'https'], true)) return '';
    $host = (string)($p['host'] ?? '');
    return $host !== '' && moni_preview_public_host($host) ? $image : '';
}

function moni_preview_fetch(string $url, int $maxBytes = 1048576, int $maxRedirects = 3): array {
    if (!function_exists('curl_init')) return ['ok' => false, 'error' => 'Sunucuda cURL bulunamadı.'];
    $current = $url;
    for ($hop = 0; $hop <= $maxRedirects; $hop++) {
        $p = @parse_url($current);
        $scheme = strtolower((string)($p['scheme'] ?? ''));
        $host = (string)($p['host'] ?? '');
        if (!in_array($scheme, ['http', 'https'], true) || $host === '' || !empty($p['user']) || !empty($p['pass'])) {
            return ['ok' => false, 'error' => 'Güvensiz hedef bağlantısı reddedildi.'];
        }
        $port = (int)($p['port'] ?? ($scheme === 'https' ? 443 : 80));
        if (!in_array($port, [80, 443], true)) return ['ok' => false, 'error' => 'Standart dışı hedef portu önizlenemez.'];
        $ip = function_exists('moni_resolve_public_host') ? moni_resolve_public_host($host) : null;
        if ($ip === null && !moni_preview_public_host($host)) return ['ok' => false, 'error' => 'Güvensiz veya yerel hedef reddedildi.'];

        $body = '';
        $tooLarge = false;
        $location = '';
        $ch = curl_init($current);
        $opts = [
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_HEADER => false,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_ENCODING => '',
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15',
            CURLOPT_HTTPHEADER => [
                'Accept: text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.5',
                'Accept-Language: tr-TR,tr;q=0.9,en-US;q=0.7,en;q=0.6',
                'Cache-Control: no-cache',
            ],
            CURLOPT_HEADERFUNCTION => static function ($ch, $line) use (&$location) {
                if (stripos($line, 'Location:') === 0) $location = trim(substr($line, 9));
                return strlen($line);
            },
            CURLOPT_WRITEFUNCTION => static function ($ch, $chunk) use (&$body, &$tooLarge, $maxBytes) {
                if (strlen($body) + strlen($chunk) > $maxBytes) {
                    $tooLarge = true;
                    return 0;
                }
                $body .= $chunk;
                return strlen($chunk);
            },
        ];
        if ($ip !== null) $opts[CURLOPT_RESOLVE] = [$host . ':' . $port . ':' . $ip];
        curl_setopt_array($ch, $opts);
        $ok = curl_exec($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $contentType = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        $err = curl_error($ch);
        curl_close($ch);

        if ($tooLarge) return ['ok' => false, 'error' => 'Hedef sayfa önizleme için çok büyük.'];
        if ($ok === false && $err !== '') return ['ok' => false, 'error' => 'Hedef sayfadan veri alınamadı.'];
        if (in_array($http, [301, 302, 303, 307, 308], true) && $location !== '' && $hop < $maxRedirects) {
            $next = moni_preview_absolute_url($current, $location);
            if ($next === '') return ['ok' => false, 'error' => 'Hedef yönlendirmesi doğrulanamadı.'];
            $current = $next;
            continue;
        }
        if ($http < 200 || $http >= 400) return ['ok' => false, 'error' => 'Hedef sayfa önizleme için erişilebilir değil.'];
        return ['ok' => true, 'body' => $body, 'http' => $http, 'content_type' => $contentType, 'url' => $current];
    }
    return ['ok' => false, 'error' => 'Çok fazla hedef yönlendirmesi var.'];
}

function moni_preview_platform(string $url): array {
    $p = @parse_url($url);
    $host = strtolower(preg_replace('/^www\./i', '', (string)($p['host'] ?? '')));
    $path = trim((string)($p['path'] ?? ''), '/');
    $segments = $path === '' ? [] : array_values(array_filter(explode('/', $path), static fn($v) => $v !== ''));
    $first = rawurldecode((string)($segments[0] ?? ''));
    $second = strtolower(rawurldecode((string)($segments[1] ?? '')));
    $info = ['key' => 'web', 'label' => 'Web', 'kind' => 'link', 'kind_label' => 'Bağlantı', 'username' => '', 'icon' => 'fa-globe'];

    if ($host === 'instagram.com' || str_ends_with($host, '.instagram.com')) {
        $info = ['key' => 'instagram', 'label' => 'Instagram', 'kind' => 'link', 'kind_label' => 'Bağlantı', 'username' => '', 'icon' => 'fa-instagram'];
        $reserved = ['p','reel','reels','tv','stories','explore','accounts','direct','about','developer','legal','web','challenge'];
        if ($first !== '' && !in_array(strtolower($first), $reserved, true)) {
            $info['username'] = ltrim($first, '@');
            $info['kind'] = count($segments) === 1 ? 'profile' : 'link';
            $info['kind_label'] = count($segments) === 1 ? 'Profil' : 'Instagram bağlantısı';
        } elseif (in_array(strtolower($first), ['p','reel','reels','tv'], true)) {
            $info['kind'] = 'content'; $info['kind_label'] = strtolower($first) === 'p' ? 'Gönderi' : 'Video / Reels';
        } elseif (strtolower($first) === 'stories') {
            $info['kind'] = 'content'; $info['kind_label'] = 'Hikâye'; $info['username'] = ltrim((string)($segments[1] ?? ''), '@');
        }
    } elseif ($host === 'tiktok.com' || str_ends_with($host, '.tiktok.com')) {
        $info = ['key' => 'tiktok', 'label' => 'TikTok', 'kind' => 'link', 'kind_label' => 'Bağlantı', 'username' => '', 'icon' => 'fa-tiktok'];
        if (str_starts_with($first, '@')) {
            $info['username'] = ltrim($first, '@');
            $info['kind'] = $second === 'video' ? 'content' : 'profile';
            $info['kind_label'] = $second === 'video' ? 'Video' : 'Profil';
        }
    } elseif (in_array($host, ['x.com','twitter.com','mobile.twitter.com'], true)) {
        $info = ['key' => 'x', 'label' => 'X', 'kind' => 'link', 'kind_label' => 'Bağlantı', 'username' => '', 'icon' => 'fa-x-twitter'];
        $reserved = ['home','explore','search','i','settings','messages','notifications','compose','login','signup','intent','share'];
        if ($first !== '' && !in_array(strtolower($first), $reserved, true)) {
            $info['username'] = ltrim($first, '@');
            $info['kind'] = $second === 'status' ? 'content' : 'profile';
            $info['kind_label'] = $second === 'status' ? 'Gönderi' : 'Profil';
        }
    } elseif ($host === 'youtube.com' || str_ends_with($host, '.youtube.com') || $host === 'youtu.be') {
        $info = ['key' => 'youtube', 'label' => 'YouTube', 'kind' => 'link', 'kind_label' => 'Bağlantı', 'username' => '', 'icon' => 'fa-youtube'];
        if ($host === 'youtu.be' || strtolower($first) === 'watch' || strtolower($first) === 'shorts') {
            $info['kind'] = 'content'; $info['kind_label'] = strtolower($first) === 'shorts' ? 'Shorts' : 'Video';
        } elseif (str_starts_with($first, '@')) {
            $info['username'] = ltrim($first, '@'); $info['kind'] = 'profile'; $info['kind_label'] = 'Kanal';
        } elseif (in_array(strtolower($first), ['channel','c','user'], true) && !empty($segments[1])) {
            $info['username'] = rawurldecode((string)$segments[1]); $info['kind'] = 'profile'; $info['kind_label'] = 'Kanal';
        }
    } elseif ($host === 'threads.net' || $host === 'threads.com' || str_ends_with($host, '.threads.net')) {
        $info = ['key' => 'threads', 'label' => 'Threads', 'kind' => 'link', 'kind_label' => 'Bağlantı', 'username' => '', 'icon' => 'fa-at'];
        if (str_starts_with($first, '@')) { $info['username'] = ltrim($first, '@'); $info['kind'] = $second === 'post' ? 'content' : 'profile'; $info['kind_label'] = $second === 'post' ? 'Gönderi' : 'Profil'; }
    } elseif ($host === 'facebook.com' || str_ends_with($host, '.facebook.com') || $host === 'fb.com') {
        $info = ['key' => 'facebook', 'label' => 'Facebook', 'kind' => 'link', 'kind_label' => 'Bağlantı', 'username' => '', 'icon' => 'fa-facebook'];
        $reserved = ['watch','reel','reels','groups','photo','photos','share','marketplace','events','login','help'];
        if ($first !== '' && !in_array(strtolower($first), $reserved, true)) { $info['username'] = ltrim($first, '@'); $info['kind'] = 'profile'; $info['kind_label'] = 'Profil / Sayfa'; }
        if (in_array(strtolower($first), ['watch','reel','reels','photo','photos'], true)) { $info['kind'] = 'content'; $info['kind_label'] = 'İçerik'; }
    } elseif ($host === 'twitch.tv' || str_ends_with($host, '.twitch.tv')) {
        $info = ['key' => 'twitch', 'label' => 'Twitch', 'kind' => 'link', 'kind_label' => 'Bağlantı', 'username' => '', 'icon' => 'fa-twitch'];
        if ($first !== '' && !in_array(strtolower($first), ['videos','directory','downloads','jobs','p'], true)) { $info['username'] = ltrim($first, '@'); $info['kind'] = 'profile'; $info['kind_label'] = 'Kanal'; }
    } elseif ($host === 't.me' || $host === 'telegram.me') {
        $info = ['key' => 'telegram', 'label' => 'Telegram', 'kind' => 'profile', 'kind_label' => 'Kanal / Profil', 'username' => ltrim($first, '@'), 'icon' => 'fa-telegram'];
    } elseif ($host === 'linkedin.com' || str_ends_with($host, '.linkedin.com')) {
        $info = ['key' => 'linkedin', 'label' => 'LinkedIn', 'kind' => 'link', 'kind_label' => 'Bağlantı', 'username' => '', 'icon' => 'fa-linkedin'];
        if (in_array(strtolower($first), ['in','company'], true) && !empty($segments[1])) { $info['username'] = rawurldecode((string)$segments[1]); $info['kind'] = 'profile'; $info['kind_label'] = strtolower($first) === 'company' ? 'Şirket Sayfası' : 'Profil'; }
    }
    return $info;
}

function moni_preview_json_value(string $body, array $keys, string $scope = ''): string {
    $haystack = $scope !== '' ? $scope : $body;
    foreach ($keys as $key) {
        if (preg_match('/"' . preg_quote($key, '/') . '"\s*:\s*"((?:\\\\.|[^"\\\\])*)"/u', $haystack, $m)) {
            $decoded = json_decode('"' . $m[1] . '"', true);
            if (is_string($decoded) && trim($decoded) !== '') return trim($decoded);
        }
    }
    return '';
}

function moni_preview_profile_scope(string $body, string $username, string $platform): string {
    if ($username === '') return '';
    $needles = $platform === 'tiktok'
        ? ['"uniqueId":"' . $username . '"', '"uniqueId": "' . $username . '"']
        : ['"username":"' . $username . '"', '"username": "' . $username . '"'];
    foreach ($needles as $needle) {
        $pos = stripos($body, $needle);
        if ($pos !== false) {
            $start = max(0, $pos - 12000);
            return substr($body, $start, 36000);
        }
    }
    return '';
}

function moni_preview_metadata(string $body, string $baseUrl): array {
    $meta = [];
    $title = '';
    $canonical = '';
    $jsonLd = [];
    if (class_exists('DOMDocument')) {
        libxml_use_internal_errors(true);
        $dom = new DOMDocument();
        @$dom->loadHTML('<?xml encoding="utf-8" ?>' . $body);
        foreach ($dom->getElementsByTagName('meta') as $node) {
            $key = strtolower(trim((string)($node->getAttribute('property') ?: $node->getAttribute('name') ?: $node->getAttribute('itemprop'))));
            $val = trim((string)$node->getAttribute('content'));
            if ($key !== '' && $val !== '' && !isset($meta[$key])) $meta[$key] = $val;
        }
        $tt = $dom->getElementsByTagName('title');
        if ($tt->length) $title = trim((string)$tt->item(0)->textContent);
        foreach ($dom->getElementsByTagName('link') as $link) {
            if (strtolower((string)$link->getAttribute('rel')) === 'canonical') { $canonical = trim((string)$link->getAttribute('href')); break; }
        }
        foreach ($dom->getElementsByTagName('script') as $script) {
            if (strtolower((string)$script->getAttribute('type')) !== 'application/ld+json') continue;
            $raw = trim((string)$script->textContent);
            if ($raw === '') continue;
            $j = json_decode($raw, true);
            if (is_array($j)) $jsonLd[] = $j;
        }
        libxml_clear_errors();
    }
    return ['meta' => $meta, 'title' => $title, 'canonical' => $canonical, 'jsonld' => $jsonLd];
}

function moni_preview_jsonld_profile(array $items): array {
    $out = ['name' => '', 'username' => '', 'description' => '', 'image' => ''];
    $walk = function ($node) use (&$walk, &$out) {
        if (!is_array($node)) return;
        $type = strtolower((string)($node['@type'] ?? ''));
        if (in_array($type, ['person','profilepage','organization','channel'], true) || isset($node['alternateName'])) {
            if ($out['name'] === '' && is_string($node['name'] ?? null)) $out['name'] = trim((string)$node['name']);
            if ($out['username'] === '' && is_string($node['alternateName'] ?? null)) $out['username'] = ltrim(trim((string)$node['alternateName']), '@');
            if ($out['description'] === '' && is_string($node['description'] ?? null)) $out['description'] = trim((string)$node['description']);
            $img = $node['image'] ?? $node['thumbnailUrl'] ?? null;
            if ($out['image'] === '' && is_string($img)) $out['image'] = trim($img);
            if ($out['image'] === '' && is_array($img)) {
                $candidate = $img['url'] ?? ($img[0] ?? '');
                if (is_string($candidate)) $out['image'] = trim($candidate);
            }
        }
        foreach ($node as $v) if (is_array($v)) $walk($v);
    };
    foreach ($items as $item) $walk($item);
    return $out;
}

function moni_preview_clean_profile_title(string $title, array $platform, string &$displayName, string &$username): void {
    $title = trim(html_entity_decode($title, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    if ($title === '') return;
    $patterns = [
        '/^(.+?)\s*\(@([^\)]+)\)\s*[•|\/\-]/u',
        '/^(.+?)\s*\(@([^\)]+)\)/u',
        '/^(.+?)\s*\(@([^\)]+)\)\s*\|\s*TikTok/iu',
    ];
    foreach ($patterns as $re) {
        if (preg_match($re, $title, $m)) {
            if ($displayName === '') $displayName = trim($m[1]);
            if ($username === '') $username = ltrim(trim($m[2]), '@');
            return;
        }
    }
    $label = preg_quote((string)($platform['label'] ?? ''), '/');
    $clean = preg_replace('/\s*[\-|•|]\s*' . $label . '.*$/iu', '', $title);
    if ($displayName === '' && is_string($clean) && trim($clean) !== '' && mb_strlen(trim($clean), 'UTF-8') < 120) $displayName = trim($clean);
}

function moni_target_preview(PDO $db, string $url): array {
    if (!moni_growth_plugin_enabled($db, 'target_preview')) return ['ok' => false, 'error' => 'Hedef önizleme eklentisi kapalı.'];
    $url = trim($url);
    if ($url === '' || strlen($url) > 1500) return ['ok' => false, 'error' => 'Geçerli bir hedef bağlantısı girin.'];
    if (!preg_match('#^https?://#i', $url)) $url = 'https://' . ltrim($url, '/');
    $p = @parse_url($url);
    $scheme = strtolower((string)($p['scheme'] ?? ''));
    $host = (string)($p['host'] ?? '');
    if (!in_array($scheme, ['http', 'https'], true) || $host === '' || !empty($p['user']) || !empty($p['pass'])) {
        return ['ok' => false, 'error' => 'Geçerli bir HTTP/HTTPS hedef bağlantısı girin.'];
    }
    return ['ok' => true, 'host' => $host, 'url' => $url, 'mode' => 'browser_iframe'];
}
