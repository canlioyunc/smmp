<?php
/**
 * Yalnız ana sayfaya özel arayüz motoru.
 * Global tema, kullanıcı paneli ve admin paneli düzenine dokunmaz.
 */
require_once __DIR__ . '/MoniHomepageTranslations.php';

if (!function_exists('moni_home_hex')) {
function moni_home_hex($value, string $fallback): string {
    $value=trim((string)$value);
    return preg_match('/^#[0-9a-fA-F]{6}$/',$value) ? $value : $fallback;
}
function moni_home_sanitize_css(string $css): string {
    $css=strip_tags($css);
    $css=preg_replace('/@import\b[^;]*;?/i','',$css);
    $css=preg_replace('/expression\s*\(|javascript\s*:|behavior\s*:|-moz-binding\s*:/i','',$css);
    return mb_substr($css,0,50000,'UTF-8');
}
function moni_home_safe_url($value, string $fallback='#'): string {
    $value=trim((string)$value);
    if($value==='') return $fallback;
    if(str_starts_with($value,'/') || str_starts_with($value,'#')) return $value;
    if(defined('SITE_URL') && str_starts_with($value,rtrim(SITE_URL,'/'))) return $value;
    if(preg_match('#^https://#i',$value)) return $value;
    if(preg_match('#^[a-z0-9][a-z0-9/_\-.?=&%#]*$#i',$value)) return rtrim(SITE_URL,'/').'/'.ltrim($value,'/');
    return $fallback;
}
function moni_home_table_ready(PDO $db): bool {
    try{$db->query('SELECT 1 FROM homepage_interfaces LIMIT 1');return true;}catch(Throwable $e){return false;}
}
function moni_home_default_interface(): array {
    return [
      'id'=>0,'name'=>'Nebula Pro','slug'=>'nebula-pro','layout_key'=>'nebula','description'=>'Koyu ve modern sosyal medya hizmet vitrini',
      'is_enabled'=>1,'is_active'=>1,'background_color'=>'#070B18','surface_color'=>'#10172B','surface_alt_color'=>'#151E36',
      'text_color'=>'#F8FAFC','muted_color'=>'#9BA8C7','primary_color'=>'#7C5CFC','secondary_color'=>'#00D084','accent_color'=>'#22D3EE',
      'button_text_color'=>'#FFFFFF','header_bg_color'=>'#080D1B','header_text_color'=>'#F8FAFC','border_color'=>'#253151',
      'hero_badge'=>'Hızlı, güvenli ve kolay sipariş','hero_title'=>'Sosyal medya hizmetlerini tek yerden yönetin','hero_description'=>'Instagram, TikTok, YouTube ve daha fazlası için güncel hizmetleri keşfedin; hesabınızı oluşturup hemen sipariş verin.',
      'primary_cta_text'=>'Ücretsiz Başla','primary_cta_url'=>'/register.php','secondary_cta_text'=>'Servisleri İncele','secondary_cta_url'=>'/services.php',
      'hero_image'=>'','secondary_image'=>'','background_image'=>'','announcement_enabled'=>0,'announcement_text'=>'','announcement_cta_text'=>'','announcement_cta_url'=>'',
      'options_json'=>'{}','custom_css'=>''
    ];
}
function moni_home_get_active(PDO $db): array {
    if(!moni_home_table_ready($db)) return moni_home_default_interface();
    try{
      $q=$db->query("SELECT * FROM homepage_interfaces WHERE is_enabled=1 AND is_active=1 ORDER BY id ASC LIMIT 1");
      $r=$q->fetch(PDO::FETCH_ASSOC);
      if(!$r){$q=$db->query("SELECT * FROM homepage_interfaces WHERE is_enabled=1 ORDER BY sort_order,id LIMIT 1");$r=$q->fetch(PDO::FETCH_ASSOC);}
      return $r ?: moni_home_default_interface();
    }catch(Throwable $e){return moni_home_default_interface();}
}
function moni_home_options(array $ui): array {
    $o=json_decode((string)($ui['options_json']??'{}'),true);
    return is_array($o)?$o:[];
}
function moni_home_enabled(array $ui,string $key,bool $default=true): bool {
    $o=moni_home_options($ui); if(!array_key_exists($key,$o)) return $default; return !empty($o[$key]);
}
function moni_home_head_css(array $ui): string {
    $layout=preg_replace('/[^a-z0-9_-]/i','',(string)($ui['layout_key']??'nebula')) ?: 'nebula';
    $vars=[
      '--hp-bg'=>moni_home_hex($ui['background_color']??'', '#070B18'),
      '--hp-surface'=>moni_home_hex($ui['surface_color']??'', '#10172B'),
      '--hp-surface-2'=>moni_home_hex($ui['surface_alt_color']??'', '#151E36'),
      '--hp-text'=>moni_home_hex($ui['text_color']??'', '#F8FAFC'),
      '--hp-muted'=>moni_home_hex($ui['muted_color']??'', '#9BA8C7'),
      '--hp-primary'=>moni_home_hex($ui['primary_color']??'', '#7C5CFC'),
      '--hp-secondary'=>moni_home_hex($ui['secondary_color']??'', '#00D084'),
      '--hp-accent'=>moni_home_hex($ui['accent_color']??'', '#22D3EE'),
      '--hp-button-text'=>moni_home_hex($ui['button_text_color']??'', '#FFFFFF'),
      '--hp-header'=>moni_home_hex($ui['header_bg_color']??'', '#080D1B'),
      '--hp-header-text'=>moni_home_hex($ui['header_text_color']??'', '#F8FAFC'),
      '--hp-border'=>moni_home_hex($ui['border_color']??'', '#253151'),
    ];
    $bg=moni_home_asset($ui,'background_image');
    $vars['--hp-bg-image']=$bg!=='' ? "url('".htmlspecialchars($bg,ENT_QUOTES,'UTF-8')."')" : 'none';
    $css='.hp-active{'.implode('',array_map(fn($k,$v)=>$k.':'.$v.';',array_keys($vars),$vars)).'}';
    $custom=moni_home_sanitize_css(trim((string)($ui['custom_css']??'')));
    if($custom!=='') $css.="\n".$custom;
    return $css;
}
function moni_home_body_attrs(array $ui): string {
    $layout=preg_replace('/[^a-z0-9_-]/i','',(string)($ui['layout_key']??'nebula')) ?: 'nebula';
    return ' class="hp-active hp-layout-'.htmlspecialchars($layout,ENT_QUOTES,'UTF-8').'" data-home-interface="'.htmlspecialchars((string)($ui['slug']??''),ENT_QUOTES,'UTF-8').'"';
}
function moni_home_asset(array $ui,string $key): string {
    $v=trim((string)($ui[$key]??'')); if($v==='') return '';
    if(str_starts_with($v,'/')) return rtrim(SITE_URL,'/').$v;
    if(preg_match('#^https://#i',$v)) return $v;
    if(preg_match('#^[a-z0-9][a-z0-9/_\-.]*$#i',$v)) return rtrim(SITE_URL,'/').'/'.ltrim($v,'/');
    return '';
}
function moni_home_collect_data(PDO $db): array {
    $stats=['orders'=>0,'users'=>0,'services'=>0,'categories'=>0]; $cats=[];$popular=[];$featured=[];$reviews=[];$blogs=[];$popup=null;
    try{$stats['orders']=(int)$db->query("SELECT COUNT(*) FROM orders")->fetchColumn();}catch(Throwable $e){}
    try{$stats['users']=(int)$db->query("SELECT COUNT(*) FROM users WHERE status='active'")->fetchColumn();}catch(Throwable $e){}
    try{$stats['services']=(int)$db->query("SELECT COUNT(*) FROM services WHERE status='active'")->fetchColumn();}catch(Throwable $e){}
    try{$stats['categories']=(int)$db->query("SELECT COUNT(*) FROM categories WHERE status='active'")->fetchColumn();}catch(Throwable $e){}
    try{$cats=$db->query("SELECT c.id,c.name,c.icon,c.icon_color,COUNT(s.id) service_count,MIN(NULLIF(s.price_per_1000,0)) min_price FROM categories c LEFT JOIN services s ON s.category_id=c.id AND s.status='active' WHERE c.status='active' GROUP BY c.id ORDER BY c.sort_order,c.name LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){}
    try{$popular=$db->query("SELECT s.id,s.name,s.price_per_1000,s.min_quantity,s.max_quantity,s.refill,s.average_time,c.name category_name,c.icon category_icon,c.icon_color FROM services s JOIN categories c ON c.id=s.category_id WHERE s.status='active' AND c.status='active' ORDER BY s.total_orders DESC,s.sort_order,s.id LIMIT 8")->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){}
    try{$featured=$db->query("SELECT hs.id homepage_service_id,hs.custom_title,hs.custom_description,hs.custom_icon,hs.custom_icon_style,hs.custom_price_text,hs.badge_text,hs.badge_color,s.id,s.name service_name,s.price_per_1000,s.min_quantity,s.max_quantity,s.refill,s.average_time,c.name category_name,c.icon category_icon,c.icon_color FROM homepage_services hs JOIN services s ON s.id=hs.service_id JOIN categories c ON c.id=s.category_id WHERE hs.status='active' AND s.status='active' AND c.status='active' ORDER BY hs.sort_order,hs.id LIMIT 8")->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){}
    try{$reviews=$db->query("SELECT sr.rating,sr.comment,sr.created_at,u.username,s.name service_name FROM service_reviews sr JOIN users u ON u.id=sr.user_id JOIN services s ON s.id=sr.service_id WHERE sr.status='approved' AND sr.comment IS NOT NULL AND sr.comment<>'' ORDER BY sr.id DESC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){}
    try{$blogs=$db->query("SELECT title,slug,excerpt,content,featured_image,created_at FROM blog_posts WHERE is_active=1 ORDER BY created_at DESC LIMIT 3")->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){}
    try{$popup=$db->query("SELECT id,title,media_type,media_path,link_url FROM popups WHERE is_active=1 ORDER BY id DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC)?:null;}catch(Throwable $e){}
    return compact('stats','cats','popular','featured','reviews','blogs','popup');
}
function moni_home_icon($row,string $fallback='fas fa-bolt'): string {
    $icon=trim((string)($row['icon']??$row['category_icon']??''));
    if($icon==='') return $fallback;
    return preg_match('/^(fa[srbld]?|fab)\s+fa-[a-z0-9-]+$/i',$icon)?$icon:$fallback;
}
function moni_home_money($value): string {
    $language=function_exists('getCurrentLanguage') ? (string)getCurrentLanguage() : 'tr';
    $decimal=$language==='tr' ? ',' : '.';$thousands=$language==='tr' ? '.' : ',';
    return ($GLOBALS['siteSettings']['currency_symbol']??'₺').number_format((float)$value,2,$decimal,$thousands);
}
function moni_home_date($value): string {
    $timestamp=strtotime((string)$value);if(!$timestamp)return '';
    return (function_exists('getCurrentLanguage') && getCurrentLanguage()==='tr') ? date('d.m.Y',$timestamp) : date('M j, Y',$timestamp);
}

function moni_home_t(string $key,string $fallback,array $replacements=[]): string {
    $text=function_exists('__') ? (string)__($key,$replacements) : $key;
    if($text===$key || trim($text)===''){
        $language=function_exists('getCurrentLanguage') ? (string)getCurrentLanguage() : 'tr';
        $text=function_exists('moni_home_builtin_translation') ? (moni_home_builtin_translation($language,$key)??$fallback) : $fallback;
        foreach($replacements as $placeholder=>$value){$text=str_replace(':'.$placeholder,(string)$value,$text);}
    }
    return clean($text);
}

function moni_home_translation_key(array $ui,string $field): string {
    $identity=(string)($ui['slug']??$ui['layout_key']??'default');
    $identity=strtolower(trim(preg_replace('/[^a-z0-9]+/i','_',$identity),'_')) ?: 'default';
    $field=strtolower(trim(preg_replace('/[^a-z0-9]+/i','_',$field),'_'));
    return 'homepage_interface_'.$identity.'_'.$field;
}

function moni_home_render_announcement(array $ui): void {
 if(empty($ui['announcement_enabled'])||trim((string)($ui['announcement_text']??''))==='')return;
 $txt=moni_home_title($ui,'announcement_text',(string)$ui['announcement_text']);$cta=trim((string)($ui['announcement_cta_text']??''));$url=moni_home_safe_url($ui['announcement_cta_url']??'','#');
 echo '<div class="hp-announcement"><div class="hp-shell"><span><i class="fas fa-sparkles"></i> '.$txt.'</span>'.($cta!==''?'<a href="'.clean($url).'">'.moni_home_title($ui,'announcement_cta_text',$cta).' <i class="fas fa-arrow-right"></i></a>':'').'</div></div>';
}
function moni_home_title(array $ui,string $field,string $fallback): string { $v=trim((string)($ui[$field]??''));return moni_home_t(moni_home_translation_key($ui,$field),$v!==''?$v:$fallback); }

function moni_home_render_dashboard_mock(array $d): void { $s=$d['stats']; ?>
<div class="hp-dashboard-mock" aria-label="<?=moni_home_t('homepage_panel_preview','Sipariş ekranı örneği')?>">
 <div class="hp-mock-top"><span><i class="fas fa-wand-magic-sparkles"></i> <?=clean((string)getSetting('site_name',getSetting('name','SMM Panel')))?> </span><div><i></i><i></i><i></i></div></div>
 <div class="hp-mock-grid"><aside aria-hidden="true"><b><i class="fas fa-table-cells-large"></i></b><b><i class="fas fa-plus"></i></b><b><i class="fas fa-bag-shopping"></i></b><b><i class="fas fa-wallet"></i></b><b><i class="fas fa-headset"></i></b></aside><section>
   <div class="hp-mock-greeting"><div><small><?=moni_home_t('homepage_workspace','Hesabım')?></small><span><?=moni_home_t('dashboard','Kontrol Paneli')?></span></div><em><i class="fas fa-lock"></i> <?=moni_home_t('homepage_secure','Güvenli')?></em></div>
   <div class="hp-mock-kpis"><div><i class="fas fa-layer-group"></i><strong><?=number_format($s['services'])?></strong><small><?=moni_home_t('homepage_active_services','Aktif servis')?></small></div><div><i class="fas fa-bolt"></i><strong><?=moni_home_t('homepage_automatic','7/24')?></strong><small><?=moni_home_t('homepage_order_flow','Sipariş verebilirsiniz')?></small></div><div><i class="fas fa-chart-line"></i><strong><?=moni_home_t('homepage_live','Canlı')?></strong><small><?=moni_home_t('homepage_order_tracking','Sipariş takibi')?></small></div></div>
   <div class="hp-mock-chart"><div><span></span><span></span><span></span><span></span><span></span><span></span></div><strong><?=moni_home_t('homepage_order_activity','Sipariş hareketleri')?></strong><small><?=moni_home_t('homepage_single_screen_tracking','Tek ekranda düzenli takip')?></small></div>
   <div class="hp-mock-order"><div><span></span><span></span></div><button type="button"><?=moni_home_t('homepage_create_new_order','Yeni Sipariş Oluştur')?></button></div>
 </section></div>
</div><?php }

function moni_home_render_platforms(): void { ?>
<div class="hp-platforms" aria-label="<?=moni_home_t('homepage_social_platforms','Sosyal medya platformları')?>"><span><i class="fab fa-instagram"></i> Instagram</span><span><i class="fab fa-tiktok"></i> TikTok</span><span><i class="fab fa-youtube"></i> YouTube</span><span><i class="fab fa-x-twitter"></i> X</span><span><i class="fab fa-facebook-f"></i> Facebook</span></div><?php }

function moni_home_default_visual(string $layout): string {
 $map=['nebula'=>'moni-social-services-v2.png','neon'=>'moni-social-services-v2.png','ivory'=>'moni-creator-hero.png','pulse'=>'moni-creator-hero.png','editorial'=>'moni-creator-hero.png','aurora'=>'moni-market-orbit.png','market'=>'moni-market-orbit.png','glass'=>'moni-glass-mobile.png'];
 return rtrim(SITE_URL,'/').'/assets/images/homepage/'.($map[$layout]??$map['nebula']);
}

function moni_home_render_visual(array $ui,array $d,string $layout,string $extra=''): void {
 $hero=moni_home_asset($ui,'hero_image');$secondary=moni_home_asset($ui,'secondary_image');$src=$hero?:moni_home_default_visual($layout); ?>
 <div class="hp-visual-wrap <?=clean($extra)?>"><img class="hp-hero-upload<?=$hero?' is-uploaded':''?>" src="<?=clean($src)?>" alt="<?=moni_home_t('homepage_hero_visual_alt','Sosyal medya hizmetleri görseli')?>"><?php if($secondary):?><img class="hp-secondary-upload" src="<?=clean($secondary)?>" alt="<?=moni_home_t('homepage_secondary_visual_alt','Ek tanıtım görseli')?>"><?php endif;?><div class="hp-visual-sheen"></div></div><?php
}

function moni_home_render_hero(array $ui,array $d): void {
 $layout=$ui['layout_key']??'nebula';
 $badge=moni_home_title($ui,'hero_badge','Hızlı, güvenli ve kolay sipariş');
 $title=moni_home_title($ui,'hero_title','Sosyal medya hizmetlerini tek yerden yönetin');
 $desc=moni_home_title($ui,'hero_description','Instagram, TikTok, YouTube ve daha fazlası için güncel hizmetleri keşfedin; hesabınızı oluşturup hemen sipariş verin.');
 $ptext=moni_home_title($ui,'primary_cta_text','Ücretsiz Başla'); $purl=moni_home_safe_url($ui['primary_cta_url']??'','/register.php');
 $stext=moni_home_title($ui,'secondary_cta_text','Servisleri İncele'); $surl=moni_home_safe_url($ui['secondary_cta_url']??'','/services.php');
 if($layout==='ivory'){ ?>
<section class="hp-hero hp-hero-ivory"><div class="hp-decor-dots"></div><div class="hp-shell hp-hero-grid"><div class="hp-hero-copy"><span class="hp-kicker"><i class="fas fa-circle-check"></i> <?=$badge?></span><h1><?=$title?></h1><p><?=$desc?></p><div class="hp-actions"><a class="hp-btn primary" href="<?=clean($purl)?>"><?=$ptext?> <i class="fas fa-arrow-right"></i></a><a class="hp-btn ghost" href="<?=clean($surl)?>"><?=$stext?></a></div><div class="hp-inline-trust"><span><i class="fas fa-shield-halved"></i> <?=moni_home_t('homepage_protected_account','Korunan hesap')?></span><span><i class="fas fa-receipt"></i> <?=moni_home_t('homepage_transparent_activity','Şeffaf hareketler')?></span><span><i class="fas fa-headset"></i> <?=moni_home_t('homepage_support_center','Destek merkezi')?></span></div></div><div class="hp-ivory-collage"><?php moni_home_render_visual($ui,$d,$layout);?><div class="hp-quick-card"><div class="hp-quick-head"><div><small><?=moni_home_t('homepage_quick_discovery','Hızlı keşif')?></small><h3><?=moni_home_t('homepage_find_service_fast','Doğru servise birkaç adımda ulaşın')?></h3></div><i class="fas fa-magnifying-glass"></i></div><div class="hp-quick-meta"><span><b><?=number_format($d['stats']['services'])?></b> <?=moni_home_t('homepage_services_lower','servis')?></span><span><b><?=number_format($d['stats']['categories'])?></b> <?=moni_home_t('homepage_categories_lower','kategori')?></span></div><a href="<?=SITE_URL?>/services.php" class="hp-btn primary wide"><?=moni_home_t('homepage_view_catalog','Kataloğu Görüntüle')?></a></div></div></div><div class="hp-shell"><?php moni_home_render_platforms();?></div></section>
<?php } elseif($layout==='pulse'){ ?>
<section class="hp-hero hp-hero-pulse"><div class="hp-pulse-blob one"></div><div class="hp-pulse-blob two"></div><div class="hp-shell"><div class="hp-pulse-badge"><i></i><?=$badge?></div><h1><?=$title?></h1><p><?=$desc?></p><div class="hp-actions center"><a class="hp-btn primary" href="<?=clean($purl)?>"><?=$ptext?> <i class="fas fa-arrow-right"></i></a><a class="hp-btn ghost" href="<?=clean($surl)?>"><?=$stext?></a></div><div class="hp-pulse-stage"><?php moni_home_render_visual($ui,$d,$layout);?><div class="hp-float-card fc-one"><i class="fas fa-bolt"></i><div><b><?=moni_home_t('homepage_fast_flow','Hızlı akış')?></b><small><?=moni_home_t('homepage_fast_flow_desc','Daha az adım, daha net takip')?></small></div></div><div class="hp-float-card fc-two"><i class="fas fa-shield"></i><div><b><?=moni_home_t('homepage_controlled','Kontrollü')?></b><small><?=moni_home_t('homepage_controlled_desc','Hesap ve işlem güvenliği')?></small></div></div><div class="hp-float-card fc-three"><i class="fas fa-heart"></i><div><b><?=moni_home_t('homepage_easy_use','Kolay kullanım')?></b><small><?=moni_home_t('homepage_easy_use_desc','Yeni kullanıcılar için sade')?></small></div></div></div></div></section>
<?php } elseif($layout==='aurora'){ ?>
<section class="hp-hero hp-hero-aurora"><div class="hp-aurora-light"></div><div class="hp-shell hp-hero-grid"><div class="hp-hero-copy"><span class="hp-kicker"><i class="fas fa-wand-magic-sparkles"></i> <?=$badge?></span><h1><?=$title?></h1><p><?=$desc?></p><div class="hp-actions"><a class="hp-btn primary" href="<?=clean($purl)?>"><?=$ptext?> <i class="fas fa-arrow-right"></i></a><a class="hp-btn ghost" href="<?=clean($surl)?>"><?=$stext?></a></div><div class="hp-mini-proof"><span><b>01</b> <?=moni_home_t('homepage_quick_setup','Hızlı kayıt')?></span><span><b>02</b> <?=moni_home_t('homepage_simple_operation','Kolay sipariş')?></span><span><b>03</b> <?=moni_home_t('homepage_growth_with_api','Anlık takip')?></span></div></div><div class="hp-aurora-bento"><div class="big"><?php moni_home_render_visual($ui,$d,$layout);?></div><div class="mini api"><i class="fas fa-layer-group"></i><b><?=moni_home_t('homepage_popular_services','Popüler Servisler')?></b><span><?=moni_home_t('homepage_integration_ready','Her ihtiyaca uygun seçenekler')?></span><em>→</em></div><div class="mini support"><i class="fas fa-headset"></i><b><?=moni_home_t('support','Destek')?></b><span><?=moni_home_t('homepage_request_management','Hızlı destek')?></span><em>→</em></div></div></div></section>
<?php } elseif($layout==='glass'){ ?>
<section class="hp-hero hp-hero-glass"><div class="hp-glow g1"></div><div class="hp-glow g2"></div><div class="hp-glow g3"></div><div class="hp-shell hp-hero-grid"><div class="hp-hero-copy"><span class="hp-kicker"><i class="fas fa-gem"></i> <?=$badge?></span><h1><?=$title?></h1><p><?=$desc?></p><div class="hp-actions"><a class="hp-btn primary" href="<?=clean($purl)?>"><?=$ptext?> <i class="fas fa-arrow-right"></i></a><a class="hp-btn ghost" href="<?=clean($surl)?>"><?=$stext?></a></div><div class="hp-glass-pills"><span><i class="fas fa-bolt"></i> <?=moni_home_t('homepage_fast_flow','Hızlı sipariş')?></span><span><i class="fas fa-wallet"></i> <?=moni_home_t('homepage_secure_transaction','Güvenli ödeme')?></span><span><i class="fas fa-chart-line"></i> <?=moni_home_t('homepage_order_tracking','Sipariş takibi')?></span><span><i class="fas fa-headset"></i> <?=moni_home_t('homepage_support_center','Destek merkezi')?></span></div></div><?php moni_home_render_visual($ui,$d,$layout,'hp-glass-window');?></div></section>
<?php } elseif($layout==='editorial'){ ?>
<section class="hp-hero hp-hero-editorial"><div class="hp-shell"><div class="hp-editorial-top"><span><?=$badge?></span><span><?=clean((string)getSetting('site_name',getSetting('name','SMM Panel')))?> / <?=moni_home_t('homepage_social_media_services','SOSYAL MEDYA HİZMETLERİ')?></span></div><div class="hp-editorial-grid"><div><h1><?=$title?></h1><div class="hp-editorial-lower"><p><?=$desc?></p><div class="hp-actions"><a class="hp-btn primary" href="<?=clean($purl)?>"><?=$ptext?> <i class="fas fa-arrow-right"></i></a><a class="hp-btn ghost" href="<?=clean($surl)?>"><?=$stext?></a></div></div></div><?php moni_home_render_visual($ui,$d,$layout);?></div><div class="hp-editorial-showcase"><span>01 / <?=moni_home_t('homepage_service_discovery','Servis keşfi')?></span><span>02 / <?=moni_home_t('homepage_secure_balance','Güvenli bakiye')?></span><span>03 / <?=moni_home_t('homepage_order_tracking','Sipariş takibi')?></span><span>04 / <?=moni_home_t('homepage_support_center','Destek merkezi')?></span></div></div></section>
<?php } elseif($layout==='market'){ ?>
<section class="hp-hero hp-hero-market"><div class="hp-shell hp-hero-grid"><div class="hp-hero-copy"><span class="hp-kicker"><i class="fas fa-store"></i> <?=$badge?></span><h1><?=$title?></h1><p><?=$desc?></p><a class="hp-search-box" href="<?=SITE_URL?>/services.php"><i class="fas fa-magnifying-glass"></i><span><?=moni_home_t('homepage_search_services','Instagram, TikTok, YouTube veya servis ara...')?></span><b><?=moni_home_t('search','Ara')?></b></a><div class="hp-actions"><a class="hp-btn primary" href="<?=clean($purl)?>"><?=$ptext?> <i class="fas fa-arrow-right"></i></a><a class="hp-btn ghost" href="<?=clean($surl)?>"><?=$stext?></a></div></div><div class="hp-market-visual"><?php moni_home_render_visual($ui,$d,$layout);?><div class="hp-market-stack"><div class="hp-market-card main"><span><?=moni_home_t('homepage_live_catalog','Canlı katalog')?></span><strong><?=number_format($d['stats']['services'])?> <?=moni_home_t('homepage_active_services','aktif servis')?></strong><small><?=moni_home_t('homepage_catalog_details','Güncel fiyat, limit ve servis detayları')?></small></div><div class="hp-market-card"><i class="fas fa-wallet"></i><div><b><?=moni_home_t('balance','Bakiye')?></b><small><?=moni_home_t('homepage_single_center_management','Tek merkezden yönetim')?></small></div></div><div class="hp-market-card"><i class="fas fa-rotate"></i><div><b><?=moni_home_t('homepage_order_tracking','Sipariş Takibi')?></b><small><?=moni_home_t('homepage_status_view','Durum görünümü')?></small></div></div></div></div></div><div class="hp-shell"><?php moni_home_render_platforms();?></div></section>
<?php } elseif($layout==='neon'){ ?>
<section class="hp-hero hp-hero-neon"><div class="hp-neon-grid"></div><div class="hp-shell hp-hero-grid"><div class="hp-hero-copy"><span class="hp-kicker"><i class="fas fa-sparkles"></i> <?=$badge?></span><h1><?=$title?></h1><p><?=$desc?></p><div class="hp-actions"><a class="hp-btn primary" href="<?=clean($purl)?>"><?=$ptext?> <i class="fas fa-arrow-right"></i></a><a class="hp-btn ghost" href="<?=clean($surl)?>"><?=$stext?></a></div><div class="hp-neon-metrics"><span><b><?=number_format($d['stats']['services'])?></b> <?=moni_home_t('homepage_services_lower','servis')?></span><span><b><?=number_format($d['stats']['categories'])?></b> <?=moni_home_t('homepage_categories_lower','kategori')?></span><span><b>7/24</b> <?=moni_home_t('homepage_order_flow','sipariş')?></span></div></div><div class="hp-neon-orbit"><?php moni_home_render_visual($ui,$d,$layout);?><i class="orb o1 fab fa-instagram"></i><i class="orb o2 fab fa-youtube"></i><i class="orb o3 fab fa-tiktok"></i><i class="orb o4 fas fa-bolt"></i></div></div></section>
<?php } else { ?>
<section class="hp-hero hp-hero-nebula"><div class="hp-nebula-light"></div><div class="hp-shell hp-hero-grid"><div class="hp-hero-copy"><span class="hp-kicker"><i class="fas fa-shield-halved"></i> <?=$badge?></span><h1><?=$title?></h1><p><?=$desc?></p><div class="hp-actions"><a class="hp-btn primary" href="<?=clean($purl)?>"><?=$ptext?> <i class="fas fa-arrow-right"></i></a><a class="hp-btn ghost" href="<?=clean($surl)?>"><?=$stext?></a></div><div class="hp-inline-trust"><span><i class="fas fa-bolt"></i> <?=moni_home_t('homepage_smooth_order','Akıcı sipariş')?></span><span><i class="fas fa-shield"></i> <?=moni_home_t('homepage_secure_transaction','Güvenli işlem')?></span><span><i class="fas fa-headset"></i> <?=moni_home_t('homepage_support_center','Destek merkezi')?></span></div></div><div class="hp-nebula-visual"><?php moni_home_render_visual($ui,$d,$layout);?><div class="hp-floating-stat top"><i class="fas fa-layer-group"></i><span><b><?=number_format($d['stats']['services'])?></b> <?=moni_home_t('homepage_active_services','aktif servis')?></span></div><div class="hp-floating-stat bottom"><i class="fas fa-chart-line"></i><span><b><?=moni_home_t('homepage_live','Canlı')?></b> <?=moni_home_t('homepage_order_tracking','sipariş takibi')?></span></div></div></div><div class="hp-shell"><?php moni_home_render_platforms();?></div></section>
<?php }
}
function moni_home_section_stats(array $d): void { $s=$d['stats']; ?>
<section class="hp-stats"><div class="hp-shell hp-stats-grid"><div><i class="fas fa-layer-group"></i><span><b><?=number_format($s['services'])?></b><?=moni_home_t('homepage_active_services','Aktif Servis')?></span></div><div><i class="fas fa-table-cells-large"></i><span><b><?=number_format($s['categories'])?></b><?=moni_home_t('homepage_categories','Kategori')?></span></div><div><i class="fas fa-bag-shopping"></i><span><b><?=number_format($s['orders'])?></b><?=moni_home_t('homepage_order_records','Sipariş Kaydı')?></span></div><div><i class="fas fa-users"></i><span><b><?=number_format($s['users'])?></b><?=moni_home_t('homepage_active_accounts','Aktif Hesap')?></span></div></div></section><?php }
function moni_home_section_categories(array $d): void { if(!$d['cats'])return; ?>
<section class="hp-section hp-categories"><div class="hp-shell"><div class="hp-heading"><div><span><?=moni_home_t('homepage_service_catalog','Servis Kataloğu')?></span><h2><?=moni_home_t('homepage_discover_by_platform','Platformlara göre hızlı keşif')?></h2><p><?=moni_home_t('homepage_categories_desc','Aktif kategorileri güncel servis kataloğundan görüntüleyin.')?></p></div><a href="<?=SITE_URL?>/services.php"><?=moni_home_t('homepage_view_all','Tümünü Gör')?> <i class="fas fa-arrow-right"></i></a></div><div class="hp-category-grid"><?php foreach($d['cats'] as $c):?><a class="hp-category-card" href="<?=SITE_URL?>/services.php?category=<?=intval($c['id'])?>"><div class="hp-category-icon" style="--cat:<?=clean($c['icon_color']?:'#7C5CFC')?>"><i class="<?=clean(moni_home_icon($c,'fas fa-hashtag'))?>"></i></div><div><strong><?=clean($c['name'])?></strong><span><?=number_format((int)$c['service_count'])?> <?=moni_home_t('homepage_services_lower','servis')?><?php if((float)$c['min_price']>0):?> · <?=moni_home_t('homepage_from_price',':price’den',['price'=>moni_home_money($c['min_price'])])?><?php endif;?></span></div><i class="fas fa-arrow-up-right-from-square"></i></a><?php endforeach;?></div></div></section><?php }
function moni_home_section_features(array $d=[]): void { $items=[['fa-bolt',moni_home_t('homepage_feature_fast_title','Hızlı Sipariş Akışı'),moni_home_t('homepage_feature_fast_desc','Kategori, servis, bağlantı ve miktar adımlarını sade bir akışta tamamlayın.')],['fa-shield-halved',moni_home_t('homepage_feature_security_title','Hesap Güvenliği'),moni_home_t('homepage_feature_security_desc','Hesabınızı korumaya yardımcı güvenlik kontrolleriyle işlemlerinizi güvenle yönetin.')],['fa-layer-group',moni_home_t('homepage_feature_api_title','Geniş Servis Seçeneği'),moni_home_t('homepage_feature_api_desc','Instagram, TikTok, YouTube ve diğer platformlar için güncel hizmetleri keşfedin.')],['fa-wallet',moni_home_t('homepage_feature_balance_title','Bakiye Yönetimi'),moni_home_t('homepage_feature_balance_desc','Ödeme ve bakiye hareketlerini tek panelden takip edin.')],['fa-chart-line',moni_home_t('homepage_feature_tracking_title','Şeffaf Takip'),moni_home_t('homepage_feature_tracking_desc','Siparişlerin durumunu ve işlem geçmişini tek ekranda görüntüleyin.')],['fa-headset',moni_home_t('homepage_feature_support_title','Departmanlı Destek'),moni_home_t('homepage_feature_support_desc','Talebinizi doğru ekibe iletin ve görüşme geçmişini koruyun.')]];?>
<section class="hp-section hp-features"><div class="hp-shell"><div class="hp-heading"><div><span><?=moni_home_t('homepage_why_moni','Neden bu panel?')?></span><h2><?=moni_home_t('homepage_features_title','Sosyal medya hizmetlerinde ihtiyacınız olan her şey')?></h2><p><?=moni_home_t('homepage_features_desc','Kolay sipariş, güvenli ödeme, şeffaf takip ve ihtiyaç duyduğunuzda ulaşabileceğiniz destek.')?></p></div></div><div class="hp-feature-grid"><?php foreach($items as $i=>$x):?><article class="hp-feature-card"><div class="hp-num">0<?=$i+1?></div><i class="fas <?=$x[0]?>"></i><h3><?=$x[1]?></h3><p><?=$x[2]?></p></article><?php endforeach;?></div></div></section><?php }
function moni_home_section_process(array $d=[]): void { ?>
<section class="hp-section hp-process"><div class="hp-shell"><div class="hp-heading"><div><span><?=moni_home_t('homepage_start_three_steps','3 Adımda Başla')?></span><h2><?=moni_home_t('homepage_process_title','Kayıttan siparişe kısa ve net süreç')?></h2></div></div><div class="hp-process-grid"><article><b>01</b><i class="fas fa-user-plus"></i><h3><?=moni_home_t('homepage_process_account_title','Hesabını oluştur')?></h3><p><?=moni_home_t('homepage_process_account_desc','Ücretsiz kayıt ol ve güvenlik ayarlarını tamamla.')?></p></article><article><b>02</b><i class="fas fa-wallet"></i><h3><?=moni_home_t('homepage_process_balance_title','Bakiyeni ekle')?></h3><p><?=moni_home_t('homepage_process_balance_desc','Aktif ödeme yöntemlerinden sana uygun olanı kullan.')?></p></article><article><b>03</b><i class="fas fa-cart-shopping"></i><h3><?=moni_home_t('homepage_process_order_title','Sipariş oluştur')?></h3><p><?=moni_home_t('homepage_process_order_desc','Servisi seç, hedefini gir ve durumunu panelden takip et.')?></p></article></div></div></section><?php }
function moni_home_section_services(array $d): void { $services=!empty($d['featured'])?$d['featured']:($d['popular']??[]);if(!$services)return; ?>
<section class="hp-section hp-popular"><div class="hp-shell"><div class="hp-heading"><div><span><?=moni_home_t('homepage_popular_services','Popüler Servisler')?></span><h2><?=moni_home_t('homepage_popular_title','Katalogdan öne çıkan hizmetler')?></h2><p><?=moni_home_t('homepage_popular_desc','Fiyat ve limitler doğrudan aktif servis kayıtlarından gelir.')?></p></div><a href="<?=SITE_URL?>/services.php"><?=moni_home_t('homepage_open_catalog','Kataloğu Aç')?> <i class="fas fa-arrow-right"></i></a></div><div class="hp-service-grid"><?php foreach($services as $s):$featured=!empty($s['homepage_service_id']);$name=$featured?($s['custom_title']?:$s['service_name']):$s['name'];$description=$featured?trim((string)($s['custom_description']??'')):'';$iconRow=$s;if($featured&&!empty($s['custom_icon']))$iconRow['category_icon']=$s['custom_icon'];$iconStyle=$featured?trim((string)($s['custom_icon_style']??'')):'';$priceText=$featured?trim((string)($s['custom_price_text']??'')):'';?><article class="hp-service-card"><?php if($featured&&!empty($s['badge_text'])):?><span class="hp-service-badge" style="--badge:<?=clean($s['badge_color']?:'#ff6b6b')?>"><?=clean($s['badge_text'])?></span><?php endif;?><div class="hp-service-top"><div class="hp-category-icon" style="--cat:<?=clean($s['icon_color']?:'#7C5CFC')?>;<?=clean($iconStyle)?>"><i class="<?=clean(moni_home_icon($iconRow,'fas fa-bolt'))?>"></i></div><span><?=clean($s['category_name'])?></span></div><h3><?=clean($name)?></h3><?php if($description!==''):?><p class="hp-service-description"><?=clean($description)?></p><?php endif;?><div class="hp-service-meta"><span><?=moni_home_t('minimum_quantity','Min')?> <?=number_format((int)$s['min_quantity'])?></span><span><?=moni_home_t('maximum_quantity','Max')?> <?=number_format((int)$s['max_quantity'])?></span><?php if($s['refill']):?><span><?=moni_home_t('refill','Refill')?></span><?php endif;?></div><div class="hp-service-price"><small><?=moni_home_t('homepage_per_thousand','1.000 için')?></small><b><?=$priceText!==''?clean($priceText):moni_home_money($s['price_per_1000'])?></b></div><a href="<?=SITE_URL?>/login.php" class="hp-btn soft"><?=moni_home_t('homepage_go_to_order','Siparişe Git')?> <i class="fas fa-arrow-right"></i></a></article><?php endforeach;?></div></div></section><?php }
function moni_home_section_reviews(array $d): void { if(!$d['reviews'])return; ?>
<section class="hp-section hp-reviews"><div class="hp-shell"><div class="hp-heading"><div><span><?=moni_home_t('homepage_verified_reviews','Doğrulanmış Değerlendirmeler')?></span><h2><?=moni_home_t('homepage_reviews_title','Gerçek siparişlerden gelen servis yorumları')?></h2><p><?=moni_home_t('homepage_reviews_desc','Yalnız sistemde onaylanmış değerlendirmeler gösterilir.')?></p></div></div><div class="hp-review-grid"><?php foreach($d['reviews'] as $r):$u=mb_substr((string)$r['username'],0,1,'UTF-8').'***';?><article><div class="hp-review-head"><div class="hp-avatar"><?=clean(mb_strtoupper(mb_substr($r['username'],0,1,'UTF-8'),'UTF-8'))?></div><div><b><?=clean($u)?></b><span><?=clean($r['service_name'])?></span></div><div class="hp-stars"><?=str_repeat('★',max(1,min(5,(int)$r['rating'])))?></div></div><p>“<?=clean(mb_strimwidth($r['comment'],0,220,'…','UTF-8'))?>”</p></article><?php endforeach;?></div></div></section><?php }
function moni_home_section_faq(array $d=[]): void { $q=[[moni_home_t('homepage_faq_order_q','Sipariş vermek için ne gerekiyor?'),moni_home_t('homepage_faq_order_a','Ücretsiz hesap, yeterli bakiye ve servis için istenen herkese açık hedef bağlantısı yeterlidir.')],[moni_home_t('homepage_faq_prices_q','Servis fiyat ve limitlerini nerede görebilirim?'),moni_home_t('homepage_faq_prices_a','Servisler sayfasında aktif hizmetlerin güncel fiyat, minimum ve maksimum miktar bilgileri listelenir.')],[moni_home_t('homepage_faq_api_q','Siparişimi nereden takip edebilirim?'),moni_home_t('homepage_faq_api_a','Giriş yaptıktan sonra Siparişlerim sayfasından tüm siparişlerinizin güncel durumunu görüntüleyebilirsiniz.')],[moni_home_t('homepage_faq_support_q','Destek talebi nasıl açılır?'),moni_home_t('homepage_faq_support_a','Giriş yaptıktan sonra Destek alanından uygun departmanı seçerek talep oluşturabilirsiniz.')]];?>
<section class="hp-section hp-faq"><div class="hp-shell hp-faq-grid"><div><span class="hp-small-label"><?=moni_home_t('homepage_faq_label','Sık Sorulan Sorular')?></span><h2><?=moni_home_t('homepage_faq_title','Başlamadan önce merak edilenler')?></h2><p><?=moni_home_t('homepage_faq_desc','Sipariş verme, fiyatlar, takip ve destek hakkında kısa cevaplar.')?></p><a class="hp-btn primary" href="<?=SITE_URL?>/register.php"><?=moni_home_t('homepage_create_account','Hesap Oluştur')?></a></div><div class="hp-accordion"><?php foreach($q as $i=>$a):?><div class="hp-faq-item <?=$i===0?'open':''?>"><button type="button"><span><?=$a[0]?></span><i class="fas fa-plus"></i></button><div><?=$a[1]?></div></div><?php endforeach;?></div></div></section><?php }
function moni_home_section_blog(array $d): void { if(!$d['blogs'])return; ?>
<section class="hp-section hp-blog"><div class="hp-shell"><div class="hp-heading"><div><span><?=moni_home_t('homepage_blog','Blog')?></span><h2><?=moni_home_t('homepage_blog_title','Sosyal medya hizmetleri ve kullanım ipuçları')?></h2></div><a href="<?=SITE_URL?>/blog.php"><?=moni_home_t('homepage_all_articles','Tüm Yazılar')?> <i class="fas fa-arrow-right"></i></a></div><div class="hp-blog-grid"><?php foreach($d['blogs'] as $b):?><article><?php if($b['featured_image']):?><img src="<?=clean($b['featured_image'])?>" alt=""><?php else:?><div class="hp-blog-placeholder"><i class="fas fa-newspaper"></i></div><?php endif;?><div><small><?=clean(moni_home_date($b['created_at']))?></small><h3><?=clean($b['title'])?></h3><p><?=clean(mb_strimwidth($b['excerpt']?:strip_tags($b['content']),0,120,'…','UTF-8'))?></p><a href="<?=SITE_URL?>/blog/<?=clean($b['slug'])?>"><?=moni_home_t('homepage_read_more','Devamını Oku')?> <i class="fas fa-arrow-right"></i></a></div></article><?php endforeach;?></div></div></section><?php }
function moni_home_section_cta(array $d=[]): void { ?>
<section class="hp-final"><div class="hp-shell"><div><span><?=moni_home_t('homepage_ready_question','Hazır mısınız?')?></span><h2><?=moni_home_t('homepage_final_title','Servis kataloğunu keşfedin, hesabınızı dakikalar içinde oluşturun.')?></h2></div><div class="hp-actions"><a class="hp-btn primary" href="<?=SITE_URL?>/register.php"><?=moni_home_t('homepage_start_free','Ücretsiz Başla')?> <i class="fas fa-arrow-right"></i></a><a class="hp-btn ghost" href="<?=SITE_URL?>/services.php"><?=moni_home_t('homepage_view_services','Servisleri Gör')?></a></div></div></section><?php }
function moni_home_render_popup(array $d): void {
  if(!empty($GLOBALS['moniHomepagePreview'])||empty($d['popup']))return;
  $p=$d['popup'];$media=moni_home_asset(['media'=>$p['media_path']??''],'media');if($media==='')return;
  $link=moni_home_safe_url($p['link_url']??'','');$title=trim((string)($p['title']??''));$id=(int)($p['id']??0); ?>
<div class="hp-site-popup" id="moniSitePopup" role="dialog" aria-modal="true" aria-label="<?=clean($title?:'Duyuru')?>"><div class="hp-site-popup-card"><button type="button" class="hp-site-popup-close" aria-label="<?=moni_home_t('close','Kapat')?>"><i class="fas fa-xmark"></i></button><?php if($link!==''):?><a class="hp-site-popup-media" href="<?=clean($link)?>" target="_blank" rel="noopener noreferrer"><?php else:?><div class="hp-site-popup-media"><?php endif;?><?php if(($p['media_type']??'image')==='video'):?><video src="<?=clean($media)?>" controls autoplay muted playsinline></video><?php else:?><img src="<?=clean($media)?>" alt="<?=clean($title?:'Duyuru')?>"><?php endif;?><?php if($link!==''):?></a><?php else:?></div><?php endif;?><?php if($title!==''):?><strong><?=clean($title)?></strong><?php endif;?></div></div>
<script>(function(){var popup=document.getElementById('moniSitePopup');if(!popup)return;var key='popup_<?=$id?>_closed';var close=function(){popup.classList.remove('is-open');try{sessionStorage.setItem(key,'1')}catch(e){}};try{if(!sessionStorage.getItem(key))setTimeout(function(){popup.classList.add('is-open')},500)}catch(e){setTimeout(function(){popup.classList.add('is-open')},500)}popup.querySelector('.hp-site-popup-close').addEventListener('click',close);popup.addEventListener('click',function(e){if(e.target===popup)close()});document.addEventListener('keydown',function(e){if(e.key==='Escape'&&popup.classList.contains('is-open'))close()})})();</script><?php
}
function moni_home_render(PDO $db,array $ui,array $d): void {
  moni_home_render_announcement($ui); moni_home_render_hero($ui,$d);
  $layout=$ui['layout_key']??'nebula';
  $orders=[
   'nebula'=>['stats','categories','features','process','services','reviews','faq','blog','cta'],
   'ivory'=>['categories','services','process','stats','features','reviews','faq','blog','cta'],
   'pulse'=>['stats','process','categories','reviews','services','features','faq','cta','blog'],
   'aurora'=>['features','stats','categories','services','process','reviews','faq','blog','cta'],
   'glass'=>['stats','features','services','categories','process','reviews','faq','cta','blog'],
   'editorial'=>['process','categories','features','stats','services','faq','reviews','blog','cta'],
   'market'=>['categories','services','stats','features','process','reviews','faq','blog','cta'],
   'neon'=>['stats','categories','features','services','process','reviews','faq','cta','blog'],
  ];
  foreach($orders[$layout]??$orders['nebula'] as $section){ if(!moni_home_enabled($ui,$section,true))continue; $fn='moni_home_section_'.$section; if(function_exists($fn)) $fn($d); }
  moni_home_render_popup($d);
  echo '<script>document.addEventListener("click",function(e){const b=e.target.closest(".hp-faq-item button");if(!b)return;b.closest(".hp-faq-item").classList.toggle("open")});</script>';
}
}
