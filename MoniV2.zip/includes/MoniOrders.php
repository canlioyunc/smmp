<?php
if(defined('MONI_ORDERS_LOADED'))return;define('MONI_ORDERS_LOADED',true);

function moni_place_order(PDO $db,int $userId,int $serviceId,string $link,int $quantity,array $options=[]):array{
    if(function_exists('moni_partial_maintenance_active') && moni_partial_maintenance_active($db,'orders')) return ['success'=>false,'error'=>moni_partial_maintenance_message($db,'orders'),'maintenance'=>true];
    if(function_exists('moni_user_can') && !moni_user_can($db,$userId,'orders.create',true)) return ['success'=>false,'error'=>'Sipariş verme yetkiniz yönetici tarafından kapatılmış.'];
    if(function_exists('moni_user_credit_overdue') && (string)getSetting('postpaid_overdue_block_orders','1')==='1'){ $creditState=moni_user_credit_overdue($db,$userId); if(!empty($creditState['overdue'])) return ['success'=>false,'error'=>'Vadeli borcunuzun ödeme süresi dolmuş. Yeni sipariş vermeden önce borcunuzu kapatın.']; }
    $link=trim($link);$isDrip=!empty($options['dripfeed']);$runs=max(1,(int)($options['runs']??1));$interval=max(0,(int)($options['interval']??0));
    $s=$db->prepare("SELECT * FROM services WHERE id=? AND status='active' LIMIT 1");$s->execute([$serviceId]);$service=$s->fetch(PDO::FETCH_ASSOC);
    if(!$service)return ['success'=>false,'error'=>__('invalid_service')];
    if(function_exists('moni_service_visible_to_user') && !moni_service_visible_to_user($db,$serviceId,$userId))return ['success'=>false,'error'=>'Bu servis müşteri grubunuza açık değil.'];
    if($link==='')return ['success'=>false,'error'=>__('link_required')];
    if(function_exists('moni_validate_service_target')){$tv=moni_validate_service_target($db,$serviceId,$link,$userId,(string)($options['source']??'web'));if(empty($tv['ok']))return ['success'=>false,'error'=>$tv['error']??'Bu hedef bu servis için kullanılamaz.'];}
    if($quantity<(int)$service['min_quantity'])return ['success'=>false,'error'=>__('minimum_quantity').': '.number_format($service['min_quantity'])];
    if($quantity>(int)$service['max_quantity'])return ['success'=>false,'error'=>__('maximum_quantity').': '.number_format($service['max_quantity'])];
    $increment=max(1,(int)($service['quantity_increment']??1));
    if($quantity % $increment !== 0)return ['success'=>false,'error'=>'Miktar '.$increment.' katı olmalıdır.'];
    if(($reason=moni_maintenance_reason($serviceId,(int)($service['api_provider_id']??0))))return ['success'=>false,'error'=>$reason];
    if(function_exists('moni_service_schedule_check')){$wh=moni_service_schedule_check($db,$serviceId);if(empty($wh['open']))return ['success'=>false,'error'=>$wh['error']??'Bu servis şu anda sipariş kabul etmiyor.'];}
    if(function_exists('moni_social_precheck')){$pc=moni_social_precheck($db,$link);if(empty($pc['ok']))return ['success'=>false,'error'=>$pc['error']??'Sosyal hesap ön kontrolü başarısız.'];}
    $geoTarget=null;if(function_exists('moni_validate_geo_target')){$gv=moni_validate_geo_target($service,$options['geo_target']??null);if(empty($gv['ok']))return ['success'=>false,'error'=>$gv['error']??'Coğrafi hedef geçersiz.'];$geoTarget=$gv['target']??null;}
    if($isDrip&&!$service['dripfeed'])return ['success'=>false,'error'=>'Bu servis dripfeed desteklemiyor.'];
    if($isDrip&&$runs<2)return ['success'=>false,'error'=>'Dripfeed için en az 2 çalıştırma gerekli.'];
    if($isDrip&&$interval<1)return ['success'=>false,'error'=>'Dripfeed aralığı en az 1 dakika olmalı.'];

    $totalQty=$isDrip?$quantity*$runs:$quantity;
    $salePer1000=function_exists('moni_effective_price_for_quantity')?moni_effective_price_for_quantity($service,$userId,$totalQty):moni_effective_price_per_1000($service,$userId);
    $price=round(($totalQty/1000)*$salePer1000,4);
    // Bundle fiyatı yalnız sunucu içindeki bundle motorundan gelebilir; public endpointler bu opsiyonu oluşturmaz.
    if(($options['source']??'')==='bundle' && array_key_exists('bundle_price',$options)){
        $bundlePrice=round(max(0,(float)$options['bundle_price']),4);
        if($bundlePrice<=$price+0.0001){$price=$bundlePrice;$salePer1000=$totalQty>0?round($price*1000/$totalQty,6):$salePer1000;}
    }
    $request=['service_id'=>$serviceId,'link'=>$link,'quantity'=>$quantity,'dripfeed'=>$isDrip,'runs'=>$runs,'interval'=>$interval,'geo_target'=>$geoTarget,'price'=>$price];

    $idemKey=(string)($options['idempotency_key']??'');
    $idem=moni_order_idempotency_begin($db,$userId,(string)($options['source']??'web'),$idemKey,$request);
    if(!empty($idem['duplicate'])){
        if(!empty($idem['conflict']))return ['success'=>false,'error'=>'Aynı işlem anahtarı farklı sipariş verisiyle kullanılamaz.'];
        $resp=!empty($idem['response_json'])?json_decode($idem['response_json'],true):null;
        if(is_array($resp))return $resp;
        if(!empty($idem['order_id']))return ['success'=>true,'order_id'=>(int)$idem['order_id'],'idempotent_replay'=>true,'message'=>'Bu sipariş isteği daha önce işlendi.'];
        return ['success'=>false,'error'=>'Bu sipariş isteği şu anda işleniyor; ikinci sipariş oluşturulmadı.','idempotent_replay'=>true,'in_progress'=>true];
    }

    $duplicate=moni_duplicate_order($db,$userId,$serviceId,$link);
    $warning=$duplicate?'Uyarı: Aynı servis ve bağlantı için #'.$duplicate['id'].' numaralı aktif siparişiniz bulunuyor. Yeni sipariş yine oluşturuldu.':'';

    try{
        $db->beginTransaction();
        $targetGuard=['ok'=>true,'guard_id'=>null];
        if(function_exists('moni_same_target_guard_acquire')){ $targetGuard=moni_same_target_guard_acquire($db,$userId,$serviceId,$link); if(empty($targetGuard['ok'])) throw new RuntimeException($targetGuard['error']??'Aynı hedefte aktif sipariş bulunuyor.'); }
        // Çoklu para birimi cüzdan bakiyesi önce baz bakiyeye çevrilir; postpaid kredi limiti varsa eksik kısım limitten karşılanabilir.
        $need=max(0,$price-(function_exists('moni_user_credit_limit')?moni_user_credit_limit($db,$userId):0));
        $walletReady=moni_wallet_prepare_base_balance($db,$userId,$need);
        if(empty($walletReady['ok']) && (!function_exists('moni_user_available_funds') || moni_user_available_funds($db,$userId)+0.00001<$price))throw new RuntimeException(__('insufficient_balance'));

        if(function_exists('moni_debit_user')){
            if(!moni_debit_user($db,$userId,$price,true))throw new RuntimeException(__('insufficient_balance'));
        }else{
            $debit=$db->prepare("UPDATE users SET balance=balance-?,spent=spent+? WHERE id=? AND status='active' AND balance>=?");
            $debit->execute([$price,$price,$userId,$price]);
            if(!$debit->rowCount())throw new RuntimeException(__('insufficient_balance'));
        }

        if($isDrip){
            $db->prepare("INSERT INTO orders_dripfeed(user_id,service_id,link,quantity,runs,interval_time,total_quantity,total_price,geo_target,status,next_run_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,'active',NOW(),NOW())")
               ->execute([$userId,$serviceId,$link,$quantity,$runs,$interval,$totalQty,$price,$geoTarget]);
            $dfid=(int)$db->lastInsertId();
            if(function_exists('moni_same_target_guard_bind'))moni_same_target_guard_bind($db,$targetGuard['guard_id']??null,'dripfeed',$dfid);
            $bal=$db->prepare("SELECT balance FROM users WHERE id=?");$bal->execute([$userId]);$after=(float)$bal->fetchColumn();
            $db->prepare("INSERT INTO transactions(user_id,type,amount,balance_after,description,status,created_at) VALUES(?,'order',?,?,?,'completed',NOW())")
               ->execute([$userId,-$price,$after,'Dripfeed #'.$dfid.' sipariş ödemesi']);
            $db->commit();
            moni_sync_base_wallet($db,$userId);
            $response=['success'=>true,'dripfeed_id'=>$dfid,'order_id'=>0,'price'=>$price,'warning'=>$warning,'message'=>__('order_success').'! Dripfeed ID: #'.$dfid];
            moni_order_idempotency_finish($db,$idem['row_id']??null,0,$response);
            if(function_exists('moni_record_service_affinity')) moni_record_service_affinity($db,$userId,$serviceId,$totalQty);
            return $response;
        }

        $refill=(int)($service['refill']??0);$refillMax=(int)($service['refill_count']??0);
        $refillUntil=$refill&&($service['refill_days']??0)>0?date('Y-m-d',strtotime('+'.(int)$service['refill_days'].' days')):null;
        $providerQty=$quantity;
        $overflow=max(0,min(500,(float)($service['overflow_percent']??0)));
        if($overflow>0)$providerQty=(int)ceil($quantity*(1+$overflow/100));
        $db->prepare("INSERT INTO orders(user_id,service_id,api_provider_id,link,quantity,provider_quantity,price,status,refill_enabled,refill_until,refill_max,geo_target,created_at) VALUES(?,?,?,?,?,?,?,'pending',?,?,?,?,NOW())")
           ->execute([$userId,$serviceId,$service['api_provider_id']?:null,$link,$quantity,$providerQty,$price,$refill,$refillUntil,$refillMax,$geoTarget]);
        $oid=(int)$db->lastInsertId();
        if(function_exists('moni_same_target_guard_bind'))moni_same_target_guard_bind($db,$targetGuard['guard_id']??null,'order',$oid);
        if(!empty($duplicate['event_id'])){$db->prepare("UPDATE duplicate_order_events SET new_order_id=? WHERE id=?")->execute([$oid,(int)$duplicate['event_id']]);}
        $bal=$db->prepare("SELECT balance FROM users WHERE id=?");$bal->execute([$userId]);$after=(float)$bal->fetchColumn();
        $db->prepare("INSERT INTO transactions(user_id,type,amount,balance_after,description,status,created_at) VALUES(?,'order',?,?,?,'completed',NOW())")
           ->execute([$userId,-$price,$after,'Sipariş #'.$oid.' ödemesi']);
        $db->commit();

        $service['_order_quantity']=$quantity;
        $service['_provider_quantity']=$providerQty;
        moni_record_order_snapshot($db,$oid,$service,$salePer1000);
        if(function_exists('moni_order_reason_record'))moni_order_reason_record($db,$oid,'pending','pending_queue','system',(int)($service['api_provider_id']??0),'pending','Sipariş oluşturuldu',null);
        moni_sync_base_wallet($db,$userId);
        if(function_exists('moni_capture_start_count')) moni_capture_start_count($db,$oid,$link);

        if(!empty($service['api_provider_id'])&&!empty($service['api_service_id'])){
            $queued=function_exists('moni_enqueue_order_dispatch')?moni_enqueue_order_dispatch($db,$oid):['ok'=>false,'error'=>'Sipariş gönderim kuyruğu yüklenemedi.'];
            if(empty($queued['ok'])){
                $rr=moni_refund_order($db,$oid,$price,'Sipariş provider gönderim kuyruğuna alınamadı: '.($queued['error']??'bilinmeyen hata'),'error');
                $response=['success'=>false,'error'=>'Sipariş güvenli gönderim kuyruğuna alınamadı; ücret iade edildi.','order_id'=>$oid];
                moni_order_idempotency_finish($db,$idem['row_id']??null,$oid,$response);
                return $response;
            }
        }

        $response=['success'=>true,'order_id'=>$oid,'price'=>$price,'queued'=>!empty($service['api_provider_id'])&&!empty($service['api_service_id']),'warning'=>$warning,'message'=>__('order_success').'! '.__('order_id').': #'.$oid];
        if(function_exists('moni_user_notify'))moni_user_notify($db,$userId,'order','Sipariş oluşturuldu','#'.$oid.' numaralı siparişiniz alındı.','/kullanici/orders.php','success');
        moni_order_idempotency_finish($db,$idem['row_id']??null,$oid,$response);
        if(function_exists('moni_record_service_affinity')) moni_record_service_affinity($db,$userId,$serviceId,$quantity);
        return $response;
    }catch(Throwable $e){
        if($db->inTransaction())$db->rollBack();
        moni_order_idempotency_abort($db,$idem['row_id']??null);
        return ['success'=>false,'error'=>$e->getMessage()];
    }
}


/**
 * Sağlayıcıdan gelen durum cevabını atomik uygular. Terminal bir sipariş daha eski bir
 * provider cevabıyla processing/pending durumuna geri döndürülemez. Kısmi/tam iade aynı kilitte yapılır.
 */
function moni_apply_provider_status(PDO $db,int $orderId,array $provider):array{
    if(empty($provider['success']))return ['success'=>false,'error'=>$provider['error']??'Sağlayıcı durumu alınamadı.'];
    $new=(string)($provider['status']??'');
    if(!in_array($new,['pending','processing','in_progress','completed','partial','cancelled','refunded','error'],true))
        return ['success'=>false,'error'=>'Sağlayıcı geçersiz sipariş durumu döndürdü.'];
    $own=!$db->inTransaction();if($own)$db->beginTransaction();
    try{
        $st=$db->prepare("SELECT * FROM orders WHERE id=? FOR UPDATE");$st->execute([$orderId]);$o=$st->fetch(PDO::FETCH_ASSOC);
        if(!$o)throw new RuntimeException('Sipariş bulunamadı.');
        $terminal=['completed','partial','cancelled','refunded','error'];
        if(in_array((string)$o['status'],$terminal,true)){
            if($own)$db->commit();
            return ['success'=>true,'applied'=>false,'status'=>(string)$o['status'],'start_count'=>$o['start_count'],'remains'=>$o['remains']];
        }
        $start=array_key_exists('start_count',$provider)&&$provider['start_count']!==null&&$provider['start_count']!==''?(int)$provider['start_count']:$o['start_count'];
        $rem=array_key_exists('remains',$provider)&&$provider['remains']!==null&&$provider['remains']!==''?(int)$provider['remains']:$o['remains'];
        if($new==='partial' && $rem!==null && (int)$o['quantity']>0){
            $userQty=max(1,(int)$o['quantity']);$providerQty=max($userQty,(int)($o['provider_quantity']??$userQty));
            $providerDelivered=max(0,$providerQty-max(0,(int)$rem));$userDelivered=min($userQty,$providerDelivered);$userMissing=max(0,$userQty-$userDelivered);
            $target=round((float)$o['price']*($userMissing/$userQty),4);
            $db->prepare("UPDATE orders SET start_count=?,remains=?,updated_at=NOW() WHERE id=?")->execute([$start,$rem,$orderId]);
            $rr=moni_refund_order($db,$orderId,$target,'Kısmi tamamlanma iadesi','partial');if(empty($rr['ok']))throw new RuntimeException($rr['error']??'Kısmi iade uygulanamadı.');
        }elseif(in_array($new,['cancelled','refunded'],true)){
            $db->prepare("UPDATE orders SET start_count=?,remains=?,updated_at=NOW() WHERE id=?")->execute([$start,$rem,$orderId]);
            $rr=moni_refund_order($db,$orderId,(float)$o['price'],'Sağlayıcı siparişi iptal/iade etti',$new);if(empty($rr['ok']))throw new RuntimeException($rr['error']??'İade uygulanamadı.');
        }elseif($new==='error'){
            // Sağlayıcı siparişi kesin hata durumuna aldıysa kullanıcıdan tahsil edilen bu run tutarı tutulmaz.
            // Dripfeed çocuk siparişlerinde parent toplamı peşin tahsil edildiği için bu iade, başarısız run'ın payını geri verir.
            $db->prepare("UPDATE orders SET start_count=?,remains=?,updated_at=NOW() WHERE id=?")->execute([$start,$rem,$orderId]);
            $rr=moni_refund_order($db,$orderId,(float)$o['price'],'Sağlayıcı siparişi hata durumuna aldı','error');if(empty($rr['ok']))throw new RuntimeException($rr['error']??'Hatalı sipariş iadesi uygulanamadı.');
        }else{
            $db->prepare("UPDATE orders SET status=?,start_count=?,remains=?,updated_at=NOW() WHERE id=?")->execute([$new,$start,$rem,$orderId]);
        }
        $oldStatus=(string)$o['status'];
        if($own)$db->commit();
        if($own && $oldStatus!==$new){
            if(function_exists('moni_order_reason_detect')&&function_exists('moni_order_reason_record')){
                $rawStatus=(string)($provider['raw_status']??$new);$rawMsg='';if(isset($provider['data'])&&is_array($provider['data']))$rawMsg=(string)($provider['data']['message']??$provider['data']['error']??'');
                $reason=moni_order_reason_detect($db,(int)($o['api_provider_id']??0),$new,$rawStatus,$rawMsg);moni_order_reason_record($db,$orderId,$new,$reason,'provider',(int)($o['api_provider_id']??0),$rawStatus,$rawMsg,null);
            }
            if(function_exists('moni_user_notify'))moni_user_notify($db,(int)$o['user_id'],'order_status','Sipariş durumunuz güncellendi','#'.$orderId.' siparişinizin yeni durumu: '.$new,'/kullanici/orders.php','info');
            if(function_exists('moni_send_template_email')){try{$em=$db->prepare("SELECT email,username FROM users WHERE id=?");$em->execute([$o['user_id']]);$eu=$em->fetch(PDO::FETCH_ASSOC);if($eu&&!empty($eu['email']))moni_send_template_email($db,'order_status',$eu['email'],['username'=>$eu['username'],'order_id'=>$orderId,'status'=>$new]);}catch(Throwable $ignore){}}
        }
        return ['success'=>true,'applied'=>true,'status'=>$new,'start_count'=>$start,'remains'=>$rem];
    }catch(Throwable $e){if($own&&$db->inTransaction())$db->rollBack();return ['success'=>false,'error'=>$e->getMessage()];}
}

/**
 * Kullanıcı/API iptalini sağlayıcı çağrısı + idempotent iade ile tek seri akışta yürütür.
 * Aynı siparişe paralel iki iptal isteğinin sağlayıcıya iki kez gitmesini önler.
 */
function moni_cancel_user_order(PDO $db,int $orderId,int $userId,string $reason='Kullanıcı sipariş iptali'):array{
    $lockName='moni_cancel_'.substr(hash('sha256',(string)$orderId),0,40);$locked=false;
    try{
        $lk=$db->prepare("SELECT GET_LOCK(?,5)");$lk->execute([$lockName]);$locked=(int)$lk->fetchColumn()===1;
        if(!$locked)return ['success'=>false,'error'=>'Sipariş üzerinde başka bir işlem devam ediyor. Lütfen tekrar deneyin.'];

        $st=$db->prepare("SELECT o.*,s.cancel AS service_cancel FROM orders o LEFT JOIN services s ON s.id=o.service_id WHERE o.id=? AND o.user_id=? LIMIT 1");
        $st->execute([$orderId,$userId]);$order=$st->fetch(PDO::FETCH_ASSOC);
        if(!$order)return ['success'=>false,'error'=>'Sipariş bulunamadı.'];
        if(!(int)($order['service_cancel']??0))return ['success'=>false,'error'=>'Bu servis için iptal desteklenmiyor.'];

        if(in_array($order['status'],['cancelled','refunded'],true)){
            $rr=moni_refund_order($db,$orderId,(float)$order['price'],$reason,'cancelled');
            return ['success'=>$rr['ok'],'already'=>true,'refund_amount'=>$rr['amount']??0,'error'=>$rr['error']??null];
        }
        if(!in_array($order['status'],['pending','processing','in_progress'],true))return ['success'=>false,'error'=>'Bu sipariş artık iptal edilemez.'];

        if(function_exists('moni_queue_cancel')){
            $q=moni_queue_cancel($db,$orderId,$userId,$userId,$reason);
            if(!empty($q['success']))return ['success'=>true,'queued'=>true,'message'=>'İptal talebiniz güvenli iş kuyruğuna alındı.'];
            return ['success'=>false,'error'=>$q['error']??'İptal kuyruğuna eklenemedi.'];
        }

        if(!empty($order['api_order_id'])&&!empty($order['api_provider_id'])){
            $cancel=moni_provider_cancel($db,$order);
            $confirmed=!empty($cancel['confirmed']);
            if(!$confirmed){
                $status=moni_provider_status($db,$order);
                $confirmed=!empty($status['success'])&&in_array($status['status']??'',['cancelled','refunded'],true);
            }
            if(!$confirmed){
                if(!empty($cancel['success'])||!empty($cancel['queued'])){
                    return ['success'=>true,'queued'=>true,'refund_amount'=>0,'message'=>'İptal talebi sağlayıcıya iletildi; kesin iptal doğrulanmadan iade yapılmayacak.'];
                }
                return ['success'=>false,'error'=>$cancel['error']??'Sağlayıcı iptal işlemini kabul etmedi.'];
            }
        }

        $rr=moni_refund_order($db,$orderId,(float)$order['price'],$reason,'cancelled');
        if(!$rr['ok'])return ['success'=>false,'error'=>$rr['error']??'İade tamamlanamadı.'];
        if(function_exists('moni_order_reason_record'))moni_order_reason_record($db,$orderId,'cancelled','cancelled_user','user',(int)($order['api_provider_id']??0),'cancelled',$reason,$userId);
        return ['success'=>true,'refund_amount'=>$rr['amount'],'already'=>!empty($rr['already_refunded'])];
    }finally{
        if($locked){try{$r=$db->prepare("SELECT RELEASE_LOCK(?)");$r->execute([$lockName]);}catch(Throwable $ignore){}}
    }
}
