<?php
if (defined('MONI_ADMIN_UI_LOADED')) return;
define('MONI_ADMIN_UI_LOADED', true);

function moni_admin_ui_styles(): string
{
    static $emitted = false;
    if ($emitted) return '';
    $emitted = true;
    return <<<'CSS'
<style>
/* ========================================================================
   Moni Admin UI — ortak profesyonel yönetim arayüzü
   ======================================================================== */
.moni-page{
    --moni-radius-xl:18px;
    --moni-radius-lg:14px;
    --moni-radius-md:10px;
    --moni-shadow:0 10px 32px rgba(10,18,35,.055);
    max-width:1480px;
    margin:0 auto;
    padding:0 0 34px;
}
.moni-page *{box-sizing:border-box}
.moni-hero{
    position:relative;
    overflow:hidden;
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:22px;
    padding:22px 24px;
    margin-bottom:18px;
    border:1px solid var(--border-color);
    border-radius:var(--moni-radius-xl);
    background:
      radial-gradient(circle at 92% 0%,var(--primary-alpha-015),transparent 34%),
      linear-gradient(145deg,color-mix(in srgb,var(--card-bg-color) 97%,var(--primary-color) 3%),var(--card-bg-color));
    box-shadow:var(--moni-shadow);
}
.moni-hero:before{
    content:"";
    position:absolute;
    width:180px;height:180px;border-radius:50%;
    right:-72px;bottom:-110px;
    background:var(--primary-alpha-01);
    pointer-events:none;
}
.moni-hero>div,.moni-hero>span,.moni-hero>a{position:relative;z-index:1}
.moni-hero h2{font-size:1.32rem;line-height:1.25;margin:0 0 7px;font-weight:760;letter-spacing:-.02em}
.moni-hero p{margin:0;max-width:860px;color:var(--muted-text-color);font-size:.89rem;line-height:1.6}
.moni-kicker{display:inline-flex;align-items:center;gap:7px;margin-bottom:7px;font-size:.68rem;font-weight:800;text-transform:uppercase;letter-spacing:.085em;color:var(--accent-text-color)}
.moni-hero-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap}

.moni-grid{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:16px}
.moni-card{
    grid-column:span 6;
    min-width:0;
    background:var(--card-bg-color);
    border:1px solid var(--border-color);
    border-radius:var(--moni-radius-lg);
    padding:19px;
    box-shadow:0 7px 24px rgba(10,18,35,.035);
}
.moni-card.full{grid-column:1/-1}
.moni-card.two-third{grid-column:span 8}
.moni-card.third{grid-column:span 4}
.moni-card.quarter{grid-column:span 3}
.moni-card.compact{padding:15px 17px}
.moni-card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:16px}
.moni-card-head>div{min-width:0}
.moni-card h3,.moni-card-head h3{margin:0;font-size:.98rem;font-weight:730;letter-spacing:-.01em}
.moni-card h3:not(:last-child){margin-bottom:13px}
.moni-card-head p{margin:5px 0 0;color:var(--muted-text-color);font-size:.8rem;line-height:1.5}
.moni-card-subtitle{margin:-7px 0 15px;color:var(--muted-text-color);font-size:.81rem;line-height:1.55}
.moni-divider{height:1px;background:var(--border-color);margin:17px 0}
.moni-muted{color:var(--muted-text-color);font-size:.82rem;line-height:1.5}
.moni-help{display:flex;align-items:flex-start;gap:9px;padding:11px 12px;border:1px solid var(--border-color);background:color-mix(in srgb,var(--background-color) 82%,var(--card-bg-color));border-radius:10px;color:var(--muted-text-color);font-size:.79rem;line-height:1.5}
.moni-help i{color:var(--accent-text-color);margin-top:2px}

.moni-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:13px 14px}
.moni-form-grid.three{grid-template-columns:repeat(3,minmax(0,1fr))}
.moni-field{display:flex;flex-direction:column;gap:6px;min-width:0}
.moni-field.full{grid-column:1/-1}
.moni-field label{font-size:.77rem;font-weight:700;color:var(--card-text-color);letter-spacing:.005em}
.moni-field small,.moni-field .hint{color:var(--muted-text-color);font-size:.72rem;line-height:1.4}
.moni-field input,
.moni-field select,
.moni-field textarea,
.moni-table input:not([type=checkbox]):not([type=radio]),
.moni-table select,
.moni-table textarea{
    width:100%;
    min-height:40px;
    border:1px solid var(--border-color);
    background:color-mix(in srgb,var(--background-color) 92%,var(--card-bg-color));
    color:var(--text-color);
    border-radius:9px;
    padding:9px 11px;
    font:inherit;
    font-size:.84rem;
    outline:none;
    transition:border-color .16s ease,box-shadow .16s ease,background .16s ease;
}
.moni-field input:hover,.moni-field select:hover,.moni-field textarea:hover,.moni-table input:hover,.moni-table select:hover{border-color:color-mix(in srgb,var(--accent-text-color) 42%,var(--border-color))}
.moni-field input:focus,.moni-field select:focus,.moni-field textarea:focus,.moni-table input:focus,.moni-table select:focus,.moni-table textarea:focus{border-color:var(--accent-text-color);box-shadow:0 0 0 3px var(--primary-alpha-01);background:var(--card-bg-color)}
.moni-field textarea{min-height:108px;resize:vertical}
.moni-field input[type=color]{padding:5px;height:40px;cursor:pointer}
.moni-check{display:flex;align-items:flex-start;gap:8px;font-size:.82rem;line-height:1.4;color:var(--card-text-color);cursor:pointer}
.moni-check input{width:17px;height:17px;margin-top:1px;accent-color:var(--primary-color);flex:0 0 auto}
.moni-switch{display:inline-flex;align-items:center;gap:9px;cursor:pointer}
.moni-switch input{position:absolute;opacity:0;pointer-events:none}
.moni-switch-track{position:relative;width:38px;height:22px;border-radius:999px;background:color-mix(in srgb,var(--muted-text-color) 30%,transparent);border:1px solid var(--border-color);transition:.18s ease}
.moni-switch-track:after{content:"";position:absolute;width:16px;height:16px;left:2px;top:2px;border-radius:50%;background:var(--card-bg-color);box-shadow:0 2px 5px rgba(0,0,0,.18);transition:.18s ease}
.moni-switch input:checked+.moni-switch-track{background:var(--primary-color);border-color:var(--primary-color)}
.moni-switch input:checked+.moni-switch-track:after{transform:translateX(16px)}

.moni-btn{
    display:inline-flex;align-items:center;justify-content:center;gap:7px;
    min-height:38px;padding:8px 13px;border:1px solid transparent;border-radius:9px;
    background:linear-gradient(135deg,var(--primary-color),var(--secondary-color));
    color:var(--on-accent-color);font-weight:720;font-size:.79rem;line-height:1;text-decoration:none;cursor:pointer;
    transition:transform .15s ease,box-shadow .15s ease,border-color .15s ease,filter .15s ease;
}
.moni-btn:hover{transform:translateY(-1px);box-shadow:0 7px 18px var(--primary-alpha-018);filter:saturate(1.04)}
.moni-btn.secondary{background:var(--card-bg-color);color:var(--text-color);border-color:var(--border-color);box-shadow:none}
.moni-btn.secondary:hover{border-color:color-mix(in srgb,var(--accent-text-color) 50%,var(--border-color));color:var(--accent-text-color);background:var(--background-color)}
.moni-btn.danger{background:#dc3545;color:#fff}.moni-btn.success{background:#198754;color:#fff}.moni-btn.warning{background:#d98c00;color:#fff}
.moni-btn.sm{min-height:32px;padding:6px 10px;font-size:.73rem;border-radius:8px}
.moni-btn.icon{width:36px;padding:0}
.moni-actions{display:flex;align-items:center;flex-wrap:wrap;gap:7px}
.moni-actions.end{justify-content:flex-end}
.moni-toolbar{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:14px;flex-wrap:wrap}
.moni-toolbar .moni-actions{margin-left:auto}

.moni-table-wrap{overflow:auto;border:1px solid var(--border-color);border-radius:12px;background:var(--card-bg-color)}
.moni-table{width:100%;border-collapse:separate;border-spacing:0;min-width:760px}
.moni-table th,.moni-table td{padding:11px 12px;border-bottom:1px solid var(--border-color);text-align:left;vertical-align:middle;font-size:.81rem}
.moni-table th{position:sticky;top:0;z-index:1;background:color-mix(in srgb,var(--card-bg-color) 86%,var(--background-color));color:var(--muted-text-color);font-size:.67rem;font-weight:800;text-transform:uppercase;letter-spacing:.065em;white-space:nowrap}
.moni-table tbody tr:last-child td{border-bottom:0}
.moni-table tbody tr:hover td{background:var(--primary-alpha-009)}
.moni-table strong{font-weight:700}
.moni-table .moni-actions{flex-wrap:nowrap}
.moni-table-empty{text-align:center!important;color:var(--muted-text-color);padding:30px!important}

.moni-badge{display:inline-flex;align-items:center;gap:5px;min-height:24px;padding:4px 8px;border-radius:999px;border:1px solid color-mix(in srgb,var(--accent-text-color) 16%,transparent);font-size:.69rem;font-weight:760;background:var(--primary-alpha-01);color:var(--accent-text-color);white-space:nowrap}
.moni-badge.ok{background:rgba(25,135,84,.10);border-color:rgba(25,135,84,.20);color:#198754}
.moni-badge.off{background:rgba(108,117,125,.10);border-color:rgba(108,117,125,.18);color:var(--muted-text-color)}
.moni-badge.warn{background:rgba(217,140,0,.10);border-color:rgba(217,140,0,.22);color:#b97400}
.moni-badge.danger{background:rgba(220,53,69,.10);border-color:rgba(220,53,69,.22);color:#dc3545}
.moni-kpi{display:flex;align-items:center;gap:12px}
.moni-kpi i{width:40px;height:40px;border-radius:11px;display:grid;place-items:center;background:var(--primary-alpha-01);color:var(--accent-text-color);flex:0 0 auto}
.moni-kpi strong{font-size:1.22rem;line-height:1.1;display:block;letter-spacing:-.02em}
.moni-kpi span{display:block;margin-top:3px}

.moni-alert{display:flex;align-items:flex-start;gap:9px;padding:11px 13px;border:1px solid var(--border-color);border-radius:10px;margin-bottom:14px;font-size:.81rem;line-height:1.45}
.moni-alert:before{font-family:"Font Awesome 6 Free";font-weight:900;margin-top:1px}
.moni-alert.success{background:rgba(25,135,84,.075);border-color:rgba(25,135,84,.20)}
.moni-alert.success:before{content:"\f058";color:#198754}
.moni-alert.danger{background:rgba(220,53,69,.075);border-color:rgba(220,53,69,.20)}
.moni-alert.danger:before{content:"\f06a";color:#dc3545}
.moni-alert.warning{background:rgba(217,140,0,.08);border-color:rgba(217,140,0,.22)}
.moni-alert.warning:before{content:"\f071";color:#b97400}

.moni-list{display:flex;flex-direction:column}
.moni-list-row{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:11px 0;border-bottom:1px solid var(--border-color)}
.moni-list-row:last-child{border-bottom:0;padding-bottom:0}.moni-list-row:first-child{padding-top:0}
.moni-list-main{min-width:0}.moni-list-title{font-weight:690;font-size:.84rem}.moni-list-meta{margin-top:3px;color:var(--muted-text-color);font-size:.74rem}
.moni-empty{padding:34px 18px;text-align:center;color:var(--muted-text-color);font-size:.84rem}.moni-empty i{display:block;font-size:1.45rem;color:var(--accent-text-color);margin-bottom:9px;opacity:.75}
.moni-code{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;background:var(--background-color);border:1px solid var(--border-color);border-radius:8px;padding:2px 6px;font-size:.78em}

html[dir="rtl"] .moni-table th,html[dir="rtl"] .moni-table td{text-align:right}
html[dir="rtl"] .moni-toolbar .moni-actions{margin-left:0;margin-right:auto}
html[dir="rtl"] .moni-switch-track:after{left:auto;right:2px}
html[dir="rtl"] .moni-switch input:checked+.moni-switch-track:after{transform:translateX(-16px)}

@media(max-width:1100px){.moni-card.third,.moni-card.quarter{grid-column:span 6}.moni-form-grid.three{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:900px){.moni-card,.moni-card.two-third,.moni-card.third,.moni-card.quarter{grid-column:1/-1}.moni-hero{align-items:flex-start;flex-direction:column}.moni-form-grid,.moni-form-grid.three{grid-template-columns:1fr}.moni-toolbar{align-items:flex-start}.moni-toolbar .moni-actions{margin-left:0}}
@media(max-width:560px){.moni-page{padding-bottom:22px}.moni-hero{padding:18px;border-radius:14px}.moni-card{padding:16px;border-radius:12px}.moni-actions{width:100%}.moni-actions .moni-btn{flex:1}.moni-table th,.moni-table td{padding:10px}}

/* ========================================================================
   Moni Admin UI — ürün tasarım katmanı
   Gösterişli dashboard kalıpları yerine sıkı, editoryal ve işlev odaklı düzen.
   ======================================================================== */
.moni-page{
    max-width:1460px;
    padding-top:2px;
}
.moni-hero{
    overflow:visible;
    padding:4px 0 16px;
    margin:0 0 16px;
    border:0;
    border-bottom:1px solid var(--border-color);
    border-radius:0;
    background:transparent;
    box-shadow:none;
}
.moni-hero:before{display:none}
.moni-hero h2{font-size:1.18rem;line-height:1.3;margin:0 0 5px;font-weight:740;letter-spacing:-.018em}
.moni-hero p{font-size:.81rem;line-height:1.52;max-width:780px}
.moni-kicker{margin-bottom:5px;font-size:.64rem;letter-spacing:.075em;color:var(--muted-text-color)}
.moni-hero-actions{gap:7px}

.moni-kpi-grid{
    display:grid;
    grid-template-columns:repeat(4,minmax(0,1fr));
    gap:10px;
    margin:0 0 15px;
}
.moni-kpi-card{
    min-width:0;
    display:flex;
    flex-direction:column;
    justify-content:center;
    gap:4px;
    min-height:84px;
    padding:13px 15px;
    background:var(--card-bg-color);
    border:1px solid var(--border-color);
    border-radius:11px;
    box-shadow:0 1px 2px rgba(10,18,35,.025);
}
.moni-kpi-card span{font-size:.69rem;font-weight:690;color:var(--muted-text-color);line-height:1.25}
.moni-kpi-card strong{display:block;font-size:1.17rem;line-height:1.15;font-weight:760;letter-spacing:-.025em;color:var(--text-color);font-variant-numeric:tabular-nums}
.moni-kpi-card small{color:var(--muted-text-color);font-size:.68rem;line-height:1.35}

.moni-grid{gap:13px}
.moni-card{
    border-radius:11px;
    padding:17px;
    box-shadow:0 1px 2px rgba(10,18,35,.025);
}
.moni-card.two-thirds,.moni-card.two-third{grid-column:span 8}
.moni-card.third{grid-column:span 4}
.moni-card-head{gap:12px;margin-bottom:14px;padding-bottom:0}
.moni-card h3,.moni-card-head h3{font-size:.92rem;font-weight:720}
.moni-card-head p{font-size:.76rem;line-height:1.46;margin-top:4px}

.moni-field>span,
.moni-field>label{
    font-size:.72rem;
    line-height:1.25;
    font-weight:690;
    color:var(--card-text-color);
    letter-spacing:.002em;
}
.moni-field input,
.moni-field select,
.moni-field textarea,
.moni-select,
.moni-table input:not([type=checkbox]):not([type=radio]),
.moni-table select,
.moni-table textarea{
    min-height:39px;
    border-radius:8px;
    padding:8px 10px;
    font-size:.81rem;
}
.moni-select{
    border:1px solid var(--border-color);
    background:color-mix(in srgb,var(--background-color) 92%,var(--card-bg-color));
    color:var(--text-color);
    outline:none;
}
.moni-field textarea{min-height:96px}

.moni-btn{
    min-height:36px;
    padding:8px 12px;
    border-radius:8px;
    background:var(--primary-color);
    box-shadow:none;
    font-size:.76rem;
    font-weight:700;
}
.moni-btn:hover{transform:none;box-shadow:none;filter:brightness(1.035)}
.moni-btn.secondary{background:transparent}
.moni-btn.danger{background:#dc3545}
.moni-btn.success{background:#198754}
.moni-btn.warning{background:#c47f00}

.moni-help{
    padding:10px 11px;
    border-radius:9px;
    background:color-mix(in srgb,var(--background-color) 72%,var(--card-bg-color));
    font-size:.75rem;
}
.moni-table-wrap{border-radius:9px}
.moni-table th,.moni-table td{padding:10px 11px;font-size:.77rem}
.moni-table th{font-size:.62rem;letter-spacing:.055em;background:color-mix(in srgb,var(--card-bg-color) 92%,var(--background-color))}
.moni-table tbody tr:hover td{background:color-mix(in srgb,var(--primary-color) 4%,transparent)}
.moni-badge{min-height:22px;padding:3px 7px;font-size:.65rem}
.moni-alert{border-radius:9px;font-size:.77rem}

/* Bazı eski/yeni sayfalarda kullanılan özet bileşenlerinin ortak karşılığı. */
.moni-summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin:0 0 15px}
.moni-summary-item{display:flex;align-items:center;gap:10px;min-width:0;padding:12px 14px;background:var(--card-bg-color);border:1px solid var(--border-color);border-radius:11px}
.moni-summary-icon{width:34px;height:34px;border-radius:9px;display:grid;place-items:center;flex:0 0 auto;background:var(--primary-alpha-01);color:var(--accent-text-color)}
.moni-summary-item b{display:block;font-size:.98rem;line-height:1.1;font-variant-numeric:tabular-nums}
.moni-summary-item span{display:block;margin-top:3px;color:var(--muted-text-color);font-size:.67rem}

/* Boş veriyi profesyonel boş-durum gibi göster. */
.moni-table tbody tr:only-child td[colspan]{padding:28px 16px;text-align:center;color:var(--muted-text-color);background:color-mix(in srgb,var(--background-color) 58%,var(--card-bg-color));}

@media(max-width:1100px){
    .moni-kpi-grid,.moni-summary{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media(max-width:900px){
    .moni-card.two-thirds,.moni-card.two-third{grid-column:1/-1}
    .moni-hero{padding-top:0}
}
@media(max-width:560px){
    .moni-hero{padding:0 0 13px;border-radius:0}
    .moni-kpi-grid,.moni-summary{grid-template-columns:1fr 1fr;gap:8px}
    .moni-kpi-card{min-height:76px;padding:11px 12px}
    .moni-card{padding:14px}
}
</style>
CSS;
}
