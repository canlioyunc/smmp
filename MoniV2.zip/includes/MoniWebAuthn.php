<?php
if (defined('MONI_WEBAUTHN_LOADED')) return;
define('MONI_WEBAUTHN_LOADED', true);

function moni_b64u_enc(string $v): string {
    return rtrim(strtr(base64_encode($v), '+/', '-_'), '=');
}
function moni_b64u_dec(string $v): string {
    $v = strtr($v, '-_', '+/');
    $v .= str_repeat('=', (4 - strlen($v) % 4) % 4);
    return base64_decode($v, true) ?: '';
}
function moni_webauthn_request_host(): string {
    $canonical=function_exists('moni_canonical_site_url')?moni_canonical_site_url():(defined('SITE_URL')?(string)SITE_URL:'');
    $mainHost=strtolower((string)(parse_url($canonical,PHP_URL_HOST)?:''));
    $requestHost=strtolower(preg_replace('/:\d+$/','',(string)($_SERVER['HTTP_HOST']??'')));
    if($requestHost!==''&&$mainHost!==''&&hash_equals($mainHost,$requestHost))return $requestHost;
    // Child panel alan adı yalnız veritabanında aktif bir child panel olarak tanımlıysa RP olarak kabul edilir.
    if($requestHost!==''&&function_exists('moni_child_panel_context')&&isset($GLOBALS['db'])&&$GLOBALS['db'] instanceof PDO){
        try{$ctx=moni_child_panel_context($GLOBALS['db']);$domain=strtolower(preg_replace('/:\d+$/','',(string)($ctx['domain']??'')));if($domain!==''&&hash_equals($domain,$requestHost))return $requestHost;}catch(Throwable $ignore){}
    }
    return $mainHost!==''?$mainHost:'localhost';
}
function moni_webauthn_rpid(): string { return moni_webauthn_request_host(); }
function moni_webauthn_origin(): string {
    $host=moni_webauthn_request_host();$canonical=function_exists('moni_canonical_site_url')?moni_canonical_site_url():(defined('SITE_URL')?(string)SITE_URL:'');
    $mainHost=strtolower((string)(parse_url($canonical,PHP_URL_HOST)?:''));
    if($mainHost!==''&&hash_equals($mainHost,$host)){
        $u=parse_url($canonical);return strtolower((string)($u['scheme']??'https')).'://'.$host.(isset($u['port'])?':'.$u['port']:'');
    }
    return 'https://'.$host;
}
function moni_webauthn_client_check(string $clientData, string $expectedType, string $challenge): array {
    $d = json_decode($clientData, true);
    if (!is_array($d)) return ['ok'=>false,'error'=>'Geçersiz clientDataJSON.'];
    if (($d['type'] ?? '') !== $expectedType) return ['ok'=>false,'error'=>'WebAuthn işlem türü uyuşmuyor.'];
    if (!hash_equals($challenge, (string)($d['challenge'] ?? ''))) return ['ok'=>false,'error'=>'WebAuthn challenge uyuşmuyor.'];
    if (!hash_equals(moni_webauthn_origin(), rtrim((string)($d['origin'] ?? ''), '/'))) return ['ok'=>false,'error'=>'WebAuthn origin uyuşmuyor.'];
    return ['ok'=>true,'data'=>$d];
}
function moni_webauthn_authenticator_check(string $authenticatorData, bool $requireUv=true): array {
    if (strlen($authenticatorData) < 37) return ['ok'=>false,'error'=>'Geçersiz authenticator verisi.'];
    $expectedRp = hash('sha256', moni_webauthn_rpid(), true);
    if (!hash_equals($expectedRp, substr($authenticatorData, 0, 32))) return ['ok'=>false,'error'=>'WebAuthn RP doğrulaması başarısız.'];
    $flags = ord($authenticatorData[32]);
    if (($flags & 0x01) !== 0x01) return ['ok'=>false,'error'=>'Kullanıcı varlığı doğrulanamadı.'];
    if ($requireUv && ($flags & 0x04) !== 0x04) return ['ok'=>false,'error'=>'Cihaz kullanıcı doğrulaması gerekli.'];
    $count = unpack('N', substr($authenticatorData, 33, 4))[1] ?? 0;
    return ['ok'=>true,'flags'=>$flags,'sign_count'=>(int)$count];
}
function moni_der_to_pem(string $der): string {
    return "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END PUBLIC KEY-----\n";
}

function moni_webauthn_register_options(PDO $db, int $userId): array {
    if (!moni_request_is_https() && moni_webauthn_rpid() !== 'localhost') {
        return ['success'=>false,'error'=>'Passkey kaydı HTTPS bağlantısı gerektirir.'];
    }
    $st = $db->prepare("SELECT id,username,email FROM users WHERE id=? AND status='active' LIMIT 1");
    $st->execute([$userId]);
    $u = $st->fetch(PDO::FETCH_ASSOC);
    if (!$u) return ['success'=>false,'error'=>'Kullanıcı bulunamadı.'];

    $challenge = moni_b64u_enc(random_bytes(32));
    $_SESSION['webauthn_register_challenge'] = $challenge;
    $_SESSION['webauthn_register_uid'] = $userId;
    $_SESSION['webauthn_register_expires'] = time() + 300;

    $exclude = [];
    $q = $db->prepare("SELECT credential_id FROM webauthn_credentials WHERE user_id=?");
    $q->execute([$userId]);
    foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $id) $exclude[] = ['type'=>'public-key','id'=>$id];

    // User handle tahmin edilebilir kullanıcı ID'sinin kendisi değil, hesaba bağlı sabit bir hash'tir.
    $userHandle = substr(hash('sha256', 'moni-webauthn-user|' . $userId, true), 0, 32);
    return ['success'=>true,'publicKey'=>[
        'challenge'=>$challenge,
        'rp'=>['name'=>getSetting('site_name', $GLOBALS['siteSettings']['name'] ?? 'SMM Panel'),'id'=>moni_webauthn_rpid()],
        'user'=>['id'=>moni_b64u_enc($userHandle),'name'=>$u['email'] ?: $u['username'],'displayName'=>$u['username']],
        'pubKeyCredParams'=>[['type'=>'public-key','alg'=>-7],['type'=>'public-key','alg'=>-257]],
        'timeout'=>60000,
        'attestation'=>'none',
        'authenticatorSelection'=>['residentKey'=>'preferred','userVerification'=>'required'],
        'excludeCredentials'=>$exclude
    ]];
}

function moni_webauthn_register_finish(PDO $db, int $userId, array $in): array {
    $challenge = $_SESSION['webauthn_register_challenge'] ?? '';
    $pending = (int)($_SESSION['webauthn_register_uid'] ?? 0);
    $expires = (int)($_SESSION['webauthn_register_expires'] ?? 0);
    unset($_SESSION['webauthn_register_challenge'], $_SESSION['webauthn_register_uid'], $_SESSION['webauthn_register_expires']);
    if (!$challenge || $pending !== $userId || $expires < time()) return ['success'=>false,'error'=>'WebAuthn kayıt oturumu sona ermiş.'];

    $client = moni_b64u_dec((string)($in['clientDataJSON'] ?? ''));
    $check = moni_webauthn_client_check($client, 'webauthn.create', $challenge);
    if (!$check['ok']) return ['success'=>false,'error'=>$check['error']];

    $authData = moni_b64u_dec((string)($in['authenticatorData'] ?? ''));
    $authCheck = moni_webauthn_authenticator_check($authData, true);
    if (!$authCheck['ok']) return ['success'=>false,'error'=>$authCheck['error']];

    $cred = (string)($in['credentialId'] ?? '');
    $pub = moni_b64u_dec((string)($in['publicKey'] ?? ''));
    $alg = (int)($in['algorithm'] ?? 0);
    if ($cred === '' || $pub === '' || !in_array($alg, [-7,-257], true)) return ['success'=>false,'error'=>'Tarayıcı public key bilgisini sağlamadı.'];
    if (strlen($cred) > 1024 || strlen($pub) > 8192) return ['success'=>false,'error'=>'Passkey verisi izin verilen sınırı aşıyor.'];

    // DER SubjectPublicKeyInfo gerçekten OpenSSL tarafından okunabiliyor mu kontrol et.
    $pkey = @openssl_pkey_get_public(moni_der_to_pem($pub));
    if ($pkey === false) return ['success'=>false,'error'=>'Passkey public key biçimi doğrulanamadı.'];

    $name = trim((string)($in['name'] ?? ''));
    if ($name === '') $name = 'Passkey · ' . date('d.m.Y H:i');
    try {
        $db->prepare("INSERT INTO webauthn_credentials(user_id,credential_id,public_key_der,algorithm,sign_count,name,transports,created_at) VALUES(?,?,?,?,?,?,?,NOW())")
           ->execute([$userId,$cred,base64_encode($pub),$alg,(int)$authCheck['sign_count'],substr($name,0,120),substr((string)($in['transports']??''),0,255)]);
        moni_security_event($userId,'passkey_added','info',['name'=>$name]);
        return ['success'=>true];
    } catch (Throwable $e) {
        return ['success'=>false,'error'=>'Bu passkey zaten kayıtlı olabilir.'];
    }
}

function moni_webauthn_auth_options(PDO $db, string $identifier): array {
    $identifier = trim($identifier);
    $attemptKey = 'passkey:' . mb_strtolower($identifier, 'UTF-8');
    [$blocked] = moni_auth_blocked($db, $attemptKey, moni_client_ip());
    if ($blocked) {
        moni_security_event(null,'passkey_rate_limited','warning',['identifier_hash'=>hash('sha256',mb_strtolower($identifier,'UTF-8'))]);
        return ['success'=>false,'error'=>'Passkey ile giriş şu anda kullanılamıyor. Daha sonra tekrar deneyin.'];
    }
    $st = $db->prepare("SELECT id,username,email,status FROM users WHERE (username=? OR email=?) LIMIT 1");
    $st->execute([$identifier,$identifier]);
    $u = $st->fetch(PDO::FETCH_ASSOC);
    if (!$u || $u['status'] !== 'active') return ['success'=>false,'error'=>'Passkey ile giriş kullanılamıyor.'];

    $q = $db->prepare("SELECT credential_id FROM webauthn_credentials WHERE user_id=?");
    $q->execute([$u['id']]);
    $ids = $q->fetchAll(PDO::FETCH_COLUMN);
    if (!$ids) return ['success'=>false,'error'=>'Passkey ile giriş kullanılamıyor.'];

    $challenge = moni_b64u_enc(random_bytes(32));
    $_SESSION['webauthn_auth_challenge'] = $challenge;
    $_SESSION['webauthn_auth_uid'] = (int)$u['id'];
    $_SESSION['webauthn_auth_attempt_key'] = $attemptKey;
    $_SESSION['webauthn_auth_expires'] = time() + 300;
    return ['success'=>true,'publicKey'=>[
        'challenge'=>$challenge,
        'rpId'=>moni_webauthn_rpid(),
        'timeout'=>60000,
        'userVerification'=>'required',
        'allowCredentials'=>array_map(fn($id)=>['type'=>'public-key','id'=>$id],$ids)
    ]];
}

function moni_webauthn_auth_finish(PDO $db, array $in): array {
    $challenge = $_SESSION['webauthn_auth_challenge'] ?? '';
    $uid = (int)($_SESSION['webauthn_auth_uid'] ?? 0);
    $attemptKey = (string)($_SESSION['webauthn_auth_attempt_key'] ?? ('passkey-user:' . $uid));
    $expires = (int)($_SESSION['webauthn_auth_expires'] ?? 0);
    unset($_SESSION['webauthn_auth_challenge'], $_SESSION['webauthn_auth_uid'], $_SESSION['webauthn_auth_attempt_key'], $_SESSION['webauthn_auth_expires']);

    $fail = function(string $error) use ($db,$uid,$attemptKey): array {
        moni_auth_record($db,$attemptKey,moni_client_ip(),false);
        moni_security_event($uid ?: null,'passkey_login_failed','warning',['reason'=>$error]);
        return ['success'=>false,'error'=>$error];
    };

    if (!$challenge || !$uid || $expires < time()) return $fail('WebAuthn giriş oturumu sona ermiş.');
    [$blocked] = moni_auth_blocked($db,$attemptKey,moni_client_ip());
    if ($blocked) return $fail('Çok fazla başarısız Passkey denemesi yapıldı. Daha sonra tekrar deneyin.');

    $client = moni_b64u_dec((string)($in['clientDataJSON'] ?? ''));
    $auth = moni_b64u_dec((string)($in['authenticatorData'] ?? ''));
    $sig = moni_b64u_dec((string)($in['signature'] ?? ''));
    $cred = (string)($in['credentialId'] ?? '');

    $check = moni_webauthn_client_check($client,'webauthn.get',$challenge);
    if (!$check['ok']) return $fail($check['error']);
    $authCheck = moni_webauthn_authenticator_check($auth,true);
    if (!$authCheck['ok']) return $fail($authCheck['error']);
    if ($sig === '' || $cred === '') return $fail('Geçersiz authenticator cevabı.');

    $st = $db->prepare("SELECT * FROM webauthn_credentials WHERE user_id=? AND credential_id=? LIMIT 1");
    $st->execute([$uid,$cred]);
    $c = $st->fetch(PDO::FETCH_ASSOC);
    if (!$c) return $fail('Passkey doğrulanamadı.');

    $pub = base64_decode((string)$c['public_key_der'], true);
    if (!$pub) return $fail('Passkey public key okunamadı.');
    $signed = $auth . hash('sha256',$client,true);
    $verify = @openssl_verify($signed,$sig,moni_der_to_pem($pub),OPENSSL_ALGO_SHA256);
    if ($verify !== 1) return $fail('Passkey imzası doğrulanamadı.');

    $count = (int)$authCheck['sign_count'];
    $old = (int)$c['sign_count'];
    if ($count > 0 && $old > 0 && $count <= $old) return $fail('Passkey sayaç doğrulaması başarısız.');
    $storedCount = $count > 0 ? $count : $old;

    $db->prepare("UPDATE webauthn_credentials SET sign_count=?,last_used_at=NOW() WHERE id=?")->execute([$storedCount,$c['id']]);
    $u = $db->prepare("SELECT * FROM users WHERE id=? AND status='active'");
    $u->execute([$uid]);
    $user = $u->fetch(PDO::FETCH_ASSOC);
    if (!$user) return $fail('Hesap aktif değil.');

    moni_auth_record($db,$attemptKey,moni_client_ip(),true);
    moni_complete_login($db,$user,false,'passkey');
    return ['success'=>true,'redirect'=>$user['role']==='admin'?'/admin/':'/kullanici/'];
}
