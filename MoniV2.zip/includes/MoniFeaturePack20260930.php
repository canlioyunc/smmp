<?php
if (defined('MONI_FEATURE_PACK_20260930')) return;
define('MONI_FEATURE_PACK_20260930', true);

function moni_feature_pack_20260930_migrate(PDO $db): void {
    static $done=false; if($done)return; $done=true;
    $revision='2026-09-30.6';
    try{
        if(function_exists('moni_v2_compat_setting') && moni_v2_compat_setting($db,'moni_feature_pack_20260930_revision','')===$revision){
            $ready=moni_table_ready($db,'service_auto_badges')&&moni_table_ready($db,'order_status_reason_catalog')&&moni_table_ready($db,'order_status_reason_history');
            if($ready && moni_v2_compat_column_exists($db,'orders','reason_code') && moni_v2_compat_column_exists($db,'api_sandbox_orders','scenario')) return;
        }
        $ddl=[];
        $ddl[]="CREATE TABLE IF NOT EXISTS service_auto_badges (service_id int NOT NULL,badge_key varchar(40) NOT NULL,label varchar(80) NOT NULL,icon varchar(60) NOT NULL DEFAULT 'fa-award',score decimal(8,2) NOT NULL DEFAULT 0,reason varchar(500) NULL,calculated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(service_id,badge_key),KEY idx_auto_badges_key_score(badge_key,score,calculated_at),KEY idx_auto_badges_service_time(service_id,calculated_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS order_status_reason_catalog (code varchar(64) NOT NULL,status varchar(40) NOT NULL,user_label varchar(190) NOT NULL,admin_label varchar(255) NOT NULL,user_description varchar(500) NULL,admin_description varchar(1000) NULL,is_user_visible tinyint(1) NOT NULL DEFAULT 1,is_active tinyint(1) NOT NULL DEFAULT 1,sort_order int NOT NULL DEFAULT 0,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(code),KEY idx_reason_status(status,is_active,sort_order)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS order_status_reason_mappings (id bigint NOT NULL AUTO_INCREMENT,provider_id int NULL,match_field enum('status','message','both') NOT NULL DEFAULT 'both',match_type enum('contains','equals','regex') NOT NULL DEFAULT 'contains',raw_pattern varchar(255) NOT NULL,reason_code varchar(64) NOT NULL,priority int NOT NULL DEFAULT 100,is_active tinyint(1) NOT NULL DEFAULT 1,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY idx_reason_mapping_provider(provider_id,is_active,priority),KEY idx_reason_mapping_code(reason_code)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS order_status_reason_history (id bigint NOT NULL AUTO_INCREMENT,order_id int NOT NULL,status varchar(40) NOT NULL,reason_code varchar(64) NOT NULL,source varchar(40) NOT NULL DEFAULT 'system',provider_id int NULL,raw_status varchar(190) NULL,raw_message varchar(1000) NULL,user_message varchar(500) NULL,admin_message varchar(1000) NULL,created_by int NULL,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY idx_reason_history_order(order_id,id),KEY idx_reason_history_code(reason_code,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        foreach($ddl as $sql)$db->exec($sql);
        if(function_exists('moni_v2_compat_add_column')){
            moni_v2_compat_add_column($db,'orders','reason_code','varchar(64) NULL');
            moni_v2_compat_add_column($db,'orders','reason_source','varchar(40) NULL');
            moni_v2_compat_add_column($db,'orders','reason_updated_at','datetime NULL');
            moni_v2_compat_add_column($db,'api_sandbox_orders','scenario',"varchar(60) NOT NULL DEFAULT 'happy_path'");
            moni_v2_compat_add_column($db,'api_sandbox_orders','scenario_started_at','datetime NULL');
            moni_v2_compat_add_column($db,'api_sandbox_orders','scenario_data_json','mediumtext NULL');
        }
        try{$db->exec("ALTER TABLE orders ADD KEY idx_orders_reason_code(reason_code,reason_updated_at)");}catch(Throwable $ignore){}
        try{$db->exec("ALTER TABLE api_sandbox_orders ADD KEY idx_sandbox_scenario(user_id,scenario,created_at)");}catch(Throwable $ignore){}

        $reasons=[
            ['pending_queue','pending','Kuyrukta bekliyor','Sipariş gönderim kuyruğunda','Siparişiniz sıraya alındı ve sağlayıcıya gönderilmeyi bekliyor.','Henüz provider order ID oluşmadı.',0,10],
            ['provider_processing','processing','İşleme alındı','Sağlayıcı işliyor','Siparişiniz sağlayıcı tarafından işleme alındı.','Provider processing/in progress yanıtı.',1,20],
            ['completed_success','completed','Başarıyla tamamlandı','Tamamlandı','Sipariş başarıyla tamamlandı.','Provider terminal completed sonucu.',1,30],
            ['partial_provider','partial','Kısmi tamamlandı','Sağlayıcı kısmi tamamladı','Siparişin bir bölümü tamamlandı; eksik bölüm için sistem politikası uygulanır.','Provider partial sonucu veya remains > 0.',1,40],
            ['cancelled_provider','cancelled','Sağlayıcı tarafından iptal edildi','Provider iptali','Sağlayıcı siparişi iptal etti. Uygunsa bakiye iadesi otomatik işlenir.','Provider cancelled/canceled sonucu.',1,50],
            ['cancelled_user','cancelled','Kullanıcı tarafından iptal edildi','Kullanıcı iptali','Sipariş sizin talebinizle iptal edildi.','Kullanıcı iptal akışı.',1,55],
            ['cancelled_admin','cancelled','Yetkili tarafından iptal edildi','Admin iptali','Sipariş operasyon ekibi tarafından iptal edildi.','Admin manuel durum değişikliği.',1,56],
            ['refunded_provider','refunded','Ücret iade edildi','Provider iadesi','Sipariş ücreti bakiyenize iade edildi.','Provider refunded sonucu.',1,60],
            ['provider_rejected','error','Sağlayıcı siparişi reddetti','Provider rejected','Sağlayıcı siparişi kabul etmedi.','Rejected/invalid/denied benzeri provider cevabı.',1,70],
            ['invalid_target','cancelled','Hedef bağlantı uygun değil','Hedef politikası reddi','Girilen hedef bu servis için uygun olmadığı için sipariş işlenemedi.','Target validation veya platform kuralı reddi.',1,80],
            ['provider_timeout','error','Sağlayıcı yanıt vermedi','Provider timeout','Sağlayıcı geçici olarak yanıt vermedi. Sipariş operasyon ekibi tarafından kontrol ediliyor.','Timeout/connection failure.',1,90],
            ['provider_unknown','error','Sağlayıcı sonucu doğrulanamadı','Belirsiz provider sonucu','Sağlayıcı sonucu doğrulanamadığı için sipariş güvenli incelemeye alındı.','Ambiguous/unknown provider response.',1,100],
            ['manual_review','processing','Kontrol ediliyor','Manuel inceleme','Siparişiniz operasyon ekibi tarafından kontrol ediliyor.','Manuel review veya güvenlik kontrolü.',1,110],
            ['system_error','error','Teknik işlem hatası','Sistem hatası','Sipariş işlenirken teknik bir hata oluştu.','Genel güvenli fallback nedeni.',1,999],
        ];
        $st=$db->prepare("INSERT INTO order_status_reason_catalog(code,status,user_label,admin_label,user_description,admin_description,is_user_visible,sort_order) VALUES(?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE status=VALUES(status),user_label=VALUES(user_label),admin_label=VALUES(admin_label),user_description=VALUES(user_description),admin_description=VALUES(admin_description),is_user_visible=VALUES(is_user_visible),sort_order=VALUES(sort_order)");
        foreach($reasons as $r)$st->execute($r);

        // Existing choices are preserved by INSERT IGNORE; manifest loader keeps metadata current.
        try{$p=$db->prepare("INSERT IGNORE INTO plugins(slug,name,description,version,is_enabled,is_core) VALUES(?,?,?,?,?,0)");
            $p->execute(['service_auto_badges','Otomatik Servis Rozet Motoru','Gerçek sipariş, kalite, hız, drop ve talep verilerinden servis rozetleri üretir.','1.0.0',0]);
            $p->execute(['order_status_reasons','Sipariş Durum Neden Kodları','Sipariş durumlarının nedenini standart kod, kullanıcı açıklaması, provider eşleme ve geçmiş ile yönetir.','1.0.0',0]);
        }catch(Throwable $ignore){}
        try{$c=$db->prepare("INSERT IGNORE INTO cron_tasks(task_key,name,interval_minutes,batch_size,is_enabled) VALUES(?,?,?,?,?)");$c->execute(['service_auto_badges','Otomatik Servis Rozetlerini Hesapla',15,300,0]);}catch(Throwable $ignore){}
        foreach([
            'auto_badge_min_sample'=>'10','auto_badge_fast_seconds'=>'3600','auto_badge_stable_score'=>'90','auto_badge_low_drop_percent'=>'2.5','auto_badge_popular_30d_orders'=>'50','auto_badge_best_price_percentile'=>'20','auto_badge_max_per_service'=>'3'
        ] as $k=>$v){try{$s=$db->prepare("INSERT IGNORE INTO plugin_settings(plugin_slug,setting_key,setting_value) VALUES('service_auto_badges',?,?)");$s->execute([$k,$v]);}catch(Throwable $ignore){}}
        if(function_exists('moni_v2_compat_set_setting'))moni_v2_compat_set_setting($db,'moni_feature_pack_20260930_revision',$revision);
    }catch(Throwable $e){error_log('Moni feature pack 20260930 migration failed: '.$e->getMessage());$GLOBALS['moni_feature_pack_20260930_error']=$e->getMessage();}
}

function moni_sandbox_scenarios(): array {
    return [
        'happy_path'=>['label'=>'Başarılı Akış','description'=>'Pending → Processing → Completed','duration'=>18],
        'slow_success'=>['label'=>'Yavaş Başarılı','description'=>'Uzun pending → Processing → Completed','duration'=>45],
        'partial'=>['label'=>'Kısmi Tamamlanma','description'=>'Processing sonrası Partial ve remains üretir','duration'=>20],
        'cancelled'=>['label'=>'Sağlayıcı İptali','description'=>'Processing sonrası Cancelled','duration'=>16],
        'provider_timeout'=>['label'=>'Provider Timeout','description'=>'Durum sorgusunda geçici 504 hatası simüle eder','duration'=>24],
        'provider_error'=>['label'=>'Provider Hatası','description'=>'Processing sonrası Error','duration'=>14],
        'refill_flow'=>['label'=>'Refill Akışı','description'=>'Completed sonrası refill isteği kabul edilir','duration'=>18],
    ];
}
function moni_sandbox_simulated_state(array $order): array {
    $scenario=(string)($order['scenario']??'happy_path');$defs=moni_sandbox_scenarios();if(!isset($defs[$scenario]))$scenario='happy_path';
    $start=strtotime((string)($order['scenario_started_at']??$order['created_at']??'now'))?:time();$e=max(0,time()-$start);$qty=max(1,(int)($order['quantity']??1));
    $state=['status'=>'pending','start_count'=>'0','remains'=>(string)$qty,'scenario'=>$scenario,'elapsed_seconds'=>$e,'terminal'=>false];
    if($scenario==='happy_path'||$scenario==='refill_flow'){
        if($e>=18){$state['status']='completed';$state['remains']='0';$state['terminal']=true;}elseif($e>=6){$state['status']='processing';$state['remains']=(string)max(0,(int)round($qty*(1-min(1,($e-6)/12))));}
    }elseif($scenario==='slow_success'){
        if($e>=45){$state['status']='completed';$state['remains']='0';$state['terminal']=true;}elseif($e>=28){$state['status']='processing';$state['remains']=(string)max(0,(int)round($qty*(1-min(1,($e-28)/17))));}
    }elseif($scenario==='partial'){
        if($e>=20){$state['status']='partial';$state['remains']=(string)max(1,(int)round($qty*.28));$state['terminal']=true;}elseif($e>=5){$state['status']='processing';$state['remains']=(string)max(1,(int)round($qty*.55));}
    }elseif($scenario==='cancelled'){
        if($e>=16){$state['status']='cancelled';$state['terminal']=true;}elseif($e>=5)$state['status']='processing';
    }elseif($scenario==='provider_error'){
        if($e>=14){$state['status']='error';$state['terminal']=true;}elseif($e>=4)$state['status']='processing';
    }elseif($scenario==='provider_timeout'){
        if($e>=24){$state['status']='completed';$state['remains']='0';$state['terminal']=true;}elseif($e>=7)$state['status']='processing';
        if($e>=10&&$e<18)$state['simulate_timeout']=true;
    }
    return $state;
}


function moni_cron_trend_summary(PDO $db,int $days=7):array{
    if(!moni_table_ready($db,'cron_runs'))return [];$days=max(1,min(90,$days));
    $sql="SELECT r.task_key,COALESCE(t.name,r.task_key) task_name,COUNT(*) runs,SUM(r.status='success') success_runs,SUM(r.status='error') error_runs,ROUND(AVG(COALESCE(r.duration_ms,0))) avg_ms,MAX(COALESCE(r.duration_ms,0)) max_ms,COALESCE(SUM(r.processed_count),0) processed FROM cron_runs r LEFT JOIN cron_tasks t ON t.task_key=r.task_key WHERE r.started_at>=DATE_SUB(NOW(),INTERVAL {$days} DAY) GROUP BY r.task_key,t.name ORDER BY avg_ms DESC";
    try{$rows=$db->query($sql)->fetchAll(PDO::FETCH_ASSOC);foreach($rows as &$r){$d=$db->prepare("SELECT duration_ms FROM cron_runs WHERE task_key=? AND started_at>=DATE_SUB(NOW(),INTERVAL {$days} DAY) AND duration_ms IS NOT NULL ORDER BY duration_ms");$d->execute([$r['task_key']]);$vals=array_map('intval',$d->fetchAll(PDO::FETCH_COLUMN));$n=count($vals);$r['p50_ms']=$n?$vals[(int)floor(($n-1)*.50)]:0;$r['p95_ms']=$n?$vals[(int)floor(($n-1)*.95)]:0;$r['success_rate']=$r['runs']?round(((int)$r['success_runs']/(int)$r['runs'])*100,1):0;}unset($r);return $rows;}catch(Throwable $e){return [];}
}
function moni_cron_daily_trend(PDO $db,int $days=14):array{if(!moni_table_ready($db,'cron_runs'))return [];$days=max(2,min(90,$days));try{$q=$db->query("SELECT DATE(started_at) day,COUNT(*) runs,ROUND(AVG(COALESCE(duration_ms,0))) avg_ms,MAX(COALESCE(duration_ms,0)) max_ms,SUM(status='error') errors,COALESCE(SUM(processed_count),0) processed FROM cron_runs WHERE started_at>=DATE_SUB(CURDATE(),INTERVAL {$days} DAY) GROUP BY DATE(started_at) ORDER BY day");return $q->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){return [];}}
