<?php
/**
 * v2 operasyon katmanı: asenkron provider gönderimi, kalite/kar koruma,
 * coğrafi hedefleme, çalışma saatleri, OpenAPI/SDK ve durum eşleme yardımcıları.
 */
if (defined('MONI_V2_OPS_LOADED')) return;
define('MONI_V2_OPS_LOADED', true);

/* ------------------------- Service geo targeting ------------------------- */
function moni_remote_geo_meta(array $remote): array {
    $options=[];
    foreach (['countries','country','target_countries','geo_countries','locations','geo'] as $k) {
        if (!array_key_exists($k,$remote)) continue;
        $v=$remote[$k];
        if (is_string($v)) $v=preg_split('/[,;|]+/', $v);
        if (!is_array($v)) continue;
        foreach ($v as $x) {
            if (is_array($x)) $x=$x['code']??$x['id']??$x['name']??'';
            $x=trim((string)$x);
            if ($x!=='' && mb_strlen($x,'UTF-8')<=80) $options[]=$x;
        }
    }
    $options=array_values(array_unique($options));
    $param='country';
    foreach (['geo_param','country_parameter','target_parameter'] as $k) {
        if (!empty($remote[$k]) && preg_match('/^[a-zA-Z0-9_]{2,40}$/',(string)$remote[$k])) { $param=(string)$remote[$k]; break; }
    }
    return ['supported'=>!empty($options),'options'=>$options,'param'=>$param];
}
function moni_service_geo_targets(array $service): array {
    if (empty($service['geo_supported'])) return [];
    $j=json_decode((string)($service['geo_targets_json']??'[]'),true);
    if (!is_array($j)) return [];
    return array_values(array_unique(array_filter(array_map(static fn($x)=>trim((string)$x),$j),static fn($x)=>$x!=='')));
}
function moni_validate_geo_target(array $service,?string $target): array {
    $targets=moni_service_geo_targets($service);
    if (!$targets) return ['ok'=>true,'target'=>null];
    $target=trim((string)$target);
    if ($target==='') return ['ok'=>false,'error'=>'Bu servis için coğrafi hedef seçmelisiniz.'];
    foreach ($targets as $allowed) if (mb_strtolower($allowed,'UTF-8')===mb_strtolower($target,'UTF-8')) return ['ok'=>true,'target'=>$allowed];
    return ['ok'=>false,'error'=>'Seçilen coğrafi hedef bu servis tarafından desteklenmiyor.'];
}

/* ------------------------- Service working hours ------------------------- */
function moni_service_schedule_check(PDO $db,int $serviceId): array {
    if (!moni_table_ready($db,'service_working_hours')) return ['open'=>true];
    try {
        $s=$db->prepare("SELECT * FROM service_working_hours WHERE service_id=? ORDER BY day_of_week,start_time");$s->execute([$serviceId]);$rows=$s->fetchAll(PDO::FETCH_ASSOC);
        if (!$rows) return ['open'=>true];
        $tz=(string)getSetting('timezone','Europe/Istanbul');try{$now=new DateTime('now',new DateTimeZone($tz));}catch(Throwable $e){$now=new DateTime();}
        $day=(int)$now->format('N');$time=$now->format('H:i:s');$today=array_values(array_filter($rows,static fn($r)=>(int)$r['day_of_week']===$day));
        if (!$today) return ['open'=>false,'error'=>'Bu servis bugün sipariş kabul etmiyor.'];
        foreach ($today as $r) {
            if (!empty($r['is_closed'])) continue;
            $start=(string)$r['start_time'];$end=(string)$r['end_time'];
            if ($start<=$end) { if ($time>=$start && $time<=$end) return ['open'=>true]; }
            else { if ($time>=$start || $time<=$end) return ['open'=>true]; }
        }
        return ['open'=>false,'error'=>'Bu servis şu anda çalışma saatleri dışında.'];
    } catch(Throwable $e) { return ['open'=>true]; }
}

/* ------------------------- Social account/link pre-check ------------------------- */
function moni_social_target_is_username(string $target): bool {
    $target=trim($target);
    if($target==='')return false;
    // URL benzeri girdileri kullanıcı adı olarak kabul etme.
    if(str_contains($target,'://')||str_contains($target,'/')||str_contains($target,'?')||str_contains($target,'#'))return false;
    return (bool)preg_match('/^@?[\p{L}\p{N}._-]{1,100}$/u',$target);
}
function moni_social_precheck(PDO $db,string $link): array {
    if (!moni_plugin_enabled('social_account_precheck',$db)) return ['ok'=>true,'skipped'=>true];
    $link=trim($link);
    // Bazı servisler URL yerine doğrudan kullanıcı adı / @kullanıcıadı bekler.
    // Bu hedeflerde ağ/DNS kontrolü yapılamaz; biçim doğrulaması yeterlidir.
    if(moni_social_target_is_username($link))return ['ok'=>true,'skipped'=>true,'target_type'=>'username','username'=>ltrim($link,'@')];
    $checkUrl=$link;
    if(!preg_match('#^[a-z][a-z0-9+.-]*://#i',$checkUrl)&&preg_match('/^[a-z0-9.-]+\.[a-z]{2,}(?:\/|$)/i',$checkUrl))$checkUrl='https://'.$checkUrl;
    $u=@parse_url($checkUrl);if(!$u||!in_array(strtolower((string)($u['scheme']??'')),['http','https'],true)||empty($u['host']))return ['ok'=>false,'error'=>'Geçerli bir sosyal medya bağlantısı veya kullanıcı adı girin.'];
    $host=strtolower(trim((string)$u['host'],'.'));$scheme=strtolower((string)($u['scheme']??''));$port=(int)($u['port']??($scheme==='https'?443:80));
    if(!in_array($port,[80,443],true))return ['ok'=>false,'error'=>'Sosyal medya bağlantısında standart dışı port kullanılamaz.'];
    $resolved=function_exists('moni_resolve_public_host')?moni_resolve_public_host($host):null;
    if ($resolved===null) return ['ok'=>false,'error'=>'Bu bağlantı güvenli bir herkese açık hedefe gitmiyor.'];
    $known=['instagram.com','www.instagram.com','tiktok.com','www.tiktok.com','youtube.com','www.youtube.com','youtu.be','x.com','www.x.com','twitter.com','www.twitter.com','facebook.com','www.facebook.com','fb.watch','t.me','telegram.me','threads.net','www.threads.net'];
    $matched=false;foreach($known as $d){if($host===$d||str_ends_with($host,'.'.$d)){$matched=true;break;}}
    if(!$matched && (string)moni_plugin_setting('social_account_precheck','known_domains_only','0')==='1')return ['ok'=>false,'error'=>'Bu servis için desteklenmeyen bir sosyal medya alan adı kullanıldı.'];
    if((string)moni_plugin_setting('social_account_precheck','network_check','0')!=='1')return ['ok'=>true,'platform_host'=>$host];
    if(!function_exists('curl_init'))return ['ok'=>true,'platform_host'=>$host,'warning'=>'cURL olmadığı için uzak kontrol atlandı.'];
    $ch=curl_init($checkUrl);curl_setopt_array($ch,[CURLOPT_NOBODY=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>5,CURLOPT_CONNECTTIMEOUT=>3,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_RESOLVE=>[$host.':'.$port.':'.$resolved],CURLOPT_USERAGENT=>'Mozilla/5.0 MoniPrecheck/2']);curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);
    if($err)return ['ok'=>false,'error'=>'Sosyal bağlantıya erişilemedi.'];
    if(in_array($http,[404,410],true))return ['ok'=>false,'error'=>'Sosyal hesap/içerik bulunamadı veya kaldırılmış.'];
    return ['ok'=>true,'http_status'=>$http,'platform_host'=>$host];
}

/* ------------------------- Provider status mapping ------------------------- */
function moni_provider_status_normalize(PDO $db,int $providerId,string $raw): string {
    $rawNorm=mb_strtolower(trim($raw),'UTF-8');
    if(moni_table_ready($db,'provider_status_mappings')){
        try{
            $s=$db->prepare("SELECT local_status FROM provider_status_mappings WHERE raw_status=? AND (provider_id=? OR provider_id IS NULL) ORDER BY provider_id IS NULL ASC,id DESC LIMIT 1");$s->execute([$rawNorm,$providerId]);$v=$s->fetchColumn();if($v!==false)return (string)$v;
        }catch(Throwable $e){}
    }
    $map=['completed'=>'completed','complete'=>'completed','partial'=>'partial','partially completed'=>'partial','canceled'=>'cancelled','cancelled'=>'cancelled','cancel'=>'cancelled','refunded'=>'refunded','fail'=>'cancelled','failed'=>'cancelled','in progress'=>'in_progress','inprogress'=>'in_progress','processing'=>'processing','pending'=>'pending'];
    return $map[$rawNorm]??$rawNorm;
}

/* ------------------------- Async order dispatch queue ------------------------- */
function moni_enqueue_order_dispatch(PDO $db,int $orderId): array {
    if(!moni_table_ready($db,'order_dispatch_jobs'))return ['ok'=>false,'error'=>'Sipariş gönderim kuyruğu hazır değil.'];
    try{
        $s=$db->prepare("SELECT o.id,o.status,o.api_order_id,s.api_provider_id,s.api_service_id FROM orders o JOIN services s ON s.id=o.service_id WHERE o.id=? LIMIT 1");$s->execute([$orderId]);$o=$s->fetch(PDO::FETCH_ASSOC);if(!$o)return ['ok'=>false,'error'=>'Sipariş bulunamadı.'];
        if(!empty($o['api_order_id']))return ['ok'=>true,'already_sent'=>true];
        if(empty($o['api_provider_id'])||empty($o['api_service_id']))return ['ok'=>true,'manual'=>true];
        if(in_array((string)$o['status'],['completed','partial','cancelled','refunded','error'],true))return ['ok'=>false,'error'=>'Terminal sipariş kuyruğa alınamaz.'];
        $db->prepare("INSERT INTO order_dispatch_jobs(order_id,status,attempts,next_attempt_at,created_at,updated_at) VALUES(?,'queued',0,NOW(),NOW(),NOW()) ON DUPLICATE KEY UPDATE status=IF(status IN('completed','manual_review','failed','cancelled'),status,'queued'),next_attempt_at=IF(status IN('completed','manual_review','failed','cancelled'),next_attempt_at,NOW()),updated_at=NOW()")
           ->execute([$orderId]);
        return ['ok'=>true,'queued'=>true];
    }catch(Throwable $e){return ['ok'=>false,'error'=>$e->getMessage()];}
}
function moni_dispatch_queue_state(PDO $db,int $orderId): ?string {
    if(!moni_table_ready($db,'order_dispatch_jobs'))return null;try{$s=$db->prepare("SELECT status FROM order_dispatch_jobs WHERE order_id=? LIMIT 1");$s->execute([$orderId]);$v=$s->fetchColumn();return $v===false?null:(string)$v;}catch(Throwable $e){return null;}
}

function moni_dispatch_priority_label(string $priority): string {
    return ['low'=>'Düşük','normal'=>'Normal','high'=>'Yüksek','urgent'=>'Acil'][$priority]??'Normal';
}
function moni_set_order_dispatch_priority(PDO $db,int $orderId,string $priority,int $adminId=0): array {
    $priority=strtolower(trim($priority)); if(!in_array($priority,['low','normal','high','urgent'],true))return ['ok'=>false,'error'=>'Geçersiz öncelik seviyesi.'];
    if(!moni_table_ready($db,'order_dispatch_jobs'))return ['ok'=>false,'error'=>'Sipariş gönderim kuyruğu hazır değil.'];
    try{
        $q=$db->prepare("SELECT o.id,o.status,o.api_order_id,s.api_provider_id,s.api_service_id,j.id job_id,j.status job_status,j.manual_priority FROM orders o JOIN services s ON s.id=o.service_id LEFT JOIN order_dispatch_jobs j ON j.order_id=o.id WHERE o.id=? LIMIT 1");$q->execute([$orderId]);$o=$q->fetch(PDO::FETCH_ASSOC);
        if(!$o)return ['ok'=>false,'error'=>'Sipariş bulunamadı.'];
        if(empty($o['api_provider_id'])||empty($o['api_service_id']))return ['ok'=>false,'error'=>'Bu sipariş provider gönderim kuyruğunu kullanmıyor.'];
        if(!empty($o['api_order_id']))return ['ok'=>false,'error'=>'Sipariş zaten sağlayıcıya gönderilmiş; kuyruk önceliği artık değiştirilemez.'];
        if(in_array((string)$o['status'],['completed','partial','cancelled','refunded','error'],true))return ['ok'=>false,'error'=>'Terminal durumdaki siparişin önceliği değiştirilemez.'];
        if(empty($o['job_id'])){ $r=moni_enqueue_order_dispatch($db,$orderId); if(empty($r['ok']))return $r; }
        $st=$db->prepare("UPDATE order_dispatch_jobs SET manual_priority=?,priority_updated_by=?,priority_updated_at=NOW(),updated_at=NOW() WHERE order_id=? AND status IN('queued','retry')");
        $st->execute([$priority,$adminId?:null,$orderId]);
        if(!$st->rowCount())return ['ok'=>false,'error'=>'Sipariş şu anda öncelik değişikliğine uygun bir kuyruk durumunda değil.'];
        if(function_exists('moni_audit_log'))moni_audit_log($db,'order.dispatch_priority','order',(string)$orderId,['priority'=>$priority,'admin_id'=>$adminId]);
        return ['ok'=>true,'priority'=>$priority,'label'=>moni_dispatch_priority_label($priority)];
    }catch(Throwable $e){return ['ok'=>false,'error'=>$e->getMessage()];}
}
function moni_process_order_dispatch_queue(PDO $db,int $batch=100): array {
    if(!moni_table_ready($db,'order_dispatch_jobs'))return ['processed'=>0,'message'=>'Sipariş gönderim kuyruğu hazır değil.'];
    $batch=max(1,min(5000,$batch));
    // Worker çökerse kilitli iş sonsuza kadar processing kalmasın. 10 dakikalık lease sonrası güvenli retry.
    try{$db->exec("UPDATE order_dispatch_jobs SET status='retry',next_attempt_at=NOW(),last_error=CONCAT(IFNULL(last_error,''),' | Eski worker lease geri alındı'),updated_at=NOW() WHERE status='processing' AND locked_at<DATE_SUB(NOW(),INTERVAL 10 MINUTE)");}catch(Throwable $ignore){}
    // Premium tabloları henüz migration görmemiş eski kurulumlarda worker'ı tamamen durdurma;
    // şema hazırsa premium önceliği, değilse klasik FIFO kullanılır.
    if(function_exists('moni_user_dispatch_priority')){
        $rows=$db->query("SELECT j.* FROM order_dispatch_jobs j LEFT JOIN orders o ON o.id=j.order_id LEFT JOIN user_premium_memberships m ON m.user_id=o.user_id AND m.status='active' AND m.starts_at<=NOW() AND m.expires_at>NOW() LEFT JOIN premium_packages p ON p.id=m.package_id WHERE j.status IN('queued','retry') AND (j.next_attempt_at IS NULL OR j.next_attempt_at<=NOW()) GROUP BY j.id ORDER BY CASE j.manual_priority WHEN 'urgent' THEN 3000 WHEN 'high' THEN 2000 WHEN 'low' THEN -1000 ELSE COALESCE(MAX(p.dispatch_priority_percent),0) END DESC,j.id ASC LIMIT $batch")->fetchAll(PDO::FETCH_ASSOC);
    }else{
        $rows=$db->query("SELECT j.* FROM order_dispatch_jobs j WHERE j.status IN('queued','retry') AND (j.next_attempt_at IS NULL OR j.next_attempt_at<=NOW()) ORDER BY CASE j.manual_priority WHEN 'urgent' THEN 3000 WHEN 'high' THEN 2000 WHEN 'low' THEN -1000 ELSE 0 END DESC,j.id ASC LIMIT $batch")->fetchAll(PDO::FETCH_ASSOC);
    }
    $n=0;$sent=0;$refunded=0;$manual=0;
    $maxAttempts=max(1,min(20,(int)getSetting('order_dispatch_max_attempts','5')));
    foreach($rows as $job){$jid=(int)$job['id'];$oid=(int)$job['order_id'];
        $claim=$db->prepare("UPDATE order_dispatch_jobs SET status='processing',attempts=attempts+1,locked_at=NOW(),updated_at=NOW() WHERE id=? AND status IN('queued','retry')");$claim->execute([$jid]);if(!$claim->rowCount())continue;
        try{
            $s=$db->prepare("SELECT o.*,s.* ,o.id AS order_id,o.quantity AS order_quantity,o.provider_quantity AS order_provider_quantity,o.link AS order_link,o.status AS order_status FROM orders o JOIN services s ON s.id=o.service_id WHERE o.id=? LIMIT 1");$s->execute([$oid]);$r=$s->fetch(PDO::FETCH_ASSOC);if(!$r)throw new RuntimeException('Sipariş bulunamadı.');
            if(!empty($r['api_order_id'])){$db->prepare("UPDATE order_dispatch_jobs SET status='completed',completed_at=NOW(),last_error=NULL,updated_at=NOW() WHERE id=?")->execute([$jid]);$n++;continue;}
            if(in_array((string)$r['order_status'],['completed','partial','cancelled','refunded','error'],true)){$db->prepare("UPDATE order_dispatch_jobs SET status='cancelled',completed_at=NOW(),last_error='Sipariş terminal durumda',updated_at=NOW() WHERE id=?")->execute([$jid]);$n++;continue;}
            $service=$r;$service['id']=(int)$r['service_id'];$service['api_provider_id']=$r['api_provider_id'];$qty=(int)($r['order_provider_quantity']?:$r['order_quantity']);
            if(function_exists('moni_validate_service_target')){$tv=moni_validate_service_target($db,(int)$r['service_id'],(string)$r['order_link'],(int)$r['user_id'],'dispatch-cron');if(empty($tv['ok'])){$rr=moni_refund_order($db,$oid,(float)$r['price'],'Hedef politikası: '.($tv['error']??'hedef engellendi'),'cancelled');if(empty($rr['ok']))throw new RuntimeException($rr['error']??'Hedef politikası iadesi başarısız.');$db->prepare("UPDATE order_dispatch_jobs SET status='cancelled',completed_at=NOW(),last_error=?,updated_at=NOW() WHERE id=?")->execute([mb_substr((string)($tv['error']??'Hedef politikası nedeniyle iptal edildi.'),0,1000),$jid]);$refunded++;$n++;continue;}}
            $res=moni_submit_order_to_provider($db,$oid,$service,(string)$r['order_link'],$qty,true);
            if(!empty($res['success'])){$db->prepare("UPDATE order_dispatch_jobs SET status='completed',completed_at=NOW(),last_error=NULL,updated_at=NOW() WHERE id=?")->execute([$jid]);$sent++;$n++;continue;}
            if(!empty($res['ambiguous'])){$db->prepare("UPDATE order_dispatch_jobs SET status='manual_review',last_error=?,updated_at=NOW() WHERE id=?")->execute([mb_substr((string)($res['error']??'Belirsiz sağlayıcı cevabı'),0,1000),$jid]);if(function_exists('moni_admin_notify'))moni_admin_notify($db,'dispatch_ambiguous','Sipariş provider sonucu belirsiz','#'.$oid.' ikinci kez gönderilmedi; manuel kontrol gerekli.','/admin/orders.php?search='.$oid,'warning');$manual++;$n++;continue;}
            $attempt=(int)$job['attempts']+1;
            if($attempt>=$maxAttempts){$rr=moni_refund_order($db,$oid,(float)$r['price'],'Provider gönderimi '.$maxAttempts.' güvenli denemede başarısız: '.($res['error']??'hata'),'error');if(empty($rr['ok']))throw new RuntimeException($rr['error']??'İade başarısız.');$db->prepare("UPDATE order_dispatch_jobs SET status='failed',completed_at=NOW(),last_error=?,updated_at=NOW() WHERE id=?")->execute([mb_substr((string)($res['error']??'Gönderim başarısız'),0,1000),$jid]);$refunded++;}
            else{$delay=min(60,max(1,(int)pow(2,min(6,$attempt-1))));$db->prepare("UPDATE order_dispatch_jobs SET status='retry',last_error=?,next_attempt_at=DATE_ADD(NOW(),INTERVAL ? MINUTE),updated_at=NOW() WHERE id=?")->execute([mb_substr((string)($res['error']??'Gönderim başarısız'),0,1000),$delay,$jid]);}
        }catch(Throwable $e){
            $attempt=(int)$job['attempts']+1;$delay=min(60,max(1,(int)pow(2,min(6,$attempt-1))));
            if($attempt>=$maxAttempts){
                // Beklenmeyen exception provider tarafında sipariş oluşmuş olabileceği anlamına gelebilir.
                // Bu yüzden körlemesine tekrar gönderme veya otomatik iade yerine manuel incelemeye al.
                $db->prepare("UPDATE order_dispatch_jobs SET status='manual_review',last_error=?,updated_at=NOW() WHERE id=?")->execute([mb_substr($e->getMessage(),0,1000),$jid]);
                if(function_exists('moni_admin_notify'))moni_admin_notify($db,'dispatch_exception','Sipariş gönderimi manuel inceleme bekliyor','#'.$oid.' beklenmeyen hata nedeniyle tekrar gönderilmedi: '.mb_substr($e->getMessage(),0,250),'/admin/orders.php?search='.$oid,'warning');
                $manual++;
            }else{
                $db->prepare("UPDATE order_dispatch_jobs SET status='retry',last_error=?,next_attempt_at=DATE_ADD(NOW(),INTERVAL ? MINUTE),updated_at=NOW() WHERE id=?")->execute([mb_substr($e->getMessage(),0,1000),$delay,$jid]);
            }
        }
        $n++;
    }
    return ['processed'=>$n,'message'=>"$n bekleyen sipariş işlendi; $sent provider'a gönderildi, $refunded iade edildi, $manual manuel kontrole alındı."];
}

/* ------------------------- Service quality + quarantine ------------------------- */
function moni_service_quality_calculate(PDO $db,int $serviceId,int $sample=100): array {
    $sample=max(10,min(1000,$sample));$s=$db->prepare("SELECT status,TIMESTAMPDIFF(SECOND,created_at,updated_at) sec FROM orders WHERE service_id=? AND status IN('completed','partial','cancelled','refunded','error') ORDER BY id DESC LIMIT $sample");$s->execute([$serviceId]);$rows=$s->fetchAll(PDO::FETCH_ASSOC);$n=count($rows);if(!$n)return ['sample'=>0,'score'=>null];
    $weights=['completed'=>100,'partial'=>55,'cancelled'=>10,'refunded'=>5,'error'=>0];$sum=0;$counts=array_fill_keys(array_keys($weights),0);$secs=[];foreach($rows as $r){$st=(string)$r['status'];$sum+=$weights[$st]??0;if(isset($counts[$st]))$counts[$st]++;$sec=(int)$r['sec'];if($st==='completed'&&$sec>0&&$sec<7776000)$secs[]=$sec;}
    return ['sample'=>$n,'score'=>round($sum/$n,2),'completed'=>$counts['completed'],'partial'=>$counts['partial'],'cancelled'=>$counts['cancelled'],'refunded'=>$counts['refunded'],'error'=>$counts['error'],'avg_seconds'=>$secs?(int)round(array_sum($secs)/count($secs)):null];
}
function moni_process_service_quality(PDO $db,int $batch=200): array {
    if(!moni_table_ready($db,'service_quality_metrics'))return ['processed'=>0,'message'=>'Servis kalite tablosu hazır değil.'];$batch=max(1,min(5000,$batch));$ids=$db->query("SELECT id FROM services WHERE deleted_at IS NULL ORDER BY COALESCE(quality_checked_at,'1970-01-01') ASC,id LIMIT $batch")->fetchAll(PDO::FETCH_COLUMN);$n=0;$quarantined=0;
    $enabled=(string)getSetting('service_auto_quarantine_enabled','1')==='1';$threshold=max(0,min(100,(float)getSetting('service_auto_quarantine_threshold','35')));$minSample=max(5,min(1000,(int)getSetting('service_auto_quarantine_min_sample','20')));
    foreach($ids as $sid){$m=moni_service_quality_calculate($db,(int)$sid,max(100,$minSample));$db->prepare("INSERT INTO service_quality_metrics(service_id,quality_score,sample_size,completed_count,partial_count,cancelled_count,refunded_count,error_count,avg_completion_seconds,calculated_at) VALUES(?,?,?,?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE quality_score=VALUES(quality_score),sample_size=VALUES(sample_size),completed_count=VALUES(completed_count),partial_count=VALUES(partial_count),cancelled_count=VALUES(cancelled_count),refunded_count=VALUES(refunded_count),error_count=VALUES(error_count),avg_completion_seconds=VALUES(avg_completion_seconds),calculated_at=NOW()")
        ->execute([(int)$sid,$m['score'],$m['sample'],$m['completed']??0,$m['partial']??0,$m['cancelled']??0,$m['refunded']??0,$m['error']??0,$m['avg_seconds']]);$db->prepare("UPDATE services SET quality_score=?,quality_checked_at=NOW() WHERE id=?")->execute([$m['score'],(int)$sid]);
        if($enabled && $m['sample']>=$minSample && $m['score']!==null && $m['score']<$threshold){$q=$db->prepare("SELECT status FROM services WHERE id=?");$q->execute([$sid]);if($q->fetchColumn()==='active'){$db->prepare("UPDATE services SET status='inactive' WHERE id=?")->execute([$sid]);$db->prepare("INSERT INTO service_quarantines(service_id,quality_score,reason,status,created_at) VALUES(?,?,?,'active',NOW())")->execute([(int)$sid,$m['score'],'Kalite puanı otomatik eşik altına düştü']);$quarantined++;if(function_exists('moni_admin_notify'))moni_admin_notify($db,'service_quarantine','Servis otomatik karantinaya alındı','#'.$sid.' kalite puanı '.$m['score'].' olduğu için pasife alındı.','/admin/service-quality.php','warning');}}
        $n++;}
    return ['processed'=>$n,'message'=>"$n servisin kalite puanı hesaplandı; $quarantined servis karantinaya alındı."];
}

/* ------------------------- Minimum profit protection ------------------------- */
function moni_process_min_profit_protection(PDO $db,int $batch=500): array {
    if((string)getSetting('min_profit_protection_enabled','0')!=='1')return ['processed'=>0,'message'=>'Minimum kâr koruması kapalı.'];$type=(string)getSetting('min_profit_protection_type','percent');if(!in_array($type,['percent','fixed'],true))$type='percent';$value=max(0,(float)getSetting('min_profit_protection_value','20'));$batch=max(1,min(5000,$batch));
    $s=$db->prepare("SELECT id,name,cost_per_1000,price_per_1000 FROM services WHERE deleted_at IS NULL AND status='active' AND cost_per_1000>0 AND cost_per_1000>=price_per_1000 ORDER BY updated_at ASC LIMIT $batch");$s->execute();$n=0;$raised=[];foreach($s->fetchAll(PDO::FETCH_ASSOC) as $r){$cost=(float)$r['cost_per_1000'];$new=$type==='fixed'?$cost+$value:$cost*(1+$value/100);$new=round(max($cost,$new),4);$u=$db->prepare("UPDATE services SET price_per_1000=?,updated_at=NOW() WHERE id=? AND price_per_1000<=cost_per_1000");$u->execute([$new,$r['id']]);if($u->rowCount()>0){$raised[]=['id'=>(int)$r['id'],'old'=>(float)$r['price_per_1000'],'new'=>$new];}$n++;}
    if($raised&&function_exists('moni_admin_notify'))moni_admin_notify($db,'profit_protection','Minimum kâr koruması uygulandı',count($raised).' servisin satış fiyatı maliyet üstüne güvenli marjla taşındı.','/admin/services.php','info');
    return ['processed'=>$n,'message'=>"$n zarar riski taşıyan servis kontrol edildi; ".count($raised).' servis fiyatı korundu.'];
}

/* ------------------------- OpenAPI / SDK ------------------------- */
function moni_api_base_url(): string { return rtrim(defined('SITE_URL')?SITE_URL:'','/').'/api/myservices.php'; }
function moni_openapi_document(): array {
    $base=moni_api_base_url();
    return ['openapi'=>'3.1.0','info'=>['title'=>(function_exists('moni_v2_site_name')?moni_v2_site_name():'SMM Panel').' API','version'=>'2.0.0','description'=>'SMM Panel reseller API. API key request body/form parameter or X-API-Key header ile kullanılabilir.'],'servers'=>[['url'=>$base]],'paths'=>[
        '/'=>['post'=>['summary'=>'API action','requestBody'=>['required'=>true,'content'=>['application/x-www-form-urlencoded'=>['schema'=>['type'=>'object','properties'=>['key'=>['type'=>'string'],'action'=>['type'=>'string','enum'=>['services','balance','add','status','refill','cancel']],'service'=>['type'=>'integer'],'link'=>['type'=>'string','format'=>'uri'],'quantity'=>['type'=>'integer'],'order'=>['type'=>'integer'],'runs'=>['type'=>'integer'],'interval'=>['type'=>'integer'],'geo_target'=>['type'=>'string']],'required'=>['key','action']]]]],'responses'=>['200'=>['description'=>'Başarılı yanıt'],'400'=>['description'=>'Geçersiz istek'],'401'=>['description'=>'Yetkisiz'],'429'=>['description'=>'Rate limit aşıldı']]]]
    ],'components'=>['securitySchemes'=>['ApiKey'=>['type'=>'apiKey','in'=>'header','name'=>'X-API-Key']]]];
}
function moni_sdk_source(string $lang): ?array {
    $url=moni_api_base_url();
    if($lang==='php'){$src="<?php\nclass SmmPanelClient { private string \$key; private string \$url='".addslashes($url)."'; public function __construct(string \$key){\$this->key=\$key;} public function call(string \$action,array \$data=[]): array { \$data=array_merge(\$data,['key'=>\$this->key,'action'=>\$action]); \$ch=curl_init(\$this->url); curl_setopt_array(\$ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>http_build_query(\$data),CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>30,CURLOPT_SSL_VERIFYPEER=>true]); \$raw=curl_exec(\$ch); if(\$raw===false) throw new RuntimeException(curl_error(\$ch)); curl_close(\$ch); return json_decode(\$raw,true)?:[]; }}\n";return ['filename'=>'SmmPanelClient.php','mime'=>'text/x-php','source'=>$src];}
    if($lang==='python'){$src="import requests\n\nclass SmmPanelClient:\n    def __init__(self, key, url='".$url."'):\n        self.key, self.url = key, url\n    def call(self, action, **data):\n        payload = {'key': self.key, 'action': action, **data}\n        r = requests.post(self.url, data=payload, timeout=30)\n        r.raise_for_status()\n        return r.json()\n";return ['filename'=>'smm_panel_client.py','mime'=>'text/x-python','source'=>$src];}
    if($lang==='node'){$src="export class SmmPanelClient { constructor(key, url='".$url."'){ this.key=key; this.url=url; } async call(action,data={}){ const body=new URLSearchParams({key:this.key,action,...Object.fromEntries(Object.entries(data).map(([k,v])=>[k,String(v)]))}); const r=await fetch(this.url,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body}); if(!r.ok) throw new Error('HTTP '+r.status); return await r.json(); }}\n";return ['filename'=>'smm-panel-client.mjs','mime'=>'text/javascript','source'=>$src];}
    return null;
}
