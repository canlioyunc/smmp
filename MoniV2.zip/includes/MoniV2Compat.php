<?php
/**
 * Moni v2 compatibility/bootstrap layer.
 * Existing-site upgrades may have new files copied before config.php or update_v2.sql is applied.
 * This file safely loads the v2 core and completes idempotent schema seeds once.
 */
if (defined('MONI_V2_COMPAT_LOADED')) return;
define('MONI_V2_COMPAT_LOADED', true);

if (!function_exists('moni_bootstrap')) {
    require_once __DIR__ . '/MoniCore.php';
}

function moni_v2_compat_column_exists(PDO $db, string $table, string $column): bool {
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $table) || !preg_match('/^[a-zA-Z0-9_]+$/', $column)) return false;
    try {
        $q = $db->query("SHOW COLUMNS FROM `{$table}` LIKE " . $db->quote($column));
        return (bool)$q->fetch(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { return false; }
}
function moni_v2_compat_add_column(PDO $db, string $table, string $column, string $definition): void {
    if (!moni_v2_compat_column_exists($db, $table, $column)) {
        $db->exec("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}");
    }
}
function moni_v2_compat_setting(PDO $db, string $key, string $default=''): string {
    try { $s=$db->prepare("SELECT setting_value FROM settings WHERE setting_key=? LIMIT 1");$s->execute([$key]);$v=$s->fetchColumn();return $v===false?$default:(string)$v; }
    catch(Throwable $e){ return $default; }
}
function moni_v2_compat_set_setting(PDO $db,string $key,string $value): void {
    $s=$db->prepare("INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");
    $s->execute([$key,$value]);
}

function moni_v2_runtime_migrate(PDO $db): void {
    static $done=false; if($done)return; $done=true;
    $revision='2026-09-30.1';
    try {
        if (moni_v2_compat_setting($db,'moni_v2_runtime_schema_revision','') === $revision) {
            $critical = moni_v2_compat_column_exists($db,'services','geo_supported')
                && moni_v2_compat_column_exists($db,'orders','geo_target')
                && moni_v2_compat_column_exists($db,'order_dispatch_jobs','manual_priority')
                && function_exists('moni_table_ready') && moni_table_ready($db,'order_dispatch_jobs');
            if ($critical) {
                try { $q=$db->query("SELECT 1 FROM cron_tasks WHERE task_key='order_dispatch' LIMIT 1"); $critical=(bool)$q->fetchColumn(); } catch(Throwable $e){ $critical=false; }
            }
            if ($critical) return;
        }

        // Columns required by current v2 pages/workers.
        moni_v2_compat_add_column($db,'api_clients','updated_at','datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP');
        moni_v2_compat_add_column($db,'child_panels','allow_custom_smtp','tinyint(1) NOT NULL DEFAULT 0');
        moni_v2_compat_add_column($db,'child_panels','allow_custom_payments','tinyint(1) NOT NULL DEFAULT 0');
        moni_v2_compat_add_column($db,'payment_requests','child_panel_id','bigint NULL');
        moni_v2_compat_add_column($db,'payment_requests','child_payment_method_id','bigint NULL');
        moni_v2_compat_add_column($db,'payment_requests','child_bank_account_id','bigint NULL');
        moni_v2_compat_add_column($db,'gateway_transactions','child_panel_id','bigint NULL');
        moni_v2_compat_add_column($db,'services','geo_supported','tinyint(1) NOT NULL DEFAULT 0');
        moni_v2_compat_add_column($db,'services','geo_targets_json','mediumtext NULL');
        moni_v2_compat_add_column($db,'services','geo_target_param',"varchar(40) NOT NULL DEFAULT 'country'");
        moni_v2_compat_add_column($db,'services','quality_score','decimal(6,2) NULL');
        moni_v2_compat_add_column($db,'services','quality_checked_at','datetime NULL');
        moni_v2_compat_add_column($db,'orders','geo_target','varchar(80) NULL');
        moni_v2_compat_add_column($db,'orders_dripfeed','geo_target','varchar(80) NULL');
        moni_v2_compat_add_column($db,'scheduled_orders','geo_target','varchar(80) NULL');
        moni_v2_compat_add_column($db,'theme_defaults','font_family',"varchar(30) NOT NULL DEFAULT 'inter'");
        moni_v2_compat_add_column($db,'theme_defaults','heading_font_family',"varchar(30) NOT NULL DEFAULT 'inter'");
        moni_v2_compat_add_column($db,'theme_defaults','input_bg_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_defaults','input_border_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_defaults','secondary_button_bg_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_defaults','secondary_button_hover_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_defaults','wallet_button_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_defaults','wallet_button_hover_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_defaults','wallet_button_text_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_defaults','panel_hero_start_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_defaults','panel_hero_end_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_defaults','panel_hero_text_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_settings','font_family',"varchar(30) NOT NULL DEFAULT 'inter'");
        moni_v2_compat_add_column($db,'theme_settings','heading_font_family',"varchar(30) NOT NULL DEFAULT 'inter'");
        moni_v2_compat_add_column($db,'theme_settings','input_bg_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_settings','input_border_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_settings','secondary_button_bg_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_settings','secondary_button_hover_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_settings','wallet_button_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_settings','wallet_button_hover_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_settings','wallet_button_text_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_settings','panel_hero_start_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_settings','panel_hero_end_color','varchar(20) DEFAULT NULL');
        moni_v2_compat_add_column($db,'theme_settings','panel_hero_text_color','varchar(20) DEFAULT NULL');

        $themeDefaults=[
            'dark'=>['inter','inter','#17172f','#373763','#2a2a4a','#34345a','#117a57','#0f7654','#ffffff','#29294d','#34345f','#f8fafc'],
            'light'=>['inter','inter','#ffffff','#d5d9e2','#eef1f7','#e2e7f0','#198754','#146c43','#ffffff','#eef0ff','#e5e8fb','#1f2937'],
            'bogurtlen'=>['inter','trebuchet','#25102d','#5a2d66','#482050','#5b2a65','#17835c','#126b4b','#ffffff','#35143f','#482050','#f7eafa'],
            'ananas'=>['system','trebuchet','#fffef6','#e5d77e','#fff4bf','#f6e68d','#198754','#146c43','#ffffff','#fff8d4','#ffedaa','#3a3214'],
            'okyanus'=>['inter','inter','#f4fdff','#90e0ef','#dff8fc','#c7f0f7','#007f73','#00665d','#ffffff','#e5f8fc','#c9f1f8','#03045e'],
            'orman'=>['system','trebuchet','#f4fbf6','#95d5b2','#e5f4e9','#d3ebda','#2d6a4f','#24563f','#ffffff','#e8f5ec','#d4eadb','#1b4332'],
        ];
        foreach($themeDefaults as $tn=>$v){
            try{$q=$db->prepare("UPDATE theme_defaults SET font_family=?,heading_font_family=?,input_bg_color=?,input_border_color=?,secondary_button_bg_color=?,secondary_button_hover_color=?,wallet_button_color=?,wallet_button_hover_color=?,wallet_button_text_color=?,panel_hero_start_color=?,panel_hero_end_color=?,panel_hero_text_color=? WHERE theme_name=?");$q->execute([...$v,$tn]);}catch(Throwable $ignore){}
            try{$q=$db->prepare("UPDATE theme_settings SET font_family=COALESCE(NULLIF(font_family,''),?),heading_font_family=COALESCE(NULLIF(heading_font_family,''),?),input_bg_color=COALESCE(input_bg_color,?),input_border_color=COALESCE(input_border_color,?),secondary_button_bg_color=COALESCE(secondary_button_bg_color,?),secondary_button_hover_color=COALESCE(secondary_button_hover_color,?),wallet_button_color=COALESCE(wallet_button_color,?),wallet_button_hover_color=COALESCE(wallet_button_hover_color,?),wallet_button_text_color=COALESCE(wallet_button_text_color,?),panel_hero_start_color=COALESCE(panel_hero_start_color,?),panel_hero_end_color=COALESCE(panel_hero_end_color,?),panel_hero_text_color=COALESCE(panel_hero_text_color,?) WHERE theme_name=?");$q->execute([...$v,$tn]);}catch(Throwable $ignore){}
        }

        try { $db->exec("ALTER TABLE api_clients MODIFY api_key varchar(80) NOT NULL"); } catch(Throwable $ignore) {}

        // API limit default: 300/min. Existing rows left on the old built-in 60/120 defaults are upgraded;
        // any custom admin value is preserved.
        try { $db->exec("UPDATE api_clients SET rate_limit_per_min=300 WHERE rate_limit_per_min IS NULL OR rate_limit_per_min<=0 OR rate_limit_per_min IN (60,120)"); } catch(Throwable $ignore) {}
        try { $db->exec("ALTER TABLE api_clients MODIFY rate_limit_per_min int(11) NOT NULL DEFAULT 300"); } catch(Throwable $ignore) {}

        $ddl = [];
        $ddl[] = "CREATE TABLE IF NOT EXISTS customer_api_request_logs (id bigint NOT NULL AUTO_INCREMENT,api_client_id int NULL,user_id int NULL,endpoint varchar(190) NOT NULL DEFAULT '',action varchar(80) NOT NULL DEFAULT '',http_method varchar(10) NOT NULL DEFAULT 'GET',ip_address varchar(45) NOT NULL DEFAULT '',http_status smallint NOT NULL DEFAULT 200,duration_ms int NOT NULL DEFAULT 0,request_json mediumtext NULL,response_json mediumtext NULL,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY idx_customer_api_user_time(user_id,created_at),KEY idx_customer_api_client_time(api_client_id,created_at),KEY idx_customer_api_action_status(action,http_status,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[] = "CREATE TABLE IF NOT EXISTS notification_preferences (id bigint NOT NULL AUTO_INCREMENT,user_id int NOT NULL,category varchar(50) NOT NULL,in_app_enabled tinyint(1) NOT NULL DEFAULT 1,email_enabled tinyint(1) NOT NULL DEFAULT 1,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY uq_notification_preference(user_id,category),KEY idx_notification_preference_user(user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[] = "CREATE TABLE IF NOT EXISTS favorite_service_alert_state (id bigint NOT NULL AUTO_INCREMENT,user_id int NOT NULL,service_id int NOT NULL,last_price decimal(15,4) NULL,last_status varchar(30) NULL,initialized_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,last_notified_at datetime NULL,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY uq_favorite_alert_user_service(user_id,service_id),KEY idx_favorite_alert_update(updated_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[] = "CREATE TABLE IF NOT EXISTS child_panel_smtp_settings (child_panel_id bigint NOT NULL,is_enabled tinyint(1) NOT NULL DEFAULT 0,smtp_host varchar(255) NULL,smtp_port int NOT NULL DEFAULT 587,smtp_username varchar(255) NULL,smtp_password text NULL,smtp_encryption enum('tls','ssl','none') NOT NULL DEFAULT 'tls',from_email varchar(255) NULL,from_name varchar(190) NULL,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(child_panel_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[] = "CREATE TABLE IF NOT EXISTS child_panel_email_templates (id bigint NOT NULL AUTO_INCREMENT,child_panel_id bigint NOT NULL,slug varchar(100) NOT NULL,subject varchar(255) NOT NULL,body_html mediumtext NOT NULL,is_active tinyint(1) NOT NULL DEFAULT 1,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY uq_child_email_template(child_panel_id,slug),KEY idx_child_email_panel(child_panel_id,is_active)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[] = "CREATE TABLE IF NOT EXISTS child_panel_payment_methods (id bigint NOT NULL AUTO_INCREMENT,child_panel_id bigint NOT NULL,type enum('bank','iyzico') NOT NULL,name varchar(120) NOT NULL,is_enabled tinyint(1) NOT NULL DEFAULT 0,min_amount decimal(15,4) NOT NULL DEFAULT 10,max_amount decimal(15,4) NOT NULL DEFAULT 50000,config_json mediumtext NULL,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY uq_child_payment_type(child_panel_id,type),KEY idx_child_payment_active(child_panel_id,is_enabled)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[] = "CREATE TABLE IF NOT EXISTS child_panel_bank_accounts (id bigint NOT NULL AUTO_INCREMENT,child_panel_id bigint NOT NULL,bank_name varchar(190) NOT NULL,account_holder varchar(190) NOT NULL,iban varchar(64) NOT NULL,branch_code varchar(80) NULL,account_number varchar(100) NULL,is_active tinyint(1) NOT NULL DEFAULT 1,sort_order int NOT NULL DEFAULT 0,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY idx_child_bank_panel(child_panel_id,is_active,sort_order)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[] = "CREATE TABLE IF NOT EXISTS order_dispatch_jobs (id bigint NOT NULL AUTO_INCREMENT,order_id int NOT NULL,status enum('queued','processing','retry','completed','manual_review','failed','cancelled') NOT NULL DEFAULT 'queued',manual_priority enum('low','normal','high','urgent') NOT NULL DEFAULT 'normal',priority_updated_by int NULL,priority_updated_at datetime NULL,attempts int NOT NULL DEFAULT 0,next_attempt_at datetime NULL,locked_at datetime NULL,last_error varchar(1000) NULL,completed_at datetime NULL,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY uq_order_dispatch_order(order_id),KEY idx_order_dispatch_queue(status,next_attempt_at,id),KEY idx_order_dispatch_manual_priority(status,manual_priority,next_attempt_at,id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[] = "CREATE TABLE IF NOT EXISTS service_working_hours (id bigint NOT NULL AUTO_INCREMENT,service_id int NOT NULL,day_of_week tinyint NOT NULL,start_time time NOT NULL DEFAULT '00:00:00',end_time time NOT NULL DEFAULT '23:59:59',is_closed tinyint(1) NOT NULL DEFAULT 0,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY uq_service_working_day(service_id,day_of_week),KEY idx_service_hours_service(service_id,day_of_week)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[] = "CREATE TABLE IF NOT EXISTS service_quality_metrics (service_id int NOT NULL,quality_score decimal(6,2) NULL,sample_size int NOT NULL DEFAULT 0,completed_count int NOT NULL DEFAULT 0,partial_count int NOT NULL DEFAULT 0,cancelled_count int NOT NULL DEFAULT 0,refunded_count int NOT NULL DEFAULT 0,error_count int NOT NULL DEFAULT 0,avg_completion_seconds int NULL,calculated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(service_id),KEY idx_quality_score(quality_score,sample_size)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[] = "CREATE TABLE IF NOT EXISTS service_quarantines (id bigint NOT NULL AUTO_INCREMENT,service_id int NOT NULL,quality_score decimal(6,2) NULL,reason varchar(500) NOT NULL,status enum('active','released') NOT NULL DEFAULT 'active',released_by int NULL,released_at datetime NULL,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY idx_quarantine_service_status(service_id,status,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[] = "CREATE TABLE IF NOT EXISTS provider_status_mappings (id bigint NOT NULL AUTO_INCREMENT,provider_id int NULL,raw_status varchar(100) NOT NULL,local_status enum('pending','processing','in_progress','completed','partial','cancelled','refunded','error') NOT NULL,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY uq_provider_status_map(provider_id,raw_status),KEY idx_provider_status_raw(raw_status)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[] = "CREATE TABLE IF NOT EXISTS api_sandbox_orders (id bigint NOT NULL AUTO_INCREMENT,user_id int NOT NULL,service_id int NULL,link varchar(1000) NULL,quantity int NOT NULL DEFAULT 0,status varchar(40) NOT NULL DEFAULT 'pending',created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY idx_sandbox_user_time(user_id,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        foreach($ddl as $sql)$db->exec($sql);
        // Existing-site columns for manual dispatch priority.
        moni_v2_compat_add_column($db,'order_dispatch_jobs','manual_priority',"enum('low','normal','high','urgent') NOT NULL DEFAULT 'normal' AFTER `status`");
        moni_v2_compat_add_column($db,'order_dispatch_jobs','priority_updated_by','int NULL AFTER `manual_priority`');
        moni_v2_compat_add_column($db,'order_dispatch_jobs','priority_updated_at','datetime NULL AFTER `priority_updated_by`');
        try{$db->exec("ALTER TABLE order_dispatch_jobs ADD KEY idx_order_dispatch_manual_priority(status,manual_priority,next_attempt_at,id)");}catch(Throwable $ignore){}
        foreach(['partial_maintenance_orders','partial_maintenance_payments','partial_maintenance_api','partial_maintenance_child_panels'] as $k){try{$db->prepare("INSERT IGNORE INTO settings(setting_key,setting_value) VALUES(?, '0')")->execute([$k]);}catch(Throwable $ignore){}}
        foreach(['orders','payments','api','child_panels'] as $k){try{$db->prepare("INSERT IGNORE INTO settings(setting_key,setting_value) VALUES(?, '')")->execute(['partial_maintenance_'.$k.'_message']);}catch(Throwable $ignore){}}

        // Plugin seeds. Existing choices are never reset. Social precheck is active on an upgraded site,
        // but the clean-install database already has the row disabled, so INSERT IGNORE preserves it.
        $plugins=[
            ['customer_api_history','Müşteri API İstek Geçmişi','Müşteri API çağrılarını gizli alanları sansürleyerek kaydeder.','2.0.0',0],
            ['provider_smart_matcher','Akıllı Provider Servis Eşleştirme','Sağlayıcı servislerini yerel servislerle benzerlik puanına göre eşleştirir.','2.0.0',1],
            ['real_delivery_eta','Gerçek Teslim Süresi Tahmini','Gerçek tamamlanan siparişlerden teslim süresi tahmini üretir.','2.0.0',0],
            ['favorite_service_alerts','Favori Servis Fiyat / Durum Alarmı','Favori servis fiyat veya durum değişimlerini bildirir.','2.0.0',1],
            ['notification_preferences','Bildirim Tercih Merkezi','Kullanıcı bildirimlerini kategori bazında yönetir.','2.0.0',1],
            ['human_captcha','Turnstile / hCaptcha','Cloudflare Turnstile veya hCaptcha insan doğrulaması sağlar.','2.0.0',0],
            ['api_sandbox','API Sandbox / Mock Modu','Gerçek bakiye veya provider çağrısı olmadan API entegrasyon testleri sağlar.','2.0.0',0],
            ['social_account_precheck','Sosyal Hesap Ön Kontrolü','Sipariş öncesi sosyal bağlantı biçimi, güvenli hedef ve isteğe bağlı erişilebilirlik kontrolü yapar.','2.0.0',1],
        ];
        $ps=$db->prepare("INSERT IGNORE INTO plugins(slug,name,description,version,is_enabled,is_core) VALUES(?,?,?,?,?,0)");
        foreach($plugins as $p)$ps->execute($p);
        // Existing-site upgrade policy: social precheck should be active. Clean installs carry the revision marker and skip this migrator.
        try{$db->exec("UPDATE plugins SET is_enabled=1 WHERE slug='social_account_precheck'");}catch(Throwable $ignore){}

        // Cron seeds. User-modified intervals/batches are preserved on duplicate.
        $tasks=[
            ['favorite_service_alerts','Favori Servis Fiyat / Durum Alarmı',5,250,1],
            ['order_dispatch','Bekleyen Siparişleri API’ye Gönder',1,100,1],
            ['service_quality','Servis Kalite Puanı / Karantina',5,200,1],
            ['profit_protection','Minimum Kâr Koruma',1,500,1],
        ];
        $cs=$db->prepare("INSERT IGNORE INTO cron_tasks(task_key,name,interval_minutes,batch_size,is_enabled) VALUES(?,?,?,?,?)");
        foreach($tasks as $t)$cs->execute($t);
        try{$db->exec("UPDATE cron_tasks SET name='Bekleyen Siparişleri API’ye Gönder' WHERE task_key='order_dispatch' AND name IN ('Bekleyen Siparişleri Provider API’ye Gönder','Bekleyen Siparişleri API’ye Gönder')");}catch(Throwable $ignore){}

        foreach([
            'api_default_rate_limit_per_min'=>'300','order_dispatch_max_attempts'=>'5','service_auto_quarantine_enabled'=>'1','service_auto_quarantine_threshold'=>'35','service_auto_quarantine_min_sample'=>'20','min_profit_protection_enabled'=>'0','min_profit_protection_type'=>'percent','min_profit_protection_value'=>'20'
        ] as $k=>$v){
            $st=$db->prepare("INSERT IGNORE INTO settings(setting_key,setting_value) VALUES(?,?)");$st->execute([$k,$v]);
        }

        moni_v2_compat_set_setting($db,'moni_v2_runtime_schema_revision',$revision);
    } catch(Throwable $e) {
        error_log('Moni v2 runtime migration failed: '.$e->getMessage());
        $GLOBALS['moni_v2_migration_error']=$e->getMessage();
    }
}


/**
 * Commerce Pro schema is intentionally versioned separately from the main v2 migrator.
 * This prevents a Commerce Pro update from replaying older migrations or overwriting
 * administrator-selected theme/plugin/rate-limit settings.
 */
function moni_commerce_runtime_migrate(PDO $db): void {
    static $done=false; if($done)return; $done=true;
    $revision='2026-09-29.1';
    try {
        $ready = moni_v2_compat_setting($db,'moni_commerce_pro_schema_revision','') === $revision
            && moni_v2_compat_column_exists($db,'users','bank_reference_code')
            && moni_v2_compat_column_exists($db,'payment_requests','payment_reference')
            && function_exists('moni_table_ready')
            && moni_table_ready($db,'service_price_schedules')
            && moni_table_ready($db,'service_price_tiers')
            && moni_table_ready($db,'bank_statement_imports')
            && moni_table_ready($db,'bank_statement_entries');
        if($ready){
            try{$q=$db->query("SELECT COUNT(*) FROM cron_tasks WHERE task_key IN('scheduled_service_prices','bank_reconciliation')");$ready=(int)$q->fetchColumn()===2;}catch(Throwable $e){$ready=false;}
        }
        if($ready)return;

        moni_v2_compat_add_column($db,'users','bank_reference_code','varchar(32) NULL');
        moni_v2_compat_add_column($db,'payment_requests','payment_reference','varchar(40) NULL');
        try{$db->exec("CREATE UNIQUE INDEX uq_users_bank_reference_code ON users(bank_reference_code)");}catch(Throwable $ignore){}

        $ddl=[];
        $ddl[]="CREATE TABLE IF NOT EXISTS service_price_schedules (id bigint NOT NULL AUTO_INCREMENT,service_id int NOT NULL,requested_price decimal(15,4) NOT NULL,previous_price decimal(15,4) NULL,applied_price decimal(15,4) NULL,execute_at datetime NOT NULL,status enum('pending','applied','cancelled','failed') NOT NULL DEFAULT 'pending',floor_adjusted tinyint(1) NOT NULL DEFAULT 0,created_by int NULL,cancelled_by int NULL,applied_at datetime NULL,cancelled_at datetime NULL,error_message varchar(1000) NULL,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY idx_price_schedule_due(status,execute_at,id),KEY idx_price_schedule_service(service_id,execute_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS service_price_tiers (id bigint NOT NULL AUTO_INCREMENT,service_id int NOT NULL,min_quantity int NOT NULL,max_quantity int NULL,pricing_type enum('fixed_per_1000','discount_percent') NOT NULL,pricing_value decimal(15,4) NOT NULL,is_active tinyint(1) NOT NULL DEFAULT 1,created_by int NULL,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY idx_service_tiers(service_id,is_active,min_quantity,max_quantity)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS bank_statement_imports (id bigint NOT NULL AUTO_INCREMENT,bank_account_id int NOT NULL,filename varchar(255) NOT NULL,file_hash char(64) NOT NULL,file_format varchar(10) NOT NULL,status enum('processing','completed','failed') NOT NULL DEFAULT 'processing',row_count int NOT NULL DEFAULT 0,imported_count int NOT NULL DEFAULT 0,matched_count int NOT NULL DEFAULT 0,duplicate_count int NOT NULL DEFAULT 0,created_by int NULL,error_message varchar(1000) NULL,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,completed_at datetime NULL,PRIMARY KEY(id),UNIQUE KEY uq_bank_import_file(bank_account_id,file_hash),KEY idx_bank_import_time(bank_account_id,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS bank_statement_entries (id bigint NOT NULL AUTO_INCREMENT,import_id bigint NOT NULL,bank_account_id int NOT NULL,entry_hash char(64) NOT NULL,transaction_date datetime NOT NULL,amount decimal(15,4) NOT NULL,currency_code varchar(8) NOT NULL DEFAULT 'TRY',direction enum('credit','debit') NOT NULL,sender_name varchar(255) NULL,description text NULL,reference_no varchar(190) NULL,raw_json mediumtext NULL,match_status enum('unmatched','suggested','matched','approved','ignored') NOT NULL DEFAULT 'unmatched',matched_payment_request_id int NULL,match_score decimal(6,2) NULL,match_reason varchar(500) NULL,matched_at datetime NULL,matched_by int NULL,approved_at datetime NULL,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY uq_bank_statement_entry(bank_account_id,entry_hash),KEY idx_bank_entry_match(match_status,direction,transaction_date),KEY idx_bank_entry_payment(matched_payment_request_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        foreach($ddl as $sql)$db->exec($sql);

        $cs=$db->prepare("INSERT IGNORE INTO cron_tasks(task_key,name,interval_minutes,batch_size,is_enabled) VALUES(?,?,?,?,?)");
        foreach([
            ['scheduled_service_prices','Zamanlanmış Servis Fiyat Değişiklikleri',1,200,1],
            ['bank_reconciliation','Banka Ekstresi Otomatik Mutabakat',5,250,1],
        ] as $t)$cs->execute($t);
        $st=$db->prepare("INSERT IGNORE INTO settings(setting_key,setting_value) VALUES(?,?)");
        foreach([
            'bank_reconciliation_date_window_days'=>'7',
            'bank_reconciliation_amount_tolerance'=>'0.01',
            'bank_reconciliation_auto_approve_exact'=>'0',
        ] as $k=>$v)$st->execute([$k,$v]);

        moni_v2_compat_set_setting($db,'moni_commerce_pro_schema_revision',$revision);
    }catch(Throwable $e){
        error_log('Moni Commerce Pro runtime migration failed: '.$e->getMessage());
        $GLOBALS['moni_commerce_migration_error']=$e->getMessage();
    }
}

require_once __DIR__ . '/MoniOpsPro.php';
require_once __DIR__ . '/MoniOpsIntelligence.php';
require_once __DIR__ . '/MoniSupportTarget.php';
require_once __DIR__ . '/MoniGrowthPro.php';
require_once __DIR__ . '/MoniShieldPro.php';
require_once __DIR__ . '/MoniFeaturePack20260930.php';
require_once __DIR__ . '/MoniCompletionPack.php';

if (isset($db) && $db instanceof PDO) {
    // Her özellik ailesi ayrı idempotent revizyon kullanır; mevcut admin ayarları tekrar varsayılana çekilmez.
    moni_v2_runtime_migrate($db);
    moni_commerce_runtime_migrate($db);
    moni_ops_pro_runtime_migrate($db);
    if (function_exists('moni_ops_intelligence_runtime_migrate')) moni_ops_intelligence_runtime_migrate($db);
    if (function_exists('moni_support_target_runtime_migrate')) moni_support_target_runtime_migrate($db);
    if (function_exists('moni_feature_pack_20260930_migrate')) moni_feature_pack_20260930_migrate($db);
    if (function_exists('moni_growth_runtime_migrate')) moni_growth_runtime_migrate($db);
    if (function_exists('moni_completion_runtime_migrate')) moni_completion_runtime_migrate($db);
    if (function_exists('moni_bootstrap')) moni_bootstrap($db);
}
