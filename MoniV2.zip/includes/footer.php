<?php
/**
 * SMM Panel - Footer Dosyası
 */

if (!isset($siteSettings)) {
    require_once __DIR__ . '/../config.php';
}

// Footer verilerini getir
$footerSections = [];
$footerLinks = [];
$socialLinks = [];
$contactSettings = [];

try {
    $footerSections = $db->query("SELECT * FROM footer_sections WHERE status = 'active' ORDER BY sort_order ASC")->fetchAll();
    $footerLinks = $db->query("SELECT * FROM footer_links WHERE status = 'active' ORDER BY section_id, sort_order ASC")->fetchAll();
    $socialLinks = $db->query("SELECT * FROM social_links WHERE status = 'active' ORDER BY sort_order ASC")->fetchAll();
    
    $stmt = $db->query("SELECT setting_key, setting_value FROM settings WHERE setting_key LIKE 'footer_%'");
    while ($row = $stmt->fetch()) {
        $contactSettings[$row['setting_key']] = $row['setting_value'];
    }
} catch (Exception $e) {}

// Linkleri bölümlere göre grupla
$linksBySection = [];
foreach ($footerLinks as $link) {
    $linksBySection[$link['section_id']][] = $link;
}

// Aktif bölüm sayısı
$activeSectionCount = 0;
foreach ($footerSections as $section) {
    if (isset($linksBySection[$section['id']]) && !empty($linksBySection[$section['id']])) {
        $activeSectionCount++;
    }
}

// İletişim aktif mi?
$contactEnabled = ($contactSettings['footer_contact_enabled'] ?? '1') === '1';
$hasContactInfo = !empty($contactSettings['footer_email']) || !empty($contactSettings['footer_phone']) || !empty($contactSettings['footer_address']) || !empty($contactSettings['footer_working_hours']);

if ($contactEnabled && $hasContactInfo) {
    $activeSectionCount++;
}

$totalColumns = 1 + $activeSectionCount;
?>
    </main>
    
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-top">
                <div class="footer-grid columns-<?php echo min($totalColumns, 4); ?>">
                    <!-- Hakkımızda -->
                    <div class="footer-section footer-about">
                        <div class="footer-logo">
                            <?php if (!empty($siteSettings['logo'])): ?>
                                <img src="<?php echo clean($siteSettings['logo']); ?>" alt="<?php echo clean($siteSettings['name']); ?>">
                            <?php else: ?>
                                <div class="footer-logo-icon"><i class="fas fa-chart-line"></i></div>
                                <span><?php echo clean($siteSettings['name']); ?></span>
                            <?php endif; ?>
                        </div>
                        <p class="footer-desc"><?php echo clean($siteSettings['description']); ?></p>
                        <?php if (!empty($socialLinks)): ?>
                        <div class="social-links">
                            <?php foreach ($socialLinks as $social): ?>
                            <a href="<?php echo clean($social['url']); ?>" class="social-link" title="<?php echo clean($social['platform']); ?>" target="_blank" rel="noopener">
                                <i class="<?php echo clean($social['icon']); ?>"></i>
                            </a>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Dinamik Bölümler -->
                    <?php foreach ($footerSections as $section): ?>
                        <?php if (isset($linksBySection[$section['id']]) && !empty($linksBySection[$section['id']])): ?>
                        <div class="footer-section">
                            <h4 class="footer-title"><?php echo clean($section['title']); ?></h4>
                            <ul class="footer-links">
                                <?php foreach ($linksBySection[$section['id']] as $link): ?>
                                <?php
                                    // Her zaman ana dizinden başlasın (http/https değilse mutlaklaştır)
                                    $linkUrl = $link['url'];
                                    if (!preg_match('~^https?://~i', $linkUrl) && strpos($linkUrl, 'mailto:') !== 0 && strpos($linkUrl, 'tel:') !== 0) {
                                        $linkUrl = rtrim(SITE_URL, '/') . '/' . ltrim($linkUrl, '/');
                                    }
                                ?>
                                <li>
                                    <a href="<?php echo clean($linkUrl); ?>" <?php echo $link['target'] === '_blank' ? 'target="_blank" rel="noopener"' : ''; ?>>
                                        <i class="<?php echo clean($link['icon'] ?: 'fas fa-chevron-right'); ?>"></i>
                                        <?php echo clean($link['title']); ?>
                                    </a>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                    
                    <!-- İletişim -->
                    <?php if ($contactEnabled && $hasContactInfo): ?>
                    <div class="footer-section">
                        <h4 class="footer-title">İletişim</h4>
                        <ul class="footer-contact">
                            <?php if (!empty($contactSettings['footer_email'])): ?>
                            <li>
                                <i class="fas fa-envelope"></i>
                                <a href="mailto:<?php echo clean($contactSettings['footer_email']); ?>"><?php echo clean($contactSettings['footer_email']); ?></a>
                            </li>
                            <?php endif; ?>
                            <?php if (!empty($contactSettings['footer_phone'])): ?>
                            <li>
                                <i class="fas fa-phone"></i>
                                <a href="tel:<?php echo clean($contactSettings['footer_phone']); ?>"><?php echo clean($contactSettings['footer_phone']); ?></a>
                            </li>
                            <?php endif; ?>
                            <?php if (!empty($contactSettings['footer_working_hours'])): ?>
                            <li>
                                <i class="fas fa-clock"></i>
                                <span><?php echo clean($contactSettings['footer_working_hours']); ?></span>
                            </li>
                            <?php endif; ?>
                            <?php if (!empty($contactSettings['footer_address'])): ?>
                            <li>
                                <i class="fas fa-map-marker-alt"></i>
                                <span><?php echo clean($contactSettings['footer_address']); ?></span>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p class="copyright">&copy; <?php echo date('Y'); ?> <strong><?php echo clean($siteSettings['name']); ?></strong>. Tüm hakları saklıdır.</p>
            </div>
        </div>
    </footer>
    
    <style>
    .footer {
        background: var(--footer-bg-color);
        color: var(--footer-muted-text-color);
        margin-top: auto;
    }
    .footer-container {
        max-width: 1400px;
        margin: 0 auto;
    }
    .footer-top {
        padding: 60px 20px 40px;
    }
    .footer-grid {
        display: grid;
        gap: 40px;
    }
    .footer-grid.columns-1 { grid-template-columns: 1fr; }
    .footer-grid.columns-2 { grid-template-columns: 1.5fr 1fr; }
    .footer-grid.columns-3 { grid-template-columns: 1.5fr 1fr 1fr; }
    .footer-grid.columns-4 { grid-template-columns: 1.5fr 1fr 1fr 1fr; }
    .footer-section {
        display: flex;
        flex-direction: column;
    }
    .footer-logo {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 20px;
    }
    .footer-logo img {
        max-height: 40px;
        width: auto;
    }
    .footer-logo-icon {
        width: 40px;
        height: 40px;
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--on-accent-color);
        font-size: 18px;
    }
    .footer-logo span {
        font-size: 1.3rem;
        font-weight: 700;
        color: var(--footer-text-color);
    }
    .footer-desc {
        font-size: 0.95rem;
        line-height: 1.7;
        margin-bottom: 20px;
        opacity: 0.8;
    }
    .social-links {
        display: flex;
        gap: 10px;
    }
    .social-link {
        width: 40px;
        height: 40px;
        background: var(--footer-hover-bg);
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--footer-text-color);
        transition: 0.3s;
    }
    .social-link:hover {
        background: var(--primary-color);
        transform: translateY(-3px);
        color: var(--on-primary-color);
    }
    .footer-title {
        font-size: 1.1rem;
        font-weight: 600;
        color: var(--footer-text-color);
        margin-bottom: 25px;
        position: relative;
        padding-bottom: 10px;
    }
    .footer-title::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 40px;
        height: 3px;
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        border-radius: 2px;
    }
    .footer-links {
        list-style: none;
        margin: 0;
        padding: 0;
    }
    .footer-links li {
        margin-bottom: 12px;
    }
    .footer-links a {
        color: var(--footer-muted-text-color);
        display: flex;
        align-items: center;
        gap: 8px;
        transition: 0.3s;
        font-size: 0.95rem;
    }
    .footer-links a:hover {
        color: var(--footer-accent-color);
        padding-left: 5px;
    }
    .footer-links i {
        font-size: 0.8rem;
        width: 16px;
    }
    .footer-contact {
        list-style: none;
        margin: 0;
        padding: 0;
    }
    .footer-contact li {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 15px;
        color: var(--footer-muted-text-color);
    }
    .footer-contact i {
        width: 35px;
        height: 35px;
        background: var(--footer-hover-bg);
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--footer-accent-color);
        flex-shrink: 0;
    }
    .footer-contact a {
        color: var(--footer-muted-text-color);
    }
    .footer-contact a:hover {
        color: var(--footer-accent-color);
    }
    .footer-bottom {
        border-top: 1px solid var(--footer-border-color);
        padding: 25px 20px;
        text-align: center;
    }
    .copyright {
        font-size: 0.9rem;
        opacity: 0.8;
        margin: 0;
    }
    @media (max-width: 992px) {
        .footer-grid.columns-4,
        .footer-grid.columns-3 {
            grid-template-columns: 1fr 1fr;
        }
        .footer-about {
            grid-column: span 2;
        }
    }
    @media (max-width: 576px) {
        .footer-top {
            padding: 40px 20px 30px;
        }
        .footer-grid.columns-2,
        .footer-grid.columns-3,
        .footer-grid.columns-4 {
            grid-template-columns: 1fr;
        }
        .footer-about {
            grid-column: span 1;
        }
    }
    </style>
    
    <button id="scrollToTop" class="scroll-to-top" onclick="scrollToTop()">
        <i class="fas fa-chevron-up"></i>
    </button>
    
    <style>
    .scroll-to-top {
        position: fixed;
        bottom: 30px;
        right: 30px;
        width: 50px;
        height: 50px;
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        border: none;
        border-radius: 50%;
        color: var(--on-accent-color);
        font-size: 1.2rem;
        cursor: pointer;
        opacity: 0;
        visibility: hidden;
        transition: 0.3s;
        z-index: 999;
        box-shadow: 0 5px 20px rgba(0,0,0,0.3);
    }
    .scroll-to-top.visible {
        opacity: 1;
        visibility: visible;
    }
    .scroll-to-top:hover {
        transform: translateY(-5px);
    }
    </style>
    
    <script>
    function scrollToTop() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    window.addEventListener('scroll', function() {
        var btn = document.getElementById('scrollToTop');
        if (window.pageYOffset > 300) {
            btn.classList.add('visible');
        } else {
            btn.classList.remove('visible');
        }
    });
    </script>
</body>
</html>