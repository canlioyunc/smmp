<?php
/**
 * Moni Operations Intelligence
 * - Provider balance depletion forecast
 * - Provider SLA tracking / breach lifecycle
 * - Queue age & latency observability
 */
if (defined('MONI_OPS_INTELLIGENCE_LOADED')) return;
define('MONI_OPS_INTELLIGENCE_LOADED', true);

function moni_ops_intelligence_runtime_migrate(PDO $db): void {
    static $done=false; if($done)return; $done=true;
    $revision='2026-09-29.1';
    try{
        $ready=function_exists('moni_v2_compat_setting')
            && moni_v2_compat_setting($db,'moni_ops_intelligence_schema_revision','')===$revision
            && function_exists('moni_table_ready')
            && moni_table_ready($db,'provider_sla_policies')
            && moni_table_ready($db,'provider_sla_snapshots')
            && moni_table_ready($db,'provider_sla_breaches');
        if($ready){
            try{$q=$db->query("SELECT 1 FROM cron_tasks WHERE task_key='provider_sla' LIMIT 1");$ready=(bool)$q->fetchColumn();}catch(Throwable $e){$ready=false;}
        }
        if($ready)return;

        $ddl=[];
        $ddl[]="CREATE TABLE IF NOT EXISTS provider_sla_policies (
            provider_id int NOT NULL,
            is_enabled tinyint(1) NOT NULL DEFAULT 1,
            window_hours int NOT NULL DEFAULT 24,
            min_success_rate decimal(6,2) NOT NULL DEFAULT 98.00,
            max_avg_latency_ms int NOT NULL DEFAULT 3000,
            min_health_score decimal(6,2) NOT NULL DEFAULT 90.00,
            max_consecutive_failures int NOT NULL DEFAULT 3,
            alert_on_breach tinyint(1) NOT NULL DEFAULT 1,
            updated_by int NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY(provider_id), KEY idx_sla_enabled(is_enabled,provider_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS provider_sla_snapshots (
            id bigint NOT NULL AUTO_INCREMENT,
            provider_id int NOT NULL,
            window_hours int NOT NULL,
            total_requests int NOT NULL DEFAULT 0,
            successful_requests int NOT NULL DEFAULT 0,
            failed_requests int NOT NULL DEFAULT 0,
            success_rate decimal(6,2) NOT NULL DEFAULT 100.00,
            avg_latency_ms decimal(12,2) NOT NULL DEFAULT 0.00,
            health_score decimal(6,2) NOT NULL DEFAULT 100.00,
            consecutive_failures int NOT NULL DEFAULT 0,
            is_breached tinyint(1) NOT NULL DEFAULT 0,
            breach_reasons varchar(1000) NULL,
            bucket_at datetime NOT NULL,
            captured_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(id), UNIQUE KEY uq_sla_provider_bucket(provider_id,bucket_at), KEY idx_sla_snap_time(provider_id,captured_at), KEY idx_sla_snap_breach(is_breached,captured_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS provider_sla_breaches (
            id bigint NOT NULL AUTO_INCREMENT,
            provider_id int NOT NULL,
            status enum('open','resolved') NOT NULL DEFAULT 'open',
            reasons varchar(1000) NOT NULL,
            metrics_json mediumtext NULL,
            opened_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_seen_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            resolved_at datetime NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY(id), KEY idx_sla_breach_open(provider_id,status,opened_at), KEY idx_sla_breach_status(status,last_seen_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        foreach($ddl as $sql)$db->exec($sql);

        $db->prepare("INSERT IGNORE INTO cron_tasks(task_key,name,interval_minutes,batch_size,is_enabled) VALUES('provider_sla','Sağlayıcı SLA Kontrolü',5,100,1)")->execute();
        $st=$db->prepare("INSERT IGNORE INTO settings(setting_key,setting_value) VALUES(?,?)");
        foreach([
            'provider_balance_forecast_window_hours'=>'168',
            'provider_balance_forecast_critical_hours'=>'12',
            'provider_balance_forecast_warning_hours'=>'72',
            'queue_health_warning_seconds'=>'300',
            'queue_health_critical_seconds'=>'1800',
        ] as $k=>$v)$st->execute([$k,$v]);
        if(function_exists('moni_v2_compat_set_setting'))moni_v2_compat_set_setting($db,'moni_ops_intelligence_schema_revision',$revision);
        else updateSetting('moni_ops_intelligence_schema_revision',$revision);
    }catch(Throwable $e){
        error_log('Moni Operations Intelligence migration failed: '.$e->getMessage());
        $GLOBALS['moni_ops_intelligence_migration_error']=$e->getMessage();
    }
}

function moni_ops_seconds_human(?int $seconds): string {
    if($seconds===null || $seconds<0)return '—';
    if($seconds<60)return $seconds.' sn';
    $m=(int)floor($seconds/60); if($m<60)return $m.' dk';
    $h=(int)floor($m/60); $rm=$m%60; if($h<48)return $h.' sa'.($rm?' '.$rm.' dk':'');
    $d=(int)floor($h/24); $rh=$h%24; return $d.' gün'.($rh?' '.$rh.' sa':'');
}

function moni_ops_percentile(array $values,float $p): ?float {
    $values=array_values(array_filter($values,fn($v)=>is_numeric($v)&&$v>=0));
    if(!$values)return null; sort($values,SORT_NUMERIC); $n=count($values);
    if($n===1)return (float)$values[0];
    $rank=max(0,min($n-1,($p/100)*($n-1)));$lo=(int)floor($rank);$hi=(int)ceil($rank);
    if($lo===$hi)return (float)$values[$lo];$w=$rank-$lo;return (float)$values[$lo]*(1-$w)+(float)$values[$hi]*$w;
}

function moni_provider_balance_forecast(PDO $db,int $providerId,?int $windowHours=null): array {
    $windowHours=$windowHours??max(6,min(720,(int)getSetting('provider_balance_forecast_window_hours','168')));
    $p=$db->prepare("SELECT id,name,alias_name,status,balance,currency,last_sync FROM api_providers WHERE id=? LIMIT 1");$p->execute([$providerId]);$provider=$p->fetch(PDO::FETCH_ASSOC);
    if(!$provider)return ['ok'=>false,'provider_id'=>$providerId,'reason'=>'Sağlayıcı bulunamadı.'];
    $balance=max(0,(float)($provider['balance']??0));$currency=strtoupper((string)($provider['currency']??''));
    $rows=[];
    if(function_exists('moni_table_ready')&&moni_table_ready($db,'provider_balance_snapshots')){
        $q=$db->prepare("SELECT balance,currency_code,captured_at FROM provider_balance_snapshots WHERE provider_id=? AND captured_at>=DATE_SUB(NOW(),INTERVAL {$windowHours} HOUR) ORDER BY captured_at ASC,id ASC");
        $q->execute([$providerId]);$rows=$q->fetchAll(PDO::FETCH_ASSOC);
    }
    $spent=0.0;$usable=0;$firstTs=null;$lastTs=null;$prev=null;
    foreach($rows as $r){
        if($currency!=='' && strtoupper((string)$r['currency_code'])!==$currency)continue;
        $ts=strtotime((string)$r['captured_at']);if(!$ts)continue;$b=(float)$r['balance'];
        if($firstTs===null)$firstTs=$ts;$lastTs=$ts;$usable++;
        if($prev!==null){$drop=$prev-$b;if($drop>0)$spent+=$drop;}
        $prev=$b;
    }
    $spanHours=($firstTs!==null&&$lastTs!==null&&$lastTs>$firstTs)?(($lastTs-$firstTs)/3600):0.0;
    $burnPerHour=($spanHours>=0.5&&$spent>0)?$spent/$spanHours:0.0;
    $hoursLeft=$burnPerHour>0?$balance/$burnPerHour:null;
    $critical=max(1,(int)getSetting('provider_balance_forecast_critical_hours','12'));
    $warning=max($critical+1,(int)getSetting('provider_balance_forecast_warning_hours','72'));
    $risk='unknown';
    if($hoursLeft!==null){$risk=$hoursLeft<=$critical?'critical':($hoursLeft<=$warning?'warning':'ok');}
    elseif($balance<=0)$risk='critical';
    $confidence='low';if($usable>=24&&$spanHours>=24)$confidence='high';elseif($usable>=6&&$spanHours>=4)$confidence='medium';
    return [
        'ok'=>true,'provider_id'=>$providerId,'provider'=>$provider,'balance'=>$balance,'currency'=>$currency,
        'sample_count'=>$usable,'span_hours'=>$spanHours,'observed_spend'=>$spent,'burn_per_hour'=>$burnPerHour,'burn_per_day'=>$burnPerHour*24,
        'hours_left'=>$hoursLeft,'risk'=>$risk,'confidence'=>$confidence,
    ];
}

function moni_provider_balance_forecasts(PDO $db,int $limit=20): array {
    try{$ids=$db->query("SELECT id FROM api_providers WHERE status='active' ORDER BY id")->fetchAll(PDO::FETCH_COLUMN);}catch(Throwable $e){return [];}
    $out=[];foreach($ids as $id){$f=moni_provider_balance_forecast($db,(int)$id);if(!empty($f['ok']))$out[]=$f;}
    $weight=['critical'=>0,'warning'=>1,'unknown'=>2,'ok'=>3];
    usort($out,function($a,$b)use($weight){$wa=$weight[$a['risk']]??9;$wb=$weight[$b['risk']]??9;if($wa!==$wb)return $wa<=>$wb;$ha=$a['hours_left']??INF;$hb=$b['hours_left']??INF;return $ha<=>$hb;});
    return array_slice($out,0,max(1,$limit));
}

function moni_provider_sla_default_policy(int $providerId): array {
    return ['provider_id'=>$providerId,'is_enabled'=>1,'window_hours'=>24,'min_success_rate'=>98.0,'max_avg_latency_ms'=>3000,'min_health_score'=>90.0,'max_consecutive_failures'=>3,'alert_on_breach'=>1];
}

function moni_provider_sla_policy(PDO $db,int $providerId): array {
    $d=moni_provider_sla_default_policy($providerId);
    if(!function_exists('moni_table_ready')||!moni_table_ready($db,'provider_sla_policies'))return $d;
    try{$s=$db->prepare("SELECT * FROM provider_sla_policies WHERE provider_id=? LIMIT 1");$s->execute([$providerId]);$r=$s->fetch(PDO::FETCH_ASSOC);return $r?array_merge($d,$r):$d;}catch(Throwable $e){return $d;}
}

function moni_provider_sla_metrics(PDO $db,int $providerId,?array $policy=null): array {
    $policy=$policy?:moni_provider_sla_policy($db,$providerId);$hours=max(1,min(720,(int)($policy['window_hours']??24)));
    $total=$ok=$fail=0;$avg=0.0;
    if(function_exists('moni_table_ready')&&moni_table_ready($db,'provider_health_events')){
        $s=$db->prepare("SELECT COUNT(*) total,SUM(is_success=1) ok_count,SUM(is_success=0) fail_count,COALESCE(AVG(CASE WHEN latency_ms>=0 THEN latency_ms END),0) avg_latency FROM provider_health_events WHERE provider_id=? AND created_at>=DATE_SUB(NOW(),INTERVAL {$hours} HOUR)");
        $s->execute([$providerId]);$r=$s->fetch(PDO::FETCH_ASSOC)?:[];$total=(int)($r['total']??0);$ok=(int)($r['ok_count']??0);$fail=(int)($r['fail_count']??0);$avg=(float)($r['avg_latency']??0);
    }
    $health=100.0;$consecutive=0;$lastError='';
    if(function_exists('moni_table_ready')&&moni_table_ready($db,'provider_health')){
        $s=$db->prepare("SELECT health_score,consecutive_failures,last_error FROM provider_health WHERE provider_id=? LIMIT 1");$s->execute([$providerId]);$h=$s->fetch(PDO::FETCH_ASSOC);if($h){$health=(float)$h['health_score'];$consecutive=(int)$h['consecutive_failures'];$lastError=(string)($h['last_error']??'');}
    }
    $rate=$total>0?($ok/$total*100):100.0;$reasons=[];
    if($total>0 && $rate+0.0001<(float)$policy['min_success_rate'])$reasons[]='Başarı oranı '.number_format($rate,2).'% < hedef '.number_format((float)$policy['min_success_rate'],2).'%';
    if($total>0 && $avg>(int)$policy['max_avg_latency_ms'])$reasons[]='Ort. gecikme '.(int)round($avg).' ms > hedef '.(int)$policy['max_avg_latency_ms'].' ms';
    if($health+0.0001<(float)$policy['min_health_score'])$reasons[]='Sağlık skoru '.number_format($health,2).' < hedef '.number_format((float)$policy['min_health_score'],2);
    if($consecutive>(int)$policy['max_consecutive_failures'])$reasons[]='Ardışık hata '.$consecutive.' > hedef '.(int)$policy['max_consecutive_failures'];
    return ['provider_id'=>$providerId,'window_hours'=>$hours,'total'=>$total,'ok'=>$ok,'fail'=>$fail,'success_rate'=>$rate,'avg_latency_ms'=>$avg,'health_score'=>$health,'consecutive_failures'=>$consecutive,'last_error'=>$lastError,'breached'=>!empty($reasons),'reasons'=>$reasons];
}

function moni_provider_sla_persist(PDO $db,int $providerId,array $policy,array $metrics): array {
    if(!moni_table_ready($db,'provider_sla_snapshots')||!moni_table_ready($db,'provider_sla_breaches'))return ['opened'=>false,'resolved'=>false];
    $bucket=date('Y-m-d H:').sprintf('%02d',(int)(floor((int)date('i')/5)*5)).':00';$reasonText=implode(' | ',$metrics['reasons']);
    $db->prepare("INSERT INTO provider_sla_snapshots(provider_id,window_hours,total_requests,successful_requests,failed_requests,success_rate,avg_latency_ms,health_score,consecutive_failures,is_breached,breach_reasons,bucket_at,captured_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE window_hours=VALUES(window_hours),total_requests=VALUES(total_requests),successful_requests=VALUES(successful_requests),failed_requests=VALUES(failed_requests),success_rate=VALUES(success_rate),avg_latency_ms=VALUES(avg_latency_ms),health_score=VALUES(health_score),consecutive_failures=VALUES(consecutive_failures),is_breached=VALUES(is_breached),breach_reasons=VALUES(breach_reasons),captured_at=NOW()")
        ->execute([$providerId,(int)$metrics['window_hours'],(int)$metrics['total'],(int)$metrics['ok'],(int)$metrics['fail'],(float)$metrics['success_rate'],(float)$metrics['avg_latency_ms'],(float)$metrics['health_score'],(int)$metrics['consecutive_failures'],!empty($metrics['breached'])?1:0,$reasonText?:null,$bucket]);
    $s=$db->prepare("SELECT * FROM provider_sla_breaches WHERE provider_id=? AND status='open' ORDER BY id DESC LIMIT 1");$s->execute([$providerId]);$open=$s->fetch(PDO::FETCH_ASSOC);$opened=$resolved=false;
    $json=json_encode($metrics,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    if(!empty($metrics['breached'])){
        if($open){$db->prepare("UPDATE provider_sla_breaches SET reasons=?,metrics_json=?,last_seen_at=NOW(),updated_at=NOW() WHERE id=?")->execute([$reasonText,$json,(int)$open['id']]);}
        else{$db->prepare("INSERT INTO provider_sla_breaches(provider_id,status,reasons,metrics_json,opened_at,last_seen_at) VALUES(?,'open',?,?,NOW(),NOW())")->execute([$providerId,$reasonText,$json]);$opened=true;}
    }elseif($open){$db->prepare("UPDATE provider_sla_breaches SET status='resolved',resolved_at=NOW(),last_seen_at=NOW(),metrics_json=?,updated_at=NOW() WHERE id=?")->execute([$json,(int)$open['id']]);$resolved=true;}
    return ['opened'=>$opened,'resolved'=>$resolved];
}

function moni_provider_sla_check_all(PDO $db,int $batch=100): array {
    if(!moni_table_ready($db,'api_providers'))return ['processed'=>0,'breached'=>0,'opened'=>0,'resolved'=>0];
    $batch=max(1,min(1000,$batch));$lockName='moni_provider_sla_scan';$hasLock=false;
    try{$lk=$db->prepare("SELECT GET_LOCK(?,0)");$lk->execute([$lockName]);$hasLock=(int)$lk->fetchColumn()===1;}catch(Throwable $e){}
    if(!$hasLock)return ['processed'=>0,'breached'=>0,'opened'=>0,'resolved'=>0,'skipped'=>true];
    try{
        $rows=$db->query("SELECT p.id,p.name,p.alias_name FROM api_providers p LEFT JOIN (SELECT provider_id,MAX(captured_at) last_capture FROM provider_sla_snapshots GROUP BY provider_id) ss ON ss.provider_id=p.id WHERE p.status='active' ORDER BY COALESCE(ss.last_capture,'1970-01-01') ASC,p.id ASC LIMIT {$batch}")->fetchAll(PDO::FETCH_ASSOC);$processed=$breached=$opened=$resolved=0;
        foreach($rows as $p){
        $policy=moni_provider_sla_policy($db,(int)$p['id']);if(empty($policy['is_enabled']))continue;$metrics=moni_provider_sla_metrics($db,(int)$p['id'],$policy);$life=moni_provider_sla_persist($db,(int)$p['id'],$policy,$metrics);$processed++;
        if($metrics['breached'])$breached++;
        $name=function_exists('moni_provider_display_name')?moni_provider_display_name($db,$p):(string)($p['alias_name']?:$p['name']);
        if(!empty($life['opened'])){$opened++;if(!empty($policy['alert_on_breach'])&&function_exists('moni_admin_notify'))moni_admin_notify($db,'provider_sla_breach','Sağlayıcı SLA ihlali',$name.': '.implode(' · ',$metrics['reasons']),'/admin/provider-sla.php','danger',false);}
        if(!empty($life['resolved'])){$resolved++;if(!empty($policy['alert_on_breach'])&&function_exists('moni_admin_notify'))moni_admin_notify($db,'provider_sla_resolved','Sağlayıcı SLA düzeldi',$name.' SLA hedeflerine yeniden ulaştı.','/admin/provider-sla.php','success',false);}
        }
        return ['processed'=>$processed,'breached'=>$breached,'opened'=>$opened,'resolved'=>$resolved];
    } finally { try{$rl=$db->prepare("SELECT RELEASE_LOCK(?)");$rl->execute([$lockName]);}catch(Throwable $e){} }
}

function moni_cron_task_provider_sla(PDO $db,int $batch): array {
    $r=moni_provider_sla_check_all($db,$batch);return ['processed'=>(int)$r['processed'],'message'=>(int)$r['processed'].' sağlayıcı SLA açısından kontrol edildi; '.(int)$r['breached'].' ihlal, '.(int)$r['opened'].' yeni, '.(int)$r['resolved'].' çözüldü.'];
}

function moni_queue_single_metrics(PDO $db,string $table,array $activeStatuses,string $created='created_at',?string $completed=null,array $terminalStatuses=[]): array {
    if(!preg_match('/^[a-zA-Z0-9_]+$/',$table)||!moni_table_ready($db,$table))return ['available'=>false];
    $quoted=implode(',',array_map(fn($s)=>$db->quote($s),$activeStatuses));$terminal=$terminalStatuses?implode(',',array_map(fn($s)=>$db->quote($s),$terminalStatuses)):'';
    $active=$db->query("SELECT COUNT(*) c,MAX(TIMESTAMPDIFF(SECOND,`{$created}`,NOW())) oldest FROM `{$table}` WHERE status IN({$quoted})")->fetch(PDO::FETCH_ASSOC)?:[];
    $result=['available'=>true,'waiting'=>(int)($active['c']??0),'oldest_seconds'=>$active['oldest']===null?null:(int)$active['oldest'],'failed'=>0,'manual'=>0,'retry'=>0,'processing'=>0,'avg_latency_seconds'=>null,'p95_latency_seconds'=>null,'max_latency_seconds'=>null];
    foreach(['failed','manual_review','retry','processing'] as $status){try{$s=$db->prepare("SELECT COUNT(*) FROM `{$table}` WHERE status=?");$s->execute([$status]);$count=(int)$s->fetchColumn();if($status==='manual_review')$result['manual']=$count;else $result[$status]=$count;}catch(Throwable $e){}}
    if($completed!==null){
        try{$where=$terminal!==''?"status IN({$terminal}) AND":"";$q=$db->query("SELECT TIMESTAMPDIFF(SECOND,`{$created}`,`{$completed}`) sec FROM `{$table}` WHERE {$where} `{$completed}` IS NOT NULL AND `{$completed}`>=DATE_SUB(NOW(),INTERVAL 24 HOUR) ORDER BY `{$completed}` DESC LIMIT 2000");$vals=[];foreach($q->fetchAll(PDO::FETCH_COLUMN) as $v)if($v!==null&&(int)$v>=0)$vals[]=(int)$v;if($vals){$result['avg_latency_seconds']=(int)round(array_sum($vals)/count($vals));$result['p95_latency_seconds']=(int)round(moni_ops_percentile($vals,95));$result['max_latency_seconds']=max($vals);$result['completed_sample']=count($vals);}}catch(Throwable $e){}
    }
    return $result;
}

function moni_queue_health(PDO $db): array {
    $queues=[];
    $queues['order_dispatch']=array_merge(['key'=>'order_dispatch','name'=>'Sipariş Provider Gönderim','icon'=>'fa-paper-plane'],moni_queue_single_metrics($db,'order_dispatch_jobs',['queued','retry','processing'],'created_at','completed_at',['completed']));
    $queues['cancel']=array_merge(['key'=>'cancel','name'=>'Sipariş İptal','icon'=>'fa-ban'],moni_queue_single_metrics($db,'cancel_jobs',['queued','retry','processing'],'created_at','completed_at',['completed']));
    $queues['accounting']=array_merge(['key'=>'accounting','name'=>'Muhasebe Senkron','icon'=>'fa-calculator'],moni_queue_single_metrics($db,'accounting_sync_queue',['pending','processing'],'created_at','sent_at',['sent']));
    $queues['web_push']=array_merge(['key'=>'web_push','name'=>'Web Push','icon'=>'fa-bell'],moni_queue_single_metrics($db,'web_push_queue',['pending'],'created_at','sent_at',['sent']));
    $warning=max(30,(int)getSetting('queue_health_warning_seconds','300'));$critical=max($warning+1,(int)getSetting('queue_health_critical_seconds','1800'));
    $summary=['waiting'=>0,'failed'=>0,'manual'=>0,'oldest_seconds'=>0,'risk'=>'ok'];
    foreach($queues as &$q){if(empty($q['available']))continue;$summary['waiting']+=(int)$q['waiting'];$summary['failed']+=(int)$q['failed'];$summary['manual']+=(int)$q['manual'];$old=(int)($q['oldest_seconds']??0);$summary['oldest_seconds']=max($summary['oldest_seconds'],$old);$q['risk']=$old>=$critical?'critical':($old>=$warning?'warning':'ok');if($q['failed']>0||$q['manual']>0)$q['risk']=$q['risk']==='critical'?'critical':'warning';}
    unset($q);
    if($summary['oldest_seconds']>=$critical)$summary['risk']='critical';elseif($summary['oldest_seconds']>=$warning||$summary['failed']>0||$summary['manual']>0)$summary['risk']='warning';
    return ['summary'=>$summary,'queues'=>$queues,'warning_seconds'=>$warning,'critical_seconds'=>$critical];
}
