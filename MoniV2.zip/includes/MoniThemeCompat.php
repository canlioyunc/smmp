<?php
/**
 * v2 theme compatibility helpers.
 * Adds optional per-surface text colors without changing panel layout.
 */
if (!function_exists('moni_theme_compat_css')) {
function moni_theme_compat_css(array $theme): string {
    $background = moniNormalizeHexColor($theme['background_color'] ?? '#1a1a2e', '#1a1a2e');
    $card = moniNormalizeHexColor($theme['card_bg_color'] ?? '#1f1f3d', '#1f1f3d');
    $header = moniNormalizeHexColor($theme['header_bg_color'] ?? '#16213e', '#16213e');
    $sidebar = moniNormalizeHexColor($theme['sidebar_bg_color'] ?? $header, $header);
    $configuredText = moniNormalizeHexColor($theme['text_color'] ?? '#ffffff', '#ffffff');
    $buttonTextConfigured = moniNormalizeHexColor($theme['button_text_color'] ?? '#ffffff', '#ffffff');
    $primary = moniNormalizeHexColor($theme['primary_color'] ?? '#6c5ce7', '#6c5ce7');
    $button = moniNormalizeHexColor($theme['button_color'] ?? $primary, $primary);
    $success = moniNormalizeHexColor($theme['success_color'] ?? '#28a745', '#28a745');
    $danger = moniNormalizeHexColor($theme['danger_color'] ?? '#dc3545', '#dc3545');
    $warning = moniNormalizeHexColor($theme['warning_color'] ?? '#ffc107', '#ffc107');
    $info = moniNormalizeHexColor($theme['info_color'] ?? '#17a2b8', '#17a2b8');
    $fontMap=[
        'inter'=>"'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
        'system'=>"-apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif",
        'trebuchet'=>"'Trebuchet MS', 'Segoe UI', Arial, sans-serif",
        'georgia'=>"Georgia, 'Times New Roman', serif",
        'mono'=>"'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace",
    ];
    $fontKey=strtolower(trim((string)($theme['font_family']??'inter')));
    $headingKey=strtolower(trim((string)($theme['heading_font_family']??$fontKey)));
    $fontFamily = function_exists('moniThemeFontStack') ? moniThemeFontStack($fontKey) : ($fontMap[$fontKey]??$fontMap['inter']);
    $headingFontFamily = function_exists('moniThemeFontStack') ? moniThemeFontStack($headingKey) : ($fontMap[$headingKey]??$fontFamily);
    $inputBg = moniNormalizeHexColor($theme['input_bg_color'] ?? moniMixHexColors($card,$background,0.58), moniMixHexColors($card,$background,0.58));
    $inputBorder = moniNormalizeHexColor($theme['input_border_color'] ?? ($theme['border_color'] ?? '#2d2d5a'), $theme['border_color'] ?? '#2d2d5a');
    $secondaryButtonBg = moniNormalizeHexColor($theme['secondary_button_bg_color'] ?? moniMixHexColors($card,$background,0.32), moniMixHexColors($card,$background,0.32));
    $secondaryButtonHover = moniNormalizeHexColor($theme['secondary_button_hover_color'] ?? moniMixHexColors($secondaryButtonBg,$primary,0.16), $secondaryButtonBg);
    $walletButton = moniNormalizeHexColor($theme['wallet_button_color'] ?? $success, $success);
    $walletButtonHover = moniNormalizeHexColor($theme['wallet_button_hover_color'] ?? moniMixHexColors($walletButton,'#000000',0.14), $walletButton);
    $walletButtonText = moniBestContrastText($walletButton, $theme['wallet_button_text_color'] ?? '#ffffff', 4.5);
    // Large user-panel hero/banner surfaces should follow the selected theme instead of
    // blindly using the usually much brighter primary/secondary pair.
    $panelHeroStart = moniNormalizeHexColor($theme['panel_hero_start_color'] ?? moniMixHexColors($card,$primary,0.16), moniMixHexColors($card,$primary,0.16));
    $panelHeroEnd = moniNormalizeHexColor($theme['panel_hero_end_color'] ?? moniMixHexColors($card,$secondary,0.12), moniMixHexColors($card,$secondary,0.12));
    $panelHeroMid = moniMixHexColors($panelHeroStart,$panelHeroEnd,0.5);
    $panelHeroText = moniBestContrastText($panelHeroMid, $theme['panel_hero_text_color'] ?? $configuredText, 4.5);
    $panelHeroMuted = moniMixHexColors($panelHeroText,$panelHeroMid,0.28);
    $panelHeroBorder = moniMixHexColors($border,$primary,0.18);

    $cardText = moniBestContrastText($card, $theme['card_text_color'] ?? $configuredText, 4.5);
    $headerText = moniBestContrastText($header, $theme['header_text_color'] ?? $configuredText, 4.5);
    $sidebarText = moniBestContrastText($sidebar, $theme['sidebar_text_color'] ?? $configuredText, 4.5);
    $mutedText = !empty($theme['muted_text_color'])
        ? moniBestContrastText($background, $theme['muted_text_color'], 4.5)
        : moniMixHexColors(moniBestContrastText($background, $configuredText, 4.5), $background, 0.34);
    $inputText = moniBestContrastText($inputBg, $theme['input_text_color'] ?? $cardText, 4.5);
    $link = !empty($theme['link_color'])
        ? moniReadableColorOnSurfaces($theme['link_color'], [$background, $card], 4.5)
        : moniReadableColorOnSurfaces($primary, [$background, $card], 4.5);
    $secondaryButtonText = moniBestContrastText($card, $theme['secondary_button_text_color'] ?? $cardText, 4.5);
    $buttonText = moniBestContrastText($button, $buttonTextConfigured, 4.5);

    return ":root{\n" .
        "--theme-font-family:{$fontFamily};\n" .
        "--theme-heading-font-family:{$headingFontFamily};\n" .
        "--header-text-color:{$headerText};\n" .
        "--sidebar-text-color:{$sidebarText};\n" .
        "--card-text-color:{$cardText};\n" .
        "--muted-text-color:{$mutedText};\n" .
        "--card-muted-text-color:" . moniMixHexColors($cardText, $card, 0.34) . ";\n" .
        "--input-bg-color:{$inputBg};\n" .
        "--input-border-color:{$inputBorder};\n" .
        "--input-text-color:{$inputText};\n" .
        "--secondary-button-bg-color:{$secondaryButtonBg};\n" .
        "--secondary-button-hover-color:{$secondaryButtonHover};\n" .
        "--wallet-button-color:{$walletButton};\n" .
        "--wallet-button-hover-color:{$walletButtonHover};\n" .
        "--wallet-button-text-color:{$walletButtonText};\n" .
        "--panel-hero-start-color:{$panelHeroStart};\n" .
        "--panel-hero-end-color:{$panelHeroEnd};\n" .
        "--panel-hero-text-color:{$panelHeroText};\n" .
        "--panel-hero-muted-text-color:{$panelHeroMuted};\n" .
        "--panel-hero-border-color:{$panelHeroBorder};\n" .
        "--accent-text-color:{$link};\n" .
        "--secondary-button-text-color:{$secondaryButtonText};\n" .
        "--button-text-color:{$buttonText};\n" .
        "--success-soft-bg:" . moniHexRgba($success,0.15) . ";\n" .
        "--danger-soft-bg:" . moniHexRgba($danger,0.15) . ";\n" .
        "--warning-soft-bg:" . moniHexRgba($warning,0.16) . ";\n" .
        "--info-soft-bg:" . moniHexRgba($info,0.15) . ";\n" .
        "--success-soft-border:" . moniHexRgba($success,0.40) . ";\n" .
        "--danger-soft-border:" . moniHexRgba($danger,0.40) . ";\n" .
        "--warning-soft-border:" . moniHexRgba($warning,0.42) . ";\n" .
        "--info-soft-border:" . moniHexRgba($info,0.40) . ";\n" .
        "}\n";
}
}
