<?php
if (defined('MONI_PREMIUM_LOADED')) return;
define('MONI_PREMIUM_LOADED', true);

function moni_premium_runtime_migrate(PDO $db): void {
    static $done=false; if($done)return; $done=true;
    $revision='2026-09-29.3';
    try {
        // Premium eklentisi açık olsa bile güncel şemada her istekte DDL çalıştırma.
        $schemaReady=function_exists('moni_table_ready')
            && moni_table_ready($db,'premium_packages')
            && moni_table_ready($db,'user_premium_memberships')
            && moni_table_ready($db,'premium_cashback_rules')
            && moni_table_ready($db,'premium_cashback_rewards')
            && moni_table_ready($db,'premium_category_discounts')
            && moni_table_ready($db,'premium_service_access')
            && moni_table_ready($db,'premium_trial_claims')
            && moni_table_ready($db,'premium_membership_changes')
            && (!function_exists('moni_v2_compat_column_exists') || (
                moni_v2_compat_column_exists($db,'premium_packages','trial_days')
                && moni_v2_compat_column_exists($db,'premium_packages','service_discount_percent')
                && moni_v2_compat_column_exists($db,'premium_packages','api_rate_bonus_percent')
                && moni_v2_compat_column_exists($db,'user_premium_memberships','scheduled_package_id')
                && moni_v2_compat_column_exists($db,'premium_cashback_rewards','available_at')
            ));
        if($schemaReady && function_exists('moni_v2_compat_setting') && moni_v2_compat_setting($db,'moni_premium_schema_revision','')===$revision)return;
        $ddl=[
            "CREATE TABLE IF NOT EXISTS premium_packages (
                id int NOT NULL AUTO_INCREMENT,name varchar(150) NOT NULL,description text NULL,
                price decimal(15,4) NOT NULL DEFAULT 0,duration_days int NOT NULL DEFAULT 30,tier_level int NOT NULL DEFAULT 0,
                dispatch_priority_percent decimal(5,2) NOT NULL DEFAULT 0,service_discount_percent decimal(5,2) NOT NULL DEFAULT 0,
                api_rate_bonus_percent int NOT NULL DEFAULT 0,badge_text varchar(80) NULL,badge_color varchar(20) NOT NULL DEFAULT '#7c3aed',
                cashback_multiplier decimal(6,2) NOT NULL DEFAULT 1.00,cashback_cap_amount decimal(15,4) NOT NULL DEFAULT 0,
                cashback_cap_cycle enum('membership','monthly') NOT NULL DEFAULT 'monthly',cashback_wait_days int NOT NULL DEFAULT 0,
                trial_days int NOT NULL DEFAULT 0,is_active tinyint(1) NOT NULL DEFAULT 1,sort_order int NOT NULL DEFAULT 0,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY(id),KEY idx_premium_packages_active(is_active,sort_order),KEY idx_premium_tier(tier_level,is_active)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS user_premium_memberships (
                id bigint NOT NULL AUTO_INCREMENT,user_id int NOT NULL,package_id int NOT NULL,starts_at datetime NOT NULL,expires_at datetime NOT NULL,
                status enum('active','expired','cancelled') NOT NULL DEFAULT 'active',auto_renew tinyint(1) NOT NULL DEFAULT 0,
                source enum('admin','balance','system','trial','upgrade','downgrade') NOT NULL DEFAULT 'admin',last_renewed_at datetime NULL,
                cashback_checked_at datetime NULL,scheduled_package_id int NULL,scheduled_auto_renew tinyint(1) NOT NULL DEFAULT 0,cancelled_at datetime NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY(id),KEY idx_premium_user_status(user_id,status,expires_at),KEY idx_premium_package(package_id,status,expires_at),KEY idx_premium_scheduled(scheduled_package_id,status,expires_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS premium_cashback_rules (
                id bigint NOT NULL AUTO_INCREMENT,package_id int NOT NULL,name varchar(150) NOT NULL,spend_threshold decimal(15,4) NOT NULL,
                reward_type enum('fixed','percent') NOT NULL DEFAULT 'fixed',reward_value decimal(15,4) NOT NULL,
                cycle enum('membership','monthly') NOT NULL DEFAULT 'membership',is_active tinyint(1) NOT NULL DEFAULT 1,sort_order int NOT NULL DEFAULT 0,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY(id),KEY idx_cashback_package(package_id,is_active,spend_threshold)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS premium_cashback_rewards (
                id bigint NOT NULL AUTO_INCREMENT,user_id int NOT NULL,membership_id bigint NOT NULL,rule_id bigint NOT NULL,cycle_key varchar(40) NOT NULL,
                cap_cycle_key varchar(60) NOT NULL DEFAULT '',eligible_spend decimal(15,4) NOT NULL DEFAULT 0,reward_amount decimal(15,4) NOT NULL DEFAULT 0,
                status enum('pending','paid','cancelled') NOT NULL DEFAULT 'paid',available_at datetime NULL,paid_at datetime NULL,transaction_id bigint NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY(id),UNIQUE KEY uq_premium_reward(membership_id,rule_id,cycle_key),KEY idx_premium_reward_user(user_id,created_at),KEY idx_premium_reward_due(status,available_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS premium_category_discounts (
                id bigint NOT NULL AUTO_INCREMENT,package_id int NOT NULL,category_id int NOT NULL,discount_percent decimal(5,2) NOT NULL DEFAULT 0,is_active tinyint(1) NOT NULL DEFAULT 1,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY(id),UNIQUE KEY uq_premium_cat_discount(package_id,category_id),KEY idx_premium_cat(category_id,is_active)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS premium_service_access (
                id bigint NOT NULL AUTO_INCREMENT,package_id int NOT NULL,service_id int NOT NULL,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(id),UNIQUE KEY uq_premium_service_access(package_id,service_id),KEY idx_premium_service(service_id,package_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS premium_trial_claims (
                id bigint NOT NULL AUTO_INCREMENT,user_id int NOT NULL,package_id int NOT NULL,membership_id bigint NULL,claimed_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(id),UNIQUE KEY uq_premium_trial(user_id,package_id),KEY idx_premium_trial_pkg(package_id,claimed_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS premium_membership_changes (
                id bigint NOT NULL AUTO_INCREMENT,user_id int NOT NULL,membership_id bigint NULL,from_package_id int NULL,to_package_id int NULL,
                change_type enum('purchase','renew','upgrade','downgrade_scheduled','downgrade_applied','trial','cancel','admin_change') NOT NULL,
                credit_amount decimal(15,4) NOT NULL DEFAULT 0,charged_amount decimal(15,4) NOT NULL DEFAULT 0,effective_at datetime NOT NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY idx_premium_changes_user(user_id,created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        ];
        foreach($ddl as $sql)$db->exec($sql);
        $cols=[
            ['premium_packages','tier_level','int NOT NULL DEFAULT 0'],['premium_packages','service_discount_percent','decimal(5,2) NOT NULL DEFAULT 0'],
            ['premium_packages','api_rate_bonus_percent','int NOT NULL DEFAULT 0'],['premium_packages','badge_text','varchar(80) NULL'],['premium_packages','badge_color',"varchar(20) NOT NULL DEFAULT '#7c3aed'"],
            ['premium_packages','cashback_multiplier','decimal(6,2) NOT NULL DEFAULT 1.00'],['premium_packages','cashback_cap_amount','decimal(15,4) NOT NULL DEFAULT 0'],
            ['premium_packages','cashback_cap_cycle',"enum('membership','monthly') NOT NULL DEFAULT 'monthly'"],['premium_packages','cashback_wait_days','int NOT NULL DEFAULT 0'],['premium_packages','trial_days','int NOT NULL DEFAULT 0'],
            ['user_premium_memberships','cashback_checked_at','datetime NULL'],['user_premium_memberships','scheduled_package_id','int NULL'],['user_premium_memberships','scheduled_auto_renew','tinyint(1) NOT NULL DEFAULT 0'],
            ['premium_cashback_rewards','cap_cycle_key',"varchar(60) NOT NULL DEFAULT ''"],['premium_cashback_rewards','status',"enum('pending','paid','cancelled') NOT NULL DEFAULT 'paid'"],
            ['premium_cashback_rewards','available_at','datetime NULL'],['premium_cashback_rewards','paid_at','datetime NULL'],['premium_cashback_rewards','updated_at','datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP']
        ];
        foreach($cols as [$t,$c,$def]){try{if(function_exists('moni_v2_compat_add_column'))moni_v2_compat_add_column($db,$t,$c,$def);else $db->exec("ALTER TABLE `$t` ADD COLUMN `$c` $def");}catch(Throwable $ignore){}}
        try{$db->exec("ALTER TABLE user_premium_memberships MODIFY source enum('admin','balance','system','trial','upgrade','downgrade') NOT NULL DEFAULT 'admin'");}catch(Throwable $ignore){}
        try{$db->exec("ALTER TABLE premium_membership_changes MODIFY change_type enum('purchase','renew','upgrade','downgrade_scheduled','downgrade_applied','trial','cancel','admin_change') NOT NULL");}catch(Throwable $ignore){}
        try{$db->exec("UPDATE premium_cashback_rewards SET status='paid',paid_at=COALESCE(paid_at,created_at) WHERE transaction_id IS NOT NULL");}catch(Throwable $ignore){}
        try{$db->exec("INSERT IGNORE INTO staff_permissions(permission_key,name,group_name) VALUES('premium.manage','Premium üyelik yönetimi','Kullanıcı')");}catch(Throwable $ignore){}
        try{$db->exec("INSERT INTO cron_tasks(task_key,name,interval_minutes,batch_size,is_enabled) VALUES('premium_memberships','Premium Üyelik / Cashback İşlemleri',5,250,1) ON DUPLICATE KEY UPDATE is_enabled=1");}catch(Throwable $ignore){}
        if(function_exists('moni_v2_compat_set_setting'))moni_v2_compat_set_setting($db,'moni_premium_schema_revision',$revision);
    } catch(Throwable $e){ error_log('Premium migration failed: '.$e->getMessage()); $GLOBALS['moni_premium_migration_error']=$e->getMessage(); }
}

function moni_premium_package(PDO $db,int $packageId,bool $activeOnly=false): ?array {
    try{$sql="SELECT * FROM premium_packages WHERE id=?".($activeOnly?" AND is_active=1":"")." LIMIT 1";$s=$db->prepare($sql);$s->execute([$packageId]);$r=$s->fetch(PDO::FETCH_ASSOC);return $r?:null;}catch(Throwable $e){return null;}
}
function moni_active_premium_membership(PDO $db,int $userId,bool $forUpdate=false): ?array {
    if($userId<=0)return null;
    try{$sql="SELECT m.*,p.name package_name,p.price package_price,p.duration_days,p.tier_level,p.dispatch_priority_percent,p.service_discount_percent,p.api_rate_bonus_percent,p.badge_text,p.badge_color,p.cashback_multiplier,p.cashback_cap_amount,p.cashback_cap_cycle,p.cashback_wait_days,p.trial_days,p.is_active package_is_active FROM user_premium_memberships m JOIN premium_packages p ON p.id=m.package_id WHERE m.user_id=? AND m.status='active' AND m.starts_at<=NOW() AND m.expires_at>NOW() ORDER BY p.tier_level DESC,p.dispatch_priority_percent DESC,m.expires_at DESC,m.id DESC LIMIT 1".($forUpdate?' FOR UPDATE':'');$s=$db->prepare($sql);$s->execute([$userId]);$r=$s->fetch(PDO::FETCH_ASSOC);return $r?:null;}catch(Throwable $e){return null;}
}
function moni_user_dispatch_priority(PDO $db,int $userId): float {$m=moni_active_premium_membership($db,$userId);return $m?max(0,min(100,(float)$m['dispatch_priority_percent'])):0.0;}
function moni_premium_badge(PDO $db,int $userId): ?array {$m=moni_active_premium_membership($db,$userId);if(!$m)return null;$text=trim((string)($m['badge_text']??''));if($text==='')$text=(string)$m['package_name'];$color=preg_match('/^#[0-9a-f]{6}$/i',(string)$m['badge_color'])?(string)$m['badge_color']:'#7c3aed';return ['text'=>$text,'color'=>$color,'package'=>$m['package_name']];}
function moni_premium_api_rate_limit(PDO $db,int $userId,int $base): int {$m=moni_active_premium_membership($db,$userId);if(!$m)return max(1,$base);$bonus=max(0,min(10000,(int)$m['api_rate_bonus_percent']));return max(1,min(100000,(int)floor($base*(1+$bonus/100))));}

function moni_premium_category_discount(PDO $db,int $packageId,int $categoryId): ?float {
    if($packageId<=0||$categoryId<=0)return null;static $cache=[];$k=$packageId.':'.$categoryId;if(array_key_exists($k,$cache))return $cache[$k];
    try{$s=$db->prepare("SELECT discount_percent FROM premium_category_discounts WHERE package_id=? AND category_id=? AND is_active=1 LIMIT 1");$s->execute([$packageId,$categoryId]);$v=$s->fetchColumn();return $cache[$k]=$v===false?null:max(0,min(95,(float)$v));}catch(Throwable $e){return $cache[$k]=null;}
}
function moni_premium_apply_price(PDO $db,int $userId,array $service,float $price): float {
    $m=moni_active_premium_membership($db,$userId);if(!$m)return $price;
    $discount=moni_premium_category_discount($db,(int)$m['package_id'],(int)($service['category_id']??0));
    if($discount===null)$discount=max(0,min(95,(float)($m['service_discount_percent']??0)));
    return round($price*(1-$discount/100),4);
}
function moni_premium_service_visible_to_user(PDO $db,int $serviceId,int $userId): bool {
    static $restricted=[];if(!array_key_exists($serviceId,$restricted)){try{$s=$db->prepare("SELECT package_id FROM premium_service_access WHERE service_id=?");$s->execute([$serviceId]);$restricted[$serviceId]=array_map('intval',$s->fetchAll(PDO::FETCH_COLUMN));}catch(Throwable $e){$restricted[$serviceId]=[];}}
    if(!$restricted[$serviceId])return true;$m=moni_active_premium_membership($db,$userId);return $m&&in_array((int)$m['package_id'],$restricted[$serviceId],true);
}

function moni_premium_log_change(PDO $db,int $userId,?int $membershipId,?int $from,?int $to,string $type,float $credit=0,float $charged=0,?string $effective=null): void {
    try{$db->prepare("INSERT INTO premium_membership_changes(user_id,membership_id,from_package_id,to_package_id,change_type,credit_amount,charged_amount,effective_at,created_at) VALUES(?,?,?,?,?,?,?,?,NOW())")->execute([$userId,$membershipId,$from,$to,$type,round($credit,4),round($charged,4),$effective?:date('Y-m-d H:i:s')]);}catch(Throwable $ignore){}
}
function moni_premium_debit(PDO $db,int $userId,float $amount,string $description): void {
    $amount=round(max(0,$amount),4);$u=$db->prepare("SELECT balance,status FROM users WHERE id=? FOR UPDATE");$u->execute([$userId]);$user=$u->fetch(PDO::FETCH_ASSOC);if(!$user||$user['status']!=='active')throw new RuntimeException('Kullanıcı aktif değil.');if((float)$user['balance']+0.00001<$amount)throw new RuntimeException('Premium işlemi için bakiye yetersiz.');if($amount<=0)return;$after=(float)$user['balance']-$amount;$db->prepare("UPDATE users SET balance=? WHERE id=?")->execute([$after,$userId]);$db->prepare("INSERT INTO transactions(user_id,type,amount,balance_after,description,status,created_at) VALUES(?,'order',?,?,?,'completed',NOW())")->execute([$userId,-$amount,$after,$description]);
}
function moni_premium_purchase(PDO $db,int $userId,int $packageId,bool $autoRenew=false,string $source='balance'): array {
    try{$pkg=moni_premium_package($db,$packageId,true);if(!$pkg)return ['ok'=>false,'error'=>'Premium paketi bulunamadı veya satışta değil.'];$price=max(0,(float)$pkg['price']);$days=max(1,(int)$pkg['duration_days']);$db->beginTransaction();$current=moni_active_premium_membership($db,$userId,true);
        if($current && (int)$current['package_id']!==$packageId){
            if($source!=='admin'){$db->rollBack();return moni_premium_change_package($db,$userId,$packageId,$autoRenew);}
            // Admin ataması ücretsizdir; aktif farklı paketi kullanıcı bakiyesine dokunmadan değiştir.
            $db->prepare("UPDATE user_premium_memberships SET status='cancelled',auto_renew=0,scheduled_package_id=NULL,scheduled_auto_renew=0,cancelled_at=NOW(),updated_at=NOW() WHERE id=?")->execute([$current['id']]);
            $expires=(new DateTimeImmutable('now'))->modify('+'.$days.' days')->format('Y-m-d H:i:s');
            $db->prepare("INSERT INTO user_premium_memberships(user_id,package_id,starts_at,expires_at,status,auto_renew,source,created_at) VALUES(?,?,NOW(),?,'active',?,'admin',NOW())")->execute([$userId,$packageId,$expires,$autoRenew?1:0]);
            $mid=(int)$db->lastInsertId();moni_premium_log_change($db,$userId,$mid,(int)$current['package_id'],$packageId,'admin_change',0,0);$db->commit();
            if(function_exists('moni_user_notify'))moni_user_notify($db,$userId,'premium','Premium paketiniz güncellendi',$pkg['name'].' paketi '.$expires.' tarihine kadar aktif.','/kullanici/premium.php','success');
            return ['ok'=>true,'membership_id'=>$mid,'expires_at'=>$expires,'change'=>'admin_switch'];
        }
        if($source==='balance')moni_premium_debit($db,$userId,$price,'Premium üyelik: '.$pkg['name']);else{$u=$db->prepare("SELECT id,status FROM users WHERE id=? FOR UPDATE");$u->execute([$userId]);$ur=$u->fetch(PDO::FETCH_ASSOC);if(!$ur||$ur['status']!=='active')throw new RuntimeException('Kullanıcı aktif değil.');}
        $base=($current&&strtotime((string)$current['expires_at'])>time())?new DateTimeImmutable((string)$current['expires_at']):new DateTimeImmutable('now');$expires=$base->modify('+'.$days.' days')->format('Y-m-d H:i:s');
        if($current){$db->prepare("UPDATE user_premium_memberships SET expires_at=?,auto_renew=?,scheduled_package_id=NULL,scheduled_auto_renew=0,updated_at=NOW() WHERE id=?")->execute([$expires,$autoRenew?1:0,$current['id']]);$mid=(int)$current['id'];$change='renew';}
        else{$src=in_array($source,['admin','balance','system'],true)?$source:'system';$db->prepare("INSERT INTO user_premium_memberships(user_id,package_id,starts_at,expires_at,status,auto_renew,source,created_at) VALUES(?,?,NOW(),?,'active',?,?,NOW())")->execute([$userId,$packageId,$expires,$autoRenew?1:0,$src]);$mid=(int)$db->lastInsertId();$change='purchase';}
        moni_premium_log_change($db,$userId,$mid,$current?(int)$current['package_id']:null,$packageId,$change,0,$source==='balance'?$price:0);$db->commit();if(function_exists('moni_sync_base_wallet'))moni_sync_base_wallet($db,$userId);if(function_exists('moni_user_notify'))moni_user_notify($db,$userId,'premium','Premium üyeliğiniz aktif edildi',$pkg['name'].' paketi '.$expires.' tarihine kadar aktif.','/kullanici/premium.php','success');return ['ok'=>true,'membership_id'=>$mid,'expires_at'=>$expires];
    }catch(Throwable $e){if($db->inTransaction())$db->rollBack();return ['ok'=>false,'error'=>$e->getMessage()];}
}
function moni_premium_start_trial(PDO $db,int $userId,int $packageId): array {
    try{$pkg=moni_premium_package($db,$packageId,true);if(!$pkg||max(0,(int)$pkg['trial_days'])<1)return ['ok'=>false,'error'=>'Bu pakette deneme süresi bulunmuyor.'];if(moni_active_premium_membership($db,$userId))return ['ok'=>false,'error'=>'Aktif premium üyeliğiniz varken deneme başlatılamaz.'];$db->beginTransaction();$q=$db->prepare("SELECT id FROM premium_trial_claims WHERE user_id=? AND package_id=? FOR UPDATE");$q->execute([$userId,$packageId]);if($q->fetchColumn())throw new RuntimeException('Bu paketin ücretsiz denemesini daha önce kullandınız.');$expires=(new DateTimeImmutable('now'))->modify('+'.(int)$pkg['trial_days'].' days')->format('Y-m-d H:i:s');$db->prepare("INSERT INTO user_premium_memberships(user_id,package_id,starts_at,expires_at,status,auto_renew,source,created_at) VALUES(?,?,NOW(),?,'active',0,'trial',NOW())")->execute([$userId,$packageId,$expires]);$mid=(int)$db->lastInsertId();$db->prepare("INSERT INTO premium_trial_claims(user_id,package_id,membership_id,claimed_at) VALUES(?,?,?,NOW())")->execute([$userId,$packageId,$mid]);moni_premium_log_change($db,$userId,$mid,null,$packageId,'trial',0,0);$db->commit();if(function_exists('moni_user_notify'))moni_user_notify($db,$userId,'premium','Premium denemeniz başladı',$pkg['name'].' denemeniz '.$expires.' tarihine kadar aktif.','/kullanici/premium.php','success');return ['ok'=>true,'membership_id'=>$mid,'expires_at'=>$expires];}catch(Throwable $e){if($db->inTransaction())$db->rollBack();return ['ok'=>false,'error'=>$e->getMessage()];}
}
function moni_premium_change_package(PDO $db,int $userId,int $targetPackageId,bool $autoRenew=false): array {
    try{$target=moni_premium_package($db,$targetPackageId,true);if(!$target)return ['ok'=>false,'error'=>'Hedef premium paket satışta değil.'];$current=moni_active_premium_membership($db,$userId);if(!$current)return moni_premium_purchase($db,$userId,$targetPackageId,$autoRenew,'balance');if((int)$current['package_id']===$targetPackageId)return moni_premium_purchase($db,$userId,$targetPackageId,$autoRenew,'balance');
        if((int)$target['tier_level']>(int)$current['tier_level']){
            $db->beginTransaction();$locked=moni_active_premium_membership($db,$userId,true);if(!$locked)throw new RuntimeException('Aktif üyelik bulunamadı.');$now=time();$remaining=max(0,strtotime((string)$locked['expires_at'])-$now);$duration=max(1,(int)$locked['duration_days'])*86400;$credit=(string)$locked['source']==='trial'?0:round(max(0,(float)$locked['package_price'])*($remaining/$duration),4);$targetPrice=max(0,(float)$target['price']);$charge=max(0,round($targetPrice-$credit,4));$extraCredit=max(0,$credit-$targetPrice);moni_premium_debit($db,$userId,$charge,'Premium yükseltme: '.$target['name']);$db->prepare("UPDATE user_premium_memberships SET status='cancelled',auto_renew=0,cancelled_at=NOW(),updated_at=NOW() WHERE id=?")->execute([$locked['id']]);$targetDays=max(1,(int)$target['duration_days']);$extraSeconds=$targetPrice>0?(int)round(($extraCredit/$targetPrice)*$targetDays*86400):0;$expires=(new DateTimeImmutable('now'))->modify('+'.$targetDays.' days')->modify('+'.$extraSeconds.' seconds')->format('Y-m-d H:i:s');$db->prepare("INSERT INTO user_premium_memberships(user_id,package_id,starts_at,expires_at,status,auto_renew,source,created_at) VALUES(?,?,NOW(),?,'active',?,'upgrade',NOW())")->execute([$userId,$targetPackageId,$expires,$autoRenew?1:0]);$mid=(int)$db->lastInsertId();moni_premium_log_change($db,$userId,$mid,(int)$locked['package_id'],$targetPackageId,'upgrade',$credit,$charge);$db->commit();if(function_exists('moni_sync_base_wallet'))moni_sync_base_wallet($db,$userId);return ['ok'=>true,'membership_id'=>$mid,'expires_at'=>$expires,'credit'=>$credit,'charged'=>$charge,'extra_seconds'=>$extraSeconds,'change'=>'upgrade'];
        }
        $db->prepare("UPDATE user_premium_memberships SET scheduled_package_id=?,scheduled_auto_renew=?,auto_renew=0,updated_at=NOW() WHERE id=? AND user_id=? AND status='active'")->execute([$targetPackageId,$autoRenew?1:0,$current['id'],$userId]);moni_premium_log_change($db,$userId,(int)$current['id'],(int)$current['package_id'],$targetPackageId,'downgrade_scheduled',0,0,(string)$current['expires_at']);return ['ok'=>true,'scheduled'=>true,'effective_at'=>$current['expires_at'],'change'=>'downgrade'];
    }catch(Throwable $e){if($db->inTransaction())$db->rollBack();return ['ok'=>false,'error'=>$e->getMessage()];}
}
function moni_premium_cancel_scheduled_change(PDO $db,int $userId,int $membershipId): bool {try{$s=$db->prepare("UPDATE user_premium_memberships SET scheduled_package_id=NULL,scheduled_auto_renew=0,updated_at=NOW() WHERE id=? AND user_id=? AND status='active'");$s->execute([$membershipId,$userId]);return $s->rowCount()>0;}catch(Throwable $e){return false;}}

function moni_premium_cycle_bounds(array $membership,string $cycle): array {$start=new DateTimeImmutable((string)$membership['starts_at']);$end=new DateTimeImmutable((string)$membership['expires_at']);if($cycle==='monthly'){$now=new DateTimeImmutable('now');$cs=$now->modify('first day of this month')->setTime(0,0);$ce=$cs->modify('first day of next month');if($cs<$start)$cs=$start;if($ce>$end)$ce=$end;return [$cs,$ce,$cs->format('Y-m')];}return [$start,$end,'membership-'.$membership['id']];}
function moni_premium_cycles(array $membership,string $cycle): array {$start=new DateTimeImmutable((string)$membership['starts_at']);$end=new DateTimeImmutable((string)$membership['expires_at']);$effective=min($end,new DateTimeImmutable('now'));if($effective<=$start)return [];if($cycle!=='monthly')return [[$start,$end,'membership-'.$membership['id']]];$out=[];$cursor=$start;$guard=0;while($cursor<$effective&&$guard++<240){$to=$cursor->modify('first day of next month')->setTime(0,0);if($to>$end)$to=$end;$out[]=[$cursor,$to,$cursor->format('Y-m')];$cursor=$to;}return $out;}
function moni_premium_eligible_spend(PDO $db,int $userId,DateTimeImmutable $start,DateTimeImmutable $end): float {try{$s=$db->prepare("SELECT COALESCE(SUM(GREATEST(0,price-COALESCE(refund_amount,0))),0) FROM orders WHERE user_id=? AND created_at>=? AND created_at<? AND status IN('completed','partial')");$s->execute([$userId,$start->format('Y-m-d H:i:s'),$end->format('Y-m-d H:i:s')]);return round((float)$s->fetchColumn(),4);}catch(Throwable $e){return 0.0;}}
function moni_premium_cashback_cap_key(array $m,DateTimeImmutable $from): string {return ($m['cashback_cap_cycle']??'monthly')==='membership'?'cap-membership-'.$m['id']:'cap-'.$from->format('Y-m');}
function moni_premium_cashback_remaining(PDO $db,array $m,string $capKey,int $excludeId=0): float {$cap=max(0,(float)($m['cashback_cap_amount']??0));if($cap<=0)return INF;try{$s=$db->prepare("SELECT COALESCE(SUM(reward_amount),0) FROM premium_cashback_rewards WHERE membership_id=? AND cap_cycle_key=? AND status IN('pending','paid') AND id<>?");$s->execute([$m['id'],$capKey,$excludeId]);return max(0,$cap-(float)$s->fetchColumn());}catch(Throwable $e){return 0;}}
function moni_premium_pay_reward(PDO $db,array $m,array $rule,array $reward,DateTimeImmutable $from,DateTimeImmutable $to): bool {
    $spend=moni_premium_eligible_spend($db,(int)$m['user_id'],$from,$to);if($spend+0.00001<(float)$rule['spend_threshold']){$db->prepare("UPDATE premium_cashback_rewards SET status='cancelled',updated_at=NOW() WHERE id=? AND status='pending'")->execute([$reward['id']]);return false;}
    $base=$rule['reward_type']==='percent'?$spend*max(0,(float)$rule['reward_value'])/100:max(0,(float)$rule['reward_value']);$amount=round($base*max(0,(float)($m['cashback_multiplier']??1)),4);$remaining=moni_premium_cashback_remaining($db,$m,(string)$reward['cap_cycle_key'],(int)$reward['id']);if(is_finite($remaining))$amount=min($amount,$remaining);if($amount<=0){$db->prepare("UPDATE premium_cashback_rewards SET status='cancelled',reward_amount=0,updated_at=NOW() WHERE id=?")->execute([$reward['id']]);return false;}
    $db->beginTransaction();try{$lock=$db->prepare("SELECT * FROM premium_cashback_rewards WHERE id=? FOR UPDATE");$lock->execute([$reward['id']]);$rr=$lock->fetch(PDO::FETCH_ASSOC);if(!$rr||$rr['status']!=='pending'||(!empty($rr['available_at'])&&strtotime($rr['available_at'])>time())){$db->rollBack();return false;}$u=$db->prepare("SELECT balance FROM users WHERE id=? FOR UPDATE");$u->execute([$m['user_id']]);$bal=$u->fetchColumn();if($bal===false)throw new RuntimeException('Cashback kullanıcısı bulunamadı.');$after=(float)$bal+$amount;$db->prepare("UPDATE users SET balance=? WHERE id=?")->execute([$after,$m['user_id']]);$db->prepare("INSERT INTO transactions(user_id,type,amount,balance_after,description,status,created_at) VALUES(?,'bonus',?,?,?,'completed',NOW())")->execute([$m['user_id'],$amount,$after,'Premium cashback: '.$rule['name'].' ('.$reward['cycle_key'].')']);$tx=(int)$db->lastInsertId();$db->prepare("UPDATE premium_cashback_rewards SET eligible_spend=?,reward_amount=?,status='paid',paid_at=NOW(),transaction_id=?,updated_at=NOW() WHERE id=?")->execute([$spend,$amount,$tx,$reward['id']]);$db->commit();if(function_exists('moni_sync_base_wallet'))moni_sync_base_wallet($db,(int)$m['user_id']);if(function_exists('moni_user_notify'))moni_user_notify($db,(int)$m['user_id'],'premium_cashback','Cashback bakiyenize yatırıldı',number_format($amount,2).' cashback ödülü hesabınıza eklendi.','/kullanici/premium.php','success');return true;}catch(Throwable $e){if($db->inTransaction())$db->rollBack();error_log('Premium cashback pay: '.$e->getMessage());return false;}
}


function moni_premium_reward_cycle_bounds(array $membership,array $rule,string $cycleKey): array {
    $start=new DateTimeImmutable((string)$membership['starts_at']);$end=new DateTimeImmutable((string)$membership['expires_at']);
    if(($rule['cycle']??'membership')==='monthly' && preg_match('/^\\d{4}-\\d{2}$/',$cycleKey)){
        $cs=new DateTimeImmutable($cycleKey.'-01 00:00:00');$ce=$cs->modify('first day of next month');if($cs<$start)$cs=$start;if($ce>$end)$ce=$end;return [$cs,$ce];
    }
    return [$start,$end];
}

function moni_process_premium_memberships(PDO $db,int $batch=250): array {
    if(function_exists('moni_plugin_enabled')&&!moni_plugin_enabled('premium_memberships',$db))return ['processed'=>0,'message'=>'Premium Üyelik eklentisi pasif.'];
    $batch=max(1,min(5000,$batch));$processed=0;$rewards=0;$renewed=0;$expired=0;$changed=0;
    // Süresi dolmuş üyelikler: önce planlı paket değişimi, sonra otomatik yenileme, son olarak expire.
    $rows=$db->query("SELECT m.*,p.name package_name,p.price package_price,p.duration_days,p.is_active package_is_active FROM user_premium_memberships m JOIN premium_packages p ON p.id=m.package_id WHERE m.status='active' AND m.expires_at<=NOW() ORDER BY m.expires_at ASC LIMIT $batch")->fetchAll(PDO::FETCH_ASSOC);
    foreach($rows as $m){$processed++;try{$db->beginTransaction();$lock=$db->prepare("SELECT * FROM user_premium_memberships WHERE id=? FOR UPDATE");$lock->execute([$m['id']]);$lm=$lock->fetch(PDO::FETCH_ASSOC);if(!$lm||$lm['status']!=='active'||strtotime((string)$lm['expires_at'])>time()){$db->rollBack();continue;}
        if(!empty($lm['scheduled_package_id'])){$target=moni_premium_package($db,(int)$lm['scheduled_package_id'],true);if($target){try{moni_premium_debit($db,(int)$lm['user_id'],max(0,(float)$target['price']),'Premium paket değişimi: '.$target['name']);$db->prepare("UPDATE user_premium_memberships SET status='expired',updated_at=NOW() WHERE id=?")->execute([$lm['id']]);$exp=(new DateTimeImmutable('now'))->modify('+'.max(1,(int)$target['duration_days']).' days')->format('Y-m-d H:i:s');$db->prepare("INSERT INTO user_premium_memberships(user_id,package_id,starts_at,expires_at,status,auto_renew,source,created_at) VALUES(?,?,NOW(),?,'active',?,'downgrade',NOW())")->execute([$lm['user_id'],$target['id'],$exp,!empty($lm['scheduled_auto_renew'])?1:0]);$mid=(int)$db->lastInsertId();moni_premium_log_change($db,(int)$lm['user_id'],$mid,(int)$lm['package_id'],(int)$target['id'],'downgrade_applied',0,(float)$target['price']);$db->commit();$changed++;continue;}catch(Throwable $inner){if($db->inTransaction())$db->rollBack();$db->prepare("UPDATE user_premium_memberships SET status='expired',auto_renew=0,scheduled_package_id=NULL,updated_at=NOW() WHERE id=?")->execute([$lm['id']]);$expired++;continue;}}}
        if(!empty($lm['auto_renew'])&&!empty($m['package_is_active'])){try{moni_premium_debit($db,(int)$lm['user_id'],max(0,(float)$m['package_price']),'Premium otomatik yenileme: '.$m['package_name']);$newExp=(new DateTimeImmutable((string)$lm['expires_at']))->modify('+'.max(1,(int)$m['duration_days']).' days')->format('Y-m-d H:i:s');$db->prepare("UPDATE user_premium_memberships SET expires_at=?,last_renewed_at=NOW(),updated_at=NOW() WHERE id=?")->execute([$newExp,$lm['id']]);moni_premium_log_change($db,(int)$lm['user_id'],(int)$lm['id'],(int)$lm['package_id'],(int)$lm['package_id'],'renew',0,(float)$m['package_price']);$db->commit();$renewed++;continue;}catch(Throwable $renewError){if($db->inTransaction())$db->rollBack();$db->prepare("UPDATE user_premium_memberships SET status='expired',auto_renew=0,updated_at=NOW() WHERE id=?")->execute([$lm['id']]);if(function_exists('moni_user_notify'))moni_user_notify($db,(int)$lm['user_id'],'premium','Premium otomatik yenilenemedi','Premium paketiniz bakiye yetersizliği veya ödeme hatası nedeniyle yenilenemedi.','/kullanici/premium.php','warning');$expired++;continue;}}
        $db->prepare("UPDATE user_premium_memberships SET status='expired',auto_renew=0,updated_at=NOW() WHERE id=?")->execute([$lm['id']]);$db->commit();$expired++;
    }catch(Throwable $e){if($db->inTransaction())$db->rollBack();error_log('Premium expiry: '.$e->getMessage());}}

    $members=$db->query("SELECT m.*,p.name package_name,p.cashback_multiplier,p.cashback_cap_amount,p.cashback_cap_cycle,p.cashback_wait_days FROM user_premium_memberships m JOIN premium_packages p ON p.id=m.package_id WHERE m.status='active' AND m.starts_at<=NOW() AND m.expires_at>NOW() ORDER BY COALESCE(m.cashback_checked_at,'1970-01-01') ASC,m.id ASC LIMIT $batch")->fetchAll(PDO::FETCH_ASSOC);
    foreach($members as $m){$rules=$db->prepare("SELECT * FROM premium_cashback_rules WHERE package_id=? AND is_active=1 ORDER BY spend_threshold,sort_order,id");$rules->execute([$m['package_id']]);foreach($rules->fetchAll(PDO::FETCH_ASSOC) as $rule){foreach(moni_premium_cycles($m,(string)$rule['cycle']) as [$from,$to,$cycleKey]){if($to<=$from)continue;$spend=moni_premium_eligible_spend($db,(int)$m['user_id'],$from,$to);$existingQ=$db->prepare("SELECT * FROM premium_cashback_rewards WHERE membership_id=? AND rule_id=? AND cycle_key=? LIMIT 1");$existingQ->execute([$m['id'],$rule['id'],$cycleKey]);$existing=$existingQ->fetch(PDO::FETCH_ASSOC);
            if($spend+0.00001<(float)$rule['spend_threshold']){if($existing&&$existing['status']==='pending')$db->prepare("UPDATE premium_cashback_rewards SET status='cancelled',updated_at=NOW() WHERE id=?")->execute([$existing['id']]);continue;}
            $capKey=moni_premium_cashback_cap_key($m,$from);$base=$rule['reward_type']==='percent'?$spend*max(0,(float)$rule['reward_value'])/100:max(0,(float)$rule['reward_value']);$amount=round($base*max(0,(float)($m['cashback_multiplier']??1)),4);$remaining=moni_premium_cashback_remaining($db,$m,$capKey,$existing?(int)$existing['id']:0);if(is_finite($remaining))$amount=min($amount,$remaining);if($amount<=0)continue;$available=(new DateTimeImmutable('now'))->modify('+'.max(0,(int)$m['cashback_wait_days']).' days')->format('Y-m-d H:i:s');
            if(!$existing){$db->prepare("INSERT INTO premium_cashback_rewards(user_id,membership_id,rule_id,cycle_key,cap_cycle_key,eligible_spend,reward_amount,status,available_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,'pending',?,NOW(),NOW())")->execute([$m['user_id'],$m['id'],$rule['id'],$cycleKey,$capKey,$spend,$amount,$available]);$existing=['id'=>(int)$db->lastInsertId(),'status'=>'pending','available_at'=>$available,'cycle_key'=>$cycleKey,'cap_cycle_key'=>$capKey];}
            elseif($existing['status']==='cancelled'){$db->prepare("UPDATE premium_cashback_rewards SET cap_cycle_key=?,eligible_spend=?,reward_amount=?,status='pending',available_at=?,transaction_id=NULL,paid_at=NULL,updated_at=NOW() WHERE id=?")->execute([$capKey,$spend,$amount,$available,$existing['id']]);$existing=array_merge($existing,['status'=>'pending','available_at'=>$available,'cap_cycle_key'=>$capKey]);}
            elseif($existing['status']==='pending'){$db->prepare("UPDATE premium_cashback_rewards SET eligible_spend=?,reward_amount=?,cap_cycle_key=?,updated_at=NOW() WHERE id=?")->execute([$spend,$amount,$capKey,$existing['id']]);}
            if(($existing['status']??'')==='pending' && (empty($existing['available_at'])||strtotime((string)$existing['available_at'])<=time()))if(moni_premium_pay_reward($db,$m,$rule,$existing,$from,$to))$rewards++;
        }}try{$db->prepare("UPDATE user_premium_memberships SET cashback_checked_at=NOW() WHERE id=?")->execute([$m['id']]);}catch(Throwable $ignore){}
    }
    // Bekleme süresi üyelik bittikten/upgrade edildikten sonra dolan kazanılmış cashback'leri de sonuçlandır.
    try{$due=$db->query("SELECT r.*,m.user_id m_user_id,m.package_id m_package_id,m.starts_at m_starts_at,m.expires_at m_expires_at,m.status m_status,p.cashback_multiplier,p.cashback_cap_amount,p.cashback_cap_cycle,p.cashback_wait_days,cr.name rule_name,cr.spend_threshold,cr.reward_type,cr.reward_value,cr.cycle FROM premium_cashback_rewards r JOIN user_premium_memberships m ON m.id=r.membership_id JOIN premium_packages p ON p.id=m.package_id JOIN premium_cashback_rules cr ON cr.id=r.rule_id WHERE r.status='pending' AND r.available_at<=NOW() ORDER BY r.available_at ASC,r.id ASC LIMIT $batch")->fetchAll(PDO::FETCH_ASSOC);foreach($due as $dr){$mm=['id'=>(int)$dr['membership_id'],'user_id'=>(int)$dr['m_user_id'],'package_id'=>(int)$dr['m_package_id'],'starts_at'=>$dr['m_starts_at'],'expires_at'=>$dr['m_expires_at'],'cashback_multiplier'=>$dr['cashback_multiplier'],'cashback_cap_amount'=>$dr['cashback_cap_amount'],'cashback_cap_cycle'=>$dr['cashback_cap_cycle'],'cashback_wait_days'=>$dr['cashback_wait_days']];$rr=['id'=>(int)$dr['rule_id'],'name'=>$dr['rule_name'],'spend_threshold'=>$dr['spend_threshold'],'reward_type'=>$dr['reward_type'],'reward_value'=>$dr['reward_value'],'cycle'=>$dr['cycle']];[$rf,$rt]=moni_premium_reward_cycle_bounds($mm,$rr,(string)$dr['cycle_key']);if(moni_premium_pay_reward($db,$mm,$rr,$dr,$rf,$rt))$rewards++;}}
    catch(Throwable $e){error_log('Premium pending cashback: '.$e->getMessage());}
    return ['processed'=>$processed+count($members),'message'=>"Premium kontrolü: $renewed yenileme, $changed paket değişimi, $rewards cashback, $expired biten üyelik."];
}
