<?php
if (defined('MONI_PROVIDERS_LOADED')) return;
define('MONI_PROVIDERS_LOADED', true);

function moni_provider_by_id(PDO $db, int $providerId): ?array {
    $st=$db->prepare("SELECT * FROM api_providers WHERE id=? LIMIT 1");
    $st->execute([$providerId]);
    $p=$st->fetch(PDO::FETCH_ASSOC);
    if(!$p) return null;
    $p['api_key']=moni_decrypt_secret($p['api_key'] ?? '');
    return $p;
}

function moni_provider_request(array $provider, array $payload, string $operation='request', int $timeout=35, bool $trackTelemetry=true): array {
    $db=$GLOBALS['db']??null;
    $url=trim((string)($provider['api_url']??''));
    $key=moni_decrypt_secret((string)($provider['api_key']??''));
    $isAdd=$operation==='add';
    if($url===''||$key===''){
        return ['success'=>false,'error'=>'Sağlayıcı API bilgileri eksik.','http_code'=>0,'latency_ms'=>0,'safe_to_failover'=>$isAdd,'ambiguous'=>false];
    }

    if (!function_exists('moni_safe_public_url') || !moni_safe_public_url($url)) {
        return ['success'=>false,'error'=>"Güvensiz veya yerel sağlayıcı URL'si reddedildi.",'http_code'=>0,'latency_ms'=>0,'safe_to_failover'=>$isAdd,'ambiguous'=>false];
    }
    $parts=parse_url($url);$host=(string)($parts['host']??'');$scheme=strtolower((string)($parts['scheme']??''));$port=(int)($parts['port']??($scheme==='https'?443:80));
    $resolved=function_exists('moni_resolve_public_host')?moni_resolve_public_host($host):null;
    if(!$resolved)return ['success'=>false,'error'=>"Sağlayıcı alan adı güvenli bir genel IP'ye çözümlenemedi.",'http_code'=>0,'latency_ms'=>0,'safe_to_failover'=>$isAdd,'ambiguous'=>false];

    $payload=['key'=>$key]+$payload;
    $started=microtime(true);
    $ch=curl_init();
    curl_setopt_array($ch,[
        CURLOPT_URL=>$url,
        CURLOPT_RESOLVE=>[$host.':'.$port.':'.$resolved],
        CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>$payload,
        CURLOPT_RETURNTRANSFER=>true,
        CURLOPT_CONNECTTIMEOUT=>10,
        CURLOPT_TIMEOUT=>$timeout,
        CURLOPT_SSL_VERIFYPEER=>true,
        CURLOPT_SSL_VERIFYHOST=>2,
        CURLOPT_FOLLOWLOCATION=>false,
        CURLOPT_HTTPHEADER=>['Accept: application/json','User-Agent: SMMPanel/2.0']
    ]);
    $raw=curl_exec($ch);
    $curlError=curl_error($ch);
    $http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);
    curl_close($ch);
    $latency=(int)round((microtime(true)-$started)*1000);
    $json=is_string($raw)?json_decode($raw,true):null;

    $transportOk=$curlError==='' && $http>=200 && $http<300;
    $hasExplicitError=is_array($json) && isset($json['error']) && trim((string)$json['error'])!=='';
    $ok=$transportOk && is_array($json) && !$hasExplicitError;
    if($operation==='add') $ok=$ok && isset($json['order']) && (string)$json['order']!=='';
    if($operation==='status') $ok=$ok && isset($json['status']);
    if($operation==='balance') $ok=$ok && (isset($json['balance'])||isset($json['currency']));

    $healthError=$curlError?:($hasExplicitError?(string)$json['error']:(!$ok?'Beklenmeyen sağlayıcı cevabı.':null));
    if($trackTelemetry){
        moni_record_provider_health($db instanceof PDO?$db:null,(int)($provider['id']??0),$operation,$ok,$latency,$http,$healthError);
        if($db instanceof PDO && function_exists('moni_log_provider_request'))moni_log_provider_request($db,(int)($provider['id']??0),$operation,$payload,$raw,$http,$latency,$ok,$healthError);
    }

    // Sipariş oluşturma sırasında timeout/5xx/bozuk cevap belirsizdir: sağlayıcı siparişi almış olabilir.
    // Bu durumda otomatik failover yapılmaz; böylece iki sağlayıcıya aynı sipariş gönderilmez.
    $ambiguous=false;
    $safeToFailover=false;
    if($isAdd && !$ok){
        if($hasExplicitError || ($http>=400 && $http<500)){
            $safeToFailover=true;
        } elseif($curlError!=='' || $http===0 || $http>=500 || ($http>=200 && $http<300 && (!is_array($json) || !isset($json['order'])))){
            $ambiguous=true;
        } else {
            $safeToFailover=true;
        }
    }

    if($curlError!==''){
        return ['success'=>false,'error'=>'Bağlantı hatası: '.$curlError,'http_code'=>$http,'latency_ms'=>$latency,'raw'=>$raw,'safe_to_failover'=>$safeToFailover,'ambiguous'=>$ambiguous];
    }
    if(!is_array($json)){
        return ['success'=>false,'error'=>'Sağlayıcı geçersiz JSON döndürdü.','http_code'=>$http,'latency_ms'=>$latency,'raw'=>$raw,'safe_to_failover'=>$safeToFailover,'ambiguous'=>$ambiguous];
    }
    if($hasExplicitError){
        return ['success'=>false,'error'=>(string)$json['error'],'http_code'=>$http,'latency_ms'=>$latency,'data'=>$json,'raw'=>$raw,'safe_to_failover'=>$safeToFailover,'ambiguous'=>$ambiguous];
    }
    return [
        'success'=>$ok,'data'=>$json,'http_code'=>$http,'latency_ms'=>$latency,'raw'=>$raw,
        'error'=>$ok?null:'Beklenmeyen sağlayıcı cevabı.',
        'safe_to_failover'=>$safeToFailover,'ambiguous'=>$ambiguous
    ];
}

function moni_record_provider_health(?PDO $db,int $providerId,string $operation,bool $success,int $latency,int $http=0,?string $error=null):void{
    if(!$db||$providerId<=0||!moni_table_ready($db,'provider_health')) return;
    try{
        if(moni_table_ready($db,'provider_health_events')){
            $db->prepare("INSERT INTO provider_health_events(provider_id,operation,is_success,latency_ms,http_code,error_message) VALUES(?,?,?,?,?,?)")
               ->execute([$providerId,$operation,$success?1:0,$latency,$http,$error]);
        }
        $st=$db->prepare("SELECT COUNT(*) total,SUM(is_success=1) ok,SUM(is_success=0) fail,AVG(latency_ms) latency FROM provider_health_events WHERE provider_id=? AND created_at>DATE_SUB(NOW(),INTERVAL 24 HOUR)");
        $st->execute([$providerId]);$m=$st->fetch(PDO::FETCH_ASSOC)?:['total'=>0,'ok'=>0,'fail'=>0,'latency'=>0];
        $total=max(1,(int)$m['total']);$successRate=((int)$m['ok']/$total)*100;$avg=(float)$m['latency'];
        $score=max(0,min(100,round($successRate-max(0,$avg-800)/100,2)));
        $db->prepare("INSERT INTO provider_health(provider_id,health_score,success_count,failure_count,consecutive_failures,avg_latency_ms,last_latency_ms,last_success_at,last_failure_at,last_error,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE health_score=VALUES(health_score),success_count=VALUES(success_count),failure_count=VALUES(failure_count),consecutive_failures=IF(?=1,0,consecutive_failures+1),avg_latency_ms=VALUES(avg_latency_ms),last_latency_ms=VALUES(last_latency_ms),last_success_at=IF(?=1,NOW(),last_success_at),last_failure_at=IF(?=0,NOW(),last_failure_at),last_error=VALUES(last_error),updated_at=NOW()")
           ->execute([$providerId,$score,(int)$m['ok'],(int)$m['fail'],$success?0:1,$avg,$latency,$success?date('Y-m-d H:i:s'):null,$success?null:date('Y-m-d H:i:s'),$error,$success?1:0,$success?1:0,$success?1:0]);
    }catch(Throwable $e){ error_log('Provider health: '.$e->getMessage()); }
}

function moni_provider_routes(PDO $db,array $service):array{
    $routes=[];
    $primaryId=(int)($service['api_provider_id']??0);
    $primaryService=(string)($service['api_service_id']??'');
    if($primaryId>0&&$primaryService!=='') $routes[]=['provider_id'=>$primaryId,'api_service_id'=>$primaryService,'priority'=>0];
    $failoverEnabled=moni_plugin_enabled('provider_failover',$db);
    if($failoverEnabled){
        try{$activeProviders=(int)$db->query("SELECT COUNT(*) FROM api_providers WHERE status='active'")->fetchColumn();if($activeProviders<2)$failoverEnabled=false;}catch(Throwable $e){$failoverEnabled=false;}
    }
    if($failoverEnabled&&moni_table_ready($db,'service_provider_routes')){
        $st=$db->prepare("SELECT provider_id,api_service_id,priority FROM service_provider_routes WHERE service_id=? AND is_enabled=1 ORDER BY priority ASC,id ASC");
        $st->execute([(int)$service['id']]);
        foreach($st->fetchAll(PDO::FETCH_ASSOC) as $r){
            if(!array_filter($routes,fn($x)=>(int)$x['provider_id']===(int)$r['provider_id'] && (string)$x['api_service_id']===(string)$r['api_service_id'])) $routes[]=$r;
        }
    }
    // Active provider + bakım penceresi + sağlık skoru ile sırala. Primary priority 0 korunur.
    $out=[];
    foreach($routes as $r){
        $p=moni_provider_by_id($db,(int)$r['provider_id']);
        if(!$p||($p['status']??'')!=='active') continue;
        if(moni_maintenance_reason(null,(int)$p['id'])) continue;
        $h=100;
        if(moni_table_ready($db,'provider_health')){
            $s=$db->prepare("SELECT health_score FROM provider_health WHERE provider_id=?");$s->execute([$p['id']]);$v=$s->fetchColumn();if($v!==false)$h=(float)$v;
        }
        $r['provider']=$p;$r['health_score']=$h;$out[]=$r;
    }
    usort($out,function($a,$b){$pa=(int)($a['priority']??100);$pb=(int)($b['priority']??100);if($pa!==$pb)return $pa<=>$pb;return (float)$b['health_score']<=>(float)$a['health_score'];});
    if(!$failoverEnabled&&count($out)>1)$out=array_slice($out,0,1);
    return $out;
}

function moni_submit_order_to_provider(PDO $db,int $orderId,array $service,string $link,int $quantity,bool $queueMode=false):array{
    if(($reason=moni_maintenance_reason((int)$service['id'],null))) return ['success'=>false,'error'=>$reason,'ambiguous'=>false];
    $routes=moni_provider_routes($db,$service);
    if(!$routes) return ['success'=>false,'error'=>'Aktif sağlayıcı bulunamadı.','ambiguous'=>false];

    $errors=[];
    foreach($routes as $route){
        $p=$route['provider'];
        // Geo hedefi provider kataloğundan primary route için doğrulanmıştır. Alternatif route'un
        // geo desteği ayrıca doğrulanmadığı için geo siparişlerinde kör failover yapılmaz.
        if(!empty($service['geo_target']) && (int)$p['id']!==(int)($service['api_provider_id']??0)) continue;
        $payload=['action'=>'add','service'=>$route['api_service_id'],'link'=>$link,'quantity'=>$quantity];
        if(!empty($service['geo_supported'])&&!empty($service['geo_target'])){
            $targets=function_exists('moni_service_geo_targets')?moni_service_geo_targets($service):[];
            if(!$targets||in_array((string)$service['geo_target'],$targets,true)){
                $param=preg_match('/^[a-zA-Z0-9_]{2,40}$/',(string)($service['geo_target_param']??''))?(string)$service['geo_target_param']:'country';
                $payload[$param]=(string)$service['geo_target'];
            }
        }
        $res=moni_provider_request($p,$payload,'add',60);
        if($res['success']){
            $apiOrder=trim((string)($res['data']['order']??''));
            // Provider başarılı HTTP/JSON dönüp sipariş kimliği vermediyse sonucun gerçekten
            // oluşturulup oluşturulmadığı bilinemez. Yeniden göndermek çift sipariş riski yaratır.
            if($apiOrder===''){
                $msg=$p['name'].': Provider başarılı yanıt verdi ancak sipariş kimliği döndürmedi.';
                $db->prepare("UPDATE orders SET status='pending',api_provider_id=?,api_response=?,admin_note=CONCAT(IFNULL(admin_note,''),?),updated_at=NOW() WHERE id=?")
                   ->execute([$p['id'],$res['raw']??json_encode($res['data']),"\n[".date('d.m.Y H:i')."] ".$msg.' Manuel kontrol gerekli; otomatik tekrar gönderim yapılmadı.',$orderId]);
                return ['success'=>false,'error'=>$msg,'ambiguous'=>true,'manual_review'=>true];
            }
            $db->prepare("UPDATE orders SET api_provider_id=?,api_order_id=?,api_response=?,status='processing',updated_at=NOW() WHERE id=?")
               ->execute([$p['id'],$apiOrder,$res['raw']??json_encode($res['data']),$orderId]);
            return ['success'=>true,'provider_id'=>(int)$p['id'],'api_order_id'=>$apiOrder,'response'=>$res['data'],'failover_used'=>(int)$p['id']!==(int)($service['api_provider_id']??0),'ambiguous'=>false];
        }

        $msg=$p['name'].': '.($res['error']??'Bilinmeyen hata');
        $errors[]=$msg;

        if(!empty($res['ambiguous'])){
            $note="Sağlayıcı sonucu belirsiz; otomatik failover/iade yapılmadı. Manuel kontrol gerekli. ".$msg;
            $db->prepare("UPDATE orders SET status='pending',admin_note=CONCAT(IFNULL(admin_note,''),?),updated_at=NOW() WHERE id=?")
               ->execute(["\n[".date('d.m.Y H:i')."] ".$note,$orderId]);
            return ['success'=>false,'error'=>$msg,'ambiguous'=>true,'manual_review'=>true];
        }

        if(empty($res['safe_to_failover'])) break;
    }

    $errorText=implode(' | ',$errors)?:'Sağlayıcı siparişi oluşturamadı.';
    if($queueMode){
        $db->prepare("UPDATE orders SET admin_note=CONCAT(IFNULL(admin_note,''),?),updated_at=NOW() WHERE id=?")
           ->execute(["\n[Gönderim kuyruğu] ".$errorText,$orderId]);
    }else{
        $db->prepare("UPDATE orders SET status='error',admin_note=CONCAT(IFNULL(admin_note,''),?),updated_at=NOW() WHERE id=?")
           ->execute(["\n".$errorText,$orderId]);
    }
    return ['success'=>false,'error'=>$errorText,'ambiguous'=>false];
}

function moni_provider_status(PDO $db,array $order):array{
    $p=moni_provider_by_id($db,(int)($order['api_provider_id']??0));
    if(!$p||empty($order['api_order_id'])) return ['success'=>false,'error'=>'Sağlayıcı sipariş bilgisi eksik.'];
    $r=moni_provider_request($p,['action'=>'status','order'=>$order['api_order_id']],'status');
    if(!$r['success'])return $r;
    $d=$r['data'];
    $raw=strtolower(trim((string)($d['status']??'')));
    $mapped=function_exists('moni_provider_status_normalize')?moni_provider_status_normalize($db,(int)($order['api_provider_id']??0),$raw):$raw;
    return ['success'=>true,'status'=>$mapped,'raw_status'=>$raw,'start_count'=>$d['start_count']??null,'remains'=>$d['remains']??null,'data'=>$d];
}

function moni_provider_cancel(PDO $db,array $order):array{
    $p=moni_provider_by_id($db,(int)($order['api_provider_id']??0));
    if(!$p||empty($order['api_order_id']))return ['success'=>false,'confirmed'=>false,'queued'=>false,'error'=>'Sağlayıcı siparişi bulunamadı.'];
    $r=moni_provider_request($p,['action'=>'cancel','order'=>$order['api_order_id']],'cancel');
    if(!$r['success'])return $r+['confirmed'=>false,'queued'=>false];

    $accepted=false;$confirmed=false;$queued=false;$error=null;
    $inspect=null;
    $inspect=function($value) use (&$inspect,&$accepted,&$confirmed,&$queued,&$error):void{
        if(is_bool($value)){
            if($value){$accepted=true;$queued=true;}
            return;
        }
        if(is_numeric($value)){
            if((float)$value>0){$accepted=true;$queued=true;}
            return;
        }
        if(is_string($value)){
            $v=strtolower(trim($value));
            if(in_array($v,['cancelled','canceled','refunded'],true)){
                $accepted=true;$confirmed=true;$queued=false;return;
            }
            if(in_array($v,['ok','success','successful','accepted','queued','queue','pending','processing','true','1'],true)){
                $accepted=true;if(!$confirmed)$queued=true;return;
            }
            if(in_array($v,['error','failed','fail','rejected','false','0'],true))$error=$value;
            return;
        }
        if(!is_array($value))return;
        if(isset($value['error']) && trim((string)$value['error'])!==''){$error=(string)$value['error'];return;}
        if(array_key_exists('success',$value))$inspect($value['success']);
        if(array_key_exists('queued',$value) && $value['queued']){$accepted=true;if(!$confirmed)$queued=true;}
        if(isset($value['status']))$inspect($value['status']);
        if(array_key_exists('cancel',$value))$inspect($value['cancel']);
        if(array_key_exists('refund',$value))$inspect($value['refund']);
    };
    $inspect($r['data']);
    if(is_array($r['data'])){
        foreach($r['data'] as $item){if(is_array($item))$inspect($item);}
    }
    if($error!==null){$accepted=false;$confirmed=false;$queued=false;}
    return [
        'success'=>$accepted,
        'confirmed'=>$confirmed,
        'queued'=>$accepted&&!$confirmed,
        'data'=>$r['data'],
        'error'=>$accepted?null:($error?:'Sağlayıcı iptal işlemini açıkça kabul etmedi.')
    ];
}

function moni_provider_refill(PDO $db,array $order):array{
    $p=moni_provider_by_id($db,(int)($order['api_provider_id']??0));
    if(!$p||empty($order['api_order_id']))return ['success'=>false,'error'=>'Sağlayıcı siparişi bulunamadı.'];
    return moni_provider_request($p,['action'=>'refill','order'=>$order['api_order_id']],'refill');
}
