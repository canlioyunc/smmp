<?php
if (defined('MONI_COMPLETION_PACK_LOADED')) return;
define('MONI_COMPLETION_PACK_LOADED', true);

function moni_completion_table(PDO $db,string $table): bool {
    return function_exists('moni_table_ready') ? moni_table_ready($db,$table) : false;
}

function moni_completion_runtime_migrate(PDO $db): void {
    static $done=false; if($done)return; $done=true;
    $revision='2026-10-02.1';
    try{
        if(function_exists('moni_v2_compat_setting') && moni_v2_compat_setting($db,'moni_completion_pack_revision','')===$revision) return;

        if(function_exists('moni_v2_compat_add_column')){
            moni_v2_compat_add_column($db,'users','credit_due_days','int NOT NULL DEFAULT 7');
            moni_v2_compat_add_column($db,'users','credit_due_at','datetime NULL');
            moni_v2_compat_add_column($db,'users','credit_overdue_since','datetime NULL');
            moni_v2_compat_add_column($db,'users','credit_overdue_notified_at','datetime NULL');
            moni_v2_compat_add_column($db,'child_panels','remote_backup_enabled','tinyint(1) NOT NULL DEFAULT 0');
            moni_v2_compat_add_column($db,'child_panels','remote_backup_url','varchar(500) NULL');
            moni_v2_compat_add_column($db,'child_panels','remote_backup_token','text NULL');
            moni_v2_compat_add_column($db,'child_panels','remote_backup_interval_hours','int NOT NULL DEFAULT 24');
            moni_v2_compat_add_column($db,'child_panels','remote_backup_last_at','datetime NULL');
            moni_v2_compat_add_column($db,'child_panels','remote_backup_last_status','varchar(30) NULL');
            moni_v2_compat_add_column($db,'child_panels','remote_backup_last_error','varchar(1000) NULL');
        }

        foreach([
            "CREATE TABLE IF NOT EXISTS service_tags (id int NOT NULL AUTO_INCREMENT,name varchar(80) NOT NULL,slug varchar(90) NOT NULL,icon varchar(80) NOT NULL DEFAULT 'fa-tag',color varchar(20) NOT NULL DEFAULT '#6d5dfc',sort_order int NOT NULL DEFAULT 0,is_active tinyint(1) NOT NULL DEFAULT 1,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY uq_service_tag_slug(slug),KEY idx_service_tag_active(is_active,sort_order,name)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS service_tag_map (service_id int NOT NULL,tag_id int NOT NULL,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(service_id,tag_id),KEY idx_service_tag_map_tag(tag_id,service_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS same_target_order_guards (id bigint NOT NULL AUTO_INCREMENT,user_id int NOT NULL,service_id int NOT NULL,target_hash char(64) NOT NULL,entity_type enum('order','dripfeed') NOT NULL DEFAULT 'order',entity_id bigint NULL,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY uq_same_target_guard(user_id,service_id,target_hash),KEY idx_same_target_entity(entity_type,entity_id),KEY idx_same_target_created(created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS child_panel_remote_backups (id bigint NOT NULL AUTO_INCREMENT,child_panel_id bigint NOT NULL,status enum('queued','success','failed') NOT NULL DEFAULT 'queued',http_status smallint NULL,payload_sha256 char(64) NULL,error_message varchar(1000) NULL,created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,finished_at datetime NULL,PRIMARY KEY(id),KEY idx_child_backup_panel(child_panel_id,created_at),KEY idx_child_backup_status(status,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        ] as $sql){$db->exec($sql);}

        $p=$db->prepare("INSERT IGNORE INTO plugins(slug,name,description,version,is_enabled,is_core) VALUES(?,?,?,?,?,0)");
        $p->execute(['same_target_concurrency','Aynı Hedefte Eşzamanlı Sipariş Koruması','Aynı servis ve hedefte önceki aktif sipariş tamamlanmadan yeni sipariş açılmasını engeller.','1.0.0',0]);

        $c=$db->prepare("INSERT IGNORE INTO cron_tasks(task_key,name,interval_minutes,batch_size,is_enabled) VALUES(?,?,?,?,?)");
        $c->execute(['postpaid_overdue','Gecikmiş Borç Otomasyonu',30,500,1]);
        $c->execute(['child_panel_remote_backup','Child Panel Uzak Yedekleme',60,50,1]);

        $st=$db->prepare("INSERT IGNORE INTO settings(setting_key,setting_value) VALUES(?,?)");
        foreach([
            'postpaid_default_due_days'=>'7',
            'postpaid_overdue_block_orders'=>'1',
            'postpaid_overdue_notify_user'=>'1',
            'postpaid_overdue_notify_admin'=>'1',
            'service_reviews_require_moderation'=>'0'
        ] as $k=>$v)$st->execute([$k,$v]);

        if(function_exists('moni_v2_compat_set_setting'))moni_v2_compat_set_setting($db,'moni_completion_pack_revision',$revision);
        else updateSetting('moni_completion_pack_revision',$revision);
    }catch(Throwable $e){
        error_log('Moni Completion Pack migration: '.$e->getMessage());
        $GLOBALS['moni_completion_pack_migration_error']=$e->getMessage();
    }
}

/* ------------------------- Service tags / smart filters ------------------------- */
function moni_service_tags_all(PDO $db,bool $activeOnly=true): array {
    if(!moni_completion_table($db,'service_tags'))return [];
    try{$sql="SELECT * FROM service_tags".($activeOnly?" WHERE is_active=1":"")." ORDER BY sort_order,name,id";return $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){return [];}
}
function moni_service_tags_map(PDO $db,array $serviceIds): array {
    $ids=array_values(array_unique(array_filter(array_map('intval',$serviceIds),fn($x)=>$x>0)));if(!$ids||!moni_completion_table($db,'service_tags')||!moni_completion_table($db,'service_tag_map'))return [];
    try{$ph=implode(',',array_fill(0,count($ids),'?'));$q=$db->prepare("SELECT m.service_id,t.id,t.name,t.slug,t.icon,t.color FROM service_tag_map m JOIN service_tags t ON t.id=m.tag_id AND t.is_active=1 WHERE m.service_id IN ($ph) ORDER BY t.sort_order,t.name");$q->execute($ids);$out=[];foreach($q->fetchAll(PDO::FETCH_ASSOC) as $r)$out[(int)$r['service_id']][]=['id'=>(int)$r['id'],'name'=>$r['name'],'slug'=>$r['slug'],'icon'=>$r['icon'],'color'=>$r['color']];return $out;}catch(Throwable $e){return [];}
}
function moni_service_tags_attach(PDO $db,array &$rows): void {$map=moni_service_tags_map($db,array_column($rows,'id'));foreach($rows as &$r){$tags=$map[(int)($r['id']??0)]??[];$r['tags']=$tags;$r['service_tags']=$tags;}unset($r);}
function moni_service_has_tag(PDO $db,int $serviceId,string $slug): bool {
    if($serviceId<=0||$slug===''||!moni_completion_table($db,'service_tag_map'))return false;
    try{$q=$db->prepare("SELECT 1 FROM service_tag_map m JOIN service_tags t ON t.id=m.tag_id WHERE m.service_id=? AND t.slug=? AND t.is_active=1 LIMIT 1");$q->execute([$serviceId,$slug]);return (bool)$q->fetchColumn();}catch(Throwable $e){return false;}
}

/* ------------------------- Service schedule meta ------------------------- */
function moni_service_schedule_meta(PDO $db,int $serviceId): array {
    if(!function_exists('moni_service_schedule_check'))return ['open'=>true,'label'=>'7/24 açık','next'=>''];
    $check=moni_service_schedule_check($db,$serviceId);
    if(!empty($check['open']))return ['open'=>true,'label'=>'Şu anda açık','next'=>''];
    if(!moni_completion_table($db,'service_working_hours'))return ['open'=>false,'label'=>'Şu anda kapalı','next'=>''];
    try{
        $q=$db->prepare("SELECT day_of_week,start_time,end_time,is_closed FROM service_working_hours WHERE service_id=? ORDER BY day_of_week,start_time");$q->execute([$serviceId]);$rows=$q->fetchAll(PDO::FETCH_ASSOC);if(!$rows)return ['open'=>true,'label'=>'7/24 açık','next'=>''];
        $tz=(string)getSetting('timezone','Europe/Istanbul');try{$now=new DateTimeImmutable('now',new DateTimeZone($tz));}catch(Throwable $e){$now=new DateTimeImmutable();}
        $names=[1=>'Pazartesi',2=>'Salı',3=>'Çarşamba',4=>'Perşembe',5=>'Cuma',6=>'Cumartesi',7=>'Pazar'];
        for($add=0;$add<8;$add++){
            $d=$now->modify('+'.$add.' day');$dow=(int)$d->format('N');
            foreach($rows as $r){if((int)$r['day_of_week']!==$dow||!empty($r['is_closed']))continue;$start=substr((string)$r['start_time'],0,5);if($add===0&&$start<=$now->format('H:i'))continue;$next=($add===0?'Bugün':($add===1?'Yarın':$names[$dow])).' '.$start;return ['open'=>false,'label'=>'Şu anda kapalı','next'=>$next,'error'=>$check['error']??''];}
        }
    }catch(Throwable $e){}
    return ['open'=>false,'label'=>'Şu anda kapalı','next'=>'','error'=>$check['error']??''];
}
function moni_service_schedule_attach(PDO $db,array &$rows): void {
    if(!$rows)return;$ids=array_values(array_unique(array_filter(array_map('intval',array_column($rows,'id')),fn($x)=>$x>0)));$map=[];
    if($ids&&moni_completion_table($db,'service_working_hours')){try{$ph=implode(',',array_fill(0,count($ids),'?'));$q=$db->prepare("SELECT service_id,day_of_week,start_time,end_time,is_closed FROM service_working_hours WHERE service_id IN ($ph) ORDER BY service_id,day_of_week,start_time");$q->execute($ids);foreach($q->fetchAll(PDO::FETCH_ASSOC) as $x)$map[(int)$x['service_id']][]=$x;}catch(Throwable $e){$map=[];}}
    $tz=(string)getSetting('timezone','Europe/Istanbul');try{$now=new DateTimeImmutable('now',new DateTimeZone($tz));}catch(Throwable $e){$now=new DateTimeImmutable();}$names=[1=>'Pazartesi',2=>'Salı',3=>'Çarşamba',4=>'Perşembe',5=>'Cuma',6=>'Cumartesi',7=>'Pazar'];$today=(int)$now->format('N');$time=$now->format('H:i:s');
    foreach($rows as &$r){$sid=(int)($r['id']??0);$hours=$map[$sid]??[];$m=['open'=>true,'label'=>'7/24 açık','next'=>''];if($hours){$open=false;foreach($hours as $h){if((int)$h['day_of_week']!==$today||!empty($h['is_closed']))continue;$a=(string)$h['start_time'];$b=(string)$h['end_time'];if(($a<=$b&&$time>=$a&&$time<=$b)||($a>$b&&($time>=$a||$time<=$b))){$open=true;break;}}if($open)$m=['open'=>true,'label'=>'Şu anda açık','next'=>''];else{$next='';for($add=0;$add<8&&$next==='';$add++){$d=$now->modify('+'.$add.' day');$dow=(int)$d->format('N');foreach($hours as $h){if((int)$h['day_of_week']!==$dow||!empty($h['is_closed']))continue;$start=substr((string)$h['start_time'],0,5);if($add===0&&$start<=$now->format('H:i'))continue;$next=($add===0?'Bugün':($add===1?'Yarın':$names[$dow])).' '.$start;break;}}$m=['open'=>false,'label'=>'Şu anda kapalı','next'=>$next];}}
        $r['schedule_meta']=$m;$r['schedule_open']=!empty($m['open']);$r['schedule_label']=(string)$m['label'];$r['schedule_next']=(string)$m['next'];
    }unset($r);
}

/* ------------------------- Same-target concurrent order guard ------------------------- */
function moni_same_target_guard_enabled(PDO $db): bool {
    $enabled=function_exists('moni_plugin_enabled')?moni_plugin_enabled('same_target_concurrency',$db):false;
    if(!$enabled && (string)getSetting('demo_mode','0')==='1')$enabled=true;
    return $enabled;
}
function moni_same_target_hash(string $target): string {
    $v=trim($target);if(function_exists('moni_social_target_is_username')&&moni_social_target_is_username($v))$v=ltrim($v,'@');
    elseif(preg_match('#^https?://#i',$v)){$u=@parse_url($v);if($u&&!empty($u['host'])){$scheme=strtolower((string)($u['scheme']??'https'));$host=strtolower((string)$u['host']);$path=rtrim((string)($u['path']??''),'/');$query=isset($u['query'])?'?'.$u['query']:'';$v=$scheme.'://'.$host.$path.$query;}}
    return hash('sha256',mb_strtolower($v,'UTF-8'));
}
function moni_same_target_guard_acquire(PDO $db,int $userId,int $serviceId,string $target): array {
    if(!moni_same_target_guard_enabled($db)||!moni_completion_table($db,'same_target_order_guards'))return ['ok'=>true,'guard_id'=>null];
    $hash=moni_same_target_hash($target);
    try{
        // Stale guardları yeni denemeden önce temizle. entity_id henüz bağlanmamış eski yarım kayıtlar da 10 dk sonra kalkar.
        $db->prepare("DELETE g FROM same_target_order_guards g LEFT JOIN orders o ON g.entity_type='order' AND o.id=g.entity_id LEFT JOIN orders_dripfeed d ON g.entity_type='dripfeed' AND d.id=g.entity_id WHERE g.user_id=? AND g.service_id=? AND g.target_hash=? AND ((g.entity_type='order' AND g.entity_id IS NOT NULL AND (o.id IS NULL OR o.status NOT IN('pending','processing','in_progress'))) OR (g.entity_type='dripfeed' AND g.entity_id IS NOT NULL AND (d.id IS NULL OR d.status NOT IN('active','paused'))) OR (g.entity_id IS NULL AND g.created_at<DATE_SUB(NOW(),INTERVAL 10 MINUTE)))")->execute([$userId,$serviceId,$hash]);
        $db->prepare("INSERT INTO same_target_order_guards(user_id,service_id,target_hash) VALUES(?,?,?)")->execute([$userId,$serviceId,$hash]);
        return ['ok'=>true,'guard_id'=>(int)$db->lastInsertId(),'target_hash'=>$hash];
    }catch(PDOException $e){
        if((string)$e->getCode()==='23000'){
            $q=$db->prepare("SELECT entity_type,entity_id FROM same_target_order_guards WHERE user_id=? AND service_id=? AND target_hash=? LIMIT 1");$q->execute([$userId,$serviceId,$hash]);$x=$q->fetch(PDO::FETCH_ASSOC)?:[];$ref=!empty($x['entity_id'])?' #'.(int)$x['entity_id']:'';
            return ['ok'=>false,'error'=>'Bu servis ve hedef için aktif bir siparişiniz'.$ref.' bulunuyor. Önceki işlem tamamlanmadan aynı hedefe yeni sipariş veremezsiniz.'];
        }
        throw $e;
    }
}
function moni_same_target_guard_bind(PDO $db,?int $guardId,string $type,int $entityId): void {if(!$guardId||$entityId<=0)return;try{$db->prepare("UPDATE same_target_order_guards SET entity_type=?,entity_id=?,updated_at=NOW() WHERE id=?")->execute([$type,$entityId,$guardId]);}catch(Throwable $e){}}

/* ------------------------- Postpaid overdue automation ------------------------- */
function moni_user_credit_overdue(PDO $db,int $userId): array {
    try{$q=$db->prepare("SELECT balance,credit_limit,credit_due_at,credit_overdue_since FROM users WHERE id=? LIMIT 1");$q->execute([$userId]);$u=$q->fetch(PDO::FETCH_ASSOC);if(!$u)return ['overdue'=>false];$debt=max(0,-(float)$u['balance']);$due=$u['credit_due_at']??null;$over=$debt>0&&$due&&strtotime($due)<time();return ['overdue'=>$over,'debt'=>$debt,'due_at'=>$due,'overdue_since'=>$u['credit_overdue_since']??null];}catch(Throwable $e){return ['overdue'=>false];}
}
function moni_postpaid_after_debit(PDO $db,int $userId): void {
    try{$q=$db->prepare("SELECT balance,credit_limit,COALESCE(NULLIF(credit_due_days,0),?) due_days,credit_due_at FROM users WHERE id=? FOR UPDATE");$q->execute([max(1,(int)getSetting('postpaid_default_due_days','7')),$userId]);$u=$q->fetch(PDO::FETCH_ASSOC);if(!$u)return;if((float)$u['balance']<0&&(float)$u['credit_limit']>0&&empty($u['credit_due_at'])){$days=max(1,min(365,(int)$u['due_days']));$db->prepare("UPDATE users SET credit_due_at=DATE_ADD(NOW(),INTERVAL ? DAY),credit_overdue_since=NULL,credit_overdue_notified_at=NULL WHERE id=?")->execute([$days,$userId]);}}catch(Throwable $e){}
}
function moni_process_postpaid_overdue(PDO $db,int $batch=500): array {
    $batch=max(1,min(5000,$batch));$n=0;$overdue=0;$cleared=0;
    try{
        // Borcu kapanan hesapların vadelerini sıfırla.
        $cleared=(int)$db->exec("UPDATE users SET credit_due_at=NULL,credit_overdue_since=NULL,credit_overdue_notified_at=NULL WHERE balance>=0 AND (credit_due_at IS NOT NULL OR credit_overdue_since IS NOT NULL)");
        // Negatif bakiyesi olup vadesi henüz oluşmamış hesaplara vade ver.
        $default=max(1,min(365,(int)getSetting('postpaid_default_due_days','7')));
        $db->exec("UPDATE users SET credit_due_at=DATE_ADD(NOW(),INTERVAL COALESCE(NULLIF(credit_due_days,0),{$default}) DAY) WHERE balance<0 AND credit_limit>0 AND credit_due_at IS NULL");
        $q=$db->query("SELECT id,username,email,balance,credit_due_at,credit_overdue_since,credit_overdue_notified_at FROM users WHERE balance<0 AND credit_limit>0 AND credit_due_at<NOW() ORDER BY COALESCE(credit_overdue_notified_at,'1970-01-01') ASC,id LIMIT {$batch}");
        foreach($q->fetchAll(PDO::FETCH_ASSOC) as $u){$n++;$overdue++;$uid=(int)$u['id'];$debt=abs((float)$u['balance']);$db->prepare("UPDATE users SET credit_overdue_since=COALESCE(credit_overdue_since,NOW()) WHERE id=?")->execute([$uid]);$notify=empty($u['credit_overdue_notified_at'])||strtotime((string)$u['credit_overdue_notified_at'])<time()-86400;if(!$notify)continue;
            if((string)getSetting('postpaid_overdue_notify_user','1')==='1'&&function_exists('moni_user_notify'))moni_user_notify($db,$uid,'postpaid_overdue','Vadeli borç süreniz doldu','Ödenmemiş vadeli borcunuz: '.number_format($debt,2).' '.($GLOBALS['siteSettings']['currency']??'TRY').'. Yeni siparişler ödeme yapılana kadar kısıtlanabilir.','/kullanici/add-funds.php','warning');
            if((string)getSetting('postpaid_overdue_notify_admin','1')==='1'&&function_exists('moni_admin_notify'))moni_admin_notify($db,'postpaid_overdue','Gecikmiş bayi borcu',($u['username']?:('#'.$uid)).' hesabının '.number_format($debt,2).' tutarında gecikmiş borcu var.','/admin/postpaid-debts.php','warning');
            $db->prepare("UPDATE users SET credit_overdue_notified_at=NOW() WHERE id=?")->execute([$uid]);
        }
    }catch(Throwable $e){return ['status'=>'error','processed'=>$n,'message'=>$e->getMessage()];}
    return ['processed'=>$n,'message'=>"{$overdue} gecikmiş hesap kontrol edildi; {$cleared} kapanmış borç temizlendi."];
}

/* ------------------------- Child panel remote backup ------------------------- */
function moni_child_remote_url_ok(string $url): bool {
    if(!filter_var($url,FILTER_VALIDATE_URL)||strtolower((string)parse_url($url,PHP_URL_SCHEME))!=='https')return false;
    $host=strtolower((string)parse_url($url,PHP_URL_HOST));if($host==='')return false;
    if(function_exists('moni_resolve_public_host') && moni_resolve_public_host($host)===null)return false;
    return true;
}
function moni_child_remote_backup(PDO $db,array $panel): array {
    $pid=(int)($panel['id']??0);$url=trim((string)($panel['remote_backup_url']??''));if($pid<=0||empty($panel['remote_backup_enabled']))return ['ok'=>false,'error'=>'Uzak yedekleme pasif.'];if(!moni_child_remote_url_ok($url))return ['ok'=>false,'error'=>'Uzak yedek URL yalnız herkese açık HTTPS adresi olabilir.'];if(!function_exists('curl_init'))return ['ok'=>false,'error'=>'cURL kullanılamıyor.'];
    $token=(string)($panel['remote_backup_token']??'');if($token!==''&&function_exists('moni_decrypt_secret'))$token=moni_decrypt_secret($token);
    $payload=['schema'=>'moni-child-panel-backup/v1','generated_at'=>date(DATE_ATOM),'panel'=>['id'=>$pid,'panel_name'=>$panel['panel_name']??'','domain'=>$panel['domain']??'','logo_url'=>$panel['logo_url']??null,'primary_color'=>$panel['primary_color']??null,'markup_percent'=>(float)($panel['markup_percent']??0),'status'=>$panel['status']??'','expires_at'=>$panel['expires_at']??null,'allow_custom_smtp'=>(int)($panel['allow_custom_smtp']??0),'allow_custom_payments'=>(int)($panel['allow_custom_payments']??0)]];
    // Panelin kendi müşteri/ödeme yapılandırmasının taşınabilir bir özeti.
    foreach(['child_payment_methods','child_bank_accounts'] as $t){if(moni_completion_table($db,$t)){try{$q=$db->prepare("SELECT * FROM `$t` WHERE child_panel_id=? ORDER BY id");$q->execute([$pid]);$rows=$q->fetchAll(PDO::FETCH_ASSOC);foreach($rows as &$r){foreach(array_keys($r) as $k)if(str_contains(strtolower($k),'secret')||str_contains(strtolower($k),'password')||str_contains(strtolower($k),'api_key'))$r[$k]='[redacted]';}unset($r);$payload[$t]=$rows;}catch(Throwable $e){}}}
    $json=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);$sha=hash('sha256',$json);$db->prepare("INSERT INTO child_panel_remote_backups(child_panel_id,status,payload_sha256) VALUES(?,'queued',?)")->execute([$pid,$sha]);$bid=(int)$db->lastInsertId();
    $headers=['Content-Type: application/json','X-Moni-Backup-SHA256: '.$sha];if($token!=='')$headers[]='Authorization: Bearer '.$token;
    $host=(string)parse_url($url,PHP_URL_HOST);$port=(int)(parse_url($url,PHP_URL_PORT)?:443);$ip=function_exists('moni_resolve_public_host')?moni_resolve_public_host($host):null;
    $ch=curl_init($url);$opts=[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$json,CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>20,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_HTTPHEADER=>$headers,CURLOPT_USERAGENT=>'MONI-ChildBackup/1.0'];if($ip)$opts[CURLOPT_RESOLVE]=[$host.':'.$port.':'.$ip];curl_setopt_array($ch,$opts);$raw=curl_exec($ch);$err=curl_error($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);$ok=$err===''&&$http>=200&&$http<300;
    $msg=$ok?null:($err!==''?$err:'HTTP '.$http);$db->prepare("UPDATE child_panel_remote_backups SET status=?,http_status=?,error_message=?,finished_at=NOW() WHERE id=?")->execute([$ok?'success':'failed',$http,$msg,$bid]);$db->prepare("UPDATE child_panels SET remote_backup_last_at=NOW(),remote_backup_last_status=?,remote_backup_last_error=?,updated_at=updated_at WHERE id=?")->execute([$ok?'success':'failed',$msg,$pid]);return ['ok'=>$ok,'http_status'=>$http,'error'=>$msg,'backup_id'=>$bid];
}
function moni_process_child_remote_backups(PDO $db,int $batch=50): array {
    if(!moni_completion_table($db,'child_panel_remote_backups'))return ['processed'=>0,'message'=>'Uzak yedek altyapısı hazır değil.'];$batch=max(1,min(500,$batch));$q=$db->query("SELECT * FROM child_panels WHERE remote_backup_enabled=1 AND status IN('active','pending') AND remote_backup_url IS NOT NULL AND remote_backup_url<>'' AND (remote_backup_last_at IS NULL OR remote_backup_last_at<=DATE_SUB(NOW(),INTERVAL GREATEST(1,LEAST(168,remote_backup_interval_hours)) HOUR)) ORDER BY COALESCE(remote_backup_last_at,'1970-01-01') ASC LIMIT {$batch}");$n=0;$ok=0;foreach($q->fetchAll(PDO::FETCH_ASSOC) as $p){$r=moni_child_remote_backup($db,$p);$n++;if(!empty($r['ok']))$ok++;}return ['processed'=>$n,'message'=>"{$n} child panel uzak yedeği işlendi; {$ok} başarılı."];
}

