<?php
/**
 * Moni Ops Pro
 * - Kâr Marjı Isı Haritası
 * - Servis Klonlama
 * - Servis Açıklama Şablonları
 * - Muhasebe Entegrasyon Merkezi
 * - Cron Kaçırma Alarmı
 */
if (defined('MONI_OPS_PRO_LOADED')) return;
define('MONI_OPS_PRO_LOADED', true);

function moni_ops_pro_runtime_migrate(PDO $db): void {
    static $done=false; if($done)return; $done=true;
    $revision='2026-09-29.1';
    try{
        $ready=function_exists('moni_v2_compat_setting')
            && moni_v2_compat_setting($db,'moni_ops_pro_schema_revision','')===$revision
            && function_exists('moni_table_ready')
            && moni_table_ready($db,'service_description_templates')
            && moni_table_ready($db,'accounting_integrations')
            && moni_table_ready($db,'accounting_sync_queue')
            && moni_table_ready($db,'cron_watchdog_state')
            && moni_table_ready($db,'service_clone_logs');
        if($ready){
            try{$q=$db->query("SELECT COUNT(*) FROM cron_tasks WHERE task_key IN('accounting_sync','cron_watchdog')");$ready=(int)$q->fetchColumn()===2;}catch(Throwable $e){$ready=false;}
        }
        if($ready)return;

        $ddl=[];
        $ddl[]="CREATE TABLE IF NOT EXISTS service_description_templates (
            id bigint NOT NULL AUTO_INCREMENT,
            name varchar(190) NOT NULL,
            category_id int NULL,
            content mediumtext NOT NULL,
            is_active tinyint(1) NOT NULL DEFAULT 1,
            sort_order int NOT NULL DEFAULT 0,
            created_by int NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY(id),KEY idx_desc_tpl_active(is_active,sort_order,id),KEY idx_desc_tpl_category(category_id,is_active)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS service_clone_logs (
            id bigint NOT NULL AUTO_INCREMENT,
            source_service_id int NOT NULL,
            cloned_service_id int NOT NULL,
            cloned_by int NULL,
            copied_relations varchar(500) NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(id),KEY idx_clone_source(source_service_id,created_at),KEY idx_clone_target(cloned_service_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS accounting_integrations (
            id bigint NOT NULL AUTO_INCREMENT,
            name varchar(190) NOT NULL,
            adapter varchar(50) NOT NULL DEFAULT 'generic_rest',
            base_url varchar(800) NOT NULL,
            auth_mode enum('none','bearer','api_key','basic') NOT NULL DEFAULT 'bearer',
            auth_header varchar(120) NULL,
            api_token text NULL,
            api_username text NULL,
            api_password text NULL,
            company_code varchar(190) NULL,
            event_types varchar(255) NOT NULL DEFAULT 'deposit,order,refund',
            allow_private_network tinyint(1) NOT NULL DEFAULT 0,
            is_enabled tinyint(1) NOT NULL DEFAULT 1,
            auto_sync tinyint(1) NOT NULL DEFAULT 1,
            last_transaction_id int NOT NULL DEFAULT 0,
            last_sync_at datetime NULL,
            last_success_at datetime NULL,
            last_error varchar(1000) NULL,
            created_by int NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY(id),KEY idx_accounting_enabled(is_enabled,auto_sync,id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS accounting_sync_queue (
            id bigint NOT NULL AUTO_INCREMENT,
            integration_id bigint NOT NULL,
            transaction_id int NOT NULL,
            event_type varchar(80) NOT NULL,
            payload_json mediumtext NULL,
            status enum('pending','processing','sent','failed','ignored') NOT NULL DEFAULT 'pending',
            attempts int NOT NULL DEFAULT 0,
            next_attempt_at datetime NULL,
            locked_until datetime NULL,
            http_code int NULL,
            external_id varchar(255) NULL,
            response_body text NULL,
            last_error varchar(1000) NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            sent_at datetime NULL,
            PRIMARY KEY(id),UNIQUE KEY uq_accounting_tx(integration_id,transaction_id),KEY idx_accounting_queue(status,next_attempt_at,id),KEY idx_accounting_integration(integration_id,status,id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $ddl[]="CREATE TABLE IF NOT EXISTS cron_watchdog_state (
            task_key varchar(100) NOT NULL,
            is_missed tinyint(1) NOT NULL DEFAULT 0,
            missed_since datetime NULL,
            last_alert_at datetime NULL,
            last_recovered_at datetime NULL,
            last_message varchar(1000) NULL,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY(task_key),KEY idx_watchdog_missed(is_missed,last_alert_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        foreach($ddl as $sql)$db->exec($sql);

        $cs=$db->prepare("INSERT IGNORE INTO cron_tasks(task_key,name,interval_minutes,batch_size,is_enabled) VALUES(?,?,?,?,?)");
        foreach([
            ['accounting_sync','Muhasebe Programı Entegrasyon Senkronu',5,100,1],
            ['cron_watchdog','Cron Kaçırma ve Görev Sağlığı Kontrolü',5,100,1],
        ] as $t)$cs->execute($t);

        $st=$db->prepare("INSERT IGNORE INTO settings(setting_key,setting_value) VALUES(?,?)");
        foreach([
            'profit_heatmap_critical_threshold'=>'10',
            'profit_heatmap_healthy_threshold'=>'25',
            'accounting_sync_max_attempts'=>'5',
            'cron_watchdog_enabled'=>'1',
            'cron_watchdog_main_threshold_minutes'=>'3',
            'cron_watchdog_task_grace_minutes'=>'5',
            'cron_watchdog_repeat_minutes'=>'60',
            'cron_watchdog_email_enabled'=>'0',
            'cron_watchdog_last_web_check_at'=>'',
            'cron_main_last_heartbeat_at'=>'',
        ] as $k=>$v)$st->execute([$k,$v]);

        if(function_exists('moni_v2_compat_set_setting')) moni_v2_compat_set_setting($db,'moni_ops_pro_schema_revision',$revision);
        else updateSetting('moni_ops_pro_schema_revision',$revision);
    }catch(Throwable $e){
        error_log('Moni Ops Pro migration failed: '.$e->getMessage());
        $GLOBALS['moni_ops_pro_migration_error']=$e->getMessage();
    }
}

function moni_service_margin_metrics(array $service): array {
    $sale=max(0.0,(float)($service['price_per_1000']??0));
    $cost=max(0.0,(float)($service['cost_per_1000']??0));
    $profit=$sale-$cost;
    $margin=$sale>0?($profit/$sale*100):($cost>0?-100.0:0.0);
    $markup=$cost>0?($profit/$cost*100):($sale>0?100.0:0.0);
    return ['sale'=>$sale,'cost'=>$cost,'profit'=>$profit,'margin_pct'=>$margin,'markup_pct'=>$markup];
}

function moni_profit_heat_level(array $service): string {
    $m=moni_service_margin_metrics($service);$margin=(float)$m['margin_pct'];
    $critical=max(0,(float)getSetting('profit_heatmap_critical_threshold','10'));
    $healthy=max($critical,(float)getSetting('profit_heatmap_healthy_threshold','25'));
    if($m['profit']<0)return 'loss';
    if($margin<$critical)return 'critical';
    if($margin<$healthy)return 'watch';
    return 'healthy';
}

function moni_clone_table_rows(PDO $db,string $table,int $sourceId,int $targetId,int $adminId=0): int {
    if(!function_exists('moni_table_ready')||!moni_table_ready($db,$table))return 0;
    if(!preg_match('/^[a-z0-9_]+$/i',$table))return 0;
    try{
        $cols=$db->query("SHOW COLUMNS FROM `{$table}`")->fetchAll(PDO::FETCH_ASSOC);if(!$cols)return 0;
        $names=array_column($cols,'Field');if(!in_array('service_id',$names,true))return 0;
        $skip=['id','created_at','updated_at'];$insert=[];$select=[];$params=[];
        foreach($names as $c){
            if(in_array($c,$skip,true))continue;
            $insert[]="`{$c}`";
            if($c==='service_id'){ $select[]='?'; $params[]=$targetId; }
            elseif($c==='created_by'&&$adminId>0){ $select[]='?'; $params[]=$adminId; }
            else $select[]="`{$c}`";
        }
        if(!$insert)return 0;
        $params[]=$sourceId;
        $sql="INSERT INTO `{$table}` (".implode(',',$insert).") SELECT ".implode(',',$select)." FROM `{$table}` WHERE service_id=?";
        $s=$db->prepare($sql);$s->execute($params);return $s->rowCount();
    }catch(Throwable $e){error_log('Clone relation '.$table.': '.$e->getMessage());return 0;}
}

function moni_clone_service(PDO $db,int $serviceId,int $adminId): array {
    if($serviceId<=0)return ['ok'=>false,'error'=>'Geçersiz servis.'];
    try{
        $q=$db->prepare("SELECT * FROM services WHERE id=? LIMIT 1");$q->execute([$serviceId]);$src=$q->fetch(PDO::FETCH_ASSOC);if(!$src)return ['ok'=>false,'error'=>'Servis bulunamadı.'];
        $cols=$db->query("SHOW COLUMNS FROM services")->fetchAll(PDO::FETCH_ASSOC);$names=array_column($cols,'Field');
        $skip=['id','created_at','updated_at','total_orders','deleted_at','deleted_by'];$insert=[];$vals=[];$params=[];
        foreach($names as $c){if(in_array($c,$skip,true))continue;$insert[]="`{$c}`";$vals[]='?';$v=$src[$c]??null;if($c==='name')$v=mb_substr((string)$v.' (Kopya)',0,500,'UTF-8');if($c==='status')$v='inactive';$params[]=$v;}
        $db->beginTransaction();
        $s=$db->prepare("INSERT INTO services (".implode(',',$insert).") VALUES (".implode(',',$vals).")");$s->execute($params);$newId=(int)$db->lastInsertId();
        $copied=[];
        foreach(['service_provider_routes','service_working_hours','service_price_tiers','group_service_visibility','service_target_rules'] as $table){$n=moni_clone_table_rows($db,$table,$serviceId,$newId,$adminId);if($n>0)$copied[]=$table.':'.$n;}
        if(function_exists('moni_table_ready')&&moni_table_ready($db,'service_target_policies')){
            $tp=$db->prepare("INSERT INTO service_target_policies(service_id,mode,block_message,updated_by,created_at,updated_at) SELECT ?,mode,block_message,?,NOW(),NOW() FROM service_target_policies WHERE service_id=? ON DUPLICATE KEY UPDATE mode=VALUES(mode),block_message=VALUES(block_message),updated_by=VALUES(updated_by),updated_at=NOW()");$tp->execute([$newId,$adminId,$serviceId]);if($tp->rowCount())$copied[]='service_target_policies:1';
        }
        if(function_exists('moni_table_ready')&&moni_table_ready($db,'profit_margin_policies')){
            $p=$db->prepare("INSERT INTO profit_margin_policies(scope_type,scope_id,margin_type,margin_value,is_active,created_at,updated_at) SELECT 'service',?,margin_type,margin_value,is_active,NOW(),NOW() FROM profit_margin_policies WHERE scope_type='service' AND scope_id=?");$p->execute([$newId,$serviceId]);if($p->rowCount())$copied[]='profit_margin_policies:'.$p->rowCount();
        }
        if(function_exists('moni_table_ready')&&moni_table_ready($db,'service_clone_logs'))$db->prepare("INSERT INTO service_clone_logs(source_service_id,cloned_service_id,cloned_by,copied_relations) VALUES(?,?,?,?)")->execute([$serviceId,$newId,$adminId,implode(',',$copied)]);
        $db->commit();
        return ['ok'=>true,'service_id'=>$newId,'relations'=>$copied];
    }catch(Throwable $e){if($db->inTransaction())$db->rollBack();return ['ok'=>false,'error'=>$e->getMessage()];}
}

function moni_description_template_render(string $content,array $service): string {
    $map=[
        '{{service_name}}'=>(string)($service['name']??''),
        '{{min}}'=>(string)($service['min_quantity']??$service['min']??''),
        '{{max}}'=>(string)($service['max_quantity']??$service['max']??''),
        '{{refill_days}}'=>(string)($service['refill_days']??''),
        '{{price}}'=>(string)($service['price_per_1000']??$service['price']??''),
    ];
    return strtr($content,$map);
}

function moni_accounting_event_type(string $transactionType): string {
    return [
        'deposit'=>'payment_received','order'=>'sale','refund'=>'refund','referral_bonus'=>'bonus','bonus'=>'bonus',
        'admin_add'=>'balance_adjustment','admin_remove'=>'balance_adjustment','coupon'=>'coupon'
    ][$transactionType]??'transaction';
}

function moni_accounting_payload(PDO $db,array $tx): array {
    $user=[];try{$u=$db->prepare("SELECT id,username,email,first_name,last_name,phone FROM users WHERE id=? LIMIT 1");$u->execute([(int)$tx['user_id']]);$user=$u->fetch(PDO::FETCH_ASSOC)?:[];}catch(Throwable $e){}
    return [
        'source'=>'moni','version'=>defined('MONI_VERSION')?MONI_VERSION:'v2','event'=>moni_accounting_event_type((string)$tx['type']),
        'transaction'=>[
            'id'=>(int)$tx['id'],'type'=>(string)$tx['type'],'amount'=>(float)$tx['amount'],'balance_after'=>(float)$tx['balance_after'],
            'status'=>(string)$tx['status'],'description'=>(string)($tx['description']??''),'created_at'=>(string)$tx['created_at'],
            'currency'=>(string)getSetting('currency','TRY')
        ],
        'customer'=>[
            'id'=>(int)($user['id']??0),'username'=>(string)($user['username']??''),'email'=>(string)($user['email']??''),
            'first_name'=>(string)($user['first_name']??''),'last_name'=>(string)($user['last_name']??''),'phone'=>(string)($user['phone']??'')
        ],
        'site'=>['name'=>(string)getSetting('site_name',''),'url'=>defined('SITE_URL')?SITE_URL:'']
    ];
}

function moni_accounting_url_allowed(string $url,bool $allowPrivate=false): bool {
    $p=parse_url($url);if(!$p||!in_array(strtolower((string)($p['scheme']??'')),['http','https'],true)||empty($p['host']))return false;
    if($allowPrivate)return true;
    if(function_exists('moni_resolve_public_host'))return moni_resolve_public_host((string)$p['host'])!==null;
    $host=(string)$p['host'];if(filter_var($host,FILTER_VALIDATE_IP))return (bool)filter_var($host,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE);
    return true;
}

function moni_accounting_http_send(array $integration,array $payload): array {
    $url=trim((string)($integration['base_url']??''));$allowPrivate=!empty($integration['allow_private_network']);
    if(!moni_accounting_url_allowed($url,$allowPrivate))return ['ok'=>false,'http'=>0,'error'=>'Güvensiz veya geçersiz entegrasyon URL’si.'];
    if(!function_exists('curl_init'))return ['ok'=>false,'http'=>0,'error'=>'cURL eklentisi bulunamadı.'];
    $headers=['Content-Type: application/json','Accept: application/json','User-Agent: Moni-Accounting/'.(defined('MONI_VERSION')?MONI_VERSION:'v2')];
    $mode=(string)($integration['auth_mode']??'none');$token=moni_decrypt_secret((string)($integration['api_token']??''));$user=moni_decrypt_secret((string)($integration['api_username']??''));$pass=moni_decrypt_secret((string)($integration['api_password']??''));
    if($mode==='bearer'&&$token!=='')$headers[]='Authorization: Bearer '.$token;
    elseif($mode==='api_key'&&$token!=='')$headers[]=(trim((string)($integration['auth_header']??''))?:'X-API-Key').': '.$token;
    elseif($mode==='basic'&&($user!==''||$pass!==''))$headers[]='Authorization: Basic '.base64_encode($user.':'.$pass);
    if(!empty($integration['company_code']))$headers[]='X-Company-Code: '.preg_replace('/[\r\n]+/',' ',(string)$integration['company_code']);
    $json=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);if($json===false)return ['ok'=>false,'http'=>0,'error'=>'JSON oluşturulamadı.'];
    $ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$json,CURLOPT_HTTPHEADER=>$headers,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>30,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
    $raw=curl_exec($ch);$err=curl_error($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
    if($raw===false||$err!=='')return ['ok'=>false,'http'=>$http,'error'=>$err?:'Bağlantı başarısız.'];
    $ok=$http>=200&&$http<300;$data=json_decode((string)$raw,true);$external='';if(is_array($data))$external=(string)($data['id']??$data['document_id']??$data['reference']??'');
    return ['ok'=>$ok,'http'=>$http,'body'=>mb_substr((string)$raw,0,4000,'UTF-8'),'external_id'=>mb_substr($external,0,255,'UTF-8'),'error'=>$ok?'':('HTTP '.$http)];
}

function moni_accounting_enqueue_new(PDO $db,int $batch=250): int {
    if(!function_exists('moni_table_ready')||!moni_table_ready($db,'accounting_integrations')||!moni_table_ready($db,'accounting_sync_queue'))return 0;
    $batch=max(1,min(5000,$batch));$count=0;
    try{$ints=$db->query("SELECT * FROM accounting_integrations WHERE is_enabled=1 AND auto_sync=1 ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){return 0;}
    foreach($ints as $i){
        $last=max(0,(int)$i['last_transaction_id']);$q=$db->prepare("SELECT * FROM transactions WHERE id>? AND status='completed' ORDER BY id ASC LIMIT {$batch}");$q->execute([$last]);$rows=$q->fetchAll(PDO::FETCH_ASSOC);if(!$rows)continue;
        $allowed=array_filter(array_map('trim',explode(',',(string)$i['event_types'])));$maxId=$last;
        $ins=$db->prepare("INSERT IGNORE INTO accounting_sync_queue(integration_id,transaction_id,event_type,payload_json,status,next_attempt_at) VALUES(?,?,?,?, 'pending',NOW())");
        foreach($rows as $tx){$maxId=max($maxId,(int)$tx['id']);if($allowed&&!in_array((string)$tx['type'],$allowed,true))continue;$payload=moni_accounting_payload($db,$tx);$ins->execute([(int)$i['id'],(int)$tx['id'],moni_accounting_event_type((string)$tx['type']),json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);$count+=$ins->rowCount();}
        $db->prepare("UPDATE accounting_integrations SET last_transaction_id=?,last_sync_at=NOW() WHERE id=?")->execute([$maxId,(int)$i['id']]);
    }
    return $count;
}

function moni_accounting_process_queue(PDO $db,int $batch=100): array {
    if(!function_exists('moni_table_ready')||!moni_table_ready($db,'accounting_sync_queue'))return ['processed'=>0,'sent'=>0,'failed'=>0];
    $batch=max(1,min(1000,$batch));$processed=$sent=$failed=0;$maxAttempts=max(1,min(20,(int)getSetting('accounting_sync_max_attempts','5')));
    try{$rows=$db->query("SELECT q.id queue_id,q.integration_id,q.transaction_id,q.event_type,q.payload_json,q.status,q.attempts,q.next_attempt_at,q.locked_until,q.http_code,q.external_id,q.response_body,q.last_error,i.name,i.adapter,i.base_url,i.auth_mode,i.auth_header,i.api_token,i.api_username,i.api_password,i.company_code,i.allow_private_network FROM accounting_sync_queue q JOIN accounting_integrations i ON i.id=q.integration_id WHERE q.status='pending' AND i.is_enabled=1 AND (q.next_attempt_at IS NULL OR q.next_attempt_at<=NOW()) AND (q.locked_until IS NULL OR q.locked_until<NOW()) ORDER BY q.id ASC LIMIT {$batch}")->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){return ['processed'=>0,'sent'=>0,'failed'=>0,'error'=>$e->getMessage()];}
    foreach($rows as $r){
        $claim=$db->prepare("UPDATE accounting_sync_queue SET status='processing',locked_until=DATE_ADD(NOW(),INTERVAL 10 MINUTE),attempts=attempts+1 WHERE id=? AND status='pending' AND (locked_until IS NULL OR locked_until<NOW())");$claim->execute([(int)$r['queue_id']]);if(!$claim->rowCount())continue;$processed++;
        $payload=json_decode((string)$r['payload_json'],true);if(!is_array($payload))$payload=[];
        $res=moni_accounting_http_send($r,$payload);$attempt=(int)$r['attempts']+1;
        if(!empty($res['ok'])){
            $db->prepare("UPDATE accounting_sync_queue SET status='sent',locked_until=NULL,http_code=?,external_id=?,response_body=?,last_error=NULL,sent_at=NOW(),updated_at=NOW() WHERE id=?")->execute([(int)($res['http']??0),(string)($res['external_id']??''),(string)($res['body']??''),(int)$r['queue_id']]);
            $db->prepare("UPDATE accounting_integrations SET last_success_at=NOW(),last_error=NULL WHERE id=?")->execute([(int)$r['integration_id']]);$sent++;
        }else{
            $terminal=$attempt>=$maxAttempts;$delays=[5,15,60,180,360];$delay=$delays[min(max(0,$attempt-1),count($delays)-1)];
            if($terminal)$db->prepare("UPDATE accounting_sync_queue SET status='failed',locked_until=NULL,http_code=?,response_body=?,last_error=?,updated_at=NOW() WHERE id=?")->execute([(int)($res['http']??0),(string)($res['body']??''),mb_substr((string)($res['error']??'Senkron hatası'),0,1000,'UTF-8'),(int)$r['queue_id']]);
            else $db->prepare("UPDATE accounting_sync_queue SET status='pending',locked_until=NULL,http_code=?,response_body=?,last_error=?,next_attempt_at=DATE_ADD(NOW(),INTERVAL ? MINUTE),updated_at=NOW() WHERE id=?")->execute([(int)($res['http']??0),(string)($res['body']??''),mb_substr((string)($res['error']??'Senkron hatası'),0,1000,'UTF-8'),$delay,(int)$r['queue_id']]);
            $db->prepare("UPDATE accounting_integrations SET last_error=? WHERE id=?")->execute([mb_substr((string)($res['error']??'Senkron hatası'),0,1000,'UTF-8'),(int)$r['integration_id']]);$failed++;
        }
    }
    return ['processed'=>$processed,'sent'=>$sent,'failed'=>$failed];
}

function moni_accounting_test(PDO $db,int $integrationId): array {
    $s=$db->prepare("SELECT * FROM accounting_integrations WHERE id=? LIMIT 1");$s->execute([$integrationId]);$i=$s->fetch(PDO::FETCH_ASSOC);if(!$i)return ['ok'=>false,'error'=>'Entegrasyon bulunamadı.'];
    return moni_accounting_http_send($i,['source'=>'moni','event'=>'connection_test','sent_at'=>date('c'),'site'=>['name'=>getSetting('site_name',''),'url'=>defined('SITE_URL')?SITE_URL:'']]);
}

function moni_cron_watchdog_heartbeat(PDO $db): void {
    try{updateSetting('cron_main_last_heartbeat_at',date('Y-m-d H:i:s'));if(function_exists('moni_table_ready')&&moni_table_ready($db,'cron_watchdog_state'))$db->prepare("INSERT INTO cron_watchdog_state(task_key,is_missed,last_recovered_at,last_message) VALUES('__main__',0,NOW(),'Ana cron heartbeat alındı') ON DUPLICATE KEY UPDATE last_recovered_at=IF(is_missed=1,NOW(),last_recovered_at),last_message='Ana cron heartbeat alındı',is_missed=0,updated_at=NOW()")->execute();}catch(Throwable $e){}
}

function moni_cron_watchdog_notify(PDO $db,string $key,string $title,string $message,string $severity='danger'): void {
    if(function_exists('moni_admin_notify'))moni_admin_notify($db,'cron_missed',$title,$message,'/admin/cron-center.php',$severity,false);
    if(getSetting('cron_watchdog_email_enabled','0')==='1'){
        if(!function_exists('sendEmail')){ $mail=__DIR__.'/mail.php'; if(is_file($mail)) require_once $mail; }
        if(function_exists('sendEmail'))try{$admins=$db->query("SELECT email FROM users WHERE role='admin' AND status='active' AND email<>'' LIMIT 20")->fetchAll(PDO::FETCH_COLUMN);foreach($admins as $email)@sendEmail((string)$email,$title,'<p>'.htmlspecialchars($message,ENT_QUOTES,'UTF-8').'</p>');}catch(Throwable $e){}
    }
}

function moni_cron_watchdog_mark(PDO $db,string $key,bool $missed,string $message): bool {
    if(!function_exists('moni_table_ready')||!moni_table_ready($db,'cron_watchdog_state'))return false;
    $s=$db->prepare("SELECT * FROM cron_watchdog_state WHERE task_key=? LIMIT 1");$s->execute([$key]);$old=$s->fetch(PDO::FETCH_ASSOC);$was=!empty($old['is_missed']);
    if($missed){
        $repeat=max(5,(int)getSetting('cron_watchdog_repeat_minutes','60'));$alert=!$was||empty($old['last_alert_at'])||(time()-strtotime((string)$old['last_alert_at']))>=($repeat*60);
        $db->prepare("INSERT INTO cron_watchdog_state(task_key,is_missed,missed_since,last_alert_at,last_message) VALUES(?,1,NOW(),?,?) ON DUPLICATE KEY UPDATE missed_since=IF(is_missed=0 OR missed_since IS NULL,NOW(),missed_since),last_alert_at=VALUES(last_alert_at),last_message=VALUES(last_message),is_missed=1,updated_at=NOW()")->execute([$key,$alert?date('Y-m-d H:i:s'):($old['last_alert_at']??null),mb_substr($message,0,1000,'UTF-8')]);
        return $alert;
    }
    $db->prepare("INSERT INTO cron_watchdog_state(task_key,is_missed,last_recovered_at,last_message) VALUES(?,0,NOW(),?) ON DUPLICATE KEY UPDATE last_recovered_at=IF(is_missed=1,NOW(),last_recovered_at),last_message=VALUES(last_message),is_missed=0,updated_at=NOW()")->execute([$key,mb_substr($message,0,1000,'UTF-8')]);
    return false;
}

function moni_cron_watchdog_check(PDO $db,bool $force=false): array {
    if(getSetting('cron_watchdog_enabled','1')!=='1')return ['missed'=>0,'messages'=>[]];
    $messages=[];$missed=0;$mainThreshold=max(2,min(120,(int)getSetting('cron_watchdog_main_threshold_minutes','3')));$lastMain=trim((string)getSetting('cron_main_last_heartbeat_at',''));
    // İlk kurulum/güncellemede cron henüz bir kez bile çalışmadıysa anında yanlış alarm üretme.
    // İlk web gözlem anını başlangıç kabul et; eşik geçip heartbeat gelmezse sonraki kontrolde alarm ver.
    if($lastMain===''){ $lastMain=date('Y-m-d H:i:s'); updateSetting('cron_main_last_heartbeat_at',$lastMain); }
    $mainLate=time()-strtotime($lastMain)>$mainThreshold*60;
    if($mainLate){$msg=$lastMain===''?'Ana cron heartbeat henüz alınmadı.':'Ana cron son '.$mainThreshold.' dakikadır heartbeat göndermiyor. Son: '.$lastMain;$messages[]=$msg;$missed++;if(moni_cron_watchdog_mark($db,'__main__',true,$msg))moni_cron_watchdog_notify($db,'__main__','Cron çalışması gecikti',$msg,'danger');}
    else moni_cron_watchdog_mark($db,'__main__',false,'Ana cron zamanında çalışıyor.');

    $grace=max(1,min(1440,(int)getSetting('cron_watchdog_task_grace_minutes','5')));
    try{$tasks=$db->query("SELECT * FROM cron_tasks WHERE is_enabled=1 AND task_key<>'cron_watchdog'")->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){$tasks=[];}
    foreach($tasks as $t){$key=(string)$t['task_key'];$interval=max(1,(int)$t['interval_minutes']);$reference=$t['last_finished_at']?:$t['last_started_at'];$late=false;
        if(!empty($t['next_run_at'])&&strtotime((string)$t['next_run_at'])<time()-$grace*60)$late=true;
        elseif($reference&&time()-strtotime((string)$reference)>($interval+$grace)*60*2)$late=true;
        if($late){$msg=(string)$t['name'].' görevi beklenen zamanda çalışmadı. Son çalışma: '.($reference?:'yok').', aralık: '.$interval.' dk.';$messages[]=$msg;$missed++;if(moni_cron_watchdog_mark($db,$key,true,$msg))moni_cron_watchdog_notify($db,$key,'Cron görevi gecikti: '.$t['name'],$msg,'warning');}
        else moni_cron_watchdog_mark($db,$key,false,(string)$t['name'].' görevi zamanında.');
    }
    return ['missed'=>$missed,'messages'=>$messages];
}

function moni_cron_watchdog_request_tick(PDO $db): void {
    if(PHP_SAPI==='cli'||getSetting('cron_watchdog_enabled','1')!=='1')return;
    try{$last=trim((string)getSetting('cron_watchdog_last_web_check_at',''));if($last!==''&&time()-strtotime($last)<60)return;updateSetting('cron_watchdog_last_web_check_at',date('Y-m-d H:i:s'));moni_cron_watchdog_check($db,false);}catch(Throwable $e){error_log('Cron watchdog web tick: '.$e->getMessage());}
}
