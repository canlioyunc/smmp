<?php
/**
 * Moni v2 Commerce Pro
 * - Scheduled service price changes
 * - Quantity tier pricing
 * - Bank statement import/reconciliation
 * - Automatic bank transfer reference matching
 */
if (defined('MONI_COMMERCE_PRO_LOADED')) return;
define('MONI_COMMERCE_PRO_LOADED', true);

/* ---------------- Quantity tier pricing ---------------- */
function moni_service_price_tiers(PDO $db, int $serviceId, bool $activeOnly=true): array {
    if (!function_exists('moni_table_ready') || !moni_table_ready($db,'service_price_tiers')) return [];
    try {
        // Kullanıcı servis listelerinde binlerce servis olabilir. Aktif kademeleri request başına tek sorguda
        // önbelleğe alarak servis başına N+1 sorgu oluşmasını engelle.
        if($activeOnly){
            static $cache=[];$key=spl_object_id($db);
            if(!array_key_exists($key,$cache)){
                $cache[$key]=[];$q=$db->query("SELECT * FROM service_price_tiers WHERE is_active=1 ORDER BY service_id,min_quantity ASC,COALESCE(max_quantity,2147483647) ASC,id ASC");
                foreach($q->fetchAll(PDO::FETCH_ASSOC) as $row)$cache[$key][(int)$row['service_id']][]=$row;
            }
            return $cache[$key][$serviceId]??[];
        }
        $q=$db->prepare("SELECT * FROM service_price_tiers WHERE service_id=? ORDER BY min_quantity ASC,COALESCE(max_quantity,2147483647) ASC,id ASC");$q->execute([$serviceId]);return $q->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch(Throwable $e){ return []; }
}
function moni_service_tier_for_quantity(PDO $db,int $serviceId,int $quantity): ?array {
    if ($quantity<=0 || !moni_table_ready($db,'service_price_tiers')) return null;
    $tiers=moni_service_price_tiers($db,$serviceId,true);$chosen=null;
    foreach($tiers as $t){$min=(int)$t['min_quantity'];$max=$t['max_quantity']===null?0:(int)$t['max_quantity'];if($quantity>=$min&&($max<=0||$quantity<=$max))$chosen=$t;}
    return $chosen;
}
function moni_effective_price_for_quantity(array $service, ?int $userId, int $quantity): float {
    $base = moni_effective_price_per_1000($service,$userId);
    $db=$GLOBALS['db']??null;
    if(!$db instanceof PDO || $quantity<=0) return $base;
    $tier=moni_service_tier_for_quantity($db,(int)($service['id']??0),$quantity);
    if(!$tier) return $base;
    $candidate=$base;
    if(($tier['pricing_type']??'')==='discount_percent'){
        $discount=max(0,min(95,(float)$tier['pricing_value']));
        $candidate=$base*(1-$discount/100);
    } elseif(($tier['pricing_type']??'')==='fixed_per_1000') {
        $candidate=max(0,(float)$tier['pricing_value']);
        // Sabit miktar kademesi Premium indirimini yanlışlıkla yok etmesin.
        if($userId && function_exists('moni_premium_apply_price'))$candidate=moni_premium_apply_price($db,(int)$userId,$service,$candidate);
    }
    // Quantity discounts can never bypass the global/category/service minimum-profit floor.
    $candidate=max($candidate,moni_minimum_sale_price($service));
    return round($candidate,4);
}
function moni_quantity_price_quote(PDO $db,array $service,?int $userId,int $quantity): array {
    $base=moni_effective_price_per_1000($service,$userId);
    $rate=moni_effective_price_for_quantity($service,$userId,$quantity);
    $tier=moni_service_tier_for_quantity($db,(int)($service['id']??0),$quantity);
    return ['rate'=>$rate,'base_rate'=>$base,'tier'=>$tier,'total'=>round(($quantity/1000)*$rate,4)];
}

/* ---------------- Scheduled service prices ---------------- */
function moni_cron_task_scheduled_service_prices(PDO $db,int $batch): array {
    if(!moni_table_ready($db,'service_price_schedules'))return ['processed'=>0,'message'=>'service_price_schedules tablosu bulunamadı.'];
    $batch=max(1,min(5000,$batch));$ids=$db->query("SELECT id FROM service_price_schedules WHERE status='pending' AND execute_at<=NOW() ORDER BY execute_at,id LIMIT ".$batch)->fetchAll(PDO::FETCH_COLUMN);
    $done=0;$adjusted=0;$failed=0;
    foreach($ids as $id){
        try{
            $db->beginTransaction();
            $q=$db->prepare("SELECT * FROM service_price_schedules WHERE id=? FOR UPDATE");$q->execute([(int)$id]);$job=$q->fetch(PDO::FETCH_ASSOC);
            if(!$job||$job['status']!=='pending'){ $db->commit(); continue; }
            $s=$db->prepare("SELECT * FROM services WHERE id=? FOR UPDATE");$s->execute([(int)$job['service_id']]);$service=$s->fetch(PDO::FETCH_ASSOC);
            if(!$service)throw new RuntimeException('Servis bulunamadı.');
            $requested=max(0,(float)$job['requested_price']);if($requested<=0)throw new RuntimeException('Planlanan fiyat geçersiz.');
            $floor=moni_minimum_sale_price($service);$applied=max($requested,$floor);$floorAdjusted=$applied>$requested+0.000001;
            $db->prepare("UPDATE services SET price_per_1000=?,updated_at=NOW() WHERE id=?")->execute([$applied,$service['id']]);
            $db->prepare("UPDATE service_price_schedules SET status='applied',previous_price=?,applied_price=?,floor_adjusted=?,applied_at=NOW(),error_message=NULL,updated_at=NOW() WHERE id=?")
               ->execute([(float)$service['price_per_1000'],$applied,$floorAdjusted?1:0,$job['id']]);
            $db->commit();$done++;if($floorAdjusted)$adjusted++;
            if($floorAdjusted&&function_exists('moni_admin_notify'))moni_admin_notify($db,'scheduled_price','Planlı fiyat minimum kâr tabanına yükseltildi',(string)$service['name'].' için '.number_format($requested,4).' yerine '.number_format($applied,4).' uygulandı.','/admin/service-pricing.php','warning');
        }catch(Throwable $e){if($db->inTransaction())$db->rollBack();$failed++;try{$db->prepare("UPDATE service_price_schedules SET status='failed',error_message=?,updated_at=NOW() WHERE id=? AND status='pending'")->execute([mb_substr($e->getMessage(),0,1000),(int)$id]);}catch(Throwable $ignore){}}
    }
    return ['processed'=>$done+$failed,'message'=>"Planlı servis fiyatları işlendi: {$done} uygulandı, {$adjusted} kâr tabanına uyarlandı, {$failed} hata."];
}

/* ---------------- Bank references ---------------- */
function moni_bank_normalize_text(string $text): string {
    $text=mb_strtolower(trim($text),'UTF-8');
    $map=['ç'=>'c','ğ'=>'g','ı'=>'i','ö'=>'o','ş'=>'s','ü'=>'u','Ç'=>'c','Ğ'=>'g','İ'=>'i','Ö'=>'o','Ş'=>'s','Ü'=>'u'];
    $text=strtr($text,$map);$text=preg_replace('/[^a-z0-9]+/u',' ',$text);return trim(preg_replace('/\s+/',' ',$text));
}
function moni_user_bank_reference(PDO $db,int $userId): string {
    if($userId<=0)return '';
    try{
        $q=$db->prepare("SELECT bank_reference_code FROM users WHERE id=?");$q->execute([$userId]);$code=trim((string)$q->fetchColumn());if($code!=='')return $code;
        for($i=0;$i<5;$i++){
            $candidate='MNI-'.strtoupper(base_convert((string)$userId,10,36)).'-'.strtoupper(substr(bin2hex(random_bytes(5)),0,6));
            try{$u=$db->prepare("UPDATE users SET bank_reference_code=? WHERE id=? AND (bank_reference_code IS NULL OR bank_reference_code='')");$u->execute([$candidate,$userId]);}catch(Throwable $e){}
            $q->execute([$userId]);$code=trim((string)$q->fetchColumn());if($code!=='')return $code;
        }
    }catch(Throwable $e){}
    return 'MNI-U'.$userId;
}
function moni_payment_reference(PDO $db,int $userId): string { return moni_user_bank_reference($db,$userId); }

/* ---------------- Statement parsing ---------------- */
function moni_bank_header_key(string $s): string {return str_replace(' ','_',moni_bank_normalize_text($s));}
function moni_bank_detect_delimiter(string $line): string {
    $best=',';$max=-1;foreach([";",",","\t","|"] as $d){$n=substr_count($line,$d);if($n>$max){$max=$n;$best=$d;}}return $best;
}
function moni_bank_parse_csv(string $path): array {
    $fh=fopen($path,'rb');if(!$fh)throw new RuntimeException('CSV dosyası açılamadı.');
    $first=fgets($fh);if($first===false){fclose($fh);return ['headers'=>[],'rows'=>[]];}$first=preg_replace('/^\xEF\xBB\xBF/','',$first);$delimiter=moni_bank_detect_delimiter($first);rewind($fh);
    $headers=fgetcsv($fh,0,$delimiter);if(!$headers){fclose($fh);return ['headers'=>[],'rows'=>[]];}$headers=array_map(static fn($x)=>trim((string)$x),$headers);$rows=[];$limit=100000;
    while(($r=fgetcsv($fh,0,$delimiter))!==false && count($rows)<$limit){if(count(array_filter($r,static fn($v)=>trim((string)$v)!==''))===0)continue;$assoc=[];foreach($headers as $i=>$h)$assoc[$h]=$r[$i]??'';$rows[]=$assoc;}fclose($fh);return ['headers'=>$headers,'rows'=>$rows];
}
function moni_xlsx_col_index(string $ref): int {$letters=preg_replace('/[^A-Z]/','',strtoupper($ref));$n=0;for($i=0;$i<strlen($letters);$i++)$n=$n*26+(ord($letters[$i])-64);return max(0,$n-1);}
function moni_bank_parse_xlsx(string $path): array {
    if(!class_exists('ZipArchive'))throw new RuntimeException('XLSX için PHP ZipArchive eklentisi gerekli.');
    if(!function_exists('simplexml_load_string'))throw new RuntimeException('XLSX için PHP SimpleXML/XML eklentisi gerekli.');
    $z=new ZipArchive();if($z->open($path)!==true)throw new RuntimeException('XLSX açılamadı.');$shared=[];
    // Sıkıştırılmış küçük bir dosyanın aşırı büyük XML açarak belleği tüketmesini engelle.
    foreach(['xl/sharedStrings.xml','xl/worksheets/sheet1.xml'] as $part){$st=$z->statName($part);if($st!==false && (int)($st['size']??0)>50*1024*1024){$z->close();throw new RuntimeException('XLSX çalışma sayfası güvenli boyut sınırını aşıyor.');}}
    $ss=$z->getFromName('xl/sharedStrings.xml');if($ss!==false){$xml=@simplexml_load_string($ss,'SimpleXMLElement',LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);if($xml){foreach($xml->si as $si){$txt='';if(isset($si->t))$txt=(string)$si->t;else foreach($si->r as $r)$txt.=(string)$r->t;$shared[]=$txt;if(count($shared)>250000){$z->close();throw new RuntimeException('XLSX paylaşılan metin sayısı güvenli sınırı aşıyor.');}}}}
    $sheet=$z->getFromName('xl/worksheets/sheet1.xml');if($sheet===false){$z->close();throw new RuntimeException('XLSX ilk çalışma sayfası bulunamadı.');}$xml=@simplexml_load_string($sheet,'SimpleXMLElement',LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);$z->close();if(!$xml)throw new RuntimeException('XLSX XML okunamadı.');
    $matrix=[];$rowCount=0;foreach($xml->sheetData->row as $row){if(++$rowCount>100001)throw new RuntimeException('XLSX en fazla 100.000 veri satırı içerebilir.');$vals=[];foreach($row->c as $c){$ref=(string)$c['r'];$idx=moni_xlsx_col_index($ref);if($idx>250)continue;$type=(string)$c['t'];$val='';if($type==='inlineStr')$val=(string)$c->is->t;else{$raw=(string)$c->v;$val=$type==='s'?($shared[(int)$raw]??''):$raw;}$vals[$idx]=$val;}if($vals){ksort($vals);$max=max(array_keys($vals));$line=[];for($i=0;$i<=$max;$i++)$line[]=$vals[$i]??'';$matrix[]=$line;}}
    if(!$matrix)return ['headers'=>[],'rows'=>[]];$headers=array_map(static fn($x)=>trim((string)$x),array_shift($matrix));$rows=[];foreach($matrix as $r){$assoc=[];foreach($headers as $i=>$h)$assoc[$h]=$r[$i]??'';if(count(array_filter($assoc,static fn($v)=>trim((string)$v)!=='')))$rows[]=$assoc;}return ['headers'=>$headers,'rows'=>$rows];
}
function moni_bank_parse_statement_file(string $path,string $format): array {
    return strtolower($format)==='xlsx'?moni_bank_parse_xlsx($path):moni_bank_parse_csv($path);
}
function moni_bank_auto_map(array $headers,array $manual=[]): array {
    $norm=[];foreach($headers as $h)$norm[moni_bank_header_key((string)$h)]=$h;
    $pick=function(array $names)use($norm){foreach($names as $n)if(isset($norm[$n]))return $norm[$n];return null;};
    $map=[
      'date'=>$pick(['tarih','islem_tarihi','transaction_date','date','valeur_date','booking_date']),
      'amount'=>$pick(['tutar','islem_tutari','amount','transaction_amount','miktar']),
      'credit'=>$pick(['alacak','credit','gelen','credit_amount']),
      'debit'=>$pick(['borc','debit','giden','debit_amount']),
      'description'=>$pick(['aciklama','islem_aciklamasi','description','details','detay','narrative']),
      'reference'=>$pick(['referans','referans_no','reference','reference_no','ref','dekont_no','transaction_id','islem_no']),
      'sender'=>$pick(['gonderen','gonderen_adi','sender','counterparty','karsi_taraf','hesap_sahibi']),
      'currency'=>$pick(['para_birimi','currency','doviz','currency_code']),
    ];
    foreach($manual as $k=>$v){$v=trim((string)$v);if($v!==''&&in_array($v,$headers,true))$map[$k]=$v;}
    return $map;
}
function moni_bank_parse_amount($raw): float {
    $s=trim((string)$raw);if($s==='')return 0.0;$s=preg_replace('/[^0-9,\.\-]/','',$s);
    if(str_contains($s,',')&&str_contains($s,'.')){if(strrpos($s,',')>strrpos($s,'.')){$s=str_replace('.','',$s);$s=str_replace(',','.',$s);}else{$s=str_replace(',','',$s);}}
    elseif(str_contains($s,',')){$parts=explode(',',$s);$last=end($parts);$s=strlen($last)<=2?str_replace(',','.',$s):str_replace(',','',$s);}return (float)$s;
}
function moni_bank_parse_date($raw): ?string {
    $s=trim((string)$raw);if($s==='')return null;if(is_numeric($s)&&(float)$s>20000&&(float)$s<100000){$ts=(int)round(((float)$s-25569)*86400);return gmdate('Y-m-d H:i:s',$ts);}
    foreach(['d.m.Y H:i:s','d.m.Y H:i','Y-m-d H:i:s','Y-m-d H:i','d/m/Y H:i:s','d/m/Y H:i','m/d/Y H:i:s'] as $f){$d=DateTime::createFromFormat('!'.$f,$s);if($d&&$d->format($f)===$s)return $d->format('Y-m-d H:i:s');}
    foreach(['d.m.Y','Y-m-d','d/m/Y','m/d/Y'] as $f){$d=DateTime::createFromFormat('!'.$f,$s);if($d&&$d->format($f)===$s)return $d->format('Y-m-d 00:00:00');}
    $ts=strtotime($s);return $ts?date('Y-m-d H:i:s',$ts):null;
}
function moni_bank_import_statement(PDO $db,int $bankAccountId,array $file,array $manualMap=[],?int $adminId=null): array {
    if(($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)throw new RuntimeException('Ekstre dosyası yüklenemedi.');if(($file['size']??0)>15*1024*1024)throw new RuntimeException('Ekstre dosyası en fazla 15 MB olabilir.');
    if(empty($file['tmp_name'])||!is_readable($file['tmp_name']))throw new RuntimeException('Ekstre geçici dosyası okunamıyor.');
    $b=$db->prepare("SELECT id FROM bank_accounts WHERE id=? LIMIT 1");$b->execute([$bankAccountId]);if(!$b->fetchColumn())throw new RuntimeException('Banka hesabı bulunamadı.');
    $name=(string)($file['name']??'ekstre');$ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));if(!in_array($ext,['csv','txt','xlsx'],true))throw new RuntimeException('Yalnız CSV, TXT veya XLSX dosyaları desteklenir.');$format=$ext==='xlsx'?'xlsx':'csv';
    if($format==='xlsx'){$sig=(string)file_get_contents($file['tmp_name'],false,null,0,4);if(substr($sig,0,2)!=='PK')throw new RuntimeException('Yüklenen dosya geçerli bir XLSX dosyası değil.');}
    $hash=hash_file('sha256',$file['tmp_name']);$dup=$db->prepare("SELECT id FROM bank_statement_imports WHERE bank_account_id=? AND file_hash=? LIMIT 1");$dup->execute([$bankAccountId,$hash]);if($dup->fetchColumn())throw new RuntimeException('Bu ekstre dosyası daha önce içe aktarılmış.');
    $parsed=moni_bank_parse_statement_file($file['tmp_name'],$format);$map=moni_bank_auto_map($parsed['headers'],$manualMap);if(!$map['date']||(!$map['amount']&&!$map['credit']&&!$map['debit']))throw new RuntimeException('Tarih ve tutar sütunları belirlenemedi. Sütun adlarını elle girin.');
    $db->prepare("INSERT INTO bank_statement_imports(bank_account_id,filename,file_hash,file_format,status,row_count,created_by,created_at) VALUES(?,?,?,?, 'processing',?,?,NOW())")->execute([$bankAccountId,mb_substr($name,0,255),$hash,$format,count($parsed['rows']),$adminId]);$importId=(int)$db->lastInsertId();
    $inserted=0;$duplicates=0;$matched=0;$creditEntryIds=[];
    try{
        foreach($parsed['rows'] as $row){
            $date=moni_bank_parse_date($row[$map['date']]??'');if(!$date)continue;$amount=0.0;$direction='credit';
            if($map['amount']){$amount=moni_bank_parse_amount($row[$map['amount']]??'');$direction=$amount<0?'debit':'credit';$amount=abs($amount);}else{$credit=$map['credit']?abs(moni_bank_parse_amount($row[$map['credit']]??'')):0;$debit=$map['debit']?abs(moni_bank_parse_amount($row[$map['debit']]??'')):0;if($credit>0){$amount=$credit;$direction='credit';}elseif($debit>0){$amount=$debit;$direction='debit';}else continue;}
            if($amount<=0)continue;$desc=trim((string)($map['description']?$row[$map['description']]??'':''));$ref=trim((string)($map['reference']?$row[$map['reference']]??'':''));$sender=trim((string)($map['sender']?$row[$map['sender']]??'':''));$currency=strtoupper(trim((string)($map['currency']?$row[$map['currency']]??'TRY':'TRY')));if(!preg_match('/^[A-Z]{3,8}$/',$currency))$currency='TRY';
            $entryHash=hash('sha256',implode('|',[$bankAccountId,$date,number_format($amount,4,'.',''),$direction,moni_bank_normalize_text($ref),moni_bank_normalize_text($desc),moni_bank_normalize_text($sender)]));
            try{$st=$db->prepare("INSERT INTO bank_statement_entries(import_id,bank_account_id,entry_hash,transaction_date,amount,currency_code,direction,sender_name,description,reference_no,raw_json,match_status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,'unmatched',NOW())");$st->execute([$importId,$bankAccountId,$entryHash,$date,$amount,$currency,$direction,mb_substr($sender,0,255),$desc,mb_substr($ref,0,190),json_encode($row,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);$eid=(int)$db->lastInsertId();$inserted++;if($direction==='credit')$creditEntryIds[]=$eid;}catch(PDOException $e){if((string)$e->getCode()==='23000'){$duplicates++;continue;}throw $e;}
        }
        // Büyük ekstrelerde web isteğini binlerce eşleştirme sorgusuyla kilitleme. İlk küçük partiyi hemen eşleştir;
        // kalan hareketleri bank_reconciliation cron görevi kontrollü batch'ler halinde tamamlar.
        foreach(array_slice($creditEntryIds,0,250) as $eid){$m=moni_reconcile_bank_entry($db,(int)$eid,$adminId);if(in_array($m['status']??'',['matched','approved'],true))$matched++;}
        $db->prepare("UPDATE bank_statement_imports SET status='completed',imported_count=?,matched_count=?,duplicate_count=?,completed_at=NOW(),error_message=NULL WHERE id=?")->execute([$inserted,$matched,$duplicates,$importId]);
    }catch(Throwable $e){try{$db->prepare("UPDATE bank_statement_imports SET status='failed',imported_count=?,matched_count=?,duplicate_count=?,error_message=?,completed_at=NOW() WHERE id=?")->execute([$inserted,$matched,$duplicates,mb_substr($e->getMessage(),0,1000),$importId]);}catch(Throwable $ignore){}throw $e;}
    return ['import_id'=>$importId,'rows'=>count($parsed['rows']),'inserted'=>$inserted,'matched'=>$matched,'duplicates'=>$duplicates,'mapping'=>$map];
}

/* ---------------- Reconciliation ---------------- */
function moni_bank_match_score(array $entry,array $p,int $windowDays,float $tolerance): array {
    $score=0;$reasons=[];$expectedAmount=(float)($p['match_amount']??$p['amount']);$amountDiff=abs((float)$entry['amount']-$expectedAmount);$amountOk=$amountDiff<=$tolerance;
    if($amountOk){$score+=45;$reasons[]='tutar';}elseif($amountDiff<=max($tolerance,0.50)){$score+=20;$reasons[]='yakın tutar';}
    $hay=moni_bank_normalize_text(($entry['reference_no']??'').' '.($entry['description']??''));$pref=moni_bank_normalize_text((string)($p['payment_reference']??''));$exactRef=$pref!==''&&str_contains(str_replace(' ','',$hay),str_replace(' ','',$pref));if($exactRef){$score+=55;$reasons[]='referans';}
    if(!$exactRef && preg_match('/(?:^|\D)#?'.preg_quote((string)$p['id'],'/').'(?:\D|$)/',$hay)){$score+=35;$reasons[]='talep no';}
    $sender=moni_bank_normalize_text((string)($entry['sender_name']??''));$expected=moni_bank_normalize_text((string)($p['sender_name']??''));if($sender!==''&&$expected!==''){$pct=0;similar_text($sender,$expected,$pct);if($pct>=90){$score+=20;$reasons[]='gönderen';}elseif($pct>=70){$score+=10;$reasons[]='gönderen benzer';}}
    $days=abs((strtotime((string)$entry['transaction_date'])?:0)-(strtotime((string)$p['transfer_date'])?:0))/86400;if($days<=1){$score+=15;$reasons[]='tarih';}elseif($days<=$windowDays){$score+=max(2,(int)round(12*(1-$days/max(1,$windowDays))));}
    return ['score'=>min(100,$score),'amount_ok'=>$amountOk,'exact_reference'=>$exactRef,'reason'=>implode(', ',$reasons)];
}
function moni_reconcile_bank_entry(PDO $db,int $entryId,?int $adminId=null): array {
    $q=$db->prepare("SELECT * FROM bank_statement_entries WHERE id=?");$q->execute([$entryId]);$entry=$q->fetch(PDO::FETCH_ASSOC);if(!$entry||$entry['direction']!=='credit')return ['status'=>'ignored'];
    if(in_array($entry['match_status'],['matched','approved'],true)&&!empty($entry['matched_payment_request_id']))return ['status'=>$entry['match_status'],'payment_request_id'=>(int)$entry['matched_payment_request_id']];
    $window=max(1,min(60,(int)(getSetting('bank_reconciliation_date_window_days','7'))));$tol=max(0,min(100,(float)getSetting('bank_reconciliation_amount_tolerance','0.01')));
    $sql="SELECT pr.*,COALESCE(NULLIF(pr.payable_amount,0),pr.amount) match_amount,u.bank_reference_code FROM payment_requests pr JOIN users u ON u.id=pr.user_id WHERE pr.status='pending' AND pr.bank_account_id=? AND pr.transfer_date BETWEEN DATE_SUB(?,INTERVAL {$window} DAY) AND DATE_ADD(?,INTERVAL {$window} DAY) AND COALESCE(NULLIF(pr.payable_amount,0),pr.amount) BETWEEN ? AND ? AND NOT EXISTS (SELECT 1 FROM bank_statement_entries be2 WHERE be2.matched_payment_request_id=pr.id AND be2.id<>? AND be2.match_status IN('matched','approved')) ORDER BY ABS(COALESCE(NULLIF(pr.payable_amount,0),pr.amount)-?) ASC,pr.created_at ASC LIMIT 40";
    $s=$db->prepare($sql);$low=max(0,(float)$entry['amount']-max($tol,1));$high=(float)$entry['amount']+max($tol,1);$s->execute([$entry['bank_account_id'],$entry['transaction_date'],$entry['transaction_date'],$low,$high,$entryId,$entry['amount']]);$candidates=$s->fetchAll(PDO::FETCH_ASSOC);if(!$candidates)return ['status'=>'unmatched'];
    $scored=[];foreach($candidates as $p){if(empty($p['payment_reference']))$p['payment_reference']=$p['bank_reference_code']??'';$m=moni_bank_match_score($entry,$p,$window,$tol);$scored[]=['p'=>$p]+$m;}usort($scored,static fn($a,$b)=>$b['score']<=>$a['score']);$best=$scored[0];$second=$scored[1]['score']??-1;
    $status='unmatched';if($best['score']>=85&&($best['score']-$second)>=8)$status='matched';elseif($best['score']>=55)$status='suggested';
    if($status==='unmatched')return ['status'=>$status];
    $db->prepare("UPDATE bank_statement_entries SET match_status=?,matched_payment_request_id=?,match_score=?,match_reason=?,matched_at=NOW(),matched_by=? WHERE id=?")
       ->execute([$status,(int)$best['p']['id'],$best['score'],$best['reason'],$adminId,$entryId]);
    $autoApprove=getSetting('bank_reconciliation_auto_approve_exact','0')==='1';if($status==='matched'&&$autoApprove&&!empty($best['exact_reference'])&&!empty($best['amount_ok'])){$r=moni_approve_payment_request($db,(int)$best['p']['id'],null,'Banka ekstresi: kesin referans ve tutar eşleşmesi');if(!empty($r['ok'])&&empty($r['already'])){$db->prepare("UPDATE bank_statement_entries SET match_status='approved',approved_at=NOW() WHERE id=?")->execute([$entryId]);return ['status'=>'approved','payment_request_id'=>(int)$best['p']['id'],'score'=>$best['score']];}if(!empty($r['already'])){$db->prepare("UPDATE bank_statement_entries SET match_status='suggested',matched_payment_request_id=NULL,match_reason='Eşleşen ödeme talebi daha önce işlendi',matched_at=NULL WHERE id=?")->execute([$entryId]);return ['status'=>'suggested'];}}
    return ['status'=>$status,'payment_request_id'=>(int)$best['p']['id'],'score'=>$best['score'],'reason'=>$best['reason']];
}
function moni_approve_payment_request(PDO $db,int $paymentId,?int $adminId=null,string $note=''): array {
    $own=!$db->inTransaction();if($own)$db->beginTransaction();
    try{
        $q=$db->prepare("SELECT * FROM payment_requests WHERE id=? FOR UPDATE");$q->execute([$paymentId]);$p=$q->fetch(PDO::FETCH_ASSOC);if(!$p)throw new RuntimeException('Ödeme talebi bulunamadı.');if($p['status']==='approved'){if($own)$db->commit();return ['ok'=>true,'already'=>true];}if($p['status']!=='pending')throw new RuntimeException('Ödeme talebi artık beklemede değil.');
        $amount=(float)(!empty($p['credit_amount'])?$p['credit_amount']:$p['amount']);$u=$db->prepare("SELECT balance FROM users WHERE id=? FOR UPDATE");$u->execute([$p['user_id']]);$before=$u->fetchColumn();if($before===false)throw new RuntimeException('Kullanıcı bulunamadı.');
        $db->prepare("UPDATE users SET balance=balance+? WHERE id=?")->execute([$amount,$p['user_id']]);$up=$db->prepare("UPDATE payment_requests SET status='approved',admin_note=?,processed_by=?,processed_at=NOW() WHERE id=? AND status='pending'");$up->execute([$note,$adminId,$paymentId]);if(!$up->rowCount())throw new RuntimeException('Ödeme başka bir işlem tarafından işlendi.');
        $after=(float)$before+$amount;$db->prepare("INSERT INTO transactions(user_id,type,amount,balance_after,description,status,created_at) VALUES(?,'deposit',?,?,?,'completed',NOW())")->execute([$p['user_id'],$amount,$after,'Bakiye yükleme - banka mutabakatı']);
        if(function_exists('moni_queue_invoice'))moni_queue_invoice($db,(int)$p['user_id'],null,(float)$p['amount'],function_exists('moni_base_currency')?moni_base_currency($db):'TRY');if($own)$db->commit();if(function_exists('moni_sync_base_wallet'))moni_sync_base_wallet($db,(int)$p['user_id']);
        if(function_exists('moni_user_notify'))moni_user_notify($db,(int)$p['user_id'],'payment','Ödemeniz onaylandı',(string)getSetting('currency_symbol','₺').number_format($amount,2).' bakiyenize eklendi.','/kullanici/add-funds.php','success');
        if(function_exists('moni_send_template_email')){try{$em=$db->prepare("SELECT email,username FROM users WHERE id=?");$em->execute([$p['user_id']]);$eu=$em->fetch(PDO::FETCH_ASSOC);if($eu&&!empty($eu['email']))moni_send_template_email($db,'payment_approved',$eu['email'],['username'=>$eu['username'],'amount'=>(string)getSetting('currency_symbol','₺').number_format($amount,2)]);}catch(Throwable $ignore){}}
        return ['ok'=>true,'amount'=>$amount];
    }catch(Throwable $e){if($own&&$db->inTransaction())$db->rollBack();return ['ok'=>false,'error'=>$e->getMessage()];}
}
function moni_cron_task_bank_reconciliation(PDO $db,int $batch): array {
    if(!moni_table_ready($db,'bank_statement_entries'))return ['processed'=>0,'message'=>'Banka mutabakat tablosu bulunamadı.'];$batch=max(1,min(5000,$batch));$q=$db->query("SELECT id FROM bank_statement_entries WHERE direction='credit' AND match_status IN('unmatched','suggested') ORDER BY id ASC LIMIT ".$batch);$n=0;$matched=0;foreach($q->fetchAll(PDO::FETCH_COLUMN) as $id){$r=moni_reconcile_bank_entry($db,(int)$id,null);$n++;if(in_array($r['status']??'',['matched','approved'],true))$matched++;}return ['processed'=>$n,'message'=>"Banka mutabakatı: {$n} kayıt kontrol edildi, {$matched} eşleşti."];
}
