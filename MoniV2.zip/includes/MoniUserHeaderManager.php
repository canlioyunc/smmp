<?php
/**
 * MONI user panel header/navigation manager.
 * Defaults intentionally mirror the shipped user header. Customization is stored
 * as JSON in the existing settings table, so no schema migration is required.
 */

if (!function_exists('moni_user_header_defaults')) {
    function moni_user_header_defaults(): array
    {
        return [
            'general' => [
                'sidebar_logo_link' => '/',
                'sidebar_search_enabled' => 1,
                'sidebar_logout_enabled' => 1,
                'topbar_toggle_enabled' => 1,
                'page_kicker_enabled' => 1,
                'page_kicker_text' => 'Kullanıcı Paneli',
            ],
            'sections' => [
                ['id'=>'quick','label'=>'Hızlı Erişim','enabled'=>1,'order'=>10,'static'=>1,'default_open'=>1],
                ['id'=>'advanced','label'=>'Özel Siparişler','enabled'=>1,'order'=>20,'static'=>0,'default_open'=>0],
                ['id'=>'orders','label'=>'Siparişler','enabled'=>1,'order'=>30,'static'=>0,'default_open'=>1],
                ['id'=>'services','label'=>'Servisler','enabled'=>1,'order'=>40,'static'=>0,'default_open'=>0],
                ['id'=>'finance','label'=>'Finans','enabled'=>1,'order'=>50,'static'=>0,'default_open'=>1],
                ['id'=>'referral','label'=>'Referans','enabled'=>1,'order'=>60,'static'=>0,'default_open'=>0],
                ['id'=>'account','label'=>'Hesap','enabled'=>1,'order'=>70,'static'=>0,'default_open'=>0],
            ],
            'sidebar_items' => [
                ['id'=>'dashboard','core'=>'dashboard','label'=>'Kontrol Paneli','url'=>'/kullanici/','icon'=>'fas fa-gauge-high','section'=>'quick','enabled'=>1,'order'=>10,'target'=>'_self'],
                ['id'=>'new_order','core'=>'new_order','label'=>'Yeni Sipariş','url'=>'/kullanici/new-order.php','icon'=>'fas fa-plus-circle','section'=>'quick','enabled'=>1,'order'=>20,'target'=>'_self'],
                ['id'=>'add_funds','core'=>'add_funds','label'=>'Bakiye Yükle','url'=>'/kullanici/add-funds.php','icon'=>'fas fa-wallet','section'=>'quick','enabled'=>1,'order'=>30,'target'=>'_self'],
                ['id'=>'scheduled_orders','core'=>'scheduled_orders','label'=>'Süreli Siparişler','url'=>'/kullanici/scheduled-orders.php','icon'=>'fas fa-clock','section'=>'advanced','enabled'=>1,'order'=>10,'target'=>'_self'],
                ['id'=>'subscriptions','core'=>'subscriptions','label'=>'Auto Subscription','url'=>'/kullanici/subscriptions.php','icon'=>'fas fa-arrows-rotate','section'=>'advanced','enabled'=>1,'order'=>20,'target'=>'_self'],
                ['id'=>'likes_spread','core'=>'likes_spread','label'=>'Likes Spread','url'=>'/kullanici/likes-spread.php','icon'=>'fas fa-share-nodes','section'=>'advanced','enabled'=>1,'order'=>30,'target'=>'_self'],
                ['id'=>'orders','core'=>'orders','label'=>'Siparişler','url'=>'/kullanici/orders.php','icon'=>'fas fa-shopping-cart','section'=>'orders','enabled'=>1,'order'=>10,'target'=>'_self'],
                ['id'=>'mass_order','core'=>'mass_order','label'=>'Toplu Sipariş','url'=>'/kullanici/mass-order.php','icon'=>'fas fa-layer-group','section'=>'orders','enabled'=>1,'order'=>20,'target'=>'_self'],
                ['id'=>'services','core'=>'services','label'=>'Tüm Servisler','url'=>'/kullanici/services.php','icon'=>'fas fa-list','section'=>'services','enabled'=>1,'order'=>10,'target'=>'_self'],
                ['id'=>'bundles','core'=>'bundles','label'=>'Servis Paketleri','url'=>'/kullanici/bundles.php','icon'=>'fas fa-boxes-stacked','section'=>'services','enabled'=>1,'order'=>20,'target'=>'_self'],
                ['id'=>'compare','core'=>'compare','label'=>'Servis Karşılaştır','url'=>'/kullanici/compare.php','icon'=>'fas fa-balance-scale','section'=>'services','enabled'=>1,'order'=>30,'target'=>'_self'],
                ['id'=>'transactions','core'=>'transactions','label'=>'İşlem Geçmişi','url'=>'/kullanici/transactions.php','icon'=>'fas fa-history','section'=>'finance','enabled'=>1,'order'=>10,'target'=>'_self'],
                ['id'=>'wallets','core'=>'wallets','label'=>'Çoklu Para Birimi','url'=>'/kullanici/wallets.php','icon'=>'fas fa-coins','section'=>'finance','enabled'=>1,'order'=>20,'target'=>'_self'],
                ['id'=>'referral','core'=>'referral','label'=>'Referans Programı','url'=>'/kullanici/referral.php','icon'=>'fas fa-gift','section'=>'referral','enabled'=>1,'order'=>10,'target'=>'_self'],
                ['id'=>'daily_bonus','core'=>'daily_bonus','label'=>'Günlük Bonus','url'=>'/kullanici/daily-bonus.php','icon'=>'fas fa-calendar-check','section'=>'referral','enabled'=>1,'order'=>20,'target'=>'_self'],
                ['id'=>'premium','core'=>'premium','label'=>'Premium Paketler','url'=>'/kullanici/premium.php','icon'=>'fas fa-crown','section'=>'account','enabled'=>1,'order'=>10,'target'=>'_self'],
                ['id'=>'notifications','core'=>'notifications','label'=>'Bildirimler','url'=>'/kullanici/notifications.php','icon'=>'fas fa-bell','section'=>'account','enabled'=>1,'order'=>20,'target'=>'_self'],
                ['id'=>'profile','core'=>'profile','label'=>'Profil','url'=>'/kullanici/profile.php','icon'=>'fas fa-user','section'=>'account','enabled'=>1,'order'=>30,'target'=>'_self'],
                ['id'=>'security','core'=>'security','label'=>'Hesap Güvenliği','url'=>'/kullanici/security-center.php','icon'=>'fas fa-shield-alt','section'=>'account','enabled'=>1,'order'=>40,'target'=>'_self'],
                ['id'=>'tax_profile','core'=>'tax_profile','label'=>'Vergi / Fatura Profili','url'=>'/kullanici/tax-profile.php','icon'=>'fas fa-file-invoice','section'=>'account','enabled'=>1,'order'=>50,'target'=>'_self'],
                ['id'=>'api','core'=>'api','label'=>'API','url'=>'/kullanici/api.php','icon'=>'fas fa-code','section'=>'account','enabled'=>1,'order'=>60,'target'=>'_self'],
                ['id'=>'api_history','core'=>'api_history','label'=>'API İstek Geçmişi','url'=>'/kullanici/api-history.php','icon'=>'fas fa-clock-rotate-left','section'=>'account','enabled'=>1,'order'=>70,'target'=>'_self'],
                ['id'=>'child_panel','core'=>'child_panel','label'=>'Child Panel','url'=>'/kullanici/child-panel.php','icon'=>'fas fa-network-wired','section'=>'account','enabled'=>1,'order'=>80,'target'=>'_self'],
                ['id'=>'support','core'=>'support','label'=>'Destek','url'=>'/kullanici/support.php','icon'=>'fas fa-headset','section'=>'account','enabled'=>1,'order'=>90,'target'=>'_self'],
                ['id'=>'admin_panel','core'=>'admin_panel','label'=>'Admin Paneline Geç','url'=>'/admin/','icon'=>'fas fa-user-shield','section'=>'account','enabled'=>1,'order'=>100,'target'=>'_self'],
            ],
            'topbar_items' => [
                ['id'=>'balance','core'=>'balance','label'=>'Mevcut Bakiye','url'=>'/kullanici/add-funds.php','icon'=>'fas fa-wallet','enabled'=>1,'order'=>10,'target'=>'_self'],
                ['id'=>'language','core'=>'language','label'=>'Dil Seçici','url'=>'','icon'=>'fas fa-language','enabled'=>1,'order'=>20,'target'=>'_self'],
                ['id'=>'notifications','core'=>'notifications','label'=>'Bildirimler','url'=>'/kullanici/notifications.php','icon'=>'fas fa-bell','enabled'=>1,'order'=>30,'target'=>'_self'],
                ['id'=>'referral','core'=>'referral','label'=>'Referans Programı','url'=>'/kullanici/referral.php','icon'=>'fas fa-gift','enabled'=>1,'order'=>40,'target'=>'_self'],
                ['id'=>'orders','core'=>'orders','label'=>'Siparişler','url'=>'/kullanici/orders.php','icon'=>'fas fa-shopping-cart','enabled'=>1,'order'=>50,'target'=>'_self'],
                ['id'=>'pwa','core'=>'pwa','label'=>'Uygulamayı Telefona Kur','url'=>'','icon'=>'fas fa-mobile-screen-button','enabled'=>1,'order'=>60,'target'=>'_self'],
                ['id'=>'profile','core'=>'profile','label'=>'Hesabım','url'=>'','icon'=>'fas fa-user','enabled'=>1,'order'=>70,'target'=>'_self'],
            ],
            'profile_items' => [
                ['id'=>'add_funds','core'=>'add_funds','label'=>'Bakiye Yükle','url'=>'/kullanici/add-funds.php','icon'=>'fas fa-wallet','enabled'=>1,'order'=>10,'target'=>'_self','danger'=>0,'separator_after'=>1],
                ['id'=>'profile','core'=>'profile','label'=>'Profil Ayarları','url'=>'/kullanici/profile.php','icon'=>'fas fa-user','enabled'=>1,'order'=>20,'target'=>'_self','danger'=>0,'separator_after'=>0],
                ['id'=>'security','core'=>'security','label'=>'Hesap Güvenliği','url'=>'/kullanici/security-center.php','icon'=>'fas fa-shield-halved','enabled'=>1,'order'=>30,'target'=>'_self','danger'=>0,'separator_after'=>0],
                ['id'=>'admin_panel','core'=>'admin_panel','label'=>'Admin Paneline Geç','url'=>'/admin/','icon'=>'fas fa-user-shield','enabled'=>1,'order'=>40,'target'=>'_self','danger'=>0,'separator_after'=>0],
                ['id'=>'logout','core'=>'logout','label'=>'Çıkış Yap','url'=>'/logout.php','icon'=>'fas fa-right-from-bracket','enabled'=>1,'order'=>50,'target'=>'_self','danger'=>1,'separator_after'=>0],
            ],
        ];
    }
}


if (!function_exists('moni_user_header_truncate')) {
    function moni_user_header_truncate($value, int $length): string
    {
        $value = (string)$value;
        return function_exists('mb_substr') ? mb_substr($value, 0, $length, 'UTF-8') : substr($value, 0, $length);
    }
}

if (!function_exists('moni_user_header_safe_url')) {
    function moni_user_header_safe_url($value, string $fallback = '#'): string
    {
        $value = trim((string)$value);
        if ($value === '') return $fallback;
        if ($value[0] === '/' && (strlen($value) === 1 || $value[1] !== '/')) return $value;
        if (preg_match('~^https?://~i', $value)) return $value;
        if (preg_match('~^(mailto|tel):~i', $value)) return $value;
        return $fallback;
    }
}

if (!function_exists('moni_user_header_safe_icon')) {
    function moni_user_header_safe_icon($value, string $fallback = 'fas fa-circle'): string
    {
        $value = trim((string)$value);
        if ($value === '' || !preg_match('/^[a-zA-Z0-9 _-]{1,100}$/', $value)) return $fallback;
        return preg_replace('/\s+/', ' ', $value);
    }
}

if (!function_exists('moni_user_header_safe_id')) {
    function moni_user_header_safe_id($value, string $prefix = 'item'): string
    {
        $value = strtolower(trim((string)$value));
        $value = preg_replace('/[^a-z0-9_-]+/', '-', $value);
        $value = trim($value, '-_');
        if ($value === '') $value = $prefix . '-' . substr(hash('sha256', uniqid('', true)), 0, 8);
        return substr($value, 0, 64);
    }
}

if (!function_exists('moni_user_header_sanitize_config')) {
    function moni_user_header_sanitize_config(array $config): array
    {
        $defaults = moni_user_header_defaults();
        $generalIn = is_array($config['general'] ?? null) ? $config['general'] : [];
        $general = [
            'sidebar_logo_link' => moni_user_header_safe_url($generalIn['sidebar_logo_link'] ?? $defaults['general']['sidebar_logo_link'], '/'),
            'sidebar_search_enabled' => !empty($generalIn['sidebar_search_enabled']) ? 1 : 0,
            'sidebar_logout_enabled' => !empty($generalIn['sidebar_logout_enabled']) ? 1 : 0,
            'topbar_toggle_enabled' => !empty($generalIn['topbar_toggle_enabled']) ? 1 : 0,
            'page_kicker_enabled' => !empty($generalIn['page_kicker_enabled']) ? 1 : 0,
            'page_kicker_text' => moni_user_header_truncate(trim((string)($generalIn['page_kicker_text'] ?? 'Kullanıcı Paneli')), 60),
        ];

        $sections = [];
        $seenSections = [];
        $defaultSectionState = [];
        foreach ($defaults['sections'] as $defaultSection) {
            $defaultSectionState[(string)$defaultSection['id']] = !empty($defaultSection['default_open']) ? 1 : 0;
        }
        foreach ((array)($config['sections'] ?? []) as $section) {
            if (!is_array($section)) continue;
            $id = moni_user_header_safe_id($section['id'] ?? '', 'section');
            if (isset($seenSections[$id])) continue;
            $seenSections[$id] = true;
            $sections[] = [
                'id' => $id,
                'label' => moni_user_header_truncate(trim((string)($section['label'] ?? 'Menü')), 80),
                'enabled' => !empty($section['enabled']) ? 1 : 0,
                'order' => max(-9999, min(9999, (int)($section['order'] ?? 0))),
                'static' => !empty($section['static']) ? 1 : 0,
                'default_open' => array_key_exists('default_open', $section)
                    ? (!empty($section['default_open']) ? 1 : 0)
                    : ($defaultSectionState[$id] ?? 0),
            ];
        }
        if (!$sections) $sections = $defaults['sections'];
        usort($sections, static function($a,$b){ return ($a['order'] <=> $b['order']) ?: strcmp($a['id'],$b['id']); });
        $validSections = array_fill_keys(array_column($sections, 'id'), true);
        $fallbackSection = $sections[0]['id'];

        $sidebar = [];
        $seenItems = [];
        foreach ((array)($config['sidebar_items'] ?? []) as $item) {
            if (!is_array($item)) continue;
            $id = moni_user_header_safe_id($item['id'] ?? '', 'item');
            if (isset($seenItems[$id])) continue;
            $seenItems[$id] = true;
            $section = moni_user_header_safe_id($item['section'] ?? $fallbackSection, 'section');
            if (!isset($validSections[$section])) $section = $fallbackSection;
            $target = (string)($item['target'] ?? '_self');
            if (!in_array($target, ['_self','_blank'], true)) $target = '_self';
            $sidebar[] = [
                'id'=>$id,
                'core'=>preg_replace('/[^a-z0-9_-]/i','',(string)($item['core'] ?? 'custom')) ?: 'custom',
                'label'=>moni_user_header_truncate(trim((string)($item['label'] ?? 'Menü')),100),
                'url'=>moni_user_header_safe_url($item['url'] ?? '#','#'),
                'icon'=>moni_user_header_safe_icon($item['icon'] ?? 'fas fa-link'),
                'section'=>$section,
                'enabled'=>!empty($item['enabled']) ? 1 : 0,
                'order'=>max(-9999,min(9999,(int)($item['order'] ?? 0))),
                'target'=>$target,
            ];
        }
        usort($sidebar, static function($a,$b){ return ($a['order'] <=> $b['order']) ?: strcmp($a['id'],$b['id']); });

        $topbar = [];
        $seenTop = [];
        foreach ((array)($config['topbar_items'] ?? []) as $item) {
            if (!is_array($item)) continue;
            $id = moni_user_header_safe_id($item['id'] ?? '', 'top');
            if (isset($seenTop[$id])) continue;
            $seenTop[$id] = true;
            $target = (string)($item['target'] ?? '_self');
            if (!in_array($target, ['_self','_blank'], true)) $target = '_self';
            $topbar[] = [
                'id'=>$id,
                'core'=>preg_replace('/[^a-z0-9_-]/i','',(string)($item['core'] ?? 'custom')) ?: 'custom',
                'label'=>moni_user_header_truncate(trim((string)($item['label'] ?? 'Menü')),100),
                'url'=>moni_user_header_safe_url($item['url'] ?? '', ''),
                'icon'=>moni_user_header_safe_icon($item['icon'] ?? 'fas fa-link'),
                'enabled'=>!empty($item['enabled']) ? 1 : 0,
                'order'=>max(-9999,min(9999,(int)($item['order'] ?? 0))),
                'target'=>$target,
            ];
        }
        usort($topbar, static function($a,$b){ return ($a['order'] <=> $b['order']) ?: strcmp($a['id'],$b['id']); });

        $profile = [];
        $seenProfile = [];
        foreach ((array)($config['profile_items'] ?? $defaults['profile_items']) as $item) {
            if (!is_array($item)) continue;
            $id = moni_user_header_safe_id($item['id'] ?? '', 'profile');
            if (isset($seenProfile[$id])) continue;
            $seenProfile[$id] = true;
            $target = (string)($item['target'] ?? '_self');
            if (!in_array($target, ['_self','_blank'], true)) $target = '_self';
            $profile[] = [
                'id'=>$id,
                'core'=>preg_replace('/[^a-z0-9_-]/i','',(string)($item['core'] ?? 'custom')) ?: 'custom',
                'label'=>moni_user_header_truncate(trim((string)($item['label'] ?? 'Menü')),100),
                'url'=>moni_user_header_safe_url($item['url'] ?? '#','#'),
                'icon'=>moni_user_header_safe_icon($item['icon'] ?? 'fas fa-link'),
                'enabled'=>!empty($item['enabled']) ? 1 : 0,
                'order'=>max(-9999,min(9999,(int)($item['order'] ?? 0))),
                'target'=>$target,
                'danger'=>!empty($item['danger']) ? 1 : 0,
                'separator_after'=>!empty($item['separator_after']) ? 1 : 0,
            ];
        }
        usort($profile, static function($a,$b){ return ($a['order'] <=> $b['order']) ?: strcmp($a['id'],$b['id']); });

        return ['general'=>$general,'sections'=>$sections,'sidebar_items'=>$sidebar,'topbar_items'=>$topbar,'profile_items'=>$profile];
    }
}

if (!function_exists('moni_user_header_config')) {
    function moni_user_header_config(PDO $db): array
    {
        $defaults = moni_user_header_defaults();
        try {
            $stmt = $db->prepare("SELECT setting_value FROM settings WHERE setting_key='user_header_manager_config' LIMIT 1");
            $stmt->execute();
            $raw = $stmt->fetchColumn();
            if (!is_string($raw) || trim($raw) === '') return $defaults;
            $decoded = json_decode($raw, true);
            if (!is_array($decoded)) return $defaults;
            return moni_user_header_sanitize_config($decoded);
        } catch (Throwable $e) {
            return $defaults;
        }
    }
}

if (!function_exists('moni_user_header_save_config')) {
    function moni_user_header_save_config(PDO $db, array $config): bool
    {
        $config = moni_user_header_sanitize_config($config);
        $json = json_encode($config, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) return false;
        $stmt = $db->prepare("INSERT INTO settings(setting_key,setting_value) VALUES('user_header_manager_config',?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");
        return $stmt->execute([$json]);
    }
}

if (!function_exists('moni_user_header_reset_config')) {
    function moni_user_header_reset_config(PDO $db): bool
    {
        $stmt = $db->prepare("DELETE FROM settings WHERE setting_key='user_header_manager_config'");
        return $stmt->execute();
    }
}

if (!function_exists('moni_user_header_item_visible')) {
    function moni_user_header_item_visible(array $item, PDO $db, array $ctx = []): bool
    {
        if (empty($item['enabled'])) return false;
        $core = (string)($item['core'] ?? 'custom');
        $userId = (int)($ctx['user_id'] ?? 0);
        try {
            switch ($core) {
                case 'subscriptions':
                    return function_exists('moni_plugin_enabled') && moni_plugin_enabled('auto_subscriptions',$db) && (!function_exists('moni_user_can') || moni_user_can($db,$userId,'subscriptions.use',true));
                case 'likes_spread':
                    return !function_exists('moni_user_can') || moni_user_can($db,$userId,'spread.use',true);
                case 'daily_bonus':
                    return !empty($ctx['bonus_active']);
                case 'premium':
                    return function_exists('moni_plugin_enabled') && moni_plugin_enabled('premium_memberships',$db);
                case 'tax_profile':
                    return function_exists('moni_plugin_enabled') && (moni_plugin_enabled('tax_vat',$db) || moni_plugin_enabled('e_invoice',$db));
                case 'api_history':
                    return function_exists('moni_plugin_enabled') && moni_plugin_enabled('customer_api_history',$db);
                case 'child_panel':
                    return function_exists('moni_plugin_enabled') && moni_plugin_enabled('child_panels',$db) && (!function_exists('moni_user_can') || moni_user_can($db,$userId,'child_panel.buy',true));
                case 'admin_panel':
                    return function_exists('isAdmin') && isAdmin();
                case 'language':
                    return ((int)($ctx['language_count'] ?? 0)) > 1;
                case 'pwa':
                    return function_exists('moni_growth_plugin_enabled') && moni_growth_plugin_enabled($db,'pwa_app');
                default:
                    return true;
            }
        } catch (Throwable $e) {
            return false;
        }
    }
}

if (!function_exists('moni_user_header_active')) {
    function moni_user_header_active(array $item, string $currentPage): bool
    {
        $core = (string)($item['core'] ?? 'custom');
        $map = [
            'dashboard'=>'index.php','new_order'=>'new-order.php','add_funds'=>'add-funds.php','scheduled_orders'=>'scheduled-orders.php',
            'subscriptions'=>'subscriptions.php','likes_spread'=>'likes-spread.php','orders'=>'orders.php','mass_order'=>'mass-order.php',
            'services'=>'services.php','bundles'=>'bundles.php','compare'=>'compare.php','transactions'=>'transactions.php','wallets'=>'wallets.php',
            'referral'=>'referral.php','daily_bonus'=>'daily-bonus.php','premium'=>'premium.php','notifications'=>'notifications.php','profile'=>'profile.php',
            'security'=>'security-center.php','tax_profile'=>'tax-profile.php','api'=>'api.php','api_history'=>'api-history.php','child_panel'=>'child-panel.php','support'=>'support.php'
        ];
        if (isset($map[$core])) return $currentPage === $map[$core];
        $path = parse_url((string)($item['url'] ?? ''), PHP_URL_PATH);
        if (!is_string($path) || $path === '') return false;
        return basename($path) === $currentPage;
    }
}

if (!function_exists('moni_user_header_badge')) {
    function moni_user_header_badge(array $item, array $ctx = []): string
    {
        $core = (string)($item['core'] ?? 'custom');
        if ($core === 'scheduled_orders' && (int)($ctx['scheduled_count'] ?? 0) > 0) return '<span class="nav-badge success">'.(int)$ctx['scheduled_count'].'</span>';
        if ($core === 'orders' && (int)($ctx['pending_orders'] ?? 0) > 0) return '<span class="nav-badge">'.(int)$ctx['pending_orders'].'</span>';
        if ($core === 'referral' && (float)($ctx['referral_pending'] ?? 0) > 0) {
            $symbol = htmlspecialchars((string)($ctx['currency_symbol'] ?? ''), ENT_QUOTES, 'UTF-8');
            return '<span class="nav-badge success">'.$symbol.number_format((float)$ctx['referral_pending'],0).'</span>';
        }
        if ($core === 'daily_bonus' && !empty($ctx['can_claim_bonus'])) return '<span class="nav-badge bonus">!</span>';
        if ($core === 'premium' && !empty($ctx['premium_badge'])) return '<span class="nav-badge success"><i class="fas fa-check"></i></span>';
        if ($core === 'notifications' && (int)($ctx['unread_notifications'] ?? 0) > 0) return '<span class="nav-badge">'.min(99,(int)$ctx['unread_notifications']).'</span>';
        return '';
    }
}
