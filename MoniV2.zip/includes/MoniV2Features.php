<?php
/**
 * v2 feature layer.
 * New functionality is isolated here so existing settings and flows remain backward compatible.
 */
if (defined('MONI_V2_FEATURES_LOADED')) return;
define('MONI_V2_FEATURES_LOADED', true);

function moni_v2_site_name(): string {
    return trim((string)getSetting('site_name', 'SMM Panel')) ?: 'SMM Panel';
}

/* ------------------------- Customer API request history ------------------------- */
function moni_api_log_safe_payload(array $data): array {
    $out=[];
    foreach($data as $k=>$v){
        $key=strtolower((string)$k);
        if(preg_match('/(?:key|token|secret|password|authorization|cookie|csrf|card|cvv)/i',$key)){$out[$k]='***';continue;}
        if(is_array($v)){$out[$k]=moni_api_log_safe_payload(array_slice($v,0,30,true));continue;}
        if(is_scalar($v))$out[$k]=mb_substr((string)$v,0,1000,'UTF-8');
    }
    return $out;
}
function moni_api_request_log(PDO $db, array $ctx): void {
    if(!moni_table_ready($db,'customer_api_request_logs'))return;
    try{
        $request=moni_api_log_safe_payload(is_array($ctx['request']??null)?$ctx['request']:[]);
        $response=$ctx['response']??null;
        if(is_array($response))$response=moni_api_log_safe_payload($response);
        elseif(is_scalar($response))$response=mb_substr((string)$response,0,2000,'UTF-8');
        $db->prepare("INSERT INTO customer_api_request_logs(api_client_id,user_id,endpoint,action,http_method,ip_address,http_status,duration_ms,request_json,response_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,NOW())")
           ->execute([
               !empty($ctx['api_client_id'])?(int)$ctx['api_client_id']:null,
               !empty($ctx['user_id'])?(int)$ctx['user_id']:null,
               mb_substr((string)($ctx['endpoint']??''),0,190,'UTF-8'),
               mb_substr((string)($ctx['action']??''),0,80,'UTF-8'),
               mb_substr((string)($ctx['http_method']??($_SERVER['REQUEST_METHOD']??'GET')),0,10,'UTF-8'),
               mb_substr((string)($ctx['ip']??moni_client_ip()),0,45,'UTF-8'),
               max(100,min(599,(int)($ctx['http_status']??200))),
               max(0,(int)($ctx['duration_ms']??0)),
               json_encode($request,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE),
               json_encode($response,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE)
           ]);
    }catch(Throwable $e){error_log('API history log failed: '.$e->getMessage());}
}

/* ------------------------- Smart provider service matcher ------------------------- */
function moni_match_normalize(string $s): string {
    $s=mb_strtolower($s,'UTF-8');
    $map=['ı'=>'i','İ'=>'i','ş'=>'s','Ş'=>'s','ğ'=>'g','Ğ'=>'g','ü'=>'u','Ü'=>'u','ö'=>'o','Ö'=>'o','ç'=>'c','Ç'=>'c'];
    $s=strtr($s,$map);$s=preg_replace('/[^a-z0-9]+/u',' ', $s);$s=trim(preg_replace('/\s+/',' ',$s));return $s;
}
function moni_match_tokens(string $s): array {
    $stop=['instagram','facebook','youtube','tiktok','twitter','x','telegram','service','servis','real','gercek','high','quality','kalite'];
    $t=array_values(array_unique(array_filter(explode(' ',moni_match_normalize($s)),static function($x)use($stop){return strlen($x)>1&&!in_array($x,$stop,true);})));sort($t);return $t;
}
function moni_service_match_score(array $local,array $remote): int {
    $ln=moni_match_normalize((string)($local['name']??''));$rn=moni_match_normalize((string)($remote['name']??''));
    if($ln===''||$rn==='')return 0;$lt=moni_match_tokens($ln);$rt=moni_match_tokens($rn);$union=array_unique(array_merge($lt,$rt));$inter=array_intersect($lt,$rt);
    $tokenScore=$union?count($inter)/count($union):0.0;similar_text($ln,$rn,$similar);
    $score=($tokenScore*55)+($similar*0.35);
    $lmin=(int)($local['min_quantity']??0);$lmax=(int)($local['max_quantity']??0);$rmin=(int)($remote['min']??0);$rmax=(int)($remote['max']??0);
    if($lmin>0&&$rmin>0){$ratio=min($lmin,$rmin)/max($lmin,$rmin);$score+=5*$ratio;}
    if($lmax>0&&$rmax>0){$ratio=min($lmax,$rmax)/max($lmax,$rmax);$score+=5*$ratio;}
    return max(0,min(100,(int)round($score)));
}
function moni_provider_match_suggestions(PDO $db,int $providerId,int $limit=500): array {
    if(!moni_plugin_enabled('provider_smart_matcher',$db))return ['ok'=>false,'error'=>'Akıllı eşleştirme eklentisi kapalı.','rows'=>[]];
    $q=$db->prepare("SELECT * FROM api_providers WHERE id=? AND status='active' LIMIT 1");$q->execute([$providerId]);$p=$q->fetch(PDO::FETCH_ASSOC);if(!$p)return ['ok'=>false,'error'=>'Aktif sağlayıcı bulunamadı.','rows'=>[]];
    $cat=moni_provider_catalog($db,$p);if(empty($cat['ok']))return ['ok'=>false,'error'=>$cat['error']??'Servis listesi alınamadı.','rows'=>[]];
    $local=$db->query("SELECT s.id,s.name,s.min_quantity,s.max_quantity,s.api_provider_id,s.api_service_id,c.name category_name FROM services s LEFT JOIN categories c ON c.id=s.category_id WHERE s.deleted_at IS NULL ORDER BY s.name LIMIT 5000")->fetchAll(PDO::FETCH_ASSOC);
    $rows=[];$remoteRows=array_slice($cat['services'],0,max(1,min(2000,$limit)));
    foreach($remoteRows as $r){
        $rid=(string)($r['service']??$r['id']??'');if($rid==='')continue;$best=null;$bestScore=-1;
        foreach($local as $l){$score=moni_service_match_score($l,$r);if($score>$bestScore){$bestScore=$score;$best=$l;}}
        $rows[]=['remote'=>$r,'remote_id'=>$rid,'remote_name'=>(string)($r['name']??('Servis '.$rid)),'local'=>$best,'score'=>$bestScore];
    }
    usort($rows,static fn($a,$b)=>$b['score']<=>$a['score']);return ['ok'=>true,'provider'=>$p,'rows'=>$rows];
}

/* ------------------------- Real delivery time estimates ------------------------- */
function moni_human_duration(int $seconds): string {
    if($seconds<60)return max(1,$seconds).' sn';$minutes=(int)round($seconds/60);
    if($minutes<60)return $minutes.' dk';$hours=$minutes/60;
    if($hours<48)return rtrim(rtrim(number_format($hours,1,'.',''),'0'),'.').' saat';$days=$hours/24;
    return rtrim(rtrim(number_format($days,1,'.',''),'0'),'.').' gün';
}
function moni_service_delivery_estimate(PDO $db,int $serviceId,int $sample=60): array {
    if(!moni_plugin_enabled('real_delivery_eta',$db))return ['available'=>false,'sample'=>0];
    static $cache=[];$key=$serviceId.':'.$sample;if(isset($cache[$key]))return $cache[$key];
    try{
        $sample=max(3,min(250,$sample));$s=$db->prepare("SELECT TIMESTAMPDIFF(SECOND,created_at,updated_at) seconds FROM orders WHERE service_id=? AND status='completed' AND updated_at>created_at ORDER BY id DESC LIMIT $sample");$s->execute([$serviceId]);$d=array_values(array_filter(array_map('intval',$s->fetchAll(PDO::FETCH_COLUMN)),static fn($x)=>$x>0&&$x<7776000));
        if(count($d)<3)return $cache[$key]=['available'=>false,'sample'=>count($d)];sort($d);$n=count($d);$median=$n%2?$d[(int)floor($n/2)]:(int)round(($d[$n/2-1]+$d[$n/2])/2);$avg=(int)round(array_sum($d)/$n);$p80=$d[min($n-1,(int)floor(($n-1)*0.80))];
        return $cache[$key]=['available'=>true,'sample'=>$n,'median_seconds'=>$median,'average_seconds'=>$avg,'p80_seconds'=>$p80,'label'=>moni_human_duration($median),'range'=>'Genelde '.moni_human_duration($median).' · %80 '.moni_human_duration($p80).' içinde'];
    }catch(Throwable $e){return $cache[$key]=['available'=>false,'sample'=>0];}
}

/* ------------------------- Notification Preference Center ------------------------- */
function moni_notification_category(string $type): string {
    $t=mb_strtolower($type,'UTF-8');
    if(preg_match('/security|login|password|2fa|webauthn|device|oturum|güven/i',$t))return 'security';
    if(preg_match('/payment|wallet|deposit|invoice|refund|coupon|balance|ödeme|bakiye/i',$t))return 'payments';
    if(preg_match('/support|ticket|destek/i',$t))return 'support';
    if(preg_match('/favorite|service|provider|price|status|servis|fiyat/i',$t))return 'service_alerts';
    if(preg_match('/campaign|promo|marketing|announcement|duyuru/i',$t))return 'marketing';
    return 'orders';
}
function moni_notification_pref(PDO $db,int $userId,string $category): array {
    $defaults=['in_app'=>1,'email'=>1,'push'=>1];
    if(!moni_plugin_enabled('notification_preferences',$db)||!moni_table_ready($db,'notification_preferences'))return $defaults;
    try{$s=$db->prepare("SELECT in_app_enabled,email_enabled,COALESCE(push_enabled,1) push_enabled FROM notification_preferences WHERE user_id=? AND category=? LIMIT 1");$s->execute([$userId,$category]);$r=$s->fetch(PDO::FETCH_ASSOC);return $r?['in_app'=>(int)$r['in_app_enabled'],'email'=>(int)$r['email_enabled'],'push'=>(int)$r['push_enabled']]:$defaults;}catch(Throwable $e){return $defaults;}
}
function moni_notification_allowed(PDO $db,int $userId,string $type,string $channel='in_app'): bool {
    $cat=moni_notification_category($type);if($cat==='security'&&$channel==='in_app')return true;$p=moni_notification_pref($db,$userId,$cat);return !empty($p[$channel]);
}

/* ------------------------- Favorite service price/status alerts ------------------------- */
function moni_process_favorite_service_alerts(PDO $db,int $batch=250): array {
    if(!moni_table_ready($db,'favorite_service_alert_state')||!moni_table_ready($db,'user_favorites'))return ['processed'=>0,'message'=>'Favori servis alarm tabloları hazır değil.'];
    $batch=max(1,min(2000,$batch));$sql="SELECT f.user_id,f.service_id,s.name,s.price_per_1000,s.status,st.last_price,st.last_status,st.id state_id FROM user_favorites f JOIN services s ON s.id=f.service_id LEFT JOIN favorite_service_alert_state st ON st.user_id=f.user_id AND st.service_id=f.service_id ORDER BY COALESCE(st.updated_at,'1970-01-01') ASC LIMIT $batch";$rows=$db->query($sql)->fetchAll(PDO::FETCH_ASSOC);$n=0;$alerts=0;
    foreach($rows as $r){$price=(float)$r['price_per_1000'];$status=(string)$r['status'];
        if(empty($r['state_id'])){$db->prepare("INSERT IGNORE INTO favorite_service_alert_state(user_id,service_id,last_price,last_status,initialized_at,updated_at) VALUES(?,?,?,?,NOW(),NOW())")->execute([(int)$r['user_id'],(int)$r['service_id'],$price,$status]);$n++;continue;}
        $changes=[];if((string)$r['last_status']!==$status)$changes[]='durum: '.(string)$r['last_status'].' → '.$status;if(abs((float)$r['last_price']-$price)>0.0001)$changes[]='fiyat: '.number_format((float)$r['last_price'],4).' → '.number_format($price,4);
        if($changes&&function_exists('moni_user_notify')){$uid=(int)$r['user_id'];$message=(string)$r['name'].' · '.implode(' · ',$changes);$id=moni_user_notify($db,$uid,'favorite_service','Favori servisiniz güncellendi',$message,'/kullanici/services.php','info');if($id)$alerts++;if(function_exists('moni_notification_allowed')&&moni_notification_allowed($db,$uid,'favorite_service','email')&&function_exists('sendEmail')){try{$em=$db->prepare("SELECT email FROM users WHERE id=? LIMIT 1");$em->execute([$uid]);$email=(string)$em->fetchColumn();if($email!=='')sendEmail($email,moni_v2_site_name().' - Favori servis güncellendi','<p>'.htmlspecialchars($message,ENT_QUOTES,'UTF-8').'</p>');}catch(Throwable $ignore){}}}
        $db->prepare("UPDATE favorite_service_alert_state SET last_price=?,last_status=?,last_notified_at=IF(?,NOW(),last_notified_at),updated_at=NOW() WHERE id=?")->execute([$price,$status,$changes?1:0,(int)$r['state_id']]);$n++;
    }
    return ['processed'=>$n,'message'=>"$n favori servis kontrol edildi; $alerts bildirim üretildi."];
}

/* ------------------------- CAPTCHA: Cloudflare Turnstile / hCaptcha ------------------------- */
function moni_captcha_config(PDO $db): array {
    $provider=(string)moni_plugin_setting('human_captcha','provider','turnstile');if(!in_array($provider,['turnstile','hcaptcha'],true))$provider='turnstile';
    return ['enabled'=>moni_plugin_enabled('human_captcha',$db),'provider'=>$provider,'site_key'=>(string)moni_plugin_setting('human_captcha','site_key',''),'secret_key'=>moni_decrypt_secret((string)moni_plugin_setting('human_captcha','secret_key',''))];
}
function moni_captcha_render(PDO $db): string {
    $c=moni_captcha_config($db);if(empty($c['enabled']))return '';if($c['site_key']==='')return '<div class="alert alert-warning">CAPTCHA etkin ancak site anahtarı yapılandırılmamış.</div>';
    $key=htmlspecialchars($c['site_key'],ENT_QUOTES,'UTF-8');
    if($c['provider']==='hcaptcha')return '<script src="https://js.hcaptcha.com/1/api.js" async defer></script><div class="h-captcha" data-sitekey="'.$key.'"></div>';
    return '<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script><div class="cf-turnstile" data-sitekey="'.$key.'"></div>';
}
function moni_captcha_verify_request(PDO $db,?string &$error=null): bool {
    $c=moni_captcha_config($db);if(empty($c['enabled']))return true;if($c['site_key']===''||$c['secret_key']===''){ $error='CAPTCHA yapılandırması eksik. Yöneticiyle iletişime geçin.';return false;}
    $field=$c['provider']==='hcaptcha'?'h-captcha-response':'cf-turnstile-response';$token=trim((string)($_POST[$field]??''));if($token===''){ $error='Lütfen insan doğrulamasını tamamlayın.';return false;}
    $url=$c['provider']==='hcaptcha'?'https://hcaptcha.com/siteverify':'https://challenges.cloudflare.com/turnstile/v0/siteverify';
    if(!function_exists('curl_init')){$error='CAPTCHA doğrulaması için cURL gerekli.';return false;}
    $ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>http_build_query(['secret'=>$c['secret_key'],'response'=>$token,'remoteip'=>moni_client_ip()]),CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>12,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_FOLLOWLOCATION=>false]);$raw=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$ce=curl_error($ch);curl_close($ch);$j=json_decode($raw?:'',true);
    if($ce||$http<200||$http>=300||!is_array($j)||empty($j['success'])){$error='İnsan doğrulaması başarısız. Lütfen tekrar deneyin.';return false;}return true;
}

/* ------------------------- Child Panel SMTP / payment privileges ------------------------- */
function moni_child_panel_by_id(PDO $db,int $panelId): ?array {try{$s=$db->prepare("SELECT * FROM child_panels WHERE id=? LIMIT 1");$s->execute([$panelId]);return $s->fetch(PDO::FETCH_ASSOC)?:null;}catch(Throwable $e){return null;}}
function moni_child_panel_smtp_settings(PDO $db,?int $panelId=null): ?array {
    if($panelId===null){$c=function_exists('moni_child_panel_context')?moni_child_panel_context($db):null;$panelId=(int)($c['id']??0);}if(!$panelId||!moni_table_ready($db,'child_panel_smtp_settings'))return null;$p=moni_child_panel_by_id($db,$panelId);if(!$p||empty($p['allow_custom_smtp']))return null;
    try{$s=$db->prepare("SELECT * FROM child_panel_smtp_settings WHERE child_panel_id=? AND is_enabled=1 LIMIT 1");$s->execute([$panelId]);$r=$s->fetch(PDO::FETCH_ASSOC);if(!$r)return null;$host=strtolower(trim((string)($r['smtp_host']??'')));if($host===''||!function_exists('moni_resolve_public_host')||moni_resolve_public_host(trim($host,'[]'))===null)return null;$r['smtp_password']=moni_decrypt_secret((string)$r['smtp_password']);return $r;}catch(Throwable $e){return null;}
}
function moni_child_panel_payment_config(PDO $db,string $type,?int $panelId=null,bool $activeOnly=true): ?array {
    if($panelId===null){$c=function_exists('moni_child_panel_context')?moni_child_panel_context($db):null;$panelId=(int)($c['id']??0);}if(!$panelId||!moni_table_ready($db,'child_panel_payment_methods'))return null;$p=moni_child_panel_by_id($db,$panelId);if(!$p||empty($p['allow_custom_payments']))return null;
    try{$sql="SELECT * FROM child_panel_payment_methods WHERE child_panel_id=? AND type=?".($activeOnly?" AND is_enabled=1":"")." LIMIT 1";$s=$db->prepare($sql);$s->execute([$panelId,$type]);$r=$s->fetch(PDO::FETCH_ASSOC);if(!$r)return null;$cfg=json_decode((string)($r['config_json']??'{}'),true)?:[];if($type==='iyzico'&&!in_array((string)($cfg['base_url']??''),['https://sandbox-api.iyzipay.com','https://api.iyzipay.com'],true))return null;foreach(['api_key','secret_key','merchant_key','client_secret'] as $k)if(isset($cfg[$k]))$cfg[$k]=moni_decrypt_secret((string)$cfg[$k]);$r['config']=$cfg;return $r;}catch(Throwable $e){return null;}
}
function moni_child_panel_bank_accounts(PDO $db,?int $panelId=null): array {
    if($panelId===null){$c=function_exists('moni_child_panel_context')?moni_child_panel_context($db):null;$panelId=(int)($c['id']??0);}if(!$panelId||!moni_table_ready($db,'child_panel_bank_accounts'))return [];$p=moni_child_panel_by_id($db,$panelId);if(!$p||empty($p['allow_custom_payments']))return [];
    try{$s=$db->prepare("SELECT * FROM child_panel_bank_accounts WHERE child_panel_id=? AND is_active=1 ORDER BY sort_order,id");$s->execute([$panelId]);return $s->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){return [];}
}
function moni_child_email_template(PDO $db,int $panelId,string $slug): ?array {
    if(!$panelId||!moni_table_ready($db,'child_panel_email_templates'))return null;$p=moni_child_panel_by_id($db,$panelId);if(!$p||empty($p['allow_custom_smtp']))return null;try{$s=$db->prepare("SELECT * FROM child_panel_email_templates WHERE child_panel_id=? AND slug=? AND is_active=1 LIMIT 1");$s->execute([$panelId,$slug]);return $s->fetch(PDO::FETCH_ASSOC)?:null;}catch(Throwable $e){return null;}
}
