<?php
if (defined('MONI_CRON_LOADED')) return;
define('MONI_CRON_LOADED', true);

function moni_cron_log(string $message):void{
    $dir=dirname(__DIR__).'/logs';if(!is_dir($dir))@mkdir($dir,0755,true);
    @file_put_contents($dir.'/cronmoni_'.date('Y-m-d').'.log','['.date('Y-m-d H:i:s').'] '.$message."\n",FILE_APPEND|LOCK_EX);
    if(PHP_SAPI==='cli')echo $message."\n";
}


/**
 * Sağlayıcı maliyetlerini sitenin baz para birimine çevirir.
 * Önce admin tarafından tanımlanan currencies oranını, yoksa saatlik TLS doğrulamalı
 * kur önbelleğini kullanır. Harici servis erişilemezse mevcut son önbellek/fallback korunur.
 */
function moni_cron_rate_to_base(PDO $db,string $currency):float{
    $currency=strtoupper(trim($currency));
    if($currency==='TL')$currency='TRY';
    $base=moni_base_currency($db);if($base==='TL')$base='TRY';
    if($currency===''||$currency===$base)return 1.0;

    if(moni_table_ready($db,'currencies')){
        try{$st=$db->prepare("SELECT rate_to_base FROM currencies WHERE code=? AND is_active=1 AND rate_to_base>0 LIMIT 1");$st->execute([$currency]);$r=$st->fetchColumn();if($r!==false&&(float)$r>0)return (float)$r;}catch(Throwable $ignore){}
    }

    $cache=dirname(__DIR__).'/cache/exchange_rates_'.preg_replace('/[^A-Z0-9]/','',$base).'.json';
    $payload=null;
    if(is_file($cache)){
        $decoded=json_decode((string)@file_get_contents($cache),true);
        if(is_array($decoded))$payload=$decoded;
    }
    $fresh=$payload&&!empty($payload['updated_at'])&&(time()-(int)$payload['updated_at']<3600);
    if(!$fresh&&function_exists('curl_init')){
        $url='https://api.exchangerate-api.com/v4/latest/'.rawurlencode($base);
        $ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>10,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_FOLLOWLOCATION=>false]);
        $raw=curl_exec($ch);$err=curl_error($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
        $j=json_decode($raw?:'',true);
        if(!$err&&$http>=200&&$http<300&&is_array($j)&&!empty($j['rates'])&&is_array($j['rates'])){
            $payload=['updated_at'=>time(),'rates'=>$j['rates']];
            @file_put_contents($cache,json_encode($payload,JSON_UNESCAPED_SLASHES),LOCK_EX);
        }
    }
    if($payload&&isset($payload['rates'][$currency])&&(float)$payload['rates'][$currency]>0){
        // Endpoint: 1 BASE = N CURRENCY. Bu nedenle 1 CURRENCY = 1/N BASE.
        return 1/(float)$payload['rates'][$currency];
    }

    // Eski panelin TRY fallback davranışını koru; yalnız harici kur ve admin oranı yoksa kullanılır.
    if($base==='TRY'){
        $fallback=['USD'=>33.50,'EUR'=>36.50,'GBP'=>41.00,'INR'=>0.39,'RUB'=>0.35,'BDT'=>0.27,'IDR'=>0.002,'PKR'=>0.11];
        if(isset($fallback[$currency]))return (float)$fallback[$currency];
    }
    return 1.0;
}

function moni_cron_notify_admins(PDO $db,string $subject,string $html):int{
    $mailFile=__DIR__.'/mail.php';if(!is_file($mailFile))return 0;require_once $mailFile;
    if(!function_exists('sendEmail'))return 0;
    try{$admins=$db->query("SELECT email FROM users WHERE role='admin' AND status='active' AND email<>''")->fetchAll(PDO::FETCH_COLUMN);}catch(Throwable $e){return 0;}
    $sent=0;foreach($admins as $email){$r=sendEmail($email,$subject,$html);if($r===true||(is_array($r)&&!empty($r['success'])))$sent++;}return $sent;
}

function moni_cron_provider_balance_notice(PDO $db,array $provider,float $balance,string $currency):void{
    $currency=strtoupper($currency?:'USD');$isLow=false;$limit='';
    if($currency==='USD'&&$balance<10){$isLow=true;$limit='10 USD';}
    elseif(($currency==='TRY'||$currency==='TL')&&$balance<75){$isLow=true;$limit='75 TL';}
    elseif(!in_array($currency,['USD','TRY','TL'],true)){
        $legacyRate=$currency==='EUR'?35:($currency==='GBP'?41:1);
        if(($balance*$legacyRate)<75){$isLow=true;$limit='75 TL karşılığı';}
    }
    $key='provider_low_balance_notice_'.(int)$provider['id'];
    if(!$isLow){if(getSetting($key,'')!=='ok')updateSetting($key,'ok');return;}
    $previous=(string)getSetting($key,'');$last=0;if(str_starts_with($previous,'low:'))$last=(int)substr($previous,4);
    // Eski uyarıyı koru ama merkezi cron her dakika tetiklendiğinde mail bombardımanı yapmasın.
    if($last>0&&time()-$last<21600)return;
    $name=htmlspecialchars((string)($provider['name']??'Sağlayıcı'),ENT_QUOTES,'UTF-8');$cur=htmlspecialchars($currency,ENT_QUOTES,'UTF-8');$lim=htmlspecialchars($limit,ENT_QUOTES,'UTF-8');
    $body="<div style='font-family:Arial,sans-serif'><h2>Sağlayıcı Bakiye Uyarısı</h2><p><strong>{$name}</strong> bakiyesi güvenlik limitinin altına düştü.</p><p>Mevcut bakiye: <strong>".number_format($balance,4)." {$cur}</strong><br>Alt limit: <strong>{$lim}</strong></p></div>";
    $sent=moni_cron_notify_admins($db,'Sağlayıcı bakiyesi azaldı: '.($provider['name']??'#'.(int)$provider['id']),$body);
    if(function_exists('moni_admin_notify'))moni_admin_notify($db,'provider_low_balance','Sağlayıcı bakiyesi düşük',($provider['name']??('#'.(int)$provider['id'])).' bakiyesi '.number_format($balance,4).' '.$currency.' seviyesine düştü.','/admin/provider-operations.php','warning');
    if($sent>0)updateSetting($key,'low:'.time());
}
function moni_cron_run(PDO $db,?string $only=null):array{
    if(!moni_table_ready($db,'cron_tasks'))return ['ok'=>false,'message'=>'cron_tasks tablosu bulunamadı.'];
    $sql="SELECT * FROM cron_tasks WHERE is_enabled=1 AND (next_run_at IS NULL OR next_run_at<=NOW()) AND (locked_until IS NULL OR locked_until<NOW())";
    $params=[];if($only){$sql.=" AND task_key=?";$params[]=$only;}$sql.=" ORDER BY id";
    $s=$db->prepare($sql);$s->execute($params);$tasks=$s->fetchAll(PDO::FETCH_ASSOC);$summary=[];
    foreach($tasks as $task)$summary[$task['task_key']]=moni_cron_execute_task($db,$task);
    return ['ok'=>true,'tasks'=>$summary,'count'=>count($summary)];
}
function moni_cron_execute_task(PDO $db,array $task):array{
    $key=$task['task_key'];
    if($key==='premium_memberships' && (!function_exists('moni_plugin_enabled') || !moni_plugin_enabled('premium_memberships',$db)))return ['status'=>'skipped','processed'=>0,'message'=>'Premium Üyelik eklentisi pasif.'];
    $batch=max(1,min(5000,(int)$task['batch_size']));$interval=max(1,min(10080,(int)$task['interval_minutes']));$started=microtime(true);
    $advisory='moni_cron_'.substr(hash('sha256',$key),0,40);$hasAdvisory=false;
    try{
        $g=$db->prepare("SELECT GET_LOCK(?,0)");$g->execute([$advisory]);$hasAdvisory=(int)$g->fetchColumn()===1;
        if(!$hasAdvisory)return ['status'=>'skipped','processed'=>0,'message'=>'Görev başka bir cron sürecinde çalışıyor.'];

        $lock=$db->prepare("UPDATE cron_tasks SET locked_until=DATE_ADD(NOW(),INTERVAL 10 MINUTE),last_started_at=NOW(),last_status='running' WHERE id=? AND (locked_until IS NULL OR locked_until<NOW())");
        $lock->execute([$task['id']]);
        if(!$lock->rowCount())return ['status'=>'skipped','processed'=>0,'message'=>'Görev veritabanı kilidinde.'];

        $db->prepare("INSERT INTO cron_runs(task_key,status,started_at) VALUES(?,'running',NOW())")->execute([$key]);$runId=(int)$db->lastInsertId();
        try{
            $fn='moni_cron_task_'.$key;if(!function_exists($fn))throw new RuntimeException('Cron görevi tanımlı değil: '.$key);
            $r=$fn($db,$batch);$processed=(int)($r['processed']??0);$msg=substr((string)($r['message']??'Tamamlandı.'),0,1000);$requestedStatus=strtolower((string)($r['status']??'success'));$status=in_array($requestedStatus,['success','error','skipped'],true)?$requestedStatus:'success';
        }catch(Throwable $e){$processed=0;$msg=substr($e->getMessage(),0,1000);$status='error';}
        $ms=(int)round((microtime(true)-$started)*1000);
        $db->prepare("UPDATE cron_runs SET finished_at=NOW(),status=?,processed_count=?,message=?,duration_ms=? WHERE id=?")->execute([$status,$processed,$msg,$ms,$runId]);
        $db->prepare("UPDATE cron_tasks SET locked_until=NULL,last_finished_at=NOW(),last_status=?,last_message=?,next_run_at=DATE_ADD(NOW(),INTERVAL ? MINUTE) WHERE id=?")->execute([$status,$msg,$interval,$task['id']]);
        if($status==='error' && ($task['last_status']??'')!=='error' && function_exists('moni_admin_notify'))moni_admin_notify($db,'cron_error','Cron görevi hata verdi',$key.': '.$msg,'/admin/cron-center.php','danger');
        moni_cron_log("[$key] $status | $processed işlem | $msg");
        return ['status'=>$status,'processed'=>$processed,'message'=>$msg,'duration_ms'=>$ms];
    }finally{
        if($hasAdvisory){try{$r=$db->prepare("SELECT RELEASE_LOCK(?)");$r->execute([$advisory]);}catch(Throwable $ignore){}}
    }
}


function moni_cron_task_service_auto_badges(PDO $db,int $batch):array{
    if(!function_exists('moni_plugin_enabled')||!moni_plugin_enabled('service_auto_badges',$db))return ['processed'=>0,'message'=>'Otomatik Servis Rozet Motoru eklentisi pasif.'];
    if(!function_exists('moni_recalculate_service_auto_badges'))return ['processed'=>0,'message'=>'Rozet motoru yüklenmedi.'];
    $r=moni_recalculate_service_auto_badges($db,$batch);
    return ['processed'=>(int)($r['processed']??0),'message'=>(int)($r['badges']??0).' otomatik rozet güncellendi.'];
}
function moni_cron_task_provider_health(PDO $db,int $batch):array{
    $s=$db->prepare("SELECT * FROM api_providers WHERE status='active' ORDER BY COALESCE(last_sync,'1970-01-01') ASC LIMIT $batch");$s->execute();$n=0;$low=0;
    foreach($s->fetchAll(PDO::FETCH_ASSOC) as $p){
        $requestProvider=$p;$requestProvider['api_key']=moni_decrypt_secret($p['api_key']);
        $r=moni_provider_request($requestProvider,['action'=>'balance'],'balance');
        if($r['success']){
            $d=$r['data'];$bal=(float)($d['balance']??0);$cur=strtoupper((string)($d['currency']??$p['currency']??'USD'));
            $db->prepare("UPDATE api_providers SET balance=?,currency=COALESCE(NULLIF(?,''),currency),last_sync=NOW() WHERE id=?")->execute([$bal,$cur,$p['id']]);
            if(function_exists('moni_snapshot_provider_balance'))moni_snapshot_provider_balance($db,(int)$p['id'],$bal,$cur);
            $before=(string)getSetting('provider_low_balance_notice_'.(int)$p['id'],'');
            moni_cron_provider_balance_notice($db,$p,$bal,$cur);
            $after=(string)getSetting('provider_low_balance_notice_'.(int)$p['id'],'');if($after!==$before&&str_starts_with($after,'low:'))$low++;
        }
        $n++;
    }
    return ['processed'=>$n,'message'=>'Sağlayıcı sağlık/bakiye kontrolü tamamlandı.'.($low?" $low düşük bakiye uyarısı gönderildi.":'')];
}
function moni_cron_task_sync_prices(PDO $db,int $batch):array{
    $providers=$db->query("SELECT * FROM api_providers WHERE status='active' ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);$updated=0;$seen=0;$raised=[];
    foreach($providers as $p){
        if($seen >= $batch)break;
        $requestProvider=$p;$requestProvider['api_key']=moni_decrypt_secret($p['api_key']);
        $r=moni_provider_request($requestProvider,['action'=>'services'],'services',60);if(!$r['success']||!is_array($r['data']))continue;
        $map=[];foreach($r['data'] as $remote)if(isset($remote['service']))$map[(string)$remote['service']]=$remote;
        $remaining=max(1,$batch-$seen);
        $q="SELECT * FROM services WHERE api_provider_id=? AND api_service_id IS NOT NULL AND status<>'inactive' ORDER BY id LIMIT ".(int)$remaining;
        $st=$db->prepare($q);$st->execute([$p['id']]);$rateToBase=moni_cron_rate_to_base($db,(string)($p['currency']??'USD'));
        foreach($st->fetchAll(PDO::FETCH_ASSOC) as $svc){
            $seen++;$rr=$map[(string)$svc['api_service_id']]??null;if(!$rr)continue;
            $remoteCost=(float)($rr['rate']??0);if($remoteCost<=0)continue;$cost=$remoteCost*$rateToBase;
            $tmp=$svc;$tmp['cost_per_1000']=$cost;$floor=moni_minimum_sale_price($tmp);$oldSale=(float)$svc['price_per_1000'];
            // Yeni minimum kâr koruması aktifse provider maliyet senkronizasyonu da aynı politikayı
            // anında uygular; kapalıysa eski %20 güvenlik davranışı aynen korunur.
            if($floor<=0&&$oldSale<=$cost){
                if((string)getSetting('min_profit_protection_enabled','0')==='1'){
                    $pt=(string)getSetting('min_profit_protection_type','percent');$pv=max(0,(float)getSetting('min_profit_protection_value','20'));
                    $floor=$pt==='fixed'?$cost+$pv:$cost*(1+$pv/100);
                }else{$floor=$cost*1.20;}
            }
            $sale=max($oldSale,$floor);$db->prepare("UPDATE services SET cost_per_1000=?,price_per_1000=?,updated_at=NOW() WHERE id=?")->execute([$cost,$sale,$svc['id']]);$updated++;
            if($sale>$oldSale+0.0000001)$raised[]=['id'=>(int)$svc['id'],'name'=>(string)$svc['name'],'cost'=>$cost,'old'=>$oldSale,'new'=>$sale];
        }
    }
    if($raised){
        $rows='';foreach(array_slice($raised,0,100) as $x){$rows.='<tr><td>'.(int)$x['id'].'</td><td>'.htmlspecialchars($x['name'],ENT_QUOTES,'UTF-8').'</td><td>'.number_format($x['cost'],4).'</td><td>'.number_format($x['old'],4).'</td><td>'.number_format($x['new'],4).'</td></tr>';}
        $html="<div style='font-family:Arial,sans-serif'><h3>Fiyat Koruma Raporu</h3><p>Zarar/minimum kâr politikasına takılan servislerin satış fiyatı yükseltildi.</p><table border='1' cellpadding='5' cellspacing='0'><tr><th>ID</th><th>Servis</th><th>Maliyet</th><th>Eski Satış</th><th>Yeni Satış</th></tr>{$rows}</table></div>";
        moni_cron_notify_admins($db,'Fiyat Koruma Raporu',$html);
        if(function_exists('moni_admin_notify'))moni_admin_notify($db,'price_protection','Fiyat koruma politikası uygulandı',count($raised).' servisin satış fiyatı minimum kâr politikasına göre yükseltildi.','/admin/provider-operations.php','info');
    }
    return ['processed'=>$seen,'message'=>"$updated servis maliyeti senkronize edildi; ".count($raised)." servis fiyatı koruma politikasıyla yükseltildi."];
}
function moni_cron_task_update_orders(PDO $db,int $batch):array{
    $s=$db->prepare("SELECT o.* FROM orders o WHERE o.api_order_id IS NOT NULL AND o.status IN('pending','processing','in_progress') AND o.created_at>DATE_SUB(NOW(),INTERVAL 30 DAY) ORDER BY o.updated_at ASC LIMIT $batch");$s->execute();$n=0;
    foreach($s->fetchAll(PDO::FETCH_ASSOC) as $o){
        $r=moni_provider_status($db,$o);
        if(empty($r['success'])){
            // Aynı arızalı siparişin her batch'in başını sonsuza kadar işgal etmesini engelle.
            $db->prepare("UPDATE orders SET updated_at=NOW() WHERE id=?")->execute([$o['id']]);$n++;continue;
        }
        $applied=moni_apply_provider_status($db,(int)$o['id'],$r);
        if(empty($applied['success']))moni_cron_log('[update_orders] #'.$o['id'].' durum uygulama hatası: '.($applied['error']??'bilinmeyen'));
        $n++;
    }
    return ['processed'=>$n,'message'=>'Sipariş durumları ve idempotent iadeler güncellendi.'];
}
function moni_cron_task_scheduled_orders(PDO $db,int $batch):array{
    if(function_exists('moni_partial_maintenance_active')&&moni_partial_maintenance_active($db,'orders',false))return ['processed'=>0,'message'=>'Kısmi bakım: yeni sipariş üretimi duraklatıldı.'];
    // Eski/yarım yükseltilmiş sitelerde geo kolonları eksik olsa bile scheduled worker durmamalı.
    $hasGeo=function_exists('moni_v2_compat_column_exists') ? moni_v2_compat_column_exists($db,'services','geo_supported') : false;
    if(!$hasGeo){try{$hasGeo=(bool)$db->query("SHOW COLUMNS FROM services LIKE 'geo_supported'")->fetch(PDO::FETCH_ASSOC);}catch(Throwable $e){$hasGeo=false;}}
    $geoSelect=$hasGeo ? "s.geo_supported,s.geo_targets_json,s.geo_target_param" : "0 AS geo_supported,NULL AS geo_targets_json,'country' AS geo_target_param";
    $s=$db->prepare("SELECT so.*,s.api_provider_id,s.api_service_id,s.name service_name,s.category_id,s.cost_per_1000,s.price_per_1000,s.refill,s.refill_days,s.refill_count,s.overflow_percent,$geoSelect FROM scheduled_orders so JOIN services s ON s.id=so.service_id WHERE so.status='active' AND so.type='scheduled' AND so.scheduled_time<=NOW() ORDER BY so.scheduled_time ASC LIMIT $batch");$s->execute();$n=0;
    foreach($s->fetchAll(PDO::FETCH_ASSOC) as $so){
        if(function_exists('moni_validate_service_target')){$tv=moni_validate_service_target($db,(int)$so['service_id'],(string)$so['link'],(int)$so['user_id'],'scheduled-cron');if(empty($tv['ok'])){if(function_exists('moni_refund_scheduled_order'))moni_refund_scheduled_order($db,(int)$so['id'],'Hedef politikası: '.($tv['error']??'hedef engellendi'));moni_cron_log('[scheduled_orders] #'.($so['id']??0).' hedef politikası nedeniyle iptal edildi.');$n++;continue;}}
        if(function_exists('moni_service_schedule_check')){$wh=moni_service_schedule_check($db,(int)$so['service_id']);if(empty($wh['open'])){$db->prepare("UPDATE scheduled_orders SET scheduled_time=DATE_ADD(NOW(),INTERVAL 5 MINUTE),updated_at=NOW() WHERE id=? AND status='active'")->execute([$so['id']]);$n++;continue;}}
        $db->beginTransaction();
        try{
            $lock=$db->prepare("SELECT status FROM scheduled_orders WHERE id=? FOR UPDATE");$lock->execute([$so['id']]);
            if($lock->fetchColumn()!=='active'){$db->rollBack();continue;}
            $db->prepare("UPDATE scheduled_orders SET status='completed',updated_at=NOW() WHERE id=?")->execute([$so['id']]);
            $providerQty=(int)$so['quantity'];$overflow=max(0,min(500,(float)($so['overflow_percent']??0)));if($overflow>0)$providerQty=(int)ceil($providerQty*(1+$overflow/100));
            $db->prepare("INSERT INTO orders(user_id,service_id,api_provider_id,link,quantity,provider_quantity,price,status,refill_enabled,refill_until,refill_max,geo_target,created_at) VALUES(?,?,?,?,?,?,?,'pending',?,?,?,?,NOW())")
               ->execute([$so['user_id'],$so['service_id'],$so['api_provider_id']?:null,$so['link'],$so['quantity'],$providerQty,$so['price'],(int)($so['refill']??0),!empty($so['refill_days'])?date('Y-m-d',strtotime('+'.(int)$so['refill_days'].' days')):null,(int)($so['refill_count']??0),$so['geo_target']??null]);
            $oid=(int)$db->lastInsertId();$db->commit();
            $so['_order_quantity']=(int)$so['quantity'];
            $so['_provider_quantity']=$providerQty;
            moni_record_order_snapshot($db,$oid,$so,(float)$so['price']*1000/max(1,(int)$so['quantity']));
            if(function_exists('moni_capture_start_count'))moni_capture_start_count($db,$oid,(string)$so['link']);
            // Zamanlanmış sipariş de web isteği gibi provider'a doğrudan gitmez; merkezi dispatch kuyruğu işler.
            if((int)($so['api_provider_id']??0)>0 && (string)($so['api_service_id']??'')!==''){
                if(function_exists('moni_enqueue_order_dispatch')){moni_enqueue_order_dispatch($db,$oid);}
                elseif(function_exists('moni_table_ready')&&moni_table_ready($db,'order_dispatch_jobs')){$db->prepare("INSERT IGNORE INTO order_dispatch_jobs(order_id,status,created_at,updated_at) VALUES(?,'queued',NOW(),NOW())")->execute([$oid]);}
            }
            $n++;
        }catch(Throwable $e){if($db->inTransaction())$db->rollBack();moni_cron_log('[scheduled_orders] #'.($so['id']??0).' hata: '.$e->getMessage());}
    }
    return ['processed'=>$n,'message'=>'Süreli siparişler işlendi.'];
}
function moni_dripfeed_previous_run_gate(PDO $db,array $df):array{
    $dfId=(int)($df['df_id']??$df['id']??0);
    if($dfId<=0 || (int)($df['completed_runs']??0)<=0)return ['ready'=>true];

    // Sadece sağlayıcı tarafından gerçekten kabul edilmiş son parçayı kontrol et.
    // Daha önce link_duplicate gibi nedenlerle hiç oluşturulamamış deneme kayıtları bu kapıya takılmaz.
    $q=$db->prepare("SELECT * FROM orders WHERE dripfeed_id=? AND api_order_id IS NOT NULL AND api_order_id<>'' ORDER BY id DESC LIMIT 1");
    $q->execute([$dfId]);
    $prev=$q->fetch(PDO::FETCH_ASSOC);
    if(!$prev)return ['ready'=>true];

    $status=(string)($prev['status']??'pending');
    if(in_array($status,['pending','processing','in_progress'],true)){
        $pr=moni_provider_status($db,$prev);
        if(empty($pr['success'])){
            $msg='Önceki dripfeed parçasının sağlayıcı durumu doğrulanamadı; yeni parça güvenli şekilde bekletildi.';
            $db->prepare("UPDATE orders_dripfeed SET next_run_at=DATE_ADD(NOW(),INTERVAL 5 MINUTE),last_error=?,updated_at=NOW() WHERE id=? AND status='active'")->execute([$msg,$dfId]);
            moni_cron_log('[dripfeed] #'.$dfId.' önceki parça #'.(int)$prev['id'].' durum sorgusu başarısız: '.($pr['error']??'bilinmeyen'));
            return ['ready'=>false,'deferred'=>true,'reason'=>$msg];
        }
        $applied=moni_apply_provider_status($db,(int)$prev['id'],$pr);
        if(empty($applied['success'])){
            $msg='Önceki dripfeed parçasının durumu uygulanamadı; yeni parça bekletildi.';
            $db->prepare("UPDATE orders_dripfeed SET next_run_at=DATE_ADD(NOW(),INTERVAL 5 MINUTE),last_error=?,updated_at=NOW() WHERE id=? AND status='active'")->execute([$msg,$dfId]);
            moni_cron_log('[dripfeed] #'.$dfId.' önceki parça #'.(int)$prev['id'].' durum uygulama hatası: '.($applied['error']??'bilinmeyen'));
            return ['ready'=>false,'deferred'=>true,'reason'=>$msg];
        }
        $status=(string)($applied['status']??$status);
    }

    if(in_array($status,['pending','processing','in_progress'],true)){
        $msg='Önceki dripfeed parçası tamamlanıyor; sonraki parça tamamlanma sonrasına ertelendi.';
        $db->prepare("UPDATE orders_dripfeed SET next_run_at=DATE_ADD(NOW(),INTERVAL 5 MINUTE),last_error=?,updated_at=NOW() WHERE id=? AND status='active'")->execute([$msg,$dfId]);
        return ['ready'=>false,'deferred'=>true,'reason'=>$msg];
    }

    if(in_array($status,['cancelled','refunded','error'],true)){
        $reason='Önceki dripfeed parçası '.$status.' durumuna geçti; gönderilmemiş kalan parçalar iptal edildi.';
        $rr=function_exists('moni_refund_dripfeed_remaining')?moni_refund_dripfeed_remaining($db,$dfId,$reason):['ok'=>false,'error'=>'Dripfeed iade fonksiyonu yok.'];
        if(empty($rr['ok']))moni_cron_log('[dripfeed] #'.$dfId.' terminal parça sonrası kalan iade hatası: '.($rr['error']??'bilinmeyen'));
        return ['ready'=>false,'stopped'=>true,'reason'=>$reason,'refund'=>$rr];
    }

    // completed ve partial terminaldir; sonraki run gönderilebilir.
    if(in_array($status,['completed','partial'],true))return ['ready'=>true];

    $msg='Önceki dripfeed parçasının durumu kesinleşmedi; sonraki parça bekletildi.';
    $db->prepare("UPDATE orders_dripfeed SET next_run_at=DATE_ADD(NOW(),INTERVAL 5 MINUTE),last_error=?,updated_at=NOW() WHERE id=? AND status='active'")->execute([$msg,$dfId]);
    return ['ready'=>false,'deferred'=>true,'reason'=>$msg];
}

function moni_cron_task_dripfeed(PDO $db,int $batch):array{
    if(function_exists('moni_partial_maintenance_active')&&moni_partial_maintenance_active($db,'orders',false))return ['processed'=>0,'message'=>'Kısmi bakım: dripfeed yeni parça üretimi duraklatıldı.'];
    $s=$db->prepare("SELECT df.*,s.* ,df.id AS df_id,df.user_id AS df_user_id,df.service_id AS df_service_id FROM orders_dripfeed df JOIN services s ON s.id=df.service_id WHERE df.status='active' AND df.completed_runs<df.runs AND (df.next_run_at IS NULL OR df.next_run_at<=NOW()) ORDER BY df.id LIMIT $batch");$s->execute();$n=0;
    foreach($s->fetchAll(PDO::FETCH_ASSOC) as $df){
        if(function_exists('moni_validate_service_target')){$tv=moni_validate_service_target($db,(int)$df['df_service_id'],(string)$df['link'],(int)$df['df_user_id'],'dripfeed-cron');if(empty($tv['ok'])){if(function_exists('moni_refund_dripfeed_remaining'))moni_refund_dripfeed_remaining($db,(int)$df['df_id'],'Hedef politikası: '.($tv['error']??'hedef engellendi'));moni_cron_log('[dripfeed] #'.($df['df_id']??0).' hedef politikası nedeniyle durduruldu.');$n++;continue;}}
        if(function_exists('moni_service_schedule_check')){$wh=moni_service_schedule_check($db,(int)$df['df_service_id']);if(empty($wh['open'])){$db->prepare("UPDATE orders_dripfeed SET next_run_at=DATE_ADD(NOW(),INTERVAL 5 MINUTE),last_error=? WHERE id=?")->execute([$wh['error']??'Çalışma saatleri dışında',$df['df_id']]);$n++;continue;}}
        // Aralık süresi dolmuş olsa bile önceki provider parçası bitmeden aynı hedefe yeni run gönderme.
        // Bu, aynı linkte eşzamanlı sipariş kabul etmeyen sağlayıcılarda link_duplicate hatasını önler.
        $gate=moni_dripfeed_previous_run_gate($db,$df);
        if(empty($gate['ready'])){$n++;continue;}
        $per=(float)$df['total_price']/max(1,(int)$df['runs']);
        $providerQty=(int)$df['quantity'];$overflow=max(0,min(500,(float)($df['overflow_percent']??0)));if($overflow>0)$providerQty=(int)ceil($providerQty*(1+$overflow/100));
        $db->prepare("INSERT INTO orders(user_id,service_id,api_provider_id,link,quantity,provider_quantity,price,status,dripfeed_id,geo_target,created_at) VALUES(?,?,?,?,?,?,?,'pending',?,?,NOW())")->execute([$df['df_user_id'],$df['df_service_id'],$df['api_provider_id']?:null,$df['link'],$df['quantity'],$providerQty,$per,$df['df_id'],$df['geo_target']??null]);
        $oid=(int)$db->lastInsertId();$df['geo_target']=$df['geo_target']??null;
        $r=moni_submit_order_to_provider($db,$oid,$df,$df['link'],$providerQty);
        if($r['success']){
            $done=(int)$df['completed_runs']+1;$status=$done>=(int)$df['runs']?'completed':'active';
            $next=$status==='active'?date('Y-m-d H:i:s',time()+max(1,(int)$df['interval_time'])*60):null;
            $db->prepare("UPDATE orders_dripfeed SET completed_runs=?,status=?,last_run_at=NOW(),next_run_at=?,error_count=0,last_error=NULL WHERE id=?")->execute([$done,$status,$next,$df['df_id']]);
        }elseif(!empty($r['ambiguous'])){
            // Belirsiz sağlayıcı cevabında aynı run tekrar gönderilmez; manuel kontrol gerekir.
            $db->prepare("UPDATE orders_dripfeed SET status='partial',last_run_at=NOW(),next_run_at=NULL,last_error=? WHERE id=?")->execute(['Sağlayıcı sonucu belirsiz; otomatik tekrar durduruldu. '.$r['error'],$df['df_id']]);
        }else{
            $providerError=(string)($r['error']??'Sağlayıcı siparişi oluşturamadı.');
            $low=mb_strtolower($providerError,'UTF-8');
            $isDuplicateLink=str_contains($low,'link_duplicate')||str_contains($low,'link duplicate')||str_contains($low,'duplicate link')||str_contains($low,'aynı link')||str_contains($low,'same link');
            if($isDuplicateLink){
                // Normalde üstteki gate önceki kabul edilmiş parçayı terminal olana kadar bekletir.
                // Provider buna rağmen duplicate döndürürse kısa aralıklarla tekrar denenir; sonsuza kadar
                // bakiye tutulmaması için 5 ardışık duplicate sonrasında kullanılmayan kalan tutar iade edilir.
                $err=(int)$df['error_count']+1;
                $wait='Sağlayıcı aynı hedefte aktif/çakışan sipariş görüyor; dripfeed otomatik bekletildi.';
                $status=$err>=5?'partial':'active';
                $next=$status==='active'?date('Y-m-d H:i:s',time()+5*60):null;
                $db->prepare("UPDATE orders_dripfeed SET error_count=?,next_run_at=?,last_error=?,status=? WHERE id=?")->execute([$err,$next,$wait,$status,$df['df_id']]);
                $db->prepare("UPDATE orders SET admin_note=CONCAT(IFNULL(admin_note,''),?),updated_at=NOW() WHERE id=?")->execute(["\n[Dripfeed bekleme] ".$providerError,$oid]);
                if($err>=5){
                    $rr=moni_refund_dripfeed_remaining($db,(int)$df['df_id'],'Sağlayıcı aynı hedefte yeni dripfeed parçasını 5 kez reddetti; gönderilmemiş kalan tutar iade edildi.');
                    if(empty($rr['ok']))moni_cron_log('[dripfeed] #'.$df['df_id'].' duplicate sonrası kalan iade hatası: '.($rr['error']??'bilinmeyen'));
                }
            }else{
                $err=(int)$df['error_count']+1;$status=$err>=5?'partial':'active';
                $next=$status==='active'?date('Y-m-d H:i:s',time()+min(60,$err*5)*60):null;
                $db->prepare("UPDATE orders_dripfeed SET error_count=?,last_error=?,status=?,next_run_at=? WHERE id=?")->execute([$err,$providerError,$status,$next,$df['df_id']]);
                if($err>=5){
                    $rr=moni_refund_dripfeed_remaining($db,(int)$df['df_id'],'5 açık sağlayıcı hatası sonrası kalan çalıştırmalar iptal edildi.');
                    if(empty($rr['ok']))moni_cron_log('[dripfeed] #'.$df['df_id'].' kalan iade hatası: '.($rr['error']??'bilinmeyen'));
                }
            }
        }
        $n++;
    }
    return ['processed'=>$n,'message'=>'Dripfeed kuyruğu işlendi.'];
}
function moni_cron_task_financial_closing(PDO $db,int $batch):array{
    $date=date('Y-m-d',strtotime('-1 day'));
    $r=moni_prepare_financial_closing($db,$date);
    if(empty($r['ok'])){
        return ['status'=>'error','processed'=>0,'message'=>$r['error']??'Kapanış başarısız'];
    }
    $msg=!empty($r['locked'])?"$date zaten kapalı; değiştirilmedi.":("$date kapanış taslağı hazırlandı. Varyans: ".($r['variance']??0));
    return ['status'=>'success','processed'=>!empty($r['locked'])?0:1,'message'=>$msg];
}
function moni_cron_task_cleanup(PDO $db,int $batch):array{
    $n=0;$remaining=max(1,$batch);
    $targets=[
        "remember_tokens"=>"expires_at<NOW()",
        "auth_attempts"=>"created_at<DATE_SUB(NOW(),INTERVAL 30 DAY)",
        "api_rate_buckets"=>"bucket_minute<DATE_SUB(NOW(),INTERVAL 2 DAY)",
        "provider_health_events"=>"created_at<DATE_SUB(NOW(),INTERVAL 90 DAY)",
        "provider_sla_snapshots"=>"captured_at<DATE_SUB(NOW(),INTERVAL 90 DAY)",
        "provider_sla_breaches"=>"status='resolved' AND resolved_at<DATE_SUB(NOW(),INTERVAL 365 DAY)",
        "order_idempotency"=>"expires_at<NOW()",
        "user_sessions"=>"last_activity_at<DATE_SUB(NOW(),INTERVAL 90 DAY)",
        "cron_runs"=>"started_at<DATE_SUB(NOW(),INTERVAL 180 DAY)",
        "security_events"=>"created_at<DATE_SUB(NOW(),INTERVAL 365 DAY)",
        "payment_fraud_events"=>"created_at<DATE_SUB(NOW(),INTERVAL 365 DAY)",
        "customer_api_request_logs"=>"created_at<DATE_SUB(NOW(),INTERVAL 90 DAY)"
    ];
    foreach($targets as $table=>$where){
        if($remaining<=0)break;
        try{$deleted=(int)$db->exec("DELETE FROM `$table` WHERE $where LIMIT ".(int)$remaining);$n+=$deleted;$remaining-=$deleted;}catch(Throwable $e){}
    }
    return ['processed'=>$n,'message'=>'Eski güvenlik/operasyon kayıtları temizlendi.'];
}
function moni_cron_task_e_invoice(PDO $db,int $batch):array{
    if(!moni_plugin_enabled('e_invoice',$db))return ['processed'=>0,'message'=>'e-Fatura eklentisi kapalı.'];
    $url=trim((string)getSetting('invoice_provider_url',''));$key=moni_decrypt_secret((string)getSetting('invoice_provider_api_key',''));if($url===''||$key==='')return ['processed'=>0,'message'=>'e-Fatura sağlayıcı bilgileri yapılandırılmamış.'];
    $s=$db->prepare("SELECT d.*,ut.* FROM e_invoice_documents d LEFT JOIN user_tax_profiles ut ON ut.user_id=d.user_id WHERE d.status='pending' ORDER BY d.id LIMIT $batch");$s->execute();$n=0;
    foreach($s->fetchAll(PDO::FETCH_ASSOC) as $d){$payload=['document_type'=>$d['document_type'],'amount'=>$d['amount'],'tax_amount'=>$d['tax_amount'],'currency'=>$d['currency_code'],'customer'=>['legal_name'=>$d['legal_name']??null,'tax_number'=>$d['tax_number']??null,'national_id'=>$d['national_id']??null,'email'=>$d['invoice_email']??null,'address'=>$d['address']??null]];$ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($payload),CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>30,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_HTTPHEADER=>['Content-Type: application/json','Authorization: Bearer '.$key]]);$raw=curl_exec($ch);$err=curl_error($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);$j=json_decode($raw?:'',true);if(!$err&&$http>=200&&$http<300&&is_array($j)){$db->prepare("UPDATE e_invoice_documents SET status='issued',external_id=?,document_number=?,payload_json=?,updated_at=NOW() WHERE id=?")->execute([$j['id']??null,$j['number']??null,$raw,$d['id']]);}else{$db->prepare("UPDATE e_invoice_documents SET status='failed',error_message=?,payload_json=?,updated_at=NOW() WHERE id=?")->execute([$err?:('HTTP '.$http),$raw,$d['id']]);}$n++;}
    return ['processed'=>$n,'message'=>'e-Fatura/e-Arşiv kuyruğu işlendi.'];
}

/* ------------------------- v2 gelişmiş cron görevleri ------------------------- */
function moni_cron_task_auto_subscriptions(PDO $db,int $batch):array{
    return function_exists('moni_process_auto_subscriptions')?moni_process_auto_subscriptions($db,$batch):['processed'=>0,'message'=>'Auto subscription çekirdeği yüklenmedi.'];
}
function moni_cron_task_real_count_completion(PDO $db,int $batch):array{
    return function_exists('moni_process_real_completion')?moni_process_real_completion($db,$batch):['processed'=>0,'message'=>'Gerçek sayı çekirdeği yüklenmedi.'];
}
function moni_cron_task_auto_refill(PDO $db,int $batch):array{
    return function_exists('moni_process_auto_refill')?moni_process_auto_refill($db,$batch):['processed'=>0,'message'=>'Auto refill çekirdeği yüklenmedi.'];
}
function moni_cron_task_provider_catalog_sync(PDO $db,int $batch):array{
    if(!function_exists('moni_sync_provider_catalog'))return ['processed'=>0,'message'=>'Sağlayıcı katalog senkronizasyonu yüklenmedi.'];
    $providers=$db->query("SELECT id FROM api_providers WHERE status='active' ORDER BY id")->fetchAll(PDO::FETCH_COLUMN);$done=0;$services=0;$errors=[];$remaining=max(1,$batch);
    foreach($providers as $pid){if($remaining<=0)break;$r=moni_sync_provider_catalog($db,(int)$pid,$remaining,moni_setting_bool('provider_sync_copy_description',true));if(!empty($r['ok'])){$done++;$count=(int)($r['processed']??0);$services+=$count;$remaining-=min($remaining,$count);}else{$errors[]='#'.$pid.' '.($r['error']??'hata');}}
    return ['processed'=>$services,'message'=>"$done sağlayıcı senkronize edildi; $services servis güncellendi".($errors?'; '.implode(' | ',array_slice($errors,0,3)):'').'.'];
}
function moni_cron_task_sitemap(PDO $db,int $batch):array{
    $r=function_exists('moni_generate_sitemap')?moni_generate_sitemap($db):['ok'=>false,'error'=>'Sitemap motoru yok'];
    if(function_exists('moni_write_robots'))moni_write_robots($db);
    return ['processed'=>!empty($r['ok'])?(int)($r['count']??1):0,'message'=>!empty($r['ok'])?'sitemap.xml ve robots.txt güncellendi.':($r['error']??'Sitemap üretilemedi.')];
}
function moni_cron_task_managed_files_scan(PDO $db,int $batch):array{
    $n=function_exists('moni_managed_file_scan')?moni_managed_file_scan($db,$batch):0;return ['processed'=>$n,'message'=>"$n dosya indekslendi."];
}
function moni_cron_task_child_panel_maintenance(PDO $db,int $batch):array{
    return function_exists('moni_child_panel_maintenance')?moni_child_panel_maintenance($db,$batch):['processed'=>0,'message'=>'Child Panel bakım çekirdeği yüklenmedi.'];
}


/* ------------------------- v2 operasyon görevleri ------------------------- */
function moni_cron_task_cancel_queue(PDO $db,int $batch):array{
    return function_exists('moni_process_cancel_queue')?moni_process_cancel_queue($db,$batch):['processed'=>0,'message'=>'Cancel queue engine unavailable.'];
}
function moni_cron_task_customer_group_upgrade(PDO $db,int $batch):array{
    if(!function_exists('moni_recalculate_customer_group'))return ['processed'=>0,'message'=>'Customer group engine unavailable.'];
    $ids=$db->query("SELECT id FROM users WHERE role IN('user','reseller') AND status='active' ORDER BY updated_at ASC LIMIT ".max(1,min(5000,$batch)))->fetchAll(PDO::FETCH_COLUMN);$n=0;foreach($ids as $id){moni_recalculate_customer_group($db,(int)$id);$n++;}return ['processed'=>$n,'message'=>"$n user level checked."];
}
function moni_cron_task_provider_reconciliation(PDO $db,int $batch):array{
    if(!function_exists('moni_provider_reconcile'))return ['processed'=>0,'message'=>'Reconciliation engine unavailable.'];$date=date('Y-m-d',strtotime('-1 day'));$ids=$db->query("SELECT id FROM api_providers ORDER BY id LIMIT ".max(1,min(500,$batch)))->fetchAll(PDO::FETCH_COLUMN);$n=0;foreach($ids as $id){$r=moni_provider_reconcile($db,(int)$id,$date);if(!empty($r['ok']))$n++;}return ['processed'=>$n,'message'=>"$n provider reconciled for $date."];
}
function moni_cron_task_automatic_backup(PDO $db,int $batch):array{
    if(!function_exists('moni_backup_create'))return ['processed'=>0,'message'=>'Backup engine unavailable.'];$r=moni_backup_create($db,0,(string)getSetting('backup_include_uploads','1')==='1');if(!empty($r['ok'])){moni_backup_retention($db);if((string)getSetting('backup_auto_notify','1')==='1'&&function_exists('moni_admin_notify'))moni_admin_notify($db,'backup','Automatic backup completed',basename($r['file']??''),'/admin/backup-center.php','success',false);return ['processed'=>1,'message'=>'Automatic backup completed.'];}if(function_exists('moni_admin_notify'))moni_admin_notify($db,'backup_failed','Automatic backup failed',$r['error']??'Unknown error','/admin/backup-center.php','danger');return ['processed'=>0,'message'=>$r['error']??'Backup failed.'];
}
function moni_cron_task_favorite_service_alerts(PDO $db,int $batch):array{
    if(!function_exists('moni_process_favorite_service_alerts'))return ['processed'=>0,'message'=>'Favori servis alarm motoru yüklenemedi.'];
    if(!moni_plugin_enabled('favorite_service_alerts',$db))return ['processed'=>0,'message'=>'Favori servis alarm eklentisi kapalı.'];
    return moni_process_favorite_service_alerts($db,$batch);
}

function moni_cron_task_notification_cleanup(PDO $db,int $batch):array{
    $n=0;$batch=max(1,min(5000,$batch));foreach(['user_notifications'=>'created_at','admin_notifications'=>'created_at'] as $table=>$col){if(!moni_table_ready($db,$table))continue;try{$d=$db->exec("DELETE FROM `$table` WHERE `$col`<DATE_SUB(NOW(),INTERVAL 180 DAY) LIMIT $batch");$n+=(int)$d;}catch(Throwable $e){}}return ['processed'=>$n,'message'=>"$n old notification removed."];
}

/* ------------------------- v2 ölçeklenebilir sipariş / kalite görevleri ------------------------- */

function moni_cron_task_premium_memberships(PDO $db,int $batch):array{
    return function_exists('moni_process_premium_memberships')?moni_process_premium_memberships($db,$batch):['processed'=>0,'message'=>'Premium üyelik motoru yüklenmedi.'];
}

function moni_cron_task_order_dispatch(PDO $db,int $batch):array{
    return function_exists('moni_process_order_dispatch_queue')?moni_process_order_dispatch_queue($db,$batch):['processed'=>0,'message'=>'Sipariş gönderim kuyruğu motoru yüklenmedi.'];
}
function moni_cron_task_service_quality(PDO $db,int $batch):array{
    return function_exists('moni_process_service_quality')?moni_process_service_quality($db,$batch):['processed'=>0,'message'=>'Servis kalite motoru yüklenmedi.'];
}
function moni_cron_task_profit_protection(PDO $db,int $batch):array{
    return function_exists('moni_process_min_profit_protection')?moni_process_min_profit_protection($db,$batch):['processed'=>0,'message'=>'Minimum kâr koruma motoru yüklenmedi.'];
}

/* ------------------------- Ops Pro görevleri ------------------------- */
function moni_cron_task_accounting_sync(PDO $db,int $batch):array{
    if(!function_exists('moni_accounting_enqueue_new')||!function_exists('moni_accounting_process_queue'))return ['processed'=>0,'message'=>'Muhasebe entegrasyon motoru yüklenmedi.'];
    $queued=moni_accounting_enqueue_new($db,max(50,$batch));
    $r=moni_accounting_process_queue($db,$batch);
    return ['processed'=>(int)($r['processed']??0),'message'=>$queued.' yeni hareket kuyruğa alındı; '.(int)($r['sent']??0).' gönderildi, '.(int)($r['failed']??0).' hata/retry.'];
}
function moni_cron_task_cron_watchdog(PDO $db,int $batch):array{
    if(!function_exists('moni_cron_watchdog_check'))return ['processed'=>0,'message'=>'Cron watchdog motoru yüklenmedi.'];
    $r=moni_cron_watchdog_check($db,true);return ['processed'=>(int)($r['missed']??0),'message'=>!empty($r['missed'])?((int)$r['missed'].' geciken görev/heartbeat tespit edildi.'):'Cron görevleri zamanında çalışıyor.'];
}

/* ------------------------- Growth Pro görevleri ------------------------- */
function moni_cron_task_service_drop_analysis(PDO $db,int $batch):array{
    return function_exists('moni_process_service_drop_analysis')?moni_process_service_drop_analysis($db,$batch):['processed'=>0,'message'=>'Drop rate analiz motoru yüklenmedi.'];
}
function moni_cron_task_web_push_delivery(PDO $db,int $batch):array{
    return function_exists('moni_process_web_push_queue')?moni_process_web_push_queue($db,$batch):['processed'=>0,'message'=>'Web Push motoru yüklenmedi.'];
}


/* ------------------------- Completion Pack görevleri ------------------------- */
function moni_cron_task_postpaid_overdue(PDO $db,int $batch):array{
    return function_exists('moni_process_postpaid_overdue')?moni_process_postpaid_overdue($db,$batch):['processed'=>0,'message'=>'Gecikmiş borç otomasyon motoru yüklenmedi.'];
}
function moni_cron_task_child_panel_remote_backup(PDO $db,int $batch):array{
    if(function_exists('moni_plugin_enabled')&&!moni_plugin_enabled('child_panels',$db))return ['status'=>'skipped','processed'=>0,'message'=>'Child Panel eklentisi pasif.'];
    return function_exists('moni_process_child_remote_backups')?moni_process_child_remote_backups($db,$batch):['processed'=>0,'message'=>'Child Panel uzak yedekleme motoru yüklenmedi.'];
}
