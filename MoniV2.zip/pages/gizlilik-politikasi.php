<?php
$pageTitle = "Gizlilik Politikası";
require_once __DIR__ . '/../includes/header.php';
?>

<style>
.page-wrapper { max-width: 900px; margin: 0 auto; padding: 40px 20px; }
.page-title { font-size: 2rem; font-weight: 700; margin-bottom: 30px; text-align: center; }
.page-box { background: var(--card-bg-color); border: 1px solid var(--border-color); border-radius: 16px; padding: 40px; }
.page-box h2 { font-size: 1.4rem; color: var(--accent-text-color); margin: 30px 0 15px; padding-bottom: 10px; border-bottom: 2px solid var(--border-color); }
.page-box h2:first-child { margin-top: 0; }
.page-box h3 { font-size: 1.1rem; margin: 20px 0 10px; }
.page-box p { margin-bottom: 15px; line-height: 1.8; }
.page-box ul, .page-box ol { margin: 15px 0; padding-left: 25px; }
.page-box li { margin-bottom: 10px; line-height: 1.7; }
.page-box a { color: var(--accent-text-color); }
@media (max-width: 768px) { .page-wrapper { padding: 25px 15px; } .page-box { padding: 25px; } .page-title { font-size: 1.5rem; } }
</style>

<div class="page-wrapper">
    <h1 class="page-title">Gizlilik Politikası</h1>
    <div class="page-box">
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Gizlilik Politikası</title>
</head>
<body>

<h1>Gizlilik Politikası</h1>

<p>
Bu gizlilik politikası, sitemizi kullanan ziyaretçi ve üyelerin kişisel verilerinin
toplanması, kullanılması ve korunmasına ilişkin esasları açıklamaktadır.
Siteyi kullanan herkes bu politikayı kabul etmiş sayılır.
</p>

<h2>1. Toplanan Bilgiler</h2>
<p>
Site üzerinden hizmet sunulabilmesi amacıyla aşağıdaki bilgiler toplanabilir:
</p>
<ul>
    <li>Ad, soyad (isteğe bağlı)</li>
    <li>E-posta adresi</li>
    <li>Kullanıcı adı</li>
    <li>IP adresi</li>
    <li>Ödeme ve işlem bilgileri</li>
</ul>

<h2>2. Kişisel Verilerin Kullanımı</h2>
<ul>
    <li>Hizmetlerin sunulması ve geliştirilmesi</li>
    <li>Kullanıcı hesaplarının yönetilmesi</li>
    <li>Ödeme işlemlerinin gerçekleştirilmesi</li>
    <li>Yasal yükümlülüklerin yerine getirilmesi</li>
</ul>

<h2>3. Kişisel Verilerin Korunması</h2>
<ul>
    <li>Kişisel veriler üçüncü kişilerle paylaşılmaz.</li>
    <li>Ödeme bilgileri sistemimizde saklanmaz.</li>
    <li>Verilerin güvenliği için gerekli teknik ve idari önlemler alınmaktadır.</li>
</ul>

<h2>4. Üçüncü Taraf Hizmetler</h2>
<p>
Ödeme işlemleri PayTR, İyzico veya benzeri ödeme sağlayıcıları aracılığıyla yapılabilir.
Bu sağlayıcıların kendi gizlilik politikaları geçerlidir.
</p>

<h2>5. Çerezler (Cookies)</h2>
<p>
Site, kullanıcı deneyimini geliştirmek amacıyla çerezler kullanabilir.
Kullanıcılar tarayıcı ayarları üzerinden çerezleri engelleyebilir.
</p>

<h2>6. IP Adresleri</h2>
<p>
IP adresleri sistem güvenliği, dolandırıcılık önleme ve yasal yükümlülükler kapsamında
kayıt altına alınabilir.
</p>

<h2>7. Kişisel Verilere Erişim ve Güncelleme</h2>
<p>
Kullanıcılar hesapları üzerinden kişisel bilgilerini güncelleyebilir.
Hesap kapatma talepleri site yönetimi tarafından değerlendirilir.
</p>

<h2>8. Politika Değişiklikleri</h2>
<p>
Site yönetimi bu gizlilik politikasını önceden haber vermeksizin değiştirme hakkını saklı tutar.
Güncel politika her zaman bu sayfa üzerinden yayınlanır.
</p>

<p>
Siteyi kullanmaya devam eden kullanıcılar güncel gizlilik politikasını kabul etmiş sayılır.
</p>

</body>
</html>

    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>