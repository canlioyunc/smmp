<?php
$pageTitle = "İade Politikası";
require_once __DIR__ . '/../includes/header.php';
?>

<style>
.page-wrapper { max-width: 900px; margin: 0 auto; padding: 40px 20px; }
.page-title { font-size: 2rem; font-weight: 700; margin-bottom: 30px; text-align: center; }
.page-box { background: var(--card-bg-color); border: 1px solid var(--border-color); border-radius: 16px; padding: 40px; }
.page-box h2 { font-size: 1.4rem; color: var(--accent-text-color); margin: 30px 0 15px; padding-bottom: 10px; border-bottom: 2px solid var(--border-color); }
.page-box h2:first-child { margin-top: 0; }
.page-box h3 { font-size: 1.1rem; margin: 20px 0 10px; }
.page-box p { margin-bottom: 15px; line-height: 1.8; }
.page-box ul, .page-box ol { margin: 15px 0; padding-left: 25px; }
.page-box li { margin-bottom: 10px; line-height: 1.7; }
.page-box a { color: var(--accent-text-color); }
@media (max-width: 768px) { .page-wrapper { padding: 25px 15px; } .page-box { padding: 25px; } .page-title { font-size: 1.5rem; } }
</style>

<div class="page-wrapper">
    <h1 class="page-title">İade Politikası</h1>
    <div class="page-box">
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>İade Politikası</title>
</head>
<body>

<h1>İade Politikası</h1>

<p>
Bu iade politikası, sitemiz üzerinden sunulan tüm dijital hizmetler için geçerlidir.
Siteyi kullanan tüm kullanıcılar bu politikayı kabul etmiş sayılır.
</p>

<h2>Genel Şartlar</h2>
<ul>
    <li>Tüm hizmetler dijitaldir ve sipariş verildikten sonra otomatik veya manuel olarak işleme alınır.</li>
    <li>Tamamlanmış siparişlerde iade yapılmaz.</li>
    <li>Yanlış verilen siparişlerden kullanıcı sorumludur.</li>
    <li>Sipariş vermeden önce servis açıklamalarının okunması kullanıcının sorumluluğundadır.</li>
</ul>

<h2>Bakiye İadeleri</h2>
<ul>
    <li>Siteye yüklenen bakiyeler iade edilmez.</li>
    <li>Yüklenen bakiye yalnızca site içerisindeki hizmetlerde kullanılabilir.</li>
    <li>Kullanılmayan bakiyeler için nakit veya banka iadesi yapılmaz.</li>
</ul>

<h2>Sipariş İptali ve Kısmi İade</h2>
<ul>
    <li>Henüz işleme alınmamış siparişler sistem tarafından uygun görülürse iptal edilebilir.</li>
    <li>İptal edilen siparişlerin ücreti sadece site bakiyesi olarak iade edilir.</li>
    <li>Kısmen tamamlanan siparişlerde yalnızca tamamlanmayan kısım için bakiye iadesi yapılabilir.</li>
</ul>

<h2>Servis Garantileri</h2>
<ul>
    <li>Servis açıklamalarında belirtilen garanti koşulları geçerlidir.</li>
    <li>Drop garantisi bulunan servislerde belirtilen süre içerisinde telafi yapılır.</li>
    <li>Garanti süresi dışında kalan talepler kabul edilmez.</li>
</ul>

<h2>Kötüye Kullanım</h2>
<ul>
    <li>İade politikasının kötüye kullanılması durumunda kullanıcı hesabı askıya alınabilir.</li>
    <li>Bu durumda bakiye ve siparişler için herhangi bir iade yapılmaz.</li>
</ul>

<h2>Politika Değişiklikleri</h2>
<p>
Site yönetimi bu iade politikasını önceden haber vermeksizin değiştirme hakkını saklı tutar.
Güncel politika her zaman bu sayfada yayınlanır.
</p>

<p>
Siteyi kullanmaya devam eden kullanıcılar güncel iade politikasını kabul etmiş sayılır.
</p>

</body>
</html>

    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>