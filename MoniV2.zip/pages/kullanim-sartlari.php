<?php
$pageTitle = "Kullanım Koşulları";
require_once __DIR__ . '/../includes/header.php';
?>

<style>
.page-wrapper { max-width: 900px; margin: 0 auto; padding: 40px 20px; }
.page-title { font-size: 2rem; font-weight: 700; margin-bottom: 30px; text-align: center; }
.page-box { background: var(--card-bg-color); border: 1px solid var(--border-color); border-radius: 16px; padding: 40px; }
.page-box h2 { font-size: 1.4rem; color: var(--accent-text-color); margin: 30px 0 15px; padding-bottom: 10px; border-bottom: 2px solid var(--border-color); }
.page-box h2:first-child { margin-top: 0; }
.page-box h3 { font-size: 1.1rem; margin: 20px 0 10px; }
.page-box p { margin-bottom: 15px; line-height: 1.8; }
.page-box ul, .page-box ol { margin: 15px 0; padding-left: 25px; }
.page-box li { margin-bottom: 10px; line-height: 1.7; }
.page-box a { color: var(--accent-text-color); }
@media (max-width: 768px) { .page-wrapper { padding: 25px 15px; } .page-box { padding: 25px; } .page-title { font-size: 1.5rem; } }
</style>

<div class="page-wrapper">
    <h1 class="page-title">Kullanım Koşulları</h1>
    <div class="page-box">
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Kullanım Şartları</title>
</head>
<body>

<h1>Kullanım Şartları</h1>

<p>
Bu kullanım şartları, sitemiz üzerinden sunulan tüm hizmetlerin kullanımına ilişkin
kuralları ve tarafların hak ve yükümlülüklerini düzenler.
Siteyi kullanan tüm kullanıcılar bu şartları kabul etmiş sayılır.
</p>

<h2>1. Genel Hükümler</h2>
<ul>
    <li>Site üzerinden sunulan tüm hizmetler dijital hizmetlerdir.</li>
    <li>Site yönetimi, hizmetlerde ve şartlarda önceden haber vermeksizin değişiklik yapma hakkını saklı tutar.</li>
    <li>Kullanıcılar, siteyi yalnızca yasal amaçlarla kullanmayı kabul eder.</li>
</ul>

<h2>2. Üyelik ve Hesap Güvenliği</h2>
<ul>
    <li>Kullanıcı, kayıt sırasında verdiği bilgilerin doğru ve güncel olduğunu kabul eder.</li>
    <li>Hesap güvenliğinden kullanıcı sorumludur.</li>
    <li>Hesabın üçüncü kişiler tarafından kullanılması durumunda tüm sorumluluk kullanıcıya aittir.</li>
    <li>Bir kullanıcı birden fazla hesap açamaz.</li>
</ul>

<h2>3. Hizmetlerin Kullanımı</h2>
<ul>
    <li>Verilen siparişler otomatik veya manuel olarak işleme alınır.</li>
    <li>Siparişler geri alınamaz ve tamamlanan siparişlerde iade yapılmaz.</li>
    <li>Yanlış verilen siparişlerden site sorumlu değildir.</li>
    <li>Servis açıklamalarında belirtilen şartlar geçerlidir.</li>
</ul>

<h2>4. Ödeme ve Bakiye</h2>
<ul>
    <li>Siteye yüklenen bakiyeler iade edilmez.</li>
    <li>Bakiye yalnızca site içerisindeki hizmetlerde kullanılabilir.</li>
    <li>Ödeme sırasında oluşabilecek teknik sorunlardan site sorumlu değildir.</li>
</ul>

<h2>5. Yasaklı Kullanımlar</h2>
<ul>
    <li>Siteyi kötüye kullanmak, sisteme zarar vermeye çalışmak yasaktır.</li>
    <li>Sahte, yanıltıcı veya illegal içerikler için hizmet alınamaz.</li>
    <li>Spam, dolandırıcılık veya üçüncü taraf haklarını ihlal eden işlemler yasaktır.</li>
</ul>

<h2>6. Hesap Askıya Alma ve Sonlandırma</h2>
<ul>
    <li>Kullanım şartlarını ihlal eden kullanıcıların hesapları askıya alınabilir veya kalıcı olarak kapatılabilir.</li>
    <li>Bu durumda kullanıcı bakiyesi ve siparişleri için iade yapılmaz.</li>
</ul>

<h2>7. Sorumluluk Reddi</h2>
<ul>
    <li>Site, sosyal medya platformları ile doğrudan bağlantılı değildir.</li>
    <li>Platformlardan kaynaklanan sorunlardan site sorumlu tutulamaz.</li>
    <li>Hizmetlerin kullanımından doğabilecek doğrudan veya dolaylı zararlardan site sorumlu değildir.</li>
</ul>

<h2>8. Değişiklikler</h2>
<p>
Site yönetimi bu kullanım şartlarını dilediği zaman güncelleme hakkına sahiptir.
Güncel şartlar bu sayfa üzerinden yayınlanır.
</p>

<p>
Siteyi kullanmaya devam eden kullanıcılar güncel kullanım şartlarını kabul etmiş sayılır.
</p>

</body>
</html>

    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>