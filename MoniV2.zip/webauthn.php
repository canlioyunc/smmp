<?php
require_once __DIR__.'/config.php';
header('Content-Type: application/json; charset=utf-8');
$raw=json_decode(file_get_contents('php://input'),true);$in=is_array($raw)?$raw:$_POST;$action=(string)($in['action']??$_GET['action']??'');
try{
    if($action==='auth_options'){echo json_encode(moni_webauthn_auth_options($db,trim((string)($in['identifier']??''))),JSON_UNESCAPED_UNICODE);exit;}
    if($action==='auth_finish'){echo json_encode(moni_webauthn_auth_finish($db,$in),JSON_UNESCAPED_UNICODE);exit;}
    if(!isLoggedIn()){http_response_code(401);echo json_encode(['success'=>false,'error'=>'Oturum gerekli.']);exit;}
    $uid=(int)$_SESSION['user_id'];
    if($action==='register_options'){echo json_encode(moni_webauthn_register_options($db,$uid),JSON_UNESCAPED_UNICODE);exit;}
    if($action==='register_finish'){echo json_encode(moni_webauthn_register_finish($db,$uid,$in),JSON_UNESCAPED_UNICODE);exit;}
    if($action==='list'){$s=$db->prepare("SELECT id,name,transports,created_at,last_used_at FROM webauthn_credentials WHERE user_id=? ORDER BY id DESC");$s->execute([$uid]);echo json_encode(['success'=>true,'items'=>$s->fetchAll(PDO::FETCH_ASSOC)],JSON_UNESCAPED_UNICODE);exit;}
    if($action==='delete'){$id=(int)($in['id']??0);$s=$db->prepare("DELETE FROM webauthn_credentials WHERE id=? AND user_id=?");$s->execute([$id,$uid]);moni_security_event($uid,'passkey_removed','warning',['credential_row'=>$id]);echo json_encode(['success'=>true]);exit;}
    http_response_code(400);echo json_encode(['success'=>false,'error'=>'Geçersiz işlem.']);
}catch(Throwable $e){http_response_code(500);echo json_encode(['success'=>false,'error'=>'İşlem tamamlanamadı.']);}
