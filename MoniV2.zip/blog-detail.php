<?php
/**
 * Blog - Yazı Detayı
 */

require_once 'config.php';

$slug = $_GET['slug'] ?? '';

if (empty($slug)) {
    header('Location: /blog');
    exit;
}

// Blog yazısını getir
$stmt = $db->prepare("SELECT * FROM blog_posts WHERE slug = ? AND is_active = 1");
$stmt->execute([$slug]);
$post = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$post) {
    http_response_code(404);
    $pageTitle = "Sayfa Bulunamadı";
    require_once 'includes/header.php';
    ?>
    <style>
    .error-page { padding: 100px 20px; text-align: center; min-height: 60vh; display: flex; flex-direction: column; align-items: center; justify-content: center; }
    .error-page i { font-size: 5rem; color: var(--accent-text-color); opacity: 0.3; margin-bottom: 25px; }
    .error-page h1 { font-size: 2rem; margin-bottom: 15px; color: var(--text-color); }
    .error-page p { opacity: 0.7; margin-bottom: 30px; color: var(--text-color); }
    </style>
    <div class="error-page">
        <i class="fas fa-file-excel"></i>
        <h1>Blog Yazısı Bulunamadı</h1>
        <p>Aradığınız blog yazısı mevcut değil veya kaldırılmış olabilir.</p>
        <a href="<?php echo SITE_URL; ?>/blog" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Blog'a Dön</a>
    </div>
    <?php
    require_once 'includes/footer.php';
    exit;
}

// Görüntülenme sayısını artır
$stmt = $db->prepare("UPDATE blog_posts SET view_count = view_count + 1 WHERE id = ?");
$stmt->execute([$post['id']]);

// İlgili yazıları getir
$stmt = $db->prepare("SELECT id, title, slug, featured_image, created_at FROM blog_posts WHERE is_active = 1 AND id != ? ORDER BY created_at DESC LIMIT 3");
$stmt->execute([$post['id']]);
$relatedPosts = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = $post['meta_title'] ?: $post['title'];
$pageDescription = $post['meta_description'] ?: ($post['excerpt'] ?: mb_substr(strip_tags($post['content']), 0, 160, 'UTF-8'));

require_once 'includes/header.php';
?>

<style>
.blog-detail-page {
    padding: 40px 20px 80px;
    background: var(--background-color);
    min-height: 70vh;
}

.blog-detail-container {
    max-width: 900px;
    margin: 0 auto;
}

/* Breadcrumb */
.blog-breadcrumb {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 30px;
    font-size: 0.9rem;
}

.blog-breadcrumb a {
    color: var(--accent-text-color);
    text-decoration: none;
    transition: opacity 0.3s;
}

.blog-breadcrumb a:hover {
    opacity: 0.7;
}

.blog-breadcrumb span {
    color: var(--text-color);
    opacity: 0.5;
}

.blog-breadcrumb i {
    font-size: 0.7rem;
    opacity: 0.4;
}

/* Featured Image */
.blog-featured-image {
    width: 100%;
    height: 400px;
    border-radius: 20px;
    overflow: hidden;
    margin-bottom: 35px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
}

.blog-featured-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.blog-featured-image-placeholder {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: rgba(255, 255, 255, 0.4);
    font-size: 5rem;
}

/* Post Header */
.blog-post-header {
    margin-bottom: 35px;
}

.blog-post-meta {
    display: flex;
    align-items: center;
    gap: 20px;
    margin-bottom: 20px;
    font-size: 0.9rem;
    color: var(--text-color);
    opacity: 0.6;
    flex-wrap: wrap;
}

.blog-post-meta span {
    display: flex;
    align-items: center;
    gap: 6px;
}

.blog-post-title {
    font-size: 2.2rem;
    font-weight: 700;
    color: var(--text-color);
    line-height: 1.3;
    margin-bottom: 0;
}

/* Post Content */
.blog-post-content {
    background: var(--card-bg-color);
    border-radius: 20px;
    padding: 40px;
    border: 1px solid var(--border-color);
    margin-bottom: 40px;
}

.blog-post-content h2 {
    font-size: 1.6rem;
    font-weight: 700;
    color: var(--text-color);
    margin: 35px 0 20px;
}

.blog-post-content h2:first-child {
    margin-top: 0;
}

.blog-post-content h3 {
    font-size: 1.3rem;
    font-weight: 600;
    color: var(--text-color);
    margin: 30px 0 15px;
}

.blog-post-content p {
    font-size: 1.05rem;
    line-height: 1.9;
    color: var(--text-color);
    opacity: 0.85;
    margin-bottom: 20px;
}

.blog-post-content ul,
.blog-post-content ol {
    margin: 20px 0;
    padding-left: 25px;
}

.blog-post-content li {
    font-size: 1.05rem;
    line-height: 1.8;
    color: var(--text-color);
    opacity: 0.85;
    margin-bottom: 10px;
}

.blog-post-content a {
    color: var(--accent-text-color);
    text-decoration: none;
    border-bottom: 1px solid transparent;
    transition: border-color 0.3s;
}

.blog-post-content a:hover {
    border-bottom-color: var(--accent-text-color);
}

.blog-post-content img {
    max-width: 100%;
    height: auto;
    border-radius: 12px;
    margin: 25px 0;
}

.blog-post-content blockquote {
    border-left: 4px solid var(--primary-color);
    padding: 20px 25px;
    margin: 25px 0;
    background: var(--background-color);
    border-radius: 0 12px 12px 0;
    font-style: italic;
    opacity: 0.9;
}

.blog-post-content code {
    background: var(--background-color);
    padding: 3px 8px;
    border-radius: 5px;
    font-family: 'Courier New', monospace;
    font-size: 0.9em;
}

.blog-post-content pre {
    background: var(--background-color);
    padding: 20px;
    border-radius: 12px;
    overflow-x: auto;
    margin: 25px 0;
}

.blog-post-content pre code {
    background: none;
    padding: 0;
}

/* Share Buttons */
.blog-share {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 25px 0;
    border-top: 1px solid var(--border-color);
    margin-top: 30px;
    flex-wrap: wrap;
}

.blog-share-label {
    font-weight: 600;
    color: var(--text-color);
    font-size: 0.95rem;
}

.blog-share a {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 42px;
    height: 42px;
    border-radius: 10px;
    font-size: 1.1rem;
    color: #fff;
    transition: all 0.3s ease;
}

.blog-share a:hover {
    transform: translateY(-3px);
}

.blog-share .share-twitter { background: #1da1f2; }
.blog-share .share-facebook { background: #1877f2; }
.blog-share .share-linkedin { background: #0a66c2; }
.blog-share .share-whatsapp { background: #25d366; }
.blog-share .share-telegram { background: #0088cc; }

/* Related Posts */
.blog-related {
    margin-top: 60px;
}

.blog-related h3 {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--text-color);
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.blog-related h3 i {
    color: var(--accent-text-color);
}

.related-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
}

.related-card {
    background: var(--card-bg-color);
    border-radius: 14px;
    overflow: hidden;
    border: 1px solid var(--border-color);
    transition: all 0.3s ease;
}

.related-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
}

.related-card-image {
    height: 140px;
    overflow: hidden;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
}

.related-card-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s;
}

.related-card:hover .related-card-image img {
    transform: scale(1.05);
}

.related-card-image-placeholder {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: rgba(255, 255, 255, 0.4);
    font-size: 2rem;
}

.related-card-body {
    padding: 18px;
}

.related-card-date {
    font-size: 0.75rem;
    color: var(--accent-text-color);
    margin-bottom: 8px;
}

.related-card-title {
    font-size: 0.95rem;
    font-weight: 600;
    line-height: 1.4;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.related-card-title a {
    color: var(--text-color);
    text-decoration: none;
    transition: color 0.3s;
}

.related-card-title a:hover {
    color: var(--accent-text-color);
}

/* Back Button */
.blog-back {
    margin-top: 40px;
    text-align: center;
}

/* Responsive */
@media (max-width: 900px) {
    .related-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 768px) {
    .blog-detail-page {
        padding: 30px 15px 60px;
    }
    
    .blog-featured-image {
        height: 280px;
        border-radius: 16px;
    }
    
    .blog-post-title {
        font-size: 1.7rem;
    }
    
    .blog-post-content {
        padding: 25px 20px;
        border-radius: 16px;
    }
    
    .blog-post-content h2 {
        font-size: 1.4rem;
    }
    
    .blog-post-content h3 {
        font-size: 1.2rem;
    }
    
    .blog-post-content p,
    .blog-post-content li {
        font-size: 1rem;
    }
}

@media (max-width: 600px) {
    .blog-featured-image {
        height: 220px;
    }
    
    .blog-post-title {
        font-size: 1.5rem;
    }
    
    .blog-post-meta {
        gap: 12px;
        font-size: 0.85rem;
    }
    
    .related-grid {
        grid-template-columns: 1fr;
        max-width: 350px;
        margin: 0 auto;
    }
    
    .blog-share a {
        width: 38px;
        height: 38px;
        font-size: 1rem;
    }
}
</style>

<section class="blog-detail-page">
    <div class="blog-detail-container">
        <!-- Breadcrumb -->
        <nav class="blog-breadcrumb">
            <a href="<?php echo SITE_URL; ?>">Ana Sayfa</a>
            <i class="fas fa-chevron-right"></i>
            <a href="<?php echo SITE_URL; ?>/blog">Blog</a>
            <i class="fas fa-chevron-right"></i>
            <span><?php echo clean($post['title']); ?></span>
        </nav>
        
        <!-- Featured Image -->
        <div class="blog-featured-image">
            <?php if ($post['featured_image']): ?>
                <img src="<?php echo clean($post['featured_image']); ?>" alt="<?php echo clean($post['title']); ?>">
            <?php else: ?>
                <div class="blog-featured-image-placeholder">
                    <i class="fas fa-newspaper"></i>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Post Header -->
        <header class="blog-post-header">
            <div class="blog-post-meta">
                <span><i class="far fa-calendar-alt"></i> <?php echo date('d F Y', strtotime($post['created_at'])); ?></span>
                <span><i class="far fa-eye"></i> <?php echo number_format($post['view_count'] + 1); ?> görüntülenme</span>
            </div>
            <h1 class="blog-post-title"><?php echo clean($post['title']); ?></h1>
        </header>
        
        <!-- Post Content -->
        <article class="blog-post-content">
            <?php echo moni_sanitize_admin_html((string)$post['content']); ?>
            
            <!-- Share Buttons -->
            <div class="blog-share">
                <span class="blog-share-label">Paylaş:</span>
                <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode(SITE_URL . '/blog/' . $post['slug']); ?>&text=<?php echo urlencode($post['title']); ?>" target="_blank" class="share-twitter" title="Twitter'da Paylaş"><i class="fab fa-twitter"></i></a>
                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(SITE_URL . '/blog/' . $post['slug']); ?>" target="_blank" class="share-facebook" title="Facebook'ta Paylaş"><i class="fab fa-facebook-f"></i></a>
                <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo urlencode(SITE_URL . '/blog/' . $post['slug']); ?>&title=<?php echo urlencode($post['title']); ?>" target="_blank" class="share-linkedin" title="LinkedIn'de Paylaş"><i class="fab fa-linkedin-in"></i></a>
                <a href="https://wa.me/?text=<?php echo urlencode($post['title'] . ' - ' . SITE_URL . '/blog/' . $post['slug']); ?>" target="_blank" class="share-whatsapp" title="WhatsApp'ta Paylaş"><i class="fab fa-whatsapp"></i></a>
                <a href="https://t.me/share/url?url=<?php echo urlencode(SITE_URL . '/blog/' . $post['slug']); ?>&text=<?php echo urlencode($post['title']); ?>" target="_blank" class="share-telegram" title="Telegram'da Paylaş"><i class="fab fa-telegram-plane"></i></a>
            </div>
        </article>
        
        <!-- Related Posts -->
        <?php if (!empty($relatedPosts)): ?>
        <div class="blog-related">
            <h3><i class="fas fa-newspaper"></i> İlgili Yazılar</h3>
            <div class="related-grid">
                <?php foreach ($relatedPosts as $related): ?>
                    <article class="related-card">
                        <a href="<?php echo SITE_URL; ?>/blog/<?php echo clean($related['slug']); ?>" class="related-card-image">
                            <?php if ($related['featured_image']): ?>
                                <img src="<?php echo clean($related['featured_image']); ?>" alt="<?php echo clean($related['title']); ?>">
                            <?php else: ?>
                                <div class="related-card-image-placeholder">
                                    <i class="fas fa-newspaper"></i>
                                </div>
                            <?php endif; ?>
                        </a>
                        <div class="related-card-body">
                            <div class="related-card-date"><?php echo date('d M Y', strtotime($related['created_at'])); ?></div>
                            <h4 class="related-card-title">
                                <a href="<?php echo SITE_URL; ?>/blog/<?php echo clean($related['slug']); ?>">
                                    <?php echo clean($related['title']); ?>
                                </a>
                            </h4>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Back Button -->
        <div class="blog-back">
            <a href="<?php echo SITE_URL; ?>/blog" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Tüm Yazılara Dön
            </a>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>