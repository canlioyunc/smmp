<?php
require_once __DIR__.'/config.php';
$slug=strtolower(trim((string)($_GET['slug']??'')));
$builder=function_exists('moni_builder_page')?moni_builder_page($db,$slug):null;
if($builder){
    $pageTitle=$builder['meta_title']?:$builder['title'];require __DIR__.'/includes/header.php';
    ?>
    <style>
    .pb-wrap{max-width:1180px;margin:36px auto;padding:0 20px}.pb-hero,.pb-card{background:var(--card-bg-color);border:1px solid var(--border-color);border-radius:22px;padding:42px;margin-bottom:22px}.pb-hero{background:linear-gradient(135deg,var(--primary-alpha-01),var(--secondary-alpha-01)),var(--card-bg-color);text-align:center}.pb-hero h1{font-size:clamp(2rem,5vw,4rem);margin:0 0 14px}.pb-hero p,.pb-cta p{font-size:1.08rem;opacity:.75}.pb-btn{display:inline-flex;margin-top:18px;padding:12px 18px;border-radius:12px;background:var(--primary-color);color:var(--on-primary-color);text-decoration:none;font-weight:700}.pb-image{text-align:center}.pb-image img{max-width:100%;height:auto;border-radius:16px}.pb-cta{text-align:center}@media(max-width:700px){.pb-hero,.pb-card{padding:24px}}
    </style><main class="pb-wrap"><?php echo moni_render_builder_blocks($builder['blocks']); ?></main><?php require __DIR__.'/includes/footer.php';exit;
}
$s=$db->prepare("SELECT * FROM custom_pages WHERE slug=? AND is_active=1 LIMIT 1");$s->execute([$slug]);$page=$s->fetch(PDO::FETCH_ASSOC);
if(!$page){http_response_code(404);$pageTitle='Sayfa bulunamadı';require __DIR__.'/includes/header.php';echo '<div style="max-width:900px;margin:50px auto;padding:25px">Sayfa bulunamadı.</div>';require __DIR__.'/includes/footer.php';exit;}
$pageTitle=$page['title'];require __DIR__.'/includes/header.php';
?><style>.custom-page{max-width:980px;margin:35px auto;padding:0 20px}.custom-page__box{background:var(--card-bg-color);border:1px solid var(--border-color);border-radius:18px;padding:34px;line-height:1.75}.custom-page h1{margin-bottom:20px}</style><main class="custom-page"><h1><?=clean($page['title'])?></h1><article class="custom-page__box"><?=moni_sanitize_admin_html((string)$page['content_html'])?></article></main><?php require __DIR__.'/includes/footer.php'; ?>
