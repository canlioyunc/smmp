<?php
/**
 * Şifremi Unuttum Sayfası
 */

// Türkiye saat dilimini zorla
date_default_timezone_set('Europe/Istanbul');

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/MoniV2Compat.php';

// Zaten giriş yapmışsa yönlendir
if (isLoggedIn()) {
    header('Location: ' . (isAdmin() ? '/admin/' : '/kullanici/'));
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = trim($_POST['identifier'] ?? '');
    $generic = 'Eğer bu bilgilerle kayıtlı bir hesap varsa, şifre sıfırlama bağlantısı e-posta adresine gönderildi.';
    $captchaError='';
    if (!moni_captcha_verify_request($db,$captchaError)) {
        $error = $captchaError;
    } elseif ($identifier === '') {
        $error = 'Lütfen kullanıcı adınızı veya e-posta adresinizi girin.';
    } else {
        try {
            $stmt=$db->prepare("SELECT id,username,email FROM users WHERE username=? OR email=? LIMIT 1");
            $stmt->execute([$identifier,$identifier]);$user=$stmt->fetch(PDO::FETCH_ASSOC);
            if ($user) {
                $recent=$db->prepare("SELECT id FROM password_resets WHERE user_id=? AND created_at>DATE_SUB(NOW(),INTERVAL 1 MINUTE) LIMIT 1");
                $recent->execute([$user['id']]);
                if (!$recent->fetchColumn()) {
                    $db->prepare("UPDATE password_resets SET used=1 WHERE user_id=? AND used=0")->execute([$user['id']]);
                    $raw=bin2hex(random_bytes(32));$stored=moni_hash_secret_token($raw);
                    $db->prepare("INSERT INTO password_resets(user_id,token,expires_at,created_at) VALUES(?,?,DATE_ADD(NOW(),INTERVAL 1 HOUR),NOW())")->execute([$user['id'],$stored]);
                    $resetLink=SITE_URL.'/reset-password.php?token='.rawurlencode($raw);
                    $site=clean($siteSettings['name'] ?? getSetting('site_name','SMM Panel'));
                    $body='<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:24px"><h2>'.$site.' - Şifre sıfırlama</h2><p>Merhaba <strong>'.clean($user['username']).'</strong>,</p><p>Şifrenizi yenilemek için aşağıdaki bağlantıyı kullanın. Bağlantı 1 saat geçerlidir ve yalnız bir kez kullanılabilir.</p><p><a href="'.$resetLink.'" style="display:inline-block;padding:14px 24px;background:#6c5ce7;color:#fff;text-decoration:none;border-radius:9px">Şifremi Sıfırla</a></p><p style="word-break:break-all">'.$resetLink.'</p><p>Bu talebi siz oluşturmadıysanız e-postayı yok sayabilirsiniz.</p></div>';
                    @sendEmail((string)$user['email'], ($siteSettings['name'] ?? 'SMM Panel').' - Şifre Sıfırlama', $body);
                }
            }
            // Hesap var/yok, rate-limit veya mail durumu dışarı sızdırılmaz.
            usleep(random_int(120000,220000));
            $success=$generic;
        } catch (Throwable $e) {
            $success=$generic;
        }
    }
}

$pageTitle = "Şifremi Unuttum";
require_once 'includes/header.php';
?>

<style>
.forgot-page {
    min-height: calc(100vh - 200px);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 40px 20px;
}

.forgot-container {
    width: 100%;
    max-width: 450px;
}

.forgot-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 20px;
    padding: 40px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
}

.forgot-header {
    text-align: center;
    margin-bottom: 30px;
}

.forgot-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    font-size: 2rem;
    color: var(--on-accent-color);
}

.forgot-header h1 {
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 10px;
}

.forgot-header p {
    color: var(--text-color);
    opacity: 0.7;
    font-size: 0.95rem;
    line-height: 1.6;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    font-size: 0.9rem;
}

.form-control {
    width: 100%;
    padding: 14px 18px;
    border: 2px solid var(--border-color);
    border-radius: 12px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 1rem;
    transition: all 0.3s ease;
}

.form-control:focus {
    outline: none;
    border-color: var(--accent-text-color);
    box-shadow: 0 0 0 4px var(--primary-alpha-01);
}

.btn-reset {
    width: 100%;
    padding: 14px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border: none;
    border-radius: 12px;
    color: var(--on-accent-color);
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.btn-reset:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px var(--primary-alpha-03);
}

.forgot-footer {
    text-align: center;
    margin-top: 25px;
    padding-top: 25px;
    border-top: 1px solid var(--border-color);
}

.forgot-footer a {
    color: var(--accent-text-color);
    text-decoration: none;
    font-weight: 500;
}

.forgot-footer a:hover {
    text-decoration: underline;
}

.alert {
    padding: 15px 20px;
    border-radius: 12px;
    margin-bottom: 20px;
    display: flex;
    align-items: flex-start;
    gap: 12px;
    font-size: 0.9rem;
    line-height: 1.5;
}

.alert i {
    margin-top: 2px;
}

.alert-danger {
    background: rgba(220, 53, 69, 0.1);
    border: 1px solid rgba(220, 53, 69, 0.2);
    color: #dc3545;
}

.alert-success {
    background: rgba(40, 167, 69, 0.1);
    border: 1px solid rgba(40, 167, 69, 0.2);
    color: #28a745;
}

.input-icon {
    position: relative;
}

.input-icon i {
    position: absolute;
    left: 16px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--text-color);
    opacity: 0.4;
}

.input-icon input {
    padding-left: 48px;
}

.rate-limit-info {
    background: var(--primary-alpha-01);
    border: 1px solid var(--primary-alpha-02);
    border-radius: 10px;
    padding: 12px 15px;
    margin-top: 15px;
    font-size: 0.85rem;
    color: var(--text-color);
    opacity: 0.8;
    display: flex;
    align-items: center;
    gap: 10px;
}

.rate-limit-info i {
    color: var(--accent-text-color);
}

@media (max-width: 576px) {
    .forgot-card {
        padding: 30px 25px;
    }
    
    .forgot-header h1 {
        font-size: 1.3rem;
    }
}
</style>

<div class="forgot-page">
    <div class="forgot-container">
        <div class="forgot-card">
            <div class="forgot-header">
                <div class="forgot-icon">
                    <i class="fas fa-key"></i>
                </div>
                <h1>Şifremi Unuttum</h1>
                <p>Hesabınıza bağlı kullanıcı adınızı veya e-posta adresinizi girin. Size şifre sıfırlama linki göndereceğiz.</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <span><?php echo $error; ?></span>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <span><?php echo $success; ?></span>
                </div>
            <?php else: ?>
                <form method="POST">
                    <div class="form-group">
                        <label>Kullanıcı Adı veya E-posta</label>
                        <div class="input-icon">
                            <i class="fas fa-user"></i>
                            <input type="text" name="identifier" class="form-control" placeholder="kullaniciadi veya ornek@email.com" required autofocus>
                        </div>
                    </div>
                    
                    <?=moni_captcha_render($db)?>
                    <button type="submit" class="btn-reset">
                        <i class="fas fa-paper-plane"></i>
                        Sıfırlama Linki Gönder
                    </button>
                    
                    <div class="rate-limit-info">
                        <i class="fas fa-info-circle"></i>
                        <span>Güvenlik nedeniyle aynı hesap için dakikada en fazla 1 talep gönderilebilir.</span>
                    </div>
                </form>
            <?php endif; ?>
            
            <div class="forgot-footer">
                <a href="<?php echo SITE_URL; ?>/login.php"><i class="fas fa-arrow-left"></i> Giriş sayfasına dön</a>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>