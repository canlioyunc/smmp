<?php
/**
 * Merkezi güvenlik katmanı
 * Oturum sertleştirme, admin kapısı, CSRF, güvenlik başlıkları.
 */

if (PHP_SAPI !== 'cli' && realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
    http_response_code(404);
    exit;
}

$SEC_SESSION_REGEN_INTERVAL = 300;
$SEC_ENABLE_CSP = true;

// PHP 7.4 uyumluluk polyfill'leri (PHP 8'de yerleşik fonksiyonlar).
if (!function_exists('str_starts_with')) {
    function str_starts_with($haystack, $needle) { return $needle === '' || strpos((string)$haystack, (string)$needle) === 0; }
}
if (!function_exists('str_contains')) {
    function str_contains($haystack, $needle) { return $needle === '' || strpos((string)$haystack, (string)$needle) !== false; }
}
if (!function_exists('str_ends_with')) {
    function str_ends_with($haystack, $needle) {
        $haystack=(string)$haystack; $needle=(string)$needle;
        if ($needle === '') return true;
        return strlen($needle) <= strlen($haystack) && substr($haystack, -strlen($needle)) === $needle;
    }
}
if (!function_exists('array_is_list')) {
    function array_is_list(array $array): bool {
        $expected = 0;
        foreach ($array as $key => $_value) {
            if ($key !== $expected++) return false;
        }
        return true;
    }
}

if (PHP_SAPI !== 'cli') {
    if (session_status() === PHP_SESSION_NONE) {
        $cookieParams = session_get_cookie_params();
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
                   (getenv('MONI_TRUST_PROXY_HTTPS') === '1' && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
        session_set_cookie_params([
            'lifetime' => $cookieParams['lifetime'],
            'path' => $cookieParams['path'] ?: '/',
            'domain' => $cookieParams['domain'] ?? '',
            'secure' => $isHttps,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }

    // Oturum ID yenilemesi veritabanındaki revoke kontrolünden SONRA MoniCore içinde yapılır.
    if ($SEC_SESSION_REGEN_INTERVAL > 0 && empty($_SESSION['_sec_regen_ts'])) {
        $_SESSION['_sec_regen_ts'] = time();
    }

    $requestPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';

    // Admin sayfalarında hiçbir POST/iş mantığı rol kontrolünden önce çalışamaz.
    if (preg_match('#/admin(?:/|$)#', $requestPath) && !preg_match('#/admin/index\.php$#', $requestPath)) {
        if (empty($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
            header('Location: /admin/index.php');
            exit;
        }
    }
}

if (!function_exists('csrf_token')) {
    function csrf_token(): string {
        if (session_status() !== PHP_SESSION_ACTIVE) return '';
        if (empty($_SESSION['_csrf_token'])) {
            $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['_csrf_token'];
    }
}
if (!function_exists('csrf_field')) {
    function csrf_field(): string {
        return '<input type="hidden" name="_token" value="' . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
    }
}
if (!function_exists('csrf_check')) {
    function csrf_check($token): bool {
        return session_status() === PHP_SESSION_ACTIVE && !empty($_SESSION['_csrf_token']) &&
            is_string($token) && hash_equals($_SESSION['_csrf_token'], $token);
    }
}

if (PHP_SAPI !== 'cli') {
    $requestPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
    // Uygulama kök dizinde veya alt klasörde kurulabilir. Callback/API yollarını
    // yalnız tam dosya/segment eşleşmesiyle muaf tut; sıradan sayfaları muaf etme.
    // Yalnız açıkça stateless veya kendi imza/CSRF doğrulamasını yapan uçlar muaftır.
    // Tüm /api dizinini muaf tutmak, gelecekte eklenecek session-auth endpointlerini sessizce CSRF'ye açardı.
    $csrfExemptPatterns = [
        '#/api/myservices\.php$#',          // API key / Bearer auth
        '#/api/sandbox\.php$#',             // API key / Bearer auth
        '#/api/admin-v2\.php$#',            // Admin API token
        '#/api/email-events\.php$#',         // Dedicated webhook token
        '#/api/target-preview\.php$#',       // Endpoint kendi CSRF doğrulamasını yapar
        '#/api/web-push-subscribe\.php$#',   // JSON body içinden kendi CSRF doğrulaması
        '#/api/web-push-unsubscribe\.php$#', // JSON body içinden kendi CSRF doğrulaması
        '#/api/web-push-pending\.php$#',     // Push endpoint+auth secret ile stateless
        '#/kullanici/iyzico-callback\.php$#',
        '#/cronmoni\.php$#',
        '#/telegram-miniapp\.php$#',
    ];
    $csrfExempt = false;
    foreach ($csrfExemptPatterns as $pattern) {
        if (preg_match($pattern, $requestPath)) { $csrfExempt = true; break; }
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$csrfExempt) {
        $token = $_POST['_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
        if (!csrf_check($token)) {
            http_response_code(419);
            header('Content-Type: text/html; charset=UTF-8');
            exit('Güvenlik doğrulaması başarısız. Sayfayı yenileyip tekrar deneyin.');
        }
    }

    if (!headers_sent()) {
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('Referrer-Policy: same-origin');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(self), publickey-credentials-get=(self)');
        $secHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (getenv('MONI_TRUST_PROXY_HTTPS') === '1' && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
        if ($secHttps) header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        if ($SEC_ENABLE_CSP) {
            $GLOBALS['_moni_csp_nonce'] = base64_encode(random_bytes(18));
            $n=$GLOBALS['_moni_csp_nonce'];
            // Inline <script>/<style> blokları nonce ile çalışır. Eski tema onclick/style öznitelikleri
            // script-src-attr/style-src-attr ile ayrı tutulur; böylece script-src artık unsafe-inline değildir.
            header("Content-Security-Policy: default-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; img-src 'self' https: data: blob:; media-src 'self' https: blob:; style-src 'self' 'nonce-$n' https://cdnjs.cloudflare.com https://fonts.googleapis.com; style-src-attr 'unsafe-inline'; script-src 'self' 'nonce-$n' https://cdnjs.cloudflare.com https://js.hcaptcha.com https://challenges.cloudflare.com https://telegram.org; script-src-elem 'self' 'nonce-$n' https://cdnjs.cloudflare.com https://js.hcaptcha.com https://challenges.cloudflare.com https://telegram.org; script-src-attr 'unsafe-inline'; connect-src 'self' https:; font-src 'self' https://cdnjs.cloudflare.com https://fonts.gstatic.com data:; frame-src 'self' https:; worker-src 'self' blob:; manifest-src 'self'; form-action 'self' https:");
        }
    }

    // Mevcut yüzlerce formu tek tek bozmak yerine token'ı merkezi olarak ekler.
    if (!defined('MONI_CSRF_BUFFER_STARTED')) {
        define('MONI_CSRF_BUFFER_STARTED', true);
        ob_start(function ($html) {
            if (!is_string($html) || stripos($html, '<html') === false) return $html;
            // RTL yönünü ortak header kullanmayan giriş/bakım gibi sayfalara da uygula.
            if (function_exists('moni_language_direction') && isset($GLOBALS['db'])) {
                $lang = function_exists('getCurrentLanguage') ? getCurrentLanguage() : 'tr';
                $dir = moni_language_direction($GLOBALS['db'], (string)$lang);
                $html = preg_replace_callback('/<html\b([^>]*)>/i', static function($m) use ($dir) {
                    if (preg_match('/\bdir\s*=/i', $m[1])) return $m[0];
                    return '<html' . $m[1] . ' dir="' . ($dir === 'rtl' ? 'rtl' : 'ltr') . '">';
                }, $html, 1);
            }

            $nonce=(string)($GLOBALS['_moni_csp_nonce']??'');
            if($nonce!==''){
                $q=htmlspecialchars($nonce,ENT_QUOTES,'UTF-8');
                $html=preg_replace('/<script(?![^>]*\bnonce=)([^>]*)>/i','<script nonce="'.$q.'"$1>',$html);
                $html=preg_replace('/<style(?![^>]*\bnonce=)([^>]*)>/i','<style nonce="'.$q.'"$1>',$html);
            }
            $token = csrf_token();
            if ($token === '') return $html;

            $field = '<input type="hidden" name="_token" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '">';
            $html = preg_replace_callback('/<form\b([^>]*)>/i', function ($m) use ($field) {
                $attrs = $m[1];
                if (!preg_match('/\bmethod\s*=\s*["\']?post\b/i', $attrs)) return $m[0];
                return $m[0] . $field;
            }, $html);

            $safeToken = json_encode($token, JSON_UNESCAPED_SLASHES);
            $nonceAttr=htmlspecialchars((string)($GLOBALS['_moni_csp_nonce']??''),ENT_QUOTES,'UTF-8');
            $script = '<script nonce="'.$nonceAttr.'">(function(){var t='.$safeToken.';window.MONI_CSRF_TOKEN=t;function so(u){try{return new URL(u||location.href,location.href).origin===location.origin;}catch(e){return false;}}function sf(f){if(!f||!t)return;var m=(f.getAttribute("method")||"GET").toUpperCase();if(m!=="POST"||!so(f.getAttribute("action")||location.href))return;var x=f.querySelector("input[name=\"_token\"]");if(!x){x=document.createElement("input");x.type="hidden";x.name="_token";f.appendChild(x);}x.value=t;}document.addEventListener("submit",function(e){sf(e.target);},true);if(window.HTMLFormElement&&HTMLFormElement.prototype){var ns=HTMLFormElement.prototype.submit;HTMLFormElement.prototype.submit=function(){sf(this);return ns.call(this);};var nr=HTMLFormElement.prototype.requestSubmit;if(nr){HTMLFormElement.prototype.requestSubmit=function(){sf(this);return nr.apply(this,arguments);};}}var of=window.fetch;if(of){window.fetch=function(i,o){o=o||{};var method=(o.method||((i&&i.method)?i.method:"GET")).toUpperCase();var url=(typeof i==="string"?i:(i&&i.url?i.url:location.href));if(method==="POST"&&t&&so(url)){o.headers=new Headers(o.headers||((i&&i.headers)?i.headers:{}));if(!o.headers.has("X-CSRF-Token"))o.headers.set("X-CSRF-Token",t);}return of.call(this,i,o);};}var X=window.XMLHttpRequest;if(X&&X.prototype){var oo=X.prototype.open,os=X.prototype.send;X.prototype.open=function(m,u){this.__moniMethod=(m||"GET").toUpperCase();this.__moniUrl=u;return oo.apply(this,arguments);};X.prototype.send=function(){if(this.__moniMethod==="POST"&&t&&so(this.__moniUrl)){try{this.setRequestHeader("X-CSRF-Token",t);}catch(e){}}return os.apply(this,arguments);};}})();</script>';
            if (stripos($html, '</body>') !== false) {
                return preg_replace('/<\/body>/i', $script . '</body>', $html, 1);
            }
            return $html . $script;
        });
    }
}

if (!function_exists('require_login')) {
    function require_login(string $redirect = '/login.php') {
        if (empty($_SESSION['user_id'])) {
            header('Location: ' . $redirect);
            exit;
        }
    }
}
if (!function_exists('require_role')) {
    function require_role($roles, string $redirect = '/login.php') {
        $roles = (array)$roles;
        if (empty($_SESSION['role'])) {
            header('Location: ' . $redirect);
            exit;
        }
        if (!in_array($_SESSION['role'], $roles, true)) {
            http_response_code(403);
            exit('Forbidden');
        }
    }
}
