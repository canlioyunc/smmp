<?php
// Sayfa başlığı
$pageTitle = 'E-posta Doğrulama';

// Config + header
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/mail.php'; // gerekirse

// Token al
$token = $_GET['token'] ?? '';
$status = 'error';
$message = 'Token bulunamadı.';

if ($token) {
    try {
        $stmt = $db->prepare("SELECT id, user_id, expires_at, used FROM email_verification_tokens WHERE token IN (?,?) LIMIT 1");
        $stmt->execute([hash('sha256',$token),$token]);
        $row = $stmt->fetch();

        if (!$row) {
            $message = 'Geçersiz doğrulama bağlantısı.';
        } elseif ((int)$row['used'] === 1) {
            $message = 'Bu doğrulama bağlantısı zaten kullanılmış.';
        } elseif (strtotime($row['expires_at']) < time()) {
            $message = 'Doğrulama bağlantısının süresi dolmuş.';
        } else {
            $db->beginTransaction();
            $db->prepare("UPDATE users SET email_verified = 1 WHERE id = ?")->execute([$row['user_id']]);
            $db->prepare("UPDATE email_verification_tokens SET used = 1 WHERE id = ?")->execute([$row['id']]);
            $db->commit();

            $status = 'success';
            $message = 'E-posta doğrulandı! Artık giriş yapabilirsiniz.';
        }
    } catch (Exception $e) {
        if ($db->inTransaction()) $db->rollBack();
        $message = 'Bir hata oluştu. Lütfen tekrar deneyin.';
    }
}

// Header (tema stilleri için)
require_once __DIR__ . '/includes/header.php';
?>
<style>
    .verify-wrapper {
        min-height: calc(100vh - 140px);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 40px 16px;
        background: radial-gradient(circle at 20% 20%, rgba(255,255,255,0.04), transparent 35%),
                    radial-gradient(circle at 80% 0%, rgba(255,255,255,0.03), transparent 30%),
                    radial-gradient(circle at 50% 100%, rgba(255,255,255,0.05), transparent 35%),
                    var(--background-color);
    }
    .verify-card {
        width: 100%;
        max-width: 520px;
        background: var(--card-bg-color);
        border: 1px solid var(--border-color);
        border-radius: 18px;
        box-shadow: 0 25px 80px rgba(0,0,0,0.25);
        padding: 32px 28px;
        text-align: center;
    }
    .verify-icon {
        width: 80px; height: 80px;
        margin: 0 auto 18px;
        border-radius: 20px;
        display: grid;
        place-items: center;
        font-size: 36px;
        color: var(--on-accent-color);
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        box-shadow: 0 10px 30px var(--primary-alpha-035);
    }
    .verify-title {
        font-size: 1.4rem;
        font-weight: 700;
        color: var(--text-color);
        margin-bottom: 10px;
    }
    .verify-text {
        color: var(--text-color);
        opacity: 0.8;
        margin-bottom: 18px;
        line-height: 1.6;
    }
    .verify-status {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        padding: 10px 14px;
        border-radius: 12px;
        font-weight: 600;
        margin-bottom: 20px;
        border: 1px solid var(--border-color);
    }
    .verify-status.success {
        color: var(--success-color);
        background: rgba(40, 167, 69, 0.12);
        border-color: rgba(40, 167, 69, 0.35);
    }
    .verify-status.error {
        color: var(--danger-color);
        background: rgba(220, 53, 69, 0.12);
        border-color: rgba(220, 53, 69, 0.35);
    }
    .verify-actions {
        display: flex;
        gap: 12px;
        justify-content: center;
        flex-wrap: wrap;
        margin-top: 8px;
    }
    .btn-ghost {
        border: 1px solid var(--border-color);
        color: var(--text-color);
        padding: 10px 16px;
        border-radius: 10px;
        font-weight: 600;
        background: transparent;
        cursor: pointer;
        transition: all .2s ease;
    }
    .btn-ghost:hover {
        border-color: var(--accent-text-color);
        color: var(--accent-text-color);
    }
</style>

<div class="verify-wrapper">
    <div class="verify-card">
        <div class="verify-icon">
            <?php if ($status === 'success'): ?>
                <i class="fas fa-check"></i>
            <?php else: ?>
                <i class="fas fa-exclamation"></i>
            <?php endif; ?>
        </div>
        <div class="verify-status <?php echo $status; ?>">
            <?php if ($status === 'success'): ?>
                <i class="fas fa-badge-check"></i>
                <span>Başarılı</span>
            <?php else: ?>
                <i class="fas fa-times-circle"></i>
                <span>Hata</span>
            <?php endif; ?>
        </div>
        <div class="verify-title">E-posta Doğrulama</div>
        <div class="verify-text">
            <?php echo clean($message); ?>
        </div>
        <div class="verify-actions">
            <?php if ($status === 'success'): ?>
                <a class="btn btn-primary" href="<?php echo SITE_URL; ?>/login.php">
                    <i class="fas fa-sign-in-alt"></i> Giriş Yap
                </a>
            <?php else: ?>
                <a class="btn btn-primary" href="<?php echo SITE_URL; ?>/register.php">
                    <i class="fas fa-user-plus"></i> Yeniden Kayıt
                </a>
            <?php endif; ?>
            <a class="btn-ghost" href="<?php echo SITE_URL; ?>/">
                <i class="fas fa-home"></i> Ana Sayfa
            </a>
        </div>
    </div>
</div>

<?php
// Footer veya main kapanışı (header.php main açıyor)
require_once __DIR__ . '/includes/footer.php';