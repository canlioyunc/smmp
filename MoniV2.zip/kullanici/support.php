<?php
/**
 * Kullanıcı Paneli - Destek Merkezi
 * Mobil uyumlu sipariş seçimi ile
 */

require_once __DIR__ . '/../config.php';
if (!empty($_SESSION['user_id']) && function_exists('moni_user_can') && !moni_user_can($db,(int)$_SESSION['user_id'],'support.create',true)) { http_response_code(403); exit('Destek talebi açma yetkiniz kapalı.'); }

// Oturum kontrolü
if (!isLoggedIn()) {
    header('Location: /login.php');
    exit;
}

// Kullanıcı ID'sini session'dan al
$userId = $_SESSION['user_id'];

$success = '';
$error = '';
$departments = moni_table_ready($db,'support_departments') ? $db->query("SELECT * FROM support_departments WHERE is_active=1 ORDER BY sort_order,id")->fetchAll(PDO::FETCH_ASSOC) : [];
if(function_exists('moni_support_department_status')){foreach($departments as &$dep){$dep['_support_status']=moni_support_department_status($db,(int)$dep['id']);}unset($dep);}

$uploadDir = __DIR__ . '/../uploads/support/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

/**
 * Kullanıcının sahip olduğu sipariş ID'lerini doğrula ve süz.
 */
function filterUserOrderIds(PDO $db, int $userId, array $orderIds): array {
    $orderIds = array_filter(array_map('intval', $orderIds));
    if (empty($orderIds)) return [];
    $placeholders = implode(',', array_fill(0, count($orderIds), '?'));
    $stmt = $db->prepare("SELECT id FROM orders WHERE user_id = ? AND id IN ($placeholders)");
    $stmt->execute(array_merge([$userId], $orderIds));
    return array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'id');
}

// Yeni destek talebi oluştur
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_ticket'])) {
    $subject   = trim($_POST['subject'] ?? '');
    $message   = trim($_POST['message'] ?? '');
    $orderId   = !empty($_POST['order_id']) ? (int)$_POST['order_id'] : null;
    $orderIds  = isset($_POST['order_ids']) && is_array($_POST['order_ids']) ? $_POST['order_ids'] : [];
    $priority  = $_POST['priority'] ?? 'medium';
    $departmentId = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;
    if($departmentId){$ds=$db->prepare("SELECT id FROM support_departments WHERE id=? AND is_active=1");$ds->execute([$departmentId]);if(!$ds->fetchColumn())$departmentId=null;}
    if($departmentId && function_exists('moni_support_department_status')){$dsStatus=moni_support_department_status($db,$departmentId);if(empty($dsStatus['open'])&&empty($dsStatus['accept_after_hours'])){$error=$dsStatus['message']??'Bu destek departmanı şu anda mesai dışında.';if(!empty($dsStatus['next_open']))$error.=' Sonraki açılış: '.$dsStatus['next_open'];}}
    
    if ($error !== '') {
        // Mesai politikası gibi ön doğrulama hataları korunur.
    } elseif (empty($subject)) {
        $error = __('subject_required');
    } elseif (empty($message)) {
        $error = __('message_required');
    } else {
        if ($orderId) {
            $checkOrder = $db->prepare("SELECT id FROM orders WHERE id = ? AND user_id = ?");
            $checkOrder->execute([$orderId, $userId]);
            if (!$checkOrder->fetch()) $orderId = null;
        }
        $validOrderIds = filterUserOrderIds($db, $userId, $orderIds);
        
        try {
            $db->beginTransaction();
            
            $stmt = $db->prepare("INSERT INTO support_tickets (user_id, order_id, subject, priority, department_id) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$userId, $orderId, $subject, $priority, $departmentId]);
            $ticketId = $db->lastInsertId();
            
            if (!empty($validOrderIds)) {
                $ins = $db->prepare("INSERT INTO support_ticket_orders (ticket_id, order_id) VALUES (?, ?)");
                foreach ($validOrderIds as $oid) {
                    $ins->execute([$ticketId, $oid]);
                }
            }
            
            $attachment = null;
            if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] !== UPLOAD_ERR_NO_FILE) {
                $upload = moni_safe_upload($_FILES['attachment'], 'support', ['image/jpeg','image/png','image/gif','image/webp'], 5 * 1024 * 1024);
                if (!$upload['ok']) throw new RuntimeException($upload['error']);
                $attachment = $upload['path'];
            }
            
            $stmt = $db->prepare("INSERT INTO support_messages (ticket_id, user_id, message, attachment, is_admin) VALUES (?, ?, ?, ?, 0)");
            $stmt->execute([$ticketId, $userId, $message, $attachment]);
            
            // Adminlere e-posta bildirimi
            $adminEmails = $db->query("SELECT email FROM users WHERE role = 'admin' AND status = 'active' AND email <> ''")->fetchAll(PDO::FETCH_COLUMN);
            $adminEmails = array_values(array_filter(array_map('trim', $adminEmails)));
            if (!empty($adminEmails) && function_exists('sendEmail')) {
                // Kullanıcı bilgilerini al
                $userStmt = $db->prepare("SELECT username, email FROM users WHERE id = ?");
                $userStmt->execute([$userId]);
                $userData = $userStmt->fetch();
                
                $siteUrl    = function_exists('moni_canonical_site_url') ? moni_canonical_site_url() : rtrim((string)(defined('SITE_URL')?SITE_URL:''),'/');
                $ticketLink = $siteUrl . '/admin/support.php?ticket=' . $ticketId;
                $ordersText = !empty($validOrderIds) ? ('#' . implode(', #', $validOrderIds)) : ($orderId ? '#'.$orderId : 'Yok');
                $userName   = $userData['username'] ?? 'Kullanıcı';
                $userEmail  = $userData['email'] ?? '-';
                
                $mailSubject = 'Yeni Destek Talebi #' . $ticketId;
                $mailBody = '
                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin:0 auto; padding:20px; background:#fff; border:1px solid #eee;">
                        <h2 style="margin-top:0;color:#333;">Yeni destek talebi oluşturuldu</h2>
                        <p><strong>Kullanıcı:</strong> ' . htmlspecialchars($userName) . ' (' . htmlspecialchars($userEmail) . ')</p>
                        <p><strong>Konu:</strong> ' . htmlspecialchars($subject) . '</p>
                        <p><strong>Öncelik:</strong> ' . htmlspecialchars($priority) . '</p>
                        <p><strong>Siparişler:</strong> ' . htmlspecialchars($ordersText) . '</p>
                        <p><strong>Mesaj:</strong><br>' . nl2br(htmlspecialchars($message)) . '</p>
                        <p><a href="' . htmlspecialchars($ticketLink) . '" style="display:inline-block;padding:10px 16px;background:#6c5ce7;color:#fff;text-decoration:none;border-radius:6px;">Talebi Görüntüle</a></p>
                    </div>';
                
                foreach ($adminEmails as $adminEmail) {
                    sendEmail($adminEmail, $mailSubject, $mailBody);
                }
            }
            
            $db->commit();
            header('Location: support.php?ticket=' . $ticketId . '&success=created');
            exit;
        } catch (Exception $e) {
            $db->rollBack();
            $error = $e->getMessage();
        }
    }
}

// Mesaj gönder
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    $ticketId = (int)($_POST['ticket_id'] ?? 0);
    $message = trim($_POST['message'] ?? '');
    
    $ticket = $db->prepare("SELECT * FROM support_tickets WHERE id = ? AND user_id = ?");
    $ticket->execute([$ticketId, $userId]);
    $ticket = $ticket->fetch();
    
    if (!$ticket) {
        $error = __('ticket_not_found');
    } elseif ($ticket['status'] === 'closed') {
        $error = __('ticket_closed');
    } elseif (empty($message)) {
        $error = __('message_required');
    } else {
        $attachment = null;
        if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] !== UPLOAD_ERR_NO_FILE) {
            $upload = moni_safe_upload($_FILES['attachment'], 'support', ['image/jpeg','image/png','image/gif','image/webp'], 5 * 1024 * 1024);
            if (!$upload['ok']) { $error = $upload['error']; }
            else { $attachment = $upload['path']; }
        }
        
        if (!$error) {
        $stmt = $db->prepare("INSERT INTO support_messages (ticket_id, user_id, message, attachment, is_admin) VALUES (?, ?, ?, ?, 0)");
        $stmt->execute([$ticketId, $userId, $message, $attachment]);
        
        $stmt = $db->prepare("UPDATE support_tickets SET status = 'open', updated_at = NOW() WHERE id = ?");
        $stmt->execute([$ticketId]);
        
        header('Location: support.php?ticket=' . $ticketId . '&success=sent');
        exit;
        }
    }
}

if (isset($_GET['success'])) {
    $success = $_GET['success'] === 'created' ? __('ticket_created_success') : __('message_sent_success');
}

// Ticket görüntüleme
$viewTicket = null;
$ticketMessages = [];
$ticketOrders = [];

if (isset($_GET['ticket'])) {
    $ticketId = (int)$_GET['ticket'];
    
    $stmt = $db->prepare("
        SELECT t.*, o.id as order_id, s.name as service_name 
        FROM support_tickets t 
        LEFT JOIN orders o ON t.order_id = o.id 
        LEFT JOIN services s ON o.service_id = s.id 
        WHERE t.id = ? AND t.user_id = ?
    ");
    $stmt->execute([$ticketId, $userId]);
    $viewTicket = $stmt->fetch();
    
    if ($viewTicket) {
        $stmt = $db->prepare("
            SELECT m.*, u.username 
            FROM support_messages m 
            LEFT JOIN users u ON m.user_id = u.id 
            WHERE m.ticket_id = ? 
            ORDER BY m.created_at ASC
        ");
        $stmt->execute([$ticketId]);
        $ticketMessages = $stmt->fetchAll();
        
        $stmt = $db->prepare("
            SELECT o.id, s.name AS service_name
            FROM support_ticket_orders sto
            JOIN orders o ON sto.order_id = o.id
            LEFT JOIN services s ON o.service_id = s.id
            WHERE sto.ticket_id = ?
            ORDER BY o.id DESC
        ");
        $stmt->execute([$ticketId]);
        $ticketOrders = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $db->prepare("UPDATE support_messages SET is_read = 1 WHERE ticket_id = ? AND is_admin = 1 AND is_read = 0")->execute([$ticketId]);
    }
}

// Filtreler
$statusFilter = $_GET['status'] ?? '';
$where = "WHERE t.user_id = ?";
$params = [$userId];

if ($statusFilter) {
    $where .= " AND t.status = ?";
    $params[] = $statusFilter;
}

$tickets = $db->prepare("
    SELECT t.*, 
           (SELECT COUNT(*) FROM support_messages WHERE ticket_id = t.id AND is_admin = 1 AND is_read = 0) as unread_count 
    FROM support_tickets t 
    $where 
    ORDER BY t.updated_at DESC
");
$tickets->execute($params);
$tickets = $tickets->fetchAll();

// İstatistikler
$statsStmt = $db->prepare("
    SELECT 
        COUNT(*) as total, 
        SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END) as open_count, 
        SUM(CASE WHEN status = 'answered' THEN 1 ELSE 0 END) as answered_count, 
        SUM(CASE WHEN status = 'closed' THEN 1 ELSE 0 END) as closed_count 
    FROM support_tickets 
    WHERE user_id = ?
");
$statsStmt->execute([$userId]);
$ticketStats = $statsStmt->fetch();

// Kullanıcının siparişleri
$userOrders = $db->prepare("
    SELECT o.id, o.created_at, o.status, s.name as service_name 
    FROM orders o 
    LEFT JOIN services s ON o.service_id = s.id 
    WHERE o.user_id = ? 
    ORDER BY o.created_at DESC 
    LIMIT 50
");
$userOrders->execute([$userId]);
$userOrders = $userOrders->fetchAll();

$pageTitle = __('support_center');
require_once 'header.php';
?>

<style>
/* Stats Row */
.stats-row {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
    margin-bottom: 25px;
}

@media (max-width: 768px) {
    .stats-row {
        grid-template-columns: repeat(2, 1fr);
    }
}

.stat-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 12px;
    padding: 20px;
    text-align: center;
}

.stat-card .value {
    font-size: 1.8rem;
    font-weight: 700;
    margin-bottom: 5px;
}

.stat-card .label {
    font-size: 0.85rem;
    opacity: 0.6;
}

.stat-card.total .value { color: var(--accent-text-color); }
.stat-card.open .value { color: var(--warning-color); }
.stat-card.answered .value { color: var(--success-color); }
.stat-card.closed .value { color: var(--muted-text-color); }

/* Support Layout */
.support-layout {
    display: grid;
    grid-template-columns: 380px 1fr;
    gap: 25px;
    min-height: 600px;
}

@media (max-width: 1100px) {
    .support-layout {
        grid-template-columns: 1fr;
    }
}

/* Tickets Sidebar */
.tickets-sidebar {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    display: flex;
    flex-direction: column;
    max-height: 700px;
}

@media (max-width: 1100px) {
    .tickets-sidebar {
        max-height: 400px;
    }
}

.sidebar-header {
    padding: 20px;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-shrink: 0;
}

.sidebar-header h3 {
    font-size: 1.1rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 10px;
}

.sidebar-header h3 i {
    color: var(--accent-text-color);
}

.new-ticket-btn {
    padding: 10px 18px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border: none;
    border-radius: 10px;
    color: var(--on-accent-color);
    font-size: 0.85rem;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
}

.new-ticket-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 20px var(--primary-alpha-03);
}

/* Status Tabs */
.status-tabs {
    display: flex;
    padding: 15px 20px;
    gap: 10px;
    border-bottom: 1px solid var(--border-color);
    flex-shrink: 0;
    overflow-x: auto;
}

.status-tab {
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 500;
    text-decoration: none;
    color: var(--text-color);
    background: var(--background-color);
    border: 1px solid var(--border-color);
    white-space: nowrap;
    transition: all 0.2s ease;
}

.status-tab:hover,
.status-tab.active {
    background: var(--primary-color);
    border-color: var(--accent-text-color);
    color: var(--on-primary-color);
}

.status-tab .count {
    margin-left: 5px;
    opacity: 0.8;
}

/* Tickets List */
.tickets-list {
    flex: 1;
    overflow-y: auto;
    padding: 10px;
}

.ticket-item {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 15px;
    border-radius: 12px;
    cursor: pointer;
    text-decoration: none;
    color: var(--text-color);
    margin-bottom: 8px;
    transition: all 0.2s ease;
}

.ticket-item:hover {
    background: var(--background-color);
}

.ticket-item.active {
    background: var(--primary-alpha-015);
    border-left: 3px solid var(--primary-color);
}

.ticket-item.unread {
    background: var(--primary-alpha-008);
}

.ticket-icon {
    width: 45px;
    height: 45px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
    flex-shrink: 0;
}

.ticket-icon.open { background: var(--warning-soft-bg); color: var(--warning-color); }
.ticket-icon.answered { background: var(--success-soft-bg); color: var(--success-color); }
.ticket-icon.closed { background: rgba(108, 117, 125, 0.15); color: var(--muted-text-color); }

.ticket-info {
    flex: 1;
    min-width: 0;
}

.ticket-info h4 {
    font-size: 0.9rem;
    font-weight: 600;
    margin-bottom: 4px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.ticket-info p {
    font-size: 0.8rem;
    opacity: 0.6;
}

.ticket-meta {
    text-align: right;
    flex-shrink: 0;
}

.ticket-meta .date {
    font-size: 0.75rem;
    opacity: 0.5;
    margin-bottom: 5px;
}

.ticket-meta .unread-badge {
    background: var(--primary-color);
    color: var(--on-primary-color);
    font-size: 0.7rem;
    padding: 3px 10px;
    border-radius: 10px;
    font-weight: 600;
}

.empty-tickets {
    text-align: center;
    padding: 50px 20px;
    opacity: 0.6;
}

.empty-tickets i {
    font-size: 3rem;
    margin-bottom: 15px;
    opacity: 0.3;
    display: block;
}

/* Support Main */
.support-main {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    display: flex;
    flex-direction: column;
    min-height: 600px;
}

/* Ticket Header */
.ticket-header {
    padding: 20px 25px;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    flex-wrap: wrap;
    gap: 15px;
    flex-shrink: 0;
}

.ticket-header-info h2 {
    font-size: 1.1rem;
    font-weight: 600;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}

.ticket-header-info h2 .ticket-id {
    font-size: 0.85rem;
    color: var(--accent-text-color);
    font-weight: 500;
}

.ticket-header-meta {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.ticket-header-meta span {
    font-size: 0.85rem;
    opacity: 0.6;
    display: flex;
    align-items: center;
    gap: 5px;
}

.ticket-header-meta i {
    color: var(--accent-text-color);
}

.ticket-status-badge {
    padding: 8px 18px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 600;
}

.ticket-status-badge.open { background: var(--warning-soft-bg); color: var(--warning-color); }
.ticket-status-badge.answered { background: var(--success-soft-bg); color: var(--success-color); }
.ticket-status-badge.closed { background: rgba(108, 117, 125, 0.15); color: var(--muted-text-color); }

/* Messages Container */
.messages-container {
    flex: 1;
    overflow-y: auto;
    padding: 25px;
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.message-item {
    display: flex;
    gap: 15px;
    max-width: 80%;
}

.message-item.user {
    margin-left: auto;
    flex-direction: row-reverse;
}

.message-avatar {
    width: 40px;
    height: 40px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    font-size: 0.9rem;
    flex-shrink: 0;
}

.message-item.admin .message-avatar {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--on-accent-color);
}

.message-item.user .message-avatar {
    background: var(--background-color);
    color: var(--text-color);
}

.message-content {
    flex: 1;
    min-width: 0;
}

.message-bubble {
    padding: 15px 20px;
    border-radius: 16px;
    font-size: 0.9rem;
    line-height: 1.6;
    word-wrap: break-word;
}

.message-item.admin .message-bubble {
    background: var(--background-color);
    border-top-left-radius: 4px;
}

.message-item.user .message-bubble {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--on-accent-color);
    border-top-right-radius: 4px;
}

.message-attachment {
    margin-top: 10px;
}

.message-attachment img {
    max-width: 280px;
    max-height: 200px;
    border-radius: 12px;
    cursor: pointer;
    transition: transform 0.2s ease;
}

.message-attachment img:hover {
    transform: scale(1.02);
}

.message-time {
    font-size: 0.75rem;
    opacity: 0.5;
    margin-top: 8px;
}

.message-item.user .message-time {
    text-align: right;
}

/* Reply Form */
.reply-form {
    padding: 20px 25px;
    border-top: 1px solid var(--border-color);
    flex-shrink: 0;
}

.reply-form.disabled {
    opacity: 0.6;
    pointer-events: none;
}

.reply-form-inner {
    display: flex;
    gap: 15px;
    align-items: flex-start;
}

@media (max-width: 576px) {
    .reply-form-inner {
        flex-direction: column;
    }
}

.reply-textarea-wrapper {
    flex: 1;
}

.reply-textarea-wrapper textarea {
    width: 100%;
    padding: 15px 18px;
    border: 2px solid var(--border-color);
    border-radius: 12px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 0.95rem;
    resize: none;
    min-height: 80px;
    transition: all 0.3s ease;
    font-family: inherit;
}

.reply-textarea-wrapper textarea:focus {
    outline: none;
    border-color: var(--accent-text-color);
}

.reply-buttons {
    display: flex;
    gap: 10px;
    flex-shrink: 0;
}

@media (max-width: 576px) {
    .reply-buttons {
        width: 100%;
        justify-content: flex-end;
    }
}

.attachment-label {
    width: 48px;
    height: 48px;
    border: 2px solid var(--border-color);
    border-radius: 12px;
    background: var(--background-color);
    color: var(--text-color);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.1rem;
    transition: all 0.2s ease;
}

.attachment-label:hover {
    border-color: var(--accent-text-color);
    color: var(--accent-text-color);
}

.attachment-label.has-file {
    background: var(--primary-color);
    border-color: var(--accent-text-color);
    color: var(--on-primary-color);
}

.attachment-label input {
    display: none;
}

.send-btn {
    padding: 14px 28px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border: none;
    border-radius: 12px;
    color: var(--on-accent-color);
    font-size: 0.95rem;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 10px;
    transition: all 0.3s ease;
    white-space: nowrap;
}

.send-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 20px var(--primary-alpha-03);
}

/* Welcome State */
.welcome-state {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 50px;
    text-align: center;
}

.welcome-state i {
    font-size: 5rem;
    color: var(--accent-text-color);
    opacity: 0.3;
    margin-bottom: 25px;
}

.welcome-state h3 {
    font-size: 1.3rem;
    margin-bottom: 10px;
}

.welcome-state p {
    opacity: 0.6;
    margin-bottom: 25px;
    max-width: 400px;
}

/* Modal */
.modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    z-index: 2000;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.modal-overlay.active {
    display: flex;
}

.modal-box {
    background: var(--card-bg-color);
    border-radius: 20px;
    width: 100%;
    max-width: 550px;
    max-height: 90vh;
    overflow-y: auto;
    animation: modalSlide 0.3s ease;
}

@keyframes modalSlide {
    from { opacity: 0; transform: translateY(-30px) scale(0.95); }
    to { opacity: 1; transform: translateY(0) scale(1); }
}

.modal-header {
    padding: 25px;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h3 {
    font-size: 1.15rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 10px;
}

.modal-header h3 i {
    color: var(--accent-text-color);
}

.modal-close {
    background: var(--background-color);
    border: none;
    width: 40px;
    height: 40px;
    border-radius: 10px;
    font-size: 1.3rem;
    cursor: pointer;
    color: var(--text-color);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
}

.modal-close:hover {
    background: var(--danger-color);
    color: var(--on-danger-color);
}

.modal-body {
    padding: 25px;
}

.form-group {
    margin-bottom: 20px;
}

.form-label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    font-size: 0.9rem;
}

.form-label .optional {
    opacity: 0.5;
    font-weight: 400;
}

.form-control {
    width: 100%;
    padding: 14px 18px;
    border: 2px solid var(--border-color);
    border-radius: 12px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 0.95rem;
    transition: all 0.3s ease;
    font-family: inherit;
}

.form-control:focus {
    outline: none;
    border-color: var(--accent-text-color);
}

textarea.form-control {
    min-height: 120px;
    resize: vertical;
}

/* Gelişmiş Sipariş Seçici */
.order-selector {
    border: 2px solid var(--border-color);
    border-radius: 12px;
    background: var(--background-color);
    overflow: hidden;
}

.order-selector-header {
    padding: 12px 15px;
    background: var(--card-bg-color);
    border-bottom: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
}

.order-selector-search {
    flex: 1;
    min-width: 150px;
    padding: 8px 12px;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 0.85rem;
}

.order-selector-search:focus {
    outline: none;
    border-color: var(--accent-text-color);
}

.order-selector-actions {
    display: flex;
    gap: 8px;
}

.order-selector-actions button {
    padding: 6px 12px;
    border: 1px solid var(--border-color);
    border-radius: 6px;
    background: var(--card-bg-color);
    color: var(--text-color);
    font-size: 0.75rem;
    cursor: pointer;
    transition: all 0.2s ease;
}

.order-selector-actions button:hover {
    background: var(--primary-color);
    border-color: var(--accent-text-color);
    color: var(--on-primary-color);
}

.order-selector-list {
    max-height: 250px;
    overflow-y: auto;
    padding: 8px;
}

.order-selector-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    border-radius: 10px;
    cursor: pointer;
    transition: all 0.2s ease;
    margin-bottom: 6px;
    border: 2px solid transparent;
}

.order-selector-item:hover {
    background: var(--card-bg-color);
}

.order-selector-item.selected {
    background: var(--primary-alpha-01);
    border-color: var(--accent-text-color);
}

.order-selector-item input[type="checkbox"] {
    display: none;
}

.order-checkbox {
    width: 22px;
    height: 22px;
    border: 2px solid var(--border-color);
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    transition: all 0.2s ease;
    background: var(--background-color);
}

.order-selector-item.selected .order-checkbox {
    background: var(--primary-color);
    border-color: var(--accent-text-color);
}

.order-checkbox i {
    color: #fff;
    font-size: 0.7rem;
    opacity: 0;
    transition: opacity 0.2s ease;
}

.order-selector-item.selected .order-checkbox i {
    opacity: 1;
}

.order-item-info {
    flex: 1;
    min-width: 0;
}

.order-item-id {
    font-weight: 600;
    font-size: 0.9rem;
    color: var(--accent-text-color);
    margin-bottom: 2px;
}

.order-item-service {
    font-size: 0.8rem;
    opacity: 0.7;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.order-item-meta {
    text-align: right;
    flex-shrink: 0;
}

.order-item-date {
    font-size: 0.75rem;
    opacity: 0.5;
    margin-bottom: 2px;
}

.order-item-status {
    font-size: 0.7rem;
    padding: 3px 8px;
    border-radius: 10px;
    font-weight: 500;
}

.order-item-status.completed { background: var(--success-soft-bg); color: var(--success-color); }
.order-item-status.pending { background: var(--warning-soft-bg); color: var(--warning-color); }
.order-item-status.processing { background: rgba(0, 123, 255, 0.15); color: var(--info-color); }
.order-item-status.cancelled { background: var(--danger-soft-bg); color: var(--danger-color); }
.order-item-status.partial { background: rgba(108, 117, 125, 0.15); color: var(--muted-text-color); }
.order-item-status.in_progress { background: rgba(0, 123, 255, 0.15); color: var(--info-color); }

.order-selector-footer {
    padding: 12px 15px;
    background: var(--card-bg-color);
    border-top: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.selected-count {
    font-size: 0.85rem;
    color: var(--accent-text-color);
    font-weight: 500;
}

.selected-orders-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    max-width: 70%;
}

.selected-order-tag {
    background: var(--primary-color);
    color: var(--on-primary-color);
    padding: 4px 10px;
    border-radius: 15px;
    font-size: 0.75rem;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 5px;
}

.selected-order-tag .remove-tag {
    cursor: pointer;
    opacity: 0.8;
    transition: opacity 0.2s;
}

.selected-order-tag .remove-tag:hover {
    opacity: 1;
}

.order-selector-empty {
    text-align: center;
    padding: 30px 20px;
    opacity: 0.5;
}

.order-selector-empty i {
    font-size: 2rem;
    margin-bottom: 10px;
    display: block;
}

/* File Upload */
.file-upload {
    border: 2px dashed var(--border-color);
    border-radius: 12px;
    padding: 25px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
}

.file-upload:hover {
    border-color: var(--accent-text-color);
    background: var(--primary-alpha-005);
}

.file-upload.has-file {
    border-color: var(--success-color);
    background: rgba(40, 167, 69, 0.05);
}

.file-upload i {
    font-size: 2rem;
    color: var(--accent-text-color);
    margin-bottom: 10px;
    display: block;
}

.file-upload p {
    font-size: 0.9rem;
    margin-bottom: 5px;
}

.file-upload span {
    font-size: 0.8rem;
    opacity: 0.5;
}

.file-upload input {
    display: none;
}

.file-preview {
    display: none;
    margin-top: 15px;
    padding: 12px 15px;
    background: var(--background-color);
    border-radius: 10px;
    align-items: center;
    gap: 15px;
}

.file-preview.active {
    display: flex;
}

.file-preview img {
    width: 50px;
    height: 50px;
    object-fit: cover;
    border-radius: 8px;
}

.file-preview .info {
    flex: 1;
}

.file-preview .info p {
    font-size: 0.85rem;
    font-weight: 500;
    margin: 0;
}

.file-preview .info span {
    font-size: 0.75rem;
    opacity: 0.6;
}

.file-preview .remove {
    background: var(--danger-color);
    color: var(--on-danger-color);
    border: none;
    width: 30px;
    height: 30px;
    border-radius: 8px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

.modal-footer {
    padding: 20px 25px;
    border-top: 1px solid var(--border-color);
}

.modal-footer .btn {
    width: 100%;
    padding: 16px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border: none;
    border-radius: 12px;
    color: var(--on-accent-color);
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    transition: all 0.3s ease;
}

.modal-footer .btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px var(--primary-alpha-035);
}

/* Lightbox */
.lightbox {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.9);
    z-index: 3000;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.lightbox.active {
    display: flex;
}

.lightbox img {
    max-width: 90%;
    max-height: 90%;
    border-radius: 12px;
}

.lightbox-close {
    position: absolute;
    top: 20px;
    right: 20px;
    background: rgba(255, 255, 255, 0.1);
    border: none;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    color: #fff;
    font-size: 1.5rem;
    cursor: pointer;
}

/* Priority Row */
.priority-row {
    margin-bottom: 20px;
}

.priority-row .form-label {
    margin-bottom: 10px;
}

.priority-options {
    display: flex;
    gap: 10px;
}

.priority-option {
    flex: 1;
    position: relative;
}

.priority-option input {
    position: absolute;
    opacity: 0;
    pointer-events: none;
}

.priority-option label {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 15px 10px;
    border: 2px solid var(--border-color);
    border-radius: 12px;
    cursor: pointer;
    transition: all 0.2s ease;
    background: var(--background-color);
}

.priority-option label i {
    font-size: 1.3rem;
    margin-bottom: 5px;
}

.priority-option label span {
    font-size: 0.8rem;
    font-weight: 500;
}

.priority-option.low label i { color: var(--success-color); }
.priority-option.medium label i { color: var(--warning-color); }
.priority-option.high label i { color: var(--danger-color); }

.priority-option input:checked + label {
    border-color: var(--accent-text-color);
    background: var(--primary-alpha-01);
}

@media (max-width: 400px) {
    .priority-options {
        flex-direction: column;
    }
    
    .priority-option label {
        flex-direction: row;
        justify-content: center;
        gap: 10px;
        padding: 12px;
    }
    
    .priority-option label i {
        margin-bottom: 0;
    }
}
</style>
<?php if ($success): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?php echo clean($success); ?>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?php echo clean($error); ?>
    </div>
<?php endif; ?>

<!-- Stats Row -->
<div class="stats-row">
    <div class="stat-card total">
        <div class="value"><?php echo $ticketStats['total'] ?? 0; ?></div>
        <div class="label"><?php echo __('total_tickets'); ?></div>
    </div>
    <div class="stat-card open">
        <div class="value"><?php echo $ticketStats['open_count'] ?? 0; ?></div>
        <div class="label"><?php echo __('ticket_status_open'); ?></div>
    </div>
    <div class="stat-card answered">
        <div class="value"><?php echo $ticketStats['answered_count'] ?? 0; ?></div>
        <div class="label"><?php echo __('ticket_status_answered'); ?></div>
    </div>
    <div class="stat-card closed">
        <div class="value"><?php echo $ticketStats['closed_count'] ?? 0; ?></div>
        <div class="label"><?php echo __('ticket_status_closed'); ?></div>
    </div>
</div>

<!-- Support Layout -->
<div class="support-layout">
    <!-- Tickets Sidebar -->
    <div class="tickets-sidebar">
        <div class="sidebar-header">
            <h3><i class="fas fa-ticket-alt"></i> <?php echo __('my_tickets'); ?></h3>
            <button type="button" class="new-ticket-btn" onclick="openModal('newTicketModal')">
                <i class="fas fa-plus"></i> <?php echo __('new_ticket'); ?>
            </button>
        </div>
        
        <div class="status-tabs">
            <a href="support.php" class="status-tab <?php echo !$statusFilter ? 'active' : ''; ?>">
                <?php echo __('all'); ?> <span class="count">(<?php echo $ticketStats['total'] ?? 0; ?>)</span>
            </a>
            <a href="support.php?status=open" class="status-tab <?php echo $statusFilter === 'open' ? 'active' : ''; ?>"><?php echo __('ticket_status_open'); ?></a>
            <a href="support.php?status=answered" class="status-tab <?php echo $statusFilter === 'answered' ? 'active' : ''; ?>"><?php echo __('ticket_status_answered'); ?></a>
            <a href="support.php?status=closed" class="status-tab <?php echo $statusFilter === 'closed' ? 'active' : ''; ?>"><?php echo __('ticket_status_closed'); ?></a>
        </div>
        
        <div class="tickets-list">
            <?php if (empty($tickets)): ?>
                <div class="empty-tickets">
                    <i class="fas fa-inbox"></i>
                    <p><?php echo __('no_support_tickets'); ?></p>
                </div>
            <?php else: ?>
                <?php foreach ($tickets as $ticket): ?>
                    <a href="support.php?ticket=<?php echo $ticket['id']; ?>" 
                       class="ticket-item <?php echo ($viewTicket && $viewTicket['id'] == $ticket['id']) ? 'active' : ''; ?> <?php echo $ticket['unread_count'] > 0 ? 'unread' : ''; ?>">
                        <div class="ticket-icon <?php echo $ticket['status']; ?>">
                            <i class="fas fa-<?php echo $ticket['status'] === 'closed' ? 'check' : ($ticket['status'] === 'answered' ? 'reply' : 'clock'); ?>"></i>
                        </div>
                        <div class="ticket-info">
                            <h4><?php echo clean($ticket['subject']); ?></h4>
                            <p>#<?php echo $ticket['id']; ?> • <?php echo __('ticket_status_' . $ticket['status']); ?></p>
                        </div>
                        <div class="ticket-meta">
                            <div class="date"><?php echo date('d.m.Y', strtotime($ticket['updated_at'])); ?></div>
                            <?php if ($ticket['unread_count'] > 0): ?>
                                <span class="unread-badge"><?php echo $ticket['unread_count']; ?> <?php echo __('new'); ?></span>
                            <?php endif; ?>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="support-main">
        <?php if ($viewTicket): ?>
            <!-- Ticket Header -->
            <div class="ticket-header">
                <div class="ticket-header-info">
                    <h2>
                        <?php echo clean($viewTicket['subject']); ?>
                        <span class="ticket-id">#<?php echo $viewTicket['id']; ?></span>
                    </h2>
                    <div class="ticket-header-meta">
                        <span><i class="fas fa-calendar"></i> <?php echo moni_format_user_time($db,(int)$_SESSION['user_id'],$viewTicket['created_at']); ?></span>
                        <span><i class="fas fa-flag"></i> <?php echo __('priority_' . ($viewTicket['priority'] ?? 'medium')); ?></span>
                        <?php if (!empty($viewTicket['order_id'])): ?>
                            <span><i class="fas fa-shopping-cart"></i> <?php echo __('order'); ?> #<?php echo $viewTicket['order_id']; ?></span>
                        <?php endif; ?>
                        <?php if (!empty($ticketOrders)): ?>
                            <span><i class="fas fa-list"></i> <?php echo __('related_orders'); ?>:
                                <?php foreach ($ticketOrders as $idx => $o): ?>
                                    #<?php echo $o['id']; ?><?php if ($idx < count($ticketOrders)-1) echo ','; ?>
                                <?php endforeach; ?>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <span class="ticket-status-badge <?php echo $viewTicket['status']; ?>">
                    <?php echo __('ticket_status_' . $viewTicket['status']); ?>
                </span>
            </div>
            
            <!-- Messages -->
            <div class="messages-container" id="messagesContainer">
                <?php foreach ($ticketMessages as $msg): ?>
                    <div class="message-item <?php echo $msg['is_admin'] ? 'admin' : 'user'; ?>">
                        <div class="message-avatar">
                            <?php if ($msg['is_admin']): ?>
                                <i class="fas fa-headset"></i>
                            <?php else: ?>
                                <?php echo strtoupper(mb_substr($msg['username'] ?? 'U', 0, 1, 'UTF-8')); ?>
                            <?php endif; ?>
                        </div>
                        <div class="message-content">
                            <div class="message-bubble">
                                <?php echo nl2br(clean($msg['message'])); ?>
                            </div>
                            <?php if (!empty($msg['attachment'])): ?>
                                <div class="message-attachment">
                                    <img src="/<?php echo clean($msg['attachment']); ?>" alt="<?php echo __('attachment'); ?>" onclick="openLightbox(this.src)">
                                </div>
                            <?php endif; ?>
                            <div class="message-time">
                                <?php echo $msg['is_admin'] ? __('support_team') : clean($msg['username'] ?? 'User'); ?> • 
                                <?php echo moni_format_user_time($db,(int)$_SESSION['user_id'],$msg['created_at']); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Reply Form -->
            <div class="reply-form <?php echo $viewTicket['status'] === 'closed' ? 'disabled' : ''; ?>">
                <?php if ($viewTicket['status'] === 'closed'): ?>
                    <p style="text-align: center; opacity: 0.6; padding: 10px;">
                        <i class="fas fa-lock"></i> <?php echo __('this_ticket_closed'); ?>
                    </p>
                <?php else: ?>
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="ticket_id" value="<?php echo $viewTicket['id']; ?>">
                        <div class="reply-form-inner">
                            <div class="reply-textarea-wrapper">
                                <textarea name="message" placeholder="<?php echo __('write_your_message'); ?>..." required></textarea>
                            </div>
                            <div class="reply-buttons">
                                <label class="attachment-label" id="replyAttachmentLabel" title="<?php echo __('attach_file'); ?>">
                                    <i class="fas fa-paperclip"></i>
                                    <input type="file" name="attachment" accept="image/*" onchange="handleReplyAttachment(this)">
                                </label>
                                <button type="submit" name="send_message" class="send-btn">
                                    <i class="fas fa-paper-plane"></i> <?php echo __('send'); ?>
                                </button>
                            </div>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <!-- Welcome State -->
            <div class="welcome-state">
                <i class="fas fa-headset"></i>
                <h3><?php echo __('support_center'); ?></h3>
                <p><?php echo __('support_welcome_message'); ?></p>
                <button type="button" class="new-ticket-btn" onclick="openModal('newTicketModal')" style="font-size: 1rem; padding: 14px 28px;">
                    <i class="fas fa-plus"></i> <?php echo __('create_new_support_ticket'); ?>
                </button>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- New Ticket Modal -->
<div class="modal-overlay" id="newTicketModal">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fas fa-plus-circle"></i> <?php echo __('new_support_ticket'); ?></h3>
            <button type="button" class="modal-close" onclick="closeModal('newTicketModal')">&times;</button>
        </div>
        <form method="POST" enctype="multipart/form-data" id="newTicketForm">
            <div class="modal-body">
                
                <!-- Gelişmiş Sipariş Seçici -->
                <div class="form-group">
                    <label class="form-label"><?php echo __('related_orders'); ?> <span class="optional">(<?php echo __('optional'); ?>)</span></label>
                    
                    <div class="order-selector">
                        <div class="order-selector-header">
                            <input type="text" class="order-selector-search" id="orderSearch" placeholder="<?php echo __('search_order'); ?>...">
                            <div class="order-selector-actions">
                                <button type="button" onclick="selectAllOrders()"><?php echo __('select_all'); ?></button>
                                <button type="button" onclick="clearAllOrders()"><?php echo __('clear'); ?></button>
                            </div>
                        </div>
                        
                        <div class="order-selector-list" id="orderList">
                            <?php if (empty($userOrders)): ?>
                                <div class="order-selector-empty">
                                    <i class="fas fa-shopping-cart"></i>
                                    <p><?php echo __('no_orders_found'); ?></p>
                                </div>
                            <?php else: ?>
                                <?php foreach ($userOrders as $order): ?>
                                    <label class="order-selector-item" data-order-id="<?php echo $order['id']; ?>" data-search="<?php echo $order['id'] . ' ' . strtolower($order['service_name'] ?? ''); ?>">
                                        <input type="checkbox" name="order_ids[]" value="<?php echo $order['id']; ?>">
                                        <div class="order-checkbox">
                                            <i class="fas fa-check"></i>
                                        </div>
                                        <div class="order-item-info">
                                            <div class="order-item-id">#<?php echo $order['id']; ?></div>
                                            <div class="order-item-service"><?php echo clean($order['service_name'] ?? __('order')); ?></div>
                                        </div>
                                        <div class="order-item-meta">
                                            <div class="order-item-date"><?php echo date('d.m.Y', strtotime($order['created_at'])); ?></div>
                                            <span class="order-item-status <?php echo $order['status'] ?? 'pending'; ?>"><?php echo __('order_status_' . ($order['status'] ?? 'pending')); ?></span>
                                        </div>
                                    </label>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                        
                        <div class="order-selector-footer">
                            <span class="selected-count"><span id="selectedCount">0</span> <?php echo __('order_selected'); ?></span>
                            <div class="selected-orders-tags" id="selectedTags"></div>
                        </div>
                    </div>
                    
                    <input type="hidden" name="order_id" value="">
                </div>
                
                <?php if(!empty($departments)): ?>
                <div class="form-group"><label class="form-label">Destek Departmanı *</label><select name="department_id" id="supportDepartmentSelect" class="form-control" required><option value="">Departman seçin</option><?php foreach($departments as $dep):$st=$dep['_support_status']??['open'=>true,'accept_after_hours'=>true,'label'=>'Açık','message'=>''];?><option value="<?=(int)$dep['id']?>" data-open="<?=!empty($st['open'])?'1':'0'?>" data-accept="<?=!empty($st['accept_after_hours'])?'1':'0'?>" data-message="<?=clean($st['message']??'')?>"><?=clean($dep['name'])?> · <?=clean($st['label']??'Açık')?></option><?php endforeach;?></select><p class="form-hint">Talebiniz doğrudan ilgili destek ekibine yönlendirilir.</p><div id="supportHoursNotice" class="form-hint" style="display:none;margin-top:8px;padding:10px 12px;border-radius:10px;background:var(--primary-alpha-008);border:1px solid var(--border-color)"></div></div>
<script>(function(){var s=document.getElementById('supportDepartmentSelect'),n=document.getElementById('supportHoursNotice');if(!s||!n)return;function u(){var o=s.options[s.selectedIndex];if(!o||!o.value){n.style.display='none';return;}var open=o.dataset.open==='1',accept=o.dataset.accept==='1',msg=o.dataset.message||'';n.style.display='block';n.textContent=(open?'Açık · ':'Mesai dışında · ')+(msg||(!open&&accept?'Talebiniz alınır ve ilk çalışma saatinde işleme alınır.':(!open?'Şu anda yeni talep kabul edilmiyor.':'Departman hizmet veriyor.')));}s.addEventListener('change',u);u();})();</script>
                <?php endif; ?>

                <!-- Öncelik Seçimi -->
                <div class="priority-row">
                    <label class="form-label"><?php echo __('priority'); ?></label>
                    <div class="priority-options">
                        <div class="priority-option low">
                            <input type="radio" name="priority" id="priority_low" value="low">
                            <label for="priority_low">
                                <i class="fas fa-arrow-down"></i>
                                <span><?php echo __('priority_low'); ?></span>
                            </label>
                        </div>
                        <div class="priority-option medium">
                            <input type="radio" name="priority" id="priority_medium" value="medium" checked>
                            <label for="priority_medium">
                                <i class="fas fa-minus"></i>
                                <span><?php echo __('priority_medium'); ?></span>
                            </label>
                        </div>
                        <div class="priority-option high">
                            <input type="radio" name="priority" id="priority_high" value="high">
                            <label for="priority_high">
                                <i class="fas fa-arrow-up"></i>
                                <span><?php echo __('priority_high'); ?></span>
                            </label>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php echo __('subject'); ?> *</label>
                    <input type="text" name="subject" class="form-control" placeholder="<?php echo __('briefly_describe_issue'); ?>" required maxlength="255">
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php echo __('message'); ?> *</label>
                    <textarea name="message" class="form-control" placeholder="<?php echo __('describe_issue_detail'); ?>..." required></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php echo __('screenshot'); ?> <span class="optional">(<?php echo __('optional'); ?>)</span></label>
                    <div class="file-upload" id="fileUploadArea" onclick="document.getElementById('fileInput').click()">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <p><?php echo __('click_to_select_file'); ?></p>
                        <span>JPG, PNG, GIF, WEBP - <?php echo __('max'); ?> 5MB</span>
                        <input type="file" id="fileInput" name="attachment" accept="image/*" onchange="handleFileSelect(this)">
                    </div>
                    <div class="file-preview" id="filePreview">
                        <img src="" alt="" id="previewImage">
                        <div class="info">
                            <p id="fileName"></p>
                            <span id="fileSize"></span>
                        </div>
                        <button type="button" class="remove" onclick="removeFile()">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" name="create_ticket" class="btn">
                    <i class="fas fa-paper-plane"></i> <?php echo __('submit_ticket'); ?>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Image Lightbox -->
<div class="lightbox" id="lightbox" onclick="closeLightbox()">
    <button class="lightbox-close">&times;</button>
    <img src="" alt="" id="lightboxImage">
</div>

<script>
// Çeviri metinleri
const t = {
    only_images_allowed: '<?php echo __('only_images_allowed'); ?>',
    max_file_size_5mb: '<?php echo __('max_file_size_5mb'); ?>',
    attach_file: '<?php echo __('attach_file'); ?>',
    order_selected: '<?php echo __('order_selected'); ?>'
};

// ===== Sipariş Seçici Fonksiyonları =====
const orderItems = document.querySelectorAll('.order-selector-item');
const selectedCountEl = document.getElementById('selectedCount');
const selectedTagsEl = document.getElementById('selectedTags');
const orderSearchEl = document.getElementById('orderSearch');

if (orderItems.length > 0) {
    orderItems.forEach(item => {
        item.addEventListener('click', function(e) {
            if (e.target.closest('.remove-tag')) return;
            
            const checkbox = this.querySelector('input[type="checkbox"]');
            checkbox.checked = !checkbox.checked;
            this.classList.toggle('selected', checkbox.checked);
            updateSelectedDisplay();
        });
    });
}

function updateSelectedDisplay() {
    const selectedItems = document.querySelectorAll('.order-selector-item.selected');
    if (selectedCountEl) selectedCountEl.textContent = selectedItems.length;
    
    if (selectedTagsEl) {
        selectedTagsEl.innerHTML = '';
        selectedItems.forEach(item => {
            const orderId = item.dataset.orderId;
            const tag = document.createElement('span');
            tag.className = 'selected-order-tag';
            tag.innerHTML = `#${orderId} <i class="fas fa-times remove-tag" onclick="removeOrder(${orderId})"></i>`;
            selectedTagsEl.appendChild(tag);
        });
    }
}

function removeOrder(orderId) {
    const item = document.querySelector(`.order-selector-item[data-order-id="${orderId}"]`);
    if (item) {
        const checkbox = item.querySelector('input[type="checkbox"]');
        checkbox.checked = false;
        item.classList.remove('selected');
        updateSelectedDisplay();
    }
}

function selectAllOrders() {
    const visibleItems = document.querySelectorAll('.order-selector-item:not([style*="display: none"])');
    visibleItems.forEach(item => {
        const checkbox = item.querySelector('input[type="checkbox"]');
        checkbox.checked = true;
        item.classList.add('selected');
    });
    updateSelectedDisplay();
}

function clearAllOrders() {
    orderItems.forEach(item => {
        const checkbox = item.querySelector('input[type="checkbox"]');
        checkbox.checked = false;
        item.classList.remove('selected');
    });
    updateSelectedDisplay();
}

if (orderSearchEl) {
    orderSearchEl.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase().trim();
        
        orderItems.forEach(item => {
            const searchData = item.dataset.search || '';
            if (searchTerm === '' || searchData.includes(searchTerm)) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
    });
}

// ===== Modal Fonksiyonları =====
function openModal(id) {
    const modal = document.getElementById(id);
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(id) {
    const modal = document.getElementById(id);
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }
}

document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) {
            this.classList.remove('active');
            document.body.style.overflow = '';
        }
    });
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(modal => {
            modal.classList.remove('active');
        });
        document.body.style.overflow = '';
        closeLightbox();
    }
});

// ===== Dosya Yükleme =====
function handleFileSelect(input) {
    const file = input.files[0];
    if (file) {
        const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        const maxSize = 5 * 1024 * 1024;
        
        if (!allowedTypes.includes(file.type)) {
            alert(t.only_images_allowed);
            input.value = '';
            return;
        }
        
        if (file.size > maxSize) {
            alert(t.max_file_size_5mb);
            input.value = '';
            return;
        }
        
        const reader = new FileReader();
        reader.onload = function(e) {
            const previewImage = document.getElementById('previewImage');
            const fileName = document.getElementById('fileName');
            const fileSize = document.getElementById('fileSize');
            const filePreview = document.getElementById('filePreview');
            const fileUploadArea = document.getElementById('fileUploadArea');
            
            if (previewImage) previewImage.src = e.target.result;
            if (fileName) fileName.textContent = file.name;
            if (fileSize) fileSize.textContent = formatFileSize(file.size);
            if (filePreview) filePreview.classList.add('active');
            if (fileUploadArea) fileUploadArea.classList.add('has-file');
        };
        reader.readAsDataURL(file);
    }
}

function removeFile() {
    const fileInput = document.getElementById('fileInput');
    const filePreview = document.getElementById('filePreview');
    const fileUploadArea = document.getElementById('fileUploadArea');
    
    if (fileInput) fileInput.value = '';
    if (filePreview) filePreview.classList.remove('active');
    if (fileUploadArea) fileUploadArea.classList.remove('has-file');
}

function formatFileSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

function handleReplyAttachment(input) {
    const label = document.getElementById('replyAttachmentLabel');
    if (label) {
        if (input.files.length > 0) {
            label.classList.add('has-file');
            label.title = input.files[0].name;
        } else {
            label.classList.remove('has-file');
            label.title = t.attach_file;
        }
    }
}

// ===== Lightbox =====
function openLightbox(src) {
    const lightboxImage = document.getElementById('lightboxImage');
    const lightbox = document.getElementById('lightbox');
    if (lightboxImage) lightboxImage.src = src;
    if (lightbox) lightbox.classList.add('active');
}

function closeLightbox() {
    const lightbox = document.getElementById('lightbox');
    if (lightbox) lightbox.classList.remove('active');
}

// Mesajları en alta kaydır
const messagesContainer = document.getElementById('messagesContainer');
if (messagesContainer) {
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}
</script>

<?php require_once 'footer.php'; ?>