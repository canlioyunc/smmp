<?php
/**
 * Kullanıcı Paneli - Günlük Bonus
 * Türkiye saat dilimi kullanılır (Europe/Istanbul)
 */

// Türkiye saat dilimini ayarla
date_default_timezone_set('Europe/Istanbul');

// Önce header'ı dahil et (config ve fonksiyonlar yüklenir)
require_once __DIR__ . '/header.php';

// Sayfa başlığını ayarla
$pageTitle = __('daily_bonus') ?: 'Günlük Bonus';

// Bonus ayarlarını al
function getBonusSettings($db) {
    $settings = [];
    try {
        $stmt = $db->query("SELECT setting_key, setting_value FROM daily_bonus_settings");
        while ($row = $stmt->fetch()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
    } catch (Exception $e) {
        // Tablo yoksa varsayılan değerler kullanılacak
    }
    return $settings;
}

// Ayarları al
$bonusSettings = getBonusSettings($db);
$isActive = ($bonusSettings['is_active'] ?? '1') === '1';
$claimIntervalHours = (int)($bonusSettings['claim_interval_hours'] ?? 24);
$bonusAmounts = json_decode($bonusSettings['bonus_amounts'] ?? '[0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50]', true);
$streakResetHours = (int)($bonusSettings['streak_reset_hours'] ?? 48);
$minBalanceRequired = (float)($bonusSettings['min_balance_required'] ?? 0);
$maxStreakDays = (int)($bonusSettings['max_streak_days'] ?? 7);

// Kullanıcının son bonus bilgisini al
$lastBonus = null;
try {
    $lastBonusStmt = $db->prepare("
        SELECT * FROM daily_bonus 
        WHERE user_id = ? 
        ORDER BY claimed_at DESC 
        LIMIT 1
    ");
    $lastBonusStmt->execute([$currentUser['id']]);
    $lastBonus = $lastBonusStmt->fetch();
} catch (Exception $e) {
    // Tablo yoksa
}

// Şu anki zaman (Türkiye)
$now = new DateTime('now', new DateTimeZone('Europe/Istanbul'));

// Son bonus zamanı ve seri hesaplama
$canClaim = false;
$currentStreak = 1;
$nextClaimTime = null;
$timeRemaining = null;

if ($lastBonus) {
    $lastClaimTime = new DateTime($lastBonus['claimed_at'], new DateTimeZone('Europe/Istanbul'));
    $hoursSinceLastClaim = ($now->getTimestamp() - $lastClaimTime->getTimestamp()) / 3600;
    
    // Bonus alınabilir mi?
    if ($hoursSinceLastClaim >= $claimIntervalHours) {
        $canClaim = true;
        
        // Seri devam ediyor mu?
        if ($hoursSinceLastClaim < $streakResetHours) {
            $currentStreak = $lastBonus['streak'] + 1;
            if ($currentStreak > $maxStreakDays) {
                $currentStreak = 1;
            }
        } else {
            $currentStreak = 1;
        }
    } else {
        $canClaim = false;
        $nextClaimTime = clone $lastClaimTime;
        $nextClaimTime->modify("+{$claimIntervalHours} hours");
        $timeRemaining = $nextClaimTime->getTimestamp() - $now->getTimestamp();
        $currentStreak = $lastBonus['streak'];
    }
} else {
    $canClaim = true;
    $currentStreak = 1;
}

// Bonus miktarını hesapla
$bonusIndex = min($currentStreak - 1, count($bonusAmounts) - 1);
$currentBonusAmount = $bonusAmounts[$bonusIndex];

// Bonus al işlemi
$message = '';
$messageType = '';
$redirectAfterClaim = false;
$claimedAmount = 0;
$claimedStreak = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['claim_bonus'])) {
    if (!$isActive) {
        $message = __('bonus_inactive') ?: 'Günlük bonus sistemi şu anda aktif değil'; $messageType='danger';
    } else {
        try {
            $db->beginTransaction();
            // Kullanıcı satırı tüm paralel bonus isteklerini sıraya sokar.
            $u=$db->prepare("SELECT balance,username FROM users WHERE id=? FOR UPDATE");$u->execute([$currentUser['id']]);$lockedUser=$u->fetch(PDO::FETCH_ASSOC);
            if(!$lockedUser) throw new RuntimeException('Kullanıcı bulunamadı.');
            if((float)$lockedUser['balance'] < $minBalanceRequired) throw new RuntimeException('MIN_BALANCE');
            $lb=$db->prepare("SELECT streak,claimed_at FROM daily_bonus WHERE user_id=? ORDER BY claimed_at DESC,id DESC LIMIT 1");$lb->execute([$currentUser['id']]);$last=$lb->fetch(PDO::FETCH_ASSOC);
            $streak=1;
            if($last){
                $seconds=time()-strtotime($last['claimed_at']);
                if($seconds < $claimIntervalHours*3600) throw new RuntimeException('ALREADY');
                if($seconds < $streakResetHours*3600){$streak=(int)$last['streak']+1;if($streak>$maxStreakDays)$streak=1;}
            }
            $idx=min($streak-1,count($bonusAmounts)-1);$amount=(float)$bonusAmounts[$idx];
            $db->prepare("INSERT INTO daily_bonus(user_id,amount,streak,claimed_at,ip_address) VALUES(?,?,?,NOW(),?)")
               ->execute([$currentUser['id'],$amount,$streak,moni_client_ip()]);
            $db->prepare("UPDATE users SET balance=balance+? WHERE id=?")->execute([$amount,$currentUser['id']]);
            $q=$db->prepare("SELECT balance FROM users WHERE id=?");$q->execute([$currentUser['id']]);$newBalance=(float)$q->fetchColumn();
            $desc=(__('daily_bonus') ?: 'Günlük Bonus').' - '.$streak.'. '.(__('day') ?: 'Gün');
            $db->prepare("INSERT INTO transactions(user_id,type,amount,balance_after,description,status,created_at) VALUES(?,'bonus',?,?,?,'completed',NOW())")
               ->execute([$currentUser['id'],$amount,$newBalance,$desc]);
            $db->prepare("INSERT INTO daily_bonus_logs(user_id,username,amount,streak,balance_before,balance_after,ip_address,user_agent,created_at) VALUES(?,?,?,?,?,?,?,?,NOW())")
               ->execute([$currentUser['id'],$lockedUser['username'],$amount,$streak,$lockedUser['balance'],$newBalance,moni_client_ip(),$_SERVER['HTTP_USER_AGENT']??null]);
            $db->commit();
            moni_sync_base_wallet($db,(int)$currentUser['id']);
            $claimedAmount=$amount;$claimedStreak=$streak;$currentBonusAmount=$amount;$currentStreak=$streak;
            $message=(__('bonus_claim_success') ?: 'Tebrikler! Günlük bonusunuz hesabınıza eklendi').' (+'.$siteSettings['currency_symbol'].number_format($amount,2).')';$messageType='success';
            $_SESSION['balance']=$newBalance;$currentUser['balance']=$newBalance;$canClaim=false;$redirectAfterClaim=true;
            $lastClaimTime=new DateTime('now',new DateTimeZone('Europe/Istanbul'));$nextClaimTime=clone $lastClaimTime;$nextClaimTime->modify("+{$claimIntervalHours} hours");$timeRemaining=$nextClaimTime->getTimestamp()-$now->getTimestamp();
        } catch(Throwable $e){
            if($db->inTransaction())$db->rollBack();
            if($e->getMessage()==='ALREADY'){$message=__('bonus_already_claimed') ?: 'Bugünkü bonusunuzu zaten aldınız';$messageType='warning';}
            elseif($e->getMessage()==='MIN_BALANCE'){$message=(__('min_balance_required') ?: 'Minimum bakiye gerekli').': '.$siteSettings['currency_symbol'].number_format($minBalanceRequired,2);$messageType='warning';}
            else{error_log('Daily Bonus Claim Error: '.$e->getMessage());$message=__('error_occurred') ?: 'Bir hata oluştu!';$messageType='danger';}
        }
    }
}

// URL'den başarı mesajı
if (isset($_GET['success']) && $_GET['success'] == '1') {
    $claimedAmount = (float)($_GET['amount'] ?? 0);
    $message = (__('bonus_claim_success') ?: 'Tebrikler! Günlük bonusunuz hesabınıza eklendi') . ' (+' . $siteSettings['currency_symbol'] . number_format($claimedAmount, 2) . ')';
    $messageType = 'success';
    
    // Verileri yeniden yükle
    try {
        $lastBonusStmt = $db->prepare("
            SELECT * FROM daily_bonus 
            WHERE user_id = ? 
            ORDER BY claimed_at DESC 
            LIMIT 1
        ");
        $lastBonusStmt->execute([$currentUser['id']]);
        $lastBonus = $lastBonusStmt->fetch();
        $canClaim = false;
        
        if ($lastBonus) {
            $lastClaimTime = new DateTime($lastBonus['claimed_at'], new DateTimeZone('Europe/Istanbul'));
            $nextClaimTime = clone $lastClaimTime;
            $nextClaimTime->modify("+{$claimIntervalHours} hours");
            $timeRemaining = max(0, $nextClaimTime->getTimestamp() - $now->getTimestamp());
            $currentStreak = $lastBonus['streak'];
        }
        
        // Güncel bakiyeyi al
        $balanceStmt = $db->prepare("SELECT balance FROM users WHERE id = ?");
        $balanceStmt->execute([$currentUser['id']]);
        $currentUser['balance'] = $balanceStmt->fetchColumn();
        $_SESSION['balance'] = $currentUser['balance'];
        
    } catch (Exception $e) {
        // Hata durumunda devam et
    }
}

// İstatistikleri al
$stats = ['total_claims' => 0, 'total_earned' => 0, 'max_streak' => 0];
try {
    $statsStmt = $db->prepare("
        SELECT 
            COUNT(*) as total_claims,
            COALESCE(SUM(amount), 0) as total_earned,
            COALESCE(MAX(streak), 0) as max_streak
        FROM daily_bonus 
        WHERE user_id = ?
    ");
    $statsStmt->execute([$currentUser['id']]);
    $stats = $statsStmt->fetch();
} catch (Exception $e) {
    // Tablo yoksa varsayılan değerler
}

// Bonus geçmişi
$bonusHistory = [];
try {
    $historyStmt = $db->prepare("
        SELECT * FROM daily_bonus 
        WHERE user_id = ? 
        ORDER BY claimed_at DESC 
        LIMIT 10
    ");
    $historyStmt->execute([$currentUser['id']]);
    $bonusHistory = $historyStmt->fetchAll();
} catch (Exception $e) {
    // Tablo yoksa boş array
}
?>

<?php if ($redirectAfterClaim): ?>
<script>
    // Çift gönderimi önlemek için sayfayı yenile
    window.location.href = 'daily-bonus.php?success=1&amount=<?php echo $claimedAmount; ?>';
</script>
<?php endif; ?>

<style>
    .bonus-container {
        max-width: 900px;
        margin: 0 auto;
    }
    
    .bonus-main-card {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
        border-radius: 20px;
        padding: 40px;
        color: #fff;
        text-align: center;
        margin-bottom: 30px;
        position: relative;
        overflow: hidden;
    }
    
    .bonus-main-card::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
        animation: pulse-bg 4s ease-in-out infinite;
    }
    
    @keyframes pulse-bg {
        0%, 100% { transform: scale(1); opacity: 0.5; }
        50% { transform: scale(1.1); opacity: 0.8; }
    }
    
    .bonus-main-card > * {
        position: relative;
        z-index: 1;
    }
    
    .bonus-inactive-overlay {
        background: rgba(0,0,0,0.7);
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10;
        border-radius: 20px;
    }
    
    .bonus-inactive-text {
        background: rgba(220, 53, 69, 0.9);
        padding: 20px 40px;
        border-radius: 12px;
        font-size: 1.1rem;
        font-weight: 600;
    }
    
    .bonus-icon {
        width: 100px;
        height: 100px;
        background: rgba(255,255,255,0.2);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 25px;
        font-size: 3rem;
        animation: bounce-icon 2s ease-in-out infinite;
    }
    
    @keyframes bounce-icon {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-10px); }
    }
    
    .bonus-icon.claimed {
        animation: none;
        opacity: 0.6;
    }
    
    .bonus-title {
        font-size: 1.8rem;
        font-weight: 700;
        margin-bottom: 10px;
    }
    
    .bonus-subtitle {
        font-size: 1rem;
        opacity: 0.9;
        margin-bottom: 25px;
    }
    
    .bonus-amount-display {
        font-size: 3.5rem;
        font-weight: 800;
        margin-bottom: 10px;
        text-shadow: 0 4px 15px rgba(0,0,0,0.2);
    }
    
    .bonus-streak-info {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        background: rgba(255,255,255,0.2);
        padding: 8px 20px;
        border-radius: 25px;
        font-size: 0.95rem;
        margin-bottom: 30px;
    }
    
    .claim-btn {
        background: var(--accent-action-bg-color);
        color: var(--accent-action-text-color);
        border: none;
        padding: 18px 50px;
        font-size: 1.2rem;
        font-weight: 700;
        border-radius: 50px;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
    }
    
    .claim-btn:hover:not(:disabled) {
        transform: translateY(-3px) scale(1.02);
        box-shadow: 0 15px 40px rgba(0,0,0,0.3);
    }
    
    .claim-btn:disabled {
        opacity: 0.7;
        cursor: not-allowed;
        background: rgba(255,255,255,0.5);
    }
    
    .countdown-container {
        margin-top: 25px;
    }
    
    .countdown-label {
        font-size: 0.9rem;
        opacity: 0.8;
        margin-bottom: 15px;
    }
    
    .countdown-timer {
        display: flex;
        justify-content: center;
        gap: 15px;
    }
    
    .countdown-item {
        background: rgba(255,255,255,0.15);
        padding: 15px 20px;
        border-radius: 12px;
        min-width: 80px;
    }
    
    .countdown-value {
        font-size: 2rem;
        font-weight: 700;
        display: block;
    }
    
    .countdown-unit {
        font-size: 0.75rem;
        opacity: 0.8;
        text-transform: uppercase;
    }
    
    /* Streak Progress */
    .streak-progress-card {
        background: var(--card-bg-color);
        border: 1px solid var(--border-color);
        border-radius: 16px;
        padding: 25px;
        margin-bottom: 25px;
    }
    
    .streak-progress-title {
        font-size: 1.1rem;
        font-weight: 600;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .streak-progress-title i {
        color: var(--warning-color);
    }
    
    .streak-days {
        display: flex;
        justify-content: space-between;
        gap: 10px;
    }
    
    .streak-day {
        flex: 1;
        text-align: center;
        padding: 15px 10px;
        background: var(--background-color);
        border-radius: 12px;
        border: 2px solid var(--border-color);
        transition: all 0.3s ease;
    }
    
    .streak-day.completed {
        background: linear-gradient(135deg, var(--success-color), #20c997);
        border-color: var(--success-color);
        color: #fff;
    }
    
    .streak-day.current {
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        border-color: var(--accent-text-color);
        color: #fff;
        transform: scale(1.05);
        box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
    }
    
    .streak-day.upcoming {
        opacity: 0.5;
    }
    
    .streak-day-number {
        font-size: 0.8rem;
        opacity: 0.8;
        margin-bottom: 5px;
    }
    
    .streak-day-amount {
        font-size: 1rem;
        font-weight: 700;
    }
    
    .streak-day-icon {
        font-size: 1.2rem;
        margin-top: 5px;
    }
    
    /* Stats Cards */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 25px;
    }
    
    .stat-card {
        background: var(--card-bg-color);
        border: 1px solid var(--border-color);
        border-radius: 16px;
        padding: 25px;
        text-align: center;
    }
    
    .stat-icon {
        width: 50px;
        height: 50px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 15px;
        font-size: 1.3rem;
    }
    
    .stat-icon.purple { background: rgba(102, 126, 234, 0.15); color: var(--accent-text-color); }
    .stat-icon.green { background: var(--success-soft-bg); color: var(--success-color); }
    .stat-icon.orange { background: var(--warning-soft-bg); color: var(--warning-color); }
    
    .stat-value {
        font-size: 1.8rem;
        font-weight: 700;
        color: var(--text-color);
        margin-bottom: 5px;
    }
    
    .stat-label {
        font-size: 0.85rem;
        color: var(--text-color);
        opacity: 0.7;
    }
    
    /* History Table */
    .history-card {
        background: var(--card-bg-color);
        border: 1px solid var(--border-color);
        border-radius: 16px;
        overflow: hidden;
    }
    
    .history-header {
        padding: 20px 25px;
        border-bottom: 1px solid var(--border-color);
        font-size: 1.1rem;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .history-header i {
        color: var(--accent-text-color);
    }
    
    .history-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .history-table th,
    .history-table td {
        padding: 15px 20px;
        text-align: left;
        border-bottom: 1px solid var(--border-color);
    }
    
    .history-table th {
        background: var(--background-color);
        font-weight: 600;
        font-size: 0.85rem;
        text-transform: uppercase;
        color: var(--text-color);
        opacity: 0.7;
    }
    
    .history-table tr:last-child td {
        border-bottom: none;
    }
    
    .history-table tr:hover td {
        background: var(--background-color);
    }
    
    .amount-cell {
        color: var(--success-color);
        font-weight: 600;
    }
    
    .streak-badge {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        background: var(--warning-soft-bg);
        color: var(--warning-color);
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
    }
    
    .empty-history {
        padding: 50px 20px;
        text-align: center;
        color: var(--text-color);
        opacity: 0.6;
    }
    
    .empty-history i {
        font-size: 3rem;
        margin-bottom: 15px;
        opacity: 0.3;
    }
    
    /* Streak Info Box */
    .streak-info-box {
        background: var(--warning-soft-bg);
        border: 1px solid rgba(243, 156, 18, 0.3);
        border-radius: 12px;
        padding: 15px 20px;
        margin-bottom: 25px;
        display: flex;
        align-items: center;
        gap: 15px;
    }
    
    .streak-info-box i {
        font-size: 1.5rem;
        color: var(--warning-color);
    }
    
    .streak-info-box p {
        margin: 0;
        font-size: 0.9rem;
        color: var(--text-color);
        opacity: 0.8;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
        .bonus-main-card {
            padding: 30px 20px;
        }
        
        .bonus-amount-display {
            font-size: 2.5rem;
        }
        
        .countdown-timer {
            flex-wrap: wrap;
        }
        
        .countdown-item {
            min-width: 70px;
            padding: 12px 15px;
        }
        
        .countdown-value {
            font-size: 1.5rem;
        }
        
        .streak-days {
            flex-wrap: wrap;
        }
        
        .streak-day {
            flex: 0 0 calc(25% - 10px);
            min-width: 70px;
        }
        
        .history-table {
            font-size: 0.85rem;
        }
        
        .history-table th,
        .history-table td {
            padding: 12px 15px;
        }
    }
</style>

<div class="bonus-container">
    <?php if ($message && !$redirectAfterClaim): ?>
        <div class="alert alert-<?php echo $messageType; ?>">
            <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : ($messageType === 'warning' ? 'exclamation-triangle' : 'times-circle'); ?>"></i>
            <?php echo $message; ?>
        </div>
    <?php endif; ?>
    
    <!-- Seri Bilgi Kutusu -->
    <div class="streak-info-box">
        <i class="fas fa-info-circle"></i>
        <p>
            <?php 
            $resetHoursText = $streakResetHours > 24 ? round($streakResetHours / 24) . ' gün' : $streakResetHours . ' saat';
            echo "Her {$claimIntervalHours} saatte bir bonus alabilirsiniz. Seriyi korumak için {$resetHoursText} içinde bonus almalısınız, aksi takdirde seri sıfırlanır.";
            ?>
        </p>
    </div>
    
    <!-- Ana Bonus Kartı -->
    <div class="bonus-main-card">
        <?php if (!$isActive): ?>
            <div class="bonus-inactive-overlay">
                <div class="bonus-inactive-text">
                    <i class="fas fa-lock"></i> <?php echo __('bonus_inactive') ?: 'Günlük bonus sistemi şu anda aktif değil'; ?>
                </div>
            </div>
        <?php endif; ?>
        
        <div class="bonus-icon <?php echo !$canClaim ? 'claimed' : ''; ?>">
            <?php if ($canClaim): ?>
                <i class="fas fa-gift"></i>
            <?php else: ?>
                <i class="fas fa-hourglass-half"></i>
            <?php endif; ?>
        </div>
        
        <h2 class="bonus-title">
            <?php echo $canClaim ? (__('bonus_ready') ?: 'Bonus Hazır!') : (__('come_back_later') ?: 'Daha Sonra Tekrar Gelin!'); ?>
        </h2>
        
        <p class="bonus-subtitle"><?php echo __('daily_bonus_description') ?: 'Her gün giriş yaparak bonus kazanın. Ardışık günlerde bonus miktarı artar!'; ?></p>
        
        <div class="bonus-amount-display">
            <?php 
            // Eğer bonus alınamıyorsa bir sonraki bonusu göster
            if (!$canClaim && $lastBonus) {
                $nextStreak = $lastBonus['streak'] + 1;
                if ($nextStreak > $maxStreakDays) $nextStreak = 1;
                $nextBonusIndex = min($nextStreak - 1, count($bonusAmounts) - 1);
                $nextBonusAmount = $bonusAmounts[$nextBonusIndex];
                echo $siteSettings['currency_symbol'] . number_format($nextBonusAmount, 2);
            } else {
                echo $siteSettings['currency_symbol'] . number_format($currentBonusAmount, 2);
            }
            ?>
        </div>
        
        <div class="bonus-streak-info">
            <i class="fas fa-fire"></i>
            <?php 
            if (!$canClaim && $lastBonus) {
                $nextStreak = $lastBonus['streak'] + 1;
                if ($nextStreak > $maxStreakDays) $nextStreak = 1;
                echo $nextStreak . '. ' . (__('day') ?: 'Gün') . ' ' . (__('bonus') ?: 'Bonus');
            } else {
                echo $currentStreak . '. ' . (__('day') ?: 'Gün') . ' ' . (__('bonus') ?: 'Bonus');
            }
            ?>
        </div>
        
        <?php if ($canClaim && $isActive): ?>
            <form method="POST" style="display: inline;">
                <button type="submit" name="claim_bonus" class="claim-btn">
                    <i class="fas fa-hand-holding-usd"></i> <?php echo __('claim_bonus') ?: 'Bonus Al'; ?>
                </button>
            </form>
        <?php elseif (!$canClaim && $timeRemaining > 0): ?>
            <div class="countdown-container">
                <div class="countdown-label"><?php echo __('bonus_cooldown') ?: 'Sonraki bonus için kalan süre'; ?></div>
                <div class="countdown-timer" id="countdownTimer" data-remaining="<?php echo $timeRemaining; ?>">
                    <div class="countdown-item">
                        <span class="countdown-value" id="hours">00</span>
                        <span class="countdown-unit"><?php echo __('hours') ?: 'Saat'; ?></span>
                    </div>
                    <div class="countdown-item">
                        <span class="countdown-value" id="minutes">00</span>
                        <span class="countdown-unit"><?php echo __('minutes') ?: 'Dakika'; ?></span>
                    </div>
                    <div class="countdown-item">
                        <span class="countdown-value" id="seconds">00</span>
                        <span class="countdown-unit"><?php echo __('seconds') ?: 'Saniye'; ?></span>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Seri İlerlemesi -->
    <div class="streak-progress-card">
        <h3 class="streak-progress-title">
            <i class="fas fa-fire-alt"></i>
            <?php echo __('bonus_streak') ?: 'Bonus Serisi'; ?>
        </h3>
        <div class="streak-days">
            <?php for ($i = 0; $i < $maxStreakDays; $i++): 
                $dayNum = $i + 1;
                $dayAmount = $bonusAmounts[$i] ?? end($bonusAmounts);
                $status = '';
                
                if ($canClaim) {
                    if ($dayNum < $currentStreak) {
                        $status = 'completed';
                    } elseif ($dayNum == $currentStreak) {
                        $status = 'current';
                    } else {
                        $status = 'upcoming';
                    }
                } else {
                    if ($dayNum <= $currentStreak) {
                        $status = 'completed';
                    } else {
                        $status = 'upcoming';
                    }
                }
            ?>
                <div class="streak-day <?php echo $status; ?>">
                    <div class="streak-day-number"><?php echo __('day') ?: 'Gün'; ?> <?php echo $dayNum; ?></div>
                    <div class="streak-day-amount"><?php echo $siteSettings['currency_symbol'] . number_format($dayAmount, 2); ?></div>
                    <div class="streak-day-icon">
                        <?php if ($status === 'completed'): ?>
                            <i class="fas fa-check-circle"></i>
                        <?php elseif ($status === 'current'): ?>
                            <i class="fas fa-star"></i>
                        <?php else: ?>
                            <i class="fas fa-lock"></i>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endfor; ?>
        </div>
    </div>
    
    <!-- İstatistikler -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon purple">
                <i class="fas fa-calendar-check"></i>
            </div>
            <div class="stat-value"><?php echo number_format($stats['total_claims'] ?? 0); ?></div>
            <div class="stat-label"><?php echo __('total_claims') ?: 'Toplam Bonus Alımı'; ?></div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-coins"></i>
            </div>
            <div class="stat-value"><?php echo $siteSettings['currency_symbol'] . number_format($stats['total_earned'] ?? 0, 2); ?></div>
            <div class="stat-label"><?php echo __('total_bonus_earned') ?: 'Toplam Kazanılan Bonus'; ?></div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon orange">
                <i class="fas fa-trophy"></i>
            </div>
            <div class="stat-value"><?php echo number_format($stats['max_streak'] ?? 0); ?> <?php echo __('days') ?: 'Gün'; ?></div>
            <div class="stat-label"><?php echo __('longest_streak') ?: 'En Uzun Seri'; ?></div>
        </div>
    </div>
    
    <!-- Bonus Geçmişi -->
    <div class="history-card">
        <div class="history-header">
            <i class="fas fa-history"></i>
            <?php echo __('bonus_history') ?: 'Bonus Geçmişi'; ?>
        </div>
        
        <?php if (empty($bonusHistory)): ?>
            <div class="empty-history">
                <i class="fas fa-gift"></i>
                <p><?php echo __('no_bonus_history') ?: 'Henüz bonus geçmişiniz bulunmuyor'; ?></p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="history-table">
                    <thead>
                        <tr>
                            <th><?php echo __('date') ?: 'Tarih'; ?></th>
                            <th><?php echo __('bonus_amount') ?: 'Bonus Miktarı'; ?></th>
                            <th><?php echo __('bonus_streak') ?: 'Seri'; ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bonusHistory as $history): ?>
                            <tr>
                                <td>
                                    <?php 
                                    $claimDate = new DateTime($history['claimed_at'], new DateTimeZone('Europe/Istanbul'));
                                    echo $claimDate->format('d.m.Y H:i'); 
                                    ?>
                                </td>
                                <td class="amount-cell">
                                    +<?php echo $siteSettings['currency_symbol'] . number_format($history['amount'], 2); ?>
                                </td>
                                <td>
                                    <span class="streak-badge">
                                        <i class="fas fa-fire"></i>
                                        <?php echo $history['streak']; ?>. <?php echo __('day') ?: 'Gün'; ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
// Geri sayım sayacı
document.addEventListener('DOMContentLoaded', function() {
    var timerEl = document.getElementById('countdownTimer');
    if (!timerEl) return;
    
    var remaining = parseInt(timerEl.dataset.remaining);
    if (remaining <= 0) return;
    
    function updateTimer() {
        if (remaining <= 0) {
            location.reload();
            return;
        }
        
        var hours = Math.floor(remaining / 3600);
        var minutes = Math.floor((remaining % 3600) / 60);
        var seconds = remaining % 60;
        
        document.getElementById('hours').textContent = hours.toString().padStart(2, '0');
        document.getElementById('minutes').textContent = minutes.toString().padStart(2, '0');
        document.getElementById('seconds').textContent = seconds.toString().padStart(2, '0');
        
        remaining--;
    }
    
    updateTimer();
    setInterval(updateTimer, 1000);
});
</script>

<?php require_once __DIR__ . '/footer.php'; ?>