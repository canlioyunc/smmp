<?php
/**
 * Kullanıcı Paneli - Bakiye Yükle (Kredi Paketli + Kupon Kodlu)
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';
require_login('/login.php');
if (!empty($_SESSION['user_id']) && function_exists('moni_user_can') && !moni_user_can($db,(int)$_SESSION['user_id'],'payments.create',true)) { http_response_code(403); exit('Bakiye yükleme yetkiniz yönetici tarafından kapatılmış.'); }
if(function_exists('moni_partial_maintenance_active')&&moni_partial_maintenance_active($db,'payments')){ $pageTitle='Ödeme Bakımı'; require_once 'header.php'; ?>
<div style="max-width:760px;margin:40px auto;padding:28px;border:1px solid var(--border-color);border-radius:20px;background:var(--card-bg-color)"><div style="font-size:2rem;margin-bottom:12px">⚙️</div><h2 style="margin-bottom:8px">Ödeme işlemleri geçici olarak bakımdadır</h2><p style="color:var(--muted-text-color);line-height:1.6"><?=clean(moni_partial_maintenance_message($db,'payments'))?></p><a href="/kullanici/" class="muser-btn" style="display:inline-flex;margin-top:18px">Panele Dön</a></div>
<?php require_once 'footer.php'; exit; }

$success = '';
$error = '';

// POST/Redirect/GET için başarı mesajını session'dan çek
if (!empty($_SESSION['payment_success_message'])) {
    $success = $_SESSION['payment_success_message'];
    unset($_SESSION['payment_success_message']);
}

// Uploads klasörünü oluştur
$uploadDir = __DIR__ . '/../uploads/receipts/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// ==================== KUPON KODU İŞLEMİ ====================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'use_coupon') {
    $couponCode=trim((string)($_POST['coupon_code']??''));$couponError='';$couponSuccess='';$couponAmount=0.0;
    if($couponCode===''){$couponError=__('coupon_empty');}
    else{
        try{
            $db->beginTransaction();
            $stmt=$db->prepare("SELECT * FROM coupons WHERE UPPER(code)=UPPER(?) AND status='active' FOR UPDATE");$stmt->execute([$couponCode]);$coupon=$stmt->fetch(PDO::FETCH_ASSOC);
            if(!$coupon) throw new RuntimeException('INVALID');
            $u=$db->prepare("SELECT balance FROM users WHERE id=? FOR UPDATE");$u->execute([$_SESSION['user_id']]);$oldBalance=$u->fetchColumn();if($oldBalance===false)throw new RuntimeException('USER');
            $now=date('Y-m-d H:i:s');
            if(!empty($coupon['start_date'])&&$coupon['start_date']>$now)throw new RuntimeException('NOT_STARTED');
            if(!empty($coupon['end_date'])&&$coupon['end_date']<$now)throw new RuntimeException('EXPIRED');
            if($coupon['usage_limit']!==null&&(int)$coupon['used_count']>=(int)$coupon['usage_limit'])throw new RuntimeException('TOTAL_LIMIT');
            $us=$db->prepare("SELECT COUNT(*) FROM coupon_usages WHERE coupon_id=? AND user_id=?");$us->execute([$coupon['id'],$_SESSION['user_id']]);$userUse=(int)$us->fetchColumn();
            if($coupon['usage_limit_per_user']!==null&&$userUse>=(int)$coupon['usage_limit_per_user'])throw new RuntimeException('USER_LIMIT');
            if($coupon['min_balance']!==null&&(float)$oldBalance<(float)$coupon['min_balance'])throw new RuntimeException('MIN_BALANCE');
            $couponAmount=(float)$coupon['amount'];
            $upd=$db->prepare("UPDATE coupons SET used_count=used_count+1 WHERE id=? AND (usage_limit IS NULL OR used_count<usage_limit)");$upd->execute([$coupon['id']]);if($upd->rowCount()!==1)throw new RuntimeException('TOTAL_LIMIT');
            $db->prepare("INSERT INTO coupon_usages(coupon_id,user_id,amount,ip_address) VALUES(?,?,?,?)")->execute([$coupon['id'],$_SESSION['user_id'],$couponAmount,moni_client_ip()]);
            $db->prepare("UPDATE users SET balance=balance+? WHERE id=?")->execute([$couponAmount,$_SESSION['user_id']]);
            $newBalance=(float)$oldBalance+$couponAmount;
            $db->prepare("INSERT INTO transactions(user_id,type,amount,balance_after,description,status,created_at) VALUES(?,'coupon',?,?,?,'completed',NOW())")
               ->execute([$_SESSION['user_id'],$couponAmount,$newBalance,'Kupon: '.$coupon['code']]);
            $db->commit();moni_sync_base_wallet($db,(int)$_SESSION['user_id']);$_SESSION['balance']=$newBalance;
            $couponSuccess=sprintf(__('coupon_success'),$siteSettings['currency_symbol'].number_format($couponAmount,2));$_SESSION['payment_success_message']=$couponSuccess;
            if(empty($_SERVER['HTTP_X_REQUESTED_WITH'])||strtolower($_SERVER['HTTP_X_REQUESTED_WITH'])!=='xmlhttprequest'){header('Location: add-funds.php');exit;}
        }catch(Throwable $e){if($db->inTransaction())$db->rollBack();$map=['INVALID'=>'coupon_invalid','NOT_STARTED'=>'coupon_not_active_yet','EXPIRED'=>'coupon_expired','TOTAL_LIMIT'=>'coupon_usage_limit_reached','USER_LIMIT'=>'coupon_user_limit_reached'];
            if(isset($map[$e->getMessage()]))$couponError=__($map[$e->getMessage()]);elseif($e->getMessage()==='MIN_BALANCE')$couponError=sprintf(__('coupon_min_balance_required'),$siteSettings['currency_symbol'].number_format((float)($coupon['min_balance']??0),2));else{$couponError=__('coupon_error');error_log('Coupon: '.$e->getMessage());}}
    }
    if(!empty($_SERVER['HTTP_X_REQUESTED_WITH'])&&strtolower($_SERVER['HTTP_X_REQUESTED_WITH'])==='xmlhttprequest'){header('Content-Type: application/json');echo json_encode($couponError?['success'=>false,'error'=>$couponError]:['success'=>true,'message'=>$couponSuccess,'amount'=>$couponAmount]);exit;}
}

// Aktif ödeme yöntemlerini getir. Child Panel kendi yöntemine sahipse yalnız admin izin verdiğinde onu kullanır.
$paymentMethods = $db->query("SELECT * FROM payment_methods WHERE status = 'active' ORDER BY sort_order ASC")->fetchAll();
$childPanelContext = function_exists('moni_child_panel_context') ? moni_child_panel_context($db) : null;
$childPanelId = (int)($childPanelContext['id'] ?? 0);
$childBankMethod = $childPanelId ? moni_child_panel_payment_config($db,'bank',$childPanelId) : null;
$childIyzicoMethod = $childPanelId ? moni_child_panel_payment_config($db,'iyzico',$childPanelId) : null;

// Aktif banka hesaplarını getir; panel özel havale aktifse global hesapların yerine panel hesapları gösterilir.
$bankAccounts = $childBankMethod ? moni_child_panel_bank_accounts($db,$childPanelId) : $db->query("SELECT * FROM bank_accounts WHERE status = 'active' ORDER BY sort_order ASC")->fetchAll();

// Aktif kredi paketlerini getir
$creditPackages = $db->query("SELECT * FROM credit_packages WHERE is_active = 1 ORDER BY sort_order ASC")->fetchAll();
$paymentReference = !empty($_SESSION['user_id']) && function_exists('moni_payment_reference') ? moni_payment_reference($db,(int)$_SESSION['user_id']) : '';
$depositMinUi=$childBankMethod?(float)$childBankMethod['min_amount']:10.0;
$depositMaxUi=$childBankMethod?(float)$childBankMethod['max_amount']:50000.0;

// Ödeme bildirimi gönder
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_payment'])) {
    $packageId = !empty($_POST['package_id']) ? (int)$_POST['package_id'] : null;
    $amount = floatval($_POST['amount']);
    $creditAmount = $amount; // Paket yoksa yatırılan tutar kadar bakiye; istemciden credit_amount kabul edilmez.
    $feeAmount = 0.0; $payableAmount = $amount;
    $bankAccountId = (int)$_POST['bank_account_id'];
    $senderName = trim($_POST['sender_name']);
    $transferDate = $_POST['transfer_date'];
    $transferTime = $_POST['transfer_time'];
    $note = trim($_POST['note'] ?? '');
    
    // Paket seçildiyse kontrol et
    $selectedPackage = null;
    if ($packageId) {
        $pkgStmt = $db->prepare("SELECT * FROM credit_packages WHERE id = ? AND is_active = 1");
        $pkgStmt->execute([$packageId]);
        $selectedPackage = $pkgStmt->fetch();
        
        if ($selectedPackage) {
            $amount = $selectedPackage['price'];
            $creditAmount = $selectedPackage['credit_amount'];
        } else {
            $error = __('package_not_found');
        }
    }
    
    $bonusBaseAmount = (float)$amount; // Bonus vergi/komisyon dahil brüt ödeme yerine temel satın alma tutarından hesaplanır.

    // Vergi eklentisi açıksa, kullanıcıya yüklenecek kredi değişmeden gerçek ödenecek brüt tutarı hesapla.
    if (!$error) {
        $taxQuote = moni_tax_breakdown($db, (int)$_SESSION['user_id'], (float)$amount);
        $amount = (float)$taxQuote['gross'];
        $feeMethod = !$childBankMethod ? $db->query("SELECT id FROM payment_methods WHERE type='bank' AND status='active' LIMIT 1")->fetch(PDO::FETCH_ASSOC) : false;
        if($feeMethod && function_exists('moni_payment_fee_quote')){ $fq=moni_payment_fee_quote($db,(int)$feeMethod['id'],$amount); $feeAmount=(float)$fq['fee']; $payableAmount=(float)$fq['payable']; $amount=$payableAmount; }
    }

    // Validasyon
    if (!$error) {
        $depositMin=$childBankMethod?(float)$childBankMethod['min_amount']:10.0;$depositMax=$childBankMethod?(float)$childBankMethod['max_amount']:50000.0;
        if ($amount < $depositMin) {
            $error = __('minimum_deposit_amount') . ' ' . $siteSettings['currency_symbol'] . number_format($depositMin,2);
        } elseif ($amount > $depositMax) {
            $error = __('maximum_deposit_amount') . ' ' . $siteSettings['currency_symbol'] . number_format($depositMax,2);
        } elseif (empty($senderName)) {
            $error = __('sender_name_required');
        } elseif (empty($transferDate) || empty($transferTime)) {
            $error = __('transfer_date_time_required');
        } else {
            // Banka hesabı kontrolü
            if($childBankMethod){$bank=$db->prepare("SELECT * FROM child_panel_bank_accounts WHERE id=? AND child_panel_id=? AND is_active=1");$bank->execute([$bankAccountId,$childPanelId]);}
            else{$bank = $db->prepare("SELECT * FROM bank_accounts WHERE id = ? AND status = 'active'");$bank->execute([$bankAccountId]);}
            $bankAccount = $bank->fetch();
            
            if (!$bankAccount) {
                $error = __('invalid_bank_account');
            } else {
                // Dekont yükleme: gerçek MIME kontrolü + sunucu tarafından güvenli uzantı.
                $receiptImage = null;
                if (isset($_FILES['receipt']) && $_FILES['receipt']['error'] !== UPLOAD_ERR_NO_FILE) {
                    $upload = moni_safe_upload($_FILES['receipt'], 'receipts', ['image/jpeg','image/png','image/gif','image/webp','application/pdf'], 10 * 1024 * 1024);
                    if (!$upload['ok']) $error = $upload['error'];
                    else $receiptImage = $upload['path'];
                }

                if (!$error) {
                    $transferDateTime = $transferDate . ' ' . $transferTime . ':00';
                    
                    // Havale/EFT yönteminin ID'sini bul
                    $bankMethod = !$childBankMethod ? $db->query("SELECT id FROM payment_methods WHERE type = 'bank' AND status = 'active' LIMIT 1")->fetch() : false;
                    $paymentMethodId = $bankMethod ? (int)$bankMethod['id'] : null;
                    $paymentBonusAmount = 0.0;
                    if ($paymentMethodId && function_exists('moni_payment_bonus_quote')) {
                        $bq = moni_payment_bonus_quote($db, $paymentMethodId, (float)$bonusBaseAmount);
                        $paymentBonusAmount = (float)$bq['bonus'];
                        $creditAmount = round((float)$creditAmount + $paymentBonusAmount, 4);
                    }
                    
                    $fraud = moni_payment_fraud_check($db, (int)$_SESSION['user_id'], (float)$amount, 'payment_attempt');
                    if (empty($fraud['allow'])) {
                        $error = __('payment_security_limit') ?: 'Ödeme güvenlik limitine takıldı.';
                    }
                    if (!$error) {
                    $stmt = $db->prepare("
                        INSERT INTO payment_requests (user_id, package_id, payment_method_id, bank_account_id, child_panel_id, child_payment_method_id, child_bank_account_id, amount, fee_amount, bonus_amount, payable_amount, credit_amount, sender_name, transfer_date, receipt_image, note, payment_reference, status) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
                    ");
                    $stmt->execute([
                        $_SESSION['user_id'],
                        $packageId,
                        $paymentMethodId,
                        $childBankMethod ? null : $bankAccountId,
                        $childBankMethod ? $childPanelId : null,
                        $childBankMethod ? (int)$childBankMethod['id'] : null,
                        $childBankMethod ? $bankAccountId : null,
                        $amount,
                        $feeAmount,
                        $paymentBonusAmount,
                        $payableAmount,
                        $creditAmount,
                        $senderName,
                        $transferDateTime,
                        $receiptImage,
                        $note,
                        $paymentReference
                    ]);
                    
                    $paymentRequestId = $db->lastInsertId();
                    if(function_exists('moni_admin_notify')) moni_admin_notify($db,'payment','Yeni bakiye yükleme talebi','#'.(int)$paymentRequestId.' numaralı havale bildirimi inceleme bekliyor.','/admin/payments.php','warning');
                    
                    // Admin e-posta bildirimi
                    $adminEmails = [];
                    try {
                        $adminEmails = $db->query("SELECT email FROM users WHERE role = 'admin' AND status = 'active' AND email IS NOT NULL AND email != ''")->fetchAll(PDO::FETCH_COLUMN);
                    } catch (Exception $e) {
                        $adminEmails = [];
                    }
                    
                    if (!empty($siteSettings['email'])) {
                        $adminEmails[] = $siteSettings['email'];
                    }
                    $adminEmails = array_values(array_unique(array_filter($adminEmails)));
                    
                    if (!empty($adminEmails)) {
                        $userEmail = $currentUser['email'] ?? '';
                        $userName  = $currentUser['username'] ?? ('UID:' . $_SESSION['user_id']);
                        $bankName  = $bankAccount['bank_name'] ?? '';
                        $iban      = $bankAccount['iban'] ?? '';
                        
                        $subject = 'Yeni Havale/EFT Bildirimi';
                        $body  = '<h3>Yeni Havale/EFT Bildirimi</h3>';
                        $body .= '<p><strong>Kullanıcı:</strong> ' . clean($userName) . ' (' . clean($userEmail) . ')</p>';
                        $body .= '<p><strong>Ödeme Tutarı:</strong> ' . $siteSettings['currency_symbol'] . number_format($amount, 2) . '</p>';
                        $body .= '<p><strong>Alınacak Bakiye:</strong> ' . $siteSettings['currency_symbol'] . number_format($creditAmount, 2) . '</p>';
                        if($feeAmount>0)$body .= '<p><strong>İşlem Ücreti:</strong> ' . $siteSettings['currency_symbol'] . number_format($feeAmount, 2) . '</p>';
                        if ($selectedPackage) {
                            $body .= '<p><strong>Seçilen Paket:</strong> ' . clean($selectedPackage['name']) . '</p>';
                        }
                        $body .= '<p><strong>Gönderen İsim:</strong> ' . clean($senderName) . '</p>';
                        $body .= '<p><strong>Tarih/Saat:</strong> ' . clean($transferDateTime) . '</p>';
                        $body .= '<p><strong>Banka:</strong> ' . clean($bankName) . '</p>';
                        $body .= '<p><strong>IBAN:</strong> ' . clean($iban) . '</p>';
                        $body .= '<p><strong>Talep ID:</strong> #' . (int)$paymentRequestId . '</p>';
                        if (!empty($note)) {
                            $body .= '<p><strong>Not:</strong> ' . nl2br(clean($note)) . '</p>';
                        }
                        if ($receiptImage) {
                            $body .= '<p><strong>Dekont:</strong> <a href="' . SITE_URL . '/' . $receiptImage . '" target="_blank">Görüntüle</a></p>';
                        }
                        
                        foreach ($adminEmails as $adminEmail) {
                            sendEmail($adminEmail, $subject, $body);
                        }
                    }
                    
                    $_SESSION['payment_success_message'] = __('payment_notification_received');
                    header('Location: add-funds.php');
                    exit;
                    }
                }
            }
        }
    }
}

// Kullanıcının ödeme geçmişi
$paymentHistory = $db->prepare("
    SELECT pr.*, COALESCE(cba.bank_name,ba.bank_name) bank_name, COALESCE(cpm.name,pm.name) as method_name, cp.name as package_name
    FROM payment_requests pr
    LEFT JOIN bank_accounts ba ON pr.bank_account_id = ba.id
    LEFT JOIN child_panel_bank_accounts cba ON pr.child_bank_account_id=cba.id AND pr.child_panel_id=cba.child_panel_id
    LEFT JOIN child_panel_payment_methods cpm ON pr.child_payment_method_id=cpm.id AND pr.child_panel_id=cpm.child_panel_id
    LEFT JOIN payment_methods pm ON pr.payment_method_id = pm.id
    LEFT JOIN credit_packages cp ON pr.package_id = cp.id
    WHERE pr.user_id = ?
    ORDER BY pr.created_at DESC
    LIMIT 10
");
$paymentHistory->execute([$_SESSION['user_id']]);
$paymentHistory = $paymentHistory->fetchAll();

// İyzico ayarları
$iyzicoMethod = $childIyzicoMethod ?: $db->query("SELECT * FROM payment_methods WHERE type = 'iyzico' AND status = 'active' LIMIT 1")->fetch();
$iyzicoEnabled = $iyzicoMethod ? true : false;

// Havale aktif mi?
$bankMethod = $childBankMethod ?: $db->query("SELECT * FROM payment_methods WHERE type = 'bank' AND status = 'active' LIMIT 1")->fetch();
$bankEnabled = $bankMethod && !empty($bankAccounts);

$pageTitle = __('add_funds');
require_once 'header.php';
?>
<style>
/* Balance Card — theme-safe on every user theme */
.balance-card {
    background: linear-gradient(135deg, var(--panel-hero-start-color), var(--panel-hero-end-color));
    border: 1px solid var(--panel-hero-border-color);
    border-radius: 20px;
    padding: 30px;
    color: var(--panel-hero-text-color);
    margin-bottom: 30px;
    box-shadow: 0 14px 34px var(--shadow-color);
}

.balance-card-inner {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 20px;
}

.balance-info h3 {
    font-size: 0.9rem;
    opacity: 0.8;
    margin-bottom: 8px;
}

.balance-info .amount {
    font-size: 2.5rem;
    font-weight: 700;
}

.balance-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.balance-actions .btn {
    padding: 12px 24px;
    background: color-mix(in srgb, var(--panel-hero-text-color) 12%, transparent);
    border: 1px solid color-mix(in srgb, var(--panel-hero-text-color) 18%, transparent);
    border-radius: 12px;
    color: var(--panel-hero-text-color);
    font-weight: 700;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: background .2s ease, border-color .2s ease, transform .2s ease, box-shadow .2s ease;
    cursor: pointer;
    font-size: 0.9rem;
    opacity: 1;
}

.balance-actions .btn:hover {
    background: color-mix(in srgb, var(--panel-hero-text-color) 19%, transparent);
    border-color: color-mix(in srgb, var(--panel-hero-text-color) 28%, transparent);
    color: var(--panel-hero-text-color);
    transform: translateY(-1px);
}

/* Coupon is an intentional warning/yellow primary action, never a washed-out tint. */
.balance-actions .btn.btn-coupon {
    background: var(--warning-color);
    border-color: var(--warning-color);
    color: var(--on-warning-color);
    box-shadow: 0 8px 20px var(--warning-soft-border);
}

.balance-actions .btn.btn-coupon:hover {
    background: color-mix(in srgb, var(--warning-color) 88%, #000 12%);
    border-color: color-mix(in srgb, var(--warning-color) 88%, #000 12%);
    color: var(--on-warning-color);
    box-shadow: 0 10px 24px var(--warning-soft-border);
}

@supports not (background: color-mix(in srgb, #000 50%, #fff)) {
    .balance-actions .btn {
        background: var(--surface-alt-color);
        border-color: var(--panel-hero-border-color);
        color: var(--panel-hero-text-color);
    }
    .balance-actions .btn.btn-coupon,
    .balance-actions .btn.btn-coupon:hover {
        background: var(--warning-color);
        border-color: var(--warning-color);
        color: var(--on-warning-color);
    }
}

/* Coupon Modal */
.coupon-modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.8);
    z-index: 10000;
    justify-content: center;
    align-items: center;
    padding: 20px;
}

.coupon-modal-overlay.active {
    display: flex;
}

.coupon-modal {
    background: var(--card-bg-color);
    border-radius: 20px;
    width: 100%;
    max-width: 450px;
    overflow: hidden;
    animation: modalSlideIn 0.3s ease;
}

@keyframes modalSlideIn {
    from {
        opacity: 0;
        transform: translateY(-30px) scale(0.95);
    }
    to {
        opacity: 1;
        transform: translateY(0) scale(1);
    }
}

.coupon-modal-header {
    background: linear-gradient(135deg, var(--warning-color), #ff9800);
    padding: 25px;
    text-align: center;
    position: relative;
}

.coupon-modal-header .close-btn {
    position: absolute;
    top: 15px;
    right: 15px;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.2);
    border: none;
    color: #fff;
    font-size: 1.2rem;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background 0.3s ease;
}

.coupon-modal-header .close-btn:hover {
    background: var(--on-accent-alpha-030);
}

.coupon-modal-header .icon {
    width: 70px;
    height: 70px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px;
    font-size: 2rem;
    color: #fff;
}

.coupon-modal-header h3 {
    color: #fff;
    font-size: 1.3rem;
    font-weight: 700;
    margin: 0;
}

.coupon-modal-header p {
    color: rgba(255, 255, 255, 0.85);
    font-size: 0.9rem;
    margin: 8px 0 0;
}

.coupon-modal-body {
    padding: 25px;
}

.coupon-input-group {
    position: relative;
    margin-bottom: 20px;
}

.coupon-input-group input {
    width: 100%;
    padding: 18px 20px;
    border: 2px solid var(--border-color);
    border-radius: 14px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 1.1rem;
    font-weight: 600;
    text-align: center;
    text-transform: uppercase;
    letter-spacing: 2px;
    transition: all 0.3s ease;
}

.coupon-input-group input:focus {
    outline: none;
    border-color: var(--warning-color);
    box-shadow: 0 0 0 4px rgba(255, 193, 7, 0.15);
}

.coupon-input-group input::placeholder {
    text-transform: none;
    letter-spacing: normal;
    font-weight: 400;
    opacity: 0.5;
}

.coupon-submit-btn {
    width: 100%;
    padding: 16px;
    background: linear-gradient(135deg, var(--warning-color), #ff9800);
    border: none;
    border-radius: 12px;
    color: #000;
    font-size: 1rem;
    font-weight: 700;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    transition: all 0.3s ease;
}

.coupon-submit-btn:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(255, 193, 7, 0.4);
}

.coupon-submit-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
}

.coupon-message {
    margin-top: 15px;
    padding: 12px 15px;
    border-radius: 10px;
    font-size: 0.9rem;
    display: none;
    align-items: center;
    gap: 10px;
}

.coupon-message.success {
    display: flex;
    background: var(--success-soft-bg);
    border: 1px solid rgba(40, 167, 69, 0.3);
    color: var(--success-color);
}

.coupon-message.error {
    display: flex;
    background: var(--danger-soft-bg);
    border: 1px solid rgba(220, 53, 69, 0.3);
    color: var(--danger-color);
}

.coupon-modal-footer {
    padding: 0 25px 25px;
    text-align: center;
}

.coupon-modal-footer p {
    font-size: 0.8rem;
    opacity: 0.6;
    margin: 0;
}

/* Credit Packages Section */
.packages-section {
    margin-bottom: 35px;
}

.section-header {
    text-align: center;
    margin-bottom: 30px;
}

.section-header .icon-box {
    width: 70px;
    height: 70px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px;
    font-size: 1.8rem;
    color: var(--on-accent-color);
    box-shadow: 0 10px 30px var(--primary-alpha-03);
}

.section-header h2 {
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 8px;
    color: var(--text-color);
}

.section-header p {
    font-size: 0.95rem;
    opacity: 0.6;
    max-width: 500px;
    margin: 0 auto;
}

/* Packages Grid */
.packages-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
}

@media (max-width: 768px) {
    .packages-grid {
        grid-template-columns: 1fr;
    }
}

/* Package Card */
.package-card {
    background: var(--card-bg-color);
    border: 2px solid var(--border-color);
    border-radius: 20px;
    padding: 25px;
    cursor: pointer;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.package-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: transparent;
    transition: all 0.3s ease;
}

.package-card:hover {
    border-color: var(--accent-text-color);
    transform: translateY(-5px);
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.1);
}

.package-card:hover::before {
    background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
}

.package-card.selected {
    border-color: var(--accent-text-color);
    background: linear-gradient(135deg, var(--primary-alpha-008) 0%, var(--primary-alpha-002) 100%);
}

.package-card.selected::before {
    background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
}

/* Popular Badge */
.package-popular-badge {
    position: absolute;
    top: -1px;
    right: 20px;
    background: linear-gradient(135deg, #fd7e14, #e85d04);
    color: #fff;
    padding: 8px 16px 12px;
    border-radius: 0 0 12px 12px;
    font-size: 0.7rem;
    font-weight: 700;
    text-transform: uppercase;
    display: flex;
    align-items: center;
    gap: 5px;
    box-shadow: 0 4px 15px rgba(253, 126, 20, 0.4);
}

/* Package Header */
.package-header {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 20px;
}

.package-icon {
    width: 55px;
    height: 55px;
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.4rem;
    color: #fff;
    flex-shrink: 0;
}

.package-title h4 {
    font-size: 1.1rem;
    font-weight: 700;
    margin-bottom: 4px;
    color: var(--text-color);
}

.package-title p {
    font-size: 0.8rem;
    opacity: 0.6;
    margin: 0;
}

/* Package Pricing */
.package-pricing {
    background: var(--background-color);
    border-radius: 14px;
    padding: 18px;
    margin-bottom: 18px;
}

.package-price-main {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
    padding-bottom: 15px;
    border-bottom: 1px dashed var(--border-color);
}

.package-price-main .credit-amount {
    text-align: right;
}

.package-price-main .credit-amount .label {
    font-size: 0.75rem;
    opacity: 0.6;
    display: block;
    margin-bottom: 3px;
}

.package-price-main .credit-amount .value {
    font-size: 1.6rem;
    font-weight: 800;
    color: var(--success-color);
}

.package-price-main .pay-amount {
    text-align: left;
}

.package-price-main .pay-amount .label {
    font-size: 0.75rem;
    opacity: 0.6;
    display: block;
    margin-bottom: 3px;
}

.package-price-main .pay-amount .value {
    font-size: 1.3rem;
    font-weight: 700;
    color: var(--accent-text-color);
}

.package-benefits {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.package-benefit {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 0.8rem;
    font-weight: 500;
}

.package-benefit.bonus {
    color: var(--success-color);
}

.package-benefit.discount {
    color: #fd7e14;
}

.package-benefit i {
    font-size: 0.75rem;
}

/* Package Select Button */
.package-select-btn {
    width: 100%;
    padding: 14px;
    background: var(--background-color);
    border: 2px solid var(--border-color);
    border-radius: 12px;
    color: var(--text-color);
    font-weight: 600;
    font-size: 0.9rem;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}

.package-card:hover .package-select-btn {
    border-color: var(--accent-text-color);
    color: var(--accent-text-color);
}

.package-card.selected .package-select-btn {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-color: var(--accent-text-color);
    color: var(--on-accent-color);
}

/* Divider */
.section-divider {
    text-align: center;
    margin: 35px 0;
    position: relative;
}

.section-divider::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 1px;
    background: var(--border-color);
}

.section-divider span {
    background: var(--background-color);
    padding: 0 25px;
    position: relative;
    color: var(--text-color);
    opacity: 0.5;
    font-size: 0.9rem;
    font-weight: 500;
}

/* Main Layout */
.funds-layout {
    display: grid;
    grid-template-columns: 1fr 380px;
    gap: 25px;
}

@media (max-width: 1100px) {
    .funds-layout {
        grid-template-columns: 1fr;
    }
}

/* Selected Package Summary */
.selected-package-summary {
    background: linear-gradient(135deg, var(--success-soft-bg) 0%, rgba(40, 167, 69, 0.02) 100%);
    border: 2px solid rgba(40, 167, 69, 0.3);
    border-radius: 16px;
    padding: 20px;
    margin-bottom: 25px;
    display: none;
}

.selected-package-summary.active {
    display: block;
}

.selected-package-summary h4 {
    font-size: 1rem;
    font-weight: 600;
    color: var(--success-color);
    margin-bottom: 15px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.summary-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
}

@media (max-width: 576px) {
    .summary-grid {
        grid-template-columns: 1fr;
    }
}

.summary-item {
    text-align: center;
    padding: 12px;
    background: rgba(255, 255, 255, 0.5);
    border-radius: 10px;
}

.summary-item .label {
    font-size: 0.75rem;
    opacity: 0.7;
    margin-bottom: 5px;
}

.summary-item .value {
    font-size: 1.1rem;
    font-weight: 700;
}

.summary-item .value.credit {
    color: var(--success-color);
}

.summary-item .value.price {
    color: var(--accent-text-color);
}

.summary-item .value.bonus {
    color: #fd7e14;
}

/* Payment Methods Selection */
.payment-method-section {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    padding: 25px;
    margin-bottom: 25px;
}

.payment-method-section h3 {
    font-size: 1rem;
    font-weight: 600;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.payment-method-section h3 i {
    color: var(--accent-text-color);
}

.payment-methods-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 15px;
}

.payment-method-card {
    background: var(--background-color);
    border: 2px solid var(--border-color);
    border-radius: 14px;
    padding: 20px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
}

.payment-method-card:hover {
    border-color: var(--accent-text-color);
    transform: translateY(-3px);
}

.payment-method-card.active {
    border-color: var(--accent-text-color);
    background: var(--primary-alpha-01);
}

.payment-method-card .icon {
    width: 50px;
    height: 50px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 12px;
    font-size: 1.3rem;
}

.payment-method-card .icon.bank {
    background: var(--success-soft-bg);
    color: var(--success-color);
}

.payment-method-card .icon.iyzico {
    background: var(--info-soft-bg);
    color: var(--info-color);
}

.payment-method-card h4 {
    font-size: 0.95rem;
    font-weight: 600;
    margin-bottom: 4px;
}

.payment-method-card p {
    font-size: 0.75rem;
    opacity: 0.6;
    margin: 0;
}

/* Custom Amount Section */
.custom-amount-section {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    padding: 25px;
    margin-bottom: 25px;
}

.custom-amount-section h3 {
    font-size: 1rem;
    font-weight: 600;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.custom-amount-section h3 i {
    color: var(--accent-text-color);
}

.amount-input-group {
    position: relative;
    margin-bottom: 20px;
}

.amount-input-group .currency {
    position: absolute;
    left: 20px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--accent-text-color);
}

.amount-input-group input {
    width: 100%;
    padding: 20px 20px 20px 60px;
    border: 2px solid var(--border-color);
    border-radius: 14px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 1.8rem;
    font-weight: 700;
    transition: all 0.3s ease;
}

.amount-input-group input:focus {
    outline: none;
    border-color: var(--accent-text-color);
}

.quick-amounts {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.quick-amount-btn {
    padding: 12px 20px;
    background: var(--background-color);
    border: 2px solid var(--border-color);
    border-radius: 10px;
    color: var(--text-color);
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
}

.quick-amount-btn:hover {
    border-color: var(--accent-text-color);
    color: var(--accent-text-color);
}

.quick-amount-btn.active {
    background: var(--primary-color);
    border-color: var(--accent-text-color);
    color: var(--on-primary-color);
}

/* Bank Section */
.bank-section {
    display: none;
}

.bank-section.active {
    display: block;
}

.bank-accounts-list {
    display: flex;
    flex-direction: column;
    gap: 15px;
    margin-bottom: 25px;
}

.bank-account-card {
    background: var(--card-bg-color);
    border: 2px solid var(--border-color);
    border-radius: 16px;
    padding: 20px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.bank-account-card:hover {
    border-color: var(--accent-text-color);
}

.bank-account-card.selected {
    border-color: var(--accent-text-color);
    background: var(--primary-alpha-008);
}

.bank-account-header {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 15px;
}

.bank-logo {
    width: 50px;
    height: 50px;
    background: var(--background-color);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.2rem;
    color: var(--accent-text-color);
}

.bank-account-header h4 {
    flex: 1;
    font-size: 1rem;
    font-weight: 600;
}

.bank-account-header .radio {
    width: 24px;
    height: 24px;
    border: 2px solid var(--border-color);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
}

.bank-account-card.selected .radio {
    border-color: var(--accent-text-color);
    background: var(--primary-color);
}

.bank-account-card.selected .radio::after {
    content: '';
    width: 10px;
    height: 10px;
    background: #fff;
    border-radius: 50%;
}

.bank-account-details {
    display: grid;
    gap: 12px;
}

.bank-detail-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 15px;
    background: var(--background-color);
    border-radius: 10px;
}

.bank-detail-row .label {
    font-size: 0.8rem;
    opacity: 0.6;
}

.bank-detail-row .value {
    font-weight: 600;
    font-size: 0.9rem;
    display: flex;
    align-items: center;
    gap: 10px;
}

.copy-btn {
    padding: 6px 12px;
    background: var(--primary-color);
    border: none;
    border-radius: 6px;
    color: var(--on-primary-color);
    font-size: 0.75rem;
    cursor: pointer;
    transition: all 0.2s ease;
}

.copy-btn:hover {
    background: var(--secondary-color);
}

.copy-btn.copied {
    background: var(--success-color);
}

/* Payment Form */
.payment-form {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    padding: 25px;
}

.payment-form h3 {
    font-size: 1rem;
    font-weight: 600;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.payment-form h3 i {
    color: var(--accent-text-color);
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}

@media (max-width: 576px) {
    .form-row {
        grid-template-columns: 1fr;
    }
}

.form-group {
    margin-bottom: 20px;
}

.form-label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    font-size: 0.9rem;
}

.form-label .required {
    color: var(--danger-color);
}

.form-control {
    width: 100%;
    padding: 14px 18px;
    border: 2px solid var(--border-color);
    border-radius: 12px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 0.95rem;
    transition: all 0.3s ease;
    font-family: inherit;
}

.form-control:focus {
    outline: none;
    border-color: var(--accent-text-color);
}

.form-control:disabled {
    opacity: 0.7;
    cursor: not-allowed;
}

/* File Upload */
.file-upload {
    border: 2px dashed var(--border-color);
    border-radius: 12px;
    padding: 30px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
}

.file-upload:hover {
    border-color: var(--accent-text-color);
    background: var(--primary-alpha-005);
}

.file-upload.has-file {
    border-color: var(--success-color);
    background: rgba(40, 167, 69, 0.05);
}

.file-upload i {
    font-size: 2.5rem;
    color: var(--accent-text-color);
    margin-bottom: 15px;
    display: block;
}

.file-upload p {
    font-size: 0.9rem;
    margin-bottom: 5px;
}

.file-upload span {
    font-size: 0.8rem;
    opacity: 0.5;
}

.file-upload input {
    display: none;
}

.file-preview {
    display: none;
    margin-top: 15px;
    padding: 12px 15px;
    background: var(--background-color);
    border-radius: 10px;
    align-items: center;
    gap: 15px;
}

.file-preview.active {
    display: flex;
}

.file-preview .icon {
    width: 45px;
    height: 45px;
    background: var(--primary-color);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--on-primary-color);
}

.file-preview .info {
    flex: 1;
}

.file-preview .info p {
    font-size: 0.85rem;
    font-weight: 500;
    margin: 0;
}

.file-preview .info span {
    font-size: 0.75rem;
    opacity: 0.6;
}

.file-preview .remove {
    background: var(--danger-color);
    color: var(--on-danger-color);
    border: none;
    width: 32px;
    height: 32px;
    border-radius: 8px;
    cursor: pointer;
}

.submit-btn {
    width: 100%;
    padding: 18px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border: none;
    border-radius: 14px;
    color: var(--on-accent-color);
    font-size: 1.1rem;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    transition: all 0.3s ease;
}

.submit-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px var(--primary-alpha-04);
}

.submit-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
}

/* İyzico Section */
.iyzico-section {
    display: none;
}

.iyzico-section.active {
    display: block;
}

.iyzico-info {
    background: var(--info-soft-bg);
    border: 1px solid rgba(23, 162, 184, 0.3);
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 20px;
}

.iyzico-info h4 {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 1rem;
    color: var(--info-color);
    margin-bottom: 10px;
}

.iyzico-info p {
    font-size: 0.9rem;
    opacity: 0.8;
    margin: 0;
}

.iyzico-form {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    padding: 25px;
}

.iyzico-form h3 {
    font-size: 1rem;
    font-weight: 600;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.iyzico-form h3 i {
    color: var(--info-color);
}

.iyzico-btn {
    width: 100%;
    padding: 18px;
    background: linear-gradient(135deg, var(--info-color), #20c997);
    border: none;
    border-radius: 14px;
    color: #fff;
    font-size: 1.1rem;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    transition: all 0.3s ease;
}

.iyzico-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(23, 162, 184, 0.4);
}

/* Payment History Sidebar */
.history-sidebar {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    overflow: hidden;
    height: fit-content;
}

.history-header {
    padding: 20px;
    border-bottom: 1px solid var(--border-color);
}

.history-header h3 {
    font-size: 1rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 0;
}

.history-header h3 i {
    color: var(--accent-text-color);
}

.history-list {
    padding: 15px;
    max-height: 500px;
    overflow-y: auto;
}

.history-item {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 15px;
    background: var(--background-color);
    border-radius: 12px;
    margin-bottom: 10px;
}

.history-item:last-child {
    margin-bottom: 0;
}

.history-item .icon {
    width: 45px;
    height: 45px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
    flex-shrink: 0;
}

.history-item .icon.pending {
    background: var(--warning-soft-bg);
    color: var(--warning-color);
}

.history-item .icon.approved {
    background: var(--success-soft-bg);
    color: var(--success-color);
}

.history-item .icon.rejected {
    background: var(--danger-soft-bg);
    color: var(--danger-color);
}

.history-item .info {
    flex: 1;
    min-width: 0;
}

.history-item .info h5 {
    font-size: 0.9rem;
    font-weight: 600;
    margin-bottom: 3px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.history-item .info p {
    font-size: 0.75rem;
    opacity: 0.6;
    margin: 0;
}

.history-item .amount {
    font-weight: 700;
    font-size: 0.95rem;
    text-align: right;
    flex-shrink: 0;
}

.history-item .amount.pending { color: var(--warning-color); }
.history-item .amount.approved { color: var(--success-color); }
.history-item .amount.rejected { color: var(--danger-color); }

.history-item .amount small {
    display: block;
    font-size: 0.7rem;
    font-weight: 500;
    opacity: 0.7;
}

.empty-history {
    text-align: center;
    padding: 40px 20px;
    opacity: 0.6;
}

.empty-history i {
    font-size: 2.5rem;
    margin-bottom: 15px;
    opacity: 0.3;
    display: block;
}

/* Alert */
.alert {
    padding: 16px 20px;
    border-radius: 12px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 0.9rem;
}

.alert-success {
    background: rgba(40, 167, 69, 0.12);
    border: 1px solid rgba(40, 167, 69, 0.3);
    color: var(--success-color);
}

.alert-danger {
    background: rgba(220, 53, 69, 0.12);
    border: 1px solid rgba(220, 53, 69, 0.3);
    color: var(--danger-color);
}

.alert-info {
    background: rgba(23, 162, 184, 0.12);
    border: 1px solid rgba(23, 162, 184, 0.3);
    color: var(--info-color);
}

@media (max-width: 576px) {
    .balance-actions {
        width: 100%;
    }
    .balance-actions .btn {
        flex: 1;
        justify-content: center;
        padding: 10px 15px;
        font-size: 0.8rem;
    }
}
</style>
<?php if ($success): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?php echo clean($success); ?>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?php echo clean($error); ?>
    </div>
<?php endif; ?>

<!-- Balance Card -->
<div class="balance-card">
    <div class="balance-card-inner">
        <div class="balance-info">
            <h3><?php echo __('your_current_balance'); ?></h3>
            <div class="amount"><?php echo $siteSettings['currency_symbol'] . number_format($currentUser['balance'], 2); ?></div>
        </div>
        <div class="balance-actions">
            <a href="/kullanici/transactions.php" class="btn">
                <i class="fas fa-history"></i> <?php echo __('transaction_history'); ?>
            </a>
            <button type="button" class="btn btn-coupon" onclick="openCouponModal()">
                <i class="fas fa-ticket-alt"></i> <?php echo __('use_coupon'); ?>
            </button>
        </div>
    </div>
</div>

<!-- Coupon Modal -->
<div class="coupon-modal-overlay" id="couponModal">
    <div class="coupon-modal">
        <div class="coupon-modal-header">
            <button type="button" class="close-btn" onclick="closeCouponModal()">
                <i class="fas fa-times"></i>
            </button>
            <div class="icon">
                <i class="fas fa-ticket-alt"></i>
            </div>
            <h3><?php echo __('use_coupon'); ?></h3>
            <p><?php echo __('enter_coupon_code'); ?></p>
        </div>
        <div class="coupon-modal-body">
            <form id="couponForm" onsubmit="submitCoupon(event)">
                <div class="coupon-input-group">
                    <input type="text" id="couponCodeInput" name="coupon_code" placeholder="<?php echo __('enter_coupon_placeholder'); ?>" autocomplete="off" required>
                </div>
                <button type="submit" class="coupon-submit-btn" id="couponSubmitBtn">
                    <i class="fas fa-check-circle"></i>
                    <?php echo __('use_coupon_btn'); ?>
                </button>
            </form>
            <div class="coupon-message" id="couponMessage">
                <i class="fas fa-info-circle"></i>
                <span id="couponMessageText"></span>
            </div>
        </div>
        <div class="coupon-modal-footer">
            <p><?php echo __('coupon_case_insensitive'); ?></p>
        </div>
    </div>
</div>

<!-- Credit Packages -->
<?php if (!empty($creditPackages)): ?>
<div class="packages-section">
    <div class="section-header">
        <div class="icon-box">
            <i class="fas fa-gift"></i>
        </div>
        <h2><?php echo __('credit_packages'); ?></h2>
        <p><?php echo __('select_package_and_save'); ?></p>
    </div>
    
    <div class="packages-grid">
        <?php foreach ($creditPackages as $package): 
            $bonusAmount = $package['credit_amount'] - $package['price'];
        ?>
            <div class="package-card" 
                 data-package-id="<?php echo $package['id']; ?>"
                 data-price="<?php echo $package['price']; ?>"
                 data-credit="<?php echo $package['credit_amount']; ?>"
                 data-name="<?php echo clean($package['name']); ?>"
                 onclick="selectPackage(this)">
                
                <?php if ($package['is_popular']): ?>
                    <div class="package-popular-badge">
                        <i class="fas fa-fire"></i> <?php echo __('popular'); ?>
                    </div>
                <?php endif; ?>
                
                <div class="package-header">
                    <div class="package-icon" style="background: <?php echo $package['icon_color'] ?: 'linear-gradient(135deg, #667eea, #764ba2)'; ?>">
                        <i class="fas <?php echo $package['icon'] ?: 'fa-coins'; ?>"></i>
                    </div>
                    <div class="package-title">
                        <h4><?php echo clean($package['name']); ?></h4>
                        <p><?php echo clean($package['description']); ?></p>
                    </div>
                </div>
                
                <div class="package-pricing">
                    <div class="package-price-main">
                        <div class="pay-amount">
                            <span class="label"><?php echo __('you_pay'); ?></span>
                            <span class="value"><?php echo $siteSettings['currency_symbol'] . number_format($package['price'], 2); ?></span>
                        </div>
                        <div class="credit-amount">
                            <span class="label"><?php echo __('you_get'); ?></span>
                            <span class="value"><?php echo $siteSettings['currency_symbol'] . number_format($package['credit_amount'], 2); ?></span>
                        </div>
                    </div>
                    
                    <div class="package-benefits">
                        <?php if ($bonusAmount > 0): ?>
                            <div class="package-benefit bonus">
                                <i class="fas fa-plus-circle"></i>
                                +<?php echo $siteSettings['currency_symbol'] . number_format($bonusAmount, 2); ?> <?php echo __('bonus'); ?>
                            </div>
                        <?php endif; ?>
                        <?php if ($package['discount_percent'] > 0): ?>
                            <div class="package-benefit discount">
                                <i class="fas fa-percent"></i>
                                %<?php echo number_format($package['discount_percent'], 0); ?> <?php echo __('save'); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <button type="button" class="package-select-btn">
                    <i class="fas fa-check-circle"></i>
                    <span><?php echo __('select_this_package'); ?></span>
                </button>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="section-divider">
    <span><?php echo __('or_enter_custom_amount'); ?></span>
</div>
<?php endif; ?>

<div class="funds-layout">
    <div class="funds-main">
        <!-- Selected Package Summary -->
        <div class="selected-package-summary" id="packageSummary">
            <h4><i class="fas fa-check-circle"></i> <?php echo __('selected_package'); ?></h4>
            <div class="summary-grid">
                <div class="summary-item">
                    <div class="label"><?php echo __('package'); ?></div>
                    <div class="value" id="summaryPackageName">-</div>
                </div>
                <div class="summary-item">
                    <div class="label"><?php echo __('you_pay'); ?></div>
                    <div class="value price" id="summaryPrice">-</div>
                </div>
                <div class="summary-item">
                    <div class="label"><?php echo __('you_get'); ?></div>
                    <div class="value credit" id="summaryCredit">-</div>
                </div>
            </div>
        </div>
        
        <!-- Payment Method Selection -->
        <div class="payment-method-section">
            <h3><i class="fas fa-wallet"></i> <?php echo __('payment_method'); ?></h3>
            <div class="payment-methods-grid">
                <?php if ($bankEnabled): ?>
                    <div class="payment-method-card active" data-method="bank" onclick="selectPaymentMethod('bank')">
                        <div class="icon bank">
                            <i class="fas fa-university"></i>
                        </div>
                        <h4><?php echo __('bank_transfer'); ?></h4>
                        <p><?php echo __('bank_transfer_desc'); ?></p>
                    </div>
                <?php endif; ?>
                
                <?php if ($iyzicoEnabled): ?>
                    <div class="payment-method-card <?php echo !$bankEnabled ? 'active' : ''; ?>" data-method="iyzico" onclick="selectPaymentMethod('iyzico')">
                        <div class="icon iyzico">
                            <i class="fas fa-credit-card"></i>
                        </div>
                        <h4><?php echo __('credit_card'); ?></h4>
                        <p><?php echo __('credit_card_desc'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Custom Amount Section -->
        <div class="custom-amount-section" id="customAmountSection">
            <h3><i class="fas fa-coins"></i> <?php echo __('custom_amount'); ?></h3>
            <div class="amount-input-group">
                <span class="currency"><?php echo $siteSettings['currency_symbol']; ?></span>
                <input type="number" id="amountInput" min="<?php echo clean((string)$depositMinUi); ?>" max="<?php echo clean((string)$depositMaxUi); ?>" step="0.01" value="<?php echo clean((string)max($depositMinUi,100)); ?>" placeholder="0.00">
            </div>
            <div class="quick-amounts">
                <button type="button" class="quick-amount-btn" onclick="setAmount(50)">50<?php echo $siteSettings['currency_symbol']; ?></button>
                <button type="button" class="quick-amount-btn active" onclick="setAmount(100)">100<?php echo $siteSettings['currency_symbol']; ?></button>
                <button type="button" class="quick-amount-btn" onclick="setAmount(250)">250<?php echo $siteSettings['currency_symbol']; ?></button>
                <button type="button" class="quick-amount-btn" onclick="setAmount(500)">500<?php echo $siteSettings['currency_symbol']; ?></button>
                <button type="button" class="quick-amount-btn" onclick="setAmount(1000)">1000<?php echo $siteSettings['currency_symbol']; ?></button>
            </div>
        </div>
        
        <!-- Bank Transfer Section -->
        <div class="bank-section <?php echo $bankEnabled ? 'active' : ''; ?>" id="bankSection">
            <?php if (empty($bankAccounts)): ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    <?php echo __('no_active_bank_accounts'); ?>
                </div>
            <?php else: ?>
                <h3 style="font-size: 1rem; font-weight: 600; margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-university" style="color: var(--accent-text-color);"></i> <?php echo __('select_bank_account'); ?>
                </h3>
                
                <div class="bank-accounts-list">
                    <?php foreach ($bankAccounts as $index => $bank): ?>
                        <div class="bank-account-card <?php echo $index === 0 ? 'selected' : ''; ?>" 
                             data-bank-id="<?php echo $bank['id']; ?>"
                             onclick="selectBank(this, <?php echo $bank['id']; ?>)">
                            <div class="bank-account-header">
                                <div class="bank-logo">
                                    <i class="fas fa-university"></i>
                                </div>
                                <h4><?php echo clean($bank['bank_name']); ?></h4>
                                <div class="radio"></div>
                            </div>
                            <div class="bank-account-details">
                                <div class="bank-detail-row">
                                    <span class="label"><?php echo __('account_holder'); ?></span>
                                    <span class="value">
                                        <?php echo clean($bank['account_holder']); ?>
                                        <button type="button" class="copy-btn" onclick="event.stopPropagation(); copyText('<?php echo addslashes($bank['account_holder']); ?>', this)">
                                            <i class="fas fa-copy"></i>
                                        </button>
                                    </span>
                                </div>
                                <div class="bank-detail-row">
                                    <span class="label">IBAN</span>
                                    <span class="value">
                                        <?php echo clean($bank['iban']); ?>
                                        <button type="button" class="copy-btn" onclick="event.stopPropagation(); copyText('<?php echo addslashes(str_replace(' ', '', $bank['iban'])); ?>', this)">
                                            <i class="fas fa-copy"></i>
                                        </button>
                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php if($paymentReference): ?>
                <div class="alert alert-info" style="margin:16px 0">
                    <i class="fas fa-hashtag"></i>
                    <div><strong>Havale açıklama kodunuz: <?=clean($paymentReference)?></strong><br><span>Transfer açıklamasına bu kodu aynen yazın. Ekstre içe aktarıldığında ödeme talebiniz otomatik eşleştirilebilir.</span></div>
                    <button type="button" class="copy-btn" onclick="copyText('<?=addslashes($paymentReference)?>',this)"><i class="fas fa-copy"></i></button>
                </div>
                <?php endif; ?>
                
                <!-- Payment Notification Form -->
                <div class="payment-form">
                    <h3><i class="fas fa-bell"></i> <?php echo __('payment_notification'); ?></h3>
                    
                    <form method="POST" enctype="multipart/form-data" id="bankPaymentForm">
                        <input type="hidden" name="package_id" id="selectedPackageId" value="">
                        <input type="hidden" name="bank_account_id" id="selectedBankId" value="<?php echo $bankAccounts[0]['id'] ?? ''; ?>">
                        <input type="hidden" name="amount" id="formAmount" value="100">
                        <input type="hidden" name="credit_amount" id="formCreditAmount" value="100">
                        
                        <div class="form-group">
                            <label class="form-label"><?php echo __('username'); ?></label>
                            <input type="text" class="form-control" value="<?php echo clean($currentUser['username']); ?>" disabled>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label"><?php echo __('sender_full_name'); ?> <span class="required">*</span></label>
                            <input type="text" name="sender_name" class="form-control" placeholder="<?php echo __('sender_name_placeholder'); ?>" required>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label"><?php echo __('transfer_date'); ?> <span class="required">*</span></label>
                                <input type="date" name="transfer_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label"><?php echo __('transfer_time'); ?> <span class="required">*</span></label>
                                <input type="time" name="transfer_time" class="form-control" value="<?php echo date('H:i'); ?>" required>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label"><?php echo __('receipt_optional'); ?></label>
                            <div class="file-upload" id="receiptUpload" onclick="document.getElementById('receiptInput').click()">
                                <i class="fas fa-cloud-upload-alt"></i>
                                <p><?php echo __('click_to_upload_receipt'); ?></p>
                                <span>JPG, PNG, PDF - <?php echo __('max'); ?> 10MB</span>
                                <input type="file" id="receiptInput" name="receipt" accept="image/*,.pdf" onchange="handleReceiptUpload(this)">
                            </div>
                            <div class="file-preview" id="receiptPreview">
                                <div class="icon"><i class="fas fa-file"></i></div>
                                <div class="info">
                                    <p id="receiptName"></p>
                                    <span id="receiptSize"></span>
                                </div>
                                <button type="button" class="remove" onclick="removeReceipt()">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label"><?php echo __('note_optional'); ?></label>
                            <textarea name="note" class="form-control" rows="3" placeholder="<?php echo __('add_note_placeholder'); ?>"></textarea>
                        </div>
                        
                        <button type="submit" name="submit_payment" class="submit-btn">
                            <i class="fas fa-paper-plane"></i>
                            <?php echo __('send_payment_notification'); ?>
                        </button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- İyzico Section -->
        <div class="iyzico-section <?php echo !$bankEnabled && $iyzicoEnabled ? 'active' : ''; ?>" id="iyzicoSection">
            <div class="iyzico-info">
                <h4><i class="fas fa-shield-alt"></i> <?php echo __('secure_payment'); ?></h4>
                <p><?php echo __('iyzico_security_info'); ?></p>
            </div>
            
            <div class="iyzico-form">
                <h3><i class="fas fa-credit-card"></i> <?php echo __('pay_with_card'); ?></h3>
                
                <?php if ($iyzicoEnabled): ?>
                    <form action="iyzico-payment.php" method="POST" id="iyzicoForm">
                        <input type="hidden" name="package_id" id="iyzicoPackageId" value="">
                        <input type="hidden" name="amount" id="iyzicoAmount" value="100">
                        <input type="hidden" name="credit_amount" id="iyzicoCreditAmount" value="100">
                        <button type="submit" class="iyzico-btn">
                            <i class="fas fa-lock"></i>
                            <?php echo __('continue_to_secure_payment'); ?>
                        </button>
                    </form>
                <?php else: ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i>
                        <?php echo __('credit_card_not_available'); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Payment History Sidebar -->
    <div class="history-sidebar">
        <div class="history-header">
            <h3><i class="fas fa-history"></i> <?php echo __('recent_deposits'); ?></h3>
        </div>
        <div class="history-list">
            <?php if (empty($paymentHistory)): ?>
                <div class="empty-history">
                    <i class="fas fa-wallet"></i>
                    <p><?php echo __('no_payment_history'); ?></p>
                </div>
            <?php else: ?>
                <?php foreach ($paymentHistory as $payment): ?>
                    <div class="history-item">
                        <div class="icon <?php echo $payment['status']; ?>">
                            <i class="fas fa-<?php echo $payment['status'] === 'approved' ? 'check' : ($payment['status'] === 'rejected' ? 'times' : 'clock'); ?>"></i>
                        </div>
                        <div class="info">
                            <h5><?php echo clean($payment['package_name'] ?? $payment['method_name'] ?? __('bank_transfer')); ?></h5>
                            <p><?php echo moni_format_user_time($db,(int)$_SESSION['user_id'],$payment['created_at']); ?></p>
                        </div>
                        <span class="amount <?php echo $payment['status']; ?>">
                            <?php echo $siteSettings['currency_symbol'] . number_format($payment['credit_amount'] ?? $payment['amount'], 2); ?>
                            <?php if ($payment['credit_amount'] && $payment['credit_amount'] != $payment['amount']): ?>
                                <small><?php echo __('paid'); ?>: <?php echo $siteSettings['currency_symbol'] . number_format($payment['amount'], 2); ?></small>
                            <?php endif; ?>
                        </span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
const currencySymbol = '<?php echo $siteSettings['currency_symbol']; ?>';
const depositMin = <?php echo json_encode((float)$depositMinUi); ?>;
const depositMax = <?php echo json_encode((float)$depositMaxUi); ?>;
const bankEnabled = <?php echo $bankEnabled ? 'true' : 'false'; ?>;
const iyzicoEnabled = <?php echo $iyzicoEnabled ? 'true' : 'false'; ?>;

// Çeviri metinleri
const t = {
    min_amount: '<?php echo __('minimum_deposit_amount'); ?>',
    max_amount: '<?php echo __('maximum_deposit_amount'); ?>',
    allowed_files: '<?php echo __('allowed_file_types'); ?>',
    max_file_size: '<?php echo __('max_file_size_10mb'); ?>',
    select_this_package: '<?php echo __('select_this_package'); ?>',
    package_selected: '<?php echo __('package_selected'); ?>',
    // Kupon çevirileri
    coupon_empty: '<?php echo __('coupon_empty'); ?>',
    coupon_checking: '<?php echo __('checking'); ?>...',
    coupon_error: '<?php echo __('coupon_error'); ?>'
};

let selectedMethod = bankEnabled ? 'bank' : 'iyzico';
let selectedBankId = <?php echo $bankAccounts[0]['id'] ?? 0; ?>;
let selectedPackage = null;

// ==================== KUPON MODAL FONKSİYONLARI ====================
function openCouponModal() {
    document.getElementById('couponModal').classList.add('active');
    document.body.style.overflow = 'hidden';
    document.getElementById('couponCodeInput').value = '';
    document.getElementById('couponMessage').className = 'coupon-message';
    document.getElementById('couponSubmitBtn').disabled = false;
    document.getElementById('couponSubmitBtn').innerHTML = '<i class="fas fa-check-circle"></i> <?php echo __('use_coupon_btn'); ?>';
    setTimeout(() => {
        document.getElementById('couponCodeInput').focus();
    }, 100);
}

function closeCouponModal() {
    document.getElementById('couponModal').classList.remove('active');
    document.body.style.overflow = '';
}

function submitCoupon(e) {
    e.preventDefault();
    
    const couponCode = document.getElementById('couponCodeInput').value.trim();
    const submitBtn = document.getElementById('couponSubmitBtn');
    const messageDiv = document.getElementById('couponMessage');
    const messageText = document.getElementById('couponMessageText');
    
    if (!couponCode) {
        messageDiv.className = 'coupon-message error';
        messageText.textContent = t.coupon_empty;
        return;
    }
    
    // Butonu devre dışı bırak
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ' + t.coupon_checking;
    messageDiv.className = 'coupon-message';
    
    // AJAX isteği
    const formData = new FormData();
    formData.append('action', 'use_coupon');
    formData.append('coupon_code', couponCode);
    
    fetch('/kullanici/add-funds.php', {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            messageDiv.className = 'coupon-message success';
            messageText.textContent = data.message;
            
            // 1.5 saniye sonra sayfayı yenile
            setTimeout(() => {
                window.location.reload();
            }, 1500);
        } else {
            messageDiv.className = 'coupon-message error';
            messageText.textContent = data.error || t.coupon_error;
            
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-check-circle"></i> <?php echo __('use_coupon_btn'); ?>';
        }
    })
    .catch(error => {
        console.error('Kupon hatası:', error);
        messageDiv.className = 'coupon-message error';
        messageText.textContent = t.coupon_error;
        
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fas fa-check-circle"></i> <?php echo __('use_coupon_btn'); ?>';
    });
}

// Modal dışına tıklanınca kapat
document.getElementById('couponModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeCouponModal();
    }
});

// ESC tuşu ile kapat
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && document.getElementById('couponModal').classList.contains('active')) {
        closeCouponModal();
    }
});

// ==================== MEVCUT FONKSİYONLAR ====================

// Paket seç
function selectPackage(element) {
    document.querySelectorAll('.package-card').forEach(card => {
        card.classList.remove('selected');
        const btn = card.querySelector('.package-select-btn span');
        if (btn) btn.textContent = t.select_this_package;
    });
    
    element.classList.add('selected');
    const btnSpan = element.querySelector('.package-select-btn span');
    if (btnSpan) btnSpan.textContent = t.package_selected;
    
    const packageId = element.dataset.packageId;
    const price = parseFloat(element.dataset.price);
    const credit = parseFloat(element.dataset.credit);
    const name = element.dataset.name;
    
    selectedPackage = { id: packageId, price: price, credit: credit, name: name };
    
    document.getElementById('selectedPackageId').value = packageId;
    document.getElementById('formAmount').value = price;
    document.getElementById('formCreditAmount').value = credit;
    
    document.getElementById('iyzicoPackageId').value = packageId;
    document.getElementById('iyzicoAmount').value = price;
    document.getElementById('iyzicoCreditAmount').value = credit;
    
    document.getElementById('summaryPackageName').textContent = name;
    document.getElementById('summaryPrice').textContent = currencySymbol + price.toFixed(2);
    document.getElementById('summaryCredit').textContent = currencySymbol + credit.toFixed(2);
    document.getElementById('packageSummary').classList.add('active');
    
    document.getElementById('customAmountSection').style.display = 'none';
    
    document.querySelector('.payment-method-section').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function clearPackageSelection() {
    document.querySelectorAll('.package-card').forEach(card => {
        card.classList.remove('selected');
        const btn = card.querySelector('.package-select-btn span');
        if (btn) btn.textContent = t.select_this_package;
    });
    
    selectedPackage = null;
    
    document.getElementById('selectedPackageId').value = '';
    document.getElementById('iyzicoPackageId').value = '';
    document.getElementById('packageSummary').classList.remove('active');
    document.getElementById('customAmountSection').style.display = 'block';
}

function selectPaymentMethod(method) {
    selectedMethod = method;
    
    document.querySelectorAll('.payment-method-card').forEach(card => {
        card.classList.toggle('active', card.dataset.method === method);
    });
    
    document.getElementById('bankSection').classList.toggle('active', method === 'bank');
    document.getElementById('iyzicoSection').classList.toggle('active', method === 'iyzico');
}

function setAmount(amount) {
    clearPackageSelection();
    
    document.getElementById('amountInput').value = amount;
    document.getElementById('formAmount').value = amount;
    document.getElementById('formCreditAmount').value = amount;
    document.getElementById('iyzicoAmount').value = amount;
    document.getElementById('iyzicoCreditAmount').value = amount;
    
    document.querySelectorAll('.quick-amount-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
}

document.getElementById('amountInput').addEventListener('input', function() {
    clearPackageSelection();
    
    document.getElementById('formAmount').value = this.value;
    document.getElementById('formCreditAmount').value = this.value;
    document.getElementById('iyzicoAmount').value = this.value;
    document.getElementById('iyzicoCreditAmount').value = this.value;
    
    document.querySelectorAll('.quick-amount-btn').forEach(btn => {
        btn.classList.remove('active');
    });
});

function selectBank(element, bankId) {
    selectedBankId = bankId;
    document.getElementById('selectedBankId').value = bankId;
    
    document.querySelectorAll('.bank-account-card').forEach(card => {
        card.classList.remove('selected');
    });
    element.classList.add('selected');
}

function copyText(text, button) {
    navigator.clipboard.writeText(text).then(() => {
        const originalHtml = button.innerHTML;
        button.innerHTML = '<i class="fas fa-check"></i>';
        button.classList.add('copied');
        
        setTimeout(() => {
            button.innerHTML = originalHtml;
            button.classList.remove('copied');
        }, 2000);
    });
}

function handleReceiptUpload(input) {
    const file = input.files[0];
    if (file) {
        const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf'];
        const maxSize = 10 * 1024 * 1024;
        
        if (!allowedTypes.includes(file.type)) {
            alert(t.allowed_files);
            input.value = '';
            return;
        }
        
        if (file.size > maxSize) {
            alert(t.max_file_size);
            input.value = '';
            return;
        }
        
        document.getElementById('receiptName').textContent = file.name;
        document.getElementById('receiptSize').textContent = formatFileSize(file.size);
        document.getElementById('receiptPreview').classList.add('active');
        document.getElementById('receiptUpload').classList.add('has-file');
    }
}

function removeReceipt() {
    document.getElementById('receiptInput').value = '';
    document.getElementById('receiptPreview').classList.remove('active');
    document.getElementById('receiptUpload').classList.remove('has-file');
}

function formatFileSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

document.getElementById('bankPaymentForm')?.addEventListener('submit', function(e) {
    let amount, creditAmount;
    
    if (selectedPackage) {
        amount = selectedPackage.price;
        creditAmount = selectedPackage.credit;
    } else {
        amount = parseFloat(document.getElementById('amountInput').value);
        creditAmount = amount;
    }
    
    if (amount < depositMin) {
        e.preventDefault();
        alert(t.min_amount + ' ' + depositMin.toLocaleString('tr-TR') + ' ' + currencySymbol);
        return;
    }
    
    if (amount > depositMax) {
        e.preventDefault();
        alert(t.max_amount + ' ' + depositMax.toLocaleString('tr-TR') + ' ' + currencySymbol);
        return;
    }
    
    document.getElementById('formAmount').value = amount;
    document.getElementById('formCreditAmount').value = creditAmount;
});

document.getElementById('iyzicoForm')?.addEventListener('submit', function(e) {
    let amount, creditAmount;
    
    if (selectedPackage) {
        amount = selectedPackage.price;
        creditAmount = selectedPackage.credit;
    } else {
        amount = parseFloat(document.getElementById('amountInput').value);
        creditAmount = amount;
    }
    
    if (amount < depositMin) {
        e.preventDefault();
        alert(t.min_amount + ' ' + depositMin.toLocaleString('tr-TR') + ' ' + currencySymbol);
        return;
    }
    
    if (amount > depositMax) {
        e.preventDefault();
        alert(t.max_amount + ' ' + depositMax.toLocaleString('tr-TR') + ' ' + currencySymbol);
        return;
    }
    
    document.getElementById('iyzicoAmount').value = amount;
    document.getElementById('iyzicoCreditAmount').value = creditAmount;
});
</script>

<?php require_once 'footer.php'; ?>