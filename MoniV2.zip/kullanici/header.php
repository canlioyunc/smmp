<?php
require_once __DIR__ . '/../includes/MoniThemeCompat.php';
require_once __DIR__ . '/../includes/MoniUserHeaderManager.php';
/**
 * Kullanıcı Paneli - Header
 */

if (!isset($db)) {
    require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';
}

// Kullanıcı bilgisi yüklendikten sonra hesap saat dilimi uygulanır.
date_default_timezone_set((string)getSetting('timezone','Europe/Istanbul'));

// Giriş kontrolü
if (!isLoggedIn()) {
    header('Location: /login.php');
    exit;
}

// Kullanıcı bilgilerini al
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$currentUser = $stmt->fetch();

if (!$currentUser || $currentUser['status'] !== 'active') {
    moni_forget_remember_token($db);
    if (!empty($_SESSION['user_id']) && moni_table_ready($db,'user_sessions')) {
        $db->prepare("UPDATE user_sessions SET revoked_at=NOW() WHERE user_id=? AND session_hash=? AND revoked_at IS NULL")
           ->execute([(int)$_SESSION['user_id'],hash('sha256',session_id())]);
    }
    $_SESSION=[];
    session_destroy();
    header('Location: /login.php?error=inactive');
    exit;
}

// Session güncelle
$_SESSION['balance'] = $currentUser['balance'];
if(function_exists('moni_user_timezone')){ $moniUserTz=moni_user_timezone($db,(int)$currentUser['id']); if(moni_valid_timezone($moniUserTz)) date_default_timezone_set($moniUserTz); }
$moniUnreadNotifications=function_exists('moni_user_unread_count')?moni_user_unread_count($db,(int)$currentUser['id']):0;
$moniPremiumBadge=function_exists('moni_premium_badge')?moni_premium_badge($db,(int)$currentUser['id']):null;

// Aktif sayfa
$currentPage = basename($_SERVER['PHP_SELF']);

// Bekleyen sipariş sayısı
$pendingOrders = $db->prepare("SELECT COUNT(*) FROM orders WHERE user_id = ? AND status IN ('pending', 'processing', 'in_progress')");
$pendingOrders->execute([$_SESSION['user_id']]);
$pendingOrderCount = $pendingOrders->fetchColumn();

// Aktif Süreli Sipariş Sayısı (Abonelikler hariç)
$activeScheduledCount = 0;
try {
    $subCountStmt = $db->prepare("SELECT COUNT(*) FROM scheduled_orders WHERE user_id = ? AND status = 'active' AND type = 'scheduled'");
    $subCountStmt->execute([$_SESSION['user_id']]);
    $activeScheduledCount = $subCountStmt->fetchColumn();
} catch (Exception $e) {}

// Referans istatistikleri
$referralStats = [
    'total_referrals' => 0,
    'total_earnings' => 0,
    'pending_earnings' => 0
];

try {
    $refCountStmt = $db->prepare("SELECT COUNT(*) FROM users WHERE referred_by = ?");
    $refCountStmt->execute([$currentUser['id']]);
    $referralStats['total_referrals'] = $refCountStmt->fetchColumn();
    
    $refEarningsStmt = $db->prepare("SELECT COALESCE(SUM(amount), 0) FROM referral_earnings WHERE user_id = ? AND status = 'paid'");
    $refEarningsStmt->execute([$currentUser['id']]);
    $referralStats['total_earnings'] = $refEarningsStmt->fetchColumn();
    
    $refPendingStmt = $db->prepare("SELECT COALESCE(SUM(amount), 0) FROM referral_earnings WHERE user_id = ? AND status = 'pending'");
    $refPendingStmt->execute([$currentUser['id']]);
    $referralStats['pending_earnings'] = $refPendingStmt->fetchColumn();
} catch (Exception $e) {}

// Günlük bonus kontrolü
$canClaimBonus = false;
$bonusSystemActive = false;

try {
    $bonusSettingsStmt = $db->query("SELECT setting_key, setting_value FROM daily_bonus_settings");
    $bonusSettings = [];
    while ($row = $bonusSettingsStmt->fetch()) {
        $bonusSettings[$row['setting_key']] = $row['setting_value'];
    }
    
    $bonusSystemActive = ($bonusSettings['is_active'] ?? '0') === '1';
    $claimIntervalHours = (int)($bonusSettings['claim_interval_hours'] ?? 24);
    
    if ($bonusSystemActive) {
        $lastBonusStmt = $db->prepare("SELECT claimed_at FROM daily_bonus WHERE user_id = ? ORDER BY claimed_at DESC LIMIT 1");
        $lastBonusStmt->execute([$currentUser['id']]);
        $lastBonus = $lastBonusStmt->fetch();
        
        if (!$lastBonus) {
            $canClaimBonus = true;
        } else {
            $now = new DateTime('now', new DateTimeZone('Europe/Istanbul'));
            $lastClaimTime = new DateTime($lastBonus['claimed_at'], new DateTimeZone('Europe/Istanbul'));
            $hoursSinceLastClaim = ($now->getTimestamp() - $lastClaimTime->getTimestamp()) / 3600;
            
            if ($hoursSinceLastClaim >= $claimIntervalHours) {
                $canClaimBonus = true;
            }
        }
    }
} catch (Exception $e) {
    $canClaimBonus = false;
    $bonusSystemActive = false;
}

// Dilleri al
$languages = getLanguages();
$currentLangData = null;
foreach ($languages as $lang) {
    if ($lang['code'] === $currentLang) {
        $currentLangData = $lang;
        break;
    }
}

// Admin panelinden yönetilebilen kullanıcı paneli header / menü yapısı.
$moniUserHeaderConfig = moni_user_header_config($db);
$moniUserHeaderGeneral = $moniUserHeaderConfig['general'];
$moniUserHeaderContext = [
    'user_id' => (int)$currentUser['id'],
    'bonus_active' => $bonusSystemActive,
    'can_claim_bonus' => $canClaimBonus,
    'scheduled_count' => (int)$activeScheduledCount,
    'pending_orders' => (int)$pendingOrderCount,
    'referral_pending' => (float)$referralStats['pending_earnings'],
    'referral_total' => (int)$referralStats['total_referrals'],
    'currency_symbol' => (string)$siteSettings['currency_symbol'],
    'premium_badge' => $moniPremiumBadge,
    'unread_notifications' => (int)$moniUnreadNotifications,
    'language_count' => count($languages),
];

// Sayfa başlığı
$pageTitle = isset($pageTitle) ? $pageTitle . ' - ' . $siteSettings['name'] : $siteSettings['name'];
?>
<!DOCTYPE html>
<html lang="<?php echo $currentLang; ?>" dir="<?php echo function_exists('moni_language_direction') ? moni_language_direction($db, $currentLang) : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title><?php echo clean($pageTitle); ?></title>
    <?php if(function_exists('moni_pwa_head_tags')) echo moni_pwa_head_tags($db); ?>
    
    <?php if (!empty($siteSettings['favicon'])): ?>
        <link rel="icon" type="image/x-icon" href="<?php echo clean($siteSettings['favicon']); ?>">
    <?php endif; ?>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        <?php echo generateCSSVariables($activeTheme); ?>
        <?php echo moni_theme_compat_css($activeTheme); ?>
        <?php if (!empty($siteSettings['child_primary_color'])): ?>
        :root{--primary-color:<?php echo clean($siteSettings['child_primary_color']); ?>;--on-primary-color:<?php echo clean($siteSettings['child_on_primary'] ?? '#fff'); ?>;}
        <?php endif; ?>
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: var(--theme-font-family);
            background: var(--background-color);
            color: var(--text-color);
            min-height: 100vh;
        }

        html[dir="rtl"] .user-sidebar { left:auto; right:0; border-right:0; border-left:1px solid var(--border-color); }
        html[dir="rtl"] .sidebar-logo, html[dir="rtl"] .nav-item { direction:rtl; text-align:right; }
        html[dir="rtl"] .nav-item { flex-direction:row-reverse; }
        html[dir="rtl"] .topbar-left, html[dir="rtl"] .topbar-right { direction:rtl; }
        @media (min-width: 769px) { html[dir="rtl"] .main-content { margin-left:0 !important; margin-right:260px; } html[dir="rtl"] .user-sidebar.collapsed ~ .main-content { margin-right:70px; } }
        
        /* Sidebar */
        .user-sidebar {
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            width: 260px;
            background: var(--sidebar-bg-color);
            border-right: 1px solid var(--border-color);
            z-index: 1000;
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
        }
        
        .user-sidebar.collapsed {
            width: 70px;
        }
        
        /* Sidebar Header - Logo Alanı */
        .sidebar-header {
            padding: 15px;
            border-bottom: 1px solid var(--border-color);
            min-height: 72px;
            display: flex;
            align-items: center;
        }
        
        .sidebar-logo {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            width: 100%;
            overflow: hidden;
        }
        
        /* Logo Container */
        .logo-icon {
            width: 42px;
            height: 42px;
            min-width: 42px;
            flex-shrink: 0;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--on-accent-color);
            font-size: 1.2rem;
        }
        
        .sidebar-logo.has-logo .logo-icon {
            background: transparent;
            width: auto;
            height: 42px;
            max-width: 180px;
            border-radius: 0;
        }
        
        .sidebar-logo.has-logo .logo-icon img {
            height: 100%;
            width: auto;
            max-width: 100%;
            object-fit: contain;
            display: block;
        }
        
        .user-sidebar.collapsed .sidebar-logo.has-logo .logo-icon {
            width: 42px;
            max-width: 42px;
            overflow: hidden;
        }
        
        .user-sidebar.collapsed .sidebar-logo.has-logo .logo-icon img {
            height: 42px;
            width: 42px;
            object-fit: cover;
            object-position: left center;
        }
        
        .logo-text {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--sidebar-text-color);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .user-sidebar.collapsed .logo-text,
        .sidebar-logo.has-logo .logo-text {
            display: none;
        }
        
        /* User Box */
        .user-box {
            padding: 20px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .user-info-card {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .user-avatar {
            width: 45px;
            height: 45px;
            min-width: 45px;
            flex-shrink: 0;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--on-accent-color);
            font-weight: 600;
            font-size: 1.1rem;
        }
        
        .user-details {
            overflow: hidden;
            flex: 1;
        }
        
        .premium-user-badge{display:inline-flex;align-items:center;gap:5px;margin-top:5px;padding:3px 7px;border-radius:999px;color:#fff;font-size:.68rem;font-weight:800;max-width:150px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
        .user-sidebar.collapsed .premium-user-badge{display:none;}

        .user-details h4 {
            font-size: 0.95rem;
            font-weight: 600;
            color: var(--text-color);
            margin-bottom: 2px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .user-details span {
            font-size: 0.8rem;
            color: var(--text-color);
            opacity: 0.6;
            display: block;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .user-sidebar.collapsed .user-details {
            display: none;
        }
        
        /* Balance Box */
        .balance-box {
            margin-top: 15px;
            padding: 15px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 12px;
            color: var(--on-accent-color);
        }
        
        .balance-box small {
            display: block;
            font-size: 0.75rem;
            opacity: 0.85;
            margin-bottom: 4px;
        }
        
        .balance-box h3 {
            font-size: 1.4rem;
            font-weight: 700;
        }
        
        .user-sidebar.collapsed .balance-box {
            padding: 10px;
            text-align: center;
        }
        
        .user-sidebar.collapsed .balance-box small {
            display: none;
        }
        
        .user-sidebar.collapsed .balance-box h3 {
            font-size: 0.9rem;
        }
        
        /* Navigation */
        .sidebar-nav {
            flex: 1;
            padding: 15px 0;
            overflow-y: auto;
        }
        
        .nav-section {
            padding: 10px 20px 5px;
            font-size: 0.7rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--sidebar-text-color);
            opacity: 0.55;
            letter-spacing: 1px;
        }
        
        .user-sidebar.collapsed .nav-section {
            display: none;
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: var(--sidebar-text-color);
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
            opacity: 0.7;
        }
        
        .nav-item:hover {
            background: var(--primary-alpha-01);
            opacity: 1;
        }
        
        .nav-item.active {
            background: var(--primary-alpha-015);
            border-left-color: var(--accent-text-color);
            opacity: 1;
            color: var(--sidebar-accent-color);
        }
        
        .nav-item i {
            width: 22px;
            text-align: center;
            font-size: 1rem;
            flex-shrink: 0;
        }
        
        .nav-item span {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .nav-badge {
            margin-left: auto;
            background: var(--primary-color);
            color: var(--on-primary-color);
            font-size: 0.7rem;
            padding: 2px 8px;
            border-radius: 10px;
            font-weight: 600;
            flex-shrink: 0;
        }
        
        .nav-badge.success {
            background: var(--success-color);
        }
        
        .nav-badge.warning {
            background: var(--warning-color);
        }
        
        .nav-badge.bonus {
            background: linear-gradient(135deg, var(--warning-color), #e67e22);
            animation: pulse-bonus 2s infinite;
        }
        
        @keyframes pulse-bonus {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }
        
        .user-sidebar.collapsed .nav-item {
            justify-content: center;
            padding: 15px;
        }
        
        .user-sidebar.collapsed .nav-item span,
        .user-sidebar.collapsed .nav-badge {
            display: none;
        }
        
        /* Sidebar Footer */
        .sidebar-footer {
            padding: 15px;
            border-top: 1px solid var(--border-color);
        }
        
        .logout-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
            padding: 12px;
            background: rgba(220, 53, 69, 0.1);
            border: none;
            border-radius: 10px;
            color: var(--danger-color);
            font-size: 0.9rem;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .logout-btn:hover {
            background: var(--danger-color);
            color: #fff;
        }
        
        .user-sidebar.collapsed .logout-btn span {
            display: none;
        }
        
        /* Topbar */
        .user-topbar {
            position: fixed;
            top: 0;
            left: 260px;
            right: 0;
            height: 65px;
            background: var(--card-bg-color);
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 25px;
            z-index: 999;
            transition: all 0.3s ease;
        }
        
        .sidebar-collapsed .user-topbar {
            left: 70px;
        }
        
        .topbar-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .toggle-sidebar {
            background: none;
            border: none;
            color: var(--text-color);
            font-size: 1.2rem;
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        
        .toggle-sidebar:hover {
            background: var(--background-color);
        }
        
        .page-title {
            font-size: 1.25rem;
            font-weight: 600;
        }
        
        .topbar-right {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .topbar-btn {
            position: relative;
            width: 42px;
            height: 42px;
            background: var(--background-color);
            border: none;
            border-radius: 10px;
            color: var(--text-color);
            font-size: 1.1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .topbar-btn:hover {
            background: var(--primary-color);
            color: var(--on-primary-color);
        }
        
        .topbar-btn.referral-btn {
            background: linear-gradient(135deg, var(--warning-color), #e67e22);
            color: #fff;
        }
        
        .topbar-btn.referral-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(243, 156, 18, 0.4);
        }
        
        .topbar-btn .badge {
            position: absolute;
            top: -3px;
            right: -3px;
            background: var(--danger-color);
            color: var(--on-danger-color);
            font-size: 0.65rem;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }
        
        .topbar-btn .badge.success {
            background: var(--success-color);
        }
        
        .add-funds-btn {
            padding: 10px 20px;
            background: var(--wallet-button-color);
            border: none;
            border-radius: 10px;
            color: var(--wallet-button-text-color);
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }
        
        .add-funds-btn:hover {
            transform: translateY(-2px);
            background: var(--wallet-button-hover-color);
            box-shadow: 0 5px 20px var(--success-soft-border);
        }
        
        /* Dil Seçici */
        .lang-dropdown {
            position: relative;
        }
        
        .lang-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 14px;
            background: var(--background-color);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            color: var(--text-color);
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .lang-btn:hover {
            border-color: var(--accent-text-color);
        }
        
        .lang-flag {
            font-size: 1.2rem;
            line-height: 1;
        }
        
        .lang-code {
            font-weight: 600;
            font-size: 0.85rem;
        }
        
        .lang-btn .fa-chevron-down {
            font-size: 0.7rem;
            opacity: 0.6;
            transition: transform 0.3s ease;
        }
        
        .lang-dropdown.open .lang-btn .fa-chevron-down {
            transform: rotate(180deg);
        }
        
        .lang-menu {
            position: absolute;
            top: calc(100% + 8px);
            right: 0;
            min-width: 180px;
            background: var(--card-bg-color);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 8px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
            z-index: 1001;
        }
        
        .lang-dropdown.open .lang-menu {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        
        .lang-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 14px;
            color: var(--sidebar-text-color);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.2s ease;
        }
        
        .lang-item:hover {
            background: var(--background-color);
        }
        
        .lang-item.active {
            background: var(--primary-alpha-015);
            color: var(--accent-text-color);
        }
        
        .lang-item .lang-name {
            flex: 1;
            font-size: 0.9rem;
        }
        
        .lang-item .fa-check {
            font-size: 0.8rem;
            color: var(--accent-text-color);
        }
        
        /* Main Content */
        .user-main {
            margin-left: 260px;
            margin-top: 65px;
            padding: 25px;
            min-height: calc(100vh - 65px);
            transition: all 0.3s ease;
        }
        
        .sidebar-collapsed .user-main {
            margin-left: 70px;
        }
        
        /* Card */
        .card {
            background: var(--card-bg-color);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            margin-bottom: 25px;
        }
        
        .card-header {
            padding: 20px 25px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .card-header h2 {
            font-size: 1.1rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .card-header h2 i {
            color: var(--accent-text-color);
        }
        
        .card-body {
            padding: 25px;
        }
        
        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
            text-decoration: none;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: var(--on-accent-color);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px var(--primary-alpha-035);
        }
        
        .btn-secondary {
            background: var(--background-color);
            color: var(--text-color);
            border: 1px solid var(--border-color);
        }
        
        .btn-secondary:hover {
            border-color: var(--accent-text-color);
            color: var(--accent-text-color);
        }
        
        .btn-sm {
            padding: 8px 16px;
            font-size: 0.85rem;
        }
        
        /* Forms */
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            font-size: 0.9rem;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--border-color);
            border-radius: 10px;
            background: var(--background-color);
            color: var(--text-color);
            font-size: 0.95rem;
            transition: all 0.3s ease;
        }
        
        select option {
            background: var(--card-bg-color);
            color: var(--card-text-color);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--accent-text-color);
            box-shadow: 0 0 0 4px var(--primary-alpha-01);
        }
        
        /* Alerts */
        .alert {
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 0.9rem;
        }
        
        .alert-success {
            background: rgba(40, 167, 69, 0.12);
            border: 1px solid rgba(40, 167, 69, 0.3);
            color: var(--success-color);
        }
        
        .alert-danger {
            background: rgba(220, 53, 69, 0.12);
            border: 1px solid rgba(220, 53, 69, 0.3);
            color: var(--danger-color);
        }
        
        .alert-warning {
            background: rgba(255, 193, 7, 0.12);
            border: 1px solid rgba(255, 193, 7, 0.3);
            color: #d39e00;
        }
        
        .alert-info {
            background: rgba(23, 162, 184, 0.12);
            border: 1px solid rgba(23, 162, 184, 0.3);
            color: var(--info-color);
        }
        
        /* Status Badges */
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            white-space: nowrap;
        }
        
        .status-pending { background: var(--warning-soft-bg); color: var(--warning-color); }
        .status-processing { background: var(--info-soft-bg); color: var(--info-color); }
        .status-in_progress { background: rgba(0, 123, 255, 0.15); color: var(--info-color); }
        .status-completed { background: var(--success-soft-bg); color: var(--success-color); }
        .status-partial { background: rgba(253, 126, 20, 0.15); color: #fd7e14; }
        .status-cancelled { background: var(--danger-soft-bg); color: var(--danger-color); }
        .status-refunded { background: rgba(108, 117, 125, 0.15); color: var(--muted-text-color); }
        .status-error { background: var(--danger-soft-bg); color: var(--danger-color); }
        .status-active { background: rgba(46, 204, 113, 0.15); color: var(--success-color); }
        
        /* Table */
        .table-responsive {
            overflow-x: auto;
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .user-sidebar {
                transform: translateX(-100%);
            }
            
            .user-sidebar.mobile-open {
                transform: translateX(0);
            }
            
            .user-topbar {
                left: 0;
            }
            
            .user-main {
                margin-left: 0;
            }
            
            .sidebar-overlay {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.5);
                z-index: 999;
            }
            
            .sidebar-overlay.active {
                display: block;
            }
        }
        
        @media (max-width: 576px) {
            .add-funds-btn span {
                display: none;
            }
            
            .add-funds-btn {
                width: 42px;
                height: 42px;
                padding: 0;
            }
            
            .page-title {
                font-size: 1rem;
            }
            
            .lang-code {
                display: none;
            }
            
            .lang-btn {
                padding: 8px 10px;
            }
        }
    </style>
    <link rel="stylesheet" href="<?php echo rtrim(SITE_URL, '/'); ?>/assets/css/user-modules.css?v=6.2.0">
    <link rel="stylesheet" href="<?php echo rtrim(SITE_URL, '/'); ?>/assets/css/theme-compat.css?v=2">
    <link rel="stylesheet" href="<?php echo rtrim(SITE_URL, '/'); ?>/assets/css/user-theme-universal.css?v=2">
    <link rel="stylesheet" href="<?php echo rtrim(SITE_URL, '/'); ?>/assets/css/user-shell-pro.css?v=6">
</head>
<body class="user-app-shell user-shell-pro">
    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>
    
    <!-- Sidebar -->
    <aside class="user-sidebar" id="userSidebar">
        <div class="sidebar-header">
            <a href="<?php echo clean($moniUserHeaderGeneral['sidebar_logo_link']); ?>" class="sidebar-logo <?php echo !empty($siteSettings['logo']) ? 'has-logo' : ''; ?>">
                <div class="logo-icon">
                    <?php if (!empty($siteSettings['logo'])): ?>
                        <img src="<?php echo clean($siteSettings['logo']); ?>" alt="<?php echo clean($siteSettings['name']); ?>">
                    <?php else: ?>
                        <i class="fas fa-bolt"></i>
                    <?php endif; ?>
                </div>
                <span class="brand-copy"><span class="logo-text"><?php echo clean($siteSettings['name']); ?></span></span>
            </a>
        </div>
        
        <?php if (!empty($moniUserHeaderGeneral['sidebar_search_enabled'])): ?>
        <div class="sidebar-quick-search">
            <i class="fas fa-magnifying-glass"></i>
            <input type="search" id="userMenuSearch" placeholder="Menüde ara…" autocomplete="off" aria-label="Kullanıcı paneli menüsünde ara">
            <button type="button" class="menu-search-clear" id="userMenuSearchClear" aria-label="Aramayı temizle"><i class="fas fa-xmark"></i></button>
        </div>
        <?php endif; ?>
        
        <nav class="sidebar-nav">
            <?php
            $moniItemsBySection = [];
            foreach ($moniUserHeaderConfig['sidebar_items'] as $moniNavItem) {
                if (!moni_user_header_item_visible($moniNavItem, $db, $moniUserHeaderContext)) continue;
                $moniItemsBySection[$moniNavItem['section']][] = $moniNavItem;
            }
            foreach ($moniUserHeaderConfig['sections'] as $moniNavSection):
                if (empty($moniNavSection['enabled'])) continue;
                $moniSectionItems = $moniItemsBySection[$moniNavSection['id']] ?? [];
                if (!$moniSectionItems) continue;
                usort($moniSectionItems, static function($a,$b){ return ($a['order'] <=> $b['order']) ?: strcmp($a['id'],$b['id']); });
            ?>
            <div class="nav-section <?php echo !empty($moniNavSection['static']) ? 'nav-section-static' : ''; ?>" data-section-key="<?php echo clean($moniNavSection['id']); ?>" data-default-open="<?php echo !empty($moniNavSection['default_open']) ? '1' : '0'; ?>"><?php echo clean($moniNavSection['label']); ?></div>
            <?php foreach ($moniSectionItems as $moniNavItem):
                $moniActive = moni_user_header_active($moniNavItem, $currentPage);
                $moniPinned = !empty($moniNavSection['static']);
                $moniTarget = $moniNavItem['target'] === '_blank' ? ' target="_blank" rel="noopener noreferrer"' : '';
            ?>
            <a href="<?php echo clean($moniNavItem['url']); ?>" class="nav-item <?php echo $moniPinned ? 'nav-pinned ' : ''; ?><?php echo $moniActive ? 'active' : ''; ?>"<?php echo $moniTarget; ?>>
                <i class="<?php echo clean($moniNavItem['icon']); ?>"></i>
                <span><?php echo clean($moniNavItem['label']); ?></span>
                <?php echo moni_user_header_badge($moniNavItem, $moniUserHeaderContext); ?>
            </a>
            <?php endforeach; endforeach; ?>
        </nav>
        
        <?php if (!empty($moniUserHeaderGeneral['sidebar_logout_enabled'])): ?>
        <div class="sidebar-footer">
            <a href="/logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i>
                <span><?php echo __('logout'); ?></span>
            </a>
        </div>
        <?php endif; ?>
    </aside>
    
    <!-- Topbar -->
    <header class="user-topbar">
        <div class="topbar-left">
            <?php if (!empty($moniUserHeaderGeneral['topbar_toggle_enabled'])): ?>
            <button type="button" class="toggle-sidebar" onclick="toggleSidebar()" aria-label="Menüyü aç veya kapat">
                <i class="fas fa-bars"></i>
            </button>
            <?php endif; ?>
            <div class="page-title-wrap user-page-heading">
                <?php if (!empty($moniUserHeaderGeneral['page_kicker_enabled']) && $moniUserHeaderGeneral['page_kicker_text'] !== ''): ?>
                <span class="page-kicker page-eyebrow"><?php echo clean($moniUserHeaderGeneral['page_kicker_text']); ?></span>
                <?php endif; ?>
                <h1 class="page-title"><?php echo isset($pageTitle) ? clean(explode(' - ', $pageTitle)[0]) : clean(__('dashboard')); ?></h1>
            </div>
        </div>
        
        <div class="topbar-right">
            <?php foreach ($moniUserHeaderConfig['topbar_items'] as $moniTopItem):
                if (!moni_user_header_item_visible($moniTopItem, $db, $moniUserHeaderContext)) continue;
                $moniTopCore = (string)$moniTopItem['core'];
                $moniTopTarget = $moniTopItem['target'] === '_blank' ? ' target="_blank" rel="noopener noreferrer"' : '';
            ?>
                <?php if ($moniTopCore === 'balance'): ?>
                    <a href="<?php echo clean($moniTopItem['url'] ?: '/kullanici/add-funds.php'); ?>" class="topbar-balance topbar-balance-chip" title="<?php echo clean($moniTopItem['label']); ?>"<?php echo $moniTopTarget; ?>>
                        <span class="topbar-balance-icon"><i class="<?php echo clean($moniTopItem['icon']); ?>"></i></span>
                        <span class="topbar-balance-meta topbar-balance-copy">
                            <small><?php echo clean(__('current_balance')); ?></small>
                            <strong><?php echo clean($siteSettings['currency_symbol'] . number_format((float)$currentUser['balance'], 2)); ?></strong>
                        </span>
                    </a>
                <?php elseif ($moniTopCore === 'language'): ?>
                    <div class="lang-dropdown" id="langDropdown">
                        <button type="button" class="lang-btn" onclick="toggleLangDropdown()" title="<?php echo clean($moniTopItem['label']); ?>">
                            <span class="lang-flag"><?php echo $currentLangData['flag'] ?? '🌐'; ?></span>
                            <span class="lang-code"><?php echo strtoupper($currentLang); ?></span>
                            <i class="fas fa-chevron-down"></i>
                        </button>
                        <div class="lang-menu">
                            <?php foreach ($languages as $lang): ?>
                                <a href="?lang=<?php echo clean($lang['code']); ?>" class="lang-item <?php echo $lang['code'] === $currentLang ? 'active' : ''; ?>">
                                    <span class="lang-flag"><?php echo $lang['flag']; ?></span>
                                    <span class="lang-name"><?php echo clean($lang['native_name']); ?></span>
                                    <?php if ($lang['code'] === $currentLang): ?><i class="fas fa-check"></i><?php endif; ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php elseif ($moniTopCore === 'notifications'): ?>
                    <a href="<?php echo clean($moniTopItem['url'] ?: '/kullanici/notifications.php'); ?>" class="topbar-btn" title="<?php echo clean($moniTopItem['label']); ?>"<?php echo $moniTopTarget; ?>>
                        <i class="<?php echo clean($moniTopItem['icon']); ?>"></i><?php if($moniUnreadNotifications>0):?><span class="badge"><?php echo min(99,$moniUnreadNotifications); ?></span><?php endif;?>
                    </a>
                <?php elseif ($moniTopCore === 'referral'): ?>
                    <a href="<?php echo clean($moniTopItem['url'] ?: '/kullanici/referral.php'); ?>" class="topbar-btn referral-btn" title="<?php echo clean($moniTopItem['label']); ?>"<?php echo $moniTopTarget; ?>>
                        <i class="<?php echo clean($moniTopItem['icon']); ?>"></i>
                        <?php if ($referralStats['total_referrals'] > 0): ?><span class="badge success"><?php echo (int)$referralStats['total_referrals']; ?></span><?php endif; ?>
                    </a>
                <?php elseif ($moniTopCore === 'orders'): ?>
                    <a href="<?php echo clean($moniTopItem['url'] ?: '/kullanici/orders.php'); ?>" class="topbar-btn" title="<?php echo clean($moniTopItem['label']); ?>"<?php echo $moniTopTarget; ?>>
                        <i class="<?php echo clean($moniTopItem['icon']); ?>"></i>
                        <?php if ($pendingOrderCount > 0): ?><span class="badge"><?php echo (int)$pendingOrderCount; ?></span><?php endif; ?>
                    </a>
                <?php elseif ($moniTopCore === 'pwa'): ?>
                    <button type="button" class="topbar-btn moni-pwa-install-btn" data-pwa-install title="<?php echo clean($moniTopItem['label']); ?>" style="display:none"><i class="<?php echo clean($moniTopItem['icon']); ?>"></i></button>
                <?php elseif ($moniTopCore === 'profile'): ?>
                    <div class="topbar-profile user-profile-menu" id="topbarProfile">
                        <button type="button" class="profile-trigger user-profile-trigger" onclick="toggleProfileMenu(event)" aria-expanded="false" aria-controls="profileMenu">
                            <span class="profile-mini-avatar"><?php echo clean(strtoupper(mb_substr($currentUser['username'], 0, 1, 'UTF-8'))); ?></span>
                            <span class="profile-mini-meta profile-trigger-copy"><strong><?php echo clean($currentUser['username']); ?></strong><small><?php echo clean($moniTopItem['label']); ?></small></span>
                            <i class="fas fa-chevron-down profile-trigger-chevron"></i>
                        </button>
                        <div class="profile-menu user-profile-dropdown" id="profileMenu">
                            <div class="profile-menu-head profile-dropdown-head"><strong><?php echo clean($currentUser['username']); ?></strong><span><?php echo clean($currentUser['email']); ?></span></div>
                            <?php foreach ($moniUserHeaderConfig['profile_items'] as $moniProfileItem):
                                if (!moni_user_header_item_visible($moniProfileItem, $db, $moniUserHeaderContext)) continue;
                                $moniProfileTarget = $moniProfileItem['target'] === '_blank' ? ' target="_blank" rel="noopener noreferrer"' : '';
                                $moniProfileClasses = 'profile-dropdown-link' . (!empty($moniProfileItem['danger']) ? ' danger' : '') . (($moniProfileItem['core'] ?? '') === 'add_funds' ? ' profile-dropdown-link-primary' : '');
                            ?>
                            <a class="<?php echo clean($moniProfileClasses); ?>" href="<?php echo clean($moniProfileItem['url']); ?>"<?php echo $moniProfileTarget; ?>><i class="<?php echo clean($moniProfileItem['icon']); ?>"></i><span><?php echo clean($moniProfileItem['label']); ?></span></a>
                            <?php if (!empty($moniProfileItem['separator_after'])): ?><div class="profile-dropdown-separator" aria-hidden="true"></div><?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="<?php echo clean($moniTopItem['url'] ?: '#'); ?>" class="topbar-btn" title="<?php echo clean($moniTopItem['label']); ?>"<?php echo $moniTopTarget; ?>><i class="<?php echo clean($moniTopItem['icon']); ?>"></i></a>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    </header>
    
    <!-- Main Content -->
    <main class="user-main">
        <?php echo showAlert(); ?>
    
    <script>
        // Sidebar Toggle
        function toggleSidebar() {
            var sidebar = document.getElementById('userSidebar');
            var overlay = document.getElementById('sidebarOverlay');
            var isMobile = window.innerWidth <= 992;
            
            if (isMobile) {
                sidebar.classList.toggle('mobile-open');
                overlay.classList.toggle('active');
            } else {
                sidebar.classList.toggle('collapsed');
                document.body.classList.toggle('sidebar-collapsed');
                localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
            }
        }
        
        // Dil dropdown toggle
        function toggleLangDropdown() {
            var dropdown = document.getElementById('langDropdown');
            if (dropdown) dropdown.classList.toggle('open');
        }

        function toggleProfileMenu(event) {
            if (event) event.stopPropagation();
            var profile = document.getElementById('topbarProfile');
            if (!profile) return;
            profile.classList.toggle('open');
            var trigger = profile.querySelector('.profile-trigger');
            if (trigger) trigger.setAttribute('aria-expanded', profile.classList.contains('open') ? 'true' : 'false');
        }

        // Dışarı tıklayınca dropdown kapat
        document.addEventListener('click', function(e) {
            var langDropdown = document.getElementById('langDropdown');
            if (langDropdown && !langDropdown.contains(e.target)) {
                langDropdown.classList.remove('open');
            }
            var profile = document.getElementById('topbarProfile');
            if (profile && !profile.contains(e.target)) {
                profile.classList.remove('open');
                var trigger = profile.querySelector('.profile-trigger');
                if (trigger) trigger.setAttribute('aria-expanded', 'false');
            }
        });
        
        // Sayfa yüklendiğinde sidebar durumunu kontrol et
        document.addEventListener('DOMContentLoaded', function() {
            var sidebar = document.getElementById('userSidebar');
            var isMobile = window.innerWidth <= 992;
            
            if (!isMobile) {
                var isCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
                if (isCollapsed) {
                    sidebar.classList.add('collapsed');
                    document.body.classList.add('sidebar-collapsed');
                }
            }
        });
        
        // Ekran boyutu değiştiğinde
        window.addEventListener('resize', function() {
            var sidebar = document.getElementById('userSidebar');
            var overlay = document.getElementById('sidebarOverlay');
            var isMobile = window.innerWidth <= 992;
            
            if (!isMobile) {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('active');
            }
        });
    </script>
    <script src="<?php echo rtrim(SITE_URL, '/'); ?>/assets/js/user-shell-pro.js?v=4"></script>
