<?php
/** Modüler gateway adaptörü üzerinden güvenli iyzico ödeme başlatma */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';
if(function_exists('moni_partial_maintenance_active')&&moni_partial_maintenance_active($db,'payments'))moni_partial_maintenance_guard($db,'payments',false);
if (!isLoggedIn()) { header('Location: /login.php'); exit; }
if(function_exists('moni_user_can')&&!moni_user_can($db,(int)$_SESSION['user_id'],'payments.create',true)){http_response_code(403);exit('Bakiye yükleme yetkiniz kapalı.');}
$stmt=$db->prepare("SELECT * FROM users WHERE id=? AND status='active'");$stmt->execute([$_SESSION['user_id']]);$currentUser=$stmt->fetch(PDO::FETCH_ASSOC);
if(!$currentUser){header('Location: /login.php');exit;}
$error='';$checkoutFormInitialize=null;$selectedPackage=null;$packageName='Bakiye Yükleme';
$childPanelContext=function_exists('moni_child_panel_context')?moni_child_panel_context($db):null;$childPanelId=(int)($childPanelContext['id']??0);$childIyzico=$childPanelId?moni_child_panel_payment_config($db,'iyzico',$childPanelId):null;
$globalIyzico=$db->query("SELECT * FROM payment_methods WHERE type='iyzico' AND status='active' LIMIT 1")->fetch(PDO::FETCH_ASSOC);
$iyzicoMethod=$childIyzico?:$globalIyzico;if(!$iyzicoMethod){header('Location: /kullanici/add-funds.php?error=iyzico_disabled');exit;}
$packageId=(int)($_POST['package_id']??$_GET['package_id']??0);$amount=(float)($_POST['amount']??0);$creditAmount=$amount;
if($packageId>0){$q=$db->prepare("SELECT * FROM credit_packages WHERE id=? AND is_active=1");$q->execute([$packageId]);$selectedPackage=$q->fetch(PDO::FETCH_ASSOC);if($selectedPackage){$amount=(float)$selectedPackage['price'];$creditAmount=(float)$selectedPackage['credit_amount'];$packageName=$selectedPackage['name'].' - Bakiye Yükleme';}else{$packageId=0;}}
if($packageId===0)$creditAmount=$amount;
$bonusBaseAmount=(float)$amount;
$taxQuote=moni_tax_breakdown($db,(int)$currentUser['id'],$amount);
$amount=(float)$taxQuote['gross'];
$feeQuote=(!$childIyzico&&function_exists('moni_payment_fee_quote'))?moni_payment_fee_quote($db,(int)$iyzicoMethod['id'],$amount):['fee'=>0,'payable'=>$amount];
$feeAmount=(float)$feeQuote['fee'];$amount=(float)$feeQuote['payable'];
$paymentBonus= (!$childIyzico&&function_exists('moni_payment_bonus_quote')) ? moni_payment_bonus_quote($db,(int)$iyzicoMethod['id'],$bonusBaseAmount) : ['bonus'=>0];
$paymentBonusAmount=(float)($paymentBonus['bonus']??0);$creditAmount=round($creditAmount+$paymentBonusAmount,4);
$min=(float)($iyzicoMethod['min_amount']??10);$max=(float)($iyzicoMethod['max_amount']??10000);
if($amount<$min){header('Location: /kullanici/add-funds.php?error=min_amount');exit;}if($amount>$max){header('Location: /kullanici/add-funds.php?error=max_amount');exit;}
$fraud=moni_payment_fraud_check($db,(int)$currentUser['id'],$amount,'payment_attempt');if(empty($fraud['allow'])){header('Location: /kullanici/add-funds.php?error=payment_security_limit');exit;}
$base=rtrim((string)(defined('SITE_URL')?SITE_URL:''),'/');if(!filter_var($base,FILTER_VALIDATE_URL)){$base=rtrim((string)getSetting('site_url',''),'/');}if(!filter_var($base,FILTER_VALIDATE_URL)){header('Location: /kullanici/add-funds.php?error=site_url_missing');exit;}
$gateway=moni_gateway('iyzico',$db);
if(!$gateway){$error='iyzico adaptörü yüklenemedi.';}else{
    $created=$gateway->createPayment($db,(int)$currentUser['id'],$amount,[
        'user'=>$currentUser,'credit_amount'=>$creditAmount,'fee_amount'=>$feeAmount,'payment_bonus_amount'=>$paymentBonusAmount,'package_id'=>$packageId,'package_name'=>$selectedPackage['name']??null,
        'callback_url'=>$base.'/kullanici/iyzico-callback.php','child_panel_id'=>$childIyzico?$childPanelId:0,'child_payment_method_id'=>$childIyzico?(int)$childIyzico['id']:0
    ]);
    if(empty($created['success'])){$error=$created['error']??'Ödeme formu oluşturulamadı.';}else{$checkoutFormInitialize=$created['checkout'];$_SESSION['iyzico_last_token']=$created['token'];}
}

$pageTitle = __('pay_with_card');
require_once 'header.php';
?>

<style>
.payment-container {
    max-width: 800px;
    margin: 0 auto;
}

.payment-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 20px;
    overflow: hidden;
}

.payment-header {
    padding: 30px;
    background: linear-gradient(135deg, #1a8cff, #00d4aa);
    color: #fff;
    text-align: center;
}

.payment-header .icon {
    width: 70px;
    height: 70px;
    background: rgba(255,255,255,0.2);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px;
    font-size: 2rem;
}

.payment-header h2 {
    font-size: 1.5rem;
    margin-bottom: 5px;
}

.payment-header p {
    opacity: 0.9;
    font-size: 0.95rem;
}

.payment-amounts {
    margin-top: 20px;
    display: flex;
    justify-content: center;
    gap: 30px;
    flex-wrap: wrap;
}

.payment-amount-box {
    text-align: center;
}

.payment-amount-box .label {
    font-size: 0.85rem;
    opacity: 0.8;
    margin-bottom: 5px;
}

.payment-amount-box .value {
    font-size: 2rem;
    font-weight: 700;
}

.payment-amount-box .value.credit {
    color: #90EE90;
}

.package-badge {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: rgba(255,255,255,0.2);
    padding: 8px 16px;
    border-radius: 20px;
    margin-top: 15px;
    font-size: 0.9rem;
}

.payment-body {
    padding: 30px;
}

.iyzico-form-container {
    min-height: 500px;
}

#iyzipay-checkout-form {
    width: 100% !important;
}

.payment-info {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 20px;
    background: var(--info-soft-bg);
    border-radius: 12px;
    margin-bottom: 25px;
}

.payment-info i {
    font-size: 1.5rem;
    color: var(--info-color);
}

.payment-info p {
    font-size: 0.9rem;
    opacity: 0.8;
    margin: 0;
}

.bonus-info {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 20px;
    background: var(--success-soft-bg);
    border-radius: 12px;
    margin-bottom: 25px;
    border: 1px solid rgba(40, 167, 69, 0.3);
}

.bonus-info i {
    font-size: 1.5rem;
    color: var(--success-color);
}

.bonus-info p {
    font-size: 0.9rem;
    color: var(--success-color);
    margin: 0;
    font-weight: 500;
}

.error-box {
    text-align: center;
    padding: 50px;
}

.error-box i {
    font-size: 4rem;
    color: var(--danger-color);
    margin-bottom: 20px;
    display: block;
}

.error-box h3 {
    font-size: 1.3rem;
    margin-bottom: 15px;
}

.error-box p {
    opacity: 0.7;
    margin-bottom: 25px;
}

.back-btn {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 14px 28px;
    background: var(--primary-color);
    color: var(--on-primary-color);
    border-radius: 12px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s ease;
}

.back-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px var(--primary-alpha-035);
}

.secure-badges {
    display: flex;
    justify-content: center;
    gap: 20px;
    margin-top: 25px;
    padding-top: 25px;
    border-top: 1px solid var(--border-color);
}

.secure-badge {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.85rem;
    opacity: 0.6;
}

.secure-badge i {
    color: var(--success-color);
}
</style>

<div class="payment-container">
    <div class="payment-card">
        <div class="payment-header">
            <div class="icon"><i class="fas fa-credit-card"></i></div>
            <h2><?php echo __('secure_payment'); ?></h2>
            <p><?php echo __('secure_payment_with_iyzico'); ?></p>
            
            <?php if (!$error): ?>
                <?php if ($selectedPackage): ?>
                    <div class="package-badge">
                        <i class="fas <?php echo $selectedPackage['icon'] ?: 'fa-gift'; ?>"></i>
                        <?php echo clean($selectedPackage['name']); ?>
                    </div>
                <?php endif; ?>
                
                <div class="payment-amounts">
                    <div class="payment-amount-box">
                        <div class="label"><?php echo __('you_pay'); ?></div>
                        <div class="value"><?php echo $siteSettings['currency_symbol'] . number_format($amount, 2); ?></div>
                    </div>
                    <?php if ($creditAmount > $amount): ?>
                        <div class="payment-amount-box">
                            <div class="label"><?php echo __('you_get'); ?></div>
                            <div class="value credit"><?php echo $siteSettings['currency_symbol'] . number_format($creditAmount, 2); ?></div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="payment-body">
            <?php if ($error): ?>
                <div class="error-box">
                    <i class="fas fa-exclamation-triangle"></i>
                    <h3><?php echo __('payment_could_not_start'); ?></h3>
                    <p><?php echo clean($error); ?></p>
                    <a href="/kullanici/add-funds.php" class="back-btn">
                        <i class="fas fa-arrow-left"></i> <?php echo __('go_back'); ?>
                    </a>
                </div>
            <?php else: ?>
                <?php if ($creditAmount > $amount): ?>
                    <div class="bonus-info">
                        <i class="fas fa-gift"></i>
                        <p><?php echo __('bonus'); ?>: +<?php echo $siteSettings['currency_symbol'] . number_format($creditAmount - $amount, 2); ?> <?php echo __('extra_credit'); ?></p>
                    </div>
                <?php endif; ?>
                
                <div class="payment-info">
                    <i class="fas fa-shield-alt"></i>
                    <p><?php echo __('card_info_security_message'); ?></p>
                </div>
                
                <div class="iyzico-form-container">
                    <div id="iyzipay-checkout-form" class="responsive">
                        <?php echo $checkoutFormInitialize->getCheckoutFormContent(); ?>
                    </div>
                </div>
                
                <div class="secure-badges">
                    <div class="secure-badge">
                        <i class="fas fa-lock"></i>
                        <span>256-bit SSL</span>
                    </div>
                    <div class="secure-badge">
                        <i class="fas fa-shield-alt"></i>
                        <span>3D Secure</span>
                    </div>
                    <div class="secure-badge">
                        <i class="fas fa-check-circle"></i>
                        <span>PCI DSS</span>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>