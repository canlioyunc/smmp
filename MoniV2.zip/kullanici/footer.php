<?php
/**
 * Kullanıcı Paneli - Footer
 */
if (!defined('SITE_URL')) { http_response_code(404); exit; }
?>
    <!-- v2: Page-local CSS is declared after header.php on many legacy pages.
         Apply the final theme compatibility layer here so theme variables always win. -->
    <link rel="stylesheet" href="<?php echo rtrim(SITE_URL, '/'); ?>/assets/css/user-theme-final.css?v=3">
    <?php if(function_exists('moni_plugin_enabled') && moni_plugin_enabled('target_preview',$db)): ?><script defer src="<?php echo rtrim(SITE_URL,'/'); ?>/assets/js/target-preview.js?v=5"></script><?php endif; ?>
    </main>
    
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('userSidebar');
            const overlay = document.getElementById('sidebarOverlay');
            
            if (window.innerWidth <= 992) {
                sidebar.classList.toggle('mobile-open');
                overlay.classList.toggle('active');
            } else {
                sidebar.classList.toggle('collapsed');
                document.body.classList.toggle('sidebar-collapsed');
                localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
            }
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            const sidebarCollapsed = localStorage.getItem('sidebarCollapsed');
            if (sidebarCollapsed === 'true' && window.innerWidth > 992) {
                document.getElementById('userSidebar').classList.add('collapsed');
                document.body.classList.add('sidebar-collapsed');
            }
        });
    </script>
</body>
</html>