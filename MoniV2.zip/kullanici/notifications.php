<?php
require_once __DIR__.'/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';
if(!isLoggedIn()){header('Location: /login.php');exit;}
$uid=(int)$_SESSION['user_id'];$ok='';$error='';
$categories=[
 'orders'=>['Siparişler','Sipariş oluşturma, durum ve refill bildirimleri.'],
 'payments'=>['Ödemeler ve Bakiye','Ödeme, iade, kupon ve bakiye bildirimleri.'],
 'support'=>['Destek','Destek talepleri ve yanıt bildirimleri.'],
 'service_alerts'=>['Servis Alarmları','Favori servis fiyat ve durum değişiklikleri.'],
 'marketing'=>['Duyuru ve Kampanyalar','Kampanya, promosyon ve genel duyurular.'],
 'security'=>['Güvenlik','Giriş, parola, 2FA ve cihaz güvenliği. Güvenlik iç bildirimleri kapatılamaz.'],
];
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  if(isset($_POST['save_preferences']) && moni_plugin_enabled('notification_preferences',$db)){
   foreach($categories as $key=>$meta){
    $inApp=$key==='security'?1:(!empty($_POST['pref'][$key]['in_app'])?1:0);
    $email=!empty($_POST['pref'][$key]['email'])?1:0;
    $push=!empty($_POST['pref'][$key]['push'])?1:0;
    $db->prepare("INSERT INTO notification_preferences(user_id,category,in_app_enabled,email_enabled,push_enabled) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE in_app_enabled=VALUES(in_app_enabled),email_enabled=VALUES(email_enabled),push_enabled=VALUES(push_enabled)")->execute([$uid,$key,$inApp,$email,$push]);
   }
   $ok='Bildirim tercihleriniz kaydedildi.';
  }elseif(isset($_POST['read'])){
   $id=(int)$_POST['read'];$s=$db->prepare("UPDATE user_notifications SET read_at=COALESCE(read_at,NOW()) WHERE id=? AND user_id=?");$s->execute([$id,$uid]);
   $q=$db->prepare("SELECT url FROM user_notifications WHERE id=? AND user_id=?");$q->execute([$id,$uid]);$url=(string)$q->fetchColumn();
   if($url!==''&&str_starts_with($url,'/')&&!str_starts_with($url,'//')){header('Location: '.$url);exit;}header('Location: notifications.php');exit;
  }elseif(isset($_POST['read_all'])){$db->prepare("UPDATE user_notifications SET read_at=COALESCE(read_at,NOW()) WHERE user_id=?")->execute([$uid]);header('Location: notifications.php');exit;}
 }catch(Throwable $e){$error='Bildirim ayarları kaydedilemedi.';error_log('Notification center: '.$e->getMessage());}
}
$prefs=[];if(moni_plugin_enabled('notification_preferences',$db)){foreach($categories as $key=>$meta)$prefs[$key]=moni_notification_pref($db,$uid,$key);}
$rows=$db->prepare("SELECT * FROM user_notifications WHERE user_id=? ORDER BY id DESC LIMIT 200");$rows->execute([$uid]);$rows=$rows->fetchAll(PDO::FETCH_ASSOC);$pageTitle='Bildirimler';require_once 'header.php';
?>
<style>
.nt-wrap{max-width:1040px;margin:0 auto}.nt-head{display:flex;justify-content:space-between;align-items:center;gap:15px;margin-bottom:16px;flex-wrap:wrap}.nt-list{display:grid;gap:10px}.nt-form{margin:0}.nt{display:flex;gap:13px;padding:15px;border:1px solid var(--border-color);border-radius:13px;background:var(--card-bg-color);color:var(--text-color);width:100%;text-align:left;cursor:pointer}.nt.unread{border-color:color-mix(in srgb,var(--primary-color) 40%,var(--border-color));background:color-mix(in srgb,var(--card-bg-color) 95%,var(--primary-color))}.nt>i{width:36px;height:36px;border-radius:10px;display:grid;place-items:center;background:var(--primary-alpha-01);color:var(--accent-text-color);flex:0 0 auto}.nt h4{font-size:.9rem;margin:0 0 4px}.nt p{font-size:.8rem;color:var(--muted-text-color);margin:0 0 5px;line-height:1.45}.nt small{font-size:.72rem;color:var(--muted-text-color)}.pref-card{margin:0 0 22px;padding:18px;border:1px solid var(--border-color);border-radius:15px;background:var(--card-bg-color)}.pref-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:10px}.pref-row{border:1px solid var(--border-color);border-radius:12px;padding:13px}.pref-row strong{display:block;margin-bottom:4px}.pref-row p{font-size:.78rem;color:var(--muted-text-color);margin:0 0 10px;min-height:34px}.pref-switches{display:flex;gap:18px;flex-wrap:wrap;font-size:.82rem}.pref-actions{display:flex;justify-content:flex-end;margin-top:14px}
</style>
<div class="nt-wrap">
 <div class="nt-head"><div><h2>Bildirim Merkezi</h2><p style="color:var(--muted-text-color)">Sipariş, ödeme, servis, güvenlik ve sistem bildirimleriniz.</p></div><form method="post" style="display:inline"><?=csrf_field()?><button class="btn btn-secondary" name="read_all" value="1"><i class="fas fa-check-double"></i> Tümünü okundu yap</button></form></div>
 <?php if($ok):?><div class="alert alert-success"><?=clean($ok)?></div><?php endif;?><?php if($error):?><div class="alert alert-danger"><?=clean($error)?></div><?php endif;?>
 <?php if(moni_plugin_enabled('notification_preferences',$db)):?>
 <form method="post" class="pref-card"><?=csrf_field()?><h3 style="margin:0 0 6px">Bildirim Tercih Merkezi</h3><p style="color:var(--muted-text-color);margin:0 0 14px">Hangi bildirimleri panel içinde, e-posta ve Web Push kanallarında almak istediğinizi seçin. Güvenlik iç bildirimleri hesap güvenliği için her zaman açıktır.</p><div class="pref-grid">
 <?php foreach($categories as $key=>$meta):$p=$prefs[$key]??['in_app'=>1,'email'=>1,'push'=>1];?><div class="pref-row"><strong><?=clean($meta[0])?></strong><p><?=clean($meta[1])?></p><div class="pref-switches"><label><input type="checkbox" name="pref[<?=clean($key)?>][in_app]" value="1" <?=!empty($p['in_app'])?'checked':''?> <?=$key==='security'?'disabled':''?>> Panel içi</label><label><input type="checkbox" name="pref[<?=clean($key)?>][email]" value="1" <?=!empty($p['email'])?'checked':''?>> E-posta</label><label><input type="checkbox" name="pref[<?=clean($key)?>][push]" value="1" <?=!empty($p['push'])?'checked':''?>> Web Push</label></div></div><?php endforeach;?>
 </div><div class="pref-actions"><button class="btn btn-primary" name="save_preferences" value="1"><i class="fas fa-save"></i> Tercihleri Kaydet</button></div></form>
 <?php endif;?>
 <?php if((string)getSetting('web_push_enabled','1')==='1'):?>
 <div class="pref-card" id="webPushCard"><h3 style="margin:0 0 6px"><i class="fas fa-mobile-screen-button"></i> Web Push Bildirimleri</h3><p style="color:var(--muted-text-color);margin:0 0 12px">Sipariş ve hesap bildirimlerini tarayıcı kapalıyken de cihazınıza alabilirsiniz. İzin tamamen cihazınızın tarayıcı ayarlarıyla kontrol edilir.</p><div style="display:flex;gap:10px;flex-wrap:wrap"><button type="button" class="btn btn-primary" id="webPushEnable"><i class="fas fa-bell"></i> Bu cihazda etkinleştir</button><button type="button" class="btn btn-secondary" id="webPushDisable"><i class="fas fa-bell-slash"></i> Bu cihazdan kaldır</button><span id="webPushStatus" style="align-self:center;color:var(--muted-text-color);font-size:.82rem"></span></div></div>
 <?php endif;?>
 <div class="nt-list"><?php if(!$rows):?><div class="admin-card"><div class="card-body">Henüz bildiriminiz yok.</div></div><?php endif;?><?php foreach($rows as $r):?><form method="post" class="nt-form"><?=csrf_field()?><button type="submit" name="read" value="<?=(int)$r['id']?>" class="nt <?=$r['read_at']?'':'unread'?>"><i class="fas <?=($r['severity']==='danger'?'fa-triangle-exclamation':($r['severity']==='success'?'fa-circle-check':'fa-bell'))?>"></i><div><h4><?=clean($r['title'])?></h4><p><?=clean($r['message']??'')?></p><small><?=clean($r['created_at'])?> <?=$r['read_at']?'':'· Yeni'?></small></div></button></form><?php endforeach;?></div>
</div>
<?php require_once 'footer.php'; ?>
