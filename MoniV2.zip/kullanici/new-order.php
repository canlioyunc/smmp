<?php
/**
 * Kullanıcı Paneli - Yeni Sipariş (Dripfeed + Favori Destekli)
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';

if (!isset($_SESSION['user_id'])) { header('Location: /login.php'); exit; }
$userId = (int)$_SESSION['user_id'];

// ==================== FAVORİ İŞLEMLERİ ====================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    
    // Favoriye ekle
    if ($_POST['action'] === 'add_favorite' && isset($_POST['service_id'])) {
        $serviceId = (int)$_POST['service_id'];
        
        $checkService = $db->prepare("SELECT id FROM services WHERE id = ? AND status = 'active'");
        $checkService->execute([$serviceId]);
        
        if ($checkService->fetch()) {
            $checkFav = $db->prepare("SELECT id FROM user_favorites WHERE user_id = ? AND service_id = ?");
            $checkFav->execute([$userId, $serviceId]);
            
            if (!$checkFav->fetch()) {
                $stmt = $db->prepare("INSERT INTO user_favorites (user_id, service_id) VALUES (?, ?)");
                $stmt->execute([$userId, $serviceId]);
            }
        }
        
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'action' => 'added']);
            exit;
        }
        
        header('Location: /kullanici/new-order.php');
        exit;
    }
    
    // Favoriden kaldır
    if ($_POST['action'] === 'remove_favorite' && isset($_POST['service_id'])) {
        $serviceId = (int)$_POST['service_id'];
        
        $stmt = $db->prepare("DELETE FROM user_favorites WHERE user_id = ? AND service_id = ?");
        $stmt->execute([$userId, $serviceId]);
        
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'action' => 'removed']);
            exit;
        }
        
        header('Location: /kullanici/new-order.php');
        exit;
    }
}

// Kullanıcının favori servis ID'lerini al
$favoriteStmt = $db->prepare("SELECT service_id FROM user_favorites WHERE user_id = ?");
$favoriteStmt->execute([$userId]);
$favoriteServiceIds = $favoriteStmt->fetchAll(PDO::FETCH_COLUMN);

// Kategorileri getir
$categories = $db->query("
    SELECT c.*, COUNT(s.id) as service_count 
    FROM categories c 
    LEFT JOIN services s ON c.id = s.category_id AND s.status = 'active'
    WHERE c.status = 'active' 
    GROUP BY c.id 
    HAVING service_count > 0
    ORDER BY c.sort_order ASC
")->fetchAll();

// Tüm aktif servisleri getir (dripfeed dahil)
$services = $db->query("
    SELECT 
        s.id, 
        s.category_id, 
        s.name, 
        IFNULL(s.description, '') as description,
        s.price_per_1000, 
        s.min_quantity, 
        s.max_quantity, 
        s.refill,
        s.dripfeed,
        s.geo_supported, s.geo_targets_json,
        s.api_provider_id, 
        s.api_service_id,
        c.name as category_name, 
        c.icon as category_icon
    FROM services s
    LEFT JOIN categories c ON s.category_id = c.id
    WHERE s.status = 'active' AND s.deleted_at IS NULL
    ORDER BY c.sort_order, s.sort_order, s.name
")->fetchAll();

// Favori servisleri al
$favoriteServices = [];
if (!empty($favoriteServiceIds)) {
    $placeholders = implode(',', array_fill(0, count($favoriteServiceIds), '?'));
    $favStmt = $db->prepare("
        SELECT 
            s.id, 
            s.category_id, 
            s.name, 
            IFNULL(s.description, '') as description,
            s.price_per_1000, 
            s.min_quantity, 
            s.max_quantity, 
            s.refill,
            s.dripfeed,
            s.api_provider_id, 
            s.api_service_id,
            c.name as category_name, 
            c.icon as category_icon
        FROM services s
        LEFT JOIN categories c ON s.category_id = c.id
        WHERE s.id IN ($placeholders) AND s.status = 'active' AND s.deleted_at IS NULL
        ORDER BY s.name
    ");
    $favStmt->execute($favoriteServiceIds);
    $favoriteServices = $favStmt->fetchAll();
}

// Çok dilli açıklama + kullanıcı davranışına göre kişiselleştirilmiş servis sıralaması.
if (function_exists('moni_localize_service_rows')) {
    $services = moni_localize_service_rows($db,$services);
    $favoriteServices = moni_localize_service_rows($db,$favoriteServices);
}
if (function_exists('moni_personalize_service_rows')) $services = moni_personalize_service_rows($db,(int)$userId,$services);

// Müşteri grubu görünürlük politikasını listeleme aşamasında da uygula.
if (function_exists('moni_service_visible_to_user')) {
    $services = array_values(array_filter($services, static function($x) use ($db,$userId){ return moni_service_visible_to_user($db,(int)$x['id'],(int)$userId); }));
    $favoriteServices = array_values(array_filter($favoriteServices, static function($x) use ($db,$userId){ return moni_service_visible_to_user($db,(int)$x['id'],(int)$userId); }));
}

// Kişiye/bayiye özel fiyat + minimum kâr politikası, ekranda tahsilatla birebir aynı olsun.
$ratingIds=array_merge(array_column($services,'id'),array_column($favoriteServices,'id'));
$serviceRatings=function_exists('moni_service_ratings')?moni_service_ratings($db,$ratingIds):[];
foreach ($services as &$svc) {
    $svc['price_per_1000'] = moni_effective_price_per_1000($svc, (int)$userId);
    $svc['price_tiers'] = function_exists('moni_service_price_tiers') ? moni_service_price_tiers($db,(int)$svc['id'],true) : [];
    $svc['min_sale_price'] = moni_minimum_sale_price($svc);
    $svc['maintenance_reason'] = moni_maintenance_reason((int)$svc['id'], (int)($svc['api_provider_id'] ?? 0));
    $r=$serviceRatings[(int)$svc['id']]??['avg'=>0.0,'count'=>0];$svc['rating_avg']=$r['avg'];$svc['rating_count']=$r['count'];
}
unset($svc);
foreach ($favoriteServices as &$svc) {
    $svc['price_per_1000'] = moni_effective_price_per_1000($svc, (int)$userId);
    $svc['price_tiers'] = function_exists('moni_service_price_tiers') ? moni_service_price_tiers($db,(int)$svc['id'],true) : [];
    $svc['min_sale_price'] = moni_minimum_sale_price($svc);
    $svc['maintenance_reason'] = moni_maintenance_reason((int)$svc['id'], (int)($svc['api_provider_id'] ?? 0));
    $r=$serviceRatings[(int)$svc['id']]??['avg'=>0.0,'count'=>0];$svc['rating_avg']=$r['avg'];$svc['rating_count']=$r['count'];
}
unset($svc);
if(function_exists('moni_service_capacity_attach')){moni_service_capacity_attach($db,$services);moni_service_capacity_attach($db,$favoriteServices);}
if(function_exists('moni_service_auto_badges_attach')){moni_service_auto_badges_attach($db,$services);moni_service_auto_badges_attach($db,$favoriteServices);}
if(function_exists('moni_service_tags_attach')){moni_service_tags_attach($db,$services);moni_service_tags_attach($db,$favoriteServices);}
if(function_exists('moni_service_schedule_attach')){moni_service_schedule_attach($db,$services);moni_service_schedule_attach($db,$favoriteServices);}
if(function_exists('moni_plugin_enabled')&&moni_plugin_enabled('real_delivery_eta',$db)&&function_exists('moni_service_delivery_estimate')){
    foreach($services as &$svc){$eta=moni_service_delivery_estimate($db,(int)$svc['id']);$svc['delivery_eta']=!empty($eta['available'])?(string)$eta['label']:'';}unset($svc);
    foreach($favoriteServices as &$svc){$eta=moni_service_delivery_estimate($db,(int)$svc['id']);$svc['delivery_eta']=!empty($eta['available'])?(string)$eta['label']:'';}unset($svc);
}

// Tek tıkla tekrar sipariş: yalnız oturum sahibinin siparişi ön doldurulur.
$reorderData=null;
if(!empty($_GET['reorder'])){$rs=$db->prepare("SELECT id,service_id,link,quantity FROM orders WHERE id=? AND user_id=? LIMIT 1");$rs->execute([(int)$_GET['reorder'],$userId]);$reorderData=$rs->fetch(PDO::FETCH_ASSOC)?:null;if($reorderData)$_GET['service']=(int)$reorderData['service_id'];}

// URL'den servis seçimi
$preSelectedService = null;
if (isset($_GET['service'])) {
    $serviceId = (int)$_GET['service'];
    foreach ($services as $s) {
        if ($s['id'] == $serviceId) {
            $preSelectedService = $s;
            break;
        }
    }
}

// Sipariş işlemi
$orderSuccess = '';
$orderError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'place_order') {
    $result = moni_place_order($db, (int)$userId, (int)($_POST['service_id'] ?? 0), trim((string)($_POST['link'] ?? '')), (int)($_POST['quantity'] ?? 0), [
        'dripfeed' => isset($_POST['dripfeed_active']) && $_POST['dripfeed_active'] === '1',
        'runs' => (int)($_POST['runs'] ?? 1),
        'interval' => (int)($_POST['interval'] ?? 1),
        'idempotency_key' => (string)($_POST['idempotency_key'] ?? ''),
        'source' => 'web-new-order',
        'geo_target' => (string)($_POST['geo_target'] ?? '')
    ]);
    if (!empty($result['success'])) {
        $_SESSION['balance'] = (float)$db->query("SELECT balance FROM users WHERE id=".(int)$userId)->fetchColumn();
        $msg = $result['message'] ?? __('order_success');
        if (!empty($result['warning'])) $msg .= ' | ' . $result['warning'];
        header('Location: /kullanici/orders.php?success=' . urlencode($msg)); exit;
    }
    $orderError = $result['error'] ?? __('order_error');
}

$pageTitle = __('new_order');
require_once 'header.php';
?>
<style>
/* Order Page Layout */
.order-page {
    display: grid;
    grid-template-columns: 1fr 400px;
    gap: 25px;
    max-width: 1200px;
}

@media (max-width: 1100px) {
    .order-page {
        grid-template-columns: 1fr;
    }
}

/* Step Indicator */
.steps-indicator {
    display: flex;
    margin-bottom: 30px;
    position: relative;
}

.steps-indicator::before {
    content: '';
    position: absolute;
    top: 20px;
    left: 60px;
    right: 60px;
    height: 3px;
    background: var(--border-color);
    z-index: 0;
}

.step {
    flex: 1;
    text-align: center;
    position: relative;
    z-index: 1;
}

.step-number {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: var(--border-color);
    color: var(--text-color);
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 10px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.step.active .step-number {
    background: var(--primary-color);
    color: var(--on-primary-color);
    box-shadow: 0 5px 20px var(--primary-alpha-04);
}

.step.completed .step-number {
    background: var(--success-color);
    color: var(--on-success-color);
}

.step-label {
    font-size: 0.85rem;
    color: var(--text-color);
    opacity: 0.6;
}

.step.active .step-label,
.step.completed .step-label {
    opacity: 1;
    font-weight: 500;
}

/* Category Grid */
.category-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
    gap: 12px;
    margin-bottom: 25px;
}

.category-card {
    background: var(--background-color);
    border: 2px solid var(--border-color);
    border-radius: 12px;
    padding: 20px 15px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
}

.category-card:hover {
    border-color: var(--accent-text-color);
    transform: translateY(-3px);
}

.category-card.selected {
    border-color: var(--accent-text-color);
    background: var(--primary-alpha-01);
}

.category-card.favorites-card {
    background: linear-gradient(135deg, rgba(255, 193, 7, 0.1), rgba(255, 152, 0, 0.05));
    border-color: rgba(255, 193, 7, 0.3);
}

.category-card.favorites-card:hover {
    border-color: var(--warning-color);
}

.category-card.favorites-card.selected {
    border-color: var(--warning-color);
    background: linear-gradient(135deg, rgba(255, 193, 7, 0.2), rgba(255, 152, 0, 0.1));
}

.category-card .icon {
    width: 45px;
    height: 45px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 12px;
    font-size: 1.2rem;
    color: #fff;
}

.category-card h4 {
    font-size: 0.9rem;
    font-weight: 600;
    margin-bottom: 4px;
}

.category-card span {
    font-size: 0.75rem;
    opacity: 0.6;
}

/* Service List */
.service-list {
    max-height: 400px;
    overflow-y: auto;
    border: 1px solid var(--border-color);
    border-radius: 12px;
    margin-bottom: 20px;
}

.service-item {
    display: flex;
    align-items: flex-start;
    padding: 15px 20px;
    border-bottom: 1px solid var(--border-color);
    cursor: pointer;
    transition: all 0.2s ease;
    position: relative;
}

.service-item:last-child {
    border-bottom: none;
}

.service-item:hover {
    background: var(--background-color);
}

.service-item.selected {
    background: var(--primary-alpha-01);
    border-left: 3px solid var(--primary-color);
}

.service-item .radio {
    width: 20px;
    height: 20px;
    border: 2px solid var(--border-color);
    border-radius: 50%;
    margin-right: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    margin-top: 3px;
}

.service-item.selected .radio {
    border-color: var(--accent-text-color);
    background: var(--primary-color);
}

.service-item.selected .radio::after {
    content: '';
    width: 8px;
    height: 8px;
    background: #fff;
    border-radius: 50%;
}

.service-item .info {
    flex: 1;
    min-width: 0;
}

.service-item .info h5 {
    font-size: 0.9rem;
    font-weight: 600;
    margin-bottom: 5px;
}

.service-item .info .desc {
    font-size: 0.8rem;
    opacity: 0.6;
    margin-bottom: 8px;
    line-height: 1.5;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.service-item .info .meta {
    display: flex;
    gap: 12px;
    font-size: 0.75rem;
    flex-wrap: wrap;
}

.service-item .info .meta span {
    display: flex;
    align-items: center;
    gap: 4px;
    opacity: 0.7;
}

.service-badges {
    display: flex;
    gap: 5px;
    margin-top: 8px;
    flex-wrap: wrap;
}

.service-badge {
    padding: 3px 8px;
    border-radius: 10px;
    font-size: 0.7rem;
    font-weight: 600;
}

.service-badge.refill {
    background: var(--success-soft-bg);
    color: var(--success-color);
}

.service-badge.auto {
    background: var(--primary-alpha-015);
    color: var(--accent-text-color);
}

.service-badge.drip {
    background: rgba(0, 123, 255, 0.15);
    color: var(--info-color);
}

.service-badge.favorite {
    background: rgba(255, 193, 7, 0.15);
    color: var(--warning-color);
}
.service-badge.capacity-ok{background:var(--success-soft-bg);color:var(--success-color)}
.service-badge.capacity-warn{background:rgba(245,158,11,.16);color:var(--warning-color)}
.service-badge.capacity-danger{background:rgba(239,68,68,.16);color:var(--danger-color)}
.service-badge.capacity-off{background:var(--primary-alpha-01);color:var(--muted-text-color)}

.service-item .price-favorite {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 8px;
    margin-left: 15px;
}

.service-item .price {
    font-weight: 700;
    color: var(--success-color);
    font-size: 0.95rem;
    white-space: nowrap;
}

.service-favorite-btn {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    border: none;
    background: rgba(255, 193, 7, 0.1);
    color: rgba(255, 193, 7, 0.5);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.85rem;
    transition: all 0.3s ease;
}

.service-favorite-btn:hover {
    background: rgba(255, 193, 7, 0.2);
    color: var(--warning-color);
    transform: scale(1.1);
}

.service-favorite-btn.active {
    background: rgba(255, 193, 7, 0.2);
    color: var(--warning-color);
}

.service-favorite-btn.active i {
    font-weight: 900;
}

/* Service Detail Box */
.service-detail-box {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 16px;
    padding: 25px;
    color: var(--on-accent-color);
    margin-bottom: 20px;
    display: none;
}

.service-detail-box.active {
    display: block;
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

.service-detail-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    margin-bottom: 8px;
}

.service-detail-box h4 {
    font-size: 1.1rem;
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 0;
}

.detail-favorite-btn {
    padding: 8px 15px;
    border-radius: 8px;
    border: none;
    font-size: 0.8rem;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 6px;
    transition: all 0.3s ease;
    background: var(--on-accent-alpha-020);
    color: var(--on-accent-color);
}

.detail-favorite-btn:hover {
    background: var(--on-accent-alpha-030);
}

.detail-favorite-btn.active {
    background: rgba(255, 193, 7, 0.3);
    color: var(--warning-color);
}

.service-detail-box .description {
    font-size: 0.9rem;
    opacity: 0.9;
    margin-bottom: 20px;
    line-height: 1.6;
}

.service-detail-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
}

.service-detail-item {
    background: var(--on-accent-alpha-015);
    padding: 12px 15px;
    border-radius: 10px;
}

.service-detail-item label {
    display: block;
    font-size: 0.75rem;
    opacity: 0.8;
    margin-bottom: 3px;
}

.service-detail-item span {
    font-size: 1rem;
    font-weight: 600;
}

/* Order Form */
.order-form .form-group {
    margin-bottom: 20px;
}

.order-form .form-label {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 10px;
    font-weight: 500;
}

.order-form .form-label i {
    color: var(--accent-text-color);
}

.order-form .form-control {
    width: 100%;
    padding: 14px 18px;
    border: 2px solid var(--border-color);
    border-radius: 12px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 1rem;
    transition: all 0.3s ease;
}

.order-form .form-control:focus {
    outline: none;
    border-color: var(--accent-text-color);
    box-shadow: 0 0 0 4px var(--primary-alpha-01);
}

.order-form .form-hint {
    font-size: 0.8rem;
    opacity: 0.6;
    margin-top: 8px;
}

.order-form .input-group {
    position: relative;
}

.order-form .input-group i {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    opacity: 0.4;
}

.order-form .input-group input {
    padding-left: 45px;
}

/* Drip-feed Section - Tema Uyumlu */
.dripfeed-section {
    margin-top: 20px;
    display: none;
}

.dripfeed-section.show {
    display: block;
    animation: slideDown 0.3s ease;
}

.dripfeed-toggle-wrapper {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 18px 20px;
    background: var(--background-color);
    border: 2px solid var(--border-color);
    border-radius: 12px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.dripfeed-toggle-wrapper:hover {
    border-color: var(--accent-text-color);
}

.dripfeed-toggle-wrapper.active {
    border-color: var(--accent-text-color);
    background: var(--primary-alpha-005);
}

.dripfeed-toggle-left {
    display: flex;
    align-items: center;
    gap: 15px;
}

.dripfeed-toggle-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--on-accent-color);
    font-size: 1.2rem;
}

.dripfeed-toggle-info h4 {
    font-size: 1rem;
    font-weight: 600;
    margin-bottom: 4px;
    color: var(--text-color);
}

.dripfeed-toggle-info p {
    font-size: 0.85rem;
    opacity: 0.6;
    margin: 0;
}

/* Toggle Switch */
.toggle-switch {
    position: relative;
    width: 56px;
    height: 30px;
}

.toggle-switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.toggle-slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: var(--border-color);
    border-radius: 30px;
    transition: 0.3s;
}

.toggle-slider:before {
    position: absolute;
    content: "";
    height: 22px;
    width: 22px;
    left: 4px;
    bottom: 4px;
    background: #fff;
    border-radius: 50%;
    transition: 0.3s;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
}

.toggle-switch input:checked + .toggle-slider {
    background: var(--primary-color);
}

.toggle-switch input:checked + .toggle-slider:before {
    transform: translateX(26px);
}

/* Dripfeed Fields */
.dripfeed-fields {
    display: none;
    margin-top: 15px;
    padding: 20px;
    background: var(--background-color);
    border: 2px solid var(--primary-color);
    border-radius: 12px;
    animation: slideDown 0.3s ease;
}

.dripfeed-fields.show {
    display: block;
}

.dripfeed-fields-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}

.dripfeed-fields .form-group {
    margin-bottom: 0;
}

.dripfeed-total-box {
    margin-top: 15px;
    padding: 15px;
    background: linear-gradient(135deg, var(--primary-alpha-01), var(--primary-alpha-005));
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.dripfeed-total-box .label {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 0.9rem;
    color: var(--text-color);
}

.dripfeed-total-box .label i {
    color: var(--accent-text-color);
}

.dripfeed-total-box .value {
    font-size: 1.2rem;
    font-weight: 700;
    color: var(--accent-text-color);
}

/* Order Summary Card */
.order-summary {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    position: sticky;
    top: 90px;
}

.order-summary .header {
    padding: 20px;
    border-bottom: 1px solid var(--border-color);
}

.order-summary .header h3 {
    font-size: 1.1rem;
    display: flex;
    align-items: center;
    gap: 10px;
}

.order-summary .header h3 i {
    color: var(--accent-text-color);
}

.order-summary .body {
    padding: 20px;
}

.summary-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 0;
    border-bottom: 1px dashed var(--border-color);
}

.summary-item:last-child {
    border-bottom: none;
}

.summary-item .label {
    font-size: 0.9rem;
    opacity: 0.7;
}

.summary-item .value {
    font-weight: 600;
    font-size: 0.95rem;
    max-width: 180px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.summary-item.total {
    padding-top: 15px;
    margin-top: 10px;
    border-top: 2px solid var(--border-color);
    border-bottom: none;
}

.summary-item.total .label {
    font-size: 1rem;
    font-weight: 600;
    opacity: 1;
}

.summary-item.total .value {
    font-size: 1.4rem;
    color: var(--accent-text-color);
}

.balance-warning {
    background: rgba(220, 53, 69, 0.1);
    border: 1px solid rgba(220, 53, 69, 0.3);
    border-radius: 10px;
    padding: 12px 15px;
    margin-top: 15px;
    display: none;
    font-size: 0.85rem;
    color: var(--danger-color);
}

.balance-warning.active {
    display: flex;
    align-items: center;
    gap: 10px;
}

.balance-info {
    background: var(--background-color);
    border-radius: 10px;
    padding: 15px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.balance-info .current {
    font-size: 0.85rem;
    opacity: 0.7;
}

.balance-info .amount {
    font-weight: 700;
    font-size: 1.1rem;
    color: var(--success-color);
}

.order-summary .footer {
    padding: 20px;
    border-top: 1px solid var(--border-color);
}

.submit-btn {
    width: 100%;
    padding: 16px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border: none;
    border-radius: 12px;
    color: var(--on-accent-color);
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    transition: all 0.3s ease;
}

.submit-btn:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px var(--primary-alpha-04);
}

.submit-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}

.add-funds-link {
    display: block;
    text-align: center;
    margin-top: 15px;
    color: var(--accent-text-color);
    text-decoration: none;
    font-size: 0.9rem;
    font-weight: 500;
}

.add-funds-link:hover {
    text-decoration: underline;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 50px 20px;
    opacity: 0.6;
}

.empty-state i {
    font-size: 3rem;
    margin-bottom: 15px;
    opacity: 0.3;
    display: block;
}

/* Search Box */
.search-box {
    position: relative;
    margin-bottom: 15px;
}

.search-box input {
    width: 100%;
    padding: 12px 15px 12px 45px;
    border: 2px solid var(--border-color);
    border-radius: 10px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 0.95rem;
}

.search-box input:focus {
    outline: none;
    border-color: var(--accent-text-color);
}

.search-box i {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    opacity: 0.4;
}

.service-badge.rating{background:rgba(245,158,11,.14);color:var(--warning-color);border:1px solid rgba(245,158,11,.22)}.service-badge.rating-empty{background:var(--primary-alpha-01);color:var(--muted-text-color);border:1px solid var(--border-color)}.detail-rating{display:inline-flex;align-items:center;gap:6px;color:var(--muted-text-color);font-weight:750}.detail-rating.has-rating{color:var(--warning-color)}.detail-rating small{font-size:.72rem;color:var(--muted-text-color);font-weight:600}
</style>
<div class="order-page">
    <div class="order-form-section">
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-plus-circle"></i> <?php echo __('create_new_order'); ?></h2>
            </div>
            <div class="card-body">
                <?php if ($orderError): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle"></i>
                        <?php echo clean($orderError); ?>
                    </div>
                <?php endif; ?>
                
                <div class="steps-indicator">
                    <div class="step active" id="step1">
                        <div class="step-number">1</div>
                        <div class="step-label"><?php echo __('category'); ?></div>
                    </div>
                    <div class="step" id="step2">
                        <div class="step-number">2</div>
                        <div class="step-label"><?php echo __('service'); ?></div>
                    </div>
                    <div class="step" id="step3">
                        <div class="step-number">3</div>
                        <div class="step-label"><?php echo __('details'); ?></div>
                    </div>
                </div>
                
                <form method="POST" id="orderForm" class="order-form">
                    <input type="hidden" name="action" value="place_order">
<input type="hidden" name="idempotency_key" value="<?php echo bin2hex(random_bytes(16)); ?>">
                    <input type="hidden" name="service_id" id="selectedServiceId" value="<?php echo $preSelectedService ? $preSelectedService['id'] : ''; ?>">
                    
                    <div class="form-group">
                        <label class="form-label"><i class="fas fa-folder"></i> <?php echo __('select_category'); ?></label>
                        <div class="category-grid">
                            <?php if (!empty($favoriteServices)): ?>
                                <div class="category-card favorites-card <?php echo (isset($_GET['cat']) && $_GET['cat'] === 'favorites') ? 'selected' : ''; ?>" 
                                     data-category="favorites"
                                     onclick="selectCategory(this, 'favorites')">
                                    <div class="icon" style="background: linear-gradient(135deg, var(--warning-color), #ff9800);">
                                        <i class="fas fa-star"></i>
                                    </div>
                                    <h4>⭐ Favorilerim</h4>
                                    <span><?php echo count($favoriteServices); ?> <?php echo __('services'); ?></span>
                                </div>
                            <?php endif; ?>
                            <?php foreach ($categories as $cat): ?>
                                <div class="category-card <?php echo ($preSelectedService && $preSelectedService['category_id'] == $cat['id']) ? 'selected' : ''; ?>" 
                                     data-category="<?php echo $cat['id']; ?>"
                                     onclick="selectCategory(this, <?php echo $cat['id']; ?>)">
                                    <div class="icon" style="background: <?php echo $cat['icon_color'] ?: '#667eea'; ?>">
                                        <i class="<?php echo $cat['icon'] ?: 'fas fa-folder'; ?>"></i>
                                    </div>
                                    <h4><?php echo clean($cat['name']); ?></h4>
                                    <span><?php echo $cat['service_count']; ?> <?php echo __('services'); ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <div class="form-group" id="serviceSection" style="<?php echo $preSelectedService ? '' : 'display:none;'; ?>">
                        <label class="form-label"><i class="fas fa-list"></i> <?php echo __('select_service'); ?></label>
                        <div class="search-box">
                            <i class="fas fa-search"></i>
                            <input type="text" id="serviceSearch" placeholder="<?php echo __('search_service'); ?>...">
                        </div>
                        <div class="service-list" id="serviceList"></div>
                    </div>
                    
                    <div class="service-detail-box" id="serviceDetailBox">
                        <div class="service-detail-header">
                            <h4><i class="fas fa-check-circle"></i> <span id="detailName"></span></h4>
                            <button type="button" class="detail-favorite-btn" id="detailFavoriteBtn" onclick="toggleDetailFavorite()">
                                <i class="far fa-star"></i> <span>Favoriye Ekle</span>
                            </button>
                        </div>
                        <p class="description" id="detailDescription"></p>
                        <div class="service-detail-grid">
                            <div class="service-detail-item">
                                <label><?php echo __('price_per_1000'); ?></label>
                                <span id="detailPrice"></span>
                            </div>
                            <div class="service-detail-item">
                                <label><?php echo __('min'); ?></label>
                                <span id="detailMin"></span>
                            </div>
                            <div class="service-detail-item">
                                <label><?php echo __('max'); ?></label>
                                <span id="detailMax"></span>
                            </div>
                            <div class="service-detail-item">
                                <label><?php echo __('estimated_time'); ?></label>
                                <span id="detailEta">Veri bekleniyor</span>
                            </div>
                            <div class="service-detail-item service-rating-detail">
                                <label>Servis Puanı</label>
                                <span id="detailRating" class="detail-rating"><i class="far fa-star"></i> Henüz puan yok</span>
                            </div>
                        </div>
                    </div>
                    
                    <div id="orderDetails" style="<?php echo $preSelectedService ? '' : 'display:none;'; ?>">
                        <div class="form-group">
                            <label class="form-label"><i class="fas fa-link"></i> <?php echo __('link'); ?> / <?php echo __('username'); ?></label>
                            <div class="input-group">
                                <i class="fas fa-link"></i>
                                <input type="text" name="link" id="linkInput" class="form-control" placeholder="https://instagram.com/username veya @kullaniciadi" value="<?php echo clean($reorderData['link'] ?? ''); ?>" required>
                            </div>
                            <p class="form-hint"><?php echo __('link_hint'); ?></p>
                        </div>
                        
                        <div class="form-group" id="geoTargetGroup" style="display:none;">
                            <label class="form-label"><i class="fas fa-globe"></i> Coğrafi Hedef</label>
                            <select name="geo_target" id="geoTargetSelect" class="form-control"><option value="">Hedef seçin</option></select>
                            <p class="form-hint">Bu servis provider tarafından coğrafi hedefleme desteklediği için hedef seçimi zorunludur.</p>
                        </div>

                        <div class="form-group">
                            <label class="form-label"><i class="fas fa-sort-numeric-up"></i> <?php echo __('quantity'); ?></label>
                            <div class="input-group">
                                <i class="fas fa-hashtag"></i>
                                <input type="number" name="quantity" id="quantityInput" class="form-control" placeholder="<?php echo __('enter_quantity'); ?>" value="<?php echo !empty($reorderData)?(int)$reorderData['quantity']:''; ?>" required>
                            </div>
                            <p class="form-hint" id="quantityHint"><?php echo __('min'); ?>: - / <?php echo __('max'); ?>: -</p>
                        </div>

                        <!-- DRIP-FEED SECTION -->
                        <div class="dripfeed-section" id="dripfeedSection">
                            <div class="dripfeed-toggle-wrapper" id="dripfeedToggleWrapper" onclick="toggleDripfeed()">
                                <div class="dripfeed-toggle-left">
                                    <div class="dripfeed-toggle-icon">
                                        <i class="fas fa-tint"></i>
                                    </div>
                                    <div class="dripfeed-toggle-info">
                                        <h4>Drip-feed Modu</h4>
                                        <p>Siparişi zamana yayarak gönder</p>
                                    </div>
                                </div>
                                <label class="toggle-switch" onclick="event.stopPropagation()">
                                    <input type="checkbox" id="dripfeedToggle" name="dripfeed_active" value="1">
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                            
                            <div class="dripfeed-fields" id="dripfeedFields">
                                <div class="dripfeed-fields-grid">
                                    <div class="form-group">
                                        <label class="form-label"><i class="fas fa-redo"></i> Runs (Tekrar)</label>
                                        <input type="number" name="runs" id="runsInput" class="form-control" placeholder="Örn: 10" min="2">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label"><i class="fas fa-clock"></i> Interval (Dakika)</label>
                                        <input type="number" name="interval" id="intervalInput" class="form-control" placeholder="Örn: 30" min="1">
                                    </div>
                                </div>
                                <div class="dripfeed-total-box">
                                    <div class="label">
                                        <i class="fas fa-calculator"></i>
                                        <span>Toplam Gönderilecek Miktar</span>
                                    </div>
                                    <div class="value" id="dfTotalQty">0</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <div class="order-summary">
        <div class="header">
            <h3><i class="fas fa-receipt"></i> <?php echo __('order_summary'); ?></h3>
        </div>
        <div class="body">
            <div class="summary-item">
                <span class="label"><?php echo __('service'); ?></span>
                <span class="value" id="summaryService">-</span>
            </div>
            <div class="summary-item">
                <span class="label"><?php echo __('quantity'); ?></span>
                <span class="value" id="summaryQuantity">-</span>
            </div>
            <div class="summary-item">
                <span class="label"><?php echo __('unit_price'); ?></span>
                <span class="value" id="summaryUnitPrice">-</span>
            </div>
            <div class="summary-item total">
                <span class="label"><?php echo __('total'); ?></span>
                <span class="value" id="summaryTotal"><?php echo $siteSettings['currency_symbol']; ?>0.00</span>
            </div>
            
            <div class="balance-info">
                <span class="current"><?php echo __('current_balance'); ?></span>
                <span class="amount"><?php echo $siteSettings['currency_symbol'] . number_format($currentUser['balance'], 2); ?></span>
            </div>
            
            <div class="balance-warning" id="balanceWarning">
                <i class="fas fa-exclamation-triangle"></i>
                <span><?php echo __('insufficient_balance'); ?>!</span>
            </div>
        </div>
        <div class="footer">
            <button type="submit" form="orderForm" class="submit-btn" id="submitBtn" disabled>
                <i class="fas fa-shopping-cart"></i>
                <?php echo __('place_order'); ?>
            </button>
            <a href="/kullanici/add-funds.php" class="add-funds-link">
                <i class="fas fa-plus-circle"></i> <?php echo __('add_funds'); ?>
            </a>
        </div>
    </div>
</div>

<script>
const currencySymbol = '<?php echo $siteSettings['currency_symbol']; ?>';
const userBalance = <?php echo $currentUser['balance']; ?>;
const servicesData = <?php echo json_encode($services, JSON_UNESCAPED_UNICODE); ?>;
const favoriteServicesData = <?php echo json_encode($favoriteServices, JSON_UNESCAPED_UNICODE); ?>;
let favoriteServiceIds = <?php echo json_encode(array_map('intval', $favoriteServiceIds)); ?>;

const t = {
    select_service: '<?php echo __('select_service'); ?>',
    refill: '<?php echo __('refill'); ?>',
    automatic: '<?php echo __('automatic'); ?>',
    min: '<?php echo __('min'); ?>',
    max: '<?php echo __('max'); ?>',
    service_not_found: '<?php echo __('service_not_found'); ?>',
    no_description: '<?php echo __('no_description'); ?>',
    please_select_service: '<?php echo __('please_select_service'); ?>',
    please_enter_link: '<?php echo __('please_enter_link'); ?>',
    minimum_quantity: '<?php echo __('minimum_quantity'); ?>',
    maximum_quantity: '<?php echo __('maximum_quantity'); ?>',
    insufficient_balance: '<?php echo __('insufficient_balance'); ?>',
    processing: '<?php echo __('processing'); ?>',
    add_to_favorites: 'Favoriye Ekle',
    remove_from_favorites: 'Favoriden Kaldır'
};

let selectedCategory = <?php echo $preSelectedService ? $preSelectedService['category_id'] : 'null'; ?>;
let selectedService = <?php echo $preSelectedService ? json_encode($preSelectedService, JSON_UNESCAPED_UNICODE) : 'null'; ?>;

// Dripfeed Elements
const dfSection = document.getElementById('dripfeedSection');
const dfToggle = document.getElementById('dripfeedToggle');
const dfToggleWrapper = document.getElementById('dripfeedToggleWrapper');
const dfFields = document.getElementById('dripfeedFields');
const runsInput = document.getElementById('runsInput');
const intervalInput = document.getElementById('intervalInput');
const detailFavoriteBtn = document.getElementById('detailFavoriteBtn');

document.addEventListener('DOMContentLoaded', function() {
    if (selectedCategory) {
        renderServices(selectedCategory);
        updateSteps(2);
    }
    if (selectedService) {
        setTimeout(() => selectServiceById(selectedService.id), 100);
    }
});

function selectCategory(el, categoryId) {
    document.querySelectorAll('.category-card').forEach(c => c.classList.remove('selected'));
    el.classList.add('selected');
    selectedCategory = categoryId;
    
    document.getElementById('serviceSection').style.display = 'block';
    document.getElementById('serviceDetailBox').classList.remove('active');
    document.getElementById('orderDetails').style.display = 'none';
    document.getElementById('selectedServiceId').value = '';
    selectedService = null;
    resetDripfeed();
    
    renderServices(categoryId);
    updateSteps(2);
    updateSummary();
}

function renderServices(categoryId) {
    let filtered = [];
    
    if (categoryId === 'favorites') {
        filtered = favoriteServicesData;
    } else {
        filtered = servicesData.filter(s => s.category_id == categoryId);
    }
    
    const searchVal = document.getElementById('serviceSearch').value.toLowerCase();
    
    let html = '';
    filtered.forEach(s => {
        if (searchVal && !s.name.toLowerCase().includes(searchVal)) return;
        
        const isSelected = selectedService && selectedService.id == s.id;
        const isFavorite = favoriteServiceIds.includes(parseInt(s.id));
        const desc = s.description || '';
        
        html += `
            <div class="service-item ${isSelected ? 'selected' : ''}" data-id="${s.id}">
                <div class="radio" onclick="selectServiceById(${s.id})"></div>
                <div class="info" onclick="selectServiceById(${s.id})">
                    <h5>${isFavorite && categoryId !== 'favorites' ? '⭐ ' : ''}${escapeHtml(s.name)}</h5>
                    ${desc ? `<p class="desc">${escapeHtml(desc)}</p>` : ''}
                    <div class="meta">
                        <span><i class="fas fa-arrow-down"></i> ${t.min}: ${Number(s.min_quantity).toLocaleString()}</span>
                        <span><i class="fas fa-arrow-up"></i> ${t.max}: ${Number(s.max_quantity).toLocaleString()}</span>
                    </div>
                    <div class="service-badges">
                        ${s.dripfeed == 1 ? '<span class="service-badge drip"><i class="fas fa-tint"></i> Drip-feed</span>' : ''}
                        ${s.refill == 1 ? `<span class="service-badge refill"><i class="fas fa-sync-alt"></i> ${t.refill}</span>` : ''}
                        ${s.api_provider_id ? `<span class="service-badge auto"><i class="fas fa-bolt"></i> ${t.automatic}</span>` : ''}
                        ${Number(s.rating_count||0)>0 ? `<span class="service-badge rating"><i class="fas fa-star"></i> ${Number(s.rating_avg).toFixed(1)} / 5 · ${Number(s.rating_count)} değerlendirme</span>` : '<span class="service-badge rating-empty"><i class="far fa-star"></i> Henüz puan yok</span>'}
                        ${s.capacity ? `<span class="service-badge capacity-${escapeHtml(s.capacity.badge||'off')}"><i class="fas ${escapeHtml(s.capacity.icon||'fa-circle-question')}"></i> ${escapeHtml(s.capacity.label||'Kapasite Belirsiz')}${s.capacity.show_exact ? ' · %'+Math.round(Number(s.capacity.utilization||0)) : ''}</span>` : ''}
                        ${Array.isArray(s.auto_badges) ? s.auto_badges.map(b=>`<span class="service-badge" title="${escapeHtml(b.reason||'')}"><i class="fas ${escapeHtml(b.icon||'fa-award')}"></i> ${escapeHtml(b.label||'Rozet')}</span>`).join('') : ''}
                        ${Array.isArray(s.service_tags) ? s.service_tags.map(tg=>`<span class="service-badge"><i class="fas ${escapeHtml(tg.icon||'fa-tag')}"></i> ${escapeHtml(tg.name||'Etiket')}</span>`).join('') : ''}
                        ${s.schedule_label ? `<span class="service-badge ${s.schedule_open ? 'refill' : 'capacity-warn'}"><i class="fas ${s.schedule_open ? 'fa-circle-check' : 'fa-clock'}"></i> ${escapeHtml(s.schedule_label)}${s.schedule_next ? ' · '+escapeHtml(s.schedule_next) : ''}</span>` : ''}
                    </div>
                </div>
                <div class="price-favorite">
                    <div class="price">${currencySymbol}${parseFloat(s.price_per_1000).toFixed(2)}</div>
                    <button type="button" class="service-favorite-btn ${isFavorite ? 'active' : ''}" onclick="toggleFavorite(event, ${s.id})" title="${isFavorite ? t.remove_from_favorites : t.add_to_favorites}">
                        <i class="${isFavorite ? 'fas' : 'far'} fa-star"></i>
                    </button>
                </div>
            </div>
        `;
    });
    
    document.getElementById('serviceList').innerHTML = html || `<div class="empty-state"><i class="fas fa-search"></i><p>${t.service_not_found}</p></div>`;
}

function selectServiceById(serviceId) {
    // Önce favorilerden veya normal servislerden bul
    selectedService = servicesData.find(s => s.id == serviceId) || favoriteServicesData.find(s => s.id == serviceId);
    if (!selectedService) return;
    
    document.getElementById('selectedServiceId').value = serviceId;
    
    document.querySelectorAll('.service-item').forEach(item => {
        item.classList.toggle('selected', item.dataset.id == serviceId);
    });
    
    const desc = selectedService.description || t.no_description;
    document.getElementById('detailName').textContent = selectedService.name;
    document.getElementById('detailDescription').textContent = desc;
    document.getElementById('detailPrice').textContent = currencySymbol + parseFloat(selectedService.price_per_1000).toFixed(2);
    document.getElementById('detailMin').textContent = Number(selectedService.min_quantity).toLocaleString();
    document.getElementById('detailMax').textContent = Number(selectedService.max_quantity).toLocaleString();
    const detailEta=document.getElementById('detailEta');if(detailEta)detailEta.textContent=selectedService.delivery_eta||selectedService.average_time||'Henüz yeterli veri yok';
    const detailRating=document.getElementById('detailRating');
    if(detailRating){const rc=Number(selectedService.rating_count||0),ra=Number(selectedService.rating_avg||0);detailRating.innerHTML=rc>0?'<i class="fas fa-star"></i> '+ra.toFixed(1)+' / 5 <small>('+rc+' değerlendirme)</small>':'<i class="far fa-star"></i> Henüz puan yok';detailRating.classList.toggle('has-rating',rc>0);}
    document.getElementById('serviceDetailBox').classList.add('active');
    
    // Favori butonunu güncelle
    const isFavorite = favoriteServiceIds.includes(parseInt(serviceId));
    updateDetailFavoriteBtn(isFavorite);
    
    document.getElementById('orderDetails').style.display = 'block';
    document.getElementById('quantityInput').min = selectedService.min_quantity;
    document.getElementById('quantityInput').max = selectedService.max_quantity;
    document.getElementById('quantityInput').placeholder = `${t.min}: ${Number(selectedService.min_quantity).toLocaleString()} - ${t.max}: ${Number(selectedService.max_quantity).toLocaleString()}`;
    document.getElementById('quantityHint').textContent = `${t.min}: ${Number(selectedService.min_quantity).toLocaleString()} / ${t.max}: ${Number(selectedService.max_quantity).toLocaleString()}`;
    
    // Provider tarafından doğrulanmış coğrafi hedefler
    const geoGroup=document.getElementById('geoTargetGroup'), geoSelect=document.getElementById('geoTargetSelect');
    let geoTargets=[];try{geoTargets=JSON.parse(selectedService.geo_targets_json||'[]')}catch(e){geoTargets=[]}
    if(selectedService.geo_supported==1 && Array.isArray(geoTargets) && geoTargets.length){geoSelect.innerHTML='<option value="">Hedef seçin</option>'+geoTargets.map(g=>'<option value="'+escapeHtml(String(g))+'">'+escapeHtml(String(g))+'</option>').join('');geoSelect.required=true;geoGroup.style.display='block';}else{geoSelect.innerHTML='<option value="">Hedef yok</option>';geoSelect.required=false;geoGroup.style.display='none';}

    // Dripfeed kontrolü
    resetDripfeed();
    if (selectedService.dripfeed == 1) {
        dfSection.classList.add('show');
    }
    
    updateSteps(3);
    updateSummary();
}

function updateDetailFavoriteBtn(isFavorite) {
    if (isFavorite) {
        detailFavoriteBtn.classList.add('active');
        detailFavoriteBtn.innerHTML = '<i class="fas fa-star"></i> <span>' + t.remove_from_favorites + '</span>';
    } else {
        detailFavoriteBtn.classList.remove('active');
        detailFavoriteBtn.innerHTML = '<i class="far fa-star"></i> <span>' + t.add_to_favorites + '</span>';
    }
}

function toggleFavorite(event, serviceId) {
    event.stopPropagation();
    
    const isFavorite = favoriteServiceIds.includes(parseInt(serviceId));
    const action = isFavorite ? 'remove_favorite' : 'add_favorite';
    
    const btn = event.currentTarget;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    
    const formData = new FormData();
    formData.append('action', action);
    formData.append('service_id', serviceId);
    
    fetch('/kullanici/new-order.php', {
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            if (data.action === 'added') {
                favoriteServiceIds.push(parseInt(serviceId));
            } else {
                const idx = favoriteServiceIds.indexOf(parseInt(serviceId));
                if (idx > -1) favoriteServiceIds.splice(idx, 1);
            }
            
            // Listeyi yeniden render et
            if (selectedCategory) {
                renderServices(selectedCategory);
            }
            
            // Eğer bu servis seçiliyse detay butonunu da güncelle
            if (selectedService && selectedService.id == serviceId) {
                updateDetailFavoriteBtn(!isFavorite);
            }
        }
    })
    .catch(error => {
        console.error('Favori işlemi hatası:', error);
    })
    .finally(() => {
        btn.disabled = false;
    });
}

function toggleDetailFavorite() {
    if (!selectedService) return;
    
    const isFavorite = favoriteServiceIds.includes(parseInt(selectedService.id));
    const action = isFavorite ? 'remove_favorite' : 'add_favorite';
    
    detailFavoriteBtn.disabled = true;
    detailFavoriteBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    
    const formData = new FormData();
    formData.append('action', action);
    formData.append('service_id', selectedService.id);
    
    fetch('/kullanici/new-order.php', {
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            if (data.action === 'added') {
                favoriteServiceIds.push(parseInt(selectedService.id));
            } else {
                const idx = favoriteServiceIds.indexOf(parseInt(selectedService.id));
                if (idx > -1) favoriteServiceIds.splice(idx, 1);
            }
            
            updateDetailFavoriteBtn(!isFavorite);
            
            // Listeyi yeniden render et
            if (selectedCategory) {
                renderServices(selectedCategory);
            }
        }
    })
    .catch(error => {
        console.error('Favori işlemi hatası:', error);
    })
    .finally(() => {
        detailFavoriteBtn.disabled = false;
        updateDetailFavoriteBtn(favoriteServiceIds.includes(parseInt(selectedService.id)));
    });
}

function resetDripfeed() {
    dfSection.classList.remove('show');
    dfToggle.checked = false;
    dfToggleWrapper.classList.remove('active');
    dfFields.classList.remove('show');
    runsInput.value = '';
    intervalInput.value = '';
}

function toggleDripfeed() {
    dfToggle.checked = !dfToggle.checked;
    updateDripfeedUI();
}

function updateDripfeedUI() {
    if (dfToggle.checked) {
        dfToggleWrapper.classList.add('active');
        dfFields.classList.add('show');
    } else {
        dfToggleWrapper.classList.remove('active');
        dfFields.classList.remove('show');
    }
    updateSummary();
}

dfToggle.addEventListener('change', updateDripfeedUI);
runsInput.addEventListener('input', updateSummary);
intervalInput.addEventListener('input', updateSummary);

document.getElementById('serviceSearch').addEventListener('input', function() {
    if (selectedCategory) {
        renderServices(selectedCategory);
    }
});

document.getElementById('quantityInput').addEventListener('input', updateSummary);

function getTierRate(service, quantity) {
    if (!service) return 0;
    let base = parseFloat(service.price_per_1000) || 0;
    const tiers = Array.isArray(service.price_tiers) ? service.price_tiers : [];
    let chosen = null;
    tiers.forEach(tier => {
        const min = parseInt(tier.min_quantity || 0);
        const max = parseInt(tier.max_quantity || 0);
        if (quantity >= min && (max <= 0 || quantity <= max)) {
            if (!chosen || min >= parseInt(chosen.min_quantity || 0)) chosen = tier;
        }
    });
    if (!chosen) return base;
    let rate = base;
    if (chosen.pricing_type === 'discount_percent') rate = Math.max(0, base * (1 - (parseFloat(chosen.pricing_value)||0)/100));
    else if (chosen.pricing_type === 'fixed_per_1000') rate = Math.max(0, parseFloat(chosen.pricing_value)||0);
    return Math.max(rate, parseFloat(service.min_sale_price||0));
}

function updateSummary() {
    let quantity = parseInt(document.getElementById('quantityInput').value) || 0;
    const isDrip = dfToggle.checked;
    let runs = isDrip ? (parseInt(runsInput.value) || 0) : 1;
    const totalQty = isDrip ? quantity * runs : quantity;
    
    document.getElementById('dfTotalQty').textContent = totalQty.toLocaleString();
    
    if (selectedService) {
        const name = selectedService.name.length > 25 
            ? selectedService.name.substring(0, 25) + '...' 
            : selectedService.name;
        document.getElementById('summaryService').textContent = name;
        const liveRate = getTierRate(selectedService, totalQty);
        document.getElementById('summaryUnitPrice').textContent = currencySymbol + liveRate.toFixed(2) + '/1K';
    } else {
        document.getElementById('summaryService').textContent = '-';
        document.getElementById('summaryUnitPrice').textContent = '-';
    }
    
    document.getElementById('summaryQuantity').textContent = totalQty > 0 ? totalQty.toLocaleString() : '-';
    
    if (selectedService && quantity > 0) {
        const liveRate = getTierRate(selectedService, totalQty);
        const total = (totalQty / 1000) * liveRate;
        document.getElementById('summaryTotal').textContent = currencySymbol + total.toFixed(2);
        
        let valid = true;
        
        if (total > userBalance) {
            document.getElementById('balanceWarning').classList.add('active');
            valid = false;
        } else {
            document.getElementById('balanceWarning').classList.remove('active');
        }
        
        if (quantity < selectedService.min_quantity || quantity > selectedService.max_quantity) {
            valid = false;
        }
        
        if (isDrip && runs < 2) {
            valid = false;
        }
        
        document.getElementById('submitBtn').disabled = !valid;
    } else {
        document.getElementById('summaryTotal').textContent = currencySymbol + '0.00';
        document.getElementById('submitBtn').disabled = true;
    }
}

function updateSteps(activeStep) {
    for (let i = 1; i <= 3; i++) {
        const step = document.getElementById('step' + i);
        step.classList.remove('active', 'completed');
        if (i < activeStep) step.classList.add('completed');
        else if (i === activeStep) step.classList.add('active');
    }
}

document.getElementById('orderForm').addEventListener('submit', function(e) {
    if (!selectedService) {
        e.preventDefault();
        alert(t.please_select_service);
        return;
    }
    
    const quantity = parseInt(document.getElementById('quantityInput').value);
    const link = document.getElementById('linkInput').value.trim();
    
    if (!link) {
        e.preventDefault();
        alert(t.please_enter_link);
        return;
    }
    
    if (quantity < selectedService.min_quantity) {
        e.preventDefault();
        alert(t.minimum_quantity + ': ' + selectedService.min_quantity.toLocaleString());
        return;
    }
    
    if (quantity > selectedService.max_quantity) {
        e.preventDefault();
        alert(t.maximum_quantity + ': ' + selectedService.max_quantity.toLocaleString());
        return;
    }
    
    // Dripfeed kontrolü
    const isDrip = dfToggle.checked;
    let runs = 1;
    if (isDrip) {
        runs = parseInt(runsInput.value) || 0;
        const interval = parseInt(intervalInput.value) || 0;
        if (runs < 2) {
            e.preventDefault();
            alert('Runs en az 2 olmalı');
            return;
        }
        if (interval < 1) {
            e.preventDefault();
            alert('Geçerli interval girin');
            return;
        }
    }
    
    const finalQty = isDrip ? quantity * runs : quantity;
    const total = (finalQty / 1000) * getTierRate(selectedService, finalQty);
    
    if (total > userBalance) {
        e.preventDefault();
        alert(t.insufficient_balance + '!');
        return;
    }
    
    setTimeout(function() {
        document.getElementById('submitBtn').disabled = true;
        document.getElementById('submitBtn').innerHTML = '<i class="fas fa-spinner fa-spin"></i> ' + t.processing + '...';
    }, 10);
});

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text || '';
    return div.innerHTML;
}
</script>

<?php require_once 'footer.php'; ?>