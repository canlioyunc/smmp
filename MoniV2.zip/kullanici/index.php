<?php
/**
 * Kullanıcı Paneli - Ana Sayfa & Hızlı Sipariş (Dripfeed + Refill + Favori Destekli)
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';

// Kullanıcı giriş kontrolü
if (!isset($_SESSION['user_id'])) {
    header('Location: /login.php');
    exit;
}

$userId = $_SESSION['user_id'];

// ==================== FAVORİ İŞLEMLERİ ====================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    
    // Favoriye ekle
    if ($_POST['action'] === 'add_favorite' && isset($_POST['service_id'])) {
        $serviceId = (int)$_POST['service_id'];
        
        // Servis var mı kontrol et
        $checkService = $db->prepare("SELECT id FROM services WHERE id = ? AND status = 'active'");
        $checkService->execute([$serviceId]);
        
        if ($checkService->fetch()) {
            // Zaten favoride mi kontrol et
            $checkFav = $db->prepare("SELECT id FROM user_favorites WHERE user_id = ? AND service_id = ?");
            $checkFav->execute([$userId, $serviceId]);
            
            if (!$checkFav->fetch()) {
                $stmt = $db->prepare("INSERT INTO user_favorites (user_id, service_id) VALUES (?, ?)");
                $stmt->execute([$userId, $serviceId]);
            }
        }
        
        // AJAX isteği ise JSON döndür
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'action' => 'added']);
            exit;
        }
        
        header('Location: /kullanici/');
        exit;
    }
    
    // Favoriden kaldır
    if ($_POST['action'] === 'remove_favorite' && isset($_POST['service_id'])) {
        $serviceId = (int)$_POST['service_id'];
        
        $stmt = $db->prepare("DELETE FROM user_favorites WHERE user_id = ? AND service_id = ?");
        $stmt->execute([$userId, $serviceId]);
        
        // AJAX isteği ise JSON döndür
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'action' => 'removed']);
            exit;
        }
        
        header('Location: /kullanici/');
        exit;
    }
}

// STORY DUYURULARINI AL (Yeni sistem - veritabanı yapınıza uygun)
$storyAnnouncements = $db->query("
    SELECT id, title, body, icon, media_type, media_url, link_url, button_text, button_color
    FROM announcements
    WHERE is_active = 1 
    AND (expires_at IS NULL OR expires_at > NOW())
    ORDER BY display_order ASC, created_at DESC
    LIMIT 10
")->fetchAll(PDO::FETCH_ASSOC);
// Eski kayıtlarda dahi story verisini DOM'a göndermeden önce allowlist ile sınırla.
foreach ($storyAnnouncements as &$storySafe) {
    $icon = trim((string)($storySafe['icon'] ?? ''));
    $storySafe['icon'] = preg_match('/^(?:fas|far|fab|fal|fad|fa-solid|fa-regular|fa-brands)(?:\s+fa-[a-z0-9-]+)+$/i', $icon) ? $icon : 'fas fa-bullhorn';
    $mediaType = strtolower(trim((string)($storySafe['media_type'] ?? 'none')));
    $storySafe['media_type'] = in_array($mediaType, ['none','image','video'], true) ? $mediaType : 'none';
    $mediaUrl = trim((string)($storySafe['media_url'] ?? ''));
    $mediaOk = $mediaUrl === '' || preg_match('#^/uploads/story/[A-Za-z0-9._/-]+$#', $mediaUrl) || (filter_var($mediaUrl, FILTER_VALIDATE_URL) && in_array(strtolower((string)parse_url($mediaUrl, PHP_URL_SCHEME)), ['http','https'], true));
    if (!$mediaOk) { $storySafe['media_url'] = null; $storySafe['media_type'] = 'none'; }
    $linkUrl = trim((string)($storySafe['link_url'] ?? ''));
    if ($linkUrl !== '' && !(filter_var($linkUrl, FILTER_VALIDATE_URL) && in_array(strtolower((string)parse_url($linkUrl, PHP_URL_SCHEME)), ['http','https'], true))) $storySafe['link_url'] = null;
    $color = strtolower(trim((string)($storySafe['button_color'] ?? 'primary')));
    $storySafe['button_color'] = in_array($color, ['primary','secondary','success','danger','warning','info','dark','light'], true) ? $color : 'primary';
}
unset($storySafe);

// Kullanıcının favori servis ID'lerini al
$favoriteStmt = $db->prepare("SELECT service_id FROM user_favorites WHERE user_id = ?");
$favoriteStmt->execute([$userId]);
$favoriteServiceIds = $favoriteStmt->fetchAll(PDO::FETCH_COLUMN);

// Kategorileri getir
$categories = $db->query("
    SELECT c.*, COUNT(s.id) as service_count 
    FROM categories c 
    LEFT JOIN services s ON c.id = s.category_id AND s.status = 'active'
    WHERE c.status = 'active' 
    GROUP BY c.id 
    HAVING service_count > 0
    ORDER BY c.sort_order ASC
")->fetchAll();

// Tüm aktif servisleri getir (dripfeed + refill bilgileri dahil)
$services = $db->query("
    SELECT s.id, s.category_id, s.name, s.description, s.price_per_1000, 
           s.min_quantity, s.max_quantity, s.refill, s.refill_days, s.refill_count,
           s.api_provider_id, s.api_service_id, s.dripfeed, s.geo_supported, s.geo_targets_json,
           c.name as category_name, c.icon as category_icon
    FROM services s
    LEFT JOIN categories c ON s.category_id = c.id
    WHERE s.status = 'active' AND s.deleted_at IS NULL
    ORDER BY c.sort_order, s.sort_order, s.name
")->fetchAll();

// Favori servisleri al (ayrı sorgu)
$favoriteServices = [];
if (!empty($favoriteServiceIds)) {
    $placeholders = implode(',', array_fill(0, count($favoriteServiceIds), '?'));
    $favStmt = $db->prepare("
        SELECT s.id, s.category_id, s.name, s.description, s.price_per_1000, 
               s.min_quantity, s.max_quantity, s.refill, s.refill_days, s.refill_count,
               s.api_provider_id, s.api_service_id, s.dripfeed, s.geo_supported, s.geo_targets_json,
               c.name as category_name, c.icon as category_icon
        FROM services s
        LEFT JOIN categories c ON s.category_id = c.id
        WHERE s.id IN ($placeholders) AND s.status = 'active' AND s.deleted_at IS NULL
        ORDER BY s.name
    ");
    $favStmt->execute($favoriteServiceIds);
    $favoriteServices = $favStmt->fetchAll();
}

// Çok dilli açıklama + kullanıcı davranışına göre kişiselleştirilmiş servis sıralaması.
if (function_exists('moni_localize_service_rows')) {
    $services = moni_localize_service_rows($db,$services);
    $favoriteServices = moni_localize_service_rows($db,$favoriteServices);
}
if (function_exists('moni_personalize_service_rows')) $services = moni_personalize_service_rows($db,(int)$userId,$services);

// Müşteri grubu görünürlük politikasını listeleme aşamasında da uygula.
if (function_exists('moni_service_visible_to_user')) {
    $services = array_values(array_filter($services, static function($x) use ($db,$userId){ return moni_service_visible_to_user($db,(int)$x['id'],(int)$userId); }));
    $favoriteServices = array_values(array_filter($favoriteServices, static function($x) use ($db,$userId){ return moni_service_visible_to_user($db,(int)$x['id'],(int)$userId); }));
}

// Kişiye/bayiye özel fiyat + minimum kâr politikası, ekranda tahsilatla birebir aynı olsun.
$ratingIds=array_merge(array_column($services,'id'),array_column($favoriteServices,'id'));
$serviceRatings=function_exists('moni_service_ratings')?moni_service_ratings($db,$ratingIds):[];
foreach ($services as &$svc) {
    $svc['price_per_1000'] = moni_effective_price_per_1000($svc, (int)$userId);
    $svc['price_tiers'] = function_exists('moni_service_price_tiers') ? moni_service_price_tiers($db, (int)$svc['id'], true) : [];
    $svc['min_sale_price'] = function_exists('moni_minimum_sale_price') ? moni_minimum_sale_price($svc) : 0;
    $svc['maintenance_reason'] = moni_maintenance_reason((int)$svc['id'], (int)($svc['api_provider_id'] ?? 0));
    $r=$serviceRatings[(int)$svc['id']]??['avg'=>0.0,'count'=>0];$svc['rating_avg']=$r['avg'];$svc['rating_count']=$r['count'];
}
unset($svc);
foreach ($favoriteServices as &$svc) {
    $svc['price_per_1000'] = moni_effective_price_per_1000($svc, (int)$userId);
    $svc['price_tiers'] = function_exists('moni_service_price_tiers') ? moni_service_price_tiers($db, (int)$svc['id'], true) : [];
    $svc['min_sale_price'] = function_exists('moni_minimum_sale_price') ? moni_minimum_sale_price($svc) : 0;
    $svc['maintenance_reason'] = moni_maintenance_reason((int)$svc['id'], (int)($svc['api_provider_id'] ?? 0));
    $r=$serviceRatings[(int)$svc['id']]??['avg'=>0.0,'count'=>0];$svc['rating_avg']=$r['avg'];$svc['rating_count']=$r['count'];
}
unset($svc);
if(function_exists('moni_service_capacity_attach')){moni_service_capacity_attach($db,$services);moni_service_capacity_attach($db,$favoriteServices);}
if(function_exists('moni_service_auto_badges_attach')){moni_service_auto_badges_attach($db,$services);moni_service_auto_badges_attach($db,$favoriteServices);}
if(function_exists('moni_service_tags_attach')){moni_service_tags_attach($db,$services);moni_service_tags_attach($db,$favoriteServices);}
if(function_exists('moni_service_schedule_attach')){moni_service_schedule_attach($db,$services);moni_service_schedule_attach($db,$favoriteServices);}
if(function_exists('moni_plugin_enabled')&&moni_plugin_enabled('real_delivery_eta',$db)&&function_exists('moni_service_delivery_estimate')){
    foreach($services as &$svc){$eta=moni_service_delivery_estimate($db,(int)$svc['id']);$svc['delivery_eta']=!empty($eta['available'])?(string)$eta['label']:'';}unset($svc);
    foreach($favoriteServices as &$svc){$eta=moni_service_delivery_estimate($db,(int)$svc['id']);$svc['delivery_eta']=!empty($eta['available'])?(string)$eta['label']:'';}unset($svc);
}

// Kullanıcı istatistikleri (iptal/iade/hata siparişleri toplam harcamadan hariç)
$userStats = $db->prepare("
    SELECT 
        COUNT(*) as total_orders,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
        SUM(CASE WHEN status IN ('pending', 'processing', 'in_progress') THEN 1 ELSE 0 END) as active_orders,
        SUM(CASE WHEN status NOT IN ('cancelled', 'canceled', 'refunded', 'error') THEN price ELSE 0 END) as total_spent
    FROM orders WHERE user_id = ?
");
$userStats->execute([$userId]);
$userStats = $userStats->fetch();

// Son siparişler (dripfeed bilgisi dahil)
$recentOrders = $db->prepare("
    SELECT o.*, s.name as service_name, c.icon as category_icon,
           df.runs as dripfeed_total_runs
    FROM orders o
    LEFT JOIN services s ON o.service_id = s.id
    LEFT JOIN categories c ON s.category_id = c.id
    LEFT JOIN orders_dripfeed df ON o.dripfeed_id = df.id
    WHERE o.user_id = ?
    ORDER BY o.created_at DESC
    LIMIT 5
");
$recentOrders->execute([$userId]);
$recentOrders = $recentOrders->fetchAll();

// Dripfeed siparişleri için part numaralarını hesapla
$dripfeedIds = [];
foreach ($recentOrders as $order) {
    if (!empty($order['dripfeed_id']) && $order['dripfeed_id'] > 0) {
        $dripfeedIds[$order['dripfeed_id']] = true;
    }
}

$dripfeedPartNumbers = [];
if (!empty($dripfeedIds)) {
    $dfIdList = implode(',', array_keys($dripfeedIds));
    $partStmt = $db->query("
        SELECT id, dripfeed_id, 
               ROW_NUMBER() OVER (PARTITION BY dripfeed_id ORDER BY id ASC) as part_number
        FROM orders 
        WHERE dripfeed_id IN ($dfIdList)
        ORDER BY dripfeed_id, id
    ");
    foreach ($partStmt->fetchAll() as $row) {
        $dripfeedPartNumbers[$row['id']] = $row['part_number'];
    }
}

// Sipariş işlemi
$orderSuccess = '';
$orderError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'place_order') {
    $result = moni_place_order($db, (int)$userId, (int)($_POST['service_id'] ?? 0), trim((string)($_POST['link'] ?? '')), (int)($_POST['quantity'] ?? 0), [
        'dripfeed' => isset($_POST['dripfeed_enabled']) && $_POST['dripfeed_enabled'] === '1',
        'runs' => (int)($_POST['dripfeed_runs'] ?? 1),
        'interval' => (int)($_POST['dripfeed_interval'] ?? 60),
        'idempotency_key' => (string)($_POST['idempotency_key'] ?? ''),
        'source' => 'web-dashboard',
        'geo_target' => (string)($_POST['geo_target'] ?? '')
    ]);
    if (!empty($result['success'])) {
        $_SESSION['balance'] = (float)$db->query("SELECT balance FROM users WHERE id=".(int)$userId)->fetchColumn();
        $msg = $result['message'] ?? __('order_success');
        if (!empty($result['warning'])) $msg .= ' | ' . $result['warning'];
        header('Location: /kullanici/orders.php?success=' . urlencode($msg)); exit;
    }
    $orderError = $result['error'] ?? __('order_error');
}

$pageTitle = __('dashboard');
require_once 'header.php';
?>
<style>
/* ==================== FAVORİ SİSTEMİ STİLLERİ ==================== */
.favorite-btn {
    position: absolute;
    top: 8px;
    right: 8px;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    border: none;
    background: rgba(255, 255, 255, 0.1);
    color: rgba(255, 255, 255, 0.5);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.9rem;
    transition: all 0.3s ease;
    z-index: 10;
}

.favorite-btn:hover {
    background: rgba(255, 193, 7, 0.2);
    color: var(--warning-color);
    transform: scale(1.1);
}

.favorite-btn.active {
    background: rgba(255, 193, 7, 0.2);
    color: var(--warning-color);
}

.favorite-btn.active i {
    animation: heartBeat 0.3s ease;
}

@keyframes heartBeat {
    0% { transform: scale(1); }
    50% { transform: scale(1.3); }
    100% { transform: scale(1); }
}

.service-option-wrapper {
    position: relative;
    display: flex;
    align-items: center;
    gap: 10px;
}

.favorite-indicator {
    color: var(--warning-color);
    font-size: 0.8rem;
}

/* Favori kategori badge */
.favorite-category-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 3px 10px;
    background: linear-gradient(135deg, rgba(255, 193, 7, 0.2), rgba(255, 152, 0, 0.2));
    border: 1px solid rgba(255, 193, 7, 0.3);
    border-radius: 20px;
    font-size: 0.75rem;
    color: var(--warning-color);
    margin-left: 8px;
}

/* Select içinde favori servisleri vurgula */
select.form-control option.favorite-option {
    background: linear-gradient(90deg, rgba(255, 193, 7, 0.1), transparent);
    font-weight: 600;
}

/* Servis info içinde favori butonu */
.service-info-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 10px;
}

.service-info-header h4 {
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.service-favorite-btn {
    padding: 8px 15px;
    border-radius: 8px;
    border: none;
    font-size: 0.8rem;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 6px;
    transition: all 0.3s ease;
}

.service-favorite-btn.add {
    background: rgba(255, 193, 7, 0.15);
    color: var(--warning-color);
}

.service-favorite-btn.add:hover {
    background: rgba(255, 193, 7, 0.25);
}

.service-favorite-btn.remove {
    background: var(--danger-soft-bg);
    color: var(--danger-color);
}

.service-favorite-btn.remove:hover {
    background: rgba(220, 53, 69, 0.25);
}

/* ==================== STORY DUYURU SİSTEMİ ==================== */
.stories-container {
    margin-bottom: 25px;
}

.stories-wrapper {
    display: flex;
    gap: 15px;
    overflow-x: auto;
    padding: 10px 5px;
    scrollbar-width: none;
    -ms-overflow-style: none;
}

.stories-wrapper::-webkit-scrollbar {
    display: none;
}

.story-item {
    flex-shrink: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    cursor: pointer;
    transition: transform 0.3s ease;
}

.story-item:hover {
    transform: scale(1.05);
}

.story-ring {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    padding: 3px;
    background: linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888);
    margin-bottom: 8px;
    position: relative;
}

.story-ring.no-media {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
}

.story-ring.has-video {
    background: linear-gradient(45deg, #405de6, #5851db, #833ab4, #c13584, #e1306c, #fd1d1d);
}

.story-avatar {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    background: var(--card-bg-color);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.8rem;
    color: var(--accent-text-color);
    border: 3px solid var(--background-color);
    overflow: hidden;
}

.story-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.story-avatar video {
    width: 100%;
    height: 100%;
    object-fit: cover;
    pointer-events: none;
}

.story-video-badge {
    position: absolute;
    bottom: -2px;
    right: -2px;
    width: 24px;
    height: 24px;
    background: linear-gradient(135deg, #e1306c, #fd1d1d);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-size: 0.5rem;
    border: 2px solid var(--background-color);
    z-index: 5;
}

.story-title {
    font-size: 0.75rem;
    font-weight: 500;
    max-width: 80px;
    text-align: center;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    opacity: 0.9;
}

/* Story Modal */
.story-modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.95);
    z-index: 10000;
    justify-content: center;
    align-items: center;
}

.story-modal-overlay.active {
    display: flex;
}

.story-modal {
    position: relative;
    width: 100%;
    max-width: 420px;
    height: 90vh;
    max-height: 750px;
    background: var(--card-bg-color);
    border-radius: 16px;
    overflow: hidden;
    display: flex;
    flex-direction: column;
}

@media (max-width: 500px) {
    .story-modal {
        max-width: 100%;
        height: 100vh;
        max-height: 100vh;
        border-radius: 0;
    }
}

.story-progress-container {
    display: flex;
    gap: 4px;
    padding: 12px 12px 8px;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    z-index: 10;
}

.story-progress-bar {
    flex: 1;
    height: 3px;
    background: rgba(255, 255, 255, 0.3);
    border-radius: 3px;
    overflow: hidden;
}

.story-progress-bar .progress {
    height: 100%;
    background: #fff;
    border-radius: 3px;
    width: 0%;
    transition: width 0.1s linear;
}

.story-progress-bar.completed .progress {
    width: 100%;
}

.story-progress-bar.active .progress {
    width: 0%;
}

.story-header {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 45px 15px 15px;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    z-index: 5;
    background: linear-gradient(to bottom, rgba(0,0,0,0.5) 0%, transparent 100%);
}

.story-header-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: var(--primary-color);
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--on-primary-color);
    font-size: 1rem;
    flex-shrink: 0;
}

.story-header-info {
    flex: 1;
}

.story-header-info h4 {
    color: #fff;
    font-size: 0.95rem;
    font-weight: 600;
    margin: 0;
}

.story-header-info span {
    color: rgba(255,255,255,0.7);
    font-size: 0.75rem;
}

.story-close-btn {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: rgba(255,255,255,0.2);
    border: none;
    color: #fff;
    font-size: 1.2rem;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background 0.3s ease;
}

.story-close-btn:hover {
    background: rgba(255,255,255,0.3);
}

.story-content {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 80px 25px 120px;
    text-align: center;
    position: relative;
    overflow: hidden;
}

.story-content.has-media {
    justify-content: flex-end;
    padding-bottom: 140px;
}

.story-media {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 0;
}

.story-media img,
.story-media video {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.story-media-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(to bottom, rgba(0,0,0,0.3) 0%, rgba(0,0,0,0.1) 40%, rgba(0,0,0,0.7) 100%);
}

.story-loading {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 2;
}

.story-spinner {
    width: 40px;
    height: 40px;
    border: 3px solid rgba(255,255,255,0.2);
    border-top-color: #fff;
    border-radius: 50%;
    animation: storySpin 0.8s linear infinite;
}

@keyframes storySpin {
    to { transform: rotate(360deg); }
}

.story-icon {
    width: 90px;
    height: 90px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2.5rem;
    color: var(--on-accent-color);
    margin-bottom: 25px;
    box-shadow: 0 10px 40px var(--primary-alpha-04);
}

.story-text {
    position: relative;
    z-index: 1;
}

.story-text h2 {
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 15px;
    color: #fff;
    text-shadow: 0 2px 10px rgba(0,0,0,0.3);
}

.story-text p {
    font-size: 1rem;
    line-height: 1.6;
    color: rgba(255,255,255,0.9);
    max-width: 320px;
    margin: 0 auto;
    text-shadow: 0 1px 5px rgba(0,0,0,0.3);
}

.story-footer {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 20px;
    z-index: 5;
    background: linear-gradient(to top, rgba(0,0,0,0.7) 0%, transparent 100%);
}

.story-cta-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    width: 100%;
    padding: 15px 25px;
    border-radius: 12px;
    font-size: 1rem;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
    border: none;
    cursor: pointer;
}

.story-cta-btn.btn-primary { background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: var(--on-accent-color); }
.story-cta-btn.btn-success { background: linear-gradient(135deg, var(--success-color), #20c997); color: #fff; }
.story-cta-btn.btn-danger { background: linear-gradient(135deg, var(--danger-color), var(--danger-color)); color: #fff; }
.story-cta-btn.btn-warning { background: linear-gradient(135deg, var(--warning-color), #fd7e14); color: #000; }
.story-cta-btn.btn-info { background: linear-gradient(135deg, var(--info-color), var(--info-color)); color: #fff; }

.story-cta-btn:hover {
    transform: scale(1.02);
    box-shadow: 0 5px 25px rgba(0,0,0,0.3);
}

.story-nav {
    position: absolute;
    top: 80px;
    bottom: 120px;
    width: 35%;
    z-index: 3;
    cursor: pointer;
}

.story-nav.prev { left: 0; }
.story-nav.next { right: 0; }

@media (max-width: 576px) {
    .story-ring { width: 70px; height: 70px; }
    .story-avatar { font-size: 1.5rem; }
    .story-title { font-size: 0.7rem; max-width: 70px; }
    .stories-wrapper { gap: 12px; padding: 8px 3px; }
    .story-icon { width: 70px; height: 70px; font-size: 2rem; }
    .story-text h2 { font-size: 1.3rem; }
    .story-text p { font-size: 0.9rem; }
    .story-video-badge { width: 20px; height: 20px; font-size: 0.45rem; }
}

/* ==================== MEVCUT STİLLER ==================== */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
    margin-bottom: 25px;
}

@media (max-width: 1200px) {
    .stats-grid { grid-template-columns: repeat(2, 1fr); }
}

@media (max-width: 576px) {
    .stats-grid { grid-template-columns: 1fr; gap: 12px; }
}

.stat-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 15px;
}

@media (max-width: 576px) {
    .stat-card { padding: 15px; border-radius: 12px; }
}

.stat-icon {
    width: 55px;
    height: 55px;
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
    flex-shrink: 0;
}

@media (max-width: 576px) {
    .stat-icon { width: 48px; height: 48px; font-size: 1.1rem; border-radius: 12px; }
}

.stat-icon.balance { background: var(--success-soft-bg); color: var(--success-color); }
.stat-icon.orders { background: var(--primary-alpha-015); color: var(--accent-text-color); }
.stat-icon.active { background: var(--info-soft-bg); color: var(--info-color); }
.stat-icon.spent { background: rgba(253, 126, 20, 0.15); color: #fd7e14; }

.stat-info h3 {
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 4px;
    word-break: break-word;
}

@media (max-width: 576px) {
    .stat-info h3 { font-size: 1.25rem; }
}

.stat-info p {
    opacity: 0.6;
    font-size: 0.85rem;
}

.order-section {
    display: grid;
    grid-template-columns: 1fr 380px;
    gap: 25px;
}

@media (max-width: 1100px) {
    .order-section { grid-template-columns: 1fr; }
}

.card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    overflow: hidden;
}

@media (max-width: 576px) {
    .card { border-radius: 12px; }
}

.card-header {
    padding: 20px;
    border-bottom: 1px solid var(--border-color);
}

@media (max-width: 576px) {
    .card-header { padding: 15px; }
    .card-header h2 { font-size: 1rem; }
}

.card-body { padding: 20px; }

@media (max-width: 576px) {
    .card-body { padding: 15px; }
}

.form-group { margin-bottom: 20px; }

@media (max-width: 576px) {
    .form-group { margin-bottom: 15px; }
}

.form-label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    font-size: 0.9rem;
}

.form-control {
    width: 100%;
    padding: 12px 16px;
    border: 2px solid var(--border-color);
    border-radius: 10px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 0.95rem;
    transition: all 0.3s ease;
}

@media (max-width: 576px) {
    .form-control { padding: 10px 14px; font-size: 16px; }
}

.form-control:focus {
    outline: none;
    border-color: var(--accent-text-color);
    box-shadow: 0 0 0 4px var(--primary-alpha-01);
}

select.form-control {
    cursor: pointer;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%236c757d' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14L2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 12px center;
    padding-right: 40px;
}

.service-info {
    background: var(--background-color);
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 20px;
    display: none;
}

.service-info.active {
    display: block;
    animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

.service-info h4 {
    font-size: 1rem;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.service-info h4 i { color: var(--accent-text-color); }

.service-description {
    font-size: 0.85rem;
    opacity: 0.7;
    margin-bottom: 15px;
    padding: 10px;
    background: var(--card-bg-color);
    border-radius: 8px;
    line-height: 1.6;
}

.service-details {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 12px;
}

@media (max-width: 400px) {
    .service-details { grid-template-columns: 1fr; gap: 8px; }
}

.service-detail {
    padding: 12px;
    background: var(--card-bg-color);
    border-radius: 8px;
}

.service-detail label {
    display: block;
    font-size: 0.75rem;
    opacity: 0.6;
    margin-bottom: 4px;
}

.service-detail span { font-weight: 600; font-size: 0.95rem; }
.service-detail span.price { color: var(--success-color); }

.service-features {
    display: flex;
    gap: 10px;
    margin-top: 12px;
    flex-wrap: wrap;
}

.feature-badge {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
}

.feature-badge.refill { background: var(--success-soft-bg); color: var(--success-color); }
.feature-badge.api { background: var(--primary-alpha-015); color: var(--accent-text-color); }
.feature-badge.dripfeed { background: rgba(0, 123, 255, 0.15); color: var(--info-color); }

.dripfeed-section {
    background: linear-gradient(135deg, rgba(0, 123, 255, 0.08) 0%, rgba(0, 123, 255, 0.03) 100%);
    border: 1px solid rgba(0, 123, 255, 0.2);
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 20px;
    display: none;
}

.dripfeed-section.active {
    display: block;
    animation: fadeIn 0.3s ease;
}

.dripfeed-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 15px;
}

.dripfeed-header h4 {
    font-size: 0.95rem;
    color: var(--info-color);
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 0;
}

.dripfeed-toggle {
    display: flex;
    align-items: center;
    gap: 10px;
}

.dripfeed-toggle label { font-size: 0.85rem; cursor: pointer; }

.toggle-switch {
    position: relative;
    width: 50px;
    height: 26px;
}

.toggle-switch input { opacity: 0; width: 0; height: 0; }

.toggle-slider {
    position: absolute;
    cursor: pointer;
    top: 0; left: 0; right: 0; bottom: 0;
    background-color: var(--border-color);
    transition: 0.3s;
    border-radius: 26px;
}

.toggle-slider:before {
    position: absolute;
    content: "";
    height: 20px;
    width: 20px;
    left: 3px;
    bottom: 3px;
    background-color: #fff;
    transition: 0.3s;
    border-radius: 50%;
}

.toggle-switch input:checked + .toggle-slider { background-color: var(--info-color); }
.toggle-switch input:checked + .toggle-slider:before { transform: translateX(24px); }

.dripfeed-options {
    display: none;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
    margin-top: 15px;
}

.dripfeed-options.active { display: grid; }

@media (max-width: 500px) {
    .dripfeed-options { grid-template-columns: 1fr; }
}

.dripfeed-options .form-group { margin-bottom: 0; }
.dripfeed-options .form-label { font-size: 0.85rem; margin-bottom: 6px; }

.dripfeed-info {
    background: rgba(0, 123, 255, 0.1);
    border-radius: 8px;
    padding: 12px;
    margin-top: 15px;
    font-size: 0.8rem;
    color: var(--info-color);
}

.dripfeed-info i { margin-right: 6px; }

.total-box {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 12px;
    padding: 20px;
    color: var(--on-accent-color);
    text-align: center;
    margin-bottom: 20px;
}

.total-box label { display: block; font-size: 0.9rem; opacity: 0.9; margin-bottom: 5px; }
.total-box .total-price { font-size: 2rem; font-weight: 700; }
.total-box .total-info { font-size: 0.8rem; opacity: 0.8; margin-top: 5px; }

.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px 24px;
    border-radius: 10px;
    font-weight: 600;
    font-size: 0.95rem;
    cursor: pointer;
    transition: all 0.3s ease;
    border: none;
    text-decoration: none;
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--on-accent-color);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 20px var(--primary-alpha-035);
}

.btn-primary:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
}

.orders-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.order-item {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 15px;
    background: var(--background-color);
    border-radius: 12px;
    transition: all 0.3s ease;
}

.order-item:hover { transform: translateX(5px); }

.order-item.dripfeed-order {
    border-left: 3px solid var(--info-color);
    background: linear-gradient(90deg, rgba(0, 123, 255, 0.05) 0%, var(--background-color) 100%);
}

.order-icon {
    width: 42px;
    height: 42px;
    border-radius: 10px;
    background: var(--card-bg-color);
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--accent-text-color);
    font-size: 1rem;
    flex-shrink: 0;
}

.order-details { flex: 1; min-width: 0; }

.order-details h4 {
    font-size: 0.9rem;
    font-weight: 600;
    margin-bottom: 3px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.order-details p { font-size: 0.8rem; opacity: 0.6; }

.order-details .dripfeed-badge-small {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 2px 6px;
    background: rgba(0, 123, 255, 0.15);
    border-radius: 4px;
    font-size: 0.7rem;
    color: var(--info-color);
    font-weight: 600;
    margin-left: 5px;
}

.status-badge {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
    white-space: nowrap;
}

.status-badge.status-pending { background: rgba(255, 193, 7, 0.15); color: var(--warning-color); }
.status-badge.status-processing { background: var(--info-soft-bg); color: var(--info-color); }
.status-badge.status-in_progress { background: rgba(0, 123, 255, 0.15); color: var(--info-color); }
.status-badge.status-completed { background: var(--success-soft-bg); color: var(--success-color); }
.status-badge.status-partial { background: rgba(255, 193, 7, 0.15); color: var(--warning-color); }
.status-badge.status-cancelled { background: var(--danger-soft-bg); color: var(--danger-color); }
.status-badge.status-refunded { background: rgba(108, 117, 125, 0.15); color: var(--muted-text-color); }
.status-badge.status-error { background: var(--danger-soft-bg); color: var(--danger-color); }

.view-all-link {
    display: block;
    text-align: center;
    padding: 15px;
    color: var(--accent-text-color);
    text-decoration: none;
    font-weight: 500;
    border-top: 1px solid var(--border-color);
    transition: all 0.3s ease;
}

.view-all-link:hover { background: var(--background-color); }

.empty-orders {
    text-align: center;
    padding: 40px 20px;
    opacity: 0.6;
}

.empty-orders i {
    font-size: 2.5rem;
    margin-bottom: 15px;
    opacity: 0.4;
    display: block;
}

.alert {
    padding: 15px 20px;
    border-radius: 12px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 0.9rem;
}

.alert-success {
    background: var(--success-soft-bg);
    border: 1px solid rgba(40, 167, 69, 0.3);
    color: var(--success-color);
}

.alert-danger {
    background: var(--danger-soft-bg);
    border: 1px solid rgba(220, 53, 69, 0.3);
    color: var(--danger-color);
}

@media (max-width: 576px) {
    .stat-info p { font-size: 0.8rem; }
    .order-section { gap: 15px; }
    .form-label { font-size: 0.85rem; margin-bottom: 6px; }
    .service-info { padding: 15px; }
    .service-info h4 { font-size: 0.9rem; }
    .service-description { font-size: 0.8rem; }
    .service-detail span { font-size: 0.9rem; }
    .feature-badge { padding: 4px 10px; font-size: 0.7rem; }
    .total-box { padding: 15px; }
    .total-box .total-price { font-size: 1.6rem; }
    .btn { padding: 12px 20px; font-size: 0.9rem; }
    .orders-list { gap: 10px; }
    .order-item { padding: 12px; gap: 12px; flex-wrap: wrap; }
    .order-item:hover { transform: none; }
    .order-icon { width: 38px; height: 38px; font-size: 0.9rem; }
    .order-details h4 { font-size: 0.85rem; white-space: normal; line-height: 1.3; }
    .order-details p { font-size: 0.75rem; }
    .status-badge { padding: 4px 10px; font-size: 0.7rem; margin-left: auto; }
    .view-all-link { padding: 12px; font-size: 0.9rem; }
    .empty-orders { padding: 30px 15px; }
    .empty-orders i { font-size: 2rem; margin-bottom: 10px; }
    .alert { padding: 12px 15px; font-size: 0.85rem; gap: 10px; margin-bottom: 15px; }
    .service-favorite-btn { padding: 6px 12px; font-size: 0.75rem; }
}

.service-rating-value{display:inline-flex;align-items:center;gap:6px;color:var(--muted-text-color);font-weight:700}.service-rating-value.has-rating{color:var(--warning-color)}.service-rating-value small{font-size:.72rem;color:var(--muted-text-color);font-weight:600}.feature-badge.service-rating-badge{background:rgba(245,158,11,.14);color:var(--warning-color);border:1px solid rgba(245,158,11,.22)}.feature-badge.service-rating-empty{background:var(--primary-alpha-01);color:var(--muted-text-color);border:1px solid var(--border-color)}
</style>
<!-- ==================== STORY DUYURU SİSTEMİ ==================== -->
<?php if (!empty($storyAnnouncements)): ?>
<div class="stories-container">
    <div class="stories-wrapper">
        <?php foreach ($storyAnnouncements as $index => $story): 
            $isVideo = $story['media_type'] === 'video';
            $hasMedia = !empty($story['media_url']) && $story['media_type'] !== 'none';
        ?>
            <div class="story-item" onclick="openStory(<?php echo $index; ?>)">
                <div class="story-ring <?php echo !$hasMedia ? 'no-media' : ($isVideo ? 'has-video' : ''); ?>">
                    <div class="story-avatar">
                        <?php if ($story['media_type'] === 'image' && !empty($story['media_url'])): ?>
                            <img src="<?php echo clean($story['media_url']); ?>" alt="<?php echo clean($story['title']); ?>" loading="lazy">
                        <?php elseif ($isVideo && !empty($story['media_url'])): ?>
                            <video muted preload="metadata" src="<?php echo clean($story['media_url']); ?>#t=0.5"></video>
                        <?php else: ?>
                            <i class="<?php echo clean($story['icon'] ?: 'fas fa-bullhorn'); ?>"></i>
                        <?php endif; ?>
                    </div>
                    <?php if ($isVideo): ?>
                        <span class="story-video-badge"><i class="fas fa-play"></i></span>
                    <?php endif; ?>
                </div>
                <span class="story-title"><?php echo clean($story['title']); ?></span>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Story Modal -->
<div class="story-modal-overlay" id="storyModal">
    <div class="story-modal">
        <div class="story-progress-container" id="storyProgressContainer">
            <?php foreach ($storyAnnouncements as $i => $s): ?>
                <div class="story-progress-bar" data-index="<?php echo $i; ?>"><div class="progress"></div></div>
            <?php endforeach; ?>
        </div>
        
        <div class="story-header">
            <div class="story-header-avatar" id="storyHeaderIcon"><i class="fas fa-bullhorn"></i></div>
            <div class="story-header-info">
                <h4 id="storyHeaderTitle">Duyuru</h4>
                <span>Az önce</span>
            </div>
            <button class="story-close-btn" onclick="closeStory()"><i class="fas fa-times"></i></button>
        </div>
        
        <div class="story-content" id="storyContent">
            <div class="story-loading" id="storyLoading" style="display:none;">
                <div class="story-spinner"></div>
            </div>
            <div class="story-media" id="storyMedia" style="display:none;"></div>
            <div class="story-icon" id="storyIcon"><i class="fas fa-bullhorn"></i></div>
            <div class="story-text">
                <h2 id="storyTitle">Başlık</h2>
                <p id="storyBody">İçerik</p>
            </div>
        </div>
        
        <div class="story-footer" id="storyFooter" style="display:none;">
            <a href="#" class="story-cta-btn btn-primary" id="storyCta" target="_blank">
                <span id="storyCtaText">Detaylar</span>
                <i class="fas fa-arrow-right"></i>
            </a>
        </div>
        
        <div class="story-nav prev" onclick="prevStory()"></div>
        <div class="story-nav next" onclick="nextStory()"></div>
    </div>
</div>

<script>
const storiesData = <?php echo json_encode($storyAnnouncements, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
let currentStoryIndex = 0;
let storyTimer = null;
let storyDuration = 5000;
let progressInterval = null;
let currentVideo = null;

function openStory(index) {
    currentStoryIndex = index;
    document.getElementById('storyModal').classList.add('active');
    document.body.style.overflow = 'hidden';
    showStory(index);
}

function closeStory() {
    document.getElementById('storyModal').classList.remove('active');
    document.body.style.overflow = '';
    stopStoryTimer();
    resetProgressBars();
    if (currentVideo) { currentVideo.pause(); currentVideo.src = ''; currentVideo = null; }
}

function stopStoryTimer() { clearTimeout(storyTimer); clearInterval(progressInterval); }

function safeStoryIconClass(raw) {
    const value = String(raw || 'fas fa-bullhorn').trim();
    return /^(?:fas|far|fab|fal|fad|fa-solid|fa-regular|fa-brands)(?:\s+fa-[a-z0-9-]+)+$/i.test(value) ? value : 'fas fa-bullhorn';
}
function renderStoryIcon(container, raw) {
    const i = document.createElement('i');
    i.className = safeStoryIconClass(raw);
    container.replaceChildren(i);
}
function createStoryOverlay() {
    const overlay = document.createElement('div');
    overlay.className = 'story-media-overlay';
    return overlay;
}

function showStory(index) {
    if (index < 0 || index >= storiesData.length) { closeStory(); return; }
    stopStoryTimer();
    currentStoryIndex = index;
    const story = storiesData[index];
    document.getElementById('storyHeaderTitle').textContent = story.title;
    renderStoryIcon(document.getElementById('storyHeaderIcon'), story.icon);
    const mediaContainer = document.getElementById('storyMedia');
    const storyContent = document.getElementById('storyContent');
    const storyIcon = document.getElementById('storyIcon');
    const storyLoading = document.getElementById('storyLoading');
    storyDuration = 5000;
    storyLoading.style.display = 'none';
    mediaContainer.innerHTML = '';
    mediaContainer.style.display = 'none';
    if (currentVideo) { currentVideo.pause(); currentVideo = null; }
    if (story.media_type !== 'none' && story.media_url) {
        mediaContainer.style.display = 'block';
        storyContent.classList.add('has-media');
        storyIcon.style.display = 'none';
        if (story.media_type === 'image') {
            storyLoading.style.display = 'block';
            const img = new Image();
            img.onload = function() {
                storyLoading.style.display = 'none';
                mediaContainer.replaceChildren(img, createStoryOverlay());
                updateProgressBars(index); startProgressAnimation();
            };
            img.onerror = function() { storyLoading.style.display = 'none'; updateProgressBars(index); startProgressAnimation(); };
            img.src = story.media_url;
        } else if (story.media_type === 'video') {
            storyLoading.style.display = 'block';
            const video = document.createElement('video');
            video.setAttribute('playsinline', ''); video.setAttribute('preload', 'auto'); video.muted = true;
            currentVideo = video;
            let metadataLoaded = false;
            video.onloadedmetadata = function() {
                if (metadataLoaded) return; metadataLoaded = true;
                storyLoading.style.display = 'none';
                if (video.duration && isFinite(video.duration) && video.duration > 0) { storyDuration = Math.min(video.duration * 1000, 30000); } else { storyDuration = 10000; }
                video.play().catch(function(e) { console.log('Video play error:', e); });
                updateProgressBars(index); startVideoProgress(video);
            };
            video.oncanplay = function() { storyLoading.style.display = 'none'; };
            video.onerror = function() { storyLoading.style.display = 'none'; storyDuration = 5000; updateProgressBars(index); startProgressAnimation(); };
            video.onended = function() { nextStory(); };
            mediaContainer.replaceChildren(video, createStoryOverlay());
            video.src = story.media_url; video.load();
        }
    } else {
        mediaContainer.style.display = 'none';
        storyContent.classList.remove('has-media');
        storyIcon.style.display = 'flex';
        renderStoryIcon(storyIcon, story.icon);
        updateProgressBars(index); startProgressAnimation();
    }
    document.getElementById('storyTitle').textContent = story.title;
    document.getElementById('storyBody').textContent = story.body;
    const footer = document.getElementById('storyFooter');
    const ctaBtn = document.getElementById('storyCta');
    const ctaText = document.getElementById('storyCtaText');
    if (story.link_url && /^https?:\/\//i.test(story.link_url)) {
        footer.style.display = 'block';
        ctaBtn.href = story.link_url; ctaBtn.rel = 'noopener noreferrer';
        ctaText.textContent = story.button_text || 'Detaylar';
        const allowedColors = ['primary','secondary','success','danger','warning','info','dark','light'];
        const btnColor = allowedColors.includes(String(story.button_color || '').toLowerCase()) ? String(story.button_color).toLowerCase() : 'primary';
        ctaBtn.className = 'story-cta-btn btn-' + btnColor;
    } else { footer.style.display = 'none'; ctaBtn.removeAttribute('href'); }
}

function startProgressAnimation() {
    stopStoryTimer();
    const bars = document.querySelectorAll('.story-progress-bar');
    const activeBar = bars[currentStoryIndex]; if (!activeBar) return;
    const progress = activeBar.querySelector('.progress');
    let startTime = Date.now(); progress.style.width = '0%';
    progressInterval = setInterval(function() {
        const elapsed = Date.now() - startTime;
        const percent = Math.min((elapsed / storyDuration) * 100, 100);
        progress.style.width = percent + '%';
        if (elapsed >= storyDuration) { clearInterval(progressInterval); nextStory(); }
    }, 30);
}

function startVideoProgress(video) {
    stopStoryTimer();
    const bars = document.querySelectorAll('.story-progress-bar');
    const activeBar = bars[currentStoryIndex]; if (!activeBar) return;
    const progress = activeBar.querySelector('.progress'); progress.style.width = '0%';
    progressInterval = setInterval(function() {
        if (video.duration && isFinite(video.duration) && video.duration > 0) {
            const percent = Math.min((video.currentTime / video.duration) * 100, 100);
            progress.style.width = percent + '%';
            if (video.ended || percent >= 100) { clearInterval(progressInterval); }
        }
    }, 30);
}

function updateProgressBars(activeIndex) {
    const bars = document.querySelectorAll('.story-progress-bar');
    bars.forEach((bar, i) => {
        bar.classList.remove('active', 'completed');
        const progress = bar.querySelector('.progress');
        if (i < activeIndex) { bar.classList.add('completed'); progress.style.width = '100%'; }
        else if (i === activeIndex) { bar.classList.add('active'); progress.style.width = '0%'; }
        else { progress.style.width = '0%'; }
    });
}

function resetProgressBars() { document.querySelectorAll('.story-progress-bar').forEach(bar => { bar.classList.remove('active', 'completed'); bar.querySelector('.progress').style.width = '0%'; }); }
function nextStory() { if (currentVideo) currentVideo.pause(); stopStoryTimer(); if (currentStoryIndex < storiesData.length - 1) { showStory(currentStoryIndex + 1); } else { closeStory(); } }
function prevStory() { if (currentVideo) currentVideo.pause(); stopStoryTimer(); if (currentStoryIndex > 0) { showStory(currentStoryIndex - 1); } }

document.addEventListener('keydown', function(e) { if (!document.getElementById('storyModal').classList.contains('active')) return; if (e.key === 'Escape') closeStory(); if (e.key === 'ArrowRight') nextStory(); if (e.key === 'ArrowLeft') prevStory(); });
let touchStartX = 0;
document.getElementById('storyModal').addEventListener('touchstart', function(e) { touchStartX = e.changedTouches[0].screenX; }, { passive: true });
document.getElementById('storyModal').addEventListener('touchend', function(e) { const diff = touchStartX - e.changedTouches[0].screenX; if (Math.abs(diff) > 50) { if (diff > 0) nextStory(); else prevStory(); } }, { passive: true });
</script>
<?php endif; ?>

<!-- Stats -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon balance"><i class="fas fa-wallet"></i></div>
        <div class="stat-info">
            <h3><?php echo $siteSettings['currency_symbol'] . number_format($currentUser['balance'], 2); ?></h3>
            <p><?php echo __('current_balance'); ?></p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon orders"><i class="fas fa-shopping-bag"></i></div>
        <div class="stat-info">
            <h3><?php echo number_format($userStats['total_orders'] ?? 0); ?></h3>
            <p><?php echo __('total_orders'); ?></p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon active"><i class="fas fa-spinner"></i></div>
        <div class="stat-info">
            <h3><?php echo number_format($userStats['active_orders'] ?? 0); ?></h3>
            <p><?php echo __('active_orders'); ?></p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon spent"><i class="fas fa-chart-line"></i></div>
        <div class="stat-info">
            <h3><?php echo $siteSettings['currency_symbol'] . number_format($userStats['total_spent'] ?? 0, 2); ?></h3>
            <p><?php echo __('total_spent'); ?></p>
        </div>
    </div>
</div>

<!-- Order Section -->
<div class="order-section">
    <!-- New Order Form -->
    <div class="card">
        <div class="card-header">
            <h2><i class="fas fa-plus-circle"></i> <?php echo __('quick_order'); ?></h2>
        </div>
        <div class="card-body">
            <?php if ($orderSuccess): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo clean($orderSuccess); ?></div>
            <?php endif; ?>
            
            <?php if ($orderError): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo clean($orderError); ?></div>
            <?php endif; ?>
            
            <form method="POST" id="orderForm">
                <input type="hidden" name="action" value="place_order">
<input type="hidden" name="idempotency_key" value="<?php echo bin2hex(random_bytes(16)); ?>">
                <input type="hidden" name="dripfeed_enabled" id="dripfeedEnabledInput" value="0">
                
                <div class="form-group">
                    <label class="form-label"><?php echo __('category'); ?></label>
                    <select id="categorySelect" class="form-control">
                        <option value="">-- <?php echo __('select_category'); ?> --</option>
                        <?php if (!empty($favoriteServices)): ?>
                            <option value="favorites" data-icon="fas fa-star">⭐ Favori Servislerim (<?php echo count($favoriteServices); ?>)</option>
                        <?php endif; ?>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo $cat['id']; ?>" data-icon="<?php echo clean($cat['icon']); ?>">
                                <?php echo clean($cat['name']); ?> (<?php echo $cat['service_count']; ?> <?php echo __('services'); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php echo __('service'); ?></label>
                    <select name="service_id" id="serviceSelect" class="form-control" required disabled>
                        <option value="">-- <?php echo __('select_category_first'); ?> --</option>
                    </select>
                </div>
                
                <!-- Service Info -->
                <div class="service-info" id="serviceInfo">
                    <div class="service-info-header">
                        <h4><i class="fas fa-info-circle"></i> <span id="serviceName"><?php echo __('service_info'); ?></span></h4>
                        <button type="button" class="service-favorite-btn add" id="serviceFavoriteBtn" onclick="toggleFavorite()" style="display: none;">
                            <i class="far fa-star"></i> <span>Favoriye Ekle</span>
                        </button>
                    </div>
                    <div class="service-description" id="serviceDescription" style="display: none;"></div>
                    <div class="service-details">
                        <div class="service-detail">
                            <label><?php echo __('price_per_1000'); ?></label>
                            <span class="price" id="servicePrice">-</span>
                        </div>
                        <div class="service-detail">
                            <label><?php echo __('min'); ?></label>
                            <span id="serviceMin">-</span>
                        </div>
                        <div class="service-detail">
                            <label><?php echo __('max'); ?></label>
                            <span id="serviceMax">-</span>
                        </div>
                        <div class="service-detail service-rating-detail">
                            <label>Servis Puanı</label>
                            <span id="serviceRating" class="service-rating-value"><i class="far fa-star"></i> Henüz puan yok</span>
                        </div>
                        <div class="service-detail">
                            <label><?php echo __('estimated_time'); ?></label>
                            <span id="serviceEta">Veri bekleniyor</span>
                        </div>
                    </div>
                    <div class="service-features" id="serviceFeatures"></div>
                </div>
                
                <!-- Dripfeed Section -->
                <div class="dripfeed-section" id="dripfeedSection">
                    <div class="dripfeed-header">
                        <h4><i class="fas fa-tint"></i> Dripfeed Modu</h4>
                        <div class="dripfeed-toggle">
                            <label class="toggle-switch">
                                <input type="checkbox" id="dripfeedToggle">
                                <span class="toggle-slider"></span>
                            </label>
                            <label for="dripfeedToggle">Aktif</label>
                        </div>
                    </div>
                    <div class="dripfeed-options" id="dripfeedOptions">
                        <div class="form-group">
                            <label class="form-label">Çalıştırma Sayısı</label>
                            <input type="number" name="dripfeed_runs" id="dripfeedRuns" class="form-control" min="2" max="100" value="2" placeholder="Kaç kez gönderilsin?">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Aralık (dakika)</label>
                            <input type="number" name="dripfeed_interval" id="dripfeedInterval" class="form-control" min="0" value="60" placeholder="Gönderimler arası süre">
                        </div>
                    </div>
                    <div class="dripfeed-info" id="dripfeedInfo">
                        <i class="fas fa-info-circle"></i>
                        <span id="dripfeedInfoText">Dripfeed ile siparişiniz belirli aralıklarla parça parça gönderilir.</span>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?php echo __('link'); ?> / <?php echo __('username'); ?></label>
                    <input type="text" name="link" id="linkInput" class="form-control" placeholder="https://instagram.com/username veya @kullaniciadi" required>
                </div>
                
                <div class="form-group" id="geoTargetGroup" style="display:none;">
                    <label class="form-label"><i class="fas fa-globe"></i> Coğrafi Hedef</label>
                    <select name="geo_target" id="geoTargetSelect" class="form-control"><option value="">Hedef seçin</option></select>
                    <small>Yalnız provider tarafından hedefleme desteği bildirilen servislerde görünür.</small>
                </div>

                <div class="form-group">
                    <label class="form-label"><?php echo __('quantity'); ?> <span id="quantityLabel"></span></label>
                    <input type="number" name="quantity" id="quantityInput" class="form-control" placeholder="<?php echo __('enter_quantity'); ?>" required>
                </div>
                
                <div class="total-box">
                    <label><?php echo __('total_price'); ?></label>
                    <div class="total-price" id="totalPrice"><?php echo $siteSettings['currency_symbol']; ?>0.00</div>
                    <div class="total-info" id="totalInfo"></div>
                </div>
                
                <button type="submit" class="btn btn-primary" style="width: 100%;" id="submitBtn" disabled>
                    <i class="fas fa-shopping-cart"></i> <?php echo __('place_order'); ?>
                </button>
            </form>
        </div>
    </div>
    
    <!-- Recent Orders -->
    <div class="card">
        <div class="card-header">
            <h2><i class="fas fa-history"></i> <?php echo __('recent_orders'); ?></h2>
        </div>
        <div class="card-body" style="padding: 15px;">
            <?php if (empty($recentOrders)): ?>
                <div class="empty-orders">
                    <i class="fas fa-shopping-bag"></i>
                    <p><?php echo __('no_orders'); ?></p>
                </div>
            <?php else: ?>
                <div class="orders-list">
                    <?php foreach ($recentOrders as $order): 
                        $isDripfeed = !empty($order['dripfeed_id']) && $order['dripfeed_id'] > 0;
                        $partNumber = $dripfeedPartNumbers[$order['id']] ?? null;
                        $totalRuns = $order['dripfeed_total_runs'] ?? null;
                    ?>
                        <div class="order-item <?php echo $isDripfeed ? 'dripfeed-order' : ''; ?>">
                            <div class="order-icon">
                                <i class="<?php echo $order['category_icon'] ?: 'fas fa-shopping-cart'; ?>"></i>
                            </div>
                            <div class="order-details">
                                <h4><?php echo clean($order['service_name'] ?: __('service') . ' #' . $order['service_id']); ?></h4>
                                <p>
                                    #<?php echo $order['id']; ?> • <?php echo number_format($order['quantity']); ?> <?php echo __('pieces'); ?>
                                    <?php if ($isDripfeed && $partNumber && $totalRuns): ?>
                                        <span class="dripfeed-badge-small"><i class="fas fa-tint"></i> <?php echo $partNumber; ?>/<?php echo $totalRuns; ?></span>
                                    <?php endif; ?>
                                </p>
                            </div>
                            <span class="status-badge status-<?php echo $order['status']; ?>"><?php echo __('status_' . $order['status']); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        <a href="/kullanici/orders.php" class="view-all-link"><?php echo __('view_all_orders'); ?> <i class="fas fa-arrow-right"></i></a>
    </div>
</div>

<script>
const currencySymbol = '<?php echo $siteSettings['currency_symbol']; ?>';
const userBalance = <?php echo $currentUser['balance']; ?>;
const favoriteServiceIds = <?php echo json_encode($favoriteServiceIds); ?>;
const favoriteServicesData = <?php echo json_encode($favoriteServices, JSON_UNESCAPED_UNICODE); ?>;

const translations = {
    select_service: '<?php echo __('select_service'); ?>',
    refill_guaranteed: '<?php echo __('refill_guaranteed'); ?>',
    automatic: '<?php echo __('automatic'); ?>',
    min: '<?php echo __('min'); ?>',
    max: '<?php echo __('max'); ?>',
    please_select_service: '<?php echo __('please_select_service'); ?>',
    minimum_quantity: '<?php echo __('minimum_quantity'); ?>',
    maximum_quantity: '<?php echo __('maximum_quantity'); ?>',
    processing: '<?php echo __('processing'); ?>',
    dripfeed: 'Dripfeed',
    per_run: 'her gönderimde',
    add_to_favorites: 'Favoriye Ekle',
    remove_from_favorites: 'Favoriden Kaldır'
};

const servicesData = <?php echo json_encode($services, JSON_UNESCAPED_UNICODE); ?>;

const categorySelect = document.getElementById('categorySelect');
const serviceSelect = document.getElementById('serviceSelect');
const quantityInput = document.getElementById('quantityInput');
const totalPriceEl = document.getElementById('totalPrice');
const totalInfoEl = document.getElementById('totalInfo');
const serviceInfo = document.getElementById('serviceInfo');
const submitBtn = document.getElementById('submitBtn');
const dripfeedSection = document.getElementById('dripfeedSection');
const dripfeedToggle = document.getElementById('dripfeedToggle');
const dripfeedOptions = document.getElementById('dripfeedOptions');
const dripfeedEnabledInput = document.getElementById('dripfeedEnabledInput');
const dripfeedRuns = document.getElementById('dripfeedRuns');
const dripfeedInterval = document.getElementById('dripfeedInterval');
const dripfeedInfoText = document.getElementById('dripfeedInfoText');
const quantityLabel = document.getElementById('quantityLabel');
const serviceFavoriteBtn = document.getElementById('serviceFavoriteBtn');

let currentService = null;

categorySelect.addEventListener('change', function() {
    const categoryId = this.value;
    
    serviceSelect.innerHTML = '<option value="">-- ' + translations.select_service + ' --</option>';
    serviceInfo.classList.remove('active');
    dripfeedSection.classList.remove('active');
    dripfeedToggle.checked = false;
    dripfeedOptions.classList.remove('active');
    dripfeedEnabledInput.value = '0';
    submitBtn.disabled = true;
    currentService = null;
    quantityLabel.textContent = '';
    serviceFavoriteBtn.style.display = 'none';
    document.getElementById('geoTargetGroup').style.display='none';document.getElementById('geoTargetSelect').required=false;
    
    if (categoryId) {
        let filteredServices = [];
        
        if (categoryId === 'favorites') {
            filteredServices = favoriteServicesData;
        } else {
            filteredServices = servicesData.filter(s => s.category_id == categoryId);
        }
        
        filteredServices.forEach(s => {
            const option = document.createElement('option');
            option.value = s.id;
            
            const isFavorite = favoriteServiceIds.includes(parseInt(s.id)) || favoriteServiceIds.includes(s.id.toString());
            let label = (isFavorite && categoryId !== 'favorites' ? '⭐ ' : '') + s.name + ' - ' + currencySymbol + parseFloat(s.price_per_1000).toFixed(2) + '/1K';
            if (Number(s.rating_count||0) > 0) { label += ' · ★' + Number(s.rating_avg||0).toFixed(1) + ' (' + Number(s.rating_count) + ')'; }
            if (s.dripfeed == 1) { label += ' 💧'; }
            if (s.capacity && s.capacity.label) { label += ' · ' + s.capacity.label; }
            if (s.schedule_open === false || s.schedule_open === 0) { label += ' · Kapalı'; }
            
            option.textContent = label;
            option.dataset.price = s.price_per_1000;
            option.dataset.min = s.min_quantity;
            option.dataset.max = s.max_quantity;
            option.dataset.name = s.name;
            option.dataset.description = s.description || '';
            option.dataset.refill = s.refill;
            option.dataset.api = s.api_provider_id ? '1' : '0';
            option.dataset.dripfeed = s.dripfeed || '0';
            option.dataset.geoSupported = s.geo_supported || '0';
            option.dataset.geoTargets = s.geo_targets_json || '[]';
            option.dataset.priceTiers = JSON.stringify(s.price_tiers || []);
            option.dataset.minSalePrice = s.min_sale_price || 0;
            option.dataset.favorite = isFavorite ? '1' : '0';
            option.dataset.ratingAvg = s.rating_avg || 0;
            option.dataset.ratingCount = s.rating_count || 0;
            option.dataset.deliveryEta = s.delivery_eta || s.average_time || '';
            option.dataset.scheduleOpen = (s.schedule_open === false || s.schedule_open === 0) ? '0' : '1';
            option.dataset.scheduleLabel = s.schedule_label || '';
            option.dataset.scheduleNext = s.schedule_next || '';
            option.dataset.autoBadges = JSON.stringify(s.auto_badges || []);
            option.dataset.serviceTags = JSON.stringify(s.service_tags || []);
            
            if (isFavorite) { option.classList.add('favorite-option'); }
            
            serviceSelect.appendChild(option);
        });
        
        serviceSelect.disabled = false;
    } else {
        serviceSelect.disabled = true;
    }
    
    calculateTotal();
});

serviceSelect.addEventListener('change', function() {
    const option = this.options[this.selectedIndex];
    
    if (option.value) {
        const isFavorite = option.dataset.favorite === '1';
        
        currentService = {
            id: option.value,
            price: parseFloat(option.dataset.price),
            min: parseInt(option.dataset.min),
            max: parseInt(option.dataset.max),
            name: option.dataset.name,
            dripfeed: option.dataset.dripfeed === '1',
            favorite: isFavorite,
            geoSupported: option.dataset.geoSupported === '1',
            geoTargets: (()=>{try{return JSON.parse(option.dataset.geoTargets||'[]')}catch(e){return []}})(),
            priceTiers: (()=>{try{return JSON.parse(option.dataset.priceTiers||'[]')}catch(e){return []}})(),
            minSalePrice: parseFloat(option.dataset.minSalePrice || '0') || 0,
            ratingAvg: parseFloat(option.dataset.ratingAvg || '0') || 0,
            ratingCount: parseInt(option.dataset.ratingCount || '0') || 0,
            deliveryEta: option.dataset.deliveryEta || '',
            scheduleOpen: option.dataset.scheduleOpen !== '0',
            scheduleLabel: option.dataset.scheduleLabel || '',
            scheduleNext: option.dataset.scheduleNext || '',
            autoBadges: (()=>{try{return JSON.parse(option.dataset.autoBadges||'[]')}catch(e){return []}})(),
            serviceTags: (()=>{try{return JSON.parse(option.dataset.serviceTags||'[]')}catch(e){return []}})()
        };
        const geoGroup=document.getElementById('geoTargetGroup'), geoSelect=document.getElementById('geoTargetSelect');
        if(currentService.geoSupported && currentService.geoTargets.length){geoSelect.innerHTML='<option value="">Hedef seçin</option>'+currentService.geoTargets.map(g=>'<option value="'+String(g).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))+'">'+String(g).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))+'</option>').join('');geoSelect.required=true;geoGroup.style.display='block';}else{geoSelect.required=false;geoSelect.innerHTML='<option value="">Hedef yok</option>';geoGroup.style.display='none';}
        
        document.getElementById('serviceName').textContent = option.dataset.name;
        document.getElementById('servicePrice').textContent = currencySymbol + parseFloat(option.dataset.price).toFixed(2);
        document.getElementById('serviceMin').textContent = parseInt(option.dataset.min).toLocaleString();
        document.getElementById('serviceMax').textContent = parseInt(option.dataset.max).toLocaleString();
        const ratingEl=document.getElementById('serviceRating');
        if(ratingEl){
            const rc=parseInt(option.dataset.ratingCount||'0')||0, ra=parseFloat(option.dataset.ratingAvg||'0')||0;
            ratingEl.innerHTML=rc>0?'<i class="fas fa-star"></i> '+ra.toFixed(1)+' / 5 <small>('+rc+' değerlendirme)</small>':'<i class="far fa-star"></i> Henüz puan yok';
            ratingEl.classList.toggle('has-rating',rc>0);
        }
        const etaEl=document.getElementById('serviceEta');
        if(etaEl)etaEl.textContent=option.dataset.deliveryEta||'Henüz yeterli veri yok';
        
        const descEl = document.getElementById('serviceDescription');
        if (option.dataset.description && option.dataset.description.trim() !== '') {
            descEl.textContent = option.dataset.description;
            descEl.style.display = 'block';
        } else {
            descEl.style.display = 'none';
        }
        
        let featuresHtml = '';
        if (option.dataset.refill === '1') { featuresHtml += '<span class="feature-badge refill"><i class="fas fa-sync-alt"></i> ' + translations.refill_guaranteed + '</span>'; }
        if (option.dataset.api === '1') { featuresHtml += '<span class="feature-badge api"><i class="fas fa-bolt"></i> ' + translations.automatic + '</span>'; }
        if (option.dataset.dripfeed === '1') { featuresHtml += '<span class="feature-badge dripfeed"><i class="fas fa-tint"></i> ' + translations.dripfeed + '</span>'; }
        const ratingCount=parseInt(option.dataset.ratingCount||'0')||0, ratingAvg=parseFloat(option.dataset.ratingAvg||'0')||0;
        featuresHtml += ratingCount>0?'<span class="feature-badge service-rating-badge"><i class="fas fa-star"></i> '+ratingAvg.toFixed(1)+' / 5 · '+ratingCount+' değerlendirme</span>':'<span class="feature-badge service-rating-empty"><i class="far fa-star"></i> Henüz puan yok</span>';
        const autoBadges=(()=>{try{return JSON.parse(option.dataset.autoBadges||'[]')}catch(e){return []}})();
        autoBadges.forEach(b=>{featuresHtml+='<span class="feature-badge"><i class="fas '+String(b.icon||'fa-award').replace(/[^a-z0-9-]/gi,'')+'"></i> '+String(b.label||'Rozet').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))+'</span>';});
        const serviceTags=(()=>{try{return JSON.parse(option.dataset.serviceTags||'[]')}catch(e){return []}})();serviceTags.forEach(tg=>{featuresHtml+='<span class="feature-badge"><i class="fas '+String(tg.icon||'fa-tag').replace(/[^a-z0-9-]/gi,'')+'"></i> '+String(tg.name||'Etiket').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))+'</span>';});
        const schedLabel=option.dataset.scheduleLabel||'';
        if(schedLabel){featuresHtml+='<span class="feature-badge '+(option.dataset.scheduleOpen==='0'?'':'refill')+'"><i class="fas '+(option.dataset.scheduleOpen==='0'?'fa-clock':'fa-circle-check')+'"></i> '+schedLabel.replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))+(option.dataset.scheduleNext?' · '+option.dataset.scheduleNext.replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m])):'')+'</span>';}
        document.getElementById('serviceFeatures').innerHTML = featuresHtml;
        
        quantityInput.min = option.dataset.min;
        quantityInput.max = option.dataset.max;
        quantityInput.placeholder = translations.min + ': ' + parseInt(option.dataset.min).toLocaleString() + ' - ' + translations.max + ': ' + parseInt(option.dataset.max).toLocaleString();
        
        serviceInfo.classList.add('active');
        
        // Favori butonu güncelle
        updateFavoriteButton(isFavorite);
        serviceFavoriteBtn.style.display = 'flex';
        
        if (option.dataset.dripfeed === '1') {
            dripfeedSection.classList.add('active');
            updateDripfeedInfo();
        } else {
            dripfeedSection.classList.remove('active');
            dripfeedToggle.checked = false;
            dripfeedOptions.classList.remove('active');
            dripfeedEnabledInput.value = '0';
        }
        
        submitBtn.disabled = false;
    } else {
        serviceInfo.classList.remove('active');
        dripfeedSection.classList.remove('active');
        dripfeedToggle.checked = false;
        dripfeedOptions.classList.remove('active');
        dripfeedEnabledInput.value = '0';
        submitBtn.disabled = true;
        currentService = null;
        serviceFavoriteBtn.style.display = 'none';
    }
    
    updateQuantityLabel();
    calculateTotal();
});

function updateFavoriteButton(isFavorite) {
    if (isFavorite) {
        serviceFavoriteBtn.className = 'service-favorite-btn remove';
        serviceFavoriteBtn.innerHTML = '<i class="fas fa-star"></i> <span>' + translations.remove_from_favorites + '</span>';
    } else {
        serviceFavoriteBtn.className = 'service-favorite-btn add';
        serviceFavoriteBtn.innerHTML = '<i class="far fa-star"></i> <span>' + translations.add_to_favorites + '</span>';
    }
}

function toggleFavorite() {
    if (!currentService) return;
    
    const action = currentService.favorite ? 'remove_favorite' : 'add_favorite';
    const formData = new FormData();
    formData.append('action', action);
    formData.append('service_id', currentService.id);
    
    // Butonu devre dışı bırak
    serviceFavoriteBtn.disabled = true;
    serviceFavoriteBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    
    fetch('/kullanici/', {
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            currentService.favorite = !currentService.favorite;
            updateFavoriteButton(currentService.favorite);
            
            // Favori ID listesini güncelle
            const serviceIdInt = parseInt(currentService.id);
            if (currentService.favorite) {
                if (!favoriteServiceIds.includes(serviceIdInt)) {
                    favoriteServiceIds.push(serviceIdInt);
                }
            } else {
                const idx = favoriteServiceIds.indexOf(serviceIdInt);
                if (idx > -1) { favoriteServiceIds.splice(idx, 1); }
            }
            
            // Mevcut seçili option'ın data-favorite'ını güncelle
            const selectedOption = serviceSelect.options[serviceSelect.selectedIndex];
            if (selectedOption) {
                selectedOption.dataset.favorite = currentService.favorite ? '1' : '0';
            }
        }
    })
    .catch(error => {
        console.error('Favori işlemi hatası:', error);
    })
    .finally(() => {
        serviceFavoriteBtn.disabled = false;
        updateFavoriteButton(currentService.favorite);
    });
}

dripfeedToggle.addEventListener('change', function() {
    if (this.checked) { dripfeedOptions.classList.add('active'); dripfeedEnabledInput.value = '1'; }
    else { dripfeedOptions.classList.remove('active'); dripfeedEnabledInput.value = '0'; }
    updateQuantityLabel(); updateDripfeedInfo(); calculateTotal();
});

dripfeedRuns.addEventListener('input', function() { updateDripfeedInfo(); calculateTotal(); });
dripfeedInterval.addEventListener('input', function() { updateDripfeedInfo(); calculateTotal(); });
quantityInput.addEventListener('input', function() { updateDripfeedInfo(); calculateTotal(); });

function updateQuantityLabel() {
    if (dripfeedToggle.checked && currentService) { quantityLabel.textContent = '(' + translations.per_run + ')'; }
    else { quantityLabel.textContent = ''; }
}

function updateDripfeedInfo() {
    if (!currentService || !dripfeedToggle.checked) { dripfeedInfoText.textContent = 'Dripfeed ile siparişiniz belirli aralıklarla parça parça gönderilir.'; return; }
    const runs = parseInt(dripfeedRuns.value) || 2;
    const interval = parseInt(dripfeedInterval.value) || 60;
    const quantity = parseInt(quantityInput.value) || 0;
    const totalQuantity = quantity * runs;
    const totalTime = (runs - 1) * interval;
    let timeStr = '';
    if (totalTime >= 1440) { const days = Math.floor(totalTime / 1440); const hours = Math.floor((totalTime % 1440) / 60); timeStr = days + ' gün' + (hours > 0 ? ' ' + hours + ' saat' : ''); }
    else if (totalTime >= 60) { const hours = Math.floor(totalTime / 60); const mins = totalTime % 60; timeStr = hours + ' saat' + (mins > 0 ? ' ' + mins + ' dk' : ''); }
    else { timeStr = totalTime + ' dakika'; }
    if (quantity > 0) { dripfeedInfoText.innerHTML = '<strong>' + runs + '</strong> çalıştırma × <strong>' + quantity.toLocaleString() + '</strong> adet = Toplam <strong>' + totalQuantity.toLocaleString() + '</strong> adet<br>Tahmini süre: <strong>' + timeStr + '</strong>'; }
    else { dripfeedInfoText.textContent = runs + ' çalıştırma, ' + interval + ' dakika aralıklarla gönderilecek. Tahmini süre: ' + timeStr; }
}

function dashboardTierRate(service, totalQuantity) {
    if (!service) return 0;
    let rate = parseFloat(service.price || 0) || 0;
    const qty = parseInt(totalQuantity || 0, 10) || 0;
    const tiers = Array.isArray(service.priceTiers) ? service.priceTiers : [];
    let matched = null;
    tiers.forEach(t => {
        const min = parseInt(t.min_quantity || 0, 10) || 0;
        const max = t.max_quantity === null || t.max_quantity === '' ? null : (parseInt(t.max_quantity, 10) || 0);
        if (qty >= min && (max === null || max <= 0 || qty <= max)) {
            if (!matched || min > (parseInt(matched.min_quantity || 0, 10) || 0)) matched = t;
        }
    });
    if (matched) {
        const value = parseFloat(matched.pricing_value || matched.tier_value || matched.value || 0) || 0;
        const type = String(matched.pricing_type || matched.price_type || matched.type || '');
        if (type === 'discount_percent') rate = rate * Math.max(0, 1 - (value / 100));
        else if (type === 'fixed_per_1000') rate = value;
    }
    const floor = parseFloat(service.minSalePrice || 0) || 0;
    if (floor > 0 && rate < floor) rate = floor;
    return rate;
}

function calculateTotal() {
    const quantity = parseInt(quantityInput.value) || 0;
    if (currentService && quantity > 0) {
        let totalQuantity = quantity; let runs = 1;
        if (dripfeedToggle.checked) { runs = parseInt(dripfeedRuns.value) || 2; totalQuantity = quantity * runs; }
        const activeRate = dashboardTierRate(currentService, totalQuantity);
        const total = (totalQuantity / 1000) * activeRate;
        const servicePriceEl = document.getElementById('servicePrice');
        if (servicePriceEl) servicePriceEl.textContent = currencySymbol + activeRate.toFixed(2);
        totalPriceEl.textContent = currencySymbol + total.toFixed(2);
        if (dripfeedToggle.checked) { totalInfoEl.textContent = totalQuantity.toLocaleString() + ' adet (' + runs + ' × ' + quantity.toLocaleString() + ')'; }
        else { totalInfoEl.textContent = ''; }
        if (total > userBalance) { totalPriceEl.style.color = 'var(--danger-color)'; submitBtn.disabled = true; }
        else { totalPriceEl.style.color = '#fff'; submitBtn.disabled = false; }
    } else { totalPriceEl.textContent = currencySymbol + '0.00'; totalInfoEl.textContent = ''; }
}

document.getElementById('orderForm').addEventListener('submit', function(e) {
    if (!currentService) { e.preventDefault(); alert(translations.please_select_service); return; }
    const quantity = parseInt(quantityInput.value);
    if (quantity < currentService.min) { e.preventDefault(); alert(translations.minimum_quantity + ': ' + currentService.min.toLocaleString()); return; }
    if (quantity > currentService.max) { e.preventDefault(); alert(translations.maximum_quantity + ': ' + currentService.max.toLocaleString()); return; }
    if (dripfeedToggle.checked) {
        const runs = parseInt(dripfeedRuns.value); const interval = parseInt(dripfeedInterval.value);
        if (runs < 2) { e.preventDefault(); alert('Dripfeed için en az 2 çalıştırma gerekli!'); return; }
        if (interval < 0) { e.preventDefault(); alert('Aralık 0 veya daha büyük olmalı!'); return; }
    }
    setTimeout(function() { submitBtn.disabled = true; submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ' + translations.processing + '...'; }, 10);
});
</script>

<?php require_once 'footer.php'; ?>