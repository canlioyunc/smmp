<?php
/**
 * Kullanıcı Paneli - Tüm Servisler
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';

// Kategorileri getir
$categories = $db->query("
    SELECT c.*, COUNT(s.id) as service_count 
    FROM categories c 
    LEFT JOIN services s ON c.id = s.category_id AND s.status = 'active'
    WHERE c.status = 'active' 
    GROUP BY c.id 
    HAVING service_count > 0
    ORDER BY c.sort_order ASC
")->fetchAll();

// Filtreler
$categoryFilter = $_GET['category'] ?? '';
$search = $_GET['search'] ?? '';
$tagFilter = trim((string)($_GET['tag'] ?? ''));
$featureFilter = trim((string)($_GET['feature'] ?? ''));
$serviceTags = function_exists('moni_service_tags_all') ? moni_service_tags_all($db,true) : [];

// Sorgu oluştur
$where = "WHERE s.status = 'active'";
$params = [];

if ($categoryFilter) {
    $where .= " AND s.category_id = ?";
    $params[] = $categoryFilter;
}

if ($search) {
    $where .= " AND (s.name LIKE ? OR s.description LIKE ? OR s.id = ? OR EXISTS (SELECT 1 FROM service_translations st WHERE st.service_id=s.id AND st.language_code=? AND st.description LIKE ?))";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = $search;
    $params[] = function_exists('getCurrentLanguage') ? getCurrentLanguage() : 'tr';
    $params[] = "%$search%";
}

// Servisleri getir
$stmt = $db->prepare("
    SELECT s.*, 
           c.name as category_name, 
           c.icon as category_icon,
           c.icon_color as category_color
    FROM services s
    LEFT JOIN categories c ON s.category_id = c.id
    $where
    ORDER BY c.sort_order, s.sort_order, s.name
");
$stmt->execute($params);
$services = $stmt->fetchAll();
$displayUserId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
if($displayUserId && function_exists('moni_service_visible_to_user')) $services=array_values(array_filter($services,static fn($x)=>moni_service_visible_to_user($GLOBALS['db'],(int)$x['id'],$displayUserId)));
if(function_exists('moni_localize_service_rows')) $services=moni_localize_service_rows($db,$services);
if($displayUserId && function_exists('moni_personalize_service_rows')) $services=moni_personalize_service_rows($db,$displayUserId,$services);
foreach ($services as &$service) {
    $service['price_per_1000'] = moni_effective_price_per_1000($service, $displayUserId);
    $service['price_tiers'] = function_exists('moni_service_price_tiers') ? moni_service_price_tiers($db,(int)$service['id'],true) : [];
    $service['maintenance_reason'] = moni_maintenance_reason((int)$service['id'], (int)($service['api_provider_id'] ?? 0));
    if (moni_plugin_enabled('real_delivery_eta',$db)) {
        $eta = moni_service_delivery_estimate($db,(int)$service['id']);
        $service['delivery_eta'] = !empty($eta['available']) ? (string)$eta['label'] : '';
        $service['delivery_eta_sample'] = (int)($eta['sample'] ?? 0);
    } else { $service['delivery_eta']=''; $service['delivery_eta_sample']=0; }
}
unset($service);
if(function_exists('moni_service_capacity_attach')) moni_service_capacity_attach($db,$services);
if(function_exists('moni_service_auto_badges_attach')) moni_service_auto_badges_attach($db,$services);
if(function_exists('moni_service_tags_attach')) moni_service_tags_attach($db,$services);
if(function_exists('moni_service_schedule_attach')) moni_service_schedule_attach($db,$services);
$ratingMap=function_exists('moni_service_ratings')?moni_service_ratings($db,array_column($services,'id')):[];
foreach($services as &$service){$rr=$ratingMap[(int)$service['id']]??['avg'=>0.0,'count'=>0];$service['rating_avg']=(float)($rr['avg']??0);$service['rating_count']=(int)($rr['count']??0);}unset($service);

if($tagFilter!==''){
    $services=array_values(array_filter($services,static function($service) use($tagFilter){foreach(($service['service_tags']??[]) as $tag){if((string)($tag['slug']??'')===$tagFilter)return true;}return false;}));
}
if($featureFilter!==''){
    if($featureFilter==='refill')$services=array_values(array_filter($services,static fn($s)=>!empty($s['refill'])));
    elseif($featureFilter==='dripfeed')$services=array_values(array_filter($services,static fn($s)=>!empty($s['dripfeed'])));
    elseif($featureFilter==='open')$services=array_values(array_filter($services,static fn($s)=>!isset($s['schedule_open'])||$s['schedule_open']));
    elseif($featureFilter==='rated')usort($services,static fn($a,$b)=>[$b['rating_avg'],$b['rating_count']]<=>[$a['rating_avg'],$a['rating_count']]);
    elseif($featureFilter==='price')usort($services,static fn($a,$b)=>(float)$a['price_per_1000']<=>(float)$b['price_per_1000']);
}

// Kategorilere göre grupla
$groupedServices = [];
foreach ($services as $service) {
    $catId = $service['category_id'];
    if (!isset($groupedServices[$catId])) {
        $groupedServices[$catId] = [
            'name' => $service['category_name'],
            'icon' => $service['category_icon'],
            'color' => $service['category_color'],
            'services' => []
        ];
    }
    $groupedServices[$catId]['services'][] = $service;
}

$pageTitle = __('all_services');
require_once 'header.php';
?>

<style>
/* Page Header */
.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
    flex-wrap: wrap;
    gap: 15px;
}

.page-header h2 {
    font-size: 1.5rem;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 12px;
}

.page-header h2 i {
    color: var(--accent-text-color);
}

.page-header .service-count {
    font-size: 0.9rem;
    font-weight: 400;
    opacity: 0.6;
}

/* Search & Filters */
.filters-section {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    padding: 20px;
    margin-bottom: 25px;
}

.filters-row {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
    align-items: center;
}

.search-box {
    flex: 1;
    min-width: 250px;
    position: relative;
}

.search-box i {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    opacity: 0.4;
    color: var(--text-color);
}

.search-box input {
    width: 100%;
    padding: 12px 15px 12px 45px;
    border: 2px solid var(--border-color);
    border-radius: 10px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 0.95rem;
    transition: all 0.3s ease;
}

.search-box input:focus {
    outline: none;
    border-color: var(--accent-text-color);
}

.filter-select {
    padding: 12px 20px;
    border: 2px solid var(--border-color);
    border-radius: 10px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 0.95rem;
    min-width: 180px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.filter-select:focus {
    outline: none;
    border-color: var(--accent-text-color);
}

/* Category Tabs */
.category-tabs {
    display: flex;
    gap: 10px;
    overflow-x: auto;
    padding-bottom: 10px;
    margin-bottom: 25px;
    -webkit-overflow-scrolling: touch;
}

.category-tabs::-webkit-scrollbar {
    height: 6px;
}

.category-tabs::-webkit-scrollbar-track {
    background: var(--background-color);
    border-radius: 3px;
}

.category-tabs::-webkit-scrollbar-thumb {
    background: var(--border-color);
    border-radius: 3px;
}

.category-tab {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 12px 20px;
    background: var(--card-bg-color);
    border: 2px solid var(--border-color);
    border-radius: 12px;
    color: var(--text-color);
    text-decoration: none;
    font-weight: 500;
    font-size: 0.9rem;
    white-space: nowrap;
    transition: all 0.3s ease;
}

.category-tab:hover {
    border-color: var(--accent-text-color);
    color: var(--accent-text-color);
}

.category-tab.active {
    background: var(--primary-color);
    border-color: var(--accent-text-color);
    color: var(--on-primary-color);
}

.category-tab .count {
    background: rgba(255, 255, 255, 0.2);
    padding: 2px 8px;
    border-radius: 10px;
    font-size: 0.75rem;
}

.category-tab:not(.active) .count {
    background: var(--background-color);
}

/* Category Section */
.category-section {
    margin-bottom: 35px;
}

.category-header {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 2px solid var(--border-color);
}

.category-header .icon {
    width: 50px;
    height: 50px;
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
    color: #fff;
}

.category-header h3 {
    font-size: 1.2rem;
    font-weight: 600;
}

.category-header .count {
    font-size: 0.85rem;
    opacity: 0.6;
    margin-left: auto;
}

/* Services Grid */
.services-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 20px;
}

@media (max-width: 768px) {
    .services-grid {
        grid-template-columns: 1fr;
    }
}

/* Service Card */
.service-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    padding: 20px;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.service-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.1);
    border-color: var(--accent-text-color);
}

.service-card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 15px;
}

.service-id {
    font-size: 0.75rem;
    font-weight: 600;
    color: var(--accent-text-color);
    background: var(--primary-alpha-01);
    padding: 4px 10px;
    border-radius: 6px;
}

.service-badges {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
}

.service-badge {
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 0.7rem;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 4px;
}

.service-badge.refill {
    background: var(--success-soft-bg);
    color: var(--success-color);
}

.service-badge.auto {
    background: var(--info-soft-bg);
    color: var(--info-color);
}

.service-badge.dripfeed {
    background: rgba(0, 188, 212, 0.15);
    color: #00bcd4;
}

.service-badge.cancel {
    background: rgba(255, 152, 0, 0.15);
    color: #ff9800;
}
.service-badge.capacity-ok{background:var(--success-soft-bg);color:var(--success-color)}
.service-badge.capacity-warn{background:rgba(245,158,11,.16);color:var(--warning-color)}
.service-badge.capacity-danger{background:rgba(239,68,68,.16);color:var(--danger-color)}
.service-badge.capacity-off{background:var(--primary-alpha-01);color:var(--muted-text-color)}

.service-name {
    font-size: 1rem;
    font-weight: 600;
    margin-bottom: 8px;
    line-height: 1.4;
}

.service-description {
    font-size: 0.85rem;
    opacity: 0.6;
    margin-bottom: 15px;
    line-height: 1.5;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    min-height: 42px;
}

.service-details {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
    margin-bottom: 15px;
    padding: 15px;
    background: var(--background-color);
    border-radius: 12px;
}

.service-detail {
    text-align: center;
}

.service-detail .label {
    font-size: 0.7rem;
    text-transform: uppercase;
    opacity: 0.5;
    margin-bottom: 4px;
    display: block;
}

.service-detail .value {
    font-size: 0.95rem;
    font-weight: 600;
}

.service-detail .value.price {
    color: var(--success-color);
}

.service-card-footer {
    display: flex;
    gap: 10px;
}

.service-card-footer .btn {
    flex: 1;
    padding: 12px;
    font-size: 0.9rem;
}

.btn-order {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--on-accent-color);
    border: none;
    border-radius: 10px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}

.btn-order:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px var(--primary-alpha-035);
}

.btn-details {
    background: var(--background-color);
    color: var(--text-color);
    border: 1px solid var(--border-color);
    border-radius: 10px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}

.btn-details:hover {
    border-color: var(--accent-text-color);
    color: var(--accent-text-color);
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 80px 20px;
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
}

.empty-state i {
    font-size: 4rem;
    color: var(--accent-text-color);
    opacity: 0.3;
    margin-bottom: 20px;
}

.empty-state h3 {
    font-size: 1.3rem;
    margin-bottom: 10px;
    opacity: 0.8;
}

.empty-state p {
    opacity: 0.6;
    margin-bottom: 25px;
}

/* Service Detail Modal */
.modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    z-index: 2000;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.modal-overlay.active {
    display: flex;
}

.modal-box {
    background: var(--card-bg-color);
    border-radius: 20px;
    width: 100%;
    max-width: 550px;
    max-height: 90vh;
    overflow-y: auto;
    animation: modalSlide 0.3s ease;
}

@keyframes modalSlide {
    from { opacity: 0; transform: translateY(-30px) scale(0.95); }
    to { opacity: 1; transform: translateY(0) scale(1); }
}

.modal-header {
    padding: 25px;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
}

.modal-header .service-info h3 {
    font-size: 1.15rem;
    font-weight: 600;
    margin-bottom: 5px;
}

.modal-header .service-info .category {
    font-size: 0.85rem;
    opacity: 0.6;
    display: flex;
    align-items: center;
    gap: 6px;
}

.modal-close {
    background: var(--background-color);
    border: none;
    width: 40px;
    height: 40px;
    border-radius: 10px;
    font-size: 1.3rem;
    cursor: pointer;
    color: var(--text-color);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
    flex-shrink: 0;
}

.modal-close:hover {
    background: var(--danger-color);
    color: var(--on-danger-color);
}

.modal-body {
    padding: 25px;
}

.modal-badges {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    margin-bottom: 20px;
}

.modal-description {
    font-size: 0.95rem;
    line-height: 1.7;
    opacity: 0.8;
    margin-bottom: 25px;
    padding: 15px;
    background: var(--background-color);
    border-radius: 12px;
}

.modal-details {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
    margin-bottom: 25px;
}

.modal-detail-item {
    background: var(--background-color);
    padding: 15px;
    border-radius: 12px;
    text-align: center;
}

.modal-detail-item .label {
    font-size: 0.75rem;
    text-transform: uppercase;
    opacity: 0.5;
    margin-bottom: 6px;
    display: block;
}

.modal-detail-item .value {
    font-size: 1.1rem;
    font-weight: 700;
}

.modal-detail-item .value.price {
    color: var(--success-color);
}

.modal-features {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-bottom: 25px;
}

.modal-feature {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 16px;
    background: var(--background-color);
    border-radius: 10px;
    font-size: 0.85rem;
    font-weight: 500;
}

.modal-feature i {
    color: var(--success-color);
}

.modal-feature.inactive i {
    color: var(--danger-color);
}

.modal-footer {
    padding: 20px 25px;
    border-top: 1px solid var(--border-color);
}

.modal-footer .btn-order {
    width: 100%;
    padding: 16px;
    font-size: 1rem;
}

/* Quick Stats */
.quick-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 15px;
    margin-bottom: 25px;
}

.quick-stat {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 12px;
    padding: 20px;
    text-align: center;
}

.quick-stat .value {
    font-size: 1.8rem;
    font-weight: 700;
    color: var(--accent-text-color);
    margin-bottom: 5px;
}

.quick-stat .label {
    font-size: 0.85rem;
    opacity: 0.6;
}
</style>

<!-- Quick Stats -->
<div class="quick-stats">
    <div class="quick-stat">
        <div class="value"><?php echo count($categories); ?></div>
        <div class="label"><?php echo __('category'); ?></div>
    </div>
    <div class="quick-stat">
        <div class="value"><?php echo count($services); ?></div>
        <div class="label"><?php echo __('total_services'); ?></div>
    </div>
    <div class="quick-stat">
        <div class="value"><?php echo $siteSettings['currency_symbol']; ?><?php 
            $minPrice = !empty($services) ? min(array_column($services, 'price_per_1000')) : 0;
            echo number_format($minPrice, 2);
        ?></div>
        <div class="label"><?php echo __('lowest_price'); ?></div>
    </div>
</div>

<!-- Filters -->
<div class="filters-section">
    <form method="GET" class="filters-row">
        <div class="search-box">
            <i class="fas fa-search"></i>
            <input type="text" name="search" placeholder="<?php echo __('search_service_name_or_id'); ?>..." value="<?php echo clean($search); ?>">
        </div>
        <select name="category" class="filter-select" onchange="this.form.submit()">
            <option value=""><?php echo __('all_categories'); ?></option>
            <?php foreach ($categories as $cat): ?>
                <option value="<?php echo $cat['id']; ?>" <?php echo $categoryFilter == $cat['id'] ? 'selected' : ''; ?>>
                    <?php echo clean($cat['name']); ?> (<?php echo $cat['service_count']; ?>)
                </option>
            <?php endforeach; ?>
        </select>
        <?php if(!empty($serviceTags)): ?><select name="tag" class="filter-select" onchange="this.form.submit()"><option value="">Tüm etiketler</option><?php foreach($serviceTags as $tag): ?><option value="<?=clean($tag['slug'])?>" <?=$tagFilter===$tag['slug']?'selected':''?>><?=clean($tag['name'])?></option><?php endforeach; ?></select><?php endif; ?>
        <select name="feature" class="filter-select" onchange="this.form.submit()">
            <option value="">Akıllı filtre</option>
            <option value="rated" <?=$featureFilter==='rated'?'selected':''?>>En yüksek puan</option>
            <option value="price" <?=$featureFilter==='price'?'selected':''?>>En düşük fiyat</option>
            <option value="open" <?=$featureFilter==='open'?'selected':''?>>Şu an açık</option>
            <option value="refill" <?=$featureFilter==='refill'?'selected':''?>>Refill destekli</option>
            <option value="dripfeed" <?=$featureFilter==='dripfeed'?'selected':''?>>Dripfeed destekli</option>
        </select>
        <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i> <?php echo __('search'); ?></button>
        <?php if ($search || $categoryFilter || $tagFilter || $featureFilter): ?>
            <a href="services.php" class="btn btn-secondary btn-sm"><i class="fas fa-times"></i> <?php echo __('clear'); ?></a>
        <?php endif; ?>
    </form>
</div>

<!-- Category Tabs -->
<div class="category-tabs">
    <a href="services.php" class="category-tab <?php echo !$categoryFilter ? 'active' : ''; ?>">
        <i class="fas fa-th"></i> <?php echo __('all'); ?>
        <span class="count"><?php echo count($services); ?></span>
    </a>
    <?php foreach ($categories as $cat): ?>
        <a href="services.php?category=<?php echo $cat['id']; ?>" class="category-tab <?php echo $categoryFilter == $cat['id'] ? 'active' : ''; ?>">
            <i class="<?php echo $cat['icon'] ?: 'fas fa-folder'; ?>"></i>
            <?php echo clean($cat['name']); ?>
            <span class="count"><?php echo $cat['service_count']; ?></span>
        </a>
    <?php endforeach; ?>
</div>

<?php if (empty($services)): ?>
    <div class="empty-state">
        <i class="fas fa-search"></i>
        <h3><?php echo __('service_not_found'); ?></h3>
        <p><?php echo __('no_service_match_criteria'); ?></p>
        <a href="services.php" class="btn btn-primary">
            <i class="fas fa-list"></i> <?php echo __('show_all_services'); ?>
        </a>
    </div>
<?php else: ?>
    <?php foreach ($groupedServices as $catId => $category): ?>
        <div class="category-section" id="category-<?php echo $catId; ?>">
            <div class="category-header">
                <div class="icon" style="background: <?php echo $category['color'] ?: '#667eea'; ?>">
                    <i class="<?php echo $category['icon'] ?: 'fas fa-folder'; ?>"></i>
                </div>
                <h3><?php echo clean($category['name']); ?></h3>
                <span class="count"><?php echo count($category['services']); ?> <?php echo __('services'); ?></span>
            </div>
            
            <div class="services-grid">
                <?php foreach ($category['services'] as $service): ?>
                    <div class="service-card">
                        <div class="service-card-header">
                            <span class="service-id">ID: <?php echo $service['id']; ?></span>
                            <div class="service-badges">
                                <?php if ($service['dripfeed'] ?? 0): ?>
                                    <span class="service-badge dripfeed"><i class="fas fa-tint"></i> Dripfeed</span>
                                <?php endif; ?>
                                <?php if ($service['refill'] ?? 0): ?>
                                    <span class="service-badge refill"><i class="fas fa-sync-alt"></i> <?php echo __('refill'); ?></span>
                                <?php endif; ?>
                                <?php if ($service['cancel'] ?? 0): ?>
                                    <span class="service-badge cancel"><i class="fas fa-ban"></i> <?php echo __('cancel'); ?></span>
                                <?php endif; ?>
                                <?php if ($service['api_provider_id']): ?>
                                    <span class="service-badge auto"><i class="fas fa-bolt"></i> <?php echo __('auto'); ?></span>
                                <?php endif; ?>
                                <?php if (!empty($service['price_tiers'])): ?><span class="service-badge"><i class="fas fa-tags"></i> Kademeli Fiyat</span><?php endif; ?>
                                <?php if (!empty($service['capacity'])): $cap=$service['capacity']; ?><span class="service-badge capacity-<?=clean($cap['badge'])?>"><i class="fas <?=clean($cap['icon'])?>"></i> <?=clean($cap['label'])?><?php if(!empty($cap['show_exact'])): ?> · %<?=number_format((float)$cap['utilization'],0)?><?php endif; ?></span><?php endif; ?>
                                <?php foreach(($service['auto_badges']??[]) as $ab): ?><span class="service-badge" title="<?=clean($ab['reason']??'')?>"><i class="fas <?=clean($ab['icon']??'fa-award')?>"></i> <?=clean($ab['label']??'Rozet')?></span><?php endforeach; ?>
                                <?php if(!empty($service['rating_count'])): ?><span class="service-badge rating"><i class="fas fa-star"></i> <?=number_format((float)$service['rating_avg'],1)?> / 5 · <?=(int)$service['rating_count']?></span><?php endif; ?>
                                <?php foreach(($service['service_tags']??[]) as $tag): ?><span class="service-badge" style="--tag-color:<?=clean($tag['color']??'#6366f1')?>"><i class="fas <?=clean($tag['icon']??'fa-tag')?>"></i> <?=clean($tag['name'])?></span><?php endforeach; ?>
                                <?php if(isset($service['schedule_open'])): ?><span class="service-badge <?=$service['schedule_open']?'refill':'cancel'?>"><i class="fas <?=$service['schedule_open']?'fa-circle-check':'fa-clock'?>"></i> <?=clean($service['schedule_label']??($service['schedule_open']?'Açık':'Kapalı'))?><?php if(!empty($service['schedule_next'])): ?> · <?=clean($service['schedule_next'])?><?php endif; ?></span><?php endif; ?>
                            </div>
                        </div>
                        
                        <h4 class="service-name"><?php echo clean($service['name']); ?></h4>
                        
                        <p class="service-description">
                            <?php echo $service['description'] ? clean($service['description']) : __('no_description'); ?>
                        </p>
                        
                        <div class="service-details">
                            <div class="service-detail">
                                <span class="label"><?php echo __('price_1k'); ?></span>
                                <span class="value price"><?php echo $siteSettings['currency_symbol'] . number_format($service['price_per_1000'], 2); ?></span>
                            </div>
                            <div class="service-detail">
                                <span class="label"><?php echo __('min'); ?></span>
                                <span class="value"><?php echo number_format($service['min_quantity']); ?></span>
                            </div>
                            <div class="service-detail">
                                <span class="label"><?php echo __('max'); ?></span>
                                <span class="value"><?php echo number_format($service['max_quantity']); ?></span>
                            </div>
                            <?php if(!empty($service['delivery_eta'])): ?><div class="service-detail"><span class="label">Gerçek teslim tahmini</span><span class="value"><?=clean($service['delivery_eta'])?></span></div><?php endif; ?>
                            <div class="service-detail"><span class="label">Müşteri puanı</span><span class="value"><?php if(!empty($service['rating_count'])): ?><i class="fas fa-star" style="color:var(--warning-color)"></i> <?=number_format((float)$service['rating_avg'],1)?> / 5 <small>(<?=(int)$service['rating_count']?>)</small><?php else: ?>Henüz puan yok<?php endif; ?></span></div>
                            <?php if(isset($service['schedule_open'])): ?><div class="service-detail"><span class="label">Çalışma durumu</span><span class="value"><?=clean($service['schedule_label']??'')?><?php if(!empty($service['schedule_next'])): ?> · <?=clean($service['schedule_next'])?><?php endif; ?></span></div><?php endif; ?>
                        </div>
                        
                        <div class="service-card-footer">
                            <a href="/kullanici/new-order.php?service=<?php echo $service['id']; ?>" class="btn btn-order">
                                <i class="fas fa-shopping-cart"></i> <?php echo __('place_order'); ?>
                            </a>
                            <button type="button" class="btn btn-details js-service-detail" data-service-id="<?php echo (int)$service['id']; ?>" aria-label="Servis detaylarını göster">
                                <i class="fas fa-info-circle"></i>
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<!-- Service Detail Modal -->
<div class="modal-overlay" id="serviceModal">
    <div class="modal-box">
        <div class="modal-header">
            <div class="service-info">
                <h3 id="modalServiceName"></h3>
                <span class="category" id="modalServiceCategory">
                    <i class="fas fa-folder"></i>
                    <span></span>
                </span>
            </div>
            <button type="button" class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <div class="modal-body">
            <!-- Badges -->
            <div class="modal-badges" id="modalServiceBadges"></div>
            
            <div class="modal-description" id="modalServiceDesc"></div>
            
            <div class="modal-details">
                <div class="modal-detail-item">
                    <span class="label"><?php echo __('price_per_1000'); ?></span>
                    <span class="value price" id="modalServicePrice"></span>
                </div>
                <div class="modal-detail-item">
                    <span class="label"><?php echo __('minimum_quantity'); ?></span>
                    <span class="value" id="modalServiceMin"></span>
                </div>
                <div class="modal-detail-item">
                    <span class="label"><?php echo __('maximum_quantity'); ?></span>
                    <span class="value" id="modalServiceMax"></span>
                </div>
                <div class="modal-detail-item">
                    <span class="label"><?php echo __('average_time'); ?></span>
                    <span class="value" id="modalServiceTime">0-24 <?php echo __('hours'); ?></span>
                </div>
            </div>
            
            <div class="modal-features" id="modalServiceFeatures"></div>
        </div>
        <div class="modal-footer">
            <a href="#" class="btn btn-order" id="modalOrderBtn">
                <i class="fas fa-shopping-cart"></i> <?php echo __('order_now'); ?>
            </a>
        </div>
    </div>
</div>

<?php
$serviceDetailsById = [];
foreach ($services as $serviceRow) {
    $serviceDetailsById[(string)(int)$serviceRow['id']] = $serviceRow;
}
?>
<script>
const serviceDetailsById = <?php echo json_encode($serviceDetailsById, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
const currencySymbol = '<?php echo $siteSettings['currency_symbol']; ?>';

// Çeviri metinleri
const t = {
    no_description: '<?php echo __('no_description'); ?>',
    refill_guarantee: '<?php echo __('refill_guarantee'); ?>',
    auto_start: '<?php echo __('auto_start'); ?>',
    order_24_7: '<?php echo __('order_24_7'); ?>',
    fast_delivery: '<?php echo __('fast_delivery'); ?>',
    dripfeed_support: '<?php echo __('dripfeed_support') ?: 'Dripfeed Desteği'; ?>',
    cancel_support: '<?php echo __('cancel_support') ?: 'İptal Edilebilir'; ?>',
    refill: '<?php echo __('refill'); ?>',
    cancel: '<?php echo __('cancel') ?: 'İptal'; ?>',
    auto: '<?php echo __('auto'); ?>',
    hours: '<?php echo __('hours'); ?>'
};

function showServiceDetail(service) {
    document.getElementById('modalServiceName').textContent = service.name;
    document.getElementById('modalServiceCategory').querySelector('span').textContent = service.category_name || '-';
    document.getElementById('modalServiceDesc').textContent = service.description || t.no_description;
    document.getElementById('modalServicePrice').textContent = currencySymbol + parseFloat(service.price_per_1000).toFixed(2);
    document.getElementById('modalServiceMin').textContent = Number(service.min_quantity).toLocaleString();
    document.getElementById('modalServiceMax').textContent = Number(service.max_quantity).toLocaleString();
    document.getElementById('modalOrderBtn').href = '/kullanici/new-order.php?service=' + service.id;
    
    // Average time
    if (service.delivery_eta) {
        document.getElementById('modalServiceTime').textContent = service.delivery_eta + ' (gerçek siparişlerden)';
    } else if (service.average_time) {
        document.getElementById('modalServiceTime').textContent = service.average_time;
    } else {
        document.getElementById('modalServiceTime').textContent = '0-24 ' + t.hours;
    }
    
    // Badges
    let badgesHtml = '';
    if (service.dripfeed == 1) {
        badgesHtml += '<span class="service-badge dripfeed"><i class="fas fa-tint"></i> Dripfeed</span>';
    }
    if (service.refill == 1) {
        badgesHtml += '<span class="service-badge refill"><i class="fas fa-sync-alt"></i> ' + t.refill + '</span>';
    }
    if (service.cancel == 1) {
        badgesHtml += '<span class="service-badge cancel"><i class="fas fa-ban"></i> ' + t.cancel + '</span>';
    }
    if (service.api_provider_id) {
        badgesHtml += '<span class="service-badge auto"><i class="fas fa-bolt"></i> ' + t.auto + '</span>';
    }
    if (Array.isArray(service.auto_badges)) {
        service.auto_badges.forEach(b => { badgesHtml += '<span class="service-badge" title="'+escapeHtml(b.reason||'')+'"><i class="fas '+escapeHtml(b.icon||'fa-award')+'"></i> '+escapeHtml(b.label||'Rozet')+'</span>'; });
    }
    document.getElementById('modalServiceBadges').innerHTML = badgesHtml;
    
    // Features
    let featuresHtml = '';
    
    if (service.dripfeed == 1) {
        featuresHtml += '<div class="modal-feature"><i class="fas fa-check-circle"></i> ' + t.dripfeed_support + '</div>';
    }
    if (service.refill == 1) {
        featuresHtml += '<div class="modal-feature"><i class="fas fa-check-circle"></i> ' + t.refill_guarantee + '</div>';
    }
    if (service.cancel == 1) {
        featuresHtml += '<div class="modal-feature"><i class="fas fa-check-circle"></i> ' + t.cancel_support + '</div>';
    }
    if (service.api_provider_id) {
        featuresHtml += '<div class="modal-feature"><i class="fas fa-check-circle"></i> ' + t.auto_start + '</div>';
    }
    featuresHtml += '<div class="modal-feature"><i class="fas fa-check-circle"></i> ' + t.order_24_7 + '</div>';
    featuresHtml += '<div class="modal-feature"><i class="fas fa-check-circle"></i> ' + t.fast_delivery + '</div>';
    
    document.getElementById('modalServiceFeatures').innerHTML = featuresHtml;
    
    document.getElementById('serviceModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    document.getElementById('serviceModal').classList.remove('active');
    document.body.style.overflow = '';
}

// Modal dışına tıklayınca kapat
document.getElementById('serviceModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeModal();
    }
});

// ESC tuşuyla kapat
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeModal();
    }
});

// Arama inputu - enter tuşuyla arama
document.querySelector('.search-box input')?.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        this.form.submit();
    }
});

// Service objects never travel through HTML attributes. Only integer IDs are stored in DOM.
(function serviceDetailBound(){
    document.querySelectorAll('.js-service-detail[data-service-id]').forEach(function(btn){
        btn.addEventListener('click', function(){
            const id = String(parseInt(btn.dataset.serviceId || '0', 10) || 0);
            const service = serviceDetailsById[id];
            if (service) showServiceDetail(service);
        });
    });
})();
</script>

<?php require_once 'footer.php'; ?>