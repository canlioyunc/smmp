<?php
/**
 * Kullanıcı Paneli - API Dokümantasyonu
 * api/myservices.php ile tam uyumlu
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';
if (!empty($_SESSION['user_id']) && function_exists('moni_user_can') && !moni_user_can($db,(int)$_SESSION['user_id'],'api.use',true)) { http_response_code(403); exit('API kullanım yetkiniz kapalı.'); }

// Türkiye saat dilimini ayarla
date_default_timezone_set('Europe/Istanbul');

// Giriş kontrolü
if (!isLoggedIn()) {
    header('Location: /login.php');
    exit;
}

// Kullanıcının API client bilgisini al
$hasApiKey = false;
$apiClientInfo = null;

try {
    $stmt = $db->prepare("SELECT * FROM api_clients WHERE user_id = ? AND status = 'active' LIMIT 1");
    $stmt->execute([$_SESSION['user_id']]);
    $apiClientInfo = $stmt->fetch();
    $hasApiKey = !empty($apiClientInfo);
} catch (Exception $e) {
    // Tablo yoksa hata vermesin
}

// Base URL
$defaultBase = (isset($_SERVER['HTTP_HOST']) ? ((isset($_SERVER['REQUEST_SCHEME']) ? $_SERVER['REQUEST_SCHEME'] : 'https') . '://' . $_SERVER['HTTP_HOST']) : '');
$apiBaseUrl = rtrim($siteSettings['base_url'] ?? $defaultBase, '/');
$apiEndpoint = $apiBaseUrl . '/api/myservices.php';
$sdkBaseUrl = rtrim(defined('SITE_URL') && SITE_URL !== '' ? SITE_URL : $defaultBase, '/');

$pageTitle = __('api') ?: 'API';
require_once 'header.php';
?>

<style>
/* Hero Card */
.api-hero {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 20px;
    padding: 30px;
    color: var(--on-accent-color);
    margin-bottom: 25px;
    position: relative;
    overflow: hidden;
}

.api-hero::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -20%;
    width: 300px;
    height: 300px;
    background: var(--on-accent-alpha-010);
    border-radius: 50%;
}

.api-hero-content {
    position: relative;
    z-index: 1;
}

.api-hero-header {
    display: flex;
    align-items: center;
    gap: 18px;
    margin-bottom: 15px;
}

.api-hero-icon {
    width: 65px;
    height: 65px;
    background: var(--on-accent-alpha-020);
    border-radius: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.8rem;
}

.api-hero-title h1 {
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 5px;
}

.api-hero-title p {
    opacity: 0.9;
    font-size: 0.95rem;
}

.api-hero-actions {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    margin-top: 20px;
}

.hero-btn {
    padding: 12px 24px;
    border-radius: 12px;
    font-weight: 600;
    font-size: 0.9rem;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
    border: none;
    cursor: pointer;
}

.hero-btn-primary {
    background: var(--accent-action-bg-color);
    color: var(--accent-action-text-color);
}

.hero-btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.2);
}

.hero-btn-secondary {
    background: var(--on-accent-alpha-015);
    color: var(--on-accent-color);
    border: 2px solid var(--on-accent-alpha-030);
}

.hero-btn-secondary:hover {
    background: var(--on-accent-alpha-030);
}

/* API Key Status */
.api-key-status {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 15px 20px;
    background: var(--on-accent-alpha-010);
    border-radius: 12px;
    margin-top: 20px;
}

.api-key-status i {
    font-size: 1.2rem;
}

.api-key-status.active {
    background: var(--success-soft-bg);
}

.api-key-status.inactive {
    background: var(--warning-soft-bg);
}

.api-key-status span {
    font-size: 0.9rem;
}

/* Info Box */
.info-box {
    background: var(--info-soft-bg);
    border: 1px solid var(--info-soft-border);
    border-radius: 12px;
    padding: 15px 20px;
    display: flex;
    align-items: flex-start;
    gap: 12px;
    margin-bottom: 25px;
}

.info-box i {
    color: var(--info-color);
    font-size: 1.2rem;
    margin-top: 2px;
}

.info-box p {
    font-size: 0.9rem;
    line-height: 1.6;
    color: var(--text-color);
}

.info-box a {
    color: var(--accent-text-color);
    font-weight: 600;
    text-decoration: none;
}

.info-box a:hover {
    text-decoration: underline;
}

/* Warning Box */
.warning-box {
    background: var(--warning-soft-bg);
    border: 1px solid var(--warning-soft-border);
    border-radius: 12px;
    padding: 15px 20px;
    display: flex;
    align-items: flex-start;
    gap: 12px;
    margin-bottom: 25px;
}

.warning-box i {
    color: var(--warning-color);
    font-size: 1.2rem;
    margin-top: 2px;
}

.warning-box p {
    font-size: 0.9rem;
    line-height: 1.6;
    color: var(--text-color);
}

/* Doc Cards */
.doc-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    margin-bottom: 20px;
    overflow: hidden;
}

.doc-card-header {
    padding: 18px 22px;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    align-items: center;
    gap: 12px;
    background: var(--background-color);
}

.doc-card-header i {
    color: var(--accent-text-color);
    font-size: 1.1rem;
}

.doc-card-header h3 {
    font-size: 1rem;
    font-weight: 600;
}

.doc-card-body {
    padding: 22px;
}

/* Code Block */
.code-block {
    background: var(--background-color);
    border: 1px solid var(--border-color);
    border-radius: 10px;
    padding: 15px 18px;
    font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
    font-size: 0.85rem;
    color: var(--text-color);
    overflow-x: auto;
    margin: 10px 0;
    position: relative;
    white-space: pre-wrap;
    word-break: break-all;
}

.code-block .keyword { color: #e83e8c; }
.code-block .string { color: var(--success-color); }
.code-block .number { color: var(--warning-color); }
.code-block .comment { color: var(--muted-text-color); font-style: italic; }

.copy-code-btn {
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 6px 12px;
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 6px;
    font-size: 0.75rem;
    cursor: pointer;
    opacity: 0.6;
    transition: all 0.3s ease;
}

.copy-code-btn:hover {
    opacity: 1;
    background: var(--primary-color);
    color: var(--on-primary-color);
    border-color: var(--accent-text-color);
}

/* Base URL Card */
.base-url-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    padding: 20px;
    margin-bottom: 20px;
}

.base-url-label {
    font-size: 0.8rem;
    font-weight: 600;
    text-transform: uppercase;
    opacity: 0.6;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.base-url-box {
    display: flex;
    align-items: center;
    gap: 10px;
}

.base-url-input {
    flex: 1;
    padding: 14px 18px;
    background: var(--background-color);
    border: 2px solid var(--border-color);
    border-radius: 10px;
    color: var(--text-color);
    font-family: 'SFMono-Regular', Consolas, monospace;
    font-size: 0.9rem;
}

.copy-btn {
    padding: 14px 18px;
    background: var(--background-color);
    border: 2px solid var(--border-color);
    border-radius: 10px;
    color: var(--text-color);
    font-size: 1rem;
    cursor: pointer;
    transition: all 0.3s ease;
}

.copy-btn:hover {
    border-color: var(--accent-text-color);
    color: var(--accent-text-color);
}

.copy-btn.copied {
    background: var(--success-color);
    border-color: var(--success-color);
    color: var(--on-success-color);
}

.base-url-note {
    margin-top: 10px;
    font-size: 0.85rem;
    opacity: 0.7;
}

/* Endpoint Grid */
.endpoint-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 15px;
}

.endpoint-item {
    background: var(--background-color);
    border: 1px solid var(--border-color);
    border-radius: 12px;
    padding: 18px;
}

.endpoint-method {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 0.7rem;
    font-weight: 700;
    text-transform: uppercase;
    margin-bottom: 10px;
}

.endpoint-method.get {
    background: var(--success-soft-bg);
    color: var(--success-color);
}

.endpoint-method.post {
    background: rgba(0, 123, 255, 0.15);
    color: var(--info-color);
}

.endpoint-name {
    font-weight: 600;
    font-size: 0.95rem;
    margin-bottom: 8px;
    font-family: monospace;
}

.endpoint-desc {
    font-size: 0.85rem;
    opacity: 0.7;
    line-height: 1.5;
}

/* Params Table */
.params-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}

.params-table th,
.params-table td {
    padding: 12px 15px;
    text-align: left;
    border-bottom: 1px solid var(--border-color);
    font-size: 0.85rem;
}

.params-table th {
    background: var(--background-color);
    font-weight: 600;
    font-size: 0.8rem;
    text-transform: uppercase;
    opacity: 0.7;
}

.params-table tr:last-child td {
    border-bottom: none;
}

.param-name {
    font-family: monospace;
    background: var(--background-color);
    padding: 3px 8px;
    border-radius: 4px;
    font-size: 0.85rem;
}

.param-required {
    color: var(--danger-color);
    font-size: 0.7rem;
    font-weight: 600;
    margin-left: 5px;
}

.param-optional {
    color: var(--muted-text-color);
    font-size: 0.7rem;
    margin-left: 5px;
}

/* Response Example */
.response-example {
    margin-top: 15px;
}

.response-label {
    font-size: 0.85rem;
    font-weight: 600;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.response-label i {
    color: var(--success-color);
}

/* Feature List */
.feature-list {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 12px;
    margin-top: 15px;
}

.feature-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px 15px;
    background: var(--background-color);
    border-radius: 10px;
    font-size: 0.85rem;
}

.feature-item i {
    color: var(--accent-text-color);
}

/* Status Badge */
.status-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 0.75rem;
    font-weight: 600;
}

.status-badge.pending { background: var(--warning-soft-bg); color: var(--warning-color); }
.status-badge.in_progress { background: rgba(0, 123, 255, 0.15); color: var(--info-color); }
.status-badge.completed { background: var(--success-soft-bg); color: var(--success-color); }
.status-badge.partial { background: rgba(255, 193, 7, 0.15); color: var(--warning-color); }
.status-badge.canceled { background: var(--danger-soft-bg); color: var(--danger-color); }
.status-badge.refunded { background: rgba(108, 117, 125, 0.15); color: var(--muted-text-color); }

/* Responsive */
@media (max-width: 768px) {
    .api-hero {
        padding: 20px;
    }
    
    .api-hero-header {
        flex-direction: column;
        text-align: center;
    }
    
    .api-hero-title h1 {
        font-size: 1.3rem;
    }
    
    .api-hero-actions {
        justify-content: center;
    }
    
    .base-url-box {
        flex-direction: column;
    }
    
    .base-url-input {
        width: 100%;
        font-size: 0.8rem;
    }
    
    .copy-btn {
        width: 100%;
        justify-content: center;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .endpoint-grid {
        grid-template-columns: 1fr;
    }
    
    .params-table {
        font-size: 0.8rem;
    }
    
    .params-table th,
    .params-table td {
        padding: 10px 12px;
    }
    
    .code-block {
        font-size: 0.75rem;
        padding: 12px 14px;
    }
    
    .feature-list {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 480px) {
    .api-hero-icon {
        width: 50px;
        height: 50px;
        font-size: 1.4rem;
    }
    
    .hero-btn {
        width: 100%;
        justify-content: center;
    }
    
    .doc-card-body {
        padding: 15px;
    }
    
    .info-box, .warning-box {
        flex-direction: column;
        text-align: center;
    }
}
</style>

<!-- Hero Section -->
<div class="api-hero">
    <div class="api-hero-content">
        <div class="api-hero-header">
            <div class="api-hero-icon">
                <i class="fas fa-plug"></i>
            </div>
            <div class="api-hero-title">
                <h1><?php echo __('api_documentation') ?: 'API Dokümantasyonu'; ?></h1>
                <p><?php echo __('api_description_v2') ?: 'SMM Panel API v2 standardı ile uyumlu. Standart SMM API istemcileri ve benzeri sistemlerle entegre çalışır.'; ?></p>
            </div>
        </div>
        
        <div class="api-key-status <?php echo $hasApiKey ? 'active' : 'inactive'; ?>">
            <?php if ($hasApiKey): ?>
                <i class="fas fa-check-circle"></i>
                <span><?php echo __('api_key_active') ?: 'API anahtarınız aktif. Hesap sayfanızdan görüntüleyebilirsiniz.'; ?></span>
            <?php else: ?>
                <i class="fas fa-exclamation-circle"></i>
                <span><?php echo __('api_key_not_created') ?: 'Henüz API anahtarı oluşturmadınız.'; ?></span>
            <?php endif; ?>
        </div>
        
        <div class="api-hero-actions">
            <a href="/kullanici/profile.php" class="hero-btn hero-btn-primary">
                <i class="fas fa-key"></i>
                <?php echo $hasApiKey ? (__('view_api_key') ?: 'API Anahtarını Görüntüle') : (__('create_api_key') ?: 'API Anahtarı Oluştur'); ?>
            </a>
            <a href="#documentation" class="hero-btn hero-btn-secondary">
                <i class="fas fa-book"></i>
                <?php echo __('view_documentation') ?: 'Dokümantasyon'; ?>
            </a>
            <a href="<?= clean($sdkBaseUrl . '/openapi.php') ?>" target="_blank" class="hero-btn hero-btn-secondary"><i class="fas fa-code"></i> OpenAPI 3.1</a>
            <a href="<?= clean($sdkBaseUrl . '/sdk.php?sdk=php') ?>" class="hero-btn hero-btn-secondary"><i class="fab fa-php"></i> PHP SDK</a>
            <a href="<?= clean($sdkBaseUrl . '/sdk.php?sdk=python') ?>" class="hero-btn hero-btn-secondary"><i class="fab fa-python"></i> Python SDK</a>
            <a href="<?= clean($sdkBaseUrl . '/sdk.php?sdk=node') ?>" class="hero-btn hero-btn-secondary"><i class="fab fa-node-js"></i> Node SDK</a>
            <?php if(function_exists('moni_plugin_enabled')&&moni_plugin_enabled('api_sandbox',$db)): ?><a href="#sandbox-simulator" class="hero-btn hero-btn-secondary"><i class="fas fa-flask"></i> Sandbox Senaryoları</a><?php endif; ?>
        </div>
    </div>
</div>

<!-- Info Box -->
<div class="info-box">
    <i class="fas fa-info-circle"></i>
    <p>
        <?php echo __('api_key_info') ?: 'API kullanmak için bir API anahtarına ihtiyacınız var. API anahtarınızı'; ?>
        <a href="/kullanici/profile.php"><?php echo __('profile_page') ?: 'Hesap sayfanızdan'; ?></a>
        <?php echo __('api_key_info_2') ?: 'oluşturabilir ve görüntüleyebilirsiniz.'; ?>
    </p>
</div>

<!-- Warning Box -->
<div class="warning-box">
    <i class="fas fa-exclamation-triangle"></i>
    <p>
        <?php echo __('api_security_warning') ?: 'API anahtarınızı kimseyle paylaşmayın. Aşırı istek gönderimi hesabınızın askıya alınmasına neden olabilir.'; ?>
    </p>
</div>

<!-- Base URL -->
<div class="base-url-card" id="documentation">
    <div class="base-url-label">
        <i class="fas fa-link"></i>
        Base URL
    </div>
    <div class="base-url-box">
        <input type="text" class="base-url-input" value="<?php echo clean($apiEndpoint); ?>" readonly id="baseUrlInput">
        <button type="button" class="copy-btn" onclick="copyToClipboard('baseUrlInput', this)">
            <i class="fas fa-copy"></i> <span class="copy-text"><?php echo __('copy') ?: 'Kopyala'; ?></span>
        </button>
    </div>
    <p class="base-url-note">
        <span class="endpoint-method get">GET</span>
        <span class="endpoint-method post">POST</span>
        <?php echo __('both_methods_supported') ?: 'Her iki HTTP metodu da desteklenir.'; ?>
    </p>
</div>

<!-- API Features -->
<div class="doc-card">
    <div class="doc-card-header">
        <i class="fas fa-star"></i>
        <h3><?php echo __('api_features') ?: 'API Özellikleri'; ?></h3>
    </div>
    <div class="doc-card-body">
        <div class="feature-list">
            <div class="feature-item">
                <i class="fas fa-check-circle"></i>
                <span><?php echo __('feature_get_post') ?: 'GET ve POST desteği'; ?></span>
            </div>
            <div class="feature-item">
                <i class="fas fa-check-circle"></i>
                <span><?php echo __('feature_json') ?: 'JSON formatında yanıt'; ?></span>
            </div>
            <div class="feature-item">
                <i class="fas fa-check-circle"></i>
                <span><?php echo __('feature_smm_standard') ?: 'SMM Panel v2 standardı'; ?></span>
            </div>
            <div class="feature-item">
                <i class="fas fa-check-circle"></i>
                <span><?php echo __('feature_order_tracking') ?: 'Sipariş takibi'; ?></span>
            </div>
        </div>
    </div>
</div>


<?php if(function_exists('moni_plugin_enabled')&&moni_plugin_enabled('api_sandbox',$db)): $sandboxDefs=function_exists('moni_sandbox_scenarios')?moni_sandbox_scenarios():[]; ?>
<div class="doc-card" id="sandbox-simulator">
  <div class="doc-card-header"><i class="fas fa-flask"></i><h3>API Sandbox Senaryo Simülatörü</h3></div>
  <div class="doc-card-body"><p style="margin-bottom:14px;opacity:.8">Gerçek bakiye veya sağlayıcı çağrısı olmadan entegrasyonunuzun farklı sipariş yaşam döngülerine nasıl tepki verdiğini test edin. <code>add</code> isteğine <code>scenario</code> gönderin, ardından normal <code>status</code> çağrılarıyla zaman akışını izleyin.</p>
    <div class="feature-list"><?php foreach($sandboxDefs as $key=>$d):?><div class="feature-item" style="align-items:flex-start"><i class="fas fa-vial"></i><span><b><?=clean($d['label'])?></b><br><small><?=clean($d['description'])?> · ~<?=(int)$d['duration']?> sn</small><br><code><?=clean($key)?></code></span></div><?php endforeach;?></div>
    <div class="info-box" style="margin-top:16px"><i class="fas fa-terminal"></i><p>Endpoint: <code><?=clean(rtrim($sdkBaseUrl,'/').'/api/sandbox.php')?></code> · Senaryo kataloğu için <code>action=scenarios</code>. Örnek: <code>action=add&amp;service=1&amp;link=https://example.com/demo&amp;quantity=1000&amp;scenario=partial</code>.</p></div>
  </div>
</div>
<?php endif; ?>

<!-- Authentication -->
<div class="doc-card">
    <div class="doc-card-header">
        <i class="fas fa-shield-alt"></i>
        <h3><?php echo __('authentication') ?: 'Kimlik Doğrulama'; ?></h3>
    </div>
    <div class="doc-card-body">
        <p style="margin-bottom: 15px; opacity: 0.8;">
            <?php echo __('auth_description') ?: 'Tüm isteklerde <code>key</code> parametresi zorunludur.'; ?>
        </p>
        <table class="params-table">
            <thead>
                <tr>
                    <th><?php echo __('parameter') ?: 'Parametre'; ?></th>
                    <th><?php echo __('type') ?: 'Tip'; ?></th>
                    <th><?php echo __('description') ?: 'Açıklama'; ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><span class="param-name">key</span><span class="param-required"><?php echo __('required') ?: 'zorunlu'; ?></span></td>
                    <td>string</td>
                    <td><?php echo __('api_key_param_desc') ?: 'Profilinizden aldığınız API anahtarı'; ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Endpoints Overview -->
<div class="doc-card">
    <div class="doc-card-header">
        <i class="fas fa-route"></i>
        <h3><?php echo __('endpoints') ?: 'Endpoints'; ?></h3>
    </div>
    <div class="doc-card-body">
        <div class="endpoint-grid">
            <div class="endpoint-item">
                <span class="endpoint-method get">GET</span>
                <span class="endpoint-method post">POST</span>
                <div class="endpoint-name">action=balance</div>
                <div class="endpoint-desc"><?php echo __('balance_endpoint_desc') ?: 'Hesap bakiyenizi sorgular.'; ?></div>
            </div>
            <div class="endpoint-item">
                <span class="endpoint-method get">GET</span>
                <span class="endpoint-method post">POST</span>
                <div class="endpoint-name">action=services</div>
                <div class="endpoint-desc"><?php echo __('services_endpoint_desc') ?: 'Tüm aktif servisleri listeler.'; ?></div>
            </div>
            <div class="endpoint-item">
                <span class="endpoint-method post">POST</span>
                <div class="endpoint-name">action=add</div>
                <div class="endpoint-desc"><?php echo __('add_endpoint_desc') ?: 'Yeni sipariş oluşturur.'; ?></div>
            </div>
            <div class="endpoint-item">
                <span class="endpoint-method get">GET</span>
                <span class="endpoint-method post">POST</span>
                <div class="endpoint-name">action=status</div>
                <div class="endpoint-desc"><?php echo __('status_endpoint_desc') ?: 'Sipariş durumunu sorgular.'; ?></div>
            </div>
        </div>
    </div>
</div>

<!-- Balance Endpoint -->
<div class="doc-card">
    <div class="doc-card-header">
        <i class="fas fa-wallet"></i>
        <h3>action=balance</h3>
    </div>
    <div class="doc-card-body">
        <p style="margin-bottom: 15px; opacity: 0.8;">
            <?php echo __('balance_endpoint_info') ?: 'Hesap bakiyenizi TRY cinsinden sorgular.'; ?>
        </p>
        
        <table class="params-table">
            <thead>
                <tr>
                    <th><?php echo __('parameter') ?: 'Parametre'; ?></th>
                    <th><?php echo __('type') ?: 'Tip'; ?></th>
                    <th><?php echo __('description') ?: 'Açıklama'; ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><span class="param-name">key</span><span class="param-required"><?php echo __('required') ?: 'zorunlu'; ?></span></td>
                    <td>string</td>
                    <td>API <?php echo __('key') ?: 'anahtarı'; ?></td>
                </tr>
                <tr>
                    <td><span class="param-name">action</span><span class="param-required"><?php echo __('required') ?: 'zorunlu'; ?></span></td>
                    <td>string</td>
                    <td>balance</td>
                </tr>
            </tbody>
        </table>
        
        <div class="response-example">
            <div class="response-label">
                <i class="fas fa-check-circle"></i> 
                <?php echo __('example_response') ?: 'Örnek Yanıt'; ?>
            </div>
            <div class="code-block">
                <button class="copy-code-btn" onclick="copyCode(this)"><i class="fas fa-copy"></i></button>
{
    "<span class="keyword">balance</span>": "<span class="string">125.50</span>",
    "<span class="keyword">currency</span>": "<span class="string">TRY</span>"
}</div>
        </div>
    </div>
</div>

<!-- Services Endpoint -->
<div class="doc-card">
    <div class="doc-card-header">
        <i class="fas fa-list"></i>
        <h3>action=services</h3>
    </div>
    <div class="doc-card-body">
        <p style="margin-bottom: 15px; opacity: 0.8;">
            <?php echo __('services_endpoint_info') ?: 'Tüm aktif servislerin listesini getirir.'; ?>
        </p>
        
        <table class="params-table">
            <thead>
                <tr>
                    <th><?php echo __('parameter') ?: 'Parametre'; ?></th>
                    <th><?php echo __('type') ?: 'Tip'; ?></th>
                    <th><?php echo __('description') ?: 'Açıklama'; ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><span class="param-name">key</span><span class="param-required"><?php echo __('required') ?: 'zorunlu'; ?></span></td>
                    <td>string</td>
                    <td>API <?php echo __('key') ?: 'anahtarı'; ?></td>
                </tr>
                <tr>
                    <td><span class="param-name">action</span><span class="param-required"><?php echo __('required') ?: 'zorunlu'; ?></span></td>
                    <td>string</td>
                    <td>services</td>
                </tr>
            </tbody>
        </table>
        
        <div class="response-example">
            <div class="response-label">
                <i class="fas fa-check-circle"></i> 
                <?php echo __('example_response') ?: 'Örnek Yanıt'; ?>
            </div>
            <div class="code-block">
                <button class="copy-code-btn" onclick="copyCode(this)"><i class="fas fa-copy"></i></button>
[
    {
        "<span class="keyword">service</span>": "<span class="string">1</span>",
        "<span class="keyword">name</span>": "<span class="string">Instagram Takipçi [TRY]</span>",
        "<span class="keyword">type</span>": "<span class="string">default</span>",
        "<span class="keyword">category</span>": "<span class="string">Instagram</span>",
        "<span class="keyword">rate</span>": "<span class="string">45.00</span>",
        "<span class="keyword">min</span>": "<span class="string">100</span>",
        "<span class="keyword">max</span>": "<span class="string">10000</span>",
        "<span class="keyword">dripfeed</span>": <span class="number">false</span>,
        "<span class="keyword">refill</span>": <span class="number">false</span>,
        "<span class="keyword">cancel</span>": <span class="number">true</span>
    }
]</div>
        </div>
        
        <p style="margin-top: 15px; font-size: 0.85rem; opacity: 0.7;">
            <i class="fas fa-info-circle"></i> 
            <?php echo __('rate_info') ?: '<code>rate</code> değeri 1000 adet için TRY fiyatını gösterir.'; ?>
        </p>
    </div>
</div>

<!-- Add Order Endpoint -->
<div class="doc-card">
    <div class="doc-card-header">
        <i class="fas fa-cart-plus"></i>
        <h3>action=add</h3>
    </div>
    <div class="doc-card-body">
        <p style="margin-bottom: 15px; opacity: 0.8;">
            <?php echo __('add_endpoint_info') ?: 'Yeni sipariş oluşturur. Bakiyenizden otomatik düşülür.'; ?>
        </p>
        
        <table class="params-table">
            <thead>
                <tr>
                    <th><?php echo __('parameter') ?: 'Parametre'; ?></th>
                    <th><?php echo __('type') ?: 'Tip'; ?></th>
                    <th><?php echo __('description') ?: 'Açıklama'; ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><span class="param-name">key</span><span class="param-required"><?php echo __('required') ?: 'zorunlu'; ?></span></td>
                    <td>string</td>
                    <td>API <?php echo __('key') ?: 'anahtarı'; ?></td>
                </tr>
                <tr>
                    <td><span class="param-name">action</span><span class="param-required"><?php echo __('required') ?: 'zorunlu'; ?></span></td>
                    <td>string</td>
                    <td>add</td>
                </tr>
                <tr>
                    <td><span class="param-name">service</span><span class="param-required"><?php echo __('required') ?: 'zorunlu'; ?></span></td>
                    <td>integer</td>
                    <td><?php echo __('service_id_desc') ?: 'Servis ID numarası'; ?></td>
                </tr>
                <tr>
                    <td><span class="param-name">link</span><span class="param-required"><?php echo __('required') ?: 'zorunlu'; ?></span></td>
                    <td>string</td>
                    <td><?php echo __('link_desc') ?: 'Hedef URL (profil, gönderi vb.)'; ?></td>
                </tr>
                <tr>
                    <td><span class="param-name">quantity</span><span class="param-required"><?php echo __('required') ?: 'zorunlu'; ?></span></td>
                    <td>integer</td>
                    <td><?php echo __('quantity_desc') ?: 'Sipariş miktarı (min-max aralığında)'; ?></td>
                </tr>
            </tbody>
        </table>
        
        <div class="response-example">
            <div class="response-label">
                <i class="fas fa-check-circle"></i> 
                <?php echo __('success_response') ?: 'Başarılı Yanıt'; ?>
            </div>
            <div class="code-block">
                <button class="copy-code-btn" onclick="copyCode(this)"><i class="fas fa-copy"></i></button>
{
    "<span class="keyword">order</span>": <span class="number">12345</span>
}</div>
        </div>
        
        <p style="margin-top: 15px; font-size: 0.85rem; opacity: 0.7;">
            <i class="fas fa-calculator"></i> 
            <?php echo __('price_formula') ?: 'Fiyat hesaplama: <code>(quantity / 1000) × rate</code>'; ?>
        </p>
    </div>
</div>

<!-- Status Endpoint -->
<div class="doc-card">
    <div class="doc-card-header">
        <i class="fas fa-search"></i>
        <h3>action=status</h3>
    </div>
    <div class="doc-card-body">
        <p style="margin-bottom: 15px; opacity: 0.8;">
            <?php echo __('status_endpoint_info') ?: 'Mevcut bir siparişin durumunu sorgular.'; ?>
        </p>
        
        <table class="params-table">
            <thead>
                <tr>
                    <th><?php echo __('parameter') ?: 'Parametre'; ?></th>
                    <th><?php echo __('type') ?: 'Tip'; ?></th>
                    <th><?php echo __('description') ?: 'Açıklama'; ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><span class="param-name">key</span><span class="param-required"><?php echo __('required') ?: 'zorunlu'; ?></span></td>
                    <td>string</td>
                    <td>API <?php echo __('key') ?: 'anahtarı'; ?></td>
                </tr>
                <tr>
                    <td><span class="param-name">action</span><span class="param-required"><?php echo __('required') ?: 'zorunlu'; ?></span></td>
                    <td>string</td>
                    <td>status</td>
                </tr>
                <tr>
                    <td><span class="param-name">order</span><span class="param-required"><?php echo __('required') ?: 'zorunlu'; ?></span></td>
                    <td>integer</td>
                    <td><?php echo __('order_id_desc') ?: 'Sipariş ID numarası'; ?></td>
                </tr>
            </tbody>
        </table>
        
        <div class="response-example">
            <div class="response-label">
                <i class="fas fa-check-circle"></i> 
                <?php echo __('example_response') ?: 'Örnek Yanıt'; ?>
            </div>
            <div class="code-block">
                <button class="copy-code-btn" onclick="copyCode(this)"><i class="fas fa-copy"></i></button>
{
    "<span class="keyword">status</span>": "<span class="string">in_progress</span>",
    "<span class="keyword">start_count</span>": "<span class="string">1500</span>",
    "<span class="keyword">remains</span>": "<span class="string">500</span>",
    "<span class="keyword">currency</span>": "<span class="string">TRY</span>"
}</div>
        </div>
    </div>
</div>

<!-- Order Statuses -->
<div class="doc-card">
    <div class="doc-card-header">
        <i class="fas fa-info-circle"></i>
        <h3><?php echo __('order_statuses') ?: 'Sipariş Durumları'; ?></h3>
    </div>
    <div class="doc-card-body">
        <table class="params-table">
            <thead>
                <tr>
                    <th><?php echo __('status') ?: 'Durum'; ?></th>
                    <th><?php echo __('description') ?: 'Açıklama'; ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><span class="status-badge pending">pending</span></td>
                    <td><?php echo __('status_pending') ?: 'Sipariş beklemede'; ?></td>
                </tr>
                <tr>
                    <td><span class="status-badge in_progress">in_progress</span></td>
                    <td><?php echo __('status_in_progress') ?: 'Sipariş işleniyor'; ?></td>
                </tr>
                <tr>
                    <td><span class="status-badge completed">completed</span></td>
                    <td><?php echo __('status_completed') ?: 'Sipariş tamamlandı'; ?></td>
                </tr>
                <tr>
                    <td><span class="status-badge partial">partial</span></td>
                    <td><?php echo __('status_partial') ?: 'Kısmi tamamlandı (kalan iade edildi)'; ?></td>
                </tr>
                <tr>
                    <td><span class="status-badge canceled">canceled</span></td>
                    <td><?php echo __('status_canceled') ?: 'Sipariş iptal edildi'; ?></td>
                </tr>
                <tr>
                    <td><span class="status-badge refunded">refunded</span></td>
                    <td><?php echo __('status_refunded') ?: 'Sipariş iade edildi'; ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Example Requests -->
<div class="doc-card">
    <div class="doc-card-header">
        <i class="fas fa-terminal"></i>
        <h3><?php echo __('example_requests') ?: 'Örnek İstekler'; ?></h3>
    </div>
    <div class="doc-card-body">
        <p style="margin-bottom: 8px;"><strong>1. <?php echo __('balance_query') ?: 'Bakiye Sorgulama'; ?>:</strong></p>
        <div class="code-block">
            <button class="copy-code-btn" onclick="copyCode(this)"><i class="fas fa-copy"></i></button>
curl -H "X-API-Key: API_KEY" "<?php echo clean($apiEndpoint); ?>?action=balance"</div>
        
        <p style="margin: 20px 0 8px;"><strong>2. <?php echo __('service_list') ?: 'Servis Listesi'; ?>:</strong></p>
        <div class="code-block">
            <button class="copy-code-btn" onclick="copyCode(this)"><i class="fas fa-copy"></i></button>
curl -H "X-API-Key: API_KEY" "<?php echo clean($apiEndpoint); ?>?action=services"</div>
        
        <p style="margin: 20px 0 8px;"><strong>3. <?php echo __('create_order') ?: 'Sipariş Oluşturma'; ?>:</strong></p>
        <div class="code-block">
            <button class="copy-code-btn" onclick="copyCode(this)"><i class="fas fa-copy"></i></button>
curl -X POST "<?php echo clean($apiEndpoint); ?>" \
  -H "X-API-Key: API_KEY" \
  -H "X-Idempotency-Key: benzersiz-istek-123" \
  -d "action=add" \
  -d "service=1" \
  -d "link=https://instagram.com/kullanici" \
  -d "quantity=1000"</div>
        
        <p style="margin: 20px 0 8px;"><strong>4. <?php echo __('order_status') ?: 'Sipariş Durumu'; ?>:</strong></p>
        <div class="code-block">
            <button class="copy-code-btn" onclick="copyCode(this)"><i class="fas fa-copy"></i></button>
curl -H "X-API-Key: API_KEY" "<?php echo clean($apiEndpoint); ?>?action=status&order=12345"</div>
    </div>
</div>

<!-- PHP Example -->
<div class="doc-card">
    <div class="doc-card-header">
        <i class="fab fa-php"></i>
        <h3>PHP <?php echo __('example') ?: 'Örneği'; ?></h3>
    </div>
    <div class="doc-card-body">
        <div class="code-block">
            <button class="copy-code-btn" onclick="copyCode(this)"><i class="fas fa-copy"></i></button>
&lt;?php
$apiUrl = "<?php echo clean($apiEndpoint); ?>";
$apiKey = "API_KEY";

function apiRequest($url, $key, $params, $idempotencyKey = null) {
    $ch = curl_init($url);
    $headers = ["X-API-Key: " . $key];
    if ($idempotencyKey) {
        $headers[] = "X-Idempotency-Key: " . $idempotencyKey;
    }
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}

function getBalance($url, $key) {
    return apiRequest($url, $key, ["action" =&gt; "balance"]);
}

function getServices($url, $key) {
    return apiRequest($url, $key, ["action" =&gt; "services"]);
}

function addOrder($url, $key, $serviceId, $link, $quantity) {
    return apiRequest($url, $key, [
        "action" =&gt; "add",
        "service" =&gt; $serviceId,
        "link" =&gt; $link,
        "quantity" =&gt; $quantity
    ], bin2hex(random_bytes(16)));
}

function getStatus($url, $key, $orderId) {
    return apiRequest($url, $key, ["action" =&gt; "status", "order" =&gt; $orderId]);
}

// Kullanım
$balance = getBalance($apiUrl, $apiKey);
print_r($balance);

$services = getServices($apiUrl, $apiKey);
print_r($services);

$order = addOrder($apiUrl, $apiKey, 1, "https://instagram.com/kullanici", 1000);
print_r($order);

if (isset($order["order"])) {
    $status = getStatus($apiUrl, $apiKey, $order["order"]);
    print_r($status);
}
?&gt;</div>
    </div>
</div>

<!-- Error Responses -->
<div class="doc-card">
    <div class="doc-card-header">
        <i class="fas fa-exclamation-triangle"></i>
        <h3><?php echo __('error_responses') ?: 'Hata Yanıtları'; ?></h3>
    </div>
    <div class="doc-card-body">
        <table class="params-table">
            <thead>
                <tr>
                    <th><?php echo __('error') ?: 'Hata'; ?></th>
                    <th><?php echo __('description') ?: 'Açıklama'; ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><span class="param-name">API Key is missing</span></td>
                    <td><?php echo __('error_key_missing') ?: 'API anahtarı gönderilmedi'; ?></td>
                </tr>
                <tr>
                    <td><span class="param-name">Invalid API Key</span></td>
                    <td><?php echo __('error_invalid_key') ?: 'Geçersiz veya pasif API anahtarı'; ?></td>
                </tr>
                <tr>
                    <td><span class="param-name">Invalid action</span></td>
                    <td><?php echo __('error_invalid_action') ?: 'Geçersiz action parametresi'; ?></td>
                </tr>
                <tr>
                    <td><span class="param-name">Missing parameters</span></td>
                    <td><?php echo __('error_missing_params') ?: 'Zorunlu parametreler eksik'; ?></td>
                </tr>
                <tr>
                    <td><span class="param-name">Service ID not found</span></td>
                    <td><?php echo __('error_service_not_found') ?: 'Servis bulunamadı veya pasif'; ?></td>
                </tr>
                <tr>
                    <td><span class="param-name">Quantity below minimum</span></td>
                    <td><?php echo __('error_qty_below_min') ?: 'Miktar minimum limitin altında'; ?></td>
                </tr>
                <tr>
                    <td><span class="param-name">Quantity above maximum</span></td>
                    <td><?php echo __('error_qty_above_max') ?: 'Miktar maksimum limitin üstünde'; ?></td>
                </tr>
                <tr>
                    <td><span class="param-name">Not enough funds</span></td>
                    <td><?php echo __('error_not_enough_funds') ?: 'Yetersiz bakiye'; ?></td>
                </tr>
                <tr>
                    <td><span class="param-name">Order not found</span></td>
                    <td><?php echo __('error_order_not_found') ?: 'Sipariş bulunamadı'; ?></td>
                </tr>
                <tr>
                    <td><span class="param-name">System error</span></td>
                    <td><?php echo __('error_system') ?: 'Sistem hatası oluştu'; ?></td>
                </tr>
            </tbody>
        </table>
        
        <div class="response-example" style="margin-top: 20px;">
            <div class="response-label">
                <i class="fas fa-times-circle" style="color: var(--danger-color);"></i> 
                <?php echo __('error_response_example') ?: 'Hata Yanıt Örneği'; ?>
            </div>
            <div class="code-block">
                <button class="copy-code-btn" onclick="copyCode(this)"><i class="fas fa-copy"></i></button>
{
    "<span class="keyword">error</span>": "<span class="string">Not enough funds</span>"
}</div>
        </div>
    </div>
</div>

<!-- Important Notes -->
<div class="doc-card">
    <div class="doc-card-header">
        <i class="fas fa-lightbulb"></i>
        <h3><?php echo __('important_notes') ?: 'Önemli Notlar'; ?></h3>
    </div>
    <div class="doc-card-body">
        <div class="feature-list">
            <div class="feature-item">
                <i class="fas fa-lira-sign"></i>
                <span><?php echo __('note_currency') ?: 'Tüm fiyatlar TRY (Türk Lirası) cinsindendir'; ?></span>
            </div>
            <div class="feature-item">
                <i class="fas fa-calculator"></i>
                <span><?php echo __('note_rate') ?: '<code>rate</code> değeri 1000 adet için fiyattır'; ?></span>
            </div>
            <div class="feature-item">
                <i class="fas fa-quote-left"></i>
                <span><?php echo __('note_string_values') ?: 'Tüm değerler string olarak döner'; ?></span>
            </div>
            <div class="feature-item">
                <i class="fas fa-shield-alt"></i>
                <span><?php echo __('note_api_key_security') ?: 'API anahtarınızı kimseyle paylaşmayın'; ?></span>
            </div>
        </div>
    </div>
</div>

<script>
function copyToClipboard(inputId, btn) {
    var input = document.getElementById(inputId);
    input.select();
    input.setSelectionRange(0, 99999);
    
    navigator.clipboard.writeText(input.value).then(function() {
        btn.classList.add('copied');
        var copyText = btn.querySelector('.copy-text');
        if (copyText) {
            copyText.textContent = '<?php echo __('copied') ?: 'Kopyalandı'; ?>';
        }
        btn.querySelector('i').className = 'fas fa-check';
        
        setTimeout(function() {
            btn.classList.remove('copied');
            if (copyText) {
                copyText.textContent = '<?php echo __('copy') ?: 'Kopyala'; ?>';
            }
            btn.querySelector('i').className = 'fas fa-copy';
        }, 2000);
    });
}

function copyCode(btn) {
    var codeBlock = btn.parentElement;
    var code = codeBlock.innerText;
    
    // Remove button text and clean up
    code = code.replace(/^\s*\n/, '').trim();
    
    // Decode HTML entities
    var textarea = document.createElement('textarea');
    textarea.innerHTML = code;
    code = textarea.value;
    
    navigator.clipboard.writeText(code).then(function() {
        btn.innerHTML = '<i class="fas fa-check"></i>';
        
        setTimeout(function() {
            btn.innerHTML = '<i class="fas fa-copy"></i>';
        }, 2000);
    });
}
</script>

<?php require_once 'footer.php'; ?>