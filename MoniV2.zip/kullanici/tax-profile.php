<?php
require_once __DIR__.'/../config.php';
if(!isLoggedIn()){header('Location: /login.php');exit;}
if(!moni_plugin_enabled('tax_vat',$db) && !moni_plugin_enabled('e_invoice',$db)){header('Location: /kullanici/');exit;}
$userId=(int)$_SESSION['user_id'];$success='';$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $type=($_POST['customer_type']??'individual')==='company'?'company':'individual';
    $country=strtoupper(preg_replace('/[^A-Z]/i','',(string)($_POST['country_code']??'TR')));$country=substr($country?:'TR',0,2);
    $email=trim((string)($_POST['invoice_email']??''));
    if($email!==''&&!filter_var($email,FILTER_VALIDATE_EMAIL)){$error='Geçerli bir fatura e-posta adresi girin.';}
    else{
        $st=$db->prepare("INSERT INTO user_tax_profiles(user_id,customer_type,legal_name,tax_office,tax_number,national_id,country_code,city,address,invoice_email) VALUES(?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE customer_type=VALUES(customer_type),legal_name=VALUES(legal_name),tax_office=VALUES(tax_office),tax_number=VALUES(tax_number),national_id=VALUES(national_id),country_code=VALUES(country_code),city=VALUES(city),address=VALUES(address),invoice_email=VALUES(invoice_email),updated_at=NOW()");
        $st->execute([$userId,$type,trim((string)($_POST['legal_name']??'')),trim((string)($_POST['tax_office']??'')),trim((string)($_POST['tax_number']??'')),trim((string)($_POST['national_id']??'')),$country,trim((string)($_POST['city']??'')),trim((string)($_POST['address']??'')),$email]);
        moni_security_event($userId,'billing_profile_updated','info');$success='Fatura/vergi bilgileriniz kaydedildi.';
    }
}
$st=$db->prepare("SELECT * FROM user_tax_profiles WHERE user_id=?");$st->execute([$userId]);$p=$st->fetch(PDO::FETCH_ASSOC)?:['customer_type'=>'individual','country_code'=>'TR'];
$pageTitle='Fatura ve Vergi Bilgilerim';require_once 'header.php';
?>
<style>.tp-wrap{max-width:960px;margin:0 auto}.tp-card{background:var(--card-bg-color);border:1px solid var(--border-color);border-radius:18px;padding:24px}.tp-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.tp-field{display:flex;flex-direction:column;gap:7px}.tp-field.full{grid-column:1/-1}.tp-field label{font-size:.88rem;font-weight:650}.tp-field input,.tp-field select,.tp-field textarea{width:100%;padding:12px 13px;border:1px solid var(--border-color);border-radius:10px;background:var(--input-bg-color,var(--card-bg-color));color:var(--text-color)}.tp-field textarea{min-height:100px;resize:vertical}.tp-btn{border:0;border-radius:10px;padding:12px 18px;background:var(--primary-color);color:var(--on-primary-color);font-weight:700;cursor:pointer}.tp-note{padding:13px;border-radius:10px;margin-bottom:16px;background:rgba(59,130,246,.08)}.tp-ok{background:rgba(34,197,94,.1)}.tp-bad{background:rgba(239,68,68,.1)}@media(max-width:700px){.tp-grid{grid-template-columns:1fr}}</style>
<div class="tp-wrap"><div class="tp-card"><h2>Fatura ve Vergi Bilgilerim</h2><p>e-Fatura/e-Arşiv veya KDV profili aktif olduğunda belgelerde kullanılacak bilgileri buradan yönetin.</p>
<?php if($success):?><div class="tp-note tp-ok"><?=clean($success)?></div><?php endif;?><?php if($error):?><div class="tp-note tp-bad"><?=clean($error)?></div><?php endif;?>
<form method="post"><div class="tp-grid">
<div class="tp-field"><label>Müşteri tipi</label><select name="customer_type"><option value="individual" <?=$p['customer_type']==='individual'?'selected':''?>>Bireysel</option><option value="company" <?=$p['customer_type']==='company'?'selected':''?>>Kurumsal</option></select></div>
<div class="tp-field"><label>Ülke kodu</label><input name="country_code" maxlength="2" value="<?=clean($p['country_code']??'TR')?>"></div>
<div class="tp-field full"><label>Ad Soyad / Ticari Ünvan</label><input name="legal_name" maxlength="255" value="<?=clean($p['legal_name']??'')?>"></div>
<div class="tp-field"><label>Vergi dairesi</label><input name="tax_office" maxlength="190" value="<?=clean($p['tax_office']??'')?>"></div>
<div class="tp-field"><label>Vergi numarası</label><input name="tax_number" maxlength="50" value="<?=clean($p['tax_number']??'')?>"></div>
<div class="tp-field"><label>T.C. kimlik / yerel kimlik no</label><input name="national_id" maxlength="50" value="<?=clean($p['national_id']??'')?>"></div>
<div class="tp-field"><label>Şehir</label><input name="city" maxlength="120" value="<?=clean($p['city']??'')?>"></div>
<div class="tp-field full"><label>Adres</label><textarea name="address"><?=clean($p['address']??'')?></textarea></div>
<div class="tp-field full"><label>Fatura e-posta adresi</label><input type="email" name="invoice_email" value="<?=clean($p['invoice_email']??'')?>"></div>
<div class="tp-field full"><div><button class="tp-btn" type="submit">Bilgileri Kaydet</button></div></div>
</div></form></div></div>
<?php require_once 'footer.php'; ?>
