<?php
/**
 * Kullanıcı Paneli - Gelişmiş Servis Karşılaştırma
 */
require_once __DIR__ . '/../config.php';

/* ================= AJAX (header'dan önce) ================= */
if (isset($_GET['ajax'])) {
    header('Content-Type: application/json; charset=utf-8');

    if (!isLoggedIn()) {
        echo json_encode(['success' => false, 'error' => __('login_required') ?: 'Oturum gerekli'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Tüm veriler
    if ($_GET['ajax'] === 'load_data') {
        try {
            $catStmt = $db->query("SELECT c.id, c.name, COUNT(s.id) as service_count 
                                   FROM categories c 
                                   LEFT JOIN services s ON c.id = s.category_id AND s.status = 'active'
                                   WHERE c.status = 'active' 
                                   GROUP BY c.id HAVING service_count > 0
                                   ORDER BY c.sort_order ASC, c.name ASC");
            $categories = $catStmt->fetchAll(PDO::FETCH_ASSOC);

            $srvStmt = $db->query("SELECT s.id, s.name, s.price_per_1000, s.min_quantity, s.max_quantity,
                                          s.refill, s.refill_days, s.cancel, s.dripfeed, s.category_id,
                                          c.name as category_name
                                   FROM services s 
                                   LEFT JOIN categories c ON s.category_id = c.id
                                   WHERE s.status = 'active' AND c.status = 'active'
                                   ORDER BY c.sort_order ASC, s.sort_order ASC, s.name ASC");
            $rawServices = $srvStmt->fetchAll(PDO::FETCH_ASSOC);

            $services = [];
            foreach ($rawServices as $srv) {
                if (function_exists('moni_service_visible_to_user') && !moni_service_visible_to_user($db,(int)$srv['id'],(int)$_SESSION['user_id'])) continue;
                $services[] = [
                    'id' => (int)$srv['id'],
                    'name' => $srv['name'],
                    'price_per_1000' => moni_effective_price_per_1000($srv, (int)$_SESSION['user_id']),
                    'min_quantity' => (int)$srv['min_quantity'],
                    'max_quantity' => (int)$srv['max_quantity'],
                    'refill' => (int)$srv['refill'],
                    'refill_days' => (int)$srv['refill_days'],
                    'cancel' => (int)$srv['cancel'],
                    'dripfeed' => (int)$srv['dripfeed'],
                    'category_id' => (int)$srv['category_id'],
                    'category_name' => $srv['category_name']
                ];
            }

            echo json_encode(['success' => true, 'categories' => $categories, 'services' => $services], JSON_UNESCAPED_UNICODE);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
        }
        exit;
    }

    // Karşılaştırma
    if ($_GET['ajax'] === 'compare') {
        $servicesParam = isset($_GET['services']) ? trim($_GET['services']) : '';
        if (empty($servicesParam)) {
            echo json_encode(['success' => false, 'error' => __('select_services') ?: 'Servis seçin'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $parts = explode(',', $servicesParam);
        $uniqueIds = [];
        foreach ($parts as $part) {
            $id = (int)trim($part);
            if ($id > 0) $uniqueIds[$id] = true;
        }
        $serviceIds = array_keys($uniqueIds);
        $priceMode = isset($_GET['price_mode']) && $_GET['price_mode'] === '1';

        if (count($serviceIds) < 2) {
            echo json_encode(['success' => false, 'error' => __('min_2_services') ?: 'En az 2 farklı servis seçin'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        if (count($serviceIds) > 5) {
            echo json_encode(['success' => false, 'error' => __('max_5_services') ?: 'En fazla 5 servis seçebilirsiniz'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        try {
            $services = [];
            foreach ($serviceIds as $srvId) {
                $stmt = $db->prepare("SELECT s.*, c.name as category_name 
                                      FROM services s 
                                      LEFT JOIN categories c ON s.category_id = c.id 
                                      WHERE s.id = ? AND s.status = 'active'");
                $stmt->execute([$srvId]);
                $srv = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($srv) {
                    $srv['id'] = (int)$srv['id'];
                    if (function_exists('moni_service_visible_to_user') && !moni_service_visible_to_user($db,(int)$srv['id'],(int)$_SESSION['user_id'])) continue;
                    $srv['price_per_1000'] = moni_effective_price_per_1000($srv, (int)$_SESSION['user_id']);
                    $srv['maintenance_reason'] = moni_maintenance_reason((int)$srv['id'], (int)($srv['api_provider_id'] ?? 0));
                    $services[] = $srv;
                }
            }

            if (count($services) < 2) {
                echo json_encode(['success' => false, 'error' => __('services_not_found') ?: 'Yeterli servis bulunamadı'], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $results = [];
            $thirtyDaysAgo = date('Y-m-d H:i:s', strtotime('-30 days'));
            $ratingMap = function_exists('moni_service_ratings') ? moni_service_ratings($db,array_column($services,'id')) : [];

            $orderCounts = [];
            foreach ($services as $s) {
                $c = $db->prepare("SELECT COUNT(*) FROM orders WHERE service_id = ? AND created_at >= ?");
                $c->execute([$s['id'], $thirtyDaysAgo]);
                $orderCounts[$s['id']] = (int)$c->fetchColumn();
            }
            $maxOrders = max($orderCounts) ?: 1;

            $prices = array_column($services, 'price_per_1000');
            $minPrice = (float)min($prices);
            $maxPrice = (float)max($prices);
            $priceRange = $maxPrice - $minPrice;

            foreach ($services as $srv) {
                $sid = (int)$srv['id'];
                $a = ['service' => $srv, 'stats' => [], 'scores' => [], 'strengths' => [], 'weaknesses' => []];

                $totalOrders = $orderCounts[$sid] ?? 0;
                $a['stats']['total_orders'] = $totalOrders;

                $q = $db->prepare("SELECT COUNT(*) FROM orders WHERE service_id=? AND status='completed' AND created_at>=?");
                $q->execute([$sid, $thirtyDaysAgo]);
                $completed = (int)$q->fetchColumn();
                $a['stats']['completed_orders'] = $completed;
                $compRate = $totalOrders > 0 ? round(($completed / $totalOrders) * 100, 1) : 0;
                $a['stats']['completion_rate'] = $compRate;

                $q = $db->prepare("SELECT AVG(TIMESTAMPDIFF(MINUTE, created_at, updated_at)) FROM orders 
                                   WHERE service_id=? AND status='completed' AND created_at>=? AND updated_at>created_at");
                $q->execute([$sid, $thirtyDaysAgo]);
                $avgTime = $q->fetchColumn();
                $a['stats']['avg_completion_time'] = $avgTime ? round($avgTime) : null;

                $q = $db->prepare("SELECT COUNT(*) FROM orders WHERE service_id=? AND status IN ('error','cancelled','refunded') AND created_at>=?");
                $q->execute([$sid, $thirtyDaysAgo]);
                $errors = (int)$q->fetchColumn();
                $errorRate = $totalOrders > 0 ? round(($errors / $totalOrders) * 100, 1) : 0;
                $a['stats']['error_rate'] = $errorRate;

                $refillRate = null;
                if ($srv['refill']) {
                    $q = $db->prepare("SELECT COUNT(*) FROM refill_requests r JOIN orders o ON r.order_id=o.id WHERE o.service_id=?");
                    $q->execute([$sid]);
                    $totalRef = (int)$q->fetchColumn();
                    if ($totalRef > 0) {
                        $q = $db->prepare("SELECT COUNT(*) FROM refill_requests r JOIN orders o ON r.order_id=o.id WHERE o.service_id=? AND r.status='completed'");
                        $q->execute([$sid]);
                        $appRef = (int)$q->fetchColumn();
                        $refillRate = round(($appRef / $totalRef) * 100, 1);
                    }
                }
                $a['stats']['refill_rate'] = $refillRate;

                $dripRate = null;
                if ($srv['dripfeed']) {
                    $q = $db->prepare("SELECT COUNT(*) FROM orders_dripfeed WHERE service_id=?");
                    $q->execute([$sid]);
                    $totalDrip = (int)$q->fetchColumn();
                    if ($totalDrip > 0) {
                        $q = $db->prepare("SELECT COUNT(*) FROM orders_dripfeed WHERE service_id=? AND status='completed'");
                        $q->execute([$sid]);
                        $compDrip = (int)$q->fetchColumn();
                        $dripRate = round(($compDrip / $totalDrip) * 100, 1);
                    }
                }
                $a['stats']['dripfeed_rate'] = $dripRate;
                $rating = $ratingMap[$sid] ?? ['avg'=>0.0,'count'=>0];
                $a['stats']['customer_rating'] = (float)($rating['avg']??0);
                $a['stats']['rating_count'] = (int)($rating['count']??0);

                $a['scores']['price'] = $priceRange > 0 ? round(10 - ((floatval($srv['price_per_1000']) - $minPrice) / $priceRange * 9), 1) : 10;
                $a['scores']['completion'] = round(max(1, min(10, $compRate / 10)), 1);
                $spd = $a['stats']['avg_completion_time'] ? 10 - (($a['stats']['avg_completion_time'] - 30) / 150) : 5;
                $a['scores']['speed'] = round(max(1, min(10, $spd)), 1);
                $a['scores']['reliability'] = round(max(1, min(10, 10 - ($errorRate / 10))), 1);
                $rs = $srv['refill'] ? (($refillRate !== null ? $refillRate / 10 : 7) + min(2, intval($srv['refill_days']) / 30)) : 2;
                $a['scores']['refill'] = round(max(1, min(10, $rs)), 1);
                $a['scores']['dripfeed'] = $srv['dripfeed'] ? round(max(1, min(10, $dripRate !== null ? $dripRate / 10 : 7)), 1) : 2;
                $a['scores']['popularity'] = round(max(1, ($totalOrders / $maxOrders) * 10), 1);
                $a['scores']['customer_rating'] = $a['stats']['rating_count'] > 0 ? round(max(1,min(10,$a['stats']['customer_rating']*2)),1) : 5.0;

                $w = $priceMode 
                    ? ['price'=>0.32,'completion'=>0.18,'speed'=>0.12,'reliability'=>0.10,'refill'=>0.07,'dripfeed'=>0.04,'popularity'=>0.05,'customer_rating'=>0.12]
                    : ['price'=>0.13,'completion'=>0.22,'speed'=>0.13,'reliability'=>0.17,'refill'=>0.08,'dripfeed'=>0.05,'popularity'=>0.07,'customer_rating'=>0.15];
                $overall = 0;
                foreach ($w as $k => $v) { $overall += $a['scores'][$k] * $v; }
                $a['scores']['overall'] = round($overall, 1);

                if ($a['scores']['completion'] >= 8) $a['strengths'][] = ['icon'=>'check-circle','text'=> __('high_completion') ?: 'Yüksek tamamlanma'];
                if ($a['scores']['speed'] >= 8)       $a['strengths'][] = ['icon'=>'bolt','text'=> __('fast_delivery') ?: 'Hızlı teslimat'];
                if ($a['scores']['price'] >= 8)       $a['strengths'][] = ['icon'=>'tag','text'=> __('affordable_price') ?: 'Uygun fiyat'];
                if ($a['scores']['reliability'] >= 8) $a['strengths'][] = ['icon'=>'shield-alt','text'=> __('reliable') ?: 'Güvenilir'];
                if ($a['stats']['rating_count'] >= 3 && $a['scores']['customer_rating'] >= 8) $a['strengths'][] = ['icon'=>'star','text'=>'Yüksek müşteri puanı'];

                if ($a['scores']['completion'] < 5) $a['weaknesses'][] = ['icon'=>'times-circle','text'=> __('low_completion') ?: 'Düşük tamamlanma'];
                if ($a['scores']['speed'] < 5)       $a['weaknesses'][] = ['icon'=>'clock','text'=> __('slow_delivery') ?: 'Yavaş teslimat'];
                if ($a['scores']['price'] < 4)       $a['weaknesses'][] = ['icon'=>'dollar-sign','text'=> __('expensive') ?: 'Pahalı'];
                if (!$srv['refill'])                 $a['weaknesses'][] = ['icon'=>'sync-alt','text'=> __('no_refill') ?: 'Refill yok'];

                $results[] = $a;
            }

            usort($results, function($x, $y) {
                return $y['scores']['overall'] <=> $x['scores']['overall'];
            });

            for ($i = 0; $i < count($results); $i++) {
                $results[$i]['rank'] = $i + 1;
                $results[$i]['badges'] = [];
                if ($i === 0) {
                    $results[$i]['badges'][] = ['type'=>'winner','text'=> __('winner') ?: 'Kazanan','icon'=>'trophy'];
                }
            }

            $bestPrice   = $results[0];
            $bestSpeed   = $results[0];
            $bestQuality = $results[0];
            foreach ($results as $r) {
                if ($r['scores']['price'] > $bestPrice['scores']['price'])       $bestPrice = $r;
                if ($r['scores']['speed'] > $bestSpeed['scores']['speed'])       $bestSpeed = $r;
                if ($r['scores']['completion'] > $bestQuality['scores']['completion']) $bestQuality = $r;
            }
            for ($i = 0; $i < count($results); $i++) {
                $sid = $results[$i]['service']['id'];
                if ($results[$i]['rank'] === 1) continue;
                if ($sid === $bestPrice['service']['id'])   $results[$i]['badges'][] = ['type'=>'price','text'=> __('best_price') ?: 'En Ucuz','icon'=>'tag'];
                if ($sid === $bestSpeed['service']['id'])   $results[$i]['badges'][] = ['type'=>'speed','text'=> __('best_speed') ?: 'En Hızlı','icon'=>'bolt'];
                if ($sid === $bestQuality['service']['id']) $results[$i]['badges'][] = ['type'=>'quality','text'=> __('best_quality') ?: 'En Kaliteli','icon'=>'star'];
            }

            echo json_encode(['success' => true, 'results' => $results], JSON_UNESCAPED_UNICODE);

        } catch (Exception $e) {
            echo json_encode(['success' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
        }
        exit;
    }

    echo json_encode(['success' => false, 'error' => __('invalid_request') ?: 'Geçersiz istek'], JSON_UNESCAPED_UNICODE);
    exit;
}

$pageTitle = __('compare_title') ?: 'Ürün Karşılaştırma';
require_once __DIR__ . '/header.php';
?>

<div class="compare-page">
    <div class="compare-hero">
        <div class="hero-content">
            <div class="hero-icon"><i class="fas fa-balance-scale"></i></div>
            <h1><?= __('compare_title') ?: 'Ürün Karşılaştırma' ?></h1>
            <p><?= __('compare_subtitle') ?: 'Servisleri detaylı karşılaştırın ve en iyisini seçin' ?></p>
        </div>
    </div>

    <div class="compare-layout">
        <div class="compare-panel panel-services">
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-list"></i> <?= __('services') ?: 'Servisler' ?></h3>
                    <span class="badge" id="serviceCounter">0</span>
                </div>
                <div class="card-body">
                    <div class="search-box">
                        <i class="fas fa-search"></i>
                        <input type="text" id="searchInput" placeholder="<?= __('search_service') ?: 'Servis ara...' ?>">
                        <button type="button" id="clearSearch"><i class="fas fa-times"></i></button>
                    </div>
                    <div class="filters">
                        <select id="categoryFilter">
                            <option value=""><?= __('all_categories') ?: 'Tüm Kategoriler' ?></option>
                        </select>
                        <div class="filter-toggles">
                            <label class="filter-toggle" id="toggleRefill">
                                <i class="fas fa-sync"></i> <?= __('refill') ?: 'Refill' ?>
                            </label>
                            <label class="filter-toggle" id="toggleDripfeed">
                                <i class="fas fa-tint"></i> <?= __('dripfeed') ?: 'Dripfeed' ?>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="services-list" id="servicesList">
                    <div class="loading"><i class="fas fa-spinner fa-spin"></i> <?= __('loading') ?: 'Yükleniyor...' ?></div>
                </div>
            </div>
        </div>

        <div class="compare-panel panel-selected">
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-check-double"></i> <?= __('selected_services') ?: 'Seçilenler' ?></h3>
                    <span class="badge"><span id="selectedCount">0</span>/5</span>
                </div>
                <div class="selected-list" id="selectedList">
                    <div class="empty-state">
                        <i class="fas fa-hand-pointer"></i>
                        <p><?= __('select_services_hint') ?: 'Karşılaştırmak için servis seçin' ?></p>
                    </div>
                </div>
                <div class="card-footer">
                    <label class="mode-switch">
                        <input type="checkbox" id="priceMode">
                        <span class="switch-track"></span>
                        <span><?= __('price_performance_mode') ?: 'Fiyat/Performans' ?></span>
                    </label>
                    <button id="compareBtn" class="btn-compare" disabled>
                        <i class="fas fa-chart-bar"></i> <?= __('compare_now') ?: 'Karşılaştır' ?>
                    </button>
                </div>
            </div>
        </div>

        <div class="compare-panel panel-results">
            <div id="resultsArea">
                <div class="placeholder">
                    <i class="fas fa-chart-pie"></i>
                    <h3><?= __('comparison_results') ?: 'Karşılaştırma Sonuçları' ?></h3>
                    <p><?= __('select_min_services') ?: 'En az 2 servis seçip karşılaştırın' ?></p>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.compare-page{width:100%}
.compare-hero{
    background:linear-gradient(135deg,var(--primary-color),var(--secondary-color));
    border-radius:20px;
    padding:48px 32px;
    margin-bottom:24px;
    color:var(--on-accent-color);
    text-align:center;
    display:grid;
    justify-items:center;
    gap:12px;
    box-shadow:0 16px 40px rgba(0,0,0,0.2);
}
.hero-content{max-width:720px}
.hero-icon{
    width:82px;height:82px;
    background:rgba(255,255,255,0.18);
    border-radius:20px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    font-size:2rem;
    backdrop-filter:blur(8px);
    box-shadow:0 10px 30px rgba(0,0,0,0.18);
}
.hero-content h1{font-size:1.9rem;font-weight:800;letter-spacing:0.3px;color:var(--text-color)}
.hero-content p{font-size:1.05rem;opacity:0.9;color:var(--muted-text-color)}
@media(max-width:768px){.compare-hero{padding:32px 18px}.hero-content h1{font-size:1.6rem}.hero-content p{font-size:0.95rem}}

.compare-layout{display:grid;grid-template-columns:1fr 1fr 1.5fr;gap:15px}
@media(max-width:1200px){.compare-layout{grid-template-columns:1fr 1fr}.panel-results{grid-column:1/-1}}
@media(max-width:768px){.compare-layout{grid-template-columns:1fr}.compare-hero{padding:32px 18px}}

.compare-panel .card{
    background:linear-gradient(180deg,rgba(255,255,255,0.02),rgba(255,255,255,0.01));
    border:1px solid rgba(255,255,255,0.04);
    border-radius:18px;
    overflow:hidden;
    box-shadow:0 12px 40px rgba(0,0,0,0.12);
    backdrop-filter:blur(6px);
}
.panel-services .card,.panel-selected .card{position:sticky;top:80px}
@media(max-width:768px){.panel-services .card,.panel-selected .card{position:relative;top:0}}

.card-header{padding:12px 15px;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center;position:relative}
.card-header::after{
    content:'';
    position:absolute;left:15px;right:15px;bottom:-1px;
    height:1px;
    background:linear-gradient(90deg,transparent,rgba(255,255,255,0.08),transparent);
}
.card-header h3{font-size:.95rem;margin:0;display:flex;align-items:center;gap:8px;color:var(--text-color)}
.card-header h3 i{color:var(--accent-text-color)}
.card-header .badge{background:var(--primary-color);color:var(--on-primary-color);padding:3px 10px;border-radius:20px;font-size:.75rem;font-weight:600}
.card-body{padding:12px}
.card-footer{padding:12px;border-top:1px solid var(--border-color)}

.search-box{position:relative;margin-bottom:10px}
.search-box>i{position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--muted-text-color);opacity:.4;font-size:.85rem}
.search-box input{
    width:100%;padding:10px 35px 10px 36px;
    border:2px solid var(--border-color);border-radius:10px;
    background:var(--background-color);color:var(--text-color);font-size:.9rem;
}
.search-box input:focus{outline:none;border-color:var(--accent-text-color)}
#clearSearch{
    position:absolute;right:8px;top:50%;transform:translateY(-50%);
    background:var(--border-color);border:none;width:22px;height:22px;
    border-radius:50%;cursor:pointer;display:none;align-items:center;justify-content:center;font-size:.65rem;color:var(--muted-text-color);
}
#clearSearch.show{display:flex}
#clearSearch:hover{background:var(--danger-color);color:#fff}

.filters{display:flex;flex-direction:column;gap:8px}
#categoryFilter{
    width:100%;padding:8px 10px;border:2px solid var(--border-color);
    border-radius:8px;background:var(--background-color);color:var(--text-color);
    font-size:.85rem;cursor:pointer;
}
#categoryFilter:focus{outline:none;border-color:var(--accent-text-color)}
.filter-toggles{display:flex;gap:8px}
.filter-toggle{
    flex:1;padding:8px 10px;border:2px solid var(--border-color);border-radius:8px;
    font-size:.8rem;text-align:center;cursor:pointer;transition:all .2s;
    display:flex;align-items:center;justify-content:center;gap:5px;
}
.filter-toggle:hover{border-color:var(--accent-text-color)}
.filter-toggle.active{background:var(--primary-alpha-01);border-color:var(--accent-text-color);color:var(--accent-text-color)}
.filter-toggle i{font-size:.75rem}

.services-list{max-height:350px;overflow-y:auto}
.services-list::-webkit-scrollbar{width:4px}
.services-list::-webkit-scrollbar-thumb{background:var(--border-color);border-radius:4px}
.loading,.empty-state{padding:30px;text-align:center;color:var(--muted-text-color);opacity:.6}
.loading i,.empty-state i{font-size:1.5rem;margin-bottom:8px;display:block}

.srv-item{
    display:flex;align-items:center;gap:10px;padding:10px 12px;
    border-bottom:1px solid var(--border-color);cursor:pointer;transition:all .15s;
}
.srv-item:last-child{border-bottom:none}
.srv-item:hover{background:var(--background-color)}
.srv-item.selected{background:var(--primary-alpha-01)}
.srv-item.disabled{opacity:.4;cursor:not-allowed}
.srv-check{width:20px;height:20px;border:2px solid var(--border-color);border-radius:5px;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:.6rem;color:transparent}
.srv-item.selected .srv-check{background:var(--primary-color);border-color:var(--accent-text-color);color:var(--on-primary-color)}
.srv-info{flex:1;min-width:0}
.srv-name{font-size:.85rem;font-weight:500;margin-bottom:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--text-color)}
.srv-meta{display:flex;align-items:center;gap:6px;font-size:.75rem;color:var(--muted-text-color)}
.srv-price{color:var(--success-color);font-weight:600}
.srv-cat{opacity:.7}
.srv-badges{display:flex;gap:3px;flex-shrink:0}
.srv-badge{width:18px;height:18px;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:.55rem;box-shadow:inset 0 0 0 1px rgba(255,255,255,0.06)}
.srv-badge.ref{background:rgba(34,197,94,.15);color:var(--success-color)}
.srv-badge.drip{background:var(--info-soft-bg);color:var(--info-color)}

.selected-list{min-height:100px;max-height:250px;overflow-y:auto;padding:8px}
.sel-item{display:flex;align-items:center;gap:8px;padding:8px 10px;background:var(--background-color);border-radius:8px;margin-bottom:6px;box-shadow:0 6px 16px rgba(0,0,0,0.12)}
.sel-num{width:22px;height:22px;background:var(--primary-color);color:var(--on-primary-color);border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:.7rem;font-weight:600;flex-shrink:0}
.sel-info{flex:1;min-width:0}
.sel-name{font-size:.8rem;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--text-color)}
.sel-price{font-size:.7rem;color:var(--success-color)}
.sel-remove{background:none;border:none;padding:4px;cursor:pointer;color:var(--muted-text-color);opacity:.5;font-size:.8rem}
.sel-remove:hover{opacity:1;color:var(--danger-color)}

.mode-switch{display:flex;align-items:center;gap:10px;margin-bottom:10px;cursor:pointer;font-size:.85rem;color:var(--text-color)}
.mode-switch input{display:none}
.switch-track{width:38px;height:20px;background:var(--border-color);border-radius:20px;position:relative;transition:background .2s}
.switch-track::after{content:'';position:absolute;width:16px;height:16px;background:#fff;border-radius:50%;top:2px;left:2px;transition:transform .2s}
.mode-switch input:checked+.switch-track{background:var(--primary-color)}
.mode-switch input:checked+.switch-track::after{transform:translateX(18px)}

.btn-compare{
    width:100%;padding:12px;background:linear-gradient(135deg,var(--primary-color),var(--secondary-color));
    border:none;border-radius:10px;color:var(--on-accent-color);font-size:.95rem;font-weight:600;cursor:pointer;
    display:flex;align-items:center;justify-content:center;gap:8px;transition:all .2s;
    box-shadow:0 8px 24px var(--primary-alpha-025);
}
.btn-compare:hover:not(:disabled){transform:translateY(-2px) scale(1.01);box-shadow:0 12px 28px var(--primary-alpha-035)}
.btn-compare:disabled{opacity:.5;cursor:not-allowed}

.placeholder{background:var(--card-bg-color);border:2px dashed var(--border-color);border-radius:14px;padding:50px 20px;text-align:center;box-shadow:0 8px 22px rgba(0,0,0,0.1)}
.placeholder i{font-size:2.5rem;color:var(--accent-text-color);opacity:.3;margin-bottom:15px}
.placeholder h3{margin-bottom:5px;font-size:1.1rem;color:var(--text-color)}
.placeholder p{opacity:.6;font-size:.9rem;color:var(--muted-text-color)}

.results-loading{background:var(--card-bg-color);border-radius:14px;padding:50px;text-align:center;box-shadow:0 8px 22px rgba(0,0,0,0.1)}
.loader-bars{display:flex;justify-content:center;gap:5px;margin-bottom:15px}
.loader-bars span{width:6px;height:30px;background:var(--primary-color);border-radius:3px;animation:barPulse .8s ease-in-out infinite}
.loader-bars span:nth-child(2){animation-delay:.1s}
.loader-bars span:nth-child(3){animation-delay:.2s}
.loader-bars span:nth-child(4){animation-delay:.3s}
@keyframes barPulse{0%,100%{transform:scaleY(.5);opacity:.5}50%{transform:scaleY(1);opacity:1}}

.winner-card{
    background:linear-gradient(135deg,#f6d365,#fda085);
    border-radius:14px;padding:20px;margin-bottom:15px;color:#111827;
    box-shadow:0 16px 48px rgba(253,160,133,0.35);
    border:1px solid rgba(255,255,255,0.3);
}
.winner-content{display:flex;align-items:center;gap:15px;flex-wrap:wrap}
.winner-trophy{width:60px;height:60px;background:rgba(255,255,255,.3);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.8rem;flex-shrink:0}
.winner-info{flex:1;min-width:150px}
.winner-label{font-size:.7rem;font-weight:600;text-transform:uppercase;letter-spacing:1px;opacity:.7}
.winner-name{font-size:1.1rem;font-weight:700;margin:3px 0}
.winner-cat{font-size:.8rem;opacity:.8}
.winner-score{display:inline-flex;align-items:baseline;gap:2px;background:rgba(255,255,255,.35);padding:5px 12px;border-radius:8px;margin-top:6px}
.winner-score strong{font-size:1.5rem;font-weight:800}
.winner-score span{font-size:.85rem;opacity:.7}
.winner-btn{padding:10px 18px;background:rgba(0,0,0,0.75);color:#f6d365;border:none;border-radius:8px;font-weight:600;font-size:.85rem;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:6px}
.winner-btn:hover{transform:scale(1.03)}
@media(max-width:500px){.winner-content{justify-content:center;text-align:center}.winner-info{min-width:100%}}

.results-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px}
.result-card{
    background:var(--card-bg-color);border:2px solid var(--border-color);border-radius:12px;overflow:hidden;
    transition:all .2s;box-shadow:0 12px 30px rgba(0,0,0,0.14);
}
.result-card:hover{transform:translateY(-5px) scale(1.01);box-shadow:0 18px 55px rgba(0,0,0,0.18)}
.result-card.rank-1{border-color:#fbbf24}
.result-card.rank-2{border-color:#9ca3af}
.result-card.rank-3{border-color:var(--warning-color)}
.res-header{padding:12px;display:flex;align-items:flex-start;gap:10px;border-bottom:1px solid var(--border-color)}
.rank-badge{width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;font-weight:800;flex-shrink:0}
.rank-1 .rank-badge{background:linear-gradient(135deg,#fbbf24,#f59e0b);color:#111827}
.rank-2 .rank-badge{background:linear-gradient(135deg,#9ca3af,#6b7280);color:#fff}
.rank-3 .rank-badge{background:linear-gradient(135deg,var(--warning-color),#b45309);color:#fff}
.rank-badge.default{background:var(--background-color)}
.res-info{flex:1;min-width:0}
.res-name{font-size:.9rem;font-weight:600;margin-bottom:2px;color:var(--text-color)}
.res-cat{font-size:.75rem;opacity:.6;color:var(--muted-text-color)}
.res-badges{display:flex;flex-wrap:wrap;gap:4px;margin-top:5px}
.r-badge{padding:2px 7px;border-radius:20px;font-size:.6rem;font-weight:600;display:inline-flex;align-items:center;gap:3px;letter-spacing:0.2px}
.r-badge.winner{background:linear-gradient(135deg,#fbbf24,#f59e0b);color:#111827}
.r-badge.price{background:rgba(34,197,94,.15);color:var(--success-color)}
.r-badge.speed{background:var(--info-soft-bg);color:var(--info-color)}
.r-badge.quality{background:rgba(168,85,247,.15);color:#a855f7}

.score-section{padding:12px;display:flex;align-items:center;gap:12px;background:var(--background-color)}
.score-circle{width:70px;height:70px;position:relative;flex-shrink:0}
.score-circle svg{transform:rotate(-90deg)}
.sc-bg{fill:none;stroke:var(--border-color);stroke-width:5}
.sc-fill{fill:none;stroke:var(--primary-color);stroke-width:5;stroke-linecap:round}
.rank-1 .sc-fill{stroke:#fbbf24}
.rank-2 .sc-fill{stroke:#9ca3af}
.rank-3 .sc-fill{stroke:var(--warning-color)}
.score-text{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center}
.score-text strong{font-size:1.2rem;font-weight:800}
.score-text span{font-size:.6rem;opacity:.6}
.score-bars{flex:1}
.bar-row{display:flex;align-items:center;gap:6px;margin-bottom:4px}
.bar-row:last-child{margin-bottom:0}
.bar-label{width:55px;font-size:.65rem;opacity:.7;color:var(--muted-text-color)}
.bar-track{flex:1;height:4px;background:var(--card-bg-color);border-radius:2px;overflow:hidden}
.bar-fill{height:100%;border-radius:2px}
.bar-fill.hi{background:var(--success-color)}
.bar-fill.md{background:#f59e0b}
.bar-fill.lo{background:var(--danger-color)}
.bar-val{width:22px;font-size:.65rem;font-weight:600;text-align:right;color:var(--text-color)}

.stats-section{padding:10px 12px;border-top:1px solid var(--border-color)}
.stats-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}
.stat-item{background:var(--background-color);padding:6px;border-radius:6px;text-align:center;box-shadow:0 6px 16px rgba(0,0,0,0.08)}
.stat-val{font-size:.9rem;font-weight:700;color:var(--accent-text-color)}
.stat-label{font-size:.6rem;opacity:.6;color:var(--muted-text-color)}

.sw-section{padding:10px 12px;border-top:1px solid var(--border-color)}
.sw-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.sw-col h5{font-size:.7rem;margin:0 0 5px;display:flex;align-items:center;gap:4px}
.sw-col.str h5{color:var(--success-color)}
.sw-col.weak h5{color:var(--danger-color)}
.sw-item{font-size:.65rem;padding:3px 6px;border-radius:4px;margin-bottom:2px;display:flex;align-items:center;gap:4px}
.str .sw-item{background:rgba(34,197,94,.1);color:var(--success-color)}
.weak .sw-item{background:rgba(239,68,68,.1);color:var(--danger-color)}

.res-actions{padding:10px 12px;border-top:1px solid var(--border-color);display:flex;gap:6px}
.res-actions a{flex:1;padding:8px;border-radius:8px;font-size:.8rem;font-weight:500;text-align:center;text-decoration:none;display:flex;align-items:center;justify-content:center;gap:5px;transition:all .15s}
.res-actions .btn-primary{background:var(--primary-color);color:var(--on-primary-color)}
.res-actions .btn-secondary{background:var(--background-color);color:var(--text-color);border:1px solid var(--border-color)}
.res-actions a:hover{transform:translateY(-1px)}
.results-note{text-align:center;padding:12px;font-size:.75rem;opacity:.5;color:var(--muted-text-color)}

@media (max-width:576px){
  .card-body,.card-header,.card-footer{padding:10px 12px}
  .compare-hero{padding:26px 14px}
}
</style>

<script>
(function() {
    'use strict';

    const MAX = 5;
    const MIN = 2;
    const CURRENCY = '<?php echo $siteSettings["currency_symbol"] ?? "₺"; ?>';

    let allCategories = [];
    let allServices = [];
    let selectedServices = {};
    let filterRefill = false;
    let filterDripfeed = false;

    const $ = id => document.getElementById(id);
    const els = {
        search: $('searchInput'),
        clearSearch: $('clearSearch'),
        category: $('categoryFilter'),
        toggleRefill: $('toggleRefill'),
        toggleDripfeed: $('toggleDripfeed'),
        servicesList: $('servicesList'),
        serviceCounter: $('serviceCounter'),
        selectedList: $('selectedList'),
        selectedCount: $('selectedCount'),
        priceMode: $('priceMode'),
        compareBtn: $('compareBtn'),
        results: $('resultsArea')
    };

    document.addEventListener('DOMContentLoaded', function() {
        loadData();
        bindEvents();
    });

    function bindEvents() {
        els.search.addEventListener('input', function() {
            els.clearSearch.classList.toggle('show', this.value.length > 0);
            renderServices();
        });

        els.clearSearch.addEventListener('click', function() {
            els.search.value = '';
            this.classList.remove('show');
            renderServices();
        });

        els.category.addEventListener('change', renderServices);

        els.toggleRefill.addEventListener('click', function() {
            filterRefill = !filterRefill;
            this.classList.toggle('active', filterRefill);
            renderServices();
        });

        els.toggleDripfeed.addEventListener('click', function() {
            filterDripfeed = !filterDripfeed;
            this.classList.toggle('active', filterDripfeed);
            renderServices();
        });

        els.compareBtn.addEventListener('click', doCompare);
    }

    function loadData() {
        els.servicesList.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> <?php echo __("loading") ?: "Yükleniyor..."; ?></div>';
        fetch('?ajax=load_data')
            .then(r => r.json())
            .then(data => {
                if (!data.success) {
                    els.servicesList.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-circle"></i><br><span class="js-error-text"></span></div>';
                    const errorText = els.servicesList.querySelector('.js-error-text');
                    if (errorText) errorText.textContent = String(data.error || '<?php echo __("error") ?: "Hata"; ?>');
                    return;
                }
                allCategories = data.categories || [];
                allServices = (data.services || []).map(s => ({
                    id: Number(s.id),
                    name: String(s.name || ''),
                    price_per_1000: Number(s.price_per_1000) || 0,
                    category_id: Number(s.category_id) || 0,
                    category_name: String(s.category_name || ''),
                    refill: Number(s.refill) || 0,
                    dripfeed: Number(s.dripfeed) || 0
                }));
                populateCategories();
                renderServices();
            })
            .catch(err => {
                console.error(err);
                els.servicesList.innerHTML = '<div class="empty-state"><i class="fas fa-wifi"></i><br><?php echo __("connection_error") ?: "Bağlantı hatası"; ?></div>';
            });
    }

    function populateCategories() {
        let html = '<option value=""><?php echo __("all_categories") ?: "Tüm Kategoriler"; ?></option>';
        allCategories.forEach(c => { html += `<option value="${c.id}">${esc(c.name)} (${c.service_count})</option>`; });
        els.category.innerHTML = html;
    }

    function getFiltered() {
        const term = els.search.value.toLowerCase().trim();
        const catId = els.category.value;
        return allServices.filter(s => {
            if (term && !s.name.toLowerCase().includes(term)) return false;
            if (catId && s.category_id !== Number(catId)) return false;
            if (filterRefill && s.refill !== 1) return false;
            if (filterDripfeed && s.dripfeed !== 1) return false;
            return true;
        });
    }

    function renderServices() {
        const list = getFiltered();
        const selectedCount = Object.keys(selectedServices).length;
        els.serviceCounter.textContent = list.length;
        if (!list.length) {
            els.servicesList.innerHTML = '<div class="empty-state"><i class="fas fa-search"></i><br><?php echo __("no_services_found") ?: "Servis bulunamadı"; ?></div>';
            return;
        }
        let html = '';
        list.forEach(s => {
            const idKey = String(s.id);
            const isSelected = selectedServices.hasOwnProperty(idKey);
            const isDisabled = !isSelected && selectedCount >= MAX;
            html += `
            <div class="srv-item${isSelected ? ' selected' : ''}${isDisabled ? ' disabled' : ''}" data-id="${s.id}">
                <div class="srv-check"><i class="fas fa-check"></i></div>
                <div class="srv-info">
                    <div class="srv-name">${esc(s.name)}</div>
                    <div class="srv-meta">
                        <span class="srv-price">${CURRENCY}${s.price_per_1000.toFixed(2)}</span>
                        <span class="srv-cat">${esc(s.category_name)}</span>
                    </div>
                </div>
                <div class="srv-badges">
                    ${s.refill === 1 ? '<span class="srv-badge ref"><i class="fas fa-sync"></i></span>' : ''}
                    ${s.dripfeed === 1 ? '<span class="srv-badge drip"><i class="fas fa-tint"></i></span>' : ''}
                </div>
            </div>`;
        });
        els.servicesList.innerHTML = html;
        els.servicesList.querySelectorAll('.srv-item').forEach(el => el.addEventListener('click', handleServiceClick));
    }

    function handleServiceClick() {
        if (this.classList.contains('disabled')) return;
        const id = Number(this.dataset.id);
        const idKey = String(id);
        if (selectedServices.hasOwnProperty(idKey)) {
            delete selectedServices[idKey];
        } else {
            if (Object.keys(selectedServices).length >= MAX) return;
            const srv = allServices.find(x => x.id === id);
            if (srv) {
                selectedServices[idKey] = {
                    id: srv.id,
                    name: srv.name,
                    price_per_1000: srv.price_per_1000,
                    category_name: srv.category_name
                };
            }
        }
        updateUI();
    }

    function updateUI() {
        const keys = Object.keys(selectedServices);
        const count = keys.length;
        els.servicesList.querySelectorAll('.srv-item').forEach(el => {
            const idKey = el.dataset.id;
            const isSelected = selectedServices.hasOwnProperty(idKey);
            const isDisabled = !isSelected && count >= MAX;
            el.classList.toggle('selected', isSelected);
            el.classList.toggle('disabled', isDisabled);
        });
        els.selectedCount.textContent = count;
        if (!count) {
            els.selectedList.innerHTML = '<div class="empty-state"><i class="fas fa-hand-pointer"></i><p><?php echo __("select_services_hint") ?: "Karşılaştırmak için servis seçin"; ?></p></div>';
        } else {
            let html = '';
            keys.forEach((key, idx) => {
                const srv = selectedServices[key];
                html += `
                <div class="sel-item">
                    <div class="sel-num">${idx + 1}</div>
                    <div class="sel-info">
                        <div class="sel-name">${esc(srv.name)}</div>
                        <div class="sel-price">${CURRENCY}${srv.price_per_1000.toFixed(2)}</div>
                    </div>
                    <button type="button" class="sel-remove" data-id="${key}"><i class="fas fa-times"></i></button>
                </div>`;
            });
            els.selectedList.innerHTML = html;
            els.selectedList.querySelectorAll('.sel-remove').forEach(btn => btn.addEventListener('click', function(e) {
                e.stopPropagation();
                delete selectedServices[this.dataset.id];
                updateUI();
            }));
        }
        els.compareBtn.disabled = count < MIN;
    }

    function doCompare() {
        const keys = Object.keys(selectedServices);
        if (keys.length < MIN) return;
        const ids = keys.join(',');
        const priceMode = els.priceMode.checked ? '1' : '0';
        els.compareBtn.disabled = true;
        els.compareBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <?php echo __("analyzing") ?: "Analiz..."; ?>';
        els.results.innerHTML = '<div class="results-loading"><div class="loader-bars"><span></span><span></span><span></span><span></span></div><p><?php echo __("analyzing") ?: "Analiz ediliyor..."; ?></p></div>';

        fetch(`?ajax=compare&services=${ids}&price_mode=${priceMode}`)
            .then(r => r.json())
            .then(data => {
                if (data.success && data.results && data.results.length >= 2) {
                    renderResults(data.results);
                } else {
                    els.results.innerHTML = '<div class="placeholder"><i class="fas fa-exclamation-triangle"></i><h3><?php echo __("error") ?: "Hata"; ?></h3><p class="js-error-text"></p></div>';
                    const errorText = els.results.querySelector('.js-error-text');
                    if (errorText) errorText.textContent = String(data.error || '<?php echo __("comparison_failed") ?: "Karşılaştırma yapılamadı"; ?>');
                }
            })
            .catch(err => {
                console.error(err);
                els.results.innerHTML = '<div class="placeholder"><i class="fas fa-wifi"></i><h3><?php echo __("connection_error") ?: "Bağlantı Hatası"; ?></h3><p><?php echo __("try_again") ?: "Tekrar deneyin"; ?></p></div>';
            })
            .finally(() => {
                els.compareBtn.disabled = Object.keys(selectedServices).length < MIN;
                els.compareBtn.innerHTML = '<i class="fas fa-chart-bar"></i> <?php echo __("compare_now") ?: "Karşılaştır"; ?>';
            });
    }

    function renderResults(results) {
        const circ = 2 * Math.PI * 28;
        let html = '';

        const winner = results[0];
        html += `
        <div class="winner-card">
            <div class="winner-content">
                <div class="winner-trophy">🏆</div>
                <div class="winner-info">
                    <div class="winner-label"><?php echo __("winner") ?: "KAZANAN"; ?></div>
                    <div class="winner-name">${esc(winner.service.name)}</div>
                    <div class="winner-cat">${esc(winner.service.category_name || '')}</div>
                    <div class="winner-score"><strong>${winner.scores.overall.toFixed(1)}</strong><span>/10</span></div>
                </div>
                <a href="/kullanici/new-order.php?service=${winner.service.id}" class="winner-btn"><i class="fas fa-shopping-cart"></i> <?php echo __("order_now") ?: "Sipariş"; ?></a>
            </div>
        </div>`;

        html += '<div class="results-grid">';
        results.forEach((r, idx) => {
            const rank = idx + 1;
            const s = r.service;
            const sc = r.scores;
            const st = r.stats;
            const offset = circ - (sc.overall / 10) * circ;
            const badgesHtml = (r.badges || []).map(b => `<span class="r-badge ${b.type}"><i class="fas fa-${b.icon}"></i> ${b.text}</span>`).join('');

            html += `
            <div class="result-card rank-${rank}">
                <div class="res-header">
                    <div class="rank-badge${rank > 3 ? ' default' : ''}">${rank}</div>
                    <div class="res-info">
                        <div class="res-name">${esc(s.name)}</div>
                        <div class="res-cat">${esc(s.category_name || '')}</div>
                        <div class="res-badges">${badgesHtml}</div>
                    </div>
                </div>

                <div class="score-section">
                    <div class="score-circle">
                        <svg width="70" height="70" viewBox="0 0 70 70">
                            <circle class="sc-bg" cx="35" cy="35" r="28"/>
                            <circle class="sc-fill" cx="35" cy="35" r="28" stroke-dasharray="${circ}" stroke-dashoffset="${offset}"/>
                        </svg>
                        <div class="score-text"><strong>${sc.overall.toFixed(1)}</strong><span>/10</span></div>
                    </div>
                    <div class="score-bars">
                        ${makeBar('<?php echo __("completion") ?: "Tamamlanma"; ?>', sc.completion)}
                        ${makeBar('<?php echo __("speed") ?: "Hız"; ?>', sc.speed)}
                        ${makeBar('<?php echo __("reliability") ?: "Güvenilirlik"; ?>', sc.reliability)}
                        ${makeBar('<?php echo __("price") ?: "Fiyat"; ?>', sc.price)}
                        ${makeBar('<?php echo __("refill") ?: "Refill"; ?>', sc.refill)}
                        ${makeBar('Müşteri puanı', sc.customer_rating)}
                    </div>
                </div>

                <div class="stats-section">
                    <div class="stats-grid">
                        <div class="stat-item"><div class="stat-val">${CURRENCY}${Number(s.price_per_1000).toFixed(2)}</div><div class="stat-label"><?php echo __("price_per_1k") ?: "Fiyat/1K"; ?></div></div>
                        <div class="stat-item"><div class="stat-val">${st.completion_rate}%</div><div class="stat-label"><?php echo __("completion") ?: "Tamamlanma"; ?></div></div>
                        <div class="stat-item"><div class="stat-val">${st.total_orders}</div><div class="stat-label"><?php echo __("orders") ?: "Sipariş"; ?></div></div>
                        <div class="stat-item"><div class="stat-val">${st.rating_count > 0 ? Number(st.customer_rating).toFixed(1) + '/5' : '-'}</div><div class="stat-label">Müşteri puanı${st.rating_count > 0 ? ' · '+st.rating_count : ''}</div></div>
                        <div class="stat-item"><div class="stat-val">${fmtTime(st.avg_completion_time)}</div><div class="stat-label"><?php echo __("avg_time") ?: "Süre"; ?></div></div>
                        ${s.refill == 1 ? `<div class="stat-item"><div class="stat-val">${st.refill_rate !== null ? st.refill_rate + '%' : '-'}</div><div class="stat-label"><?php echo __("refill") ?: "Refill"; ?></div></div>` : ''}
                        ${s.dripfeed == 1 ? `<div class="stat-item"><div class="stat-val">${st.dripfeed_rate !== null ? st.dripfeed_rate + '%' : '-'}</div><div class="stat-label"><?php echo __("dripfeed") ?: "Dripfeed"; ?></div></div>` : ''}
                    </div>
                </div>

                ${(r.strengths && r.strengths.length) || (r.weaknesses && r.weaknesses.length) ? `
                <div class="sw-section">
                    <div class="sw-grid">
                        <div class="sw-col str">
                            <h5><i class="fas fa-check-circle"></i> <?php echo __("strengths") ?: "Güçlü"; ?></h5>
                            ${r.strengths && r.strengths.length ? r.strengths.slice(0,3).map(x => `<div class="sw-item"><i class="fas fa-${x.icon}"></i> ${x.text}</div>`).join('') : '<div class="sw-item" style="opacity:.4">-</div>'}
                        </div>
                        <div class="sw-col weak">
                            <h5><i class="fas fa-times-circle"></i> <?php echo __("weaknesses") ?: "Zayıf"; ?></h5>
                            ${r.weaknesses && r.weaknesses.length ? r.weaknesses.slice(0,3).map(x => `<div class="sw-item"><i class="fas fa-${x.icon}"></i> ${x.text}</div>`).join('') : '<div class="sw-item" style="opacity:.4">-</div>'}
                        </div>
                    </div>
                </div>` : ''}

                <div class="res-actions">
                    <a href="/kullanici/new-order.php?service=${s.id}" class="btn-primary"><i class="fas fa-shopping-cart"></i> <?php echo __("order_now") ?: "Sipariş"; ?></a>
                    <a href="/kullanici/services.php" class="btn-secondary"><i class="fas fa-info-circle"></i> <?php echo __("details") ?: "Detay"; ?></a>
                </div>
            </div>`;
        });
        html += '</div>';
        html += '<div class="results-note"><i class="fas fa-info-circle"></i> <?php echo __("results_note") ?: "Son 30 günlük verilere göre hesaplandı."; ?></div>';
        els.results.innerHTML = html;
        els.results.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function makeBar(label, score) {
        const cls = score >= 7 ? 'hi' : (score >= 4 ? 'md' : 'lo');
        return `<div class="bar-row">
            <span class="bar-label">${label}</span>
            <div class="bar-track"><div class="bar-fill ${cls}" style="width:${score * 10}%"></div></div>
            <span class="bar-val">${score.toFixed(1)}</span>
        </div>`;
    }

    function fmtTime(mins) {
        if (!mins) return '-';
        mins = parseInt(mins, 10);
        if (mins < 60) return mins + ' <?php echo __("min_short") ?: "dk"; ?>';
        if (mins < 1440) return Math.round(mins / 60) + ' <?php echo __("hour_short") ?: "sa"; ?>';
        return Math.round(mins / 1440) + ' <?php echo __("day_short") ?: "g"; ?>';
    }

    function esc(str) {
        if (!str) return '';
        var div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }
})();
</script>

<?php require_once __DIR__ . '/footer.php'; ?>