<?php
require_once __DIR__.'/../config.php';
if(!isLoggedIn()){header('Location:/login.php');exit;}
if(!moni_plugin_enabled('auto_subscriptions',$db)){http_response_code(404);exit('Auto Subscription eklentisi kapalı.');}
moni_require_user_capability($db,(int)$_SESSION['user_id'],'subscriptions.use','Auto Subscription kullanım yetkiniz kapalı.');
$error='';$ok='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        $a=$_POST['action']??'';
        if($a==='create'){
            moni_require_user_capability($db,(int)$_SESSION['user_id'],'orders.create','Sipariş verme yetkiniz kapalı.');
            $sid=(int)($_POST['service_id']??0);$profile=trim((string)($_POST['profile_url']??''));$qty=(int)($_POST['quantity']??0);
            $interval=max(2,min(1440,(int)($_POST['check_interval_minutes']??10)));$maxNew=max(1,min(20,(int)($_POST['max_new_items_per_run']??3)));$days=max(1,min(365,(int)($_POST['days']??30)));
            $s=$db->prepare("SELECT * FROM services WHERE id=? AND status='active' AND deleted_at IS NULL");$s->execute([$sid]);$srv=$s->fetch(PDO::FETCH_ASSOC);
            if(!$srv)throw new RuntimeException('Servis bulunamadı.');
            if(function_exists('moni_service_visible_to_user')&&!moni_service_visible_to_user($db,$sid,(int)$_SESSION['user_id']))throw new RuntimeException('Bu servis premium paketiniz için kullanılamıyor.');
            $inc=max(1,(int)($srv['quantity_increment']??1));
            if($qty<(int)$srv['min_quantity']||$qty>(int)$srv['max_quantity'])throw new RuntimeException('Miktar servis min/max aralığında olmalıdır.');
            if($qty%$inc!==0)throw new RuntimeException('Miktar '.$inc.' katı olmalıdır.');
            if(!moni_safe_public_url($profile))throw new RuntimeException('Geçerli ve herkese açık profil URL girin.');
            $db->prepare("INSERT INTO auto_subscriptions(user_id,service_id,profile_url,quantity,check_interval_minutes,max_new_items_per_run,status,expires_at,next_check_at) VALUES(?,?,?,?,?,?,'active',DATE_ADD(NOW(),INTERVAL ? DAY),DATE_ADD(NOW(),INTERVAL ? MINUTE))")
               ->execute([$_SESSION['user_id'],$sid,$profile,$qty,$interval,$maxNew,$days,$interval]);
            $id=(int)$db->lastInsertId();
            foreach(moni_discover_profile_items($db,$profile,30) as $item)$db->prepare("INSERT IGNORE INTO auto_subscription_items(subscription_id,item_url,status,created_at) VALUES(?,?,'seen',NOW())")->execute([$id,$item]);
            $ok='Abonelik oluşturuldu. Mevcut içerikler işaretlendi; bundan sonra bulunan yeni içerikler otomatik siparişe dönüşecek.';
        }elseif(in_array($a,['pause','resume','cancel'],true)){
            $id=(int)($_POST['id']??0);$status=$a==='pause'?'paused':($a==='resume'?'active':'cancelled');
            $db->prepare("UPDATE auto_subscriptions SET status=?,next_check_at=IF(?='active',NOW(),next_check_at) WHERE id=? AND user_id=?")->execute([$status,$status,$id,$_SESSION['user_id']]);
            $ok='Abonelik durumu güncellendi.';
        }
    }catch(Throwable $e){$error=$e->getMessage();}
}
$services=$db->query("SELECT id,name,min_quantity,max_quantity,quantity_increment FROM services WHERE status='active' AND deleted_at IS NULL ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
if(function_exists('moni_service_visible_to_user')) $services=array_values(array_filter($services,static fn($x)=>moni_service_visible_to_user($GLOBALS['db'],(int)$x['id'],(int)$_SESSION['user_id'])));
$q=$db->prepare("SELECT a.*,s.name service_name,(SELECT COUNT(*) FROM auto_subscription_items i WHERE i.subscription_id=a.id AND i.status='ordered') order_count FROM auto_subscriptions a JOIN services s ON s.id=a.service_id WHERE a.user_id=? ORDER BY a.id DESC");$q->execute([$_SESSION['user_id']]);$rows=$q->fetchAll(PDO::FETCH_ASSOC);
$activeCount=$pausedCount=$orderCount=0;$nextCheck=null;
foreach($rows as $r){if($r['status']==='active')$activeCount++;if($r['status']==='paused')$pausedCount++;$orderCount+=(int)$r['order_count'];if($r['status']==='active'&&!empty($r['next_check_at'])&&($nextCheck===null||strtotime($r['next_check_at'])<strtotime($nextCheck)))$nextCheck=$r['next_check_at'];}
$pageTitle='Otomatik Abonelikler';require_once 'header.php';
?>
<div class="muser-page">
  <section class="muser-hero">
    <div class="muser-hero-main"><span class="muser-kicker"><i class="fas fa-arrows-rotate"></i> Otomatik sipariş motoru</span><h2>Otomatik Abonelikler</h2><p>Bir profilin yeni içeriklerini belirlediğiniz aralıklarla kontrol edin. Yeni içerik bulunduğunda seçilen servis ve miktarla sipariş otomatik oluşturulur; eski içerikler yeniden siparişe dönüşmez.</p></div>
    <div class="muser-hero-icon"><i class="fas fa-bolt"></i></div>
  </section>
  <?php if($ok):?><div class="muser-alert success"><i class="fas fa-circle-check"></i> <?=clean($ok)?></div><?php endif;?>
  <?php if($error):?><div class="muser-alert danger"><i class="fas fa-triangle-exclamation"></i> <?=clean($error)?></div><?php endif;?>
  <div class="muser-stats">
    <div class="muser-stat"><i class="fas fa-play"></i><div><strong><?=$activeCount?></strong><span>Aktif abonelik</span></div></div>
    <div class="muser-stat"><i class="fas fa-pause"></i><div><strong><?=$pausedCount?></strong><span>Duraklatılmış</span></div></div>
    <div class="muser-stat"><i class="fas fa-cart-shopping"></i><div><strong><?=number_format($orderCount)?></strong><span>Otomatik sipariş</span></div></div>
    <div class="muser-stat"><i class="fas fa-clock"></i><div><strong><?=$nextCheck?clean(date('H:i',strtotime($nextCheck))):'-'?></strong><span>En yakın kontrol</span></div></div>
  </div>
  <div class="muser-grid">
    <section class="muser-card two-third">
      <div class="muser-card-head"><div><h3>Yeni abonelik oluştur</h3><p>Servis sınırları seçiminize göre aşağıda otomatik gösterilir.</p></div><span class="muser-badge active"><i class="fas fa-shield-halved"></i> Kontrollü otomasyon</span></div>
      <form method="post" id="subscriptionForm"><?=csrf_field()?><input type="hidden" name="action" value="create">
        <div class="muser-form-grid">
          <div class="muser-field full"><label>Servis</label><select name="service_id" id="subscriptionService" required><option value="">Servis seçin</option><?php foreach($services as $s):?><option value="<?=$s['id']?>" data-min="<?=$s['min_quantity']?>" data-max="<?=$s['max_quantity']?>" data-inc="<?=max(1,(int)($s['quantity_increment']??1))?>"><?=clean($s['name'])?></option><?php endforeach;?></select><small id="subscriptionServiceHint">Servis seçildiğinde miktar sınırları gösterilir.</small></div>
          <div class="muser-field full"><label>Profil URL</label><input type="url" name="profile_url" placeholder="https://.../profil" required><small>Profil herkese açık olmalı ve yeni içeriklerin dışarıdan okunabilmesine izin vermelidir.</small></div>
          <div class="muser-field"><label>Her yeni içerik için miktar</label><input type="number" name="quantity" id="subscriptionQuantity" min="1" required></div>
          <div class="muser-field"><label>Kontrol aralığı</label><select name="check_interval_minutes"><option value="2">2 dakika</option><option value="5">5 dakika</option><option value="10" selected>10 dakika</option><option value="15">15 dakika</option><option value="30">30 dakika</option><option value="60">1 saat</option><option value="180">3 saat</option><option value="360">6 saat</option><option value="720">12 saat</option><option value="1440">24 saat</option></select></div>
          <div class="muser-field"><label>Kontrol başına maksimum yeni içerik</label><input type="number" name="max_new_items_per_run" value="3" min="1" max="20"><small>Ani toplu içeriklerde bütçenizi korur.</small></div>
          <div class="muser-field"><label>Abonelik süresi</label><select name="days"><option value="7">7 gün</option><option value="30" selected>30 gün</option><option value="90">90 gün</option><option value="180">180 gün</option><option value="365">365 gün</option></select></div>
        </div>
        <div class="muser-actions"><button class="muser-btn"><i class="fas fa-plus"></i> Aboneliği Oluştur</button></div>
      </form>
    </section>
    <aside class="muser-card third">
      <div class="muser-card-head"><div><h3>Nasıl çalışır?</h3><p>Üç adımda otomatik sipariş.</p></div></div>
      <div class="muser-info"><i class="fas fa-1"></i><span>Profil ve servisi seçin. Mevcut içerikler başlangıçta <b>görülmüş</b> olarak kaydedilir.</span></div><br>
      <div class="muser-info"><i class="fas fa-2"></i><span>Merkezi <b>cronmoni.php</b> profilinizi seçtiğiniz aralıkla kontrol eder.</span></div><br>
      <div class="muser-info"><i class="fas fa-3"></i><span>Yeni URL bulunduğunda bakiye ve servis kuralları uygunsa sipariş otomatik açılır.</span></div>
    </aside>
    <section class="muser-card">
      <div class="muser-card-head"><div><h3>Aboneliklerim</h3><p>Aktif otomasyonlarınızı duraklatabilir, devam ettirebilir veya iptal edebilirsiniz.</p></div><span class="muser-badge"><?=count($rows)?> kayıt</span></div>
      <?php if(!$rows):?><div class="muser-empty"><i class="fas fa-rotate"></i><strong>Henüz otomatik aboneliğiniz yok</strong><span>Yukarıdaki formdan ilk aboneliğinizi oluşturabilirsiniz.</span></div><?php else:?><div class="muser-table-wrap"><table class="muser-table"><thead><tr><th>Servis / Profil</th><th>Miktar</th><th>Üretilen Sipariş</th><th>Durum</th><th>Sonraki Kontrol</th><th>İşlem</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><strong><?=clean($r['service_name'])?></strong><br><a href="<?=clean($r['profile_url'])?>" target="_blank" rel="noopener" class="muser-muted"><i class="fas fa-arrow-up-right-from-square"></i> Profili aç</a></td><td><?=number_format((int)$r['quantity'])?></td><td><?=intval($r['order_count'])?></td><td><span class="muser-badge <?=clean($r['status'])?>"><?=clean(ucfirst($r['status']))?></span></td><td><?=!empty($r['next_check_at'])?clean(date('d.m.Y H:i',strtotime($r['next_check_at']))):'-'?></td><td><div class="muser-actions" style="margin:0"><?php if(in_array($r['status'],['active','paused'],true)):?><form method="post"><?=csrf_field()?><input type="hidden" name="id" value="<?=$r['id']?>"><input type="hidden" name="action" value="<?=$r['status']==='active'?'pause':'resume'?>"><button class="muser-btn secondary sm"><i class="fas <?=$r['status']==='active'?'fa-pause':'fa-play'?>"></i> <?=$r['status']==='active'?'Duraklat':'Devam'?></button></form><form method="post" onsubmit="return confirm('Abonelik iptal edilsin mi?')"><?=csrf_field()?><input type="hidden" name="id" value="<?=$r['id']?>"><input type="hidden" name="action" value="cancel"><button class="muser-btn danger sm"><i class="fas fa-xmark"></i></button></form><?php endif;?></div></td></tr><?php endforeach;?></tbody></table></div><?php endif;?>
    </section>
  </div>
</div>
<script>
(function(){const s=document.getElementById('subscriptionService'),q=document.getElementById('subscriptionQuantity'),h=document.getElementById('subscriptionServiceHint');if(!s||!q||!h)return;function sync(){const o=s.options[s.selectedIndex];if(!o||!o.value){h.textContent='Servis seçildiğinde miktar sınırları gösterilir.';return;}const min=o.dataset.min,max=o.dataset.max,inc=o.dataset.inc||1;h.textContent=`Miktar: ${Number(min).toLocaleString('tr-TR')}–${Number(max).toLocaleString('tr-TR')} · Artış adımı: ${Number(inc).toLocaleString('tr-TR')}`;q.min=min;q.max=max;q.step=inc;if(!q.value)q.value=min;}s.addEventListener('change',sync);sync();})();
</script>
<?php require_once 'footer.php'; ?>
