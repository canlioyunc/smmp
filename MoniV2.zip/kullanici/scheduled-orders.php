<?php
/**
 * Kullanıcı Paneli - Profesyonel Süreli Siparişler (Final Düzeltilmiş Sürüm)
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';
$pageTitle = __('scheduled_orders');
require_once 'header.php';

// --- İŞLEM KODLARI ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_scheduled'])) {
    if (function_exists('moni_partial_maintenance_active') && moni_partial_maintenance_active($db,'orders')) { $error=moni_partial_maintenance_message($db,'orders'); }
    if (function_exists('moni_user_can') && !moni_user_can($db,(int)$_SESSION['user_id'],'orders.create',true)) { $error='Sipariş verme yetkiniz yönetici tarafından kapatılmış.'; }
    $service_id = (int)($_POST['service_id'] ?? 0);
    $link = trim((string)($_POST['link'] ?? ''));
    $quantity = (int)($_POST['quantity'] ?? 0);
    $date = (string)($_POST['date'] ?? '');
    $time = (string)($_POST['time'] ?? '');
    $geoInput = trim((string)($_POST['geo_target'] ?? ''));
    $scheduled_datetime = $date . ' ' . $time . ':00';

    if (!$error && ($link === '' || $quantity < 1 || $date === '' || $time === '')) {
        $error = __('fill_all_fields');
    } elseif (!$error && (strtotime($scheduled_datetime) === false || strtotime($scheduled_datetime) < time())) {
        $error = __('invalid_date');
    } elseif (!$error) {
        $stmt = $db->prepare("SELECT * FROM services WHERE id = ? AND status='active' AND deleted_at IS NULL");
        $stmt->execute([$service_id]);
        $service = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$service) {
            $error = __('service_not_found');
        } elseif (function_exists('moni_service_visible_to_user') && !moni_service_visible_to_user($db,$service_id,(int)$_SESSION['user_id'])) {
            $error = 'Bu servis müşteri grubunuza açık değil.';
        } elseif (function_exists('moni_validate_service_target') && empty(($tv=moni_validate_service_target($db,$service_id,$link,(int)$_SESSION['user_id'],'scheduled-web'))['ok'])) {
            $error = $tv['error'] ?? 'Bu hedef bu servis için kullanılamaz.';
        } elseif ($quantity < (int)$service['min_quantity'] || $quantity > (int)$service['max_quantity']) {
            $error = __('quantity_range_error') . " " . number_format($service['min_quantity']) . " - " . number_format($service['max_quantity']);
        } elseif ($quantity % max(1,(int)($service['quantity_increment']??1)) !== 0) {
            $error = 'Miktar '.max(1,(int)($service['quantity_increment']??1)).' katı olmalıdır.';
        } elseif (moni_maintenance_reason($service_id, (int)($service['api_provider_id'] ?? 0))) {
            $error = 'Bu servis şu anda bakım penceresinde.';
        } elseif (function_exists('moni_social_precheck') && empty(($pc=moni_social_precheck($db,$link))['ok'])) {
            $error = $pc['error'] ?? 'Sosyal hesap ön kontrolü başarısız.';
        } elseif (function_exists('moni_validate_geo_target') && empty(($gv=moni_validate_geo_target($service,$geoInput))['ok'])) {
            $error = $gv['error'] ?? 'Coğrafi hedef geçersiz.';
        } else {
            $geoTarget = isset($gv) ? ($gv['target'] ?? null) : null;
            $unitPrice = function_exists('moni_effective_price_for_quantity') ? moni_effective_price_for_quantity($service, (int)$_SESSION['user_id'], $quantity) : moni_effective_price_per_1000($service, (int)$_SESSION['user_id']);
            $price = round(($quantity / 1000) * $unitPrice, 4);
            try {
                $db->beginTransaction();
                // Yabancı para cüzdanından baz para birimine dönüşüm gerekiyorsa,
                // rezervasyon bakiyesiyle aynı transaction içinde yapılır. Böylece sipariş
                // oluşturulamazsa kur dönüşümü de geri alınır.
                $need=max(0,$price-(function_exists('moni_user_credit_limit')?moni_user_credit_limit($db,(int)$_SESSION['user_id']):0));
                $walletReady = moni_wallet_prepare_base_balance($db, (int)$_SESSION['user_id'], $need);
                if (empty($walletReady['ok']) && (!function_exists('moni_user_available_funds') || moni_user_available_funds($db,(int)$_SESSION['user_id'])+0.00001<$price)) throw new RuntimeException('INSUFFICIENT_BALANCE');
                if(function_exists('moni_debit_user')){$ok=moni_debit_user($db,(int)$_SESSION['user_id'],$price,true);if(!$ok)throw new RuntimeException('INSUFFICIENT_BALANCE');}
                else{$debit=$db->prepare("UPDATE users SET balance=balance-?,spent=spent+? WHERE id=? AND balance>=?");$debit->execute([$price,$price,$_SESSION['user_id'],$price]);if($debit->rowCount()!==1)throw new RuntimeException('INSUFFICIENT_BALANCE');}
                $insert = $db->prepare("INSERT INTO scheduled_orders (user_id, service_id, link, quantity, price, scheduled_time, geo_target, type, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'scheduled', 'active', NOW())");
                $insert->execute([$_SESSION['user_id'], $service_id, $link, $quantity, $price, $scheduled_datetime, $geoTarget]);
                $bal=$db->prepare("SELECT balance FROM users WHERE id=?");$bal->execute([$_SESSION['user_id']]);$newBalance=(float)$bal->fetchColumn();
                $db->prepare("INSERT INTO transactions(user_id,type,amount,balance_after,description,status,created_at) VALUES(?, 'order', ?, ?, ?, 'completed', NOW())")
                   ->execute([$_SESSION['user_id'], -$price, $newBalance, 'Süreli sipariş rezervasyonu']);
                $db->commit();
                moni_sync_base_wallet($db,(int)$_SESSION['user_id']);
                $currentUser['balance']=$newBalance; $_SESSION['balance']=$newBalance;
                $success = __('scheduled_order_created');
                echo "<script>setTimeout(function(){ window.location.href = 'scheduled-orders.php'; }, 800);</script>";
            } catch (Throwable $e) {
                if ($db->inTransaction()) $db->rollBack();
                $error = $e->getMessage()==='INSUFFICIENT_BALANCE'
                    ? __('insufficient_balance') . ' ' . __('required_amount') . ': ' . $siteSettings['currency_symbol'] . number_format($price, 2)
                    : 'Süreli sipariş oluşturulamadı.';
            }
        }
    }
}

// Filtreleme
$statusFilter = isset($_GET['status']) ? $_GET['status'] : 'all';
$allowedStatuses = ['active', 'completed', 'cancelled'];
$whereClause = "WHERE so.user_id = ? AND so.type = 'scheduled'";
$params = [$_SESSION['user_id']];

if (in_array($statusFilter, $allowedStatuses)) {
    $whereClause .= " AND so.status = ?";
    $params[] = $statusFilter;
}

// İstatistikler
$statsStmt = $db->prepare("
    SELECT 
        COUNT(*) as total, 
        SUM(CASE WHEN status='active' THEN 1 ELSE 0 END) as active,
        SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) as completed,
        SUM(price) as total_spent
    FROM scheduled_orders WHERE user_id = ? AND type='scheduled'
");
$statsStmt->execute([$_SESSION['user_id']]);
$stats = $statsStmt->fetch(PDO::FETCH_ASSOC);

// Sayfalama
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$totalStmt = $db->prepare("SELECT COUNT(*) FROM scheduled_orders so $whereClause");
$totalStmt->execute($params);
$totalRecords = $totalStmt->fetchColumn();
$totalPages = ceil($totalRecords / $limit);

$query = "SELECT so.*, s.name as service_name, c.name as cat_name 
          FROM scheduled_orders so 
          LEFT JOIN services s ON so.service_id = s.id 
          LEFT JOIN categories c ON s.category_id = c.id 
          $whereClause 
          ORDER BY so.scheduled_time ASC 
          LIMIT $limit OFFSET $offset";
$stmt = $db->prepare($query);
$stmt->execute($params);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// JS Verileri
$categories = $db->query("SELECT * FROM categories ORDER BY sort_order ASC")->fetchAll(PDO::FETCH_ASSOC);
$servicesRaw = $db->query("SELECT * FROM services WHERE status = 'active' ORDER BY sort_order ASC")->fetchAll(PDO::FETCH_ASSOC);
if(function_exists('moni_service_visible_to_user')) $servicesRaw=array_values(array_filter($servicesRaw,static fn($x)=>moni_service_visible_to_user($GLOBALS['db'],(int)$x['id'],(int)$_SESSION['user_id'])));
$servicesJS = array_map(function($s) use ($db) {
    $s['price_per_1000'] = moni_effective_price_per_1000($s, (int)$_SESSION['user_id']);
    $s['price_tiers'] = function_exists('moni_service_price_tiers') ? moni_service_price_tiers($db,(int)$s['id'],true) : [];
    $s['min_sale_price'] = moni_minimum_sale_price($s);
    $s['maintenance_reason'] = moni_maintenance_reason((int)$s['id'], (int)($s['api_provider_id'] ?? 0));
    return $s;
}, $servicesRaw);
?>

<style>
/* --- PROFESYONEL TASARIM --- */
:root {
    --card-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
    --hover-shadow: 0 15px 35px rgba(0, 0, 0, 0.08);
    --primary-gradient: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
}

/* İstatistik Kartları */
.stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; margin-bottom: 20px; }
.stat-card { background: var(--card-bg-color); border-radius: 20px; padding: 25px; border: 1px solid var(--border-color); box-shadow: var(--card-shadow); display: flex; align-items: center; gap: 20px; transition: all 0.3s ease; }
.stat-card:hover { transform: translateY(-5px); box-shadow: var(--hover-shadow); }
.stat-icon-wrapper { width: 60px; height: 60px; border-radius: 16px; display: flex; align-items: center; justify-content: center; font-size: 1.6rem; flex-shrink: 0; }
.stat-card.blue .stat-icon-wrapper { background: rgba(52, 152, 219, 0.1); color: var(--info-color); }
.stat-card.yellow .stat-icon-wrapper { background: rgba(241, 196, 15, 0.1); color: var(--warning-color); }
.stat-card.green .stat-icon-wrapper { background: rgba(46, 204, 113, 0.1); color: var(--success-color); }
.stat-card.red .stat-icon-wrapper { background: rgba(231, 76, 60, 0.1); color: var(--danger-color); }
.stat-content h3 { font-size: 1.8rem; font-weight: 700; margin: 0; color: var(--text-color); }
.stat-content p { margin: 0; font-size: 0.9rem; color: var(--text-color); opacity: 0.6; }

/* Kırmızı Uyarı Kutusu */
.warning-box {
    background: rgba(231, 76, 60, 0.08);
    border-left: 4px solid var(--danger-color);
    color: var(--danger-color);
    padding: 16px 20px;
    border-radius: 8px;
    margin-bottom: 30px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 15px;
    font-size: 0.9rem;
    box-shadow: 0 5px 15px rgba(231, 76, 60, 0.05);
    transition: transform 0.3s ease;
}
.warning-box:hover { transform: translateX(5px); background: rgba(231, 76, 60, 0.12); }
.warning-box i { font-size: 1.4rem; animation: gentle-pulse 2s infinite; }

@keyframes gentle-pulse {
    0% { transform: scale(1); opacity: 1; }
    50% { transform: scale(1.1); opacity: 0.8; }
    100% { transform: scale(1); opacity: 1; }
}

/* Başlık ve Buton */
.page-header-flex { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; flex-wrap: wrap; gap: 15px; }
.create-btn { background: var(--primary-gradient); color: var(--on-accent-color); padding: 12px 28px; border-radius: 12px; border: none; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 10px; box-shadow: 0 4px 15px var(--primary-alpha-03); transition: all 0.3s; }
.create-btn:hover { transform: translateY(-2px); }

/* Sekmeler */
.status-tabs { display: flex; gap: 10px; margin-bottom: 20px; overflow-x: auto; padding-bottom: 5px; }
.status-tab { padding: 10px 20px; border-radius: 10px; background: var(--card-bg-color); border: 1px solid var(--border-color); color: var(--text-color); text-decoration: none; font-size: 0.9rem; font-weight: 500; white-space: nowrap; transition: all 0.2s; }
.status-tab.active, .status-tab:hover { background: var(--primary-gradient); color: var(--on-accent-color); border-color: transparent; }

/* Tablo */
.table-container { 
    background: var(--card-bg-color); 
    border-radius: 20px; 
    border: 1px solid var(--border-color); 
    box-shadow: var(--card-shadow); 
    overflow: hidden; 
    margin-bottom: 30px;
}

.table-responsive {
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch; /* Mobil kaydırma için */
}

.modern-table { 
    width: 100%; 
    border-collapse: collapse; 
    min-width: 800px; /* Mobilde sıkışmayı önlemek için minimum genişlik */
}

.modern-table th { 
    background: var(--background-color); 
    padding: 18px 25px; 
    text-align: left; 
    font-weight: 600; 
    opacity: 0.8; 
    font-size: 0.85rem; 
    text-transform: uppercase; 
    white-space: nowrap;
}

.modern-table td { 
    padding: 20px 25px; 
    border-top: 1px solid var(--border-color); 
    vertical-align: middle; 
}

.modern-table tr:hover td { background: rgba(0,0,0,0.01); }

/* Badge ve Taglar */
.cat-badge { display: inline-block; font-size: 0.7rem; padding: 3px 8px; border-radius: 6px; background: var(--primary-alpha-01); color: var(--accent-text-color); font-weight: 600; margin-bottom: 5px; }
.price-tag { font-weight: 700; color: var(--success-color); background: rgba(46, 204, 113, 0.1); padding: 6px 12px; border-radius: 8px; font-size: 0.95rem; white-space: nowrap; }
.date-badge { display: flex; align-items: center; gap: 8px; font-size: 0.9rem; font-weight: 500; white-space: nowrap; }
.date-badge i { color: var(--info-color); }

/* Link Alanı */
.link-display {
    background: var(--background-color);
    padding: 8px 12px;
    border-radius: 6px;
    border: 1px solid var(--border-color);
    font-family: monospace;
    font-size: 0.85rem;
    color: var(--text-color);
    display: inline-block;
    max-width: 200px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

/* Mobil Uyumlu Düzenlemeler */
@media (max-width: 768px) {
    .page-header-flex { flex-direction: column; align-items: stretch; }
    .create-btn { justify-content: center; width: 100%; }
    
    /* Mobilde Tablo Kart Görünümü YERİNE Kaydırmalı Görünüm */
    /* Bu sayede kullanıcı tabloyu sağa sola kaydırarak tüm sütunları görür */
    .table-container {
        border-radius: 12px;
    }
    
    .modern-table th, .modern-table td {
        padding: 15px;
    }
}
</style>

<!-- İstatistikler -->
<div class="stats-grid">
    <div class="stat-card blue">
        <div class="stat-icon-wrapper"><i class="fas fa-clock"></i></div>
        <div class="stat-content">
            <h3><?php echo number_format($stats['total']); ?></h3>
            <p><?php echo __('total'); ?></p>
        </div>
    </div>
    <div class="stat-card yellow">
        <div class="stat-icon-wrapper"><i class="fas fa-hourglass-half"></i></div>
        <div class="stat-content">
            <h3><?php echo number_format($stats['active']); ?></h3>
            <p><?php echo __('status_active'); ?></p>
        </div>
    </div>
    <div class="stat-card green">
        <div class="stat-icon-wrapper"><i class="fas fa-check-circle"></i></div>
        <div class="stat-content">
            <h3><?php echo number_format($stats['completed']); ?></h3>
            <p><?php echo __('status_completed'); ?></p>
        </div>
    </div>
    <div class="stat-card red">
        <div class="stat-icon-wrapper"><i class="fas fa-coins"></i></div>
        <div class="stat-content">
            <h3><?php echo $siteSettings['currency_symbol'] . number_format($stats['total_spent'], 2); ?></h3>
            <p><?php echo __('total_cost'); ?></p>
        </div>
    </div>
</div>

<!-- Uyarı -->
<div class="warning-box">
    <i class="fas fa-exclamation-triangle"></i>
    <span><?php echo __('prepayment_warning') ?: 'Ücret peşin alınır. İşlemin geri dönüşü ve iadesi yoktur!'; ?></span>
</div>

<?php if (isset($error)): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
<?php endif; ?>
<?php if (isset($success)): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
<?php endif; ?>

<!-- Başlık ve Buton -->
<div class="page-header-flex">
    <h2 style="margin:0; font-size:1.5rem; font-weight:700;"><?php echo __('scheduled_orders'); ?></h2>
    <button type="button" class="create-btn" onclick="openModal('newScheduledModal')">
        <i class="fas fa-calendar-plus"></i> <?php echo __('new_scheduled_order'); ?>
    </button>
</div>

<!-- Sekmeler -->
<div class="status-tabs">
    <a href="?status=all" class="status-tab <?php echo $statusFilter == 'all' ? 'active' : ''; ?>"><?php echo __('all_orders') ?: 'Tümü'; ?></a>
    <a href="?status=active" class="status-tab <?php echo $statusFilter == 'active' ? 'active' : ''; ?>"><?php echo __('status_active'); ?></a>
    <a href="?status=completed" class="status-tab <?php echo $statusFilter == 'completed' ? 'active' : ''; ?>"><?php echo __('status_completed'); ?></a>
    <a href="?status=cancelled" class="status-tab <?php echo $statusFilter == 'cancelled' ? 'active' : ''; ?>"><?php echo __('status_cancelled') ?: 'İptal'; ?></a>
</div>

<!-- Tablo Alanı -->
<div class="table-container">
    <div class="table-responsive"> <!-- Kaydırma için kritik div -->
        <?php if (empty($orders)): ?>
            <div style="padding: 60px; text-align: center; opacity: 0.6;">
                <i class="fas fa-calendar-times" style="font-size: 4rem; margin-bottom: 20px; color: var(--text-color);"></i>
                <h3 style="margin:0;"><?php echo __('no_scheduled_orders'); ?></h3>
            </div>
        <?php else: ?>
            <table class="modern-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th><?php echo __('service'); ?></th>
                        <th><?php echo __('link'); ?></th>
                        <th><?php echo __('quantity'); ?></th>
                        <th><?php echo __('total_cost'); ?></th>
                        <th><?php echo __('scheduled_time'); ?></th>
                        <th><?php echo __('status'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><strong>#<?php echo $order['id']; ?></strong></td>
                            <td>
                                <div style="display:flex; flex-direction:column;">
                                    <span class="cat-badge"><?php echo clean($order['cat_name'] ?? '-'); ?></span>
                                    <span style="font-weight:600;"><?php echo clean($order['service_name']); ?></span>
                                </div>
                            </td>
                            <td>
                                <span class="link-display" title="<?php echo clean($order['link']); ?>"><?php echo clean($order['link']); ?></span>
                            </td>
                            <td>
                                <strong><?php echo number_format($order['quantity']); ?></strong>
                            </td>
                            <td>
                                <span class="price-tag"><?php echo $siteSettings['currency_symbol'] . number_format($order['price'], 2); ?></span>
                            </td>
                            <td>
                                <div class="date-badge">
                                    <i class="far fa-clock"></i>
                                    <span><?php echo moni_format_user_time($db,(int)$_SESSION['user_id'],$order['scheduled_time']); ?></span>
                                </div>
                            </td>
                            <td>
                                <span class="status-badge status-<?php echo $order['status']; ?>">
                                    <?php echo __('status_' . $order['status']) ?? ucfirst($order['status']); ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<!-- Sayfalama -->
<?php if ($totalPages > 1): ?>
    <div style="padding: 20px; display: flex; justify-content: center;">
        <nav style="display: flex; gap: 5px;">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="?page=<?php echo $i; ?>&status=<?php echo $statusFilter; ?>" 
                   style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center; border-radius: 8px; background: var(--card-bg-color); border: 1px solid var(--border-color); color: var(--text-color); text-decoration: none; font-weight: 600; <?php echo $i === $page ? 'background: var(--primary-gradient); color: var(--on-accent-color); border-color: transparent;' : ''; ?>">
                   <?php echo $i; ?>
                </a>
            <?php endfor; ?>
        </nav>
    </div>
<?php endif; ?>

<!-- MODAL -->
<div id="newScheduledModal" class="custom-modal">
    <div class="custom-modal-content">
        <div class="custom-modal-header">
            <h3><i class="fas fa-calendar-plus" style="margin-right: 10px; color: var(--accent-text-color);"></i> <?php echo __('new_scheduled_order'); ?></h3>
            <span class="close-modal" onclick="closeModal('newScheduledModal')">&times;</span>
        </div>
        <div class="custom-modal-body">
            <form method="POST">
                <input type="hidden" name="create_scheduled" value="1">
                
                <div class="form-group">
                    <label class="form-label"><?php echo __('category'); ?></label>
                    <select id="categorySelect" class="form-control" onchange="filterServices()">
                        <option value=""><?php echo __('choose_category'); ?></option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo $cat['id']; ?>"><?php echo $cat['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label"><?php echo __('service'); ?></label>
                    <select name="service_id" id="serviceSelect" class="form-control" onchange="updateLimits()" required>
                        <option value="" data-price="0"><?php echo __('choose_service_first'); ?></option>
                    </select>
                    <div style="display: flex; justify-content: space-between; margin-top: 8px; font-size: 0.85rem;">
                        <span id="limitInfo" class="text-muted" style="background: rgba(0,0,0,0.05); padding: 4px 8px; border-radius: 6px;"></span>
                        <span id="priceInfo" style="color: var(--success-color); font-weight: 700;"></span>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label"><?php echo __('link'); ?></label>
                    <div style="position: relative;">
                        <input type="text" name="link" class="form-control" placeholder="<?php echo __('link_placeholder') ?: 'https://... veya kullanıcı adı'; ?>" required style="padding-left: 40px;">
                        <span style="position: absolute; left: 15px; top: 13px; opacity: 0.5;"><i class="fas fa-link"></i></span>
                    </div>
                </div>

                <div class="form-group" id="scheduledGeoGroup" style="display:none;">
                    <label class="form-label"><i class="fas fa-globe"></i> Coğrafi Hedef</label>
                    <select name="geo_target" id="scheduledGeoSelect" class="form-control"><option value="">Hedef seçin</option></select>
                </div>

                <div class="form-group">
                    <label class="form-label"><?php echo __('quantity'); ?></label>
                    <input type="number" id="quantity" name="quantity" class="form-control" placeholder="0" oninput="calculatePrice()" required>
                </div>

                <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label class="form-label"><?php echo __('date'); ?></label>
                        <input type="date" name="date" class="form-control" min="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label"><?php echo __('time'); ?></label>
                        <input type="time" name="time" class="form-control" required>
                    </div>
                </div>

                <div style="background: rgba(39, 174, 96, 0.1); border: 1px solid rgba(39, 174, 96, 0.2); padding: 20px; border-radius: 12px; margin-bottom: 20px; text-align: center;">
                    <span style="display:block; font-size:0.9rem; color: var(--text-color); opacity: 0.8; margin-bottom: 5px;"><?php echo __('total_cost'); ?></span>
                    <strong style="font-size:2rem; color: var(--success-color);" id="totalPriceDisplay">0.00 <?php echo $siteSettings['currency_symbol']; ?></strong>
                </div>

                <button type="submit" class="create-btn" style="width: 100%; justify-content: center; font-size: 1.1rem; padding: 15px;">
                    <?php echo __('pay_and_plan'); ?>
                </button>
            </form>
        </div>
    </div>
</div>

<style>
/* Modal */
.custom-modal { display: none; position: fixed; z-index: 10000; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.6); backdrop-filter: blur(5px); }
.custom-modal-content { background-color: var(--card-bg-color); margin: 5% auto; padding: 0; border: 1px solid var(--border-color); width: 90%; max-width: 500px; border-radius: 24px; box-shadow: 0 25px 50px rgba(0,0,0,0.3); animation: slideUp 0.3s cubic-bezier(0.165, 0.84, 0.44, 1); }
.custom-modal-header { padding: 25px; border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center; background: var(--background-color); border-radius: 24px 24px 0 0; }
.custom-modal-body { padding: 30px; }
.close-modal { font-size: 24px; cursor: pointer; color: var(--text-color); opacity: 0.5; transition: all 0.2s; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; border-radius: 50%; }
.close-modal:hover { opacity: 1; background: rgba(0,0,0,0.05); }
@keyframes slideUp { from { opacity: 0; transform: translateY(50px); } to { opacity: 1; transform: translateY(0); } }
</style>

<script>
const allServices = <?php echo json_encode($servicesJS); ?>;
const currencySymbol = "<?php echo $siteSettings['currency_symbol']; ?>";
const textChoose = "<?php echo __('choose_service'); ?>";

function filterServices() {
    const catId = document.getElementById('categorySelect').value;
    const serviceSelect = document.getElementById('serviceSelect');
    serviceSelect.innerHTML = '<option value="" data-price="0">' + textChoose + '</option>';
    const filtered = allServices.filter(s => s.category_id == catId);
    filtered.forEach(s => {
        const option = document.createElement('option');
        option.value = s.id;
        option.setAttribute('data-price', s.price_per_1000);
        option.setAttribute('data-min', s.min_quantity);
        option.setAttribute('data-max', s.max_quantity);
        option.setAttribute('data-tiers', JSON.stringify(s.price_tiers || []));
        option.setAttribute('data-floor', s.min_sale_price || 0);
        option.setAttribute('data-geo-supported', s.geo_supported || '0');
        option.setAttribute('data-geo-targets', s.geo_targets_json || '[]');
        option.text = s.name;
        serviceSelect.appendChild(option);
    });
    updateLimits();
}

function updateLimits() {
    const serviceSelect = document.getElementById('serviceSelect');
    const selectedOption = serviceSelect.options[serviceSelect.selectedIndex];
    const min = selectedOption.getAttribute('data-min');
    const max = selectedOption.getAttribute('data-max');
    const price = selectedOption.getAttribute('data-price');
    if (min && max) {
        document.getElementById('limitInfo').innerText = `Min: ${min} - Max: ${max}`;
        document.getElementById('priceInfo').innerText = `${parseFloat(price).toFixed(2)} ${currencySymbol} / 1000`;
    } else {
        document.getElementById('limitInfo').innerText = '';
        document.getElementById('priceInfo').innerText = '';
    }
    const geoGroup=document.getElementById('scheduledGeoGroup'), geoSelect=document.getElementById('scheduledGeoSelect');let targets=[];try{targets=JSON.parse(selectedOption.getAttribute('data-geo-targets')||'[]')}catch(e){targets=[]}
    if(selectedOption.getAttribute('data-geo-supported')==='1'&&targets.length){geoSelect.innerHTML='<option value="">Hedef seçin</option>'+targets.map(g=>'<option value="'+String(g).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))+'">'+String(g).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))+'</option>').join('');geoSelect.required=true;geoGroup.style.display='block';}else{geoSelect.required=false;geoSelect.innerHTML='<option value="">Hedef yok</option>';geoGroup.style.display='none';}
    calculatePrice();
}

function calculatePrice() {
    const serviceSelect = document.getElementById('serviceSelect');
    const selectedOption = serviceSelect.options[serviceSelect.selectedIndex];
    let pricePer1k = parseFloat(selectedOption.getAttribute('data-price')) || 0;
    const quantity = parseInt(document.getElementById('quantity').value) || 0;
    let tiers=[];try{tiers=JSON.parse(selectedOption.getAttribute('data-tiers')||'[]')}catch(e){tiers=[]}
    let chosen=null;tiers.forEach(t=>{const min=parseInt(t.min_quantity||0),max=parseInt(t.max_quantity||0);if(quantity>=min&&(max<=0||quantity<=max)){if(!chosen||min>=parseInt(chosen.min_quantity||0))chosen=t;}});
    if(chosen){if(chosen.pricing_type==='discount_percent')pricePer1k=Math.max(0,pricePer1k*(1-(parseFloat(chosen.pricing_value)||0)/100));else if(chosen.pricing_type==='fixed_per_1000')pricePer1k=Math.max(0,parseFloat(chosen.pricing_value)||0);}
    pricePer1k=Math.max(pricePer1k,parseFloat(selectedOption.getAttribute('data-floor')||0));
    const total = (quantity / 1000) * pricePer1k;
    document.getElementById('priceInfo').innerText = pricePer1k.toFixed(2) + ' ' + currencySymbol + ' / 1000';
    document.getElementById('totalPriceDisplay').innerText = total.toFixed(2) + ' ' + currencySymbol;
}

function openModal(id) { document.getElementById(id).style.display = "block"; }
function closeModal(id) { document.getElementById(id).style.display = "none"; }
window.onclick = function(event) { if (event.target.classList.contains('custom-modal')) { event.target.style.display = "none"; } }
</script>

<?php require_once 'footer.php'; ?>