<?php
/**
 * Kullanıcı Paneli - Profilim
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';
if (!isLoggedIn()) { header('Location: /login.php'); exit; }

/* ==========================================================================
   Google Authenticator Helper Class
   ========================================================================== */
if (!class_exists('GoogleAuthenticator')) {
    class GoogleAuthenticator {
        protected $_codeLength = 6;

        public function createSecret($secretLength = 16) {
            $validChars = $this->_getBase32LookupTable();
            if ($secretLength < 16 || $secretLength > 128) {
                throw new Exception('Bad secret length');
            }
            $secret = '';
            $rnd = false;
            if (function_exists('random_bytes')) {
                $rnd = random_bytes($secretLength);
            } elseif (function_exists('mcrypt_create_iv')) {
                $rnd = mcrypt_create_iv($secretLength, MCRYPT_DEV_URANDOM);
            } elseif (function_exists('openssl_random_pseudo_bytes')) {
                $rnd = openssl_random_pseudo_bytes($secretLength, $cryptoStrong);
                if (!$cryptoStrong) { $rnd = false; }
            }
            if ($rnd !== false) {
                for ($i = 0; $i < $secretLength; ++$i) {
                    $secret .= $validChars[ord($rnd[$i]) & 31];
                }
            } else {
                throw new Exception('No source of secure random');
            }
            return $secret;
        }

        public function getCode($secret, $time = null) {
            if (!$time) {
                $time = floor(time() / 30);
            }
            $base32 = new FixedBitNotation(5, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567', TRUE, TRUE);
            $secret = $base32->decode($secret);
            $time = pack("N", $time);
            $time = str_pad($time, 8, chr(0), STR_PAD_LEFT);
            $hash = hash_hmac('sha1', $time, $secret, true);
            $offset = ord(substr($hash, -1));
            $offset = $offset & 0xF;
            $hash = substr($hash, $offset, 4);
            $value = unpack('N', $hash);
            $value = $value[1];
            $value = $value & 0x7FFFFFFF;
            $modulo = pow(10, $this->_codeLength);
            return str_pad($value % $modulo, $this->_codeLength, '0', STR_PAD_LEFT);
        }

        public function getQRCodeGoogleUrl($name, $secret, $siteTitle) {
            $otpAuth = 'otpauth://totp/' . rawurlencode($siteTitle . ':' . $name) . '?secret=' . $secret . '&issuer=' . rawurlencode($siteTitle);
            return ''; // 2FA sırrı üçüncü taraf QR servisine gönderilmez; manuel anahtar kullanılır.
        }

        public function verifyCode($secret, $code, $discrepancy = 1, $currentTimeSlice = null) {
            if ($currentTimeSlice === null) {
                $currentTimeSlice = floor(time() / 30);
            }
            if (strlen($code) != 6) {
                return false;
            }
            for ($i = -$discrepancy; $i <= $discrepancy; ++$i) {
                $calculatedCode = $this->getCode($secret, $currentTimeSlice + $i);
                if ($this->timingSafeEquals($calculatedCode, $code)) {
                    return true;
                }
            }
            return false;
        }

        protected function _getBase32LookupTable() {
            return array(
                'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
                'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
                'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',
                'Y', 'Z', '2', '3', '4', '5', '6', '7',
                '='
            );
        }

        private function timingSafeEquals($safeString, $userString) {
            if (function_exists('hash_equals')) {
                return hash_equals($safeString, $userString);
            }
            $safeLen = strlen($safeString);
            $userLen = strlen($userString);
            if ($userLen != $safeLen) {
                return false;
            }
            $result = 0;
            for ($i = 0; $i < $userLen; ++$i) {
                $result |= (ord($safeString[$i]) ^ ord($userString[$i]));
            }
            return $result === 0;
        }
    }
}

if (!class_exists('FixedBitNotation')) {
    class FixedBitNotation {
        protected $_chars;
        protected $_rightPadFinalBits;
        protected $_padFinalGroup;
        protected $_padChar;

        public function __construct($bits, $chars = NULL, $rightPadFinalBits = FALSE, $padFinalGroup = FALSE, $padChar = '=') {
            $this->_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
            $this->_rightPadFinalBits = $rightPadFinalBits;
            $this->_padFinalGroup = $padFinalGroup;
            $this->_padChar = $padChar;
        }

        public function decode($string) {
            $string = strtoupper($string);
            $chars = $this->_chars;
            $charMap = array_flip(str_split($chars));
            $bin = "";
            $len = strlen($string);
            $padding = 0;
            for ($i = 0; $i < $len; $i++) {
                $char = $string[$i];
                if ($char == $this->_padChar) {
                    $padding++;
                    continue;
                }
                if (!isset($charMap[$char])) return false;
                $bin .= sprintf("%05b", $charMap[$char]);
            }
            $binLen = strlen($bin);
            $bytes = "";
            for ($i = 0; $i < $binLen; $i += 8) {
                if ($i + 8 > $binLen) break;
                $bytes .= chr(bindec(substr($bin, $i, 8)));
            }
            return $bytes;
        }
    }
}
/* ==========================================================================
   Bitiş: Helper Classes
   ========================================================================== */

// currentUser yoksa kullanıcıyı çek
if (empty($currentUser)) {
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $currentUser = $stmt->fetch(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
}

$success = '';
$error   = '';
$newApiKeyOnce = '';
$telegramLinkCodeOnce = '';
$ga = new GoogleAuthenticator();

// API client bilgisi çek
$apiClientStmt = $db->prepare("SELECT * FROM api_clients WHERE user_id = ? LIMIT 1");
$apiClientStmt->execute([$_SESSION['user_id']]);
$apiClient = $apiClientStmt->fetch(PDO::FETCH_ASSOC);
$apiClientStmt->closeCursor();

// Site Adını Veritabanından Çekme
$siteName = 'SMM Panel'; // Varsayılan değer
try {
    $siteNameStmt = $db->prepare("
        SELECT setting_value 
        FROM settings 
        WHERE setting_key IN ('site_name', 'site_title', 'title', 'website_title') 
        AND setting_value IS NOT NULL 
        AND setting_value != ''
        ORDER BY FIELD(setting_key, 'site_name', 'site_title', 'title', 'website_title') 
        LIMIT 1
    ");
    $siteNameStmt->execute();
    $result = $siteNameStmt->fetch(PDO::FETCH_ASSOC);
    if ($result && !empty($result['setting_value'])) {
        $siteName = $result['setting_value'];
    }
    $siteNameStmt->closeCursor();
} catch (Exception $e) {
    // Hata durumunda varsayılan kalır
}

// API base URL / endpoint
$defaultBase = (isset($_SERVER['HTTP_HOST']) ? ((isset($_SERVER['REQUEST_SCHEME']) ? $_SERVER['REQUEST_SCHEME'] : 'https') . '://' . $_SERVER['HTTP_HOST']) : '');
$apiBaseUrl  = rtrim($siteSettings['base_url'] ?? $defaultBase, '/');
$apiEndpoint = $apiBaseUrl . '/api/myservices.php';

// İşlemler
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if(isset($_POST['generate_telegram_link']) && moni_plugin_enabled('telegram_miniapp',$db)){
        $code=strtoupper(substr(bin2hex(random_bytes(6)),0,10));$hash=hash('sha256',$code);
        $db->prepare("UPDATE telegram_miniapp_links SET used_at=NOW() WHERE user_id=? AND used_at IS NULL")->execute([$_SESSION['user_id']]);
        $db->prepare("INSERT INTO telegram_miniapp_links(user_id,link_code_hash,expires_at,created_at) VALUES(?,?,DATE_ADD(NOW(),INTERVAL 10 MINUTE),NOW())")->execute([$_SESSION['user_id'],$hash]);
        $telegramLinkCodeOnce=$code;$success='Telegram Mini App bağlantı kodu oluşturuldu. Kod 10 dakika geçerlidir ve tek kullanımlıktır.';
    }

    
    // 2FA Doğrulama ve Kaydetme
    if (isset($_POST['enable_2fa'])) {
        $secret = $_POST['secret'];
        $code = $_POST['verification_code'];
        
        if ($ga->verifyCode($secret, $code)) {
            $stmt = $db->prepare("UPDATE users SET two_factor_enabled = 1, two_factor_secret = ? WHERE id = ?");
            $stmt->execute([moni_encrypt_secret($secret), $_SESSION['user_id']]);
            // Çeviri yoksa varsayılan İngilizce olsun
            $success = __('two_factor_success_msg') ?: 'Your account is protected with Two-Factor Authentication.';
            $currentUser['two_factor_enabled'] = 1;
            $currentUser['two_factor_secret'] = $secret;
        } else {
            $error = __('invalid_verification_code') ?: 'Invalid verification code!';
        }
    }

    // TOTP 2FA kapatma kritik güvenlik işlemidir: mevcut şifre zorunlu.
    if (isset($_POST['disable_2fa'])) {
        $reauth=(string)($_POST['current_password_security']??'');
        if(!moni_password_ok_for_user($db,(int)$_SESSION['user_id'],$reauth)){$error='Mevcut şifreniz doğrulanamadı.';}
        else{
            $stmt=$db->prepare("UPDATE users SET two_factor_enabled=0,two_factor_secret=NULL WHERE id=?");$stmt->execute([$_SESSION['user_id']]);
            $success=__('disable_2fa_success_msg') ?: 'Two-Factor Authentication disabled.';$currentUser['two_factor_enabled']=0;$currentUser['two_factor_secret']=null;
        }
    }

    // E-posta ile 2FA (hesaba özel, varsayılan pasif)
    if(isset($_POST['toggle_email_2fa'])){
        $reauth=(string)($_POST['current_password_security']??'');$enable=!empty($_POST['enable_email_2fa'])?1:0;
        if(!moni_password_ok_for_user($db,(int)$_SESSION['user_id'],$reauth)){$error='Mevcut şifreniz doğrulanamadı.';}
        else{$db->prepare("UPDATE users SET email_two_factor_enabled=? WHERE id=?")->execute([$enable,$_SESSION['user_id']]);$currentUser['email_two_factor_enabled']=$enable;$success=$enable?'E-posta ile iki aşamalı doğrulama etkinleştirildi.':'E-posta ile iki aşamalı doğrulama kapatıldı.';}
    }

    // API anahtarı yalnız oluşturulduğu anda gösterilir; veritabanında hash saklanır.
    if (isset($_POST['generate_api_key'])) {
        try {
            $reauth=(string)($_POST['current_password_security']??'');
            if(!moni_password_ok_for_user($db,(int)$_SESSION['user_id'],$reauth)) throw new RuntimeException('Mevcut şifreniz doğrulanamadı.');
            $newKey='moni_'.bin2hex(random_bytes(24));$stored=moni_hash_secret_token($newKey);$apiName=$currentUser['username']??('user-'.$_SESSION['user_id']);
            if($apiClient){$db->prepare("UPDATE api_clients SET api_key=?,status='active' WHERE user_id=?")->execute([$stored,$_SESSION['user_id']]);}
            else{$apiDefaultRate=max(1,min(100000,(int)getSetting('api_default_rate_limit_per_min','300')));$db->prepare("INSERT INTO api_clients(user_id,name,api_key,status,rate_limit_per_min,created_at) VALUES(?,?,?,'active',?,NOW())")->execute([$_SESSION['user_id'],$apiName,$stored,$apiDefaultRate]);}
            $newApiKeyOnce=$newKey;$success='Yeni API anahtarınız oluşturuldu. Bu anahtar yalnız bu ekranda bir kez gösterilir.';
            $apiClientStmt=$db->prepare("SELECT * FROM api_clients WHERE user_id=? LIMIT 1");$apiClientStmt->execute([$_SESSION['user_id']]);$apiClient=$apiClientStmt->fetch(PDO::FETCH_ASSOC);$apiClientStmt->closeCursor();
        }catch(Throwable $e){$error='API anahtarı oluşturulamadı: '.$e->getMessage();}
    }

    // Saat dilimi
    if (isset($_POST['save_timezone'])) {
        $tz=trim((string)($_POST['timezone']??''));
        if(!function_exists('moni_valid_timezone') || !moni_valid_timezone($tz)){$error='Geçerli bir saat dilimi seçin.';}
        else{$db->prepare("UPDATE users SET timezone=?,updated_at=NOW() WHERE id=?")->execute([$tz,$_SESSION['user_id']]);$currentUser['timezone']=$tz;date_default_timezone_set($tz);$success='Saat dilimi kaydedildi.';}
    }

    // Şifre Değiştirme
    if (isset($_POST['change_password'])) {
        $currentPassword = $_POST['current_password'];
        $newPassword = $_POST['new_password'];
        $confirmPassword = $_POST['confirm_password'];
        
        if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
            $error = __('fill_all_password_fields');
        } elseif (strlen($newPassword) < 8) {
            $error = __('password_min_length');
        } elseif ($newPassword !== $confirmPassword) {
            $error = __('passwords_not_match');
        } else {
            $stmt = $db->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch();
            $stmt->closeCursor();
            
            if (!password_verify($currentPassword, $user['password'])) {
                $error = __('current_password_wrong');
            } else {
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $stmt = $db->prepare("UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$hashedPassword, $_SESSION['user_id']]);
                $stmt->closeCursor();
                if(function_exists('moni_revoke_user_sessions'))moni_revoke_user_sessions($db,(int)$_SESSION['user_id']);
                session_regenerate_id(true);
                $success = __('password_changed_success');
            }
        }
    }
}

// 2FA için Secret Oluşturma
$newSecret = null;
$qrCodeUrl = null;
if (!$currentUser['two_factor_enabled']) {
    $newSecret = $ga->createSecret();
    $qrCodeUrl = $ga->getQRCodeGoogleUrl($currentUser['username'], $newSecret, $siteName);
}

// İstatistikler
$userStats = $db->prepare("
    SELECT 
        COUNT(*) as total_orders,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
        SUM(CASE WHEN status IN ('pending', 'processing', 'in_progress') THEN 1 ELSE 0 END) as active_orders,
        SUM(price) as total_spent,
        MIN(created_at) as first_order,
        MAX(created_at) as last_order
    FROM orders 
    WHERE user_id = ?
");
$userStats->execute([$_SESSION['user_id']]);
$stats = $userStats->fetch();
$userStats->closeCursor();

// Son siparişler
$recentOrders = $db->prepare("
    SELECT o.*, s.name as service_name
    FROM orders o
    LEFT JOIN services s ON o.service_id = s.id
    WHERE o.user_id = ?
    ORDER BY o.created_at DESC
    LIMIT 5
");
$recentOrders->execute([$_SESSION['user_id']]);
$activities = $recentOrders->fetchAll();
$recentOrders->closeCursor();

$pageTitle = __('my_profile');
require_once 'header.php';
?>

<style>
/* CSS Stilleri */
.profile-layout { display: grid; grid-template-columns: 350px 1fr; gap: 25px; }
@media (max-width: 1100px) { .profile-layout { grid-template-columns: 1fr; } }
.profile-card { background: var(--card-bg-color); border: 1px solid var(--border-color); border-radius: 20px; overflow: hidden; height: fit-content; }
.profile-header { background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); padding: 40px 25px; text-align: center; position: relative; }
.profile-header::after { content: ''; position: absolute; bottom: 0; left: 0; right: 0; height: 30px; background: var(--card-bg-color); border-radius: 30px 30px 0 0; }
.profile-avatar { width: 100px; height: 100px; background: var(--on-accent-alpha-020); border: 4px solid var(--on-accent-alpha-030); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px; font-size: 2.5rem; font-weight: 700; color: var(--on-accent-color); position: relative; z-index: 1; }
.profile-name { color: var(--on-accent-color); font-size: 1.4rem; font-weight: 700; margin-bottom: 5px; position: relative; z-index: 1; }
.profile-email { color: var(--on-accent-color); opacity: .82; font-size: 0.9rem; position: relative; z-index: 1; }
.profile-body { padding: 20px 25px 25px; }
.profile-stats { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin-bottom: 25px; }
.profile-stat { background: var(--background-color); padding: 18px; border-radius: 12px; text-align: center; }
.profile-stat .value { font-size: 1.5rem; font-weight: 700; color: var(--accent-text-color); margin-bottom: 5px; }
.profile-stat .label { font-size: 0.8rem; opacity: 0.6; }
.profile-info { display: flex; flex-direction: column; gap: 12px; }
.profile-info-item { display: flex; align-items: center; gap: 15px; padding: 15px; background: var(--background-color); border-radius: 12px; }
.profile-info-item i { width: 40px; height: 40px; background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: var(--on-accent-color); font-size: 1rem; }
.profile-info-item .info { flex: 1; }
.profile-info-item .info .label { font-size: 0.75rem; opacity: 0.5; margin-bottom: 3px; }
.profile-info-item .info .value { font-size: 0.95rem; font-weight: 600; }
.profile-main { display: flex; flex-direction: column; gap: 25px; }
.profile-tabs { display: flex; gap: 5px; background: var(--card-bg-color); border: 1px solid var(--border-color); border-radius: 12px; padding: 5px; }
.profile-tab { flex: 1; padding: 14px 20px; background: transparent; border: none; border-radius: 10px; color: var(--text-color); font-size: 0.9rem; font-weight: 500; cursor: pointer; transition: all 0.3s ease; display: flex; align-items: center; justify-content: center; gap: 8px; }
.profile-tab:hover { background: var(--background-color); }
.profile-tab.active { background: var(--primary-color); color: var(--on-primary-color); }
.tab-content { display: none; }
.tab-content.active { display: block; animation: fadeIn 0.3s ease; }
@keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
.form-card { background: var(--card-bg-color); border: 1px solid var(--border-color); border-radius: 16px; overflow: hidden; }
.form-card-header { padding: 20px 25px; border-bottom: 1px solid var(--border-color); display: flex; align-items: center; gap: 12px; }
.form-card-header i { color: var(--accent-text-color); font-size: 1.1rem; }
.form-card-header h3 { font-size: 1.05rem; font-weight: 600; }
.form-card-body { padding: 25px; }
.info-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }
@media (max-width: 576px) { .info-grid { grid-template-columns: 1fr; } }
.info-item { background: var(--background-color); padding: 20px; border-radius: 12px; }
.info-item .label { font-size: 0.8rem; opacity: 0.5; margin-bottom: 8px; display: flex; align-items: center; gap: 8px; }
.info-item .label i { color: var(--accent-text-color); }
.info-item .value { font-size: 1.05rem; font-weight: 600; }
.form-row { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }
@media (max-width: 576px) { .form-row { grid-template-columns: 1fr; } }
.form-group { margin-bottom: 20px; }
.form-group:last-child { margin-bottom: 0; }
.form-label { display: block; margin-bottom: 8px; font-weight: 500; font-size: 0.9rem; }
.form-label .required { color: var(--danger-color); }
.form-control { width: 100%; padding: 14px 18px; border: 2px solid var(--border-color); border-radius: 12px; background: var(--background-color); color: var(--text-color); font-size: 0.95rem; transition: all 0.3s ease; }
.form-control:focus { outline: none; border-color: var(--accent-text-color); box-shadow: 0 0 0 4px var(--primary-alpha-01); }
.input-group { position: relative; }
.input-group .toggle-password { position: absolute; right: 15px; top: 50%; transform: translateY(-50%); background: none; border: none; color: var(--text-color); opacity: 0.5; cursor: pointer; padding: 5px; }
.input-group .toggle-password:hover { opacity: 1; }
.form-actions { margin-top: 25px; padding-top: 25px; border-top: 1px solid var(--border-color); }
.btn { display: inline-flex; align-items: center; justify-content: center; gap: 8px; padding: 14px 28px; border-radius: 12px; font-weight: 600; font-size: 0.95rem; cursor: pointer; transition: all 0.3s ease; border: none; text-decoration: none; }
.btn-primary { background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: var(--on-accent-color); }
.btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 25px var(--primary-alpha-035); }
.btn-secondary { background: var(--background-color); color: var(--text-color); border: 2px solid var(--border-color); }
.btn-secondary:hover { border-color: var(--accent-text-color); color: var(--accent-text-color); }
.btn-danger { background: var(--danger-color); color: #fff; }
.btn-danger:hover { background: var(--danger-color); }
.security-info { background: var(--info-soft-bg); border: 1px solid var(--info-soft-border); border-radius: 12px; padding: 20px; margin-bottom: 25px; }
.security-info h5 { display: flex; align-items: center; gap: 10px; font-size: 0.95rem; color: var(--info-color); margin-bottom: 10px; }
.security-info p { font-size: 0.85rem; opacity: 0.8; line-height: 1.6; }
.api-key-box { background: var(--background-color); border-radius: 12px; padding: 20px; margin-top: 25px; }
.api-key-box h5 { font-size: 0.95rem; margin-bottom: 15px; display: flex; align-items: center; gap: 10px; }
.api-key-box h5 i { color: var(--accent-text-color); }
.api-key-field { display: flex; gap: 10px; }
.api-key-field input { flex: 1; padding: 12px 15px; border: 2px solid var(--border-color); border-radius: 10px; background: var(--card-bg-color); color: var(--text-color); font-family: monospace; font-size: 0.85rem; }
.api-key-field button { padding: 12px 20px; border: none; border-radius: 10px; background: var(--primary-color); color: var(--on-primary-color); cursor: pointer; transition: all 0.2s ease; }
.api-key-field button:hover { background: var(--secondary-color); }
.form-hint { font-size: 0.8rem; opacity: 0.6; margin-top: 10px; }
.activity-list { display: flex; flex-direction: column; gap: 12px; }
.activity-item { display: flex; align-items: center; gap: 15px; padding: 18px; background: var(--background-color); border-radius: 12px; transition: all 0.2s ease; }
.activity-item:hover { transform: translateX(5px); }
.activity-icon { width: 45px; height: 45px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1rem; background: var(--primary-alpha-015); color: var(--accent-text-color); }
.activity-info { flex: 1; min-width: 0; }
.activity-info h5 { font-size: 0.9rem; font-weight: 600; margin-bottom: 3px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.activity-info p { font-size: 0.8rem; opacity: 0.6; }
.activity-meta { text-align: right; }
.activity-meta .amount { font-weight: 600; font-size: 0.95rem; color: var(--danger-color); margin-bottom: 3px; }
.activity-meta .status { font-size: 0.75rem; }
.empty-activity { text-align: center; padding: 50px 20px; opacity: 0.6; }
.empty-activity i { font-size: 3rem; margin-bottom: 15px; opacity: 0.3; display: block; }
.alert { padding: 16px 20px; border-radius: 12px; margin-bottom: 20px; display: flex; align-items: center; gap: 12px; font-size: 0.9rem; }
.alert-success { background: var(--success-soft-bg); border: 1px solid var(--success-soft-border); color: var(--success-color); }
.alert-danger { background: var(--danger-soft-bg); border: 1px solid var(--danger-soft-border); color: var(--danger-color); }
.status-badge { padding: 4px 10px; border-radius: 6px; font-size: 0.75rem; font-weight: 600; }
.status-pending { background: var(--warning-soft-bg); color: var(--warning-color); }
.status-processing { background: var(--info-soft-bg); color: var(--info-color); }
.status-in_progress { background: rgba(0, 123, 255, 0.15); color: var(--info-color); }
.status-completed { background: var(--success-soft-bg); color: var(--success-color); }
.status-partial { background: rgba(253, 126, 20, 0.15); color: var(--warning-color); }
.status-cancelled { background: var(--danger-soft-bg); color: var(--danger-color); }
.status-refunded { background: rgba(108, 117, 125, 0.15); color: var(--muted-text-color); }
.status-error { background: var(--danger-soft-bg); color: var(--danger-color); }
.two-factor-setup { background: var(--background-color); padding: 20px; border-radius: 12px; margin-bottom: 25px; text-align: center; }
.qr-container { background: #fff; padding: 10px; display: inline-block; border-radius: 8px; margin: 15px 0; }
.secret-code { font-family: monospace; background: var(--card-bg-color); padding: 5px 10px; border: 1px solid var(--border-color); border-radius: 5px; letter-spacing: 1px; }


/* Profil sayfası yerleşim düzeltmeleri */
.profile-layout,
.profile-layout * { box-sizing: border-box; }
.profile-layout {
    grid-template-columns: minmax(280px, 320px) minmax(0, 1fr);
    align-items: start;
    gap: 24px;
    width: 100%;
    min-width: 0;
}
.profile-card,
.profile-main,
.tab-content,
.form-card,
.form-card-body,
.info-grid,
.form-row { min-width: 0; }
.profile-card { width: 100%; align-self: start; }
.profile-main { width: 100%; }
.profile-name,
.profile-email { max-width: 100%; overflow-wrap: anywhere; }
.profile-email { margin: 0; }
.profile-info-item { min-width: 0; }
.profile-info-item > i {
    flex: 0 0 40px;
    justify-content: center;
}
.profile-info-item .info { min-width: 0; }
.profile-info-item .info .value,
.info-item .value { overflow-wrap: anywhere; word-break: break-word; }
.profile-info-item .info .value i {
    width: auto;
    height: auto;
    background: transparent;
    border-radius: 0;
    display: inline;
    color: inherit;
    font-size: inherit;
}
.profile-tabs {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    width: 100%;
    min-width: 0;
}
.profile-tab {
    min-width: 0;
    padding: 12px 14px;
    line-height: 1.25;
    text-align: center;
}
.form-card-header { min-width: 0; }
.form-card-header h3 { margin: 0; min-width: 0; overflow-wrap: anywhere; }
.form-card-body { width: 100%; }
.info-grid,
.form-row { grid-template-columns: repeat(2, minmax(0, 1fr)); }
.form-control { min-width: 0; max-width: 100%; }
.api-key-field { width: 100%; min-width: 0; align-items: stretch; }
.api-key-field input { min-width: 0; width: 100%; }
.api-key-field button { flex: 0 0 auto; }
.profile-timezone-card { margin-top: 25px; }
.secret-code { display: inline-block; max-width: 100%; overflow-wrap: anywhere; word-break: break-all; }
.security-info,
.alert { max-width: 100%; overflow-wrap: anywhere; }
.alert-info { background: var(--info-soft-bg); border: 1px solid var(--info-soft-border); color: var(--info-color); }
.activity-item { min-width: 0; }
.activity-meta { flex: 0 0 auto; }

@media (max-width: 1180px) {
    .profile-layout { grid-template-columns: minmax(250px, 290px) minmax(0, 1fr); gap: 20px; }
}
@media (max-width: 980px) {
    .profile-layout { grid-template-columns: 1fr; }
    .profile-card { max-width: none; }
    .profile-stats { grid-template-columns: repeat(4, minmax(0, 1fr)); }
    .profile-info { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); }
}
@media (max-width: 720px) {
    .profile-tabs { grid-template-columns: 1fr; gap: 4px; }
    .profile-tab { justify-content: flex-start; text-align: left; }
    .profile-stats { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .profile-info { grid-template-columns: 1fr; }
    .info-grid,
    .form-row { grid-template-columns: 1fr; }
    .form-card-header { padding: 16px 18px; }
    .form-card-body { padding: 18px; }
}
@media (max-width: 520px) {
    .profile-header { padding: 30px 18px; }
    .profile-body { padding: 18px; }
    .profile-stats { gap: 10px; }
    .profile-stat { padding: 14px 10px; }
    .profile-stat .value { font-size: 1.18rem; }
    .profile-info-item { gap: 12px; padding: 12px; }
    .api-key-field { gap: 8px; }
    .api-key-field button { padding: 10px 14px; }
    .btn { width: 100%; padding-left: 16px; padding-right: 16px; }
    .activity-item { align-items: flex-start; flex-wrap: wrap; }
    .activity-meta { width: 100%; text-align: left; padding-left: 60px; }
}

</style>

<?php if ($success): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?php echo clean($success); ?>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?php echo clean($error); ?>
    </div>
<?php endif; ?>

<div class="profile-layout">
    <!-- Profile Card -->
    <div class="profile-card">
        <div class="profile-header">
            <div class="profile-avatar">
                <?php echo strtoupper(mb_substr($currentUser['username'], 0, 1, 'UTF-8')); ?>
            </div>
            <h2 class="profile-name"><?php echo clean($currentUser['username']); ?></h2>
            <p class="profile-email"><?php echo clean($currentUser['email']); ?></p>
        </div>
        <div class="profile-body">
            <div class="profile-stats">
                <div class="profile-stat">
                    <div class="value"><?php echo number_format($stats['total_orders'] ?? 0); ?></div>
                    <div class="label"><?php echo __('total_orders'); ?></div>
                </div>
                <div class="profile-stat">
                    <div class="value"><?php echo ($siteSettings['currency_symbol'] ?? '₺') . number_format($currentUser['balance'], 2); ?></div>
                    <div class="label"><?php echo __('balance'); ?></div>
                </div>
                <div class="profile-stat">
                    <div class="value"><?php echo number_format($stats['completed_orders'] ?? 0); ?></div>
                    <div class="label"><?php echo __('completed'); ?></div>
                </div>
                <div class="profile-stat">
                    <div class="value"><?php echo ($siteSettings['currency_symbol'] ?? '₺') . number_format($stats['total_spent'] ?? 0, 0); ?></div>
                    <div class="label"><?php echo __('spending'); ?></div>
                </div>
            </div>
            
            <div class="profile-info">
                <div class="profile-info-item">
                    <i class="fas fa-calendar-alt"></i>
                    <div class="info">
                        <div class="label"><?php echo __('registration_date'); ?></div>
                        <div class="value"><?php echo moni_format_user_time($db,(int)$_SESSION['user_id'],$currentUser['created_at']); ?></div>
                    </div>
                </div>
                <div class="profile-info-item">
                    <i class="fas fa-shield-alt"></i>
                    <div class="info">
                        <div class="label"><?php echo __('security_title') ?: 'Güvenlik'; ?></div>
                        <div class="value">
                            <?php if ($currentUser['two_factor_enabled']): ?>
                                <span style="color: var(--success-color);"><i class="fas fa-check-circle"></i> <?php echo __('two_factor_active'); ?></span>
                            <?php else: ?>
                                <span style="color: var(--danger-color);"><i class="fas fa-times-circle"></i> <?php echo __('two_factor_passive'); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="profile-main">
        <!-- Tabs -->
        <div class="profile-tabs">
            <button type="button" class="profile-tab active" data-tab="info">
                <i class="fas fa-user"></i> <?php echo __('account_info'); ?>
            </button>
            <button type="button" class="profile-tab" data-tab="security">
                <i class="fas fa-lock"></i> <?php echo __('security_and_password'); ?>
            </button>
            <button type="button" class="profile-tab" data-tab="activity">
                <i class="fas fa-history"></i> <?php echo __('recent_orders'); ?>
            </button>
        </div>
        
        <!-- Account Info Tab -->
        <div class="tab-content active" id="tab-info">
            <div class="form-card">
                <div class="form-card-header">
                    <i class="fas fa-id-card"></i>
                    <h3><?php echo __('account_info'); ?></h3>
                </div>
                <div class="form-card-body">
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="label"><i class="fas fa-user"></i> <?php echo __('username'); ?></div>
                            <div class="value"><?php echo clean($currentUser['username']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="label"><i class="fas fa-envelope"></i> <?php echo __('email_address'); ?></div>
                            <div class="value"><?php echo clean($currentUser['email']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="label"><i class="fas fa-wallet"></i> <?php echo __('current_balance'); ?></div>
                            <div class="value" style="color: var(--success-color);"><?php echo ($siteSettings['currency_symbol'] ?? '₺') . number_format($currentUser['balance'], 2); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="label"><i class="fas fa-money-bill-wave"></i> <?php echo __('total_spent'); ?></div>
                            <div class="value"><?php echo ($siteSettings['currency_symbol'] ?? '₺') . number_format($currentUser['spent'] ?? 0, 2); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="label"><i class="fas fa-calendar-plus"></i> <?php echo __('registration_date'); ?></div>
                            <div class="value"><?php echo moni_format_user_time($db,(int)$_SESSION['user_id'],$currentUser['created_at']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="label"><i class="fas fa-user-tag"></i> <?php echo __('account_type'); ?></div>
                            <div class="value"><?php echo ucfirst($currentUser['role']); ?></div>
                        </div>
                    </div>
                    
                    <div class="api-key-box">
                        <h5><i class="fas fa-key"></i> <?php echo __('api_key_title'); ?></h5>
                        <?php if (!empty($newApiKeyOnce)): ?>
                            <div class="alert alert-success"><i class="fas fa-shield-alt"></i> Anahtarı şimdi güvenli bir yere kaydedin; tekrar görüntülenmeyecektir.</div>
                            <div class="api-key-field"><input type="text" id="apiKeyField" value="<?php echo clean($newApiKeyOnce); ?>" readonly><button type="button" onclick="copyApiKey()"><i class="fas fa-copy"></i></button></div>
                        <?php elseif (!empty($apiClient)): ?>
                            <div class="security-info"><i class="fas fa-lock"></i> Aktif bir API anahtarınız var. Güvenlik nedeniyle mevcut anahtar tekrar gösterilmez.</div>
                        <?php endif; ?>
                        <div class="api-key-field" style="margin-top:12px;"><input type="text" id="apiUrlField" value="<?php echo clean($apiEndpoint); ?>" readonly><button type="button" onclick="copyApiUrl(this)"><i class="fas fa-link"></i></button></div>
                        <p class="form-hint">X-API-Key HTTP başlığı ile kullanın; anahtarı URL'ye eklemeyin.</p>
                        <form method="POST" style="margin-top:12px"><div class="form-group"><label class="form-label">Mevcut şifre</label><input type="password" name="current_password_security" class="form-control" autocomplete="current-password" required></div><button type="submit" name="generate_api_key" class="btn btn-primary"><i class="fas fa-sync-alt"></i> <?php echo !empty($apiClient)?'API Anahtarını Yenile':'API Anahtarı Oluştur'; ?></button></form>
                    </div>
                </div>
            </div>

            <div class="form-card profile-timezone-card">
                <div class="form-card-header"><i class="fas fa-clock"></i><h3>Kullanıcı Saat Dilimi</h3></div>
                <div class="form-card-body">
                    <form method="POST">
                        <div class="form-group">
                            <label class="form-label">Saat Dilimi</label>
                            <select name="timezone" class="form-control" required><?php foreach(timezone_identifiers_list() as $tz):?><option value="<?=clean($tz)?>" <?=($currentUser['timezone']??'Europe/Istanbul')===$tz?'selected':''?>><?=clean($tz)?></option><?php endforeach;?></select>
                            <p class="form-hint">Sipariş, ödeme, destek ve bildirim zamanları hesabınız için bu saat diliminde gösterilir.</p>
                        </div>
                        <button class="btn btn-primary" name="save_timezone"><i class="fas fa-save"></i> Saat Dilimini Kaydet</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Security Tab -->
        <div class="tab-content" id="tab-security">
            
            <!-- 2FA Setup Box -->
            <div class="form-card" style="margin-bottom: 25px;">
                <div class="form-card-header">
                    <i class="fas fa-shield-alt"></i>
                    <h3><?php echo __('two_factor_title'); ?></h3>
                </div>
                <div class="form-card-body">
                    <?php if ($currentUser['two_factor_enabled']): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i>
                            <?php echo __('two_factor_success_msg'); ?>
                        </div>
                        <p style="margin-bottom:15px;"><?php echo __('two_factor_warning_msg'); ?></p>
                        <form method="POST" onsubmit="return confirm('<?php echo __('disable_2fa_confirm'); ?>');">
                            <div class="form-group"><label class="form-label">Mevcut şifre</label><input type="password" name="current_password_security" class="form-control" required autocomplete="current-password"></div>
                            <button type="submit" name="disable_2fa" class="btn btn-danger">
                                <i class="fas fa-times-circle"></i> <?php echo __('disable_2fa_btn'); ?>
                            </button>
                        </form>
                    <?php else: ?>
                        <div class="security-info">
                            <h5><i class="fas fa-info-circle"></i> <?php echo __('how_to_setup'); ?></h5>
                            <p><?php echo __('two_factor_step_1'); ?><br>
                            <?php echo __('two_factor_step_2'); ?><br>
                            <?php echo __('two_factor_step_3'); ?></p>
                        </div>

                        <div class="two-factor-setup">
                            <div class="security-info" style="margin-bottom:12px">
                                <i class="fas fa-user-shield"></i> Güvenlik nedeniyle 2FA sırrı üçüncü taraf QR servisine gönderilmez. Authenticator uygulamanızda <b>Kurulum anahtarını manuel gir</b> seçeneğini kullanın.
                            </div>
                            <p><?php echo __('manual_entry_hint'); ?> <br> <strong class="secret-code"><?php echo clean($newSecret); ?></strong></p>
                        </div>

                        <form method="POST">
                            <input type="hidden" name="secret" value="<?php echo $newSecret; ?>">
                            <div class="form-group">
                                <label class="form-label"><?php echo __('verification_code_label'); ?></label>
                                <input type="text" name="verification_code" class="form-control" placeholder="123456" required maxlength="6" pattern="\d*">
                            </div>
                            <div class="form-actions">
                                <button type="submit" name="enable_2fa" class="btn btn-primary">
                                    <i class="fas fa-check"></i> <?php echo __('verify_and_enable_btn'); ?>
                                </button>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-card" style="margin-bottom:25px;">
                <div class="form-card-header"><i class="fas fa-envelope-open-text"></i><h3>E-posta ile İki Aşamalı Doğrulama</h3></div>
                <div class="form-card-body">
                    <p class="form-hint">Giriş sırasında e-posta adresinize 6 haneli, 10 dakika geçerli doğrulama kodu gönderir. Hesap bazında açılır ve varsayılan olarak kapalıdır.</p>
                    <div class="alert <?php echo !empty($currentUser['email_two_factor_enabled'])?'alert-success':'alert-info'; ?>"><i class="fas fa-envelope"></i> <?php echo !empty($currentUser['email_two_factor_enabled'])?'E-posta 2FA etkin.':'E-posta 2FA pasif.'; ?></div>
                    <form method="POST">
                        <input type="hidden" name="enable_email_2fa" value="<?php echo empty($currentUser['email_two_factor_enabled'])?'1':'0'; ?>">
                        <div class="form-group"><label class="form-label">Mevcut şifre</label><input type="password" name="current_password_security" class="form-control" required autocomplete="current-password"></div>
                        <button class="btn <?php echo empty($currentUser['email_two_factor_enabled'])?'btn-primary':'btn-danger'; ?>" name="toggle_email_2fa"><i class="fas fa-envelope"></i> <?php echo empty($currentUser['email_two_factor_enabled'])?'E-posta 2FA’yı Etkinleştir':'E-posta 2FA’yı Kapat'; ?></button>
                    </form>
                </div>
            </div>

        <?php if(moni_plugin_enabled('telegram_miniapp',$db)): ?><div class="form-card" style="margin-bottom:25px"><div class="form-card-header"><i class="fab fa-telegram"></i><h3>Telegram Mini App</h3></div><div class="form-card-body"><p class="form-hint">Telegram içindeki Mini App hesabınızı <?=clean($siteSettings['name'] ?? 'hesabınıza')?> hesabınıza tek kullanımlık kodla bağlayın. Bağlantı kodu 10 dakika geçerlidir.</p><?php if(!empty($currentUser['telegram_user_id'])):?><div class="alert alert-success"><i class="fas fa-check-circle"></i> Telegram hesabınız bağlı.</div><?php endif;?><?php if(!empty($telegramLinkCodeOnce)):?><div class="api-key-field"><input id="tgLinkCode" value="<?=clean($telegramLinkCodeOnce)?>" readonly><button type="button" onclick="navigator.clipboard.writeText(document.getElementById('tgLinkCode').value)"><i class="fas fa-copy"></i></button></div><?php endif;?><form method="post" style="margin-top:12px"><button class="btn btn-primary" name="generate_telegram_link"><i class="fab fa-telegram"></i> Tek Kullanımlık Bağlantı Kodu Oluştur</button></form></div></div><?php endif; ?>

            <!-- Password Change Box -->
            <div class="form-card">
                <div class="form-card-header">
                    <i class="fas fa-key"></i>
                    <h3><?php echo __('change_password'); ?></h3>
                </div>
                <div class="form-card-body">
                    <div class="security-info">
                        <h5><i class="fas fa-shield-alt"></i> <?php echo __('security_tip') ?: 'Güvenlik İpucu'; ?></h5>
                        <p><?php echo __('password_requirements') ?: 'Şifreniz en az 8 karakter olmalı.'; ?></p>
                    </div>

                    <form method="POST">
                        <div class="form-group">
                            <label class="form-label"><?php echo __('current_password'); ?> <span class="required">*</span></label>
                            <div class="input-group">
                                <input type="password" name="current_password" id="currentPassword" class="form-control" required placeholder="<?php echo __('enter_current_password'); ?>">
                                <button type="button" class="toggle-password" onclick="togglePassword('currentPassword')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label"><?php echo __('new_password'); ?> <span class="required">*</span></label>
                                <div class="input-group">
                                    <input type="password" name="new_password" id="newPassword" class="form-control" required placeholder="<?php echo __('enter_new_password'); ?>" minlength="8">
                                    <button type="button" class="toggle-password" onclick="togglePassword('newPassword')">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label"><?php echo __('confirm_new_password'); ?> <span class="required">*</span></label>
                                <div class="input-group">
                                    <input type="password" name="confirm_password" id="confirmPassword" class="form-control" required placeholder="<?php echo __('reenter_new_password'); ?>" minlength="8">
                                    <button type="button" class="toggle-password" onclick="togglePassword('confirmPassword')">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" name="change_password" class="btn btn-primary">
                                <i class="fas fa-lock"></i> <?php echo __('change_password'); ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        


        <!-- Activity Tab -->
        <div class="tab-content" id="tab-activity">
            <div class="form-card">
                <div class="form-card-header">
                    <i class="fas fa-history"></i>
                    <h3><?php echo __('recent_orders'); ?></h3>
                </div>
                <div class="form-card-body">
                    <?php if (empty($activities)): ?>
                        <div class="empty-activity">
                            <i class="fas fa-shopping-bag"></i>
                            <p><?php echo __('no_orders'); ?></p>
                        </div>
                    <?php else: ?>
                        <div class="activity-list">
                            <?php foreach ($activities as $order): ?>
                                <div class="activity-item">
                                    <div class="activity-icon">
                                        <i class="fas fa-shopping-cart"></i>
                                    </div>
                                    <div class="activity-info">
                                        <h5><?php echo clean($order['service_name'] ?: __('order') . ' #' . $order['id']); ?></h5>
                                        <p><?php echo moni_format_user_time($db,(int)$_SESSION['user_id'],$order['created_at']); ?> • <?php echo number_format($order['quantity']); ?> <?php echo __('pieces'); ?></p>
                                    </div>
                                    <div class="activity-meta">
                                        <div class="amount">-<?php echo ($siteSettings['currency_symbol'] ?? '₺') . number_format($order['price'], 2); ?></div>
                                        <span class="status-badge status-<?php echo $order['status']; ?>">
                                            <?php echo __('status_' . $order['status']); ?>
                                        </span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div style="text-align: center; margin-top: 25px;">
                            <a href="/kullanici/orders.php" class="btn btn-secondary">
                                <i class="fas fa-list"></i> <?php echo __('view_all_orders'); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Çeviri metinleri
const t = {
    passwords_not_match: '<?php echo __('passwords_not_match'); ?>',
    copied_msg: '<?php echo __('copied_msg'); ?>'
};

// Tab switching
document.querySelectorAll('.profile-tab').forEach(tab => {
    tab.addEventListener('click', function() {
        document.querySelectorAll('.profile-tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        
        this.classList.add('active');
        document.getElementById('tab-' + this.dataset.tab).classList.add('active');
    });
});

// Toggle password visibility
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const icon = input.nextElementSibling.querySelector('i');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// Copy API Key
function copyApiKey() {
    const apiKeyField = document.getElementById('apiKeyField');
    apiKeyField.select();
    apiKeyField.setSelectionRange(0, 99999);
    document.execCommand('copy');
    
    const btn = apiKeyField.nextElementSibling;
    const originalHtml = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-check"></i>';
    btn.style.background = 'var(--success-color)';
    
    setTimeout(() => {
        btn.innerHTML = originalHtml;
        btn.style.background = '';
    }, 2000);
}

// Copy API URL
function copyApiUrl(btn) {
    const input = btn.previousElementSibling;
    input.select();
    input.setSelectionRange(0, 99999);
    document.execCommand('copy');
    
    const original = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-check"></i>';
    btn.style.background = 'var(--success-color)';
    setTimeout(() => {
        btn.innerHTML = original;
        btn.style.background = '';
    }, 2000);
}

// Password validation (formdan sadece şifre formunu kontrol et)
document.querySelectorAll('form').forEach(f => {
    f.addEventListener('submit', function(e) {
        if (this.querySelector('[name="change_password"]')) {
            const newPass = document.getElementById('newPassword')?.value;
            const confirmPass = document.getElementById('confirmPassword')?.value;
            if (newPass && confirmPass && newPass !== confirmPass) {
                e.preventDefault();
                alert(t.passwords_not_match);
            }
        }
    });
});
</script>

<?php require_once 'footer.php'; ?>