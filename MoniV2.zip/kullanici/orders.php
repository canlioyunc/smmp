<?php
/**
 * Kullanıcı Paneli - Siparişlerim
 * Dripfeed, Refill ve Cancel Destekli
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/MoniV2Compat.php';

// Türkiye saat dilimi
date_default_timezone_set('Europe/Istanbul');

if (!isLoggedIn()) {
    header('Location: /login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$autoTicketStatuses = ['cancelled', 'partial', 'refunded', 'error'];

function orderHasTicket(PDO $db, int $userId, int $orderId): bool {
    $stmt = $db->prepare("
        SELECT 1
        FROM support_tickets t
        LEFT JOIN support_ticket_orders sto ON sto.ticket_id = t.id
        WHERE t.user_id = ?
          AND (t.order_id = ? OR sto.order_id = ?)
        LIMIT 1
    ");
    $stmt->execute([$userId, $orderId, $orderId]);
    return (bool) $stmt->fetchColumn();
}

function orderHasPendingRefill(PDO $db, int $userId, int $orderId): bool {
    $stmt = $db->prepare("SELECT 1 FROM refill_requests WHERE order_id = ? AND user_id = ? AND status IN ('pending', 'processing') LIMIT 1");
    $stmt->execute([$orderId, $userId]);
    return (bool) $stmt->fetchColumn();
}

// ==================== AJAX: Durum Güncelleme ====================
if (isset($_POST['action']) && $_POST['action'] === 'check_status' && isset($_POST['order_id'])) {
    header('Content-Type: application/json');
    $orderId=(int)$_POST['order_id'];
    $st=$db->prepare("SELECT o.* FROM orders o WHERE o.id=? AND o.user_id=?");$st->execute([$orderId,$userId]);$order=$st->fetch(PDO::FETCH_ASSOC);
    if(!$order){echo json_encode(['success'=>false,'error'=>__('order_not_found')]);exit;}
    if(empty($order['api_order_id'])||empty($order['api_provider_id'])){echo json_encode(['success'=>false,'error'=>__('not_api_order')]);exit;}
    $r=moni_provider_status($db,$order);
    if(!$r['success']){echo json_encode(['success'=>false,'error'=>$r['error']??__('api_error')]);exit;}
    $applied=moni_apply_provider_status($db,$orderId,$r);
    if(empty($applied['success'])){echo json_encode(['success'=>false,'error'=>$applied['error']??__('api_error')]);exit;}
    $bal=$db->prepare("SELECT balance FROM users WHERE id=?");$bal->execute([$userId]);$_SESSION['balance']=(float)$bal->fetchColumn();
    echo json_encode(['success'=>true,'status'=>$applied['status'],'start_count'=>$applied['start_count'],'remains'=>$applied['remains']]);exit;
}

// ==================== AJAX: Sipariş İptal ====================
if (isset($_POST['action']) && $_POST['action'] === 'cancel_order' && isset($_POST['order_id'])) {
    header('Content-Type: application/json');
    $orderId=(int)$_POST['order_id'];
    $r=moni_cancel_user_order($db,$orderId,(int)$userId,'Kullanıcı sipariş iptali');
    if(!$r['success']){echo json_encode(['success'=>false,'error'=>$r['error']??__('order_cancel_failed')]);exit;}
    $bal=$db->prepare("SELECT balance FROM users WHERE id=?");$bal->execute([$userId]);$_SESSION['balance']=(float)$bal->fetchColumn();
    echo json_encode(['success'=>true,'message'=>__('order_cancelled'),'refund_amount'=>$r['refund_amount']??0]);exit;
}

// ==================== AJAX: Refill Talebi ====================
if (isset($_POST['action']) && $_POST['action'] === 'request_refill' && isset($_POST['order_id'])) {
    header('Content-Type: application/json');
    $orderId = (int)$_POST['order_id'];
    if (function_exists('moni_user_can') && !moni_user_can($db,(int)$userId,'refill.request',true)) {
        echo json_encode(['success'=>false,'error'=>'Refill talebi yetkiniz yönetici tarafından kapatılmış.']); exit;
    }

    try {
        $db->beginTransaction();

        // Sipariş satırını kilitle: paralel iki refill isteği aynı hakkı tüketemez.
        $stmt = $db->prepare("\n            SELECT o.*, s.name AS service_name\n            FROM orders o\n            LEFT JOIN services s ON o.service_id = s.id\n            WHERE o.id = ? AND o.user_id = ?\n            FOR UPDATE\n        ");
        $stmt->execute([$orderId, $userId]);
        $order = $stmt->fetch();

        if (!$order) {
            throw new RuntimeException(__('order_not_found'));
        }
        if ($order['status'] !== 'completed') {
            throw new RuntimeException(__('refill_only_completed'));
        }
        if (!($order['refill_enabled'] ?? 0)) {
            throw new RuntimeException(__('refill_not_available'));
        }
        if (($order['refill_until'] ?? null) && strtotime($order['refill_until']) < strtotime('today')) {
            throw new RuntimeException(__('refill_expired'));
        }
        if ((int)($order['refill_used'] ?? 0) >= (int)($order['refill_max'] ?? 0)) {
            throw new RuntimeException(__('refill_no_rights'));
        }

        $pending = $db->prepare("SELECT id FROM refill_requests WHERE order_id = ? AND user_id = ? AND status IN ('pending','processing') LIMIT 1 FOR UPDATE");
        $pending->execute([$orderId, $userId]);
        if ($pending->fetchColumn()) {
            throw new RuntimeException(__('refill_already_pending'));
        }

        $db->prepare("INSERT INTO refill_requests (order_id, user_id, api_order_id, quantity, status) VALUES (?, ?, ?, ?, 'pending')")
            ->execute([$orderId, $userId, $order['api_order_id'], $order['quantity']]);

        // Hakkı yalnız beklenen mevcut sayaçta artır. Başka akış değiştirdiyse işlem başarısız olur.
        $upd = $db->prepare("UPDATE orders SET refill_used = refill_used + 1 WHERE id = ? AND user_id = ? AND refill_used = ? AND refill_used < refill_max");
        $upd->execute([$orderId, $userId, (int)$order['refill_used']]);
        if ($upd->rowCount() !== 1) {
            throw new RuntimeException(__('refill_no_rights'));
        }

        $db->commit();
        echo json_encode(['success' => true, 'message' => __('refill_requested')]);
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

// ==================== Servis Puanlama ====================
if(isset($_POST['action']) && $_POST['action']==='submit_review'){
    $orderId=(int)($_POST['order_id']??0);
    $rating=(int)($_POST['rating']??0);
    $comment=trim((string)($_POST['comment']??''));

    if(!csrf_check($_POST['_token']??'')){
        $error='Güvenlik doğrulaması başarısız. Lütfen sayfayı yenileyip tekrar deneyin.';
    }elseif($rating<1||$rating>5){
        $error='Lütfen 1 ile 5 arasında bir puan seçin.';
    }else{
        try{
            $db->beginTransaction();
            $st=$db->prepare("SELECT id,service_id FROM orders WHERE id=? AND user_id=? AND status='completed' LIMIT 1 FOR UPDATE");
            $st->execute([$orderId,$userId]);
            $o=$st->fetch(PDO::FETCH_ASSOC);
            if(!$o)throw new RuntimeException('Yalnız tamamlanan kendi siparişlerinizi değerlendirebilirsiniz.');

            $already=$db->prepare("SELECT id FROM service_reviews WHERE order_id=? LIMIT 1 FOR UPDATE");
            $already->execute([$orderId]);
            if($already->fetchColumn())throw new RuntimeException('Bu sipariş için daha önce değerlendirme yaptınız. Her sipariş yalnızca bir kez değerlendirilebilir.');

            $reviewStatus=getSetting('service_reviews_require_moderation','0')==='1'?'pending':'approved';
            $ins=$db->prepare("INSERT INTO service_reviews(user_id,service_id,order_id,rating,comment,status) VALUES(?,?,?,?,?,?)");
            $ins->execute([$userId,$o['service_id'],$orderId,$rating,mb_substr($comment,0,1000),$reviewStatus]);
            $db->commit();
            $reviewMessage=$reviewStatus==='pending'?'Değerlendirmeniz kaydedildi ve yönetici onayına gönderildi.':'Değerlendirmeniz için teşekkürler. Puanınız kaydedildi.';
            header('Location: orders.php?success='.urlencode($reviewMessage));
            exit;
        }catch(Throwable $e){
            if($db->inTransaction())$db->rollBack();
            $error=$e->getMessage();
            if($e instanceof PDOException && (string)$e->getCode()==='23000'){
                $error='Bu sipariş için daha önce değerlendirme yaptınız. Her sipariş yalnızca bir kez değerlendirilebilir.';
            }
        }
    }
}

// ==================== Destek Talebi Aç ====================
if (isset($_POST['action']) && $_POST['action'] === 'open_ticket' && isset($_POST['order_id'])) {
    if (function_exists('moni_user_can') && !moni_user_can($db,(int)$userId,'support.create',true)) {
        setAlert('Destek talebi açma yetkiniz yönetici tarafından kapatılmış.','error');
        header('Location: orders.php'); exit;
    }
    $orderId = (int)$_POST['order_id'];

    $stmt = $db->prepare("
        SELECT o.*, s.name AS service_name
        FROM orders o
        LEFT JOIN services s ON o.service_id = s.id
        WHERE o.id = ? AND o.user_id = ?
    ");
    $stmt->execute([$orderId, $userId]);
    $order = $stmt->fetch();

    if ($order && in_array($order['status'], $autoTicketStatuses)) {
        if (!orderHasTicket($db, $userId, $orderId)) {
            try {
                $db->beginTransaction();

                $subject = 'Sipariş #' . $orderId . ' için destek talebi';
                $message = "Merhaba,\nSipariş durumum: " . strtoupper($order['status']) . "\nHizmet: " . ($order['service_name'] ?? 'Hizmet #' . $order['service_id']) . "\nLütfen inceleyiniz.";
                $priority = 'medium';

                $stmt = $db->prepare("INSERT INTO support_tickets (user_id, order_id, subject, priority) VALUES (?, ?, ?, ?)");
                $stmt->execute([$userId, $orderId, $subject, $priority]);
                $ticketId = $db->lastInsertId();

                $db->prepare("INSERT INTO support_ticket_orders (ticket_id, order_id) VALUES (?, ?)")->execute([$ticketId, $orderId]);

                $stmt = $db->prepare("INSERT INTO support_messages (ticket_id, user_id, message, attachment, is_admin) VALUES (?, ?, ?, ?, 0)");
                $stmt->execute([$ticketId, $userId, $message, null]);

                $db->commit();
                header('Location: /kullanici/support.php?ticket=' . $ticketId . '&success=created');
                exit;
            } catch (Exception $e) {
                $db->rollBack();
                $error = $e->getMessage();
            }
        } else {
            $error = 'Bu sipariş için mevcut bir destek talebi zaten var.';
        }
    } else {
        $error = 'Bu sipariş için destek talebi açılamaz.';
    }
}

// ==================== Filtreler ====================
$status = $_GET['status'] ?? '';
$search = $_GET['search'] ?? '';
$dateFrom = $_GET['date_from'] ?? '';
$dateTo = $_GET['date_to'] ?? '';
$typeFilter = $_GET['type'] ?? '';

$where = "WHERE o.user_id = ?";
$params = [$userId];

if ($status) {
    $where .= " AND o.status = ?";
    $params[] = $status;
}

if ($search) {
    $where .= " AND (o.id = ? OR o.link LIKE ? OR s.name LIKE ?)";
    $params[] = $search;
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($dateFrom) {
    $where .= " AND DATE(o.created_at) >= ?";
    $params[] = $dateFrom;
}

if ($dateTo) {
    $where .= " AND DATE(o.created_at) <= ?";
    $params[] = $dateTo;
}

if ($typeFilter === 'dripfeed') {
    $where .= " AND o.dripfeed_id IS NOT NULL AND o.dripfeed_id > 0";
}

// Sayfalama
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

$countStmt = $db->prepare("SELECT COUNT(*) FROM orders o LEFT JOIN services s ON o.service_id = s.id $where");
$countStmt->execute($params);
$totalOrders = $countStmt->fetchColumn();
$totalPages = ceil($totalOrders / $perPage);

// Siparişleri getir
$stmt = $db->prepare("
    SELECT o.*, 
           s.name as service_name, 
           s.description as service_description,
           s.cancel as service_cancel,
           c.name as category_name, 
           c.icon as category_icon,
           c.icon_color as category_color,
           df.runs as dripfeed_total_runs,
           df.completed_runs as dripfeed_completed_runs,
           df.status as dripfeed_status
    FROM orders o
    LEFT JOIN services s ON o.service_id = s.id
    LEFT JOIN categories c ON s.category_id = c.id
    LEFT JOIN orders_dripfeed df ON o.dripfeed_id = df.id
    $where
    ORDER BY o.created_at DESC
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Dripfeed part numaraları
$dripfeedIds = [];
foreach ($orders as $order) {
    if (!empty($order['dripfeed_id']) && $order['dripfeed_id'] > 0) {
        $dripfeedIds[$order['dripfeed_id']] = true;
    }
}

$dripfeedPartNumbers = [];
if (!empty($dripfeedIds)) {
    $dfIdList = implode(',', array_keys($dripfeedIds));
    $partStmt = $db->query("
        SELECT id, dripfeed_id, 
               ROW_NUMBER() OVER (PARTITION BY dripfeed_id ORDER BY id ASC) as part_number
        FROM orders 
        WHERE dripfeed_id IN ($dfIdList)
        ORDER BY dripfeed_id, id
    ");
    foreach ($partStmt->fetchAll() as $row) {
        $dripfeedPartNumbers[$row['id']] = $row['part_number'];
    }
}

// Destek talebi kontrolü
$orderIds = array_column($orders, 'id');
$ordersWithTicket = [];
if (!empty($orderIds)) {
    $placeholders = implode(',', array_fill(0, count($orderIds), '?'));
    $stmt = $db->prepare("
        SELECT DISTINCT sto.order_id
        FROM support_ticket_orders sto
        JOIN support_tickets t ON t.id = sto.ticket_id
        WHERE t.user_id = ? AND sto.order_id IN ($placeholders)
    ");
    $stmt->execute(array_merge([$userId], $orderIds));
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $oid) {
        $ordersWithTicket[(int)$oid] = true;
    }
    $stmt = $db->prepare("
        SELECT DISTINCT t.order_id
        FROM support_tickets t
        WHERE t.user_id = ? AND t.order_id IN ($placeholders)
    ");
    $stmt->execute(array_merge([$userId], $orderIds));
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $oid) {
        if ($oid !== null) {
            $ordersWithTicket[(int)$oid] = true;
        }
    }
}

// Bekleyen refill talepleri
$ordersWithPendingRefill = [];
if (!empty($orderIds)) {
    $placeholders = implode(',', array_fill(0, count($orderIds), '?'));
    $stmt = $db->prepare("SELECT DISTINCT order_id FROM refill_requests WHERE user_id = ? AND order_id IN ($placeholders) AND status IN ('pending', 'processing')");
    $stmt->execute(array_merge([$userId], $orderIds));
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $oid) {
        $ordersWithPendingRefill[(int)$oid] = true;
    }
}

// Bu sayfadaki siparişlerin daha önce değerlendirilip değerlendirilmediğini tek sorguda al.
$reviewsByOrder = [];
if (!empty($orderIds)) {
    try {
        $placeholders = implode(',', array_fill(0, count($orderIds), '?'));
        $reviewStmt = $db->prepare("SELECT order_id,rating,comment,status,created_at FROM service_reviews WHERE user_id=? AND order_id IN ($placeholders)");
        $reviewStmt->execute(array_merge([(int)$userId], $orderIds));
        foreach ($reviewStmt->fetchAll(PDO::FETCH_ASSOC) as $reviewRow) {
            $reviewsByOrder[(int)$reviewRow['order_id']] = $reviewRow;
        }
    } catch (Throwable $ignore) {
        $reviewsByOrder = [];
    }
}

// İstatistikler
$statsStmt = $db->prepare("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status IN ('pending', 'processing', 'in_progress') THEN 1 ELSE 0 END) as active,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
        SUM(CASE WHEN status IN ('cancelled', 'refunded', 'error') THEN 1 ELSE 0 END) as cancelled,
        SUM(CASE WHEN dripfeed_id IS NOT NULL AND dripfeed_id > 0 THEN 1 ELSE 0 END) as dripfeed,
        SUM(price) as total_spent
    FROM orders 
    WHERE user_id = ?
");
$statsStmt->execute([$userId]);
$stats = $statsStmt->fetch();

$statusIcons = [
    'pending' => 'fa-clock',
    'processing' => 'fa-cog fa-spin',
    'in_progress' => 'fa-spinner fa-pulse',
    'completed' => 'fa-check-circle',
    'partial' => 'fa-exclamation-circle',
    'cancelled' => 'fa-times-circle',
    'refunded' => 'fa-undo',
    'error' => 'fa-exclamation-triangle'
];

$successMsg = '';
if (isset($_GET['success'])) {
    $successMsg = $_GET['success'];
}

$pageTitle = __('my_orders');
require_once 'header.php';
?>
<style>
.card, .card-body { min-width: 0; }

.stats-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 15px;
    margin-bottom: 25px;
}

.stat-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 12px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 15px;
}

.stat-card .icon {
    width: 50px;
    height: 50px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.2rem;
}

.stat-card .icon.total { background: var(--primary-alpha-015); color: var(--accent-text-color); }
.stat-card .icon.active { background: var(--info-soft-bg); color: var(--info-color); }
.stat-card .icon.completed { background: var(--success-soft-bg); color: var(--success-color); }
.stat-card .icon.cancelled { background: var(--danger-soft-bg); color: var(--danger-color); }
.stat-card .icon.dripfeed { background: rgba(0, 123, 255, 0.15); color: var(--info-color); }

.stat-card .info h4 { font-size: 1.4rem; font-weight: 700; margin-bottom: 2px; }
.stat-card .info p { font-size: 0.85rem; opacity: 0.6; }

.filters-bar {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: 20px;
    align-items: center;
}

.filters-bar .form-control { padding: 10px 15px; min-width: 150px; }
.filters-bar .search-input { flex: 1; min-width: 200px; }

.status-filters { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 20px; }

.status-filter {
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all 0.2s ease;
    border: 1px solid var(--border-color);
    background: var(--background-color);
    color: var(--text-color);
}

.status-filter:hover, .status-filter.active {
    background: var(--primary-color);
    border-color: var(--accent-text-color);
    color: var(--on-primary-color);
}

.status-filter.dripfeed-filter:hover, .status-filter.dripfeed-filter.active {
    background: var(--info-color);
    border-color: var(--info-color);
}

.status-filter .count {
    background: rgba(255,255,255,0.2);
    padding: 2px 8px;
    border-radius: 10px;
    margin-left: 5px;
    font-size: 0.75rem;
}

.orders-table-wrapper {
    width: 100%;
    max-width: 100%;
    min-width: 0;
    overflow-x: auto;
    overflow-y: visible;
    -webkit-overflow-scrolling: touch;
    overscroll-behavior-inline: contain;
    scrollbar-width: thin;
    scrollbar-color: var(--border-color) transparent;
    padding-bottom: 8px;
}
.orders-table-wrapper::-webkit-scrollbar { height: 9px; }
.orders-table-wrapper::-webkit-scrollbar-track { background: transparent; }
.orders-table-wrapper::-webkit-scrollbar-thumb {
    background: var(--border-color);
    border: 2px solid transparent;
    background-clip: padding-box;
    border-radius: 999px;
}
.orders-table-wrapper::-webkit-scrollbar-thumb:hover { background: var(--muted-text-color); background-clip: padding-box; }
.orders-table {
    width: 100%;
    min-width: 1120px;
    border-collapse: collapse;
}
.orders-table th, .orders-table td { padding: 15px; text-align: left; border-bottom: 1px solid var(--border-color); }
.orders-table th { background: var(--background-color); font-weight: 600; font-size: 0.8rem; text-transform: uppercase; color: var(--text-color); opacity: 0.7; }
.orders-table tbody tr { transition: all 0.2s ease; }
.orders-table tbody tr:hover { background: var(--background-color); }

.order-id { font-weight: 600; color: var(--accent-text-color); }
.order-id-cell { min-width: 140px; }
.order-id-cell .order-id { display: block; margin-bottom: 6px; }

.dripfeed-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 5px 10px;
    background: linear-gradient(135deg, rgba(0, 123, 255, 0.15) 0%, rgba(0, 123, 255, 0.08) 100%);
    border: 1px solid rgba(0, 123, 255, 0.3);
    border-radius: 8px;
    font-size: 0.75rem;
    color: var(--info-color);
    font-weight: 600;
}

.dripfeed-badge i { font-size: 0.7rem; }
.dripfeed-badge .part-info { background: rgba(0, 123, 255, 0.2); padding: 2px 6px; border-radius: 4px; font-size: 0.7rem; }

.dripfeed-row {
    background: linear-gradient(90deg, rgba(0, 123, 255, 0.03) 0%, transparent 100%);
    border-left: 3px solid var(--info-color);
}

.dripfeed-row:hover { background: linear-gradient(90deg, rgba(0, 123, 255, 0.08) 0%, var(--background-color) 100%) !important; }

.order-service { display: flex; align-items: center; gap: 12px; }
.order-service .icon { width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 1rem; }
.order-service .info h5 { font-size: 0.9rem; font-weight: 600; margin-bottom: 2px; max-width: 250px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.order-service .info p { font-size: 0.8rem; opacity: 0.6; max-width: 250px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

.order-link { max-width: 200px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-size: 0.85rem; }
.order-link a { color: var(--accent-text-color); text-decoration: none; }
.order-link a:hover { text-decoration: underline; }

.order-quantity { font-weight: 600; }
.order-price { font-weight: 600; color: var(--success-color); }
.order-date { font-size: 0.85rem; opacity: 0.7; }

.order-actions { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }

.action-btn {
    width: 34px;
    height: 34px;
    border-radius: 8px;
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.2s ease;
    font-size: 0.85rem;
}

.action-btn:hover { transform: scale(1.1); }
.action-btn.view { background: var(--primary-alpha-015); color: var(--accent-text-color); }
.action-btn.copy { background: var(--info-soft-bg); color: var(--info-color); }
.action-btn.refresh { background: var(--success-soft-bg); color: var(--success-color); }
.action-btn.cancel { background: var(--danger-soft-bg); color: var(--danger-color); }
.action-btn.refill { background: rgba(255, 193, 7, 0.15); color: #d39e00; }
.action-btn.refill-pending { background: rgba(255, 193, 7, 0.25); color: #d39e00; cursor: default; }

.action-btn.loading { pointer-events: none; }
.action-btn.loading i { animation: spin 1s linear infinite; }

@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }

.refill-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 4px 8px;
    background: rgba(40, 167, 69, 0.12);
    border: 1px solid rgba(40, 167, 69, 0.3);
    border-radius: 6px;
    font-size: 0.7rem;
    color: var(--success-color);
    font-weight: 500;
    margin-top: 5px;
}

.refill-badge.expired { background: rgba(108, 117, 125, 0.12); border-color: rgba(108, 117, 125, 0.3); color: var(--muted-text-color); }
.refill-badge.no-rights { background: rgba(220, 53, 69, 0.12); border-color: rgba(220, 53, 69, 0.3); color: var(--danger-color); }

.orders-cards { display: none; }

@media (max-width: 992px) {
    .orders-table-wrapper { display: none; }
    .orders-cards { display: flex; flex-direction: column; gap: 15px; }
    .order-card { background: var(--card-bg-color); border: 1px solid var(--border-color); border-radius: 12px; padding: 20px; }
    .order-card.dripfeed-card { border-left: 4px solid var(--info-color); background: linear-gradient(135deg, rgba(0, 123, 255, 0.05) 0%, var(--card-bg-color) 100%); }
    .order-card-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 15px; gap: 10px; }
    .order-card-header .order-id { font-size: 1rem; margin-bottom: 8px; }
    .order-card-body { display: flex; flex-direction: column; gap: 12px; }
    .order-card-row { display: flex; justify-content: space-between; font-size: 0.9rem; }
    .order-card-row .label { opacity: 0.6; }
    .order-card-row .value { font-weight: 500; text-align: right; max-width: 60%; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .order-card-footer { display: flex; gap: 10px; margin-top: 15px; padding-top: 15px; border-top: 1px solid var(--border-color); flex-wrap: wrap; }
    .order-card-footer .btn { flex: 1; padding: 10px; font-size: 0.85rem; min-width: 70px; }
}

.empty-state { text-align: center; padding: 60px 20px; }
.empty-state i { font-size: 4rem; color: var(--accent-text-color); opacity: 0.3; margin-bottom: 20px; }
.empty-state h3 { font-size: 1.2rem; margin-bottom: 10px; opacity: 0.8; }
.empty-state p { opacity: 0.6; margin-bottom: 20px; }

.pagination { display: flex; justify-content: center; gap: 8px; margin-top: 25px; flex-wrap: wrap; }
.pagination a, .pagination span { padding: 10px 16px; border-radius: 8px; text-decoration: none; font-size: 0.9rem; font-weight: 500; }
.pagination a { background: var(--background-color); color: var(--text-color); border: 1px solid var(--border-color); transition: all 0.2s ease; }
.pagination a:hover { border-color: var(--accent-text-color); color: var(--accent-text-color); }
.pagination .current { background: var(--primary-color); color: var(--on-primary-color); border: 1px solid var(--primary-color); }
.pagination .disabled { opacity: 0.5; pointer-events: none; }

.modal-overlay { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0, 0, 0, 0.7); z-index: 2000; align-items: center; justify-content: center; padding: 20px; }
.modal-overlay.active { display: flex; }
.modal-box { background: var(--card-bg-color); border-radius: 16px; width: 100%; max-width: 500px; max-height: 90vh; overflow-y: auto; animation: modalSlide 0.3s ease; }
@keyframes modalSlide { from { opacity: 0; transform: translateY(-30px); } to { opacity: 1; transform: translateY(0); } }

.modal-header { padding: 20px 25px; border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center; }
.modal-header h3 { font-size: 1.1rem; display: flex; align-items: center; gap: 10px; }
.modal-header h3 i { color: var(--accent-text-color); }
.modal-close { background: var(--background-color); border: none; width: 36px; height: 36px; border-radius: 8px; font-size: 1.2rem; cursor: pointer; color: var(--text-color); display: flex; align-items: center; justify-content: center; transition: all 0.2s ease; }
.modal-close:hover { background: var(--danger-color); color: var(--on-danger-color); }

.modal-body { padding: 25px; }
.detail-row { display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid var(--border-color); }
.detail-row:last-child { border-bottom: none; }
.detail-row .label { font-size: 0.9rem; opacity: 0.7; }
.detail-row .value { font-weight: 600; font-size: 0.9rem; text-align: right; max-width: 60%; word-break: break-all; }
.detail-row .value a { color: var(--accent-text-color); text-decoration: none; }
.detail-row .value a:hover { text-decoration: underline; }

.modal-dripfeed-box { background: linear-gradient(135deg, rgba(0, 123, 255, 0.1) 0%, rgba(0, 123, 255, 0.05) 100%); border: 1px solid rgba(0, 123, 255, 0.3); border-radius: 12px; padding: 18px; margin-bottom: 20px; }
.modal-dripfeed-box h5 { color: var(--info-color); font-size: 0.95rem; margin-bottom: 12px; display: flex; align-items: center; gap: 8px; }
.modal-dripfeed-box .dripfeed-detail { display: flex; justify-content: space-between; padding: 8px 0; font-size: 0.85rem; border-bottom: 1px solid rgba(0, 123, 255, 0.15); }
.modal-dripfeed-box .dripfeed-detail:last-child { border-bottom: none; }
.modal-dripfeed-box .dripfeed-detail .label { opacity: 0.8; }
.modal-dripfeed-box .dripfeed-detail .value { font-weight: 600; color: var(--info-color); }

.modal-refill-box { background: linear-gradient(135deg, var(--success-soft-bg) 0%, rgba(40, 167, 69, 0.05) 100%); border: 1px solid rgba(40, 167, 69, 0.3); border-radius: 12px; padding: 18px; margin-bottom: 20px; }
.modal-refill-box h5 { color: var(--success-color); font-size: 0.95rem; margin-bottom: 12px; display: flex; align-items: center; gap: 8px; }
.modal-refill-box .refill-detail { display: flex; justify-content: space-between; padding: 8px 0; font-size: 0.85rem; border-bottom: 1px solid var(--success-soft-bg); }
.modal-refill-box .refill-detail:last-child { border-bottom: none; }
.modal-refill-box .refill-detail .label { opacity: 0.8; }
.modal-refill-box .refill-detail .value { font-weight: 600; color: var(--success-color); }
.modal-refill-box.expired { background: linear-gradient(135deg, rgba(108, 117, 125, 0.1) 0%, rgba(108, 117, 125, 0.05) 100%); border-color: rgba(108, 117, 125, 0.3); }
.modal-refill-box.expired h5 { color: var(--muted-text-color); }
.modal-refill-box.expired .refill-detail .value { color: var(--muted-text-color); }

.modal-footer { padding: 20px 25px; border-top: 1px solid var(--border-color); display: flex; gap: 10px; flex-wrap: wrap; }
.modal-footer .btn { flex: 1; min-width: 100px; }

.refresh-all-btn { display: flex; align-items: center; gap: 8px; }
.refresh-all-btn.loading { pointer-events: none; opacity: 0.7; }
.refresh-all-btn.loading i { animation: spin 1s linear infinite; }

.ticket-open-icon { display: inline-flex; align-items: center; gap: 6px; font-size: 0.85rem; opacity: 0.7; }

/* Sipariş değerlendirme deneyimi */
.action-btn.rating-trigger { background: rgba(245, 183, 54, .14); color: #e7ad2c; }
.action-btn.rating-trigger:hover { background: rgba(245, 183, 54, .22); }
.rating-done-chip {
    height: 34px; padding: 0 10px; border-radius: 9px; display: inline-flex; align-items: center; gap: 6px;
    background: rgba(245, 183, 54, .10); border: 1px solid rgba(245, 183, 54, .22); color: #e3a51f;
    font-size: .74rem; font-weight: 700; white-space: nowrap; cursor: default;
}
.rating-done-chip i { font-size: .72rem; }
.rating-modal-box { max-width: 440px; overflow: hidden; }
.rating-modal-body { padding: 0; }
.rating-modal-intro { padding: 24px 25px 18px; text-align: center; border-bottom: 1px solid var(--border-color); }
.rating-modal-icon {
    width: 48px; height: 48px; margin: 0 auto 12px; border-radius: 14px; display: grid; place-items: center;
    background: rgba(245, 183, 54, .12); color: #e3a51f; font-size: 1.1rem;
}
.rating-service-name { font-weight: 700; font-size: .94rem; line-height: 1.4; color: var(--text-color); }
.rating-order-meta { margin-top: 5px; font-size: .75rem; color: var(--muted-text-color); }
.rating-form-content { padding: 22px 25px 24px; }
.rating-question { text-align: center; font-size: .8rem; color: var(--muted-text-color); margin-bottom: 13px; }
.rating-stars-picker { display: flex; align-items: center; justify-content: center; gap: 8px; margin-bottom: 9px; }
.rating-star {
    width: 44px; height: 44px; border: 1px solid var(--border-color); border-radius: 12px; background: var(--background-color);
    color: color-mix(in srgb, var(--muted-text-color) 55%, transparent); font-size: 1.05rem; cursor: pointer;
    display: grid; place-items: center; transition: transform .15s ease, border-color .15s ease, background .15s ease, color .15s ease;
}
.rating-star:hover { transform: translateY(-2px); border-color: rgba(245,183,54,.45); color: #e3a51f; }
.rating-star.is-selected { background: rgba(245,183,54,.14); border-color: rgba(245,183,54,.38); color: #e3a51f; }
.rating-choice-label { min-height: 20px; text-align: center; margin-bottom: 18px; font-size: .76rem; font-weight: 650; color: var(--muted-text-color); }
.rating-comment-label { display: flex; justify-content: space-between; gap: 10px; align-items: center; margin-bottom: 8px; font-size: .78rem; font-weight: 650; }
.rating-comment-label small { font-weight: 500; color: var(--muted-text-color); }
.rating-comment {
    width: 100%; min-height: 92px; resize: vertical; border: 1px solid var(--border-color); background: var(--background-color);
    color: var(--text-color); border-radius: 11px; padding: 12px 13px; line-height: 1.45; outline: none; font: inherit; font-size: .82rem;
}
.rating-comment:focus { border-color: var(--primary-color); box-shadow: 0 0 0 3px var(--primary-alpha-01); }
.rating-modal-footer { padding: 15px 25px 20px; border-top: 1px solid var(--border-color); display: flex; gap: 10px; }
.rating-modal-footer .btn { min-height: 40px; }
.rating-submit { flex: 1; }
.rating-mobile-done {
    display: inline-flex; align-items: center; gap: 7px; min-height: 39px; padding: 0 12px; border-radius: 9px;
    background: rgba(245,183,54,.10); border: 1px solid rgba(245,183,54,.22); color: #e3a51f; font-size: .78rem; font-weight: 700;
}
@media (max-width: 520px) {
    .rating-modal-box { max-width: 100%; }
    .rating-stars-picker { gap: 6px; }
    .rating-star { width: 40px; height: 40px; border-radius: 10px; }
    .rating-modal-intro, .rating-form-content { padding-left: 18px; padding-right: 18px; }
    .rating-modal-footer { padding-left: 18px; padding-right: 18px; }
}
</style>

<?php if ($successMsg): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?php echo clean($successMsg); ?>
    </div>
<?php endif; ?>
<?php if (!empty($error)): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?php echo clean($error); ?>
    </div>
<?php endif; ?>

<div class="stats-row">
    <div class="stat-card">
        <div class="icon total"><i class="fas fa-shopping-bag"></i></div>
        <div class="info">
            <h4><?php echo number_format($stats['total'] ?? 0); ?></h4>
            <p><?php echo __('total_orders'); ?></p>
        </div>
    </div>
    <div class="stat-card">
        <div class="icon active"><i class="fas fa-spinner"></i></div>
        <div class="info">
            <h4><?php echo number_format($stats['active'] ?? 0); ?></h4>
            <p><?php echo __('active_orders'); ?></p>
        </div>
    </div>
    <div class="stat-card">
        <div class="icon completed"><i class="fas fa-check"></i></div>
        <div class="info">
            <h4><?php echo number_format($stats['completed'] ?? 0); ?></h4>
            <p><?php echo __('completed_orders'); ?></p>
        </div>
    </div>
    <div class="stat-card">
        <div class="icon dripfeed"><i class="fas fa-tint"></i></div>
        <div class="info">
            <h4><?php echo number_format($stats['dripfeed'] ?? 0); ?></h4>
            <p>Dripfeed</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="icon cancelled"><i class="fas fa-times"></i></div>
        <div class="info">
            <h4><?php echo number_format($stats['cancelled'] ?? 0); ?></h4>
            <p><?php echo __('cancelled_refunded'); ?></p>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2><i class="fas fa-shopping-cart"></i> <?php echo __('my_orders'); ?></h2>
        <div style="display: flex; gap: 10px;">
            <button type="button" class="btn btn-secondary btn-sm refresh-all-btn" onclick="refreshAllOrders()" id="refreshAllBtn">
                <i class="fas fa-sync-alt"></i> <?php echo __('update_statuses'); ?>
            </button>
            <a href="/kullanici/new-order.php" class="btn btn-primary btn-sm">
                <i class="fas fa-plus"></i> <?php echo __('new_order'); ?>
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="status-filters">
            <a href="orders.php" class="status-filter <?php echo !$status && !$typeFilter ? 'active' : ''; ?>">
                <?php echo __('all'); ?> <span class="count"><?php echo $stats['total'] ?? 0; ?></span>
            </a>
            <a href="orders.php?status=pending" class="status-filter <?php echo $status === 'pending' ? 'active' : ''; ?>">
                <i class="fas fa-clock"></i> <?php echo __('status_pending'); ?>
            </a>
            <a href="orders.php?status=processing" class="status-filter <?php echo $status === 'processing' ? 'active' : ''; ?>">
                <i class="fas fa-cog"></i> <?php echo __('status_processing'); ?>
            </a>
            <a href="orders.php?status=in_progress" class="status-filter <?php echo $status === 'in_progress' ? 'active' : ''; ?>">
                <i class="fas fa-spinner"></i> <?php echo __('status_in_progress'); ?>
            </a>
            <a href="orders.php?status=completed" class="status-filter <?php echo $status === 'completed' ? 'active' : ''; ?>">
                <i class="fas fa-check"></i> <?php echo __('status_completed'); ?>
            </a>
            <a href="orders.php?status=cancelled" class="status-filter <?php echo $status === 'cancelled' ? 'active' : ''; ?>">
                <i class="fas fa-times"></i> <?php echo __('status_cancelled'); ?>
            </a>
            <a href="orders.php?type=dripfeed" class="status-filter dripfeed-filter <?php echo $typeFilter === 'dripfeed' ? 'active' : ''; ?>">
                <i class="fas fa-tint"></i> Dripfeed <span class="count"><?php echo $stats['dripfeed'] ?? 0; ?></span>
            </a>
        </div>
        
        <form method="GET" class="filters-bar">
            <?php if ($status): ?>
                <input type="hidden" name="status" value="<?php echo clean($status); ?>">
            <?php endif; ?>
            <?php if ($typeFilter): ?>
                <input type="hidden" name="type" value="<?php echo clean($typeFilter); ?>">
            <?php endif; ?>
            <input type="text" name="search" class="form-control search-input" placeholder="<?php echo __('search_order_id_or_link'); ?>..." value="<?php echo clean($search); ?>">
            <input type="date" name="date_from" class="form-control" value="<?php echo clean($dateFrom); ?>" title="<?php echo __('start_date'); ?>">
            <input type="date" name="date_to" class="form-control" value="<?php echo clean($dateTo); ?>" title="<?php echo __('end_date'); ?>">
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i></button>
            <?php if ($search || $dateFrom || $dateTo): ?>
                <a href="orders.php<?php echo $status ? '?status=' . $status : ($typeFilter ? '?type=' . $typeFilter : ''); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-times"></i></a>
            <?php endif; ?>
        </form>
        
        <?php if (empty($orders)): ?>
            <div class="empty-state">
                <i class="fas fa-shopping-bag"></i>
                <h3><?php echo __('no_orders_found'); ?></h3>
                <p><?php echo __('no_orders_message'); ?></p>
                <a href="/kullanici/new-order.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> <?php echo __('place_first_order'); ?>
                </a>
            </div>
        <?php else: ?>
            <div class="orders-table-wrapper">
                <table class="orders-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th><?php echo __('service'); ?></th>
                            <th><?php echo __('link'); ?></th>
                            <th><?php echo __('quantity'); ?></th>
                            <th><?php echo __('price'); ?></th>
                            <th><?php echo __('status'); ?></th>
                            <th><?php echo __('date'); ?></th>
                            <th><?php echo __('action'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): 
                            $existingReview = $reviewsByOrder[(int)$order['id']] ?? null;
                            $hasTicket = !empty($ordersWithTicket[$order['id']]);
                            $canOpenTicket = in_array($order['status'], $autoTicketStatuses) && !$hasTicket;
                            $isDripfeed = !empty($order['dripfeed_id']) && $order['dripfeed_id'] > 0;
                            $partNumber = $dripfeedPartNumbers[$order['id']] ?? null;
                            $totalRuns = $order['dripfeed_total_runs'] ?? null;
                            $hasPendingRefill = !empty($ordersWithPendingRefill[$order['id']]);
                            
                            $canCancel = ($order['service_cancel'] ?? 0) && in_array($order['status'], ['pending', 'processing']);
                            
                            $refillEnabled = $order['refill_enabled'] ?? 0;
                            $refillUntil = $order['refill_until'] ?? null;
                            $refillUsed = $order['refill_used'] ?? 0;
                            $refillMax = $order['refill_max'] ?? 0;
                            $refillExpired = $refillUntil && strtotime($refillUntil) < strtotime('today');
                            $refillNoRights = $refillMax > 0 && $refillUsed >= $refillMax;
                            $canRefill = $order['status'] === 'completed' && $refillEnabled && !$refillExpired && !$refillNoRights && !$hasPendingRefill;
                            $refillDaysLeft = 0;
                            if ($refillUntil && !$refillExpired) {
                                $refillDaysLeft = max(0, ceil((strtotime($refillUntil) - strtotime('today')) / 86400));
                            }
                        ?>
                            <tr data-order-id="<?php echo $order['id']; ?>" class="<?php echo $isDripfeed ? 'dripfeed-row' : ''; ?>">
                                <td class="order-id-cell">
                                    <span class="order-id">#<?php echo $order['id']; ?></span>
                                    <?php if ($isDripfeed): ?>
                                        <div class="dripfeed-badge">
                                            <i class="fas fa-tint"></i>
                                            Dripfeed #<?php echo $order['dripfeed_id']; ?>
                                            <?php if ($partNumber && $totalRuns): ?>
                                                <span class="part-info"><?php echo $partNumber; ?>/<?php echo $totalRuns; ?></span>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                    <?php if ($refillEnabled && $order['status'] === 'completed'): ?>
                                        <div class="refill-badge <?php echo $refillExpired ? 'expired' : ($refillNoRights ? 'no-rights' : ''); ?>">
                                            <i class="fas fa-sync-alt"></i>
                                            <?php if ($refillExpired): ?>
                                                <?php echo __('refill_expired'); ?>
                                            <?php elseif ($refillNoRights): ?>
                                                <?php echo __('refill_no_rights'); ?>
                                            <?php else: ?>
                                                <?php echo ($refillMax - $refillUsed); ?>/<?php echo $refillMax; ?> • <?php echo $refillDaysLeft; ?> <?php echo __('refill_days_left'); ?>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="order-service">
                                        <div class="icon" style="background: <?php echo $order['category_color'] ?: '#667eea'; ?>">
                                            <i class="<?php echo $order['category_icon'] ?: 'fas fa-shopping-cart'; ?>"></i>
                                        </div>
                                        <div class="info">
                                            <h5><?php echo clean($order['service_name'] ?: __('service') . ' #' . $order['service_id']); ?></h5>
                                            <p><?php echo clean($order['category_name'] ?: '-'); ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td class="order-link">
                                    <a href="<?php echo clean($order['link']); ?>" target="_blank" title="<?php echo clean($order['link']); ?>">
                                        <?php echo clean($order['link']); ?>
                                    </a>
                                </td>
                                <td class="order-quantity">
                                    <?php echo number_format($order['quantity']); ?>
                                    <?php if ($order['start_count'] !== null): ?>
                                        <br><small style="opacity:0.6;">Başlangıç: <?php echo number_format($order['start_count']); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td class="order-price"><?php echo $siteSettings['currency_symbol'] . number_format($order['price'], 2); ?></td>
                                <td class="order-status-cell">
                                    <span class="status-badge status-<?php echo $order['status']; ?>">
                                        <i class="fas <?php echo $statusIcons[$order['status']] ?? 'fa-circle'; ?>"></i>
                                        <?php echo __('status_' . $order['status']); ?>
                                    </span>
                                    <?php if(function_exists('moni_order_reason_user') && ($rr=moni_order_reason_user($db,$order))): ?><small style="display:block;margin-top:5px;max-width:220px;opacity:.72" title="<?=clean($rr['user_description']??'')?>"><i class="fas fa-circle-info"></i> <?=clean($rr['user_label'])?></small><?php endif;?>
                                    <?php if ($order['remains'] !== null && $order['remains'] > 0): ?>
                                        <br><small style="color: var(--warning-color);">Kalan: <?php echo number_format($order['remains']); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td class="order-date">
                                    <?php echo date('d.m.Y', strtotime($order['created_at'])); ?><br>
                                    <small><?php echo date('H:i', strtotime($order['created_at'])); ?></small>
                                </td>
                                <td>
                                    <div class="order-actions">
                                        <button type="button" class="action-btn view" onclick='viewOrder(<?php echo json_encode(array_merge($order, [
                                            'part_number' => $partNumber,
                                            'total_runs' => $totalRuns,
                                            'refill_days_left' => $refillDaysLeft,
                                            'can_refill' => $canRefill,
                                            'can_cancel' => $canCancel,
                                            'has_pending_refill' => $hasPendingRefill
                                        ]), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>)' title="<?php echo __('detail'); ?>">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        
                                        <?php if ($order['api_order_id'] && in_array($order['status'], ['pending', 'processing', 'in_progress'])): ?>
                                            <button type="button" class="action-btn refresh" onclick="refreshOrder(<?php echo $order['id']; ?>, this)" title="<?php echo __('update_status'); ?>">
                                                <i class="fas fa-sync-alt"></i>
                                            </button>
                                        <?php endif; ?>
                                        
                                        <?php if ($canCancel): ?>
                                            <button type="button" class="action-btn cancel" onclick="cancelOrder(<?php echo $order['id']; ?>, this)" title="<?php echo __('cancel_order'); ?>">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        <?php endif; ?>
                                        
                                        <?php if ($canRefill): ?>
                                            <button type="button" class="action-btn refill" onclick="requestRefill(<?php echo $order['id']; ?>, this)" title="<?php echo __('request_refill'); ?>">
                                                <i class="fas fa-redo"></i>
                                            </button>
                                        <?php elseif ($hasPendingRefill): ?>
                                            <span class="action-btn refill-pending" title="<?php echo __('refill_pending'); ?>">
                                                <i class="fas fa-hourglass-half"></i>
                                            </span>
                                        <?php endif; ?>
                                        
                                        <button type="button" class="action-btn copy" onclick="copyLink('<?php echo htmlspecialchars($order['link'], ENT_QUOTES); ?>')" title="<?php echo __('copy_link'); ?>">
                                            <i class="fas fa-copy"></i>
                                        </button>
                                        <a href="/kullanici/new-order.php?reorder=<?php echo (int)$order['id']; ?>" class="action-btn view" title="Tek tıkla tekrar sipariş"><i class="fas fa-repeat"></i></a>
                                        <?php if($order['status']==='completed'): ?>
                                            <?php if($existingReview): ?>
                                                <span class="rating-done-chip" title="Bu sipariş daha önce değerlendirildi"><i class="fas fa-star"></i> <?php echo (int)$existingReview['rating']; ?>/5<?php if(($existingReview['status']??'approved')==='pending'): ?> · Onay bekliyor<?php elseif(($existingReview['status']??'approved')==='rejected'): ?> · Gizli<?php endif; ?></span>
                                            <?php else: ?>
                                                <button type="button" class="action-btn rating-trigger" onclick='openRatingModal(<?php echo (int)$order['id']; ?>, <?php echo json_encode((string)($order['service_name'] ?: ('Servis #'.$order['service_id'])), JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT); ?>)' title="Servisi değerlendir"><i class="fas fa-star"></i></button>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        
                                        <?php if ($canOpenTicket): ?>
                                            <form method="POST" style="display:inline;">
                                                <input type="hidden" name="action" value="open_ticket">
                                                <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                                <button type="submit" class="action-btn view" title="Destek talebi aç">
                                                    <i class="fas fa-life-ring"></i>
                                                </button>
                                            </form>
                                        <?php elseif ($hasTicket): ?>
                                            <span class="action-btn" style="background: rgba(255,193,7,0.18); color:#d39e00;" title="Talep mevcut">
                                                <i class="fas fa-life-ring"></i>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Mobil Kartlar -->
            <div class="orders-cards">
                <?php foreach ($orders as $order): 
                    $existingReview = $reviewsByOrder[(int)$order['id']] ?? null;
                    $hasTicket = !empty($ordersWithTicket[$order['id']]);
                    $canOpenTicket = in_array($order['status'], $autoTicketStatuses) && !$hasTicket;
                    $isDripfeed = !empty($order['dripfeed_id']) && $order['dripfeed_id'] > 0;
                    $partNumber = $dripfeedPartNumbers[$order['id']] ?? null;
                    $totalRuns = $order['dripfeed_total_runs'] ?? null;
                    $hasPendingRefill = !empty($ordersWithPendingRefill[$order['id']]);
                    $canCancel = ($order['service_cancel'] ?? 0) && in_array($order['status'], ['pending', 'processing']);
                    $refillEnabled = $order['refill_enabled'] ?? 0;
                    $refillUntil = $order['refill_until'] ?? null;
                    $refillUsed = $order['refill_used'] ?? 0;
                    $refillMax = $order['refill_max'] ?? 0;
                    $refillExpired = $refillUntil && strtotime($refillUntil) < strtotime('today');
                    $refillNoRights = $refillMax > 0 && $refillUsed >= $refillMax;
                    $canRefill = $order['status'] === 'completed' && $refillEnabled && !$refillExpired && !$refillNoRights && !$hasPendingRefill;
                    $refillDaysLeft = ($refillUntil && !$refillExpired) ? max(0, ceil((strtotime($refillUntil) - strtotime('today')) / 86400)) : 0;
                ?>
                    <div class="order-card <?php echo $isDripfeed ? 'dripfeed-card' : ''; ?>" data-order-id="<?php echo $order['id']; ?>">
                        <div class="order-card-header">
                            <div>
                                <span class="order-id">#<?php echo $order['id']; ?></span>
                                <?php if ($isDripfeed): ?>
                                    <div class="dripfeed-badge">
                                        <i class="fas fa-tint"></i>
                                        Dripfeed #<?php echo $order['dripfeed_id']; ?>
                                        <?php if ($partNumber && $totalRuns): ?>
                                            <span class="part-info"><?php echo $partNumber; ?>/<?php echo $totalRuns; ?></span>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <span class="status-badge status-<?php echo $order['status']; ?> order-status-badge">
                                <i class="fas <?php echo $statusIcons[$order['status']] ?? 'fa-circle'; ?>"></i>
                                <?php echo __('status_' . $order['status']); ?>
                            </span>
                            <?php if(function_exists('moni_order_reason_user') && ($rr=moni_order_reason_user($db,$order))): ?><small style="display:block;margin-top:6px;opacity:.72"><i class="fas fa-circle-info"></i> <?=clean($rr['user_label'])?></small><?php endif;?>
                        </div>
                        <div class="order-card-body">
                            <div class="order-card-row">
                                <span class="label"><?php echo __('service'); ?></span>
                                <span class="value"><?php echo clean($order['service_name'] ?: __('service') . ' #' . $order['service_id']); ?></span>
                            </div>
                            <div class="order-card-row">
                                <span class="label"><?php echo __('quantity'); ?></span>
                                <span class="value"><?php echo number_format($order['quantity']); ?></span>
                            </div>
                            <div class="order-card-row">
                                <span class="label"><?php echo __('price'); ?></span>
                                <span class="value" style="color: var(--success-color);"><?php echo $siteSettings['currency_symbol'] . number_format($order['price'], 2); ?></span>
                            </div>
                            <div class="order-card-row">
                                <span class="label"><?php echo __('date'); ?></span>
                                <span class="value"><?php echo moni_format_user_time($db,(int)$_SESSION['user_id'],$order['created_at']); ?></span>
                            </div>
                            <?php if ($refillEnabled && $order['status'] === 'completed'): ?>
                            <div class="order-card-row">
                                <span class="label"><?php echo __('refill'); ?></span>
                                <span class="value">
                                    <?php if ($refillExpired): ?>
                                        <span style="color:var(--muted-text-color);"><?php echo __('refill_expired'); ?></span>
                                    <?php elseif ($refillNoRights): ?>
                                        <span style="color:var(--danger-color);"><?php echo __('refill_no_rights'); ?></span>
                                    <?php else: ?>
                                        <span style="color:var(--success-color);"><?php echo ($refillMax - $refillUsed); ?>/<?php echo $refillMax; ?> (<?php echo $refillDaysLeft; ?> gün)</span>
                                    <?php endif; ?>
                                </span>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="order-card-footer">
                            <button type="button" class="btn btn-primary btn-sm" onclick='viewOrder(<?php echo json_encode(array_merge($order, [
                                'part_number' => $partNumber,
                                'total_runs' => $totalRuns,
                                'refill_days_left' => $refillDaysLeft,
                                'can_refill' => $canRefill,
                                'can_cancel' => $canCancel,
                                'has_pending_refill' => $hasPendingRefill
                            ]), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'>
                                <i class="fas fa-eye"></i> <?php echo __('detail'); ?>
                            </button>
                            <?php if ($order['api_order_id'] && in_array($order['status'], ['pending', 'processing', 'in_progress'])): ?>
                                <button type="button" class="btn btn-success btn-sm" onclick="refreshOrder(<?php echo $order['id']; ?>, this)">
                                    <i class="fas fa-sync-alt"></i>
                                </button>
                            <?php endif; ?>
                            <?php if ($canCancel): ?>
                                <button type="button" class="btn btn-danger btn-sm" onclick="cancelOrder(<?php echo $order['id']; ?>, this)">
                                    <i class="fas fa-times"></i>
                                </button>
                            <?php endif; ?>
                            <?php if ($canRefill): ?>
                                <button type="button" class="btn btn-warning btn-sm" onclick="requestRefill(<?php echo $order['id']; ?>, this)">
                                    <i class="fas fa-redo"></i>
                                </button>
                            <?php endif; ?>
                            <button type="button" class="btn btn-secondary btn-sm" onclick="copyLink('<?php echo htmlspecialchars($order['link'], ENT_QUOTES); ?>')">
                                <i class="fas fa-copy"></i>
                            </button>
                            <?php if($order['status']==='completed'): ?>
                                <?php if($existingReview): ?>
                                    <span class="rating-mobile-done"><i class="fas fa-star"></i> <?php echo (int)$existingReview['rating']; ?>/5 · <?php echo (($existingReview['status']??'approved')==='pending')?'Onay bekliyor':((($existingReview['status']??'approved')==='rejected')?'Gizli':'Değerlendirildi'); ?></span>
                                <?php else: ?>
                                    <button type="button" class="btn btn-sm rating-trigger" onclick='openRatingModal(<?php echo (int)$order['id']; ?>, <?php echo json_encode((string)($order['service_name'] ?: ('Servis #'.$order['service_id'])), JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT); ?>)'><i class="fas fa-star"></i> Değerlendir</button>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>&status=<?php echo urlencode($status); ?>&search=<?php echo urlencode($search); ?>&type=<?php echo urlencode($typeFilter); ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    <?php endif; ?>
                    
                    <?php
                    $startPage = max(1, $page - 2);
                    $endPage = min($totalPages, $page + 2);
                    
                    if ($startPage > 1): ?>
                        <a href="?page=1&status=<?php echo urlencode($status); ?>&search=<?php echo urlencode($search); ?>&type=<?php echo urlencode($typeFilter); ?>">1</a>
                        <?php if ($startPage > 2): ?>
                            <span>...</span>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    <?php for ($i = $startPage; $i <= $endPage; $i++): ?>
                        <?php if ($i == $page): ?>
                            <span class="current"><?php echo $i; ?></span>
                        <?php else: ?>
                            <a href="?page=<?php echo $i; ?>&status=<?php echo urlencode($status); ?>&search=<?php echo urlencode($search); ?>&type=<?php echo urlencode($typeFilter); ?>"><?php echo $i; ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($endPage < $totalPages): ?>
                        <?php if ($endPage < $totalPages - 1): ?>
                            <span>...</span>
                        <?php endif; ?>
                        <a href="?page=<?php echo $totalPages; ?>&status=<?php echo urlencode($status); ?>&search=<?php echo urlencode($search); ?>&type=<?php echo urlencode($typeFilter); ?>"><?php echo $totalPages; ?></a>
                    <?php endif; ?>
                    
                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?php echo $page + 1; ?>&status=<?php echo urlencode($status); ?>&search=<?php echo urlencode($search); ?>&type=<?php echo urlencode($typeFilter); ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Servis Değerlendirme Modalı -->
<div class="modal-overlay" id="ratingModal" aria-hidden="true">
    <div class="modal-box rating-modal-box" role="dialog" aria-modal="true" aria-labelledby="ratingModalTitle">
        <div class="modal-header">
            <h3 id="ratingModalTitle"><i class="fas fa-star"></i> Servisi Değerlendir</h3>
            <button type="button" class="modal-close" onclick="closeRatingModal()" aria-label="Kapat">&times;</button>
        </div>
        <form method="post" id="ratingForm" onsubmit="return validateRatingForm()">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="submit_review">
            <input type="hidden" name="order_id" id="ratingOrderId" value="">
            <input type="hidden" name="rating" id="ratingValue" value="0">
            <div class="rating-modal-body">
                <div class="rating-modal-intro">
                    <div class="rating-modal-icon"><i class="fas fa-star"></i></div>
                    <div class="rating-service-name" id="ratingServiceName">Servis</div>
                    <div class="rating-order-meta" id="ratingOrderMeta">Sipariş</div>
                </div>
                <div class="rating-form-content">
                    <div class="rating-question">Bu servisten ne kadar memnun kaldınız?</div>
                    <div class="rating-stars-picker" id="ratingStars" aria-label="Puan seçin">
                        <?php for($star=1;$star<=5;$star++): ?>
                            <button type="button" class="rating-star" data-value="<?php echo $star; ?>" onclick="selectRating(<?php echo $star; ?>)" aria-label="<?php echo $star; ?> yıldız"><i class="fas fa-star"></i></button>
                        <?php endfor; ?>
                    </div>
                    <div class="rating-choice-label" id="ratingChoiceLabel">Puanınızı seçin</div>
                    <label class="rating-comment-label" for="ratingComment"><span>Yorumunuz</span><small>İsteğe bağlı</small></label>
                    <textarea class="rating-comment" id="ratingComment" name="comment" maxlength="1000" placeholder="Deneyiminizi kısa ve faydalı şekilde paylaşabilirsiniz."></textarea>
                </div>
            </div>
            <div class="rating-modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeRatingModal()">Vazgeç</button>
                <button type="submit" class="btn btn-primary rating-submit"><i class="fas fa-check"></i> Değerlendirmeyi Gönder</button>
            </div>
        </form>
    </div>
</div>

<!-- Detay Modal -->
<div class="modal-overlay" id="orderModal">
    <div class="modal-box">
        <div class="modal-header">
            <h3><i class="fas fa-receipt"></i> <?php echo __('order_detail'); ?> <span id="modalOrderId"></span></h3>
            <button type="button" class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <div class="modal-body">
            <div class="modal-dripfeed-box" id="modalDripfeedBox" style="display: none;">
                <h5><i class="fas fa-tint"></i> Dripfeed Siparişi</h5>
                <div class="dripfeed-detail">
                    <span class="label">Dripfeed ID</span>
                    <span class="value" id="modalDripfeedId"></span>
                </div>
                <div class="dripfeed-detail">
                    <span class="label">Part</span>
                    <span class="value" id="modalDripfeedPart"></span>
                </div>
            </div>
            
            <div class="modal-refill-box" id="modalRefillBox" style="display: none;">
                <h5><i class="fas fa-sync-alt"></i> <?php echo __('refill'); ?></h5>
                <div class="refill-detail">
                    <span class="label"><?php echo __('refill_remaining'); ?></span>
                    <span class="value" id="modalRefillRemaining"></span>
                </div>
                <div class="refill-detail">
                    <span class="label"><?php echo __('refill_until'); ?></span>
                    <span class="value" id="modalRefillUntil"></span>
                </div>
            </div>
            
            <div class="detail-row">
                <span class="label"><?php echo __('order_id'); ?></span>
                <span class="value" id="modalId"></span>
            </div>
            <div class="detail-row">
                <span class="label"><?php echo __('service'); ?></span>
                <span class="value" id="modalService"></span>
            </div>
            <div class="detail-row">
                <span class="label"><?php echo __('link'); ?></span>
                <span class="value" id="modalLink"></span>
            </div>
            <div class="detail-row">
                <span class="label"><?php echo __('quantity'); ?></span>
                <span class="value" id="modalQuantity"></span>
            </div>
            <div class="detail-row">
                <span class="label"><?php echo __('start_count'); ?></span>
                <span class="value" id="modalStartCount"></span>
            </div>
            <div class="detail-row">
                <span class="label"><?php echo __('remains'); ?></span>
                <span class="value" id="modalRemains"></span>
            </div>
            <div class="detail-row">
                <span class="label"><?php echo __('price'); ?></span>
                <span class="value" id="modalPrice"></span>
            </div>
            <div class="detail-row">
                <span class="label"><?php echo __('status'); ?></span>
                <span class="value" id="modalStatus"></span>
            </div>
            <div class="detail-row">
                <span class="label"><?php echo __('date'); ?></span>
                <span class="value" id="modalDate"></span>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-success" id="modalRefreshBtn" onclick="refreshOrderFromModal()" style="display: none;">
                <i class="fas fa-sync-alt"></i> <?php echo __('update_status'); ?>
            </button>
            <button type="button" class="btn btn-danger" id="modalCancelBtn" onclick="cancelOrderFromModal()" style="display: none;">
                <i class="fas fa-times"></i> <?php echo __('cancel_order'); ?>
            </button>
            <button type="button" class="btn btn-warning" id="modalRefillBtn" onclick="requestRefillFromModal()" style="display: none;">
                <i class="fas fa-redo"></i> <?php echo __('request_refill'); ?>
            </button>
            <button type="button" class="btn btn-secondary" onclick="closeModal()"><?php echo __('close'); ?></button>
        </div>
    </div>
</div>

<script>
const currencySymbol = '<?php echo $siteSettings['currency_symbol']; ?>';

const t = {
    status_pending: '<?php echo __('status_pending'); ?>',
    status_processing: '<?php echo __('status_processing'); ?>',
    status_in_progress: '<?php echo __('status_in_progress'); ?>',
    status_completed: '<?php echo __('status_completed'); ?>',
    status_partial: '<?php echo __('status_partial'); ?>',
    status_cancelled: '<?php echo __('status_cancelled'); ?>',
    status_refunded: '<?php echo __('status_refunded'); ?>',
    status_error: '<?php echo __('status_error'); ?>',
    link_copied: '<?php echo __('link_copied'); ?>',
    order_updated: '<?php echo __('order_updated'); ?>',
    update_failed: '<?php echo __('update_failed'); ?>',
    error_occurred: '<?php echo __('error_occurred'); ?>',
    no_active_orders: '<?php echo __('no_active_orders'); ?>',
    orders_updated: '<?php echo __('orders_updated'); ?>',
    updating: '<?php echo __('updating'); ?>',
    update_status: '<?php echo __('update_status'); ?>',
    update_statuses: '<?php echo __('update_statuses'); ?>',
    cancel_confirm: '<?php echo __('cancel_confirm'); ?>',
    order_cancelled: '<?php echo __('order_cancelled'); ?>',
    refill_requested: '<?php echo __('refill_requested'); ?>',
    refill_days_left: '<?php echo __('refill_days_left'); ?>'
};

const statusNames = {
    pending: t.status_pending,
    processing: t.status_processing,
    in_progress: t.status_in_progress,
    completed: t.status_completed,
    partial: t.status_partial,
    cancelled: t.status_cancelled,
    refunded: t.status_refunded,
    error: t.status_error
};

const statusIcons = <?php echo json_encode($statusIcons); ?>;

let currentModalOrder = null;
let currentRatingValue = 0;

const ratingLabels = {
    1: 'Beklentimin altında',
    2: 'Geliştirilebilir',
    3: 'İyi',
    4: 'Çok iyi',
    5: 'Mükemmel'
};

function openRatingModal(orderId, serviceName) {
    currentRatingValue = 0;
    document.getElementById('ratingOrderId').value = String(orderId);
    document.getElementById('ratingServiceName').textContent = String(serviceName || 'Servis');
    document.getElementById('ratingOrderMeta').textContent = 'Sipariş #' + orderId;
    document.getElementById('ratingValue').value = '0';
    document.getElementById('ratingComment').value = '';
    document.getElementById('ratingChoiceLabel').textContent = 'Puanınızı seçin';
    document.querySelectorAll('#ratingStars .rating-star').forEach(btn => btn.classList.remove('is-selected'));
    const modal = document.getElementById('ratingModal');
    modal.classList.add('active');
    modal.setAttribute('aria-hidden', 'false');
}

function closeRatingModal() {
    const modal = document.getElementById('ratingModal');
    if (!modal) return;
    modal.classList.remove('active');
    modal.setAttribute('aria-hidden', 'true');
}

function selectRating(value) {
    value = Math.max(1, Math.min(5, Number(value) || 0));
    currentRatingValue = value;
    document.getElementById('ratingValue').value = String(value);
    document.getElementById('ratingChoiceLabel').textContent = value + '/5 · ' + (ratingLabels[value] || '');
    document.querySelectorAll('#ratingStars .rating-star').forEach(btn => {
        btn.classList.toggle('is-selected', Number(btn.dataset.value) <= value);
    });
}

function validateRatingForm() {
    if (currentRatingValue < 1 || currentRatingValue > 5) {
        document.getElementById('ratingChoiceLabel').textContent = 'Göndermeden önce bir puan seçin.';
        return false;
    }
    return true;
}

function safeOrderHref(raw) {
    try {
        const u = new URL(String(raw || ''), window.location.origin);
        return /^https?:$/i.test(u.protocol) ? u.href : '#';
    } catch (e) { return '#'; }
}
function renderOrderStatusBadge(host, rawStatus, names) {
    const safeStatus = /^[a-z0-9_-]{1,40}$/i.test(String(rawStatus || '')) ? String(rawStatus).toLowerCase() : 'unknown';
    const badge = document.createElement('span');
    badge.className = 'status-badge status-' + safeStatus;
    badge.textContent = (names && names[safeStatus]) || safeStatus;
    host.replaceChildren(badge);
}
function renderOrderLink(host, raw) {
    const a = document.createElement('a');
    const label = String(raw || '');
    a.textContent = label;
    a.href = safeOrderHref(label);
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    host.replaceChildren(a);
}

function viewOrder(order) {
    currentModalOrder = order;
    
    const isDripfeed = order.dripfeed_id && order.dripfeed_id > 0;
    
    document.getElementById('modalOrderId').textContent = '#' + order.id;
    document.getElementById('modalId').textContent = '#' + order.id;
    document.getElementById('modalService').textContent = order.service_name || 'Servis #' + order.service_id;
    renderOrderLink(document.getElementById('modalLink'), order.link);
    document.getElementById('modalQuantity').textContent = Number(order.quantity).toLocaleString();
    document.getElementById('modalStartCount').textContent = order.start_count ? Number(order.start_count).toLocaleString() : '-';
    document.getElementById('modalRemains').textContent = (order.remains !== null && order.remains !== '' && order.remains !== undefined) ? Number(order.remains).toLocaleString() : '-';
    document.getElementById('modalPrice').textContent = currencySymbol + parseFloat(order.price).toFixed(2);
    renderOrderStatusBadge(document.getElementById('modalStatus'), order.status, statusNames);
    document.getElementById('modalDate').textContent = formatDate(order.created_at);
    
    if (isDripfeed) {
        document.getElementById('modalDripfeedBox').style.display = 'block';
        document.getElementById('modalDripfeedId').textContent = '#' + order.dripfeed_id;
        document.getElementById('modalDripfeedPart').textContent = (order.part_number && order.total_runs) ? order.part_number + ' / ' + order.total_runs : '-';
    } else {
        document.getElementById('modalDripfeedBox').style.display = 'none';
    }
    
    const refillBox = document.getElementById('modalRefillBox');
    if (order.refill_enabled && order.status === 'completed') {
        refillBox.style.display = 'block';
        const remaining = (order.refill_max || 0) - (order.refill_used || 0);
        document.getElementById('modalRefillRemaining').textContent = remaining + ' / ' + (order.refill_max || 0);
        document.getElementById('modalRefillUntil').textContent = order.refill_until ? formatDateShort(order.refill_until) + ' (' + (order.refill_days_left || 0) + ' ' + t.refill_days_left + ')' : '-';
        
        if ((order.refill_days_left || 0) <= 0 || remaining <= 0) {
            refillBox.classList.add('expired');
        } else {
            refillBox.classList.remove('expired');
        }
    } else {
        refillBox.style.display = 'none';
    }
    
    document.getElementById('modalRefreshBtn').style.display = (order.api_order_id && ['pending', 'processing', 'in_progress'].includes(order.status)) ? 'block' : 'none';
    document.getElementById('modalCancelBtn').style.display = order.can_cancel ? 'block' : 'none';
    document.getElementById('modalRefillBtn').style.display = order.can_refill ? 'block' : 'none';
    
    document.getElementById('orderModal').classList.add('active');
}

function closeModal() {
    document.getElementById('orderModal').classList.remove('active');
    currentModalOrder = null;
}

document.getElementById('orderModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeModal();
    }
});

document.getElementById('ratingModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeRatingModal();
    }
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeModal();
        closeRatingModal();
    }
});

function copyLink(link) {
    navigator.clipboard.writeText(link).then(() => {
        showToast(t.link_copied, 'success');
    }).catch(() => {
        const textarea = document.createElement('textarea');
        textarea.value = link;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showToast(t.link_copied, 'success');
    });
}

function refreshOrder(orderId, btn) {
    if (btn) {
        btn.classList.add('loading');
    }
    
    fetch('orders.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=check_status&order_id=' + orderId
    })
    .then(response => response.json())
    .then(data => {
        if (btn) {
            btn.classList.remove('loading');
        }
        
        if (data.success) {
            updateOrderStatus(orderId, data.status, data.start_count, data.remains);
            showToast(t.order_updated, 'success');
        } else {
            showToast(data.error || t.update_failed, 'error');
        }
    })
    .catch(error => {
        if (btn) {
            btn.classList.remove('loading');
        }
        showToast(t.error_occurred, 'error');
    });
}

function refreshOrderFromModal() {
    if (!currentModalOrder) return;
    
    const btn = document.getElementById('modalRefreshBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ' + t.updating + '...';
    
    fetch('orders.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=check_status&order_id=' + currentModalOrder.id
    })
    .then(response => response.json())
    .then(data => {
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-sync-alt"></i> ' + t.update_status;
        
        if (data.success) {
            const statusHost = document.getElementById('modalStatus');
            const statusSpan = document.createElement('span');
            const safeStatus = /^[a-z0-9_-]{1,40}$/i.test(String(data.status || '')) ? String(data.status).toLowerCase() : 'unknown';
            statusSpan.className = 'status-badge status-' + safeStatus;
            statusSpan.textContent = statusNames[safeStatus] || safeStatus;
            statusHost.replaceChildren(statusSpan);
            if (data.start_count !== null && data.start_count !== undefined) {
                document.getElementById('modalStartCount').textContent = Number(data.start_count).toLocaleString();
            }
            if (data.remains !== null && data.remains !== undefined) {
                document.getElementById('modalRemains').textContent = Number(data.remains).toLocaleString();
            }
            
            currentModalOrder.status = data.status;
            currentModalOrder.start_count = data.start_count;
            currentModalOrder.remains = data.remains;
            
            updateOrderStatus(currentModalOrder.id, data.status, data.start_count, data.remains);
            
            if (!['pending', 'processing', 'in_progress'].includes(data.status)) {
                btn.style.display = 'none';
                document.getElementById('modalCancelBtn').style.display = 'none';
            }
            
            showToast(t.order_updated, 'success');
        } else {
            showToast(data.error || t.update_failed, 'error');
        }
    })
    .catch(error => {
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-sync-alt"></i> ' + t.update_status;
        showToast(t.error_occurred, 'error');
    });
}

function cancelOrder(orderId, btn) {
    if (!confirm(t.cancel_confirm)) return;
    
    if (btn) {
        btn.classList.add('loading');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    }
    
    fetch('orders.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=cancel_order&order_id=' + orderId
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast(data.message || t.order_cancelled, 'success');
            setTimeout(() => location.reload(), 1500);
        } else {
            if (btn) {
                btn.classList.remove('loading');
                btn.innerHTML = '<i class="fas fa-times"></i>';
            }
            showToast(data.error, 'error');
        }
    })
    .catch(error => {
        if (btn) {
            btn.classList.remove('loading');
            btn.innerHTML = '<i class="fas fa-times"></i>';
        }
        showToast(t.error_occurred, 'error');
    });
}

function cancelOrderFromModal() {
    if (!currentModalOrder) return;
    cancelOrder(currentModalOrder.id, document.getElementById('modalCancelBtn'));
}

function requestRefill(orderId, btn) {
    if (btn) {
        btn.classList.add('loading');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    }
    
    fetch('orders.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=request_refill&order_id=' + orderId
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast(data.message || t.refill_requested, 'success');
            setTimeout(() => location.reload(), 1500);
        } else {
            if (btn) {
                btn.classList.remove('loading');
                btn.innerHTML = '<i class="fas fa-redo"></i>';
            }
            showToast(data.error, 'error');
        }
    })
    .catch(error => {
        if (btn) {
            btn.classList.remove('loading');
            btn.innerHTML = '<i class="fas fa-redo"></i>';
        }
        showToast(t.error_occurred, 'error');
    });
}

function requestRefillFromModal() {
    if (!currentModalOrder) return;
    requestRefill(currentModalOrder.id, document.getElementById('modalRefillBtn'));
}

function refreshAllOrders() {
    const btn = document.getElementById('refreshAllBtn');
    btn.classList.add('loading');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ' + t.updating + '...';
    
    const activeOrders = document.querySelectorAll('tr[data-order-id] .action-btn.refresh, .order-card[data-order-id] .btn-success');
    const orderIds = [];
    
    activeOrders.forEach(el => {
        const row = el.closest('[data-order-id]');
        if (row) {
            const orderId = row.dataset.orderId;
            if (!orderIds.includes(orderId)) {
                orderIds.push(orderId);
            }
        }
    });
    
    if (orderIds.length === 0) {
        btn.classList.remove('loading');
        btn.innerHTML = '<i class="fas fa-sync-alt"></i> ' + t.update_statuses;
        showToast(t.no_active_orders, 'info');
        return;
    }
    
    let completed = 0;
    let updated = 0;
    
    orderIds.forEach(orderId => {
        fetch('orders.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'action=check_status&order_id=' + orderId
        })
        .then(response => response.json())
        .then(data => {
            completed++;
            if (data.success) {
                updated++;
                updateOrderStatus(orderId, data.status, data.start_count, data.remains);
            }
            
            if (completed >= orderIds.length) {
                btn.classList.remove('loading');
                btn.innerHTML = '<i class="fas fa-sync-alt"></i> ' + t.update_statuses;
                showToast(updated + ' ' + t.orders_updated, 'success');
            }
        })
        .catch(() => {
            completed++;
            if (completed >= orderIds.length) {
                btn.classList.remove('loading');
                btn.innerHTML = '<i class="fas fa-sync-alt"></i> ' + t.update_statuses;
            }
        });
    });
}

function updateOrderStatus(orderId, status, startCount, remains) {
    const row = document.querySelector('tr[data-order-id="' + orderId + '"]');
    if (row) {
        const statusCell = row.querySelector('.order-status-cell');
        if (statusCell) {
            const icon = statusIcons[status] || 'fa-circle';
            const safeStatus = /^[a-z0-9_-]{1,40}$/i.test(String(status || '')) ? String(status).toLowerCase() : 'unknown';
            const badge = document.createElement('span');
            badge.className = 'status-badge status-' + safeStatus;
            const badgeIcon = document.createElement('i');
            badgeIcon.className = 'fas ' + (/^fa-[a-z0-9-]+$/i.test(String(icon || '')) ? icon : 'fa-circle');
            badge.appendChild(badgeIcon);
            badge.appendChild(document.createTextNode(' ' + (statusNames[safeStatus] || safeStatus)));
            const fragment = document.createDocumentFragment();
            fragment.appendChild(badge);
            if (remains !== null && remains !== undefined && remains > 0) {
                fragment.appendChild(document.createElement('br'));
                const small = document.createElement('small');
                small.style.color = 'var(--warning-color)';
                small.textContent = 'Kalan: ' + Number(remains).toLocaleString();
                fragment.appendChild(small);
            }
            statusCell.replaceChildren(fragment);
        }
        
        if (!['pending', 'processing', 'in_progress'].includes(status)) {
            const refreshBtn = row.querySelector('.action-btn.refresh');
            const cancelBtn = row.querySelector('.action-btn.cancel');
            if (refreshBtn) refreshBtn.remove();
            if (cancelBtn) cancelBtn.remove();
        }
    }
    
    const card = document.querySelector('.order-card[data-order-id="' + orderId + '"]');
    if (card) {
        const statusBadge = card.querySelector('.order-status-badge');
        if (statusBadge) {
            const icon = statusIcons[status] || 'fa-circle';
            const safeStatus = /^[a-z0-9_-]{1,40}$/i.test(String(status || '')) ? String(status).toLowerCase() : 'unknown';
            statusBadge.className = 'status-badge status-' + safeStatus + ' order-status-badge';
            const statusIcon = document.createElement('i');
            statusIcon.className = 'fas ' + (/^fa-[a-z0-9-]+$/i.test(String(icon || '')) ? icon : 'fa-circle');
            statusBadge.replaceChildren(statusIcon, document.createTextNode(' ' + (statusNames[safeStatus] || safeStatus)));
        }
        
        if (!['pending', 'processing', 'in_progress'].includes(status)) {
            const refreshBtn = card.querySelector('.btn-success');
            const cancelBtn = card.querySelector('.btn-danger');
            if (refreshBtn) refreshBtn.remove();
            if (cancelBtn) cancelBtn.remove();
        }
    }
}

function formatDate(dateStr) {
    const date = new Date(dateStr);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return day + '.' + month + '.' + year + ' ' + hours + ':' + minutes;
}

function formatDateShort(dateStr) {
    const date = new Date(dateStr);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return day + '.' + month + '.' + year;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showToast(message, type) {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 9999;';
        document.body.appendChild(container);
    }
    
    const toast = document.createElement('div');
    toast.style.cssText = 'background: ' + (type === 'success' ? 'var(--success-color)' : type === 'error' ? 'var(--danger-color)' : 'var(--info-color)') + '; color: #fff; padding: 12px 20px; border-radius: 8px; margin-bottom: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.2); animation: slideIn 0.3s ease;';
    const toastIcon = document.createElement('i');
    toastIcon.className = 'fas fa-' + (type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle');
    toast.appendChild(toastIcon);
    toast.appendChild(document.createTextNode(' ' + String(message || '')));
    
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { opacity: 0; transform: translateX(100px); }
        to { opacity: 1; transform: translateX(0); }
    }
    @keyframes slideOut {
        from { opacity: 1; transform: translateX(0); }
        to { opacity: 0; transform: translateX(100px); }
    }
`;
document.head.appendChild(style);
</script>

<?php require_once 'footer.php'; ?>