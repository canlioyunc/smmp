<?php
/**
 * Kullanıcı Paneli - İşlem Geçmişi
 * Paket desteği eklenmiş versiyon
 */

require_once __DIR__ . '/../config.php';

// Türkiye saat dilimini ayarla
date_default_timezone_set('Europe/Istanbul');

// Giriş kontrolü
if (!isLoggedIn()) {
    header('Location: /login.php');
    exit;
}

// Filtreler
$typeFilter = $_GET['type'] ?? '';
$dateFrom = $_GET['date_from'] ?? '';
$dateTo = $_GET['date_to'] ?? '';

// İşlemleri topla
$transactions = [];

// Siparişler (bakiye azaltan)
if (!$typeFilter || $typeFilter === 'order') {
    try {
        $orderWhere = "WHERE o.user_id = ?";
        $orderParams = [$_SESSION['user_id']];
        
        if ($dateFrom) {
            $orderWhere .= " AND DATE(o.created_at) >= ?";
            $orderParams[] = $dateFrom;
        }
        
        if ($dateTo) {
            $orderWhere .= " AND DATE(o.created_at) <= ?";
            $orderParams[] = $dateTo;
        }
        
        $orderStmt = $db->prepare("
            SELECT 
                'order' as type,
                o.id,
                o.price as amount,
                NULL as credit_amount,
                CONCAT('Sipariş #', o.id) as title,
                s.name as description,
                o.status,
                NULL as package_id,
                NULL as package_name,
                o.created_at
            FROM orders o
            LEFT JOIN services s ON o.service_id = s.id
            $orderWhere
            ORDER BY o.created_at DESC
        ");
        $orderStmt->execute($orderParams);
        $transactions = array_merge($transactions, $orderStmt->fetchAll());
    } catch (Exception $e) {}
}

// Ödemeler (bakiye artıran) - PAKET DESTEĞİ EKLENDİ
if (!$typeFilter || $typeFilter === 'deposit') {
    try {
        $paymentWhere = "WHERE pr.user_id = ? AND pr.status = 'approved'";
        $paymentParams = [$_SESSION['user_id']];
        
        if ($dateFrom) {
            $paymentWhere .= " AND DATE(pr.created_at) >= ?";
            $paymentParams[] = $dateFrom;
        }
        
        if ($dateTo) {
            $paymentWhere .= " AND DATE(pr.created_at) <= ?";
            $paymentParams[] = $dateTo;
        }
        
        $paymentStmt = $db->prepare("
            SELECT 
                'deposit' as type,
                pr.id,
                pr.amount,
                pr.credit_amount,
                CASE 
                    WHEN cp.name IS NOT NULL THEN 'package_deposit'
                    ELSE 'balance_deposit'
                END as title,
                COALESCE(pm.name, ba.bank_name, 'Havale/EFT') as description,
                'completed' as status,
                pr.package_id,
                cp.name as package_name,
                pr.created_at
            FROM payment_requests pr
            LEFT JOIN payment_methods pm ON pr.payment_method_id = pm.id
            LEFT JOIN bank_accounts ba ON pr.bank_account_id = ba.id
            LEFT JOIN credit_packages cp ON pr.package_id = cp.id
            $paymentWhere
            ORDER BY pr.created_at DESC
        ");
        $paymentStmt->execute($paymentParams);
        $transactions = array_merge($transactions, $paymentStmt->fetchAll());
    } catch (Exception $e) {}
}

// Günlük Bonus (bakiye artıran)
if (!$typeFilter || $typeFilter === 'bonus') {
    try {
        $bonusWhere = "WHERE db.user_id = ?";
        $bonusParams = [$_SESSION['user_id']];
        
        if ($dateFrom) {
            $bonusWhere .= " AND DATE(db.claimed_at) >= ?";
            $bonusParams[] = $dateFrom;
        }
        
        if ($dateTo) {
            $bonusWhere .= " AND DATE(db.claimed_at) <= ?";
            $bonusParams[] = $dateTo;
        }
        
        $bonusStmt = $db->prepare("
            SELECT 
                'bonus' as type,
                db.id,
                db.amount,
                NULL as credit_amount,
                'daily_bonus' as title,
                CONCAT(db.streak, '. Gün Bonusu') as description,
                'completed' as status,
                NULL as package_id,
                NULL as package_name,
                db.claimed_at as created_at
            FROM daily_bonus db
            $bonusWhere
            ORDER BY db.claimed_at DESC
        ");
        $bonusStmt->execute($bonusParams);
        $transactions = array_merge($transactions, $bonusStmt->fetchAll());
    } catch (Exception $e) {}
}

// Referans Kazançları (bakiye artıran) - referral_logs tablosu
if (!$typeFilter || $typeFilter === 'referral') {
    try {
        $refWhere = "WHERE rl.referrer_id = ? AND rl.status = 'completed'";
        $refParams = [$_SESSION['user_id']];
        
        if ($dateFrom) {
            $refWhere .= " AND DATE(rl.created_at) >= ?";
            $refParams[] = $dateFrom;
        }
        
        if ($dateTo) {
            $refWhere .= " AND DATE(rl.created_at) <= ?";
            $refParams[] = $dateTo;
        }
        
        $refStmt = $db->prepare("
            SELECT 
                'referral' as type,
                rl.id,
                rl.bonus_amount as amount,
                NULL as credit_amount,
                'referral_earning' as title,
                CONCAT('Referans: ', u.username) as description,
                'completed' as status,
                NULL as package_id,
                NULL as package_name,
                COALESCE(rl.completed_at, rl.created_at) as created_at
            FROM referral_logs rl
            LEFT JOIN users u ON rl.referred_id = u.id
            $refWhere
            ORDER BY rl.created_at DESC
        ");
        $refStmt->execute($refParams);
        $transactions = array_merge($transactions, $refStmt->fetchAll());
    } catch (Exception $e) {}
}

// Tarihe göre sırala (en yeni en üstte)
usort($transactions, function($a, $b) {
    return strtotime($b['created_at']) - strtotime($a['created_at']);
});

// Sayfalama
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$totalTransactions = count($transactions);
$totalPages = max(1, ceil($totalTransactions / $perPage));
$transactions = array_slice($transactions, ($page - 1) * $perPage, $perPage);

// İstatistikler - credit_amount dahil
$stats = ['total_spent' => 0, 'total_deposited' => 0, 'total_credit_received' => 0, 'order_count' => 0, 'deposit_count' => 0];
try {
    $statsQuery = $db->prepare("
        SELECT 
            (SELECT COALESCE(SUM(price), 0) FROM orders WHERE user_id = ?) as total_spent,
            (SELECT COALESCE(SUM(amount), 0) FROM payment_requests WHERE user_id = ? AND status = 'approved') as total_deposited,
            (SELECT COALESCE(SUM(COALESCE(credit_amount, amount)), 0) FROM payment_requests WHERE user_id = ? AND status = 'approved') as total_credit_received,
            (SELECT COUNT(*) FROM orders WHERE user_id = ?) as order_count,
            (SELECT COUNT(*) FROM payment_requests WHERE user_id = ? AND status = 'approved') as deposit_count
    ");
    $statsQuery->execute([$_SESSION['user_id'], $_SESSION['user_id'], $_SESSION['user_id'], $_SESSION['user_id'], $_SESSION['user_id']]);
    $stats = $statsQuery->fetch();
} catch (Exception $e) {}

// Bonus istatistikleri
$bonusStats = ['total_bonus' => 0, 'bonus_count' => 0];
try {
    $bonusStatsQuery = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total_bonus, COUNT(*) as bonus_count 
        FROM daily_bonus WHERE user_id = ?
    ");
    $bonusStatsQuery->execute([$_SESSION['user_id']]);
    $bonusStats = $bonusStatsQuery->fetch();
} catch (Exception $e) {}

// Referans istatistikleri - referral_logs tablosu
$referralStats = ['total_referral' => 0, 'referral_count' => 0];
try {
    $refStatsQuery = $db->prepare("
        SELECT COALESCE(SUM(bonus_amount), 0) as total_referral, COUNT(*) as referral_count 
        FROM referral_logs WHERE referrer_id = ? AND status = 'completed'
    ");
    $refStatsQuery->execute([$_SESSION['user_id']]);
    $referralStats = $refStatsQuery->fetch();
} catch (Exception $e) {}

$pageTitle = __('transaction_history') ?: 'İşlem Geçmişi';
require_once 'header.php';
?>

<style>
/* Stats Row */
.stats-row {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 15px;
    margin-bottom: 25px;
}

.stat-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    padding: 18px;
    display: flex;
    align-items: center;
    gap: 12px;
}

.stat-card .icon {
    width: 46px;
    height: 46px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.1rem;
    flex-shrink: 0;
}

.stat-card .icon.balance {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--on-accent-color);
}

.stat-card .icon.deposit {
    background: var(--success-soft-bg);
    color: var(--success-color);
}

.stat-card .icon.spent {
    background: var(--danger-soft-bg);
    color: var(--danger-color);
}

.stat-card .icon.bonus {
    background: var(--warning-soft-bg);
    color: var(--warning-color);
}

.stat-card .icon.referral {
    background: rgba(156, 89, 182, 0.15);
    color: #9b59b6;
}

.stat-card .info {
    min-width: 0;
    flex: 1;
}

.stat-card .info h4 {
    font-size: 1.15rem;
    font-weight: 700;
    margin-bottom: 2px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.stat-card .info p {
    font-size: 0.7rem;
    opacity: 0.6;
    margin: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.stat-card .info small {
    font-size: 0.65rem;
    opacity: 0.5;
    display: block;
    margin-top: 2px;
}

/* Filters */
.filters-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    padding: 20px;
    margin-bottom: 25px;
}

.filters-row {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    align-items: flex-end;
}

.filters-row .form-group {
    flex: 1;
    min-width: 130px;
    margin-bottom: 0;
}

.filters-row .form-group label {
    display: block;
    font-size: 0.75rem;
    margin-bottom: 6px;
    opacity: 0.7;
    font-weight: 600;
}

.filters-row .form-control {
    width: 100%;
    padding: 10px 12px;
    border: 2px solid var(--border-color);
    border-radius: 10px;
    background: var(--background-color);
    color: var(--text-color);
    font-size: 0.85rem;
}

.filters-row .form-control:focus {
    outline: none;
    border-color: var(--accent-text-color);
}

.filter-buttons {
    display: flex;
    gap: 8px;
}

.filters-row .btn {
    padding: 10px 16px;
    border-radius: 10px;
    font-weight: 600;
    cursor: pointer;
    border: none;
    display: flex;
    align-items: center;
    gap: 6px;
    transition: all 0.3s ease;
    font-size: 0.85rem;
    white-space: nowrap;
}

.filters-row .btn-primary {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--on-accent-color);
}

.filters-row .btn-secondary {
    background: var(--background-color);
    color: var(--text-color);
    border: 2px solid var(--border-color);
    padding: 8px 14px;
}

/* Transactions Card */
.transactions-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    overflow: hidden;
}

.card-header {
    padding: 18px 20px;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
}

.card-header h2 {
    font-size: 1rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 0;
}

.card-header h2 i {
    color: var(--accent-text-color);
}

.card-header .count {
    font-size: 0.8rem;
    opacity: 0.6;
    background: var(--background-color);
    padding: 6px 14px;
    border-radius: 8px;
}

/* Transactions List */
.transactions-list {
    padding: 12px;
}

.transaction-item {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 16px;
    background: var(--background-color);
    border-radius: 12px;
    margin-bottom: 10px;
    transition: all 0.2s ease;
}

.transaction-item:last-child {
    margin-bottom: 0;
}

.transaction-item:hover {
    transform: translateX(3px);
}

.transaction-item.has-package {
    border-left: 3px solid #e91e63;
}

.transaction-icon {
    width: 44px;
    height: 44px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
    flex-shrink: 0;
}

.transaction-icon.deposit {
    background: var(--success-soft-bg);
    color: var(--success-color);
}

.transaction-icon.order {
    background: var(--danger-soft-bg);
    color: var(--danger-color);
}

.transaction-icon.bonus {
    background: var(--warning-soft-bg);
    color: var(--warning-color);
}

.transaction-icon.referral {
    background: rgba(156, 89, 182, 0.15);
    color: #9b59b6;
}

.transaction-icon.package {
    background: rgba(233, 30, 99, 0.15);
    color: #e91e63;
}

.transaction-info {
    flex: 1;
    min-width: 0;
}

.transaction-info h4 {
    font-size: 0.9rem;
    font-weight: 600;
    margin-bottom: 4px;
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
}

.badge {
    font-size: 0.65rem;
    padding: 3px 8px;
    border-radius: 6px;
    font-weight: 500;
}

.badge.pending { background: var(--warning-soft-bg); color: var(--warning-color); }
.badge.processing { background: var(--info-soft-bg); color: var(--info-color); }
.badge.in_progress { background: rgba(0, 123, 255, 0.15); color: var(--info-color); }
.badge.completed { background: var(--success-soft-bg); color: var(--success-color); }
.badge.partial { background: rgba(253, 126, 20, 0.15); color: #fd7e14; }
.badge.cancelled { background: var(--danger-soft-bg); color: var(--danger-color); }
.badge.refunded { background: rgba(108, 117, 125, 0.15); color: var(--muted-text-color); }

.package-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 8px;
    background: rgba(233, 30, 99, 0.12);
    color: #e91e63;
    border-radius: 6px;
    font-size: 0.68rem;
    font-weight: 600;
}

.package-badge i {
    font-size: 0.6rem;
}

.transaction-info p {
    font-size: 0.8rem;
    opacity: 0.6;
    margin: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.transaction-meta {
    text-align: right;
    flex-shrink: 0;
}

.transaction-amount {
    font-size: 1rem;
    font-weight: 700;
    margin-bottom: 3px;
}

.transaction-amount.positive {
    color: var(--success-color);
}

.transaction-amount.positive::before {
    content: '+';
}

.transaction-amount.negative {
    color: var(--danger-color);
}

.transaction-amount.negative::before {
    content: '-';
}

.transaction-price-info {
    font-size: 0.7rem;
    opacity: 0.6;
    margin-top: 2px;
}

.transaction-price-info span {
    color: var(--accent-text-color);
    font-weight: 600;
}

.transaction-date {
    font-size: 0.75rem;
    opacity: 0.5;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 50px 20px;
}

.empty-state i {
    font-size: 3rem;
    color: var(--accent-text-color);
    opacity: 0.2;
    margin-bottom: 20px;
}

.empty-state h3 {
    font-size: 1.1rem;
    margin-bottom: 10px;
    opacity: 0.8;
}

.empty-state p {
    opacity: 0.5;
    margin-bottom: 20px;
    font-size: 0.9rem;
}

.empty-state .btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 24px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--on-accent-color);
    border-radius: 10px;
    text-decoration: none;
    font-weight: 600;
    font-size: 0.9rem;
}

/* Pagination */
.pagination {
    display: flex;
    justify-content: center;
    gap: 6px;
    padding: 18px;
    border-top: 1px solid var(--border-color);
    flex-wrap: wrap;
}

.pagination a,
.pagination span {
    padding: 8px 14px;
    border-radius: 8px;
    text-decoration: none;
    font-size: 0.85rem;
    font-weight: 500;
    transition: all 0.2s ease;
    min-width: 38px;
    text-align: center;
}

.pagination a {
    background: var(--background-color);
    color: var(--text-color);
    border: 1px solid var(--border-color);
}

.pagination a:hover {
    border-color: var(--accent-text-color);
    color: var(--accent-text-color);
}

.pagination .current {
    background: var(--primary-color);
    color: var(--on-primary-color);
}

.pagination .disabled {
    opacity: 0.4;
    pointer-events: none;
}

/* Mobile Cards */
.mobile-cards {
    display: none;
    padding: 12px;
}

.mobile-card {
    background: var(--background-color);
    border-radius: 12px;
    padding: 15px;
    margin-bottom: 10px;
}

.mobile-card:last-child {
    margin-bottom: 0;
}

.mobile-card.has-package {
    border-left: 3px solid #e91e63;
}

.mobile-card-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 12px;
    gap: 10px;
}

.mobile-card-header .left {
    display: flex;
    align-items: center;
    gap: 10px;
    min-width: 0;
    flex: 1;
}

.mobile-card-header .transaction-icon {
    width: 38px;
    height: 38px;
    font-size: 0.95rem;
}

.mobile-card-header .title {
    font-weight: 600;
    font-size: 0.85rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.mobile-card-body {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    padding-top: 12px;
    border-top: 1px solid var(--border-color);
}

.mobile-card-item {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.mobile-card-item label {
    font-size: 0.65rem;
    text-transform: uppercase;
    opacity: 0.5;
    font-weight: 600;
}

.mobile-card-item span {
    font-size: 0.8rem;
    font-weight: 500;
}

.mobile-card-item.full {
    grid-column: 1 / -1;
}

/* Responsive */
@media (max-width: 1200px) {
    .stats-row {
        grid-template-columns: repeat(3, 1fr);
    }
}

@media (max-width: 992px) {
    .stats-row {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 768px) {
    .stats-row {
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
    }
    
    .stat-card {
        padding: 14px;
    }
    
    .stat-card .icon {
        width: 40px;
        height: 40px;
        font-size: 1rem;
    }
    
    .stat-card .info h4 {
        font-size: 1rem;
    }
    
    .filters-row {
        flex-direction: column;
    }
    
    .filters-row .form-group {
        width: 100%;
    }
    
    .filter-buttons {
        width: 100%;
    }
    
    .filter-buttons .btn {
        flex: 1;
        justify-content: center;
    }
    
    /* Desktop list gizle, mobile cards göster */
    .transactions-list {
        display: none;
    }
    
    .mobile-cards {
        display: block;
    }
}

@media (max-width: 480px) {
    .stats-row {
        grid-template-columns: 1fr;
    }
    
    .card-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .card-header .count {
        width: 100%;
        text-align: center;
    }
}
</style>

<!-- Stats Row -->
<div class="stats-row">
    <div class="stat-card">
        <div class="icon balance"><i class="fas fa-wallet"></i></div>
        <div class="info">
            <h4><?php echo $siteSettings['currency_symbol'] . number_format($currentUser['balance'], 2); ?></h4>
            <p><?php echo __('current_balance') ?: 'Mevcut Bakiye'; ?></p>
        </div>
    </div>
    <div class="stat-card">
        <div class="icon deposit"><i class="fas fa-plus-circle"></i></div>
        <div class="info">
            <h4><?php echo $siteSettings['currency_symbol'] . number_format($stats['total_credit_received'] ?? $stats['total_deposited'] ?? 0, 2); ?></h4>
            <p><?php echo __('total_deposits') ?: 'Toplam Yükleme'; ?></p>
            <?php if (($stats['total_credit_received'] ?? 0) != ($stats['total_deposited'] ?? 0)): ?>
                <small>Ödenen: <?php echo $siteSettings['currency_symbol'] . number_format($stats['total_deposited'] ?? 0, 2); ?></small>
            <?php endif; ?>
        </div>
    </div>
    <div class="stat-card">
        <div class="icon spent"><i class="fas fa-minus-circle"></i></div>
        <div class="info">
            <h4><?php echo $siteSettings['currency_symbol'] . number_format($stats['total_spent'] ?? 0, 2); ?></h4>
            <p><?php echo __('total_spent') ?: 'Toplam Harcama'; ?></p>
        </div>
    </div>
    <div class="stat-card">
        <div class="icon bonus"><i class="fas fa-gift"></i></div>
        <div class="info">
            <h4><?php echo $siteSettings['currency_symbol'] . number_format($bonusStats['total_bonus'] ?? 0, 2); ?></h4>
            <p><?php echo __('bonus_earnings') ?: 'Bonus Kazancı'; ?></p>
        </div>
    </div>
    <div class="stat-card">
        <div class="icon referral"><i class="fas fa-users"></i></div>
        <div class="info">
            <h4><?php echo $siteSettings['currency_symbol'] . number_format($referralStats['total_referral'] ?? 0, 2); ?></h4>
            <p><?php echo __('referral_earnings') ?: 'Referans Kazancı'; ?></p>
        </div>
    </div>
</div>

<!-- Filters -->
<div class="filters-card">
    <form method="GET" class="filters-row">
        <div class="form-group">
            <label><?php echo __('transaction_type') ?: 'İşlem Türü'; ?></label>
            <select name="type" class="form-control">
                <option value=""><?php echo __('all') ?: 'Tümü'; ?></option>
                <option value="deposit" <?php echo $typeFilter === 'deposit' ? 'selected' : ''; ?>><?php echo __('balance_deposit') ?: 'Bakiye Yükleme'; ?></option>
                <option value="order" <?php echo $typeFilter === 'order' ? 'selected' : ''; ?>><?php echo __('orders') ?: 'Siparişler'; ?></option>
                <option value="bonus" <?php echo $typeFilter === 'bonus' ? 'selected' : ''; ?>><?php echo __('daily_bonus') ?: 'Günlük Bonus'; ?></option>
                <option value="referral" <?php echo $typeFilter === 'referral' ? 'selected' : ''; ?>><?php echo __('referral_earnings') ?: 'Referans Kazancı'; ?></option>
            </select>
        </div>
        <div class="form-group">
            <label><?php echo __('start_date') ?: 'Başlangıç'; ?></label>
            <input type="date" name="date_from" class="form-control" value="<?php echo $dateFrom; ?>">
        </div>
        <div class="form-group">
            <label><?php echo __('end_date') ?: 'Bitiş'; ?></label>
            <input type="date" name="date_to" class="form-control" value="<?php echo $dateTo; ?>">
        </div>
        <div class="filter-buttons">
            <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> <?php echo __('filter') ?: 'Filtrele'; ?></button>
            <a href="transactions.php" class="btn btn-secondary"><i class="fas fa-times"></i></a>
        </div>
    </form>
</div>

<!-- Transactions List -->
<div class="transactions-card">
    <div class="card-header">
        <h2><i class="fas fa-history"></i> <?php echo __('transaction_history') ?: 'İşlem Geçmişi'; ?></h2>
        <span class="count"><?php echo $totalTransactions; ?> <?php echo __('transactions') ?: 'işlem'; ?></span>
    </div>
    
    <?php if (empty($transactions)): ?>
        <div class="empty-state">
            <i class="fas fa-receipt"></i>
            <h3><?php echo __('no_transactions_found') ?: 'İşlem Bulunamadı'; ?></h3>
            <p><?php echo __('no_transactions_message') ?: 'Henüz herhangi bir işlem kaydınız bulunmuyor.'; ?></p>
            <a href="/kullanici/add-funds.php" class="btn">
                <i class="fas fa-plus"></i> <?php echo __('add_funds') ?: 'Bakiye Yükle'; ?>
            </a>
        </div>
    <?php else: ?>
        <!-- Desktop List -->
        <div class="transactions-list">
            <?php foreach ($transactions as $t): ?>
                <?php
                $hasPackage = !empty($t['package_id']) && !empty($t['package_name']);
                $creditAmount = !empty($t['credit_amount']) ? $t['credit_amount'] : $t['amount'];
                $paidAmount = $t['amount'];
                
                // İşlem türüne göre ikon ve sınıf belirleme
                $icon = 'arrow-up';
                $iconClass = 'order';
                $amountClass = 'negative';
                $displayAmount = $t['amount'];
                
                switch ($t['type']) {
                    case 'deposit':
                        $icon = $hasPackage ? 'box-open' : 'arrow-down';
                        $iconClass = $hasPackage ? 'package' : 'deposit';
                        $amountClass = 'positive';
                        $displayAmount = $creditAmount; // Paketli ödemelerde credit_amount göster
                        break;
                    case 'bonus':
                        $icon = 'gift';
                        $iconClass = 'bonus';
                        $amountClass = 'positive';
                        break;
                    case 'referral':
                        $icon = 'users';
                        $iconClass = 'referral';
                        $amountClass = 'positive';
                        break;
                }
                
                // Başlık çevirisi
                $title = $t['title'];
                if ($t['title'] === 'balance_deposit') {
                    $title = __('balance_deposit') ?: 'Bakiye Yükleme';
                } elseif ($t['title'] === 'package_deposit') {
                    $title = __('package_deposit') ?: 'Paket ile Yükleme';
                } elseif ($t['title'] === 'daily_bonus') {
                    $title = __('daily_bonus') ?: 'Günlük Bonus';
                } elseif ($t['title'] === 'referral_earning') {
                    $title = __('referral_earning') ?: 'Referans Kazancı';
                } elseif (strpos($t['title'], 'Sipariş #') === 0) {
                    $title = (__('order') ?: 'Sipariş') . ' #' . str_replace('Sipariş #', '', $t['title']);
                }
                
                // Tarih formatla
                $dateTime = new DateTime($t['created_at'], new DateTimeZone('Europe/Istanbul'));
                $formattedDate = $dateTime->format('d.m.Y H:i');
                ?>
                <div class="transaction-item <?php echo $hasPackage ? 'has-package' : ''; ?>">
                    <div class="transaction-icon <?php echo $iconClass; ?>">
                        <i class="fas fa-<?php echo $icon; ?>"></i>
                    </div>
                    <div class="transaction-info">
                        <h4>
                            <?php echo clean($title); ?>
                            <?php if ($t['type'] === 'order' && !empty($t['status'])): ?>
                                <span class="badge <?php echo $t['status']; ?>"><?php echo __('status_' . $t['status']) ?: ucfirst(str_replace('_', ' ', $t['status'])); ?></span>
                            <?php endif; ?>
                            <?php if ($hasPackage): ?>
                                <span class="package-badge">
                                    <i class="fas fa-box-open"></i>
                                    <?php echo clean($t['package_name']); ?>
                                </span>
                            <?php endif; ?>
                        </h4>
                        <p><?php echo clean($t['description'] ?? ''); ?></p>
                    </div>
                    <div class="transaction-meta">
                        <div class="transaction-amount <?php echo $amountClass; ?>">
                            <?php echo $siteSettings['currency_symbol'] . number_format($displayAmount, 2); ?>
                        </div>
                        <?php if ($hasPackage && $creditAmount != $paidAmount): ?>
                            <div class="transaction-price-info">
                                Ödenen: <span><?php echo $siteSettings['currency_symbol'] . number_format($paidAmount, 2); ?></span>
                            </div>
                        <?php endif; ?>
                        <div class="transaction-date"><?php echo $formattedDate; ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Mobile Cards -->
        <div class="mobile-cards">
            <?php foreach ($transactions as $t): ?>
                <?php
                $hasPackage = !empty($t['package_id']) && !empty($t['package_name']);
                $creditAmount = !empty($t['credit_amount']) ? $t['credit_amount'] : $t['amount'];
                $paidAmount = $t['amount'];
                
                // İşlem türüne göre ikon ve sınıf belirleme
                $icon = 'arrow-up';
                $iconClass = 'order';
                $amountClass = 'negative';
                $displayAmount = $t['amount'];
                
                switch ($t['type']) {
                    case 'deposit':
                        $icon = $hasPackage ? 'box-open' : 'arrow-down';
                        $iconClass = $hasPackage ? 'package' : 'deposit';
                        $amountClass = 'positive';
                        $displayAmount = $creditAmount;
                        break;
                    case 'bonus':
                        $icon = 'gift';
                        $iconClass = 'bonus';
                        $amountClass = 'positive';
                        break;
                    case 'referral':
                        $icon = 'users';
                        $iconClass = 'referral';
                        $amountClass = 'positive';
                        break;
                }
                
                // Başlık çevirisi
                $title = $t['title'];
                if ($t['title'] === 'balance_deposit') {
                    $title = __('balance_deposit') ?: 'Bakiye Yükleme';
                } elseif ($t['title'] === 'package_deposit') {
                    $title = __('package_deposit') ?: 'Paket ile Yükleme';
                } elseif ($t['title'] === 'daily_bonus') {
                    $title = __('daily_bonus') ?: 'Günlük Bonus';
                } elseif ($t['title'] === 'referral_earning') {
                    $title = __('referral_earning') ?: 'Referans Kazancı';
                } elseif (strpos($t['title'], 'Sipariş #') === 0) {
                    $title = (__('order') ?: 'Sipariş') . ' #' . str_replace('Sipariş #', '', $t['title']);
                }
                
                // Tarih formatla
                $dateTime = new DateTime($t['created_at'], new DateTimeZone('Europe/Istanbul'));
                $formattedDate = $dateTime->format('d.m.Y H:i');
                ?>
                <div class="mobile-card <?php echo $hasPackage ? 'has-package' : ''; ?>">
                    <div class="mobile-card-header">
                        <div class="left">
                            <div class="transaction-icon <?php echo $iconClass; ?>">
                                <i class="fas fa-<?php echo $icon; ?>"></i>
                            </div>
                            <span class="title"><?php echo clean($title); ?></span>
                        </div>
                        <div>
                            <div class="transaction-amount <?php echo $amountClass; ?>" style="font-size:0.9rem;">
                                <?php echo ($amountClass === 'positive' ? '+' : '-') . $siteSettings['currency_symbol'] . number_format($displayAmount, 2); ?>
                            </div>
                            <?php if ($hasPackage && $creditAmount != $paidAmount): ?>
                                <div class="transaction-price-info" style="text-align:right;">
                                    Ödenen: <span><?php echo $siteSettings['currency_symbol'] . number_format($paidAmount, 2); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="mobile-card-body">
                        <?php if ($hasPackage): ?>
                            <div class="mobile-card-item">
                                <label><?php echo __('package') ?: 'Paket'; ?></label>
                                <span class="package-badge" style="width:fit-content;">
                                    <i class="fas fa-box-open"></i>
                                    <?php echo clean($t['package_name']); ?>
                                </span>
                            </div>
                        <?php endif; ?>
                        <div class="mobile-card-item">
                            <label><?php echo __('description') ?: 'Açıklama'; ?></label>
                            <span><?php echo clean($t['description'] ?? '-'); ?></span>
                        </div>
                        <div class="mobile-card-item">
                            <label><?php echo __('date') ?: 'Tarih'; ?></label>
                            <span><?php echo $formattedDate; ?></span>
                        </div>
                        <?php if ($t['type'] === 'order' && !empty($t['status'])): ?>
                            <div class="mobile-card-item full">
                                <label><?php echo __('status') ?: 'Durum'; ?></label>
                                <span class="badge <?php echo $t['status']; ?>" style="width:fit-content;margin-top:3px;">
                                    <?php echo __('status_' . $t['status']) ?: ucfirst(str_replace('_', ' ', $t['status'])); ?>
                                </span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <?php if ($totalPages > 1): ?>
            <div class="pagination">
                <?php 
                $queryString = http_build_query(array_filter([
                    'type' => $typeFilter,
                    'date_from' => $dateFrom,
                    'date_to' => $dateTo
                ]));
                $baseUrl = 'transactions.php?' . ($queryString ? $queryString . '&' : '');
                ?>
                
                <?php if ($page > 1): ?>
                    <a href="<?php echo $baseUrl; ?>page=<?php echo $page - 1; ?>"><i class="fas fa-chevron-left"></i></a>
                <?php endif; ?>
                
                <?php
                $startPage = max(1, $page - 2);
                $endPage = min($totalPages, $page + 2);
                
                if ($startPage > 1): ?>
                    <a href="<?php echo $baseUrl; ?>page=1">1</a>
                    <?php if ($startPage > 2): ?><span class="disabled">...</span><?php endif; ?>
                <?php endif; ?>
                
                <?php for ($i = $startPage; $i <= $endPage; $i++): ?>
                    <?php if ($i == $page): ?>
                        <span class="current"><?php echo $i; ?></span>
                    <?php else: ?>
                        <a href="<?php echo $baseUrl; ?>page=<?php echo $i; ?>"><?php echo $i; ?></a>
                    <?php endif; ?>
                <?php endfor; ?>
                
                <?php if ($endPage < $totalPages): ?>
                    <?php if ($endPage < $totalPages - 1): ?><span class="disabled">...</span><?php endif; ?>
                    <a href="<?php echo $baseUrl; ?>page=<?php echo $totalPages; ?>"><?php echo $totalPages; ?></a>
                <?php endif; ?>
                
                <?php if ($page < $totalPages): ?>
                    <a href="<?php echo $baseUrl; ?>page=<?php echo $page + 1; ?>"><i class="fas fa-chevron-right"></i></a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php require_once 'footer.php'; ?>