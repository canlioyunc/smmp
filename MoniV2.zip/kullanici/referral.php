<?php
/**
 * Kullanıcı Paneli - Referans Programı
 */

require_once 'header.php';

// Referans sistemi açık mı kontrol et
$referralEnabled = getSetting('referral_enabled', '1');

if ($referralEnabled != '1') {
    ?>
    <style>
        .closed-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 60vh;
            text-align: center;
            padding: 40px;
        }
        
        .closed-icon {
            width: 120px;
            height: 120px;
            background: linear-gradient(135deg, var(--danger-soft-bg), rgba(220, 53, 69, 0.05));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 30px;
        }
        
        .closed-icon i {
            font-size: 3.5rem;
            color: var(--danger-color);
        }
        
        .closed-container h2 {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 15px;
            color: var(--text-color);
        }
        
        .closed-container p {
            font-size: 1.1rem;
            opacity: 0.7;
            max-width: 500px;
            margin-bottom: 30px;
            line-height: 1.6;
        }
        
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 14px 30px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 12px;
            color: var(--on-accent-color);
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .back-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px var(--primary-alpha-03);
        }
    </style>
    
    <div class="closed-container">
        <div class="closed-icon">
            <i class="fas fa-lock"></i>
        </div>
        <h2><?php echo __('referral_program_closed'); ?></h2>
        <p><?php echo __('referral_program_closed_desc'); ?></p>
        <a href="/kullanici/" class="back-btn">
            <i class="fas fa-arrow-left"></i>
            <?php echo __('back_to_dashboard'); ?>
        </a>
    </div>
    
    <?php
    require_once 'footer.php';
    exit;
}

// Kullanıcının referans kodunu kontrol et ve yoksa oluştur
if (empty($currentUser['referral_code'])) {
    $referralCode = strtoupper(substr(md5($currentUser['id'] . $currentUser['username'] . time()), 0, 8));
    $stmt = $db->prepare("UPDATE users SET referral_code = ? WHERE id = ?");
    $stmt->execute([$referralCode, $currentUser['id']]);
    $currentUser['referral_code'] = $referralCode;
}

$success = '';
$error = '';

// Referans ayarlarını al
$referralSettings = [
    'enabled' => getSetting('referral_enabled', '1'),
    'bonus_amount' => floatval(getSetting('referral_bonus_amount', '5')),
    'min_transfer' => floatval(getSetting('referral_min_transfer', '10'))
];
$referralFraudColumn = function_exists('moni_v2_compat_column_exists') && moni_v2_compat_column_exists($db,'referral_logs','fraud_status');
$referralClearSql = $referralFraudColumn ? " AND fraud_status='clear'" : '';

// Kazancı bakiyeye aktar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['transfer_earnings'])) {
    $minTransfer=$referralSettings['min_transfer'];
    try{
        $db->beginTransaction();
        $u=$db->prepare("SELECT balance FROM users WHERE id=? FOR UPDATE");$u->execute([$currentUser['id']]);$oldBalance=$u->fetchColumn();
        if($oldBalance===false) throw new RuntimeException('USER');
        $rows=$db->prepare("SELECT id,bonus_amount FROM referral_logs WHERE referrer_id=? AND status='pending'{$referralClearSql} FOR UPDATE");$rows->execute([$currentUser['id']]);$pendingRows=$rows->fetchAll(PDO::FETCH_ASSOC);
        $pendingAmount=array_sum(array_map(fn($r)=>(float)$r['bonus_amount'],$pendingRows));
        if($pendingAmount<=0) throw new RuntimeException('NONE');
        if($pendingAmount<$minTransfer) throw new RuntimeException('MIN');
        $ids=array_map(fn($r)=>(int)$r['id'],$pendingRows);$ph=implode(',',array_fill(0,count($ids),'?'));
        $db->prepare("UPDATE referral_logs SET status='completed',completed_at=NOW() WHERE status='pending' AND id IN ($ph)")->execute($ids);
        $db->prepare("UPDATE users SET balance=balance+? WHERE id=?")->execute([$pendingAmount,$currentUser['id']]);
        $newBalance=(float)$oldBalance+$pendingAmount;
        $db->prepare("INSERT INTO transactions(user_id,type,amount,balance_after,description,status,created_at) VALUES(?,'referral_bonus',?,?,?,'completed',NOW())")
           ->execute([$currentUser['id'],$pendingAmount,$newBalance,'Referral Bonus']);
        $db->commit();moni_sync_base_wallet($db,(int)$currentUser['id']);
        $success=__('transfer_success',['amount'=>$siteSettings['currency_symbol'].number_format($pendingAmount,2)]);$currentUser['balance']=$newBalance;$_SESSION['balance']=$newBalance;
    }catch(Throwable $e){if($db->inTransaction())$db->rollBack();if($e->getMessage()==='NONE')$error=__('no_pending_earnings');elseif($e->getMessage()==='MIN')$error=__('insufficient_earnings',['amount'=>$siteSettings['currency_symbol'].number_format($minTransfer,2)]);else{$error=__('transfer_error');error_log('Referral transfer: '.$e->getMessage());}}
}

// İstatistikleri hesapla
$stats = [
    'total_referrals' => 0,
    'total_earnings' => 0,
    'pending_earnings' => 0,
    'completed_earnings' => 0
];

$referralLogs = [];

try {
    $totalRefStmt = $db->prepare("SELECT COUNT(*) FROM referral_logs WHERE referrer_id = ?");
    $totalRefStmt->execute([$currentUser['id']]);
    $stats['total_referrals'] = $totalRefStmt->fetchColumn();

    $totalEarningsStmt = $db->prepare("SELECT COALESCE(SUM(bonus_amount), 0) FROM referral_logs WHERE referrer_id = ?");
    $totalEarningsStmt->execute([$currentUser['id']]);
    $stats['total_earnings'] = $totalEarningsStmt->fetchColumn();

    $pendingEarningsStmt = $db->prepare("SELECT COALESCE(SUM(bonus_amount), 0) FROM referral_logs WHERE referrer_id = ? AND status = 'pending'{$referralClearSql}");
    $pendingEarningsStmt->execute([$currentUser['id']]);
    $stats['pending_earnings'] = $pendingEarningsStmt->fetchColumn();

    $completedEarningsStmt = $db->prepare("SELECT COALESCE(SUM(bonus_amount), 0) FROM referral_logs WHERE referrer_id = ? AND status = 'completed'");
    $completedEarningsStmt->execute([$currentUser['id']]);
    $stats['completed_earnings'] = $completedEarningsStmt->fetchColumn();

    $referralLogsStmt = $db->prepare("
        SELECT rl.*, u.username, u.email
        FROM referral_logs rl
        LEFT JOIN users u ON rl.referred_id = u.id
        WHERE rl.referrer_id = ?
        ORDER BY rl.created_at DESC
        LIMIT 50
    ");
    $referralLogsStmt->execute([$currentUser['id']]);
    $referralLogs = $referralLogsStmt->fetchAll();
} catch (Exception $e) {}

$referralLink = SITE_URL . '/register.php?ref=' . $currentUser['referral_code'];
$pageTitle = __('referral_program');
?>

<style>
.referral-hero {
    background: linear-gradient(135deg, var(--warning-color), var(--danger-color));
    border-radius: 20px;
    padding: 40px;
    margin-bottom: 25px;
    position: relative;
    overflow: hidden;
}

.referral-hero::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -20%;
    width: 400px;
    height: 400px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
}

.referral-hero-content {
    position: relative;
    z-index: 1;
}

.referral-hero h1 {
    font-size: 2rem;
    font-weight: 700;
    color: #fff;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 15px;
}

.referral-hero h1 i {
    font-size: 2.5rem;
}

.referral-hero p {
    font-size: 1.1rem;
    color: rgba(255, 255, 255, 0.9);
    margin-bottom: 25px;
    max-width: 600px;
}

.bonus-highlight {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    background: rgba(255, 255, 255, 0.2);
    padding: 10px 20px;
    border-radius: 30px;
    margin-bottom: 20px;
    color: #fff;
    font-weight: 600;
}

.bonus-highlight .amount {
    font-size: 1.5rem;
    font-weight: 700;
}

.referral-link-box {
    background: rgba(255, 255, 255, 0.15);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
    display: flex;
    gap: 15px;
    align-items: center;
    flex-wrap: wrap;
}

.referral-link-input {
    flex: 1;
    min-width: 250px;
    padding: 15px 20px;
    background: rgba(255, 255, 255, 0.2);
    border: 2px solid rgba(255, 255, 255, 0.3);
    border-radius: 12px;
    color: #fff;
    font-size: 0.95rem;
    font-family: monospace;
}

.referral-link-input:focus {
    outline: none;
    border-color: #fff;
}

.copy-btn {
    padding: 15px 30px;
    background: #fff;
    border: none;
    border-radius: 12px;
    color: var(--danger-color);
    font-size: 0.95rem;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 10px;
    transition: all 0.3s ease;
}

.copy-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
}

.copy-btn.copied {
    background: var(--success-color);
    color: #fff;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
    margin-bottom: 25px;
}

@media (max-width: 1200px) {
    .stats-grid { grid-template-columns: repeat(2, 1fr); }
}

@media (max-width: 576px) {
    .stats-grid { grid-template-columns: 1fr; }
}

.stat-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    padding: 25px;
    display: flex;
    align-items: center;
    gap: 20px;
}

.stat-icon {
    width: 60px;
    height: 60px;
    border-radius: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
}

.stat-icon.referrals { background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: var(--on-accent-color); }
.stat-icon.earnings { background: linear-gradient(135deg, #11998e, #38ef7d); color: #fff; }
.stat-icon.pending { background: linear-gradient(135deg, var(--warning-color), var(--danger-color)); color: #fff; }
.stat-icon.completed { background: linear-gradient(135deg, #00b894, #00cec9); color: #fff; }

.stat-info h3 {
    font-size: 1.8rem;
    font-weight: 700;
    margin: 0 0 5px 0;
}

.stat-info p {
    font-size: 0.9rem;
    opacity: 0.6;
    margin: 0;
}

.content-grid {
    display: grid;
    grid-template-columns: 1fr 350px;
    gap: 25px;
}

@media (max-width: 1100px) {
    .content-grid { grid-template-columns: 1fr; }
}

.referral-card {
    background: var(--card-bg-color);
    border: 1px solid var(--border-color);
    border-radius: 16px;
    overflow: hidden;
}

.referral-card-header {
    padding: 20px 25px;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.referral-card-header h3 {
    font-size: 1.1rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 0;
}

.referral-card-header h3 i {
    color: var(--accent-text-color);
}

.referral-card-body {
    padding: 25px;
}

.share-buttons {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 12px;
    margin-bottom: 20px;
}

.share-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    padding: 14px 20px;
    border: none;
    border-radius: 12px;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    color: #fff;
    transition: all 0.3s ease;
}

.share-btn:hover {
    transform: translateY(-2px);
    color: #fff;
}

.share-btn.facebook { background: #1877f2; }
.share-btn.twitter { background: #1da1f2; }
.share-btn.whatsapp { background: #25d366; }
.share-btn.telegram { background: #0088cc; }

.referral-code-box {
    background: var(--background-color);
    border-radius: 12px;
    padding: 20px;
    text-align: center;
    margin-bottom: 20px;
}

.referral-code-box label {
    display: block;
    font-size: 0.85rem;
    opacity: 0.6;
    margin-bottom: 10px;
}

.referral-code {
    font-size: 2rem;
    font-weight: 700;
    font-family: monospace;
    letter-spacing: 3px;
    color: var(--accent-text-color);
    margin-bottom: 15px;
}

.copy-code-btn {
    padding: 10px 25px;
    background: var(--primary-color);
    border: none;
    border-radius: 10px;
    color: var(--on-primary-color);
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
}

.how-it-works {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.step-item {
    display: flex;
    gap: 15px;
    align-items: flex-start;
}

.step-number {
    width: 36px;
    height: 36px;
    min-width: 36px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    color: var(--on-accent-color);
}

.step-content h4 {
    font-size: 0.95rem;
    font-weight: 600;
    margin: 0 0 3px 0;
}

.step-content p {
    font-size: 0.85rem;
    opacity: 0.6;
    margin: 0;
}

.referral-table {
    width: 100%;
    border-collapse: collapse;
}

.referral-table th,
.referral-table td {
    padding: 15px;
    text-align: left;
    border-bottom: 1px solid var(--border-color);
}

.referral-table th {
    font-size: 0.8rem;
    font-weight: 600;
    text-transform: uppercase;
    opacity: 0.6;
    background: var(--background-color);
}

.referral-table tbody tr:hover {
    background: var(--background-color);
}

.user-cell {
    display: flex;
    align-items: center;
    gap: 12px;
}

.user-avatar-sm {
    width: 38px;
    height: 38px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--on-accent-color);
    font-weight: 600;
}

.user-info-sm h5 {
    font-size: 0.9rem;
    font-weight: 600;
    margin: 0 0 2px 0;
}

.user-info-sm span {
    font-size: 0.8rem;
    opacity: 0.6;
}

.amount-cell {
    font-weight: 600;
    color: var(--success-color);
}

.status-badge {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
}

.status-badge.pending { background: var(--warning-soft-bg); color: var(--warning-color); }
.status-badge.completed { background: var(--success-soft-bg); color: var(--success-color); }

.transfer-box {
    background: linear-gradient(135deg, var(--success-soft-bg), rgba(32, 201, 151, 0.1));
    border: 2px solid rgba(40, 167, 69, 0.3);
    border-radius: 16px;
    padding: 25px;
    margin-bottom: 25px;
}

.transfer-box-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 20px;
}

.transfer-info h4 {
    font-size: 1rem;
    font-weight: 600;
    margin: 0 0 5px 0;
    color: var(--success-color);
}

.transfer-info p {
    font-size: 0.85rem;
    opacity: 0.7;
    margin: 0;
}

.transfer-amount .label {
    font-size: 0.85rem;
    opacity: 0.6;
    margin-bottom: 5px;
}

.transfer-amount .value {
    font-size: 2rem;
    font-weight: 700;
    color: var(--success-color);
}

.transfer-btn {
    width: 100%;
    margin-top: 20px;
    padding: 16px;
    background: linear-gradient(135deg, var(--success-color), #20c997);
    border: none;
    border-radius: 12px;
    color: #fff;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.transfer-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.min-info {
    text-align: center;
    margin-top: 10px;
    font-size: 0.8rem;
    opacity: 0.6;
}

.empty-state {
    text-align: center;
    padding: 50px 20px;
}

.empty-state i {
    font-size: 4rem;
    color: var(--accent-text-color);
    opacity: 0.2;
    margin-bottom: 20px;
}

.empty-state h4 {
    font-size: 1.1rem;
    margin-bottom: 10px;
}

.empty-state p {
    font-size: 0.9rem;
    opacity: 0.6;
}

@media (max-width: 768px) {
    .referral-hero { padding: 25px; }
    .referral-hero h1 { font-size: 1.5rem; }
    .referral-link-box { flex-direction: column; }
    .referral-link-input, .copy-btn { width: 100%; }
    .copy-btn { justify-content: center; }
    .share-buttons { grid-template-columns: 1fr; }
    .transfer-box-header { flex-direction: column; text-align: center; }
    .transfer-amount { text-align: center; }
}
</style>

<?php if ($success): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?php echo $success; ?>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?php echo $error; ?>
    </div>
<?php endif; ?>

<!-- Referral Hero -->
<div class="referral-hero">
    <div class="referral-hero-content">
        <h1>
            <i class="fas fa-gift"></i>
            <?php echo __('share_and_earn'); ?>
        </h1>
        
        <div class="bonus-highlight">
            <i class="fas fa-coins"></i>
            <span><?php echo __('per_referral'); ?>:</span>
            <span class="amount"><?php echo $siteSettings['currency_symbol'] . number_format($referralSettings['bonus_amount'], 2); ?></span>
        </div>
        
        <p><?php echo __('referral_invite_text', ['amount' => $siteSettings['currency_symbol'] . number_format($referralSettings['bonus_amount'], 2)]); ?></p>
        
        <div class="referral-link-box">
            <input type="text" class="referral-link-input" id="referralLink" value="<?php echo $referralLink; ?>" readonly>
            <button type="button" class="copy-btn" id="copyLinkBtn" onclick="copyReferralLink()">
                <i class="fas fa-copy"></i>
                <span><?php echo __('copy_link'); ?></span>
            </button>
        </div>
    </div>
</div>

<!-- Transfer Box -->
<?php if ($stats['pending_earnings'] > 0): ?>
<div class="transfer-box">
    <div class="transfer-box-header">
        <div class="transfer-info">
            <h4>
                <i class="fas fa-wallet"></i>
                <?php echo __('pending_earnings'); ?>
            </h4>
            <p><?php echo __('min_transfer_amount'); ?>: <?php echo $siteSettings['currency_symbol'] . number_format($referralSettings['min_transfer'], 2); ?></p>
        </div>
        <div class="transfer-amount">
            <div class="label"><?php echo __('available_to_transfer'); ?></div>
            <div class="value"><?php echo $siteSettings['currency_symbol'] . number_format($stats['pending_earnings'], 2); ?></div>
        </div>
    </div>
    
    <form method="POST">
        <button type="submit" name="transfer_earnings" class="transfer-btn" <?php echo $stats['pending_earnings'] < $referralSettings['min_transfer'] ? 'disabled' : ''; ?>>
            <i class="fas fa-exchange-alt"></i>
            <?php echo __('transfer_to_balance'); ?>
        </button>
        <?php if ($stats['pending_earnings'] < $referralSettings['min_transfer']): ?>
            <div class="min-info">
                <?php echo __('min_required', ['amount' => $siteSettings['currency_symbol'] . number_format($referralSettings['min_transfer'], 2)]); ?>
            </div>
        <?php endif; ?>
    </form>
</div>
<?php endif; ?>

<!-- Stats Grid -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon referrals"><i class="fas fa-users"></i></div>
        <div class="stat-info">
            <h3><?php echo number_format($stats['total_referrals']); ?></h3>
            <p><?php echo __('total_referrals'); ?></p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon earnings"><i class="fas fa-coins"></i></div>
        <div class="stat-info">
            <h3><?php echo $siteSettings['currency_symbol'] . number_format($stats['total_earnings'], 2); ?></h3>
            <p><?php echo __('total_earnings'); ?></p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon pending"><i class="fas fa-clock"></i></div>
        <div class="stat-info">
            <h3><?php echo $siteSettings['currency_symbol'] . number_format($stats['pending_earnings'], 2); ?></h3>
            <p><?php echo __('pending_earnings_stat'); ?></p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon completed"><i class="fas fa-check-circle"></i></div>
        <div class="stat-info">
            <h3><?php echo $siteSettings['currency_symbol'] . number_format($stats['completed_earnings'], 2); ?></h3>
            <p><?php echo __('transferred_earnings'); ?></p>
        </div>
    </div>
</div>

<!-- Content Grid -->
<div class="content-grid">
    <!-- Referral Logs -->
    <div class="referral-card">
        <div class="referral-card-header">
            <h3>
                <i class="fas fa-history"></i>
                <?php echo __('referral_history'); ?>
            </h3>
            <span class="status-badge completed"><?php echo $stats['total_referrals']; ?> <?php echo __('total'); ?></span>
        </div>
        
        <?php if (empty($referralLogs)): ?>
            <div class="empty-state">
                <i class="fas fa-users"></i>
                <h4><?php echo __('no_referrals_yet'); ?></h4>
                <p><?php echo __('no_referrals_desc'); ?></p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="referral-table">
                    <thead>
                        <tr>
                            <th><?php echo __('user'); ?></th>
                            <th><?php echo __('bonus'); ?></th>
                            <th><?php echo __('status'); ?></th>
                            <th><?php echo __('date'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($referralLogs as $log): ?>
                            <tr>
                                <td>
                                    <div class="user-cell">
                                        <div class="user-avatar-sm">
                                            <?php echo strtoupper(mb_substr($log['username'] ?? '?', 0, 1, 'UTF-8')); ?>
                                        </div>
                                        <div class="user-info-sm">
                                            <h5><?php echo clean($log['username'] ?? __('deleted_user')); ?></h5>
                                            <span><?php echo clean($log['email'] ?? ''); ?></span>
                                        </div>
                                    </div>
                                </td>
                                <td class="amount-cell">
                                    +<?php echo $siteSettings['currency_symbol'] . number_format($log['bonus_amount'], 2); ?>
                                </td>
                                <td>
                                    <span class="status-badge <?php echo $log['status']; ?>">
                                        <?php echo $log['status'] === 'pending' ? __('status_pending') : __('status_transferred'); ?>
                                    </span>
                                </td>
                                <td><?php echo moni_format_user_time($db,(int)$_SESSION['user_id'],$log['created_at']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Sidebar -->
    <div>
        <!-- Share Card -->
        <div class="referral-card" style="margin-bottom: 25px;">
            <div class="referral-card-header">
                <h3>
                    <i class="fas fa-share-alt"></i>
                    <?php echo __('quick_share'); ?>
                </h3>
            </div>
            <div class="referral-card-body">
                <div class="share-buttons">
                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode($referralLink); ?>" target="_blank" class="share-btn facebook">
                        <i class="fab fa-facebook-f"></i> Facebook
                    </a>
                    <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode($referralLink); ?>" target="_blank" class="share-btn twitter">
                        <i class="fab fa-twitter"></i> Twitter
                    </a>
                    <a href="https://wa.me/?text=<?php echo urlencode($referralLink); ?>" target="_blank" class="share-btn whatsapp">
                        <i class="fab fa-whatsapp"></i> WhatsApp
                    </a>
                    <a href="https://t.me/share/url?url=<?php echo urlencode($referralLink); ?>" target="_blank" class="share-btn telegram">
                        <i class="fab fa-telegram-plane"></i> Telegram
                    </a>
                </div>
                
                <div class="referral-code-box">
                    <label><?php echo __('your_referral_code'); ?></label>
                    <div class="referral-code" id="referralCode"><?php echo $currentUser['referral_code']; ?></div>
                    <button type="button" class="copy-code-btn" onclick="copyReferralCode()">
                        <i class="fas fa-copy"></i> <?php echo __('copy_code'); ?>
                    </button>
                </div>
            </div>
        </div>
        
        <!-- How It Works -->
        <div class="referral-card">
            <div class="referral-card-header">
                <h3>
                    <i class="fas fa-question-circle"></i>
                    <?php echo __('how_it_works'); ?>
                </h3>
            </div>
            <div class="referral-card-body">
                <div class="how-it-works">
                    <div class="step-item">
                        <div class="step-number">1</div>
                        <div class="step-content">
                            <h4><?php echo __('step1_title'); ?></h4>
                            <p><?php echo __('step1_desc'); ?></p>
                        </div>
                    </div>
                    <div class="step-item">
                        <div class="step-number">2</div>
                        <div class="step-content">
                            <h4><?php echo __('step2_title'); ?></h4>
                            <p><?php echo __('step2_desc'); ?></p>
                        </div>
                    </div>
                    <div class="step-item">
                        <div class="step-number">3</div>
                        <div class="step-content">
                            <h4><?php echo __('step3_title'); ?></h4>
                            <p><?php echo __('step3_desc', ['amount' => $siteSettings['currency_symbol'] . number_format($referralSettings['bonus_amount'], 2)]); ?></p>
                        </div>
                    </div>
                    <div class="step-item">
                        <div class="step-number">4</div>
                        <div class="step-content">
                            <h4><?php echo __('step4_title'); ?></h4>
                            <p><?php echo __('step4_desc'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function copyReferralLink() {
    var input = document.getElementById('referralLink');
    input.select();
    navigator.clipboard.writeText(input.value).then(function() {
        var btn = document.getElementById('copyLinkBtn');
        btn.classList.add('copied');
        btn.innerHTML = '<i class="fas fa-check"></i> <span><?php echo __('copied'); ?></span>';
        setTimeout(function() {
            btn.classList.remove('copied');
            btn.innerHTML = '<i class="fas fa-copy"></i> <span><?php echo __('copy_link'); ?></span>';
        }, 2000);
    });
}

function copyReferralCode() {
    var code = document.getElementById('referralCode').textContent;
    navigator.clipboard.writeText(code).then(function() {
        var btn = document.querySelector('.copy-code-btn');
        var original = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-check"></i> <?php echo __('copied'); ?>';
        btn.style.background = 'var(--success-color)';
        setTimeout(function() {
            btn.innerHTML = original;
            btn.style.background = '';
        }, 2000);
    });
}
</script>

<?php require_once 'footer.php'; ?>