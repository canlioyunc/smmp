<?php
require_once __DIR__ . '/../config.php';
require_login('/login.php');
$userId=(int)$_SESSION['user_id'];

if($_SERVER['REQUEST_METHOD']==='POST'){
    $action=(string)($_POST['action']??'');
    if($action==='revoke_session'){
        $id=(int)($_POST['session_id']??0);
        $q=$db->prepare("SELECT session_hash,device_id FROM user_sessions WHERE id=? AND user_id=? LIMIT 1");$q->execute([$id,$userId]);$sessionRow=$q->fetch(PDO::FETCH_ASSOC);$hash=$sessionRow['session_hash']??false;
        if($hash!==false){
            moni_revoke_session($db,$userId,$id);
            if(!empty($sessionRow['device_id']) && moni_table_ready($db,'remember_tokens'))$db->prepare("DELETE FROM remember_tokens WHERE user_id=? AND device_id=?")->execute([$userId,$sessionRow['device_id']]);
            setAlert('Oturum kapatıldı.','success');
        }
        if($hash!==false && hash_equals((string)$hash,hash('sha256',session_id()))){moni_forget_remember_token($db);$_SESSION=[];session_destroy();header('Location: /login.php?error=session_revoked');exit;}
        $returnPage=max(1,(int)($_POST['session_page']??1));
        header('Location: /kullanici/security-center.php?session_page='.$returnPage.'#sessions');exit;
    }
    if($action==='revoke_others'){
        $current=hash('sha256',session_id());
        $s=$db->prepare("UPDATE user_sessions SET revoked_at=NOW() WHERE user_id=? AND session_hash<>? AND revoked_at IS NULL");$s->execute([$userId,$current]);
        if(moni_table_ready($db,'remember_tokens'))$db->prepare("DELETE FROM remember_tokens WHERE user_id=? AND (device_id IS NULL OR device_id<>?)")->execute([$userId,moni_device_id()]);
        moni_security_event($userId,'other_sessions_revoked','warning',['count'=>$s->rowCount()]);
        setAlert($s->rowCount().' diğer oturum kapatıldı.','success');
        $returnPage=max(1,(int)($_POST['session_page']??1));
        header('Location: /kullanici/security-center.php?session_page='.$returnPage.'#sessions');exit;
    }
}

moni_track_session($db,$userId);
$currentHash=hash('sha256',session_id());

// Oturum Yönetimi: uzun cihaz geçmişinin sayfayı gereksiz uzatmaması için sunucu taraflı sayfalama.
$sessionPerPage=5;
$sessionPage=max(1,(int)($_GET['session_page']??1));
$sessionCountStmt=$db->prepare("SELECT COUNT(*) FROM user_sessions WHERE user_id=?");
$sessionCountStmt->execute([$userId]);
$sessionTotal=(int)$sessionCountStmt->fetchColumn();
$sessionTotalPages=max(1,(int)ceil($sessionTotal/$sessionPerPage));
if($sessionPage>$sessionTotalPages)$sessionPage=$sessionTotalPages;
$sessionOffset=($sessionPage-1)*$sessionPerPage;
$s=$db->prepare("SELECT * FROM user_sessions WHERE user_id=? ORDER BY (revoked_at IS NULL) DESC,last_activity_at DESC LIMIT ".$sessionPerPage." OFFSET ".$sessionOffset);
$s->execute([$userId]);
$sessions=$s->fetchAll(PDO::FETCH_ASSOC);
$sessionFrom=$sessionTotal>0?$sessionOffset+1:0;
$sessionTo=min($sessionTotal,$sessionOffset+$sessionPerPage);

$e=$db->prepare("SELECT * FROM security_events WHERE user_id=? ORDER BY id DESC LIMIT 100");$e->execute([$userId]);$events=$e->fetchAll(PDO::FETCH_ASSOC);
$p=$db->prepare("SELECT id,name,transports,created_at,last_used_at FROM webauthn_credentials WHERE user_id=? ORDER BY id DESC");$p->execute([$userId]);$passkeys=$p->fetchAll(PDO::FETCH_ASSOC);
$pageTitle='Hesap Güvenliği';require_once __DIR__.'/header.php';
?>
<style>
.sec-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}.scard{background:var(--card-bg-color);border:1px solid var(--border-color);border-radius:16px;padding:22px;margin-bottom:20px}.scard h2{font-size:1.05rem;margin:0 0 8px}.muted2{font-size:.85rem;opacity:.7;line-height:1.6}.rowx{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:14px 0;border-bottom:1px solid var(--border-color)}.rowx:last-child{border-bottom:0}.device{display:flex;gap:12px;align-items:flex-start}.device .ico{width:40px;height:40px;border-radius:12px;background:var(--primary-alpha-012);display:grid;place-items:center;color:var(--accent-text-color)}.b2{display:inline-flex;padding:4px 8px;border-radius:99px;font-size:.72rem;font-weight:700}.ok2{background:rgba(34,197,94,.15);color:var(--success-color)}.bad2{background:var(--danger-soft-bg);color:var(--danger-color)}.warn2{background:var(--warning-soft-bg);color:var(--warning-color)}.btnx{border:0;border-radius:9px;padding:9px 12px;background:var(--primary-color);color:var(--on-primary-color);font-weight:600;cursor:pointer;text-decoration:none}.btnx.d{background:var(--danger-color)}.btnx.g{background:var(--background-color);color:var(--text-color);border:1px solid var(--border-color)}.event{display:grid;grid-template-columns:145px 160px 1fr;gap:12px;padding:11px 0;border-bottom:1px solid var(--border-color);font-size:.84rem}.empty{padding:24px;text-align:center;opacity:.65}@media(max-width:900px){.sec-grid{grid-template-columns:1fr}.event{grid-template-columns:1fr;gap:4px}}.session-card{scroll-margin-top:90px}.session-toolbar{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:15px 0}.session-toolbar form{margin:0!important}.session-count{font-size:.76rem;color:var(--muted-text-color);font-weight:650;white-space:nowrap}.session-pagination{display:flex;align-items:center;justify-content:space-between;gap:14px;padding-top:14px;margin-top:2px;border-top:1px solid var(--border-color)}.session-pagination-info{font-size:.76rem;color:var(--muted-text-color)}.session-pages{display:flex;align-items:center;gap:6px;flex-wrap:wrap;justify-content:flex-end}.session-page-link{min-width:34px;height:34px;padding:0 10px;border:1px solid var(--border-color);border-radius:9px;display:inline-flex;align-items:center;justify-content:center;background:var(--background-color);color:var(--text-color);text-decoration:none;font-size:.76rem;font-weight:700;transition:.16s ease}.session-page-link:hover{border-color:var(--primary-color);color:var(--sidebar-accent-color);background:var(--primary-alpha-01)}.session-page-link.active{border-color:var(--primary-alpha-015);background:var(--primary-alpha-015);color:var(--sidebar-accent-color)}.session-page-link.disabled{opacity:.35;pointer-events:none}.session-device-copy{min-width:0}.session-device-copy .muted2{overflow-wrap:anywhere}@media(max-width:640px){.session-toolbar,.session-pagination{align-items:flex-start;flex-direction:column}.session-pages{justify-content:flex-start}.rowx{align-items:flex-start}.rowx>form{flex:0 0 auto}.session-count{white-space:normal}}</style>
<?=showAlert()?>
<div class="sec-grid">
<div class="scard"><h2><i class="fas fa-key"></i> Passkey / WebAuthn</h2><p class="muted2">Face ID, Touch ID, Windows Hello veya güvenlik anahtarıyla şifresiz giriş ekleyebilirsiniz. Passkey yalnız HTTPS üzerinde çalışır.</p><div style="margin:16px 0"><input id="passkeyName" placeholder="Örn. MacBook Touch ID" style="padding:10px;border:1px solid var(--border-color);border-radius:9px;background:var(--background-color);color:var(--text-color)"> <button class="btnx" id="addPasskey"><i class="fas fa-plus"></i> Passkey ekle</button></div><div id="passkeyList"><?php foreach($passkeys as $pk):?><div class="rowx"><div><b><?=clean($pk['name'])?></b><div class="muted2">Eklendi: <?=clean($pk['created_at'])?> · Son kullanım: <?=clean($pk['last_used_at']??'Henüz kullanılmadı')?></div></div><button class="btnx d" onclick="deletePasskey(<?=$pk['id']?>)">Sil</button></div><?php endforeach;?><?php if(!$passkeys):?><div class="empty">Henüz passkey eklenmemiş.</div><?php endif;?></div></div>
<div class="scard session-card" id="sessions">
<h2><i class="fas fa-shield-alt"></i> Oturum Yönetimi</h2>
<p class="muted2">Hesabınıza giriş yapılmış cihazları buradan görebilir ve tek tek kapatabilirsiniz. Oturum geçmişi sayfa başına <?=$sessionPerPage?> kayıt gösterir.</p>
<div class="session-toolbar">
    <form method="post">
        <input type="hidden" name="action" value="revoke_others">
        <input type="hidden" name="session_page" value="<?=$sessionPage?>">
        <button class="btnx d" onclick="return confirm('Bu cihaz dışındaki tüm aktif oturumlar kapatılsın mı?')">Diğer tüm oturumları kapat</button>
    </form>
    <span class="session-count"><?=$sessionTotal?> oturum kaydı</span>
</div>
<?php if(!$sessions):?>
    <div class="empty">Henüz oturum kaydı bulunmuyor.</div>
<?php else:foreach($sessions as $ss):$isCurrent=hash_equals($currentHash,(string)$ss['session_hash']);?>
<div class="rowx">
    <div class="device">
        <div class="ico"><i class="fas fa-laptop"></i></div>
        <div class="session-device-copy">
            <b><?=clean($ss['device_name']?:'Bilinmeyen cihaz')?> <?=$isCurrent?'<span class="b2 ok2">Bu cihaz</span>':''?></b>
            <div class="muted2"><?=clean($ss['ip_address']??'-')?> · Son etkinlik: <?=clean($ss['last_activity_at'])?></div>
            <div class="muted2"><?=clean(substr((string)$ss['user_agent'],0,100))?></div>
        </div>
    </div>
    <?php if($ss['revoked_at']):?>
        <span class="b2 bad2">Kapatıldı</span>
    <?php else:?>
        <form method="post">
            <input type="hidden" name="action" value="revoke_session">
            <input type="hidden" name="session_id" value="<?=$ss['id']?>">
            <input type="hidden" name="session_page" value="<?=$sessionPage?>">
            <button class="btnx d" onclick="return confirm('Bu oturum kapatılsın mı?')">Kapat</button>
        </form>
    <?php endif;?>
</div>
<?php endforeach;endif;?>
<?php if($sessionTotalPages>1):?>
<div class="session-pagination" aria-label="Oturum sayfalama">
    <span class="session-pagination-info"><?=$sessionFrom?>–<?=$sessionTo?> / <?=$sessionTotal?> kayıt</span>
    <div class="session-pages">
        <a class="session-page-link <?=$sessionPage<=1?'disabled':''?>" href="?session_page=<?=max(1,$sessionPage-1)?>#sessions" aria-label="Önceki sayfa"><i class="fas fa-chevron-left"></i></a>
        <?php
        $startPage=max(1,$sessionPage-2);
        $endPage=min($sessionTotalPages,$sessionPage+2);
        if($startPage>1):?>
            <a class="session-page-link" href="?session_page=1#sessions">1</a>
            <?php if($startPage>2):?><span class="session-pagination-info">…</span><?php endif;?>
        <?php endif;?>
        <?php for($i=$startPage;$i<=$endPage;$i++):?>
            <a class="session-page-link <?=$i===$sessionPage?'active':''?>" href="?session_page=<?=$i?>#sessions" <?=$i===$sessionPage?'aria-current="page"':''?>><?=$i?></a>
        <?php endfor;?>
        <?php if($endPage<$sessionTotalPages):?>
            <?php if($endPage<$sessionTotalPages-1):?><span class="session-pagination-info">…</span><?php endif;?>
            <a class="session-page-link" href="?session_page=<?=$sessionTotalPages?>#sessions"><?=$sessionTotalPages?></a>
        <?php endif;?>
        <a class="session-page-link <?=$sessionPage>=$sessionTotalPages?'disabled':''?>" href="?session_page=<?=min($sessionTotalPages,$sessionPage+1)?>#sessions" aria-label="Sonraki sayfa"><i class="fas fa-chevron-right"></i></a>
    </div>
</div>
<?php endif;?>
</div>
</div>
<div class="scard"><h2><i class="fas fa-history"></i> Giriş ve Güvenlik Geçmişi</h2><p class="muted2">Başarılı/başarısız girişler, passkey ve oturum işlemleri gibi güvenlik olayları tutulur.</p><?php if(!$events):?><div class="empty">Henüz güvenlik olayı yok.</div><?php else:foreach($events as $ev):$lbl=['login_success'=>'Başarılı giriş','login_failed'=>'Başarısız giriş','login_rate_limited'=>'Giriş hız limiti','passkey_added'=>'Passkey eklendi','passkey_removed'=>'Passkey silindi','session_revoked'=>'Oturum kapatıldı','other_sessions_revoked'=>'Diğer oturumlar kapatıldı','two_factor_failed'=>'Hatalı 2FA','revoked_session_blocked'=>'Kapatılmış oturum engellendi'][$ev['event_type']]??$ev['event_type'];?><div class="event"><span><?=clean($ev['created_at'])?></span><span><span class="b2 <?=$ev['severity']==='critical'?'bad2':($ev['severity']==='warning'?'warn2':'ok2')?>"><?=clean($lbl)?></span></span><span><?=clean($ev['ip_address']??'-')?> · <?=clean(moni_device_name($ev['user_agent']??''))?></span></div><?php endforeach;endif;?></div>
<script>
function b64uToBuf(v){v=v.replace(/-/g,'+').replace(/_/g,'/');while(v.length%4)v+='=';const b=atob(v),o=new Uint8Array(b.length);for(let i=0;i<b.length;i++)o[i]=b.charCodeAt(i);return o.buffer}
function bufToB64u(v){const a=new Uint8Array(v);let s='';a.forEach(b=>s+=String.fromCharCode(b));return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
async function api(body){const r=await fetch('/webauthn.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json();if(!d.success)throw new Error(d.error||'İşlem başarısız.');return d}
document.getElementById('addPasskey')?.addEventListener('click',async()=>{if(!window.PublicKeyCredential){alert('Bu tarayıcı Passkey/WebAuthn desteklemiyor.');return}try{const d=await api({action:'register_options'}),o=d.publicKey;o.challenge=b64uToBuf(o.challenge);o.user.id=b64uToBuf(o.user.id);o.excludeCredentials=(o.excludeCredentials||[]).map(x=>({...x,id:b64uToBuf(x.id)}));const c=await navigator.credentials.create({publicKey:o});if(!c.response.getPublicKey||!c.response.getAuthenticatorData)throw new Error('Tarayıcı gerekli Passkey güvenlik verilerini dışa aktarmayı desteklemiyor.');const pub=c.response.getPublicKey(),authData=c.response.getAuthenticatorData(),alg=c.response.getPublicKeyAlgorithm?c.response.getPublicKeyAlgorithm():-7;await api({action:'register_finish',credentialId:bufToB64u(c.rawId),clientDataJSON:bufToB64u(c.response.clientDataJSON),authenticatorData:bufToB64u(authData),publicKey:bufToB64u(pub),algorithm:alg,transports:(c.response.getTransports?c.response.getTransports():[]).join(','),name:document.getElementById('passkeyName').value.trim()});location.reload()}catch(e){if(e.name!=='NotAllowedError')alert(e.message||'Passkey eklenemedi.')}});
async function deletePasskey(id){if(!confirm('Passkey silinsin mi?'))return;try{await api({action:'delete',id});location.reload()}catch(e){alert(e.message)}}
</script>
<?php require_once __DIR__.'/footer.php'; ?>
